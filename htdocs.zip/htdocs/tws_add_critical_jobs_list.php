<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html><head>
<title>Add Critical Jobs List</title>
<?php tws_stylesheet(); ?>
</head>
<body>
<?php tws_set_window_title(); ?>

<h1>Add Critical Jobs List</h1>
<br><br>

<form method=post name="contents" action="tws_add_critical_jobs_list_exec.php">
<table border=0 cellspacing=0>
<tr>
<td class=standard width=120>
&nbsp;&nbsp;<b>Description:</b>
</td>
<td class=standard>
<input type="text" name="description" size=40 maxlength=255>
</td>
</tr>
<? 
if(tws_profile('is_admin')){ ?>
   <tr><td></td>
      <td><label><input type="checkbox" name="forall" value="yes">Save for all users</label></td></tr>
<? } ?>

</table>
<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Add">&nbsp;&nbsp;
<input type="button" name="action" value="Cancel" onclick="window.location.replace('tws_critical_jobs_lists.php');">
</form>
</body>
</html>
