<?php
//   HORIZONT Software GmbH, Munich
//
   $__tlogmode='APPEND';
   require_once 'tws_functions.php';

   tws_import_request_variables("P","rqst_");

   $fieldname=@$rqst_fieldname;
   tws_check_elname($fieldname);
   $fieldvalue=@$rqst_fieldvalue;
   $allowmultiple=@$rqst_allowmultiple;
   $caret=@$rqst_caret;
   $append=@$rqst_append;
   $insert=@$rqst_insert;
   $display="yes";

   if (!isset($fieldname)) {
      $fieldname="parameter_table";
   }

   if ((strpos($fieldname,"[") !== FALSE) && (strpos($fieldname,"]") !== FALSE)) {
      $jsfieldname="elements['" . $fieldname . "']";
   }
   else {
      $jsfieldname = $fieldname;
   }
?>
<script type="text/javascript">

function sendValue(formsel) {
 var selectionval = "";
 if(formsel) {
   for (var i = 0; i < formsel.options.length; i++) {
     if (formsel.options[i].selected) {
         selectionval = selectionval + formsel.options[i].value + ",";
     <?php
     if ($caret == "yes") {
     ?>
         selectionval="^" + selectionval.substr(0, selectionval.length - 1) + "^,";
     <?php
     }
     ?>
     }
   }
   selectionval=selectionval.substr(0, selectionval.length - 1);
   <?php
   if ($insert == "yes") {
      echo " if (window.document.selection) {\n";
      echo "    window.document.contents.$jsfieldname.focus();\n";
      echo "    sel = window.document.selection.createRange();\n";
      echo "    sel.text = selectionval;\n";
      echo " } else if (window.document.contents.$jsfieldname.selectionStart || window.document.contents.$jsfieldname.selectionStart == '0') {\n";
      echo "    var startpos = window.document.contents.$jsfieldname.selectionStart;\n";
      echo "    var endpos = window.document.contents.$jsfieldname.selectionEnd;\n";
      echo "    window.document.contents.$jsfieldname.value = window.document.contents.$jsfieldname.value.substring(0, startpos) + selectionval + window.document.contents.$jsfieldname.value.substring(endpos, window.document.contents.$jsfieldname.value.length);\n";
      echo "    window.document.contents.$jsfieldname.selectionStart = startpos + selectionval.length;\n";
      echo "    window.document.contents.$jsfieldname.selectionEnd = startpos + selectionval.length;\n";
      echo " } else {\n";
      echo "    window.document.contents.$jsfieldname.value += selectionval;\n";
      echo " }\n";
   } elseif ($append == "yes") {
      echo " window.document.contents.$jsfieldname.value += selectionval;\n";
   } else {
      echo " window.document.contents.$jsfieldname.value = selectionval;\n";
   }
   ?>
 }
   $('[name="<?=$fieldname?>"]').keyup();
   $("#parameter_table_picker").dialog( "close" );
}

</script>

<div id="parameter_table_picker">

<h1>Select Parameter Table</h1>
<?php
   if ($fieldvalue == "") {
      $arg="@";
   } else {
      if ((strpos($fieldvalue,"*") === FALSE) && (strpos($fieldvalue,"@") === FALSE)) {
         $arg=$fieldvalue . "@";
      } elseif (strpos($fieldvalue,"*") !== FALSE) {
         $arg=strtr($fieldvalue,"*","@");
      } else {
         $arg=$fieldvalue;
      }
   }

   if (($parameter_tables = tws_get_parameter_tables($arg)) === FALSE) {
      echo "<center><p class=warning>Unable to list parameter tables</p></center>\n";
      //echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\">\n";
   }
?>
<form name="parameter_table_list" action="">
<?php
   if ($parameter_tables['parameter_table_num']==0) {
      echo "<center><p class=warning>No parameter table entries matching '".htmlspecialchars($arg)."' criteria found.</p>\n";
      echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\"></center>\n";
   } else {
      echo '<select class="picker" name="selection" size=15 onDblClick="sendValue(this.form.selection);"',($allowmultiple=='yes' ? ' multiple' : ''),'>',"\n";
      foreach ($parameter_tables['parameter_table_name'] as $name) {
         echo '   <option value="',$name,'">',$name,'</option>',"\n";
      }
      echo '</select>',"\n";
      echo '<center><input type="button" value="OK" onClick="sendValue(this.form.selection);"></center>',"\n";
   }
?>
</form>
</div>

<script type="text/javascript">

$(function() {
   tws_picker_constructor("parameter_table_picker");
});

</script>
