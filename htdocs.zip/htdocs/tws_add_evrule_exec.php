<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   require_once "tws_evt.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add/Copy/Modify Event Rule</title>
<?php
tws_stylesheet();
evt_js();
tws_show_backup();
?>
<script type="text/javascript">
   function ConfirmCancel(objectname, url) {
   tws_waiting(0);
      var conftext = confirm("Exit " + objectname + " Definition (Changes will be lost) ?");
      if (conftext) {
         if (url==null) return true;
         if(window.name == 'tws_popup')  window.close();
         else window.location.replace(url);
      } else {
         return false;
      }
   }

   $(function() {
      $('#tabs table').css('font-size','0.9em');
      $('#tabs table').css('padding','0');
      $('#tabs table').css('margin','1px');
//      $('#tabs table td').css('padding','0');
      $('#tabs table td').css('margin','0');

      $("#tabs").tabs();
      $("#tabs").css("background-color","transparent");
      $("#tabs").css("border","none 0px");
   });
</script>
</head>
<body>
<?php tws_set_window_title(); ?>

<?php
   tws_check_synchro_token();    // synchro_token
   $original_data=tws_gpc_get($rqst_original_data);
   $confirm=tws_gpc_get($rqst_confirm);
   $modify=tws_gpc_get($rqst_modify);
   $copy=tws_gpc_get($rqst_copy);
   $backup=tws_gpc_get($rqst_backup);

   if ($modify == "yes") {
      if (!tws_permit_action('database_evrules','Modify')) { tws_access_denied ();}
   }
   else {
      if (!tws_permit_action('database_evrules','Add')) { tws_access_denied ();}
   }


// Check for existing event rule
   $match=FALSE;
   if ($confirm != "yes") {
      $evrules=tws_get_evrules_from_post($_POST);
      $events=tws_get_evrule_conditions_from_post($_POST);
      $actions=tws_get_evrule_actions_from_post($_POST);
      $cmd=tws_get_evrule_xml($evrules, $events, $actions);

      if (($db_evrule=tws_get_evrules($evrule_name)) === FALSE) {
         tws_dyer("Unable to list event rules");
      }
      if ($db_evrule['evrule_num'] > 1) {
         tws_dyer("Database query failed");
      }
      if (($db_evrule['evrule_num'] == 1) && ($db_evrule['evrule_name'][0] == $evrule_name)) {
         $match=TRUE;
      }
   } else {
      $cmd=tws_gpc_get($_POST['cmd']);
   }

   if ($match == TRUE) {
      if ($modify == "yes") {
         echo "<h1>Confirmation</h1>\n";
      } else {
         echo "<h1>Replace Event Rule Confirmation</h1>\n";
      }

      echo "<h3>Confirm:</h3>\n";
      if ($modify != "yes") {
         echo "<p class=\"warning\">The Event Rule Name entered already exists</p>\n";
      }

      $data=array('evrules'=>$evrules, 'events'=>$events, 'actions'=>$actions);
      echo '<div id="tabs">'."\n";
      echo '<ul>'."\n";
      echo '  <li><a href="#display">'.($modify=='yes' ? 'Modified' : 'New').' Event Rule'.'</a></li>'."\n";
      echo '  <li><a href="#xmldiff">Text Diff</a></li>'."\n";
      echo '</ul>'."\n";

      echo '<div id="display">'."\n";
      echo tws_evrule_display($data);
      echo '</div>'."\n";
      echo '<div id="xmldiff">'."\n";
      $orig_data_scopeless=preg_replace('!<scope>.*</scope>\s*<!sU','<', $original_data);
      $orig_data_scopeless=preg_replace('/$\s*$/m','',$orig_data_scopeless);
      $orig_er=array('xml'=>$orig_data_scopeless);
      $new_er=array('xml'=>$cmd);
      $label_map=Array('xml'=>'Event Rule Text Definition');
      if (tws_show_cmp_table('Original Event Rule', ($modify=='yes' ? 'Modified' : 'New').' Event Rule', $orig_er, $new_er, $label_map)===FALSE) {
         tws_err();
      }
      echo '</div>'."\n";
      echo '</div>'."\n";//div#tabs

      echo "<form method=post name=\"confirm\" action=\"tws_add_evrule_action.php\" onsubmit=\"if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Event Rule',null)) { cancel_button_pressed=false; return false;}\">\n";

      echo tws_create_hidden_inputs($data, '', NULL);

      echo "<input type=\"hidden\" name=\"confirm\" value=\"yes\">\n";
      if ($original_data=='') {
//missing original data - this happens if user is adding event rule that already exists.
         if (($original_data=tws_composer_create_from("er=$evrule_name"))===FALSE) {
            tws_err("Unable to get original data required to create the backup.");
         }
      }
      echo "<input type=\"hidden\" name=\"original_data\" value=\"".htmlspecialchars($original_data)."\">\n";
      echo "<input type=\"hidden\" name=\"cmd\" value=\"".htmlspecialchars($cmd)."\">\n";
      if (tws_rights(SAVEBACKUPS) && $original_data!=''){
         echo "<input type='hidden' name='backup' value='yes'>";
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type='checkbox' name='backup' value='yes' checked disabled>&nbsp;Save Backup Copy of Original Event Rule</label>\n";
      }
      else
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type=\"checkbox\" name=\"backup\" value=\"yes\" ".($original_data!='' ? 'checked' : 'disabled').">&nbsp;Save Backup Copy of Original Event Rule</label>\n";
      echo "<br><br><br>\n";
      if ($modify == "yes") {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Update\" name=\"action\">\n";
         echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
         echo "<input type=\"hidden\" name=\"evrule_namex\" value=\"".htmlspecialchars($evrule_namex)."\">\n";
      } else {
         if ($copy=="yes") {
            echo "<input type=\"hidden\" name=\"copy\" value=\"yes\">\n";
         }
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input name=\"action\" type=\"submit\" value=\"Replace\">\n";
      }
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input name=\"action\" type=\"submit\" value=\"Return to Event Rule Modification\">\n";
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input name=\"action\" type=\"submit\" value=\"Cancel\" onClick=\"cancel_button_pressed=true;\">\n";
      tws_print_synchro_token();  // synchro token
      echo "</form>\n";

   } else {
// Create Backup Copy if option checked
      if ($backup == "yes") {
         if (($bckfilename = tws_write_backup($original_data, "evrule", $evrule_name)) === FALSE) {
            tws_dyer("Unable to write backup");
         }
      }

// unlock the object
      tws_composer_unlock("er=$evrule_name");

      $tmpfilename="$maestro_dir/webadmin/tmp/evrule.".tws_rndstr().".tmp";
      $fp=fopen($tmpfilename,'w') or tws_dyer("Unable to create temporary file '$tmpfilename'");
      $num_bytes=fwrite($fp,$cmd);
      fclose($fp);
      if ($num_bytes===FALSE) {
         tws_dyer("Unable to write temporary file '$tmpfilename'");
      }
      tws_chmod($tmpfilename,0644);

      if ($confirm == "yes") {
         $command=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "replace $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      } else {
         $command=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "add $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      }

      $stdout='';$ec='';
      $ec_popen=tws_popen($command, $ec, $stdout, $stdout, "N");
     
      //remove the tmp file now
      unlink($tmpfilename);
 
      //testing for the AWSBIA288I Total objects updated: 0.
      //Note: This has been added on 2016-07 to fix the problem of composer updating 
      //correctly objects but returning incorrect return codes (not 0 or 4)
      $not_updated=!preg_match('/AWSBIA288[^\n]+(\d+)/', $stdout, $_r) || $_r[1]==0;

      if ($ec_popen===FALSE || ($ec!=0 && $ec!=4 && $not_updated)) {
         if ($modify == "yes") {
            echo "<h1>Modify Event Rule Status</h1>\n";
         } else {
            echo "<h1>Add Event Rule Status</h1>\n";
         }
         tws_err("Event Rule add/modify operation failed", array('twsdef'=>$command->compile('log'), 'stdout'=>$stdout, "EC_POPEN"=>$ec_popen, "EC_UPDATED"=>$ec, "NOT_UPDATED"=>tws_yesno($not_updated,'YES','NO')));

         echo "<form action=\"tws_add_evrule_action.php\" method=\"post\" onsubmit=\"if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Event Rule',null)) { cancel_button_pressed=false; return false;}\">\n";

         if (is_array($evrules)) {
            $data=array('evrules'=>$evrules, 'events'=>$events, 'actions'=>$actions);
            echo tws_create_hidden_inputs($data, '', NULL);
         } else echo tws_create_hidden_inputs($_POST);
         tws_print_synchro_token();
         echo "<input type=\"submit\" name=\"action\" value=\"Cancel\" onClick=\"cancel_button_pressed=true;\"/>\n";
         echo "<input type=\"submit\" name=\"action\" value=\"Return to Event Rule Modification\"/>\n";
         echo "</form>";
      } else {
          if (preg_match("/warnings?\s[1-9]/i",$stdout)) {
              if ($modify == "yes") {
                  $headertext="Modify Event Rule";
              } else {
                  $headertext="Add Event Rule";
              }
              tws_err("The Event Rule has been saved with the following warnings:", array('stdout'=>$stdout));

              $shortwarnfilename="warn.".tws_rndstr().".txt";
              $warnfilename="$webadmin_tmp_dir/$shortwarnfilename";
              $warnfp=fopen("$warnfilename","w") or tws_dyer("Unable to create warning text file", "Warning output :\n$stdout");
              $num_bytes=fwrite($warnfp,$stdout);
              if ($num_bytes < 0) {
                  fclose($warnfp);
                  unlink($warnfilename);
                  tws_dyer("Unable to write warning text file", "Warning output :\n$stdout");
              }
              fclose($warnfp);
              tws_dyer();
          } else {
              if ($backup == "yes") {
                  if ($modify == "yes") {
                      echo "<h1>Modify Event Rule Status</h1>\n";
                  } else {
                      echo "<h1>Add Event Rule Status</h1>\n";
                  }
                  echo "<p class=\"message\">\n";
                  echo "The event rule has been successfuly saved.&nbsp;";
                  $bckfilename = preg_replace("/\\\\/", '/', $bckfilename);
                  $file = explode('/',$bckfilename);
                  $file = end($file);
                  if(tws_profile('auth_user_group')=='admin')
                     echo "<a href=\"javascript:showBackup('$file')\">Display Backup File</a>\n";
                  echo "</p>\n";
                     echo "<input type='button' value='OK' onClick=\"closeme('tws_evrulesx.php')\">\n";
              } else {
                  echo "<script type='text/javascript'>
                  closeme('tws_evrulesx.php');
                  </script>\n";
              }
          }
      }
   }
?>
</body>
</html>
