<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Modify Jobstream</title>
<? tws_stylesheet();
   tws_set_window_title();
   
   $date_format = tws_profile('date_format');
?>
<script type="text/javascript" src="tws_insert_row.js"></script>
<script type="text/javascript">
var cancel_button_pressed=false;
var ignore_err_tooltip = true;   // don't show err_tooltip
var display = false;
<? if($display == 'yes'){  // for add_jobstream_js ?>
   display = true;
<? } ?>

function tws_onSubmit(myform) {

   if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Jobstream',null)) {
      cancel_button_pressed=false;
      return false;
   }
   // Confirmed Cancel
   if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed) {
      return true;
   }
   setjobnames('storage');
}
</script>

<style type="text/css">

table.transparent {
    background-color:transparent;
}
</style>
</head>

<body>
<?
   if (!isset($copy))
      @$copy=$_POST['copy'];
   if (!isset($modify))
      @$modify=$_POST['modify'];
   @$override=$_POST['override'];

   if (tws_zli_module_check ()) {
      $netmodule_file = "";
      $netmodule_show_prompt = "";
      $netmodule_show_internet = "";
      $netmodule_show_file = "";
      $netmodule_show_resource = "";
      if (isset ($rqst_netmodule_file))
         $netmodule_file=$rqst_netmodule_file;
      if (isset ($rqst_netmodule_show_prompt))
         $netmodule_show_prompt=$rqst_netmodule_show_prompt;
      if (isset ($rqst_netmodule_show_internet))
         $netmodule_show_internet=$rqst_netmodule_show_internet;
      if (isset ($rqst_netmodule_show_file))
         $netmodule_show_file=$rqst_netmodule_show_file;
      if (isset ($rqst_netmodule_show_resource))
         $netmodule_show_resource=$rqst_netmodule_show_resource;
   }

   $log_file_name=tws_log('', 'OPEN');
   tws_log('-- START ('.basename(__FILE__).'['.__LINE__.'])');

   if (isset($_POST['action']) && preg_match('/return/i',$_POST['action'])) {    // return from exec

      if ($copy == "yes") 
          $h1="Copy Jobstream";
      elseif($modify == "yes")
         $h1="Modify Jobstream ".$_POST['workstation']."#".$_POST['jobstream'];
      else 
         $h1 = "Add Jobstream";

      // read POSTed params
      $stream_data = $_POST;
//      tws_arr_to_form('jobstream', $_POST['action'], $_POST);
      //exit;
   }
   elseif ( $copy == "yes" || $modify == "yes" || $display == "yes" ) {   // from tws_jobstreamsx.php
      $num_elements=count($selection);
      if ($num_elements == 0)
         tws_dyer("No jobstream selected");
      elseif ($num_elements > 1)
         tws_dyer("Multiple jobstreams selected - Only one jobstream can be modified at a time");

   if (isset($selection[0])) {
      $workstation=strtok($selection[0],"#");
      $jobstream=strtok(":");
      if ($validfrom=tws_make_iso_valid_from(strtok("\n")))
         $tws_validfrom="valid from ".tws_date_from_iso($validfrom);
      else
         $tws_validfrom='';
   }
   else
      tws_dyer("Unable to read selected jobstream name");

      if ($copy == "yes"){
         $h1="Copy Jobstream";
         $action = "copy";
      }
      elseif ($display == "yes"){
         $h1="Display Jobstream $workstation#$jobstream";
         $action = "display";
      }
      else{
         $h1="Modify Jobstream $workstation#$jobstream";
         $action = "modify";
      }

      if(empty($original_data)){
         if ($modify=="yes")
            tws_composer_lock("js=$workstation#$jobstream $tws_validfrom") or tws_dyer("Unable to lock jobstream");
         //get the original data to be able to save backup (if needed) later on...
         if (($original_data=tws_get_jobstream_definition_text($workstation,$jobstream,$validfrom))===FALSE)
            tws_err("Unable to get jobstream original data");
            // tws_dyer("Unable to get jobstream original data");
      }
      $id = "$workstation#$jobstream";
      if(!empty($validfrom)) $id .= ":$validfrom";
      $stream_data = tws_dbobject_to_array('jobstream', $id);
   }
   else {
         $h1 = "Add Jobstream";
         $stream_data = array();
         $action = 'add';
   }

tws_print_head($h1, array('__help__' => 'tws_add_jobstream_help.php', '__log__' => $log_file_name) );
?>

<form method=post name="contents" action="tws_add_jobstream4_action.php" onsubmit="return tws_onSubmit(this);">
<?
   tws_arr_to_form('jobstream', $action, $stream_data);
?>
<br>
<?
   if ($modify == "yes") {
      echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
      echo "<input type=\"hidden\" name=\"locked\" value=\"yes\">\n";
      echo "<input type=\"hidden\" name=\"workstationx\" value=\"".htmlspecialchars($workstation)."\">\n";
      echo "<input type=\"hidden\" name=\"jobstreamx\" value=\"".htmlspecialchars($jobstream)."\">\n";
      echo "<input type=\"hidden\" name=\"validfromx\" value=\"".htmlspecialchars($validfrom)."\">\n";
      echo "<input type=\"hidden\" name=\"original_data\" value=\"".htmlspecialchars($original_data)."\"/>\n";
   } else {
      echo "<input type=\"hidden\" name=\"modify\" value=\"no\">\n";
   }
   if ($copy == "yes") {
      echo "<input type=\"hidden\" name=\"copy\" value=\"yes\">\n";
   } else {
      echo "<input type=\"hidden\" name=\"copy\" value=\"no\">\n";
   }
   echo "<input type=\"hidden\" name=\"override\" value=\"".htmlspecialchars($override)."\">\n";

   if (tws_zli_module_check ()) {
       echo "<input type=\"hidden\" name=\"netmodule_file\" value=\"".htmlspecialchars($netmodule_file)."\">\n";
       echo "<input type=\"hidden\" name=\"netmodule_show_file\" value=\"".htmlspecialchars($netmodule_show_file)."\">\n";
       echo "<input type=\"hidden\" name=\"netmodule_show_resource\" value=\"".htmlspecialchars($netmodule_show_resource)."\">\n";
       echo "<input type=\"hidden\" name=\"netmodule_show_prompt\" value=\"".htmlspecialchars($netmodule_show_prompt)."\">\n";
       echo "<input type=\"hidden\" name=\"netmodule_show_internet\" value=\"".htmlspecialchars($netmodule_show_internet)."\">\n";
   }

if ($display!='yes'){
   echo '&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Save Jobstream" onclick="return tws_validate_form();">';

    if (tws_zli_module_check () && $netmodule_file != "")
        ;
    else {
        if ($modify=="yes")
            echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' name='action' value='Cancel' formnovalidate='formnovalidate' onClick='cancel_button_pressed=true;'>\n";
        else
            echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' value='Cancel' onClick=\"ConfirmCancel('Jobstream','tws_jobstreamsx.php')\"/>\n";
    }
}
else{
      echo '<input type="button" value="Print" id="print_button" onClick="window.print();">&nbsp;&nbsp;&nbsp;';
      echo "<input type='button' value='Close' id='close_button' onClick='window.close();'>\n";
}
   if (tws_zli_module_check() && !empty($netmodule_file)) {
       echo "<input type=\"hidden\" name=\"netmodule_file\" value=\"".htmlspecialchars($netmodule_file)."\">\n";
       echo "<input type=\"hidden\" name=\"netmodule_show_file\" value=\"".htmlspecialchars($netmodule_show_file)."\">\n";
       echo "<input type=\"hidden\" name=\"netmodule_show_resource\" value=\"".htmlspecialchars($netmodule_show_resource)."\">\n";
       echo "<input type=\"hidden\" name=\"netmodule_show_prompt\" value=\"".htmlspecialchars($netmodule_show_prompt)."\">\n";
       echo "<input type=\"hidden\" name=\"netmodule_show_internet\" value=\"".htmlspecialchars($netmodule_show_internet)."\">\n";
   }

tws_print_synchro_token();   // synchro_token
   tws_log('-- FINISH ('.basename(__FILE__).'['.__LINE__.'])', 'CLOSE');
?>
</form>
</body>
</html>
