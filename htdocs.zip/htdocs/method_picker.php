<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";

   tws_import_request_variables("P","rqst_");

   $fieldname=$rqst_fieldname;
   tws_check_elname($fieldname);
   $allowmultiple=$rqst_allowmultiple;
   $display="yes";

   if (!isset($fieldname)) {
      $fieldname="method";
   }

   if ((strpos($fieldname,"[") !== FALSE) && (strpos($fieldname,"]") !== FALSE)) {
      $jsfieldname="elements['" . $fieldname . "']";
   }
   else {
      $jsfieldname = $fieldname;
   }
?>
<script type="text/javascript">

function sendValue(formsel) {
 var selectionval = "";
 if(formsel) {
   for (var i = 0; i < formsel.options.length; i++)
      if (formsel.options[i].selected)
         selectionval = selectionval + formsel.options[i].value + ",";
   window.document.contents.<?php echo $jsfieldname ?>.value = selectionval.substr(0, selectionval.length - 1);
 }
 $('[name="<?=$fieldname?>"]').keyup();
 $("#method_picker").dialog( "close" );
}

</script>

<div id="method_picker">

<h1>Select Method</h1>
<br>

<form name="method_list">

<?php
   $method_num=0;

   $methods_dir="$maestro_dir/methods";

   if (!is_dir($methods_dir)) {
      echo "<center><p class=warning>No methods available</p>\n";
      echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\"></center>\n";
   } else {
      $dp=opendir($methods_dir);
      while (($filename=readdir($dp))!==FALSE) {
         if(!is_file("$methods_dir/$filename")) continue;
         if ($host_os == "win32") {
            if (strtoupper(substr($filename,-4,4)) == ".EXE") {
               $method_num++;
               $method[$method_num]=substr($filename,0,-4);
            }
         } else {
            if (strpos($filename,".") === FALSE) {
               $method_num++;
               $method[$method_num]=$filename;
            }
         }
      }
      closedir($dp);

      if ($method_num == 0) {
         echo "<center><p class=warning>No methods available</p>\n";
         echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\"></center>\n";
      } else {
         echo "<select name=\"selection\" class=\"picker\" size=14 onDblClick=\"sendValue(this.form.selection);\"";
         if ($allowmultiple == "yes") {
            echo " multiple";
         }
         echo ">\n";

         for ($i=1; $i<=$method_num; $i++) {
            echo "<option value=\"$method[$i]\">$method[$i]</option>\n";
         }
         echo "</select>\n";
         echo "<br><br>\n";
         echo "<center><input type=\"button\" value=\"OK\" onClick=\"sendValue(this.form.selection);\"></center>\n";
      }
   }
?>
</form>
</div>
<script type="text/javascript">
$(function() {
   tws_picker_constructor("method_picker");
});
</script>