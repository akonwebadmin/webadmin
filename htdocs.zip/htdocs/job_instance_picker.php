<?php
//   HORIZONT Software GmbH, Munich
//
   require_once "tws_functions.php";

   if (defined('IWD_PROCMAN')) {
      $iwd_class='iwd_dbcal';
      $search_elems=array();
      $search=$iwd_class::get_search_elems($search_elems, 'ref');
   }

   tws_import_request_variables("P","rqst_");

   $cpux=strtoupper(trim($rqst_cpux));
   $schedulex=strtoupper(trim($rqst_schedulex));
   $jobfieldname=$rqst_jobfieldname;
   $jsfieldname=$rqst_jsfieldname;
   $wksfieldname=$rqst_wksfieldname;
   tws_check_elname($jobfieldname);
   tws_check_elname($jsfieldname);
   tws_check_elname($wksfieldname);
   $fieldvalue=$rqst_fieldvalue;
   @$allowmultiple=$rqst_allowmultiple;
   @$thiscpu=$rqst_thiscpu;
   @$thissched=$rqst_thissched;
   @$thisjob=$rqst_thisjob;
   @$validfrom=$rqst_validfrom;
   $display="yes";
?>
<script type="text/javascript">

function updateValue(ws,js,jb) {
      //window.document.contents.<?=$wksfieldname?>.value = ws;
      //window.document.contents.<?=$jsfieldname?>.value = js;
      //window.document.contents.<?=$jobfieldname?>.value = jb;

      //ws!==null && $('input:text[name="<?=$wksfieldname?>"]').val(ws);
      //ws!==null && $('input:text[name="<?=$wksfieldname?>"]').keyup();
      //js!==null && $('input:text[name="<?=$jsfieldname?>"]').val(js);
      //js!==null && $('input:text[name="<?=$jsfieldname?>"]').keyup();
      jb!==null && $('input:text[name="<?=$jobfieldname?>"]').val(jb);
      $('input:text[name="<?=$jobfieldname?>"]').keyup();
}

function sendValue(formsel) {
   if (formsel) {
      var selval = "";
      for (var i = 0; i < formsel.options.length; i++)
         if (formsel.options[i].selected)
            selval = formsel.options[i].value;
      updateValue(selval.substr(0, selval.indexOf('#')), selval.substr(selval.indexOf('#')+1, selval.indexOf('.')-selval.indexOf('#')-1), selval.substr(selval.indexOf('.')+1,selval.length - selval.indexOf('.') ));
   }
   $("#job_instance_picker").dialog("close");
}

   <?php
      if (defined('IWD_PROCMAN')) {
         if (trim($fieldvalue)=='') {
            $fieldvalue=$search_elems[$iwd_class][0];
            echo "updateValue(null, null, '".$fieldvalue."');\n";
         }
      }
    ?>
</script>

<div id="job_instance_picker">

<form name="job_list" action="">

<? tws_log("job_instance picker params: thiscpu='$thiscpu', thissched='$thissched', thisjob='$thisjob', cpux='$cpux', schedulex='$schedulex'");
if ($thiscpu!="" && $thissched!="" && $thisjob!="" && trim($cpux)=='' && trim($schedulex)=='') {
   // Used in job properties
?>
<h1>Select Internal Job Dependency</h1>
<br>

<select name="selection" size=14  class="picker" onDblClick="sendValue(this.form.selection);" <? if ($allowmultiple == "yes") { echo " multiple";} ?> >

</select>

<script type="text/javascript">

var jobcount=0;
control=window.opener.document.contents["jobs"];
numjobs=control.length;
for (i=0; i<numjobs; i++) {
  jobname=control.options[i].value;
  jobcount++;
  splitpos=jobname.indexOf("#");
  if (splitpos != -1) {
    optjobname=jobname.substring(splitpos + 1);
  } else {
    optjobname=jobname;
  }
  var folder_pos = optjobname.lastIndexOf('/');
  if(folder_pos != -1)
     optjobname = optjobname.substring(folder_pos + 1);

  jobname = jobname.toUpperCase();
  aspos=jobname.indexOf(" AS ");
  if (aspos!=-1) optjobname=jobname.substring(aspos + 4);

  if (jobname != '<?=htmlspecialchars($thisjob) ?>') {
      $('select[name="selection"]').append('<option value="' + optjobname + '">' + optjobname + '</option>');
  }
}

if (jobcount == 0) {
   $('select[name="selection"]').after ("<br><br><center><p class=warning>No jobs found for <?=htmlspecialchars("$cpux#$schedulex")?> </p><input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\"></center>");
} else {
   $('select[name="selection"]').after ("<br><br><center><input type=\"button\" value=\"OK\" onClick=\"sendValue(this.form.selection);\"></center>");
}

</script>

<?
   }
   // External Job Dependencies
   else {
      $skip=FALSE; $error=FALSE;
      echo "<h1>Select Job</h1>\n";

      if (trim($schedulex) == "") {
         echo "<center><p class=warning>No Jobstream selected</p>\n";
         echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\"></center>\n";
      }
   else{

      if (trim($cpux) == '') $cpux = '*';
      if (trim($schedulex) == '') $schedulex = '*';
      if (trim($fieldvalue) == '') $fieldvalue = '*';
      if (preg_match('/[*@]/', $cpux) || preg_match('/[*@]/', $schedulex))
         $show_full_name = true;

      tws_display_info(array('Workstation'=>$cpux,'Jobstream'=>$schedulex), false);

      if (defined('IWD_PROCMAN')) {
         //check if $cpux#$chedulex is in current transaction
         $tos=$iwd->get_transaction_summary();
         foreach ($tos as $to) {
            if ($to['archive']==iwd_dbjs::get_type(IWD_INTERIM_STORAGE) && $to['path']==$cpux.'#'.$schedulex) {
               try {
                  $too=new iwd_to($to);
                  $too_data=$too->obj->get_data();
                  echo '<select name="selection" class="picker" size="14" onDblClick="sendValue(this.form.selection);" '.($allowmultiple ? ' multiple' : '').'>'."\n";
                  if (isset($too_data['jobname'])) {
                     foreach ($too_data['jobname'] as $jobname) {
                        echo '<option value="'.$too->obj->get_name().'.'.(substr($jobname,(($p=strpos($jobname,'#'))===FALSE ? 0 : $p+1))).'">'.$jobname.'</option>'."\n";
                     }
                  }
                  echo "</select>\n";
                  $skip=TRUE; $error=FALSE;
               } catch (Exception $e) {$row=TRUE;}
            }
         }
      }

      if (!$skip) {
         if (!db_connect($composer_db,DB_PERSISTENT) ) {
            tws_warning("Cannot connect to database");
            echo '<script> sendValue(null); </script>'."\n";
         }
         $schema = $composer_db['schema'];

         // add this selection in case that valid from information is to be displayed
         if ($validfrom=="yes") $valid_from_sel=" JST.JST_VALID_FROM VALID_FROM, JST.JST_VALID_TO VALID_TO ";
         else $valid_from_sel="";

         // **********  FOLDERS  ********** //
         $stream_folder = '';
         $ws_folder = '';

         if ($tws_config['cpuinfo']['version']>='9.5'){
            $pos = strrpos($schedulex, '/');
               $stream_folder = substr($schedulex, 0, $pos+1 );
               $schedulex = substr($schedulex, $pos+1 );
         }
         if ($tws_config['cpuinfo']['version']>='9.5002'){
            $pos = strrpos($cpux, '/');
               $ws_folder = substr($cpux, 0, $pos+1 );
               $cpux = substr($cpux, $pos+1 );
         }

         $query="SELECT DISTINCT
               WKC.WKC_NAME      WKC,
               AJS.AJS_NAME      AJS,
               AJB.AJB_NAME      AJB
               $valid_from_sel";

         if ($tws_config['cpuinfo']['version']>='9.5')
            $query .= ",
            JS_FOLDER.FOL_PATH   STREAM_FOLDER";
         if ($tws_config['cpuinfo']['version']>='9.5002')
            $query .= ",
            WS_FOLDER.FOL_PATH   WORKSTATION_FOLDER";
         $query .= "
            FROM (((( $schema.JOB_JOBS          JOB
               JOIN $schema.AJB_ABSTRACT_JOBS   AJB   ON    AJB.AJB_ID = JOB.AJB_ID)
               JOIN $schema.JST_JOB_STREAMS     JST   ON    JST.JST_ID = JOB.JST_ID)
               JOIN $schema.AJS_ABSTRACT_JOB_STREAMS  AJS   ON AJS.AJS_ID = JST.AJS_ID)
               JOIN $schema.WKC_WORKSTATION_CLASSES   WKC   ON WKC.WKC_ID = AJS.WKC_ID)";
         if ($tws_config['cpuinfo']['version']>='9.5')
            $query .= "
            LEFT JOIN $schema.FOL_FOLDERS       JS_FOLDER   ON JS_FOLDER.FOL_ID = AJS.FOL_ID";
         if ($tws_config['cpuinfo']['version']>='9.5002')
            $query .= "
            LEFT JOIN $schema.FOL_FOLDERS       WS_FOLDER   ON WS_FOLDER.FOL_ID = WKC.FOL_ID";

         $query .= "
            WHERE WKC.WKC_NAME ".tws_sqllike(db_string($composer_db, $cpux))." AND
               AJS.AJS_NAME ".tws_sqllike(db_string($composer_db, $schedulex)). " AND
               AJB.AJB_NAME   ".tws_sqllike(db_string($composer_db, $fieldvalue));
         if ($tws_config['cpuinfo']['version']>='9.5')
            $query .= "
            AND JS_FOLDER.FOL_PATH ".tws_sqllike(db_string($composer_db, $stream_folder));
         if ($tws_config['cpuinfo']['version']>='9.5002')
            $query .= "
            AND WS_FOLDER.FOL_PATH ".tws_sqllike(db_string($composer_db, $ws_folder));
         $query .= "
               ORDER BY WKC, AJS, AJB";

         if (!db_query($composer_db,$query) ) {
            tws_warning("Database query error");
            echo '<script> sendValue(null); </script>'."\n";
         }

         if (($row=db_fetch_row($composer_db))) {
            echo "<select name='selection' class='picker' size='14' onDblClick='sendValue(this.form.selection);'";
            if ($allowmultiple == "yes") echo " multiple";
            echo ">\n";
            do {
               $jobname_display=$row['AJB'];
               $valid_str='';
               if ($validfrom=="yes") {
                  if ($row['VALID_FROM']) {
                     $valid_str="&nbsp;(valid&nbsp;from&nbsp;".tws_date_from_iso($row['VALID_FROM']);
                  }
                  if ($row['VALID_TO']) {
                     if ($row['VALID_FROM']) {
                        $valid_str.="&nbsp;to&nbsp;".tws_date_from_iso($row['VALID_TO']).")";
                     } else $valid_str="&nbsp;(valid&nbsp;to&nbsp;".tws_date_from_iso($row['VALID_TO']).")";
                  } else if ($row['VALID_FROM']) {
                     $valid_str.=")";
                  }
               }
               echo "<option value=\"".$row['WKC']."#".$row['AJS'].".".$row['AJB']."\">".(!empty($show_full_name) ? $row['WKC'].'#'.$row['AJS'].'.' : '').$row['AJB'].$valid_str."</option>\n";
            } while ($row = db_fetch_row($composer_db));
         } else $error=TRUE;
      }

      if ($error) {
            echo "<center>\n";
            if( $cpux && $schedulex ) echo "<p class=warning>No jobs found for ". htmlspecialchars("$cpux#$schedulex") ."</p>\n";
            else echo "<p class=warning>Error: Empty or non-supported content of <em>Workstation</em> or <em>Jobstream</em> field.</p>\n";
            echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\">\n";
      } else {
         echo "</select>\n";
         echo "<br><br>\n";
         echo "<center>\n";
         echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(this.form.selection);\">\n";
      }
      echo "</center>\n";
   }
}?>
</form>
</div>

<script type="text/javascript">

$(function() {
   tws_picker_constructor("job_instance_picker");
});

</script>
