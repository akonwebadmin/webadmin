<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");

   // Cancel button test
   $tmp_test = (isset($_POST['action']) && $_POST['action'] == 'Return to Modification') ? true : false;
   if ($tmp_test == true) {
      foreach ($_POST as $key => $val){
         $$key = tws_gpc_get($val);
      }
   }
   if ($modify == "yes") $h1 = "Modify Local Parameter";
   elseif ($copy == "yes") $h1 = "Copy Local Parameter";
   else $h1 = "Add Local Parameter";

?>
<html>
<head>
<title><?=$h1 ?></title>
<?php tws_stylesheet(); ?>
<script type="text/javascript">
function ConfirmCancel(objectname,url){
   $('form').unbind('submit');
   var conftext=confirm("Exit " + objectname + " Definition (Changes will be lost) ?");
   if (conftext) {
         closeme(url);
   } else {
      return false;
   }
}
</script>
</head>
<body>
<?php tws_set_window_title(); ?>

<?php
   if ($tmp_test == false && ($modify == "yes" || $copy == "yes")) {

      $num_elements=count($selection);
      if ($num_elements == 0) {
         tws_dyer("No local parameter selected");
      } elseif ($num_elements > 1) {
         tws_dyer("Multiple local parameters selected. Only one local parameter can be ".($copy=="yes" ? 'copied' : 'modified')." at a time.");
      }

      $pos=strpos($selection[0],":");
      $length=substr($selection[0],0,$pos);
      $parm_name = substr($selection[0],$pos+1,$length);
      $parm_value = substr(urldecode($selection[0]),$pos+$length+2);

      if (isset($status) && $status == "error") {
         tws_dyer("Unable to retrieve local parameter definition");
      }
   }

   tws_print_head($h1);

?>

<br><br>
<form method=post name="contents" action="tws_add_local_parm_exec.php" onsubmit="if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Local Parameter',null)) { cancel_button_pressed=false; return false;}">
<table border=0 cellspacing=0>
<tr>
<td class=standard width=150>
&nbsp;&nbsp;<b>Parameter Name:</b>
</td>
<td class=standard>
   <? $maxlen=16; if($tws_config['cpuinfo']['version']<='8.4') $maxlen=8;?>
<input type="text" name="parm_name" class="tws_name" required="required" size="<?=$maxlen?>" maxlength="<?=$maxlen?>" <?php if (isset($parm_name)) echo " value=\"".htmlspecialchars($parm_name)."\""; ?>
   <?php if ($modify == "yes") echo " disabled"; ?>>
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class=standard width=150>
&nbsp;&nbsp;<b>Parameter Value:</b>
</td>
<td class=standard>
<input type="text" name="parm_value" required="required" size=40 maxlength=72 <?php if (isset($parm_value)) echo " value=\"".htmlspecialchars($parm_value)."\""; ?>>
</td>
</tr>
</table>
<br><br>
<?
   if ($modify == "yes" || $copy == "yes") {
      if ($modify == "yes") echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
      if ($copy == "yes") echo "<input type=\"hidden\" name=\"copy\" value=\"yes\">\n";
      echo "<input type=\"hidden\" name=\"parm_namex\" value=\"$parm_name\">\n";
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Update\" onClick=\"return tws_validate_form()\"/>\n";
   } else {
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Add\" onClick=\"return tws_validate_form()\"/>\n";
   }
   tws_print_synchro_token();  // synchro token
?>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" value="Cancel" onClick="ConfirmCancel('Local Parameter','tws_local_parmsx.php')">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" value="Print" onClick="window.print()">
</form>
</body>
</html>
