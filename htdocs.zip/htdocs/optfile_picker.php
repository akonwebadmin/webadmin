<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";

   tws_import_request_variables("P","rqst_");

   $fieldname=$rqst_fieldname;
   $method=$rqst_method;
   tws_check_elname($fieldname);
   $display="yes";

   if (!isset($fieldname)) {
      $fieldname="optfile";
   }
   if ((strpos($fieldname,"[") !== FALSE) && (strpos($fieldname,"]") !== FALSE)) {
      $jsfieldname="elements['" . $fieldname . "']";
   }
   else {
      $jsfieldname = $fieldname;
   }
?>
<script type="text/javascript">

function sendValue(formsel) {
 var selectionval = "";
 if(formsel) {
   for (var i = 0; i < formsel.options.length; i++)
      if (formsel.options[i].selected)
         selectionval = selectionval + formsel.options[i].value + ",";
   window.document.contents.<?php echo $jsfieldname ?>.value = selectionval.substr(0, selectionval.length - 1);
 }
 $('[name="<?=$fieldname?>"]').keyup();
 $("#optfile_picker").dialog( "close" );
}
</script>

<div id="optfile_picker">
   
<h1>Select Option File</h1>
<br>

<form name="optfile_list">

<?php
   $optfile_num=0;

   $optfile_dir="$maestro_dir/methods";

   if (!is_dir($optfile_dir)) {
      echo "<center><p class=warning>No methods available</p>\n";
      echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\"></center>\n";
   }
   elseif(trim($method) == '') {
      echo "<center><p class=warning>No method selected</p>\n";
      echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\"></center>\n";
   }
   else {
      $dp=opendir($optfile_dir);
      while (($filename=readdir($dp))!==FALSE) {
         if ( strtoupper(substr($filename,-5,5)) == ".OPTS" && strtoupper(substr($filename,0,-5)) == strtoupper($method)) {
            $optfile_num++;
            $optfile[$optfile_num]=substr($filename,0,-5);
         }
      }
      closedir($dp);

      if ($optfile_num == 0) {
         echo "<center><p class=warning>No option files for ". htmlspecialchars($method) ." method are available</p>\n";
         echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\"></center>\n";
      }
      else {
         echo "<select name=\"selection\" class=\"picker\" size=14 onDblClick=\"sendValue(this.form.selection);\">\n";
         for ($i=1; $i<=$optfile_num; $i++) {
            echo "<option value=\"$optfile[$i]\">$optfile[$i]</option>\n";
         }
         echo "</select>\n";
         echo "<br><br>\n";
         echo "<center><input type=\"button\" value=\"OK\" onClick=\"sendValue(this.form.selection);\"></center>\n";
      }
   }
?>
</form>
</div>

<script type="text/javascript">
$(function() {
   tws_picker_constructor("optfile_picker");
});
</script>
