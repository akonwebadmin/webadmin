<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
   // Cancel button test
   $tmp_test = (isset($_POST['action']) && $_POST['action'] == 'Return to Modification') ? true : false;
   if ($tmp_test == true) {
      foreach ($_POST as $key => $val)
         $$key = tws_gpc_get($val);
   }
?>
<html>
<head>
<?php tws_stylesheet();
   if ($copy == "yes") $h1 = "Copy Folder";
   else $h1 = "Add Folder";
?>
<title><?=$h1 ?></title>
<script type="text/javascript">
function ConfirmCancel(objectname,url){
   $('form').unbind('submit');
   var conftext=confirm("Exit " + objectname + " Definition (Changes will be lost) ?");
   if (conftext) {
      if (url==null) return true;
         closeme(url);
   } else {
      return false;
   }
}
</script>
</head>
<body>
<?php tws_set_window_title();

tws_print_head($h1);

   if ($tmp_test == false && $copy == "yes") {

      $num_elements=count($selection);

      if ($num_elements == 0) {
         tws_dyer("No folder selected");
      }
      elseif ($num_elements > 1) {
         tws_dyer("Multiple folders selected. Only one folder can be ".($copy=="yes" ? 'copied' : 'modified')." at a time");
      }

      if (($db_folder=tws_get_folders($selection[0]))===FALSE){
         tws_dyer("Unable to list folders");
      }

      if ($db_folder['folder_num'] != 1) {
         tws_dyer("Database query failed");
      }

      // divide $folder_path and folder_name
      $selection[0] = substr($selection[0], 0, -1);    // remove last slash
      list($folder_path, $folder_name) = tws_explode_folder($selection[0]);
   }
?>

<br><br>
<form method=post name="contents" action="tws_add_folder_exec.php" onsubmit="if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Folder',null)) { cancel_button_pressed=false; return false;}">
<table border=0 cellspacing=0>
<tr>
<td class=standard width=120>
&nbsp;&nbsp;<b>Folder Name:</b>
</td>
<td class=standard >
<input type="text" name="folder_name" class="tws_name" size="60" required="required" <? if (isset($folder_name)) echo " value='$folder_name'"; ?>
   <? if ($modify == "yes"){
         echo " disabled />";
         echo "<input type='hidden' name='folder_name' value='$folder_name'>";
      }
   ?>
</td>
</tr>
<?
   if ($copy == "yes") {
      echo "<script type='text/javascript'>\n";
      echo "<!--\n";
      echo "document.contents.folder_name.focus();\n";
      echo "document.contents.folder_name.select();\n";
      echo "// -->\n";
      echo "</script>\n";
   }
?>
<tr>
<td class=standard width=120>
&nbsp;&nbsp;<b>In Folder:</b>
</td>
<td class=standard>
<input type="text" name="folder_path" size=60 required="required" value="<?=(!empty($folder_path) ? $folder_path : '/')?>">
<input type="button" name="folder_list" onClick="tws_picker_open('folder_picker.php', 'fieldname=folder_path&fieldvalue=' + document.contents.folder_path.value);" value="List" >
</td>
</tr>
</table>
<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' name='action' value='Add' onClick='return tws_validate_form()'>
&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' value='Cancel' onClick="ConfirmCancel('Folder','tws_foldersx.php')">
&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" value="Print" onClick="window.print()">
<? tws_print_synchro_token(); ?>
</form>
</body>
</html>
