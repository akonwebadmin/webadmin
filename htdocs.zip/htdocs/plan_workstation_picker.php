<?php
//   HORIZONT Software GmbH, Munich
//
   require_once "tws_functions.php";

   if (defined('IWD_PROCMAN')) {
      $iwd_class='iwd_cpws';
      $search_elems=array();
      $search=$iwd_class::get_search_elems($search_elems, 'ref');
   }

   tws_import_request_variables("P","rqst_");

   $fieldname=$rqst_fieldname;
   tws_check_elname($fieldname);
   $fieldvalue=$rqst_fieldvalue;
   $allowmultiple=@$rqst_allowmultiple;
   $display="yes";

   if (!isset($fieldname)) {
      $fieldname="workstation";
   }

   if ((strpos($fieldname,"[") !== FALSE) && (strpos($fieldname,"]") !== FALSE)) {
      $jsfieldname="elements['" . $fieldname . "']";
   }
   else $jsfieldname = $fieldname;

?>
<script type="text/javascript">
function updateValue(val) {
   window.document.contents.<?=$jsfieldname ?>.value = val;
   $('[name="<?=$fieldname?>"]').keyup();
}

function sendValue(formsel) {
   var selectionval = "";
   if (formsel) {
      for (var i = 0; i < formsel.options.length; i++)
         if (formsel.options[i].selected) selectionval = selectionval + formsel.options[i].value + ",";
      updateValue(selectionval.substr(0, selectionval.length - 1));
   }
   $("#plan_workstation_picker").dialog("close");
}

<?php
   if (defined('IWD_PROCMAN')) {
      if (trim($fieldvalue)=='') {
         $fieldvalue=$search_elems[$iwd_class][0];
         echo "updateValue('".$fieldvalue."');\n";
      }
   }
?>
</script>

<div id="plan_workstation_picker">

<h1>Select Workstation</h1>
<br>

<form name="workstation_list">

<select name="selection" id='ws_select' class="picker" size=14 onDblClick="sendValue(this.form.selection);"<?php if ($allowmultiple == "yes") echo " multiple"; ?>>

<?php
   $cpu_num=0;

   if ($fieldvalue == "") {
      $arg="@!@";
      if($tws_config['cpuinfo']['version']>='9.5002')
         $arg="@!/@/@";
   }
   else {
      if ((strpos($fieldvalue,"*") === FALSE) && (strpos($fieldvalue,"@") === FALSE)) {
         $arg="@!" . $fieldvalue . "@";
      } elseif (strpos($fieldvalue,"*") !== FALSE) {
         $arg="@!" . strtr($fieldvalue,"*","@");
      } else {
         $arg="@!" . $fieldvalue;
      }
   }

   if (defined('IWD_PROCMAN')) { //IWD/ProcMan
      $arg=strtr($arg,"@","*");
      if (($objs=$iwd_class::get_listing($arg, 'ref'))!==FALSE) {
         foreach($objs as $obj) {
            echo '<option value="'.$obj['rname'].'" '.(($obj['rname']==$fieldvalue) ? 'selected' : '').'>'.$obj['rname'].'</option>'."\n";
         }
      } else hwi_log_flush();
   }
   else { //IWS/WebAdmin
      $command=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/conman", $tws_config['conman_args'], "-gui", "sc $arg", hwi_cmd::operator('2>&1',FALSE));
      $stdout=array();
      if (tws_popen($command, $ec, $stdout, $stdout)===FALSE){
         tws_warning("Unable to list plan workstations", $stdout);
      }
      else {

         $result = tws_get_plan_workstation_list($arg, 0, 0, 1);

         tws_log("result = ".var_export($result, true));
         var_export($result);

         $cpu_num = $result['cpu_num'];
         for ($i=1; $i<=$cpu_num; $i++){
/*
               if ($tws_config['cpuinfo']['version']>='9.5002')
                  $res['fullname'] = $res['ws_folder'].$res['cpu']; // wks full name with folder
               else
                  $res['fullname'] = $res['cpu'];
*/
            echo "<option value='".$result['ws_folder'][$i].$result['cpu'][$i]."'>".$result['ws_folder'][$i].$result['cpu'][$i]."</option>\n";
         }
/*
         include("colpos_sc.php");

         $ws_folder = '';
         if($tws_config['cpuinfo']['version']>='9.5002')
            $ws_folder = '/';

         foreach($stdout as $buffer){
            tws_log($buffer);
            if (substr($buffer,0,2) != "^d")
               continue;

            if(substr($buffer,2,2) == '>>'){  // IWS 9.5.2 // WS Folder begin
               $ws_folder =  trim(substr($buffer, 4));
               continue;
            }

            $trim = trim(substr($buffer,2));
            if($trim=='/')
               continue;

               $cpu_num++;
               $cpu[$cpu_num]=htmlspecialchars(trim(substr($buffer,$col[1],$len[1])));

         }

         for ($i=1; $i<=$cpu_num; $i++) {
            echo "<option value=\"$ws_folder$cpu[$i]\">$ws_folder$cpu[$i]</option>\n";
         }
*/
      }
   }
?>
</select><br>
<center><input type="button" value="OK" onClick="sendValue(this.form.selection);"></center>
<br>
</form>
</div>

<script type="text/javascript">

$(function() {
   tws_picker_constructor("plan_workstation_picker");

   // sort workstation list
   var lb = document.getElementById('ws_select');
   arr = new Array();

   for(i=0; i<lb.length; i++)
     arr[i] = lb.options[i].text;

   arr.sort();

   for(i=0; i<lb.length; i++)  {
     lb.options[i].text = arr[i];
     lb.options[i].value = arr[i];
   }

});

</script>
