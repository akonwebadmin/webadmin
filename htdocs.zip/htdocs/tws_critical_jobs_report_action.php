<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_import_request_variables("P","rqst_");

   $run=$rqst_run;
   $schedule_date=tws_gpc_get($rqst_schedule_date, 'tws_datetime');
   if ($run == "current") {
      $schedule_date=tws_gpc_get($rqst_current_schedule_date, 'tws_datetime');
   } elseif ($run == "yesterday") {
      $schedule_date=tws_gpc_get($rqst_yesterday_schedule_date, 'tws_datetime');
   }
   var_dump(__LINE__);
   $critical_job_list=tws_gpc_get($rqst_critical_job_list, 'tws_num');

   var_dump(__LINE__);
   $show_all=$rqst_show_all;
   $late_only=$rqst_late_only;
   $last_only=$rqst_last_only;
   $action=$rqst_action;
   $skin=$rqst_skin;

   switch ($action) {
     case "Generate Report":
       if ($send == "yes") {
          include("tws_send_critical_jobs_report.php");
       } else {
          include("tws_view_critical_jobs_report.php");
       }
       break;
   }
?>