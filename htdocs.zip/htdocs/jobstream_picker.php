<?php
//   HORIZONT Software GmbH, Munich
//
    $__tlogmode='APPEND';
   require_once "tws_functions.php";

   if (defined('IWD_PROCMAN')) {
      $iwd_class='iwd_dbjs';
      $search_elems=array();
      $search=iwd_dbjs::get_search_elems($search_elems, 'ref');
   }

   tws_import_request_variables("P","rqst_");

   $cpux=strtoupper($rqst_cpux);

   if ($tws_config['cpuinfo']['version']>='9.5002') {
	  $tmp = tws_divide_folder($cpux);
	  $cpux_name = $tmp[1];
      $cpux_folder = $tmp[0];
   }

   $fieldname=$rqst_fieldname;
   @$fieldvalue=$rqst_fieldvalue;
   $fieldid=@$rqst_fieldid;
   if(!isset($fieldid))
      tws_check_elname($fieldname);
   $allowmultiple=@$rqst_allowmultiple;
   $thiscpu=@$rqst_thiscpu; //TODO?
   $thissched=@$rqst_thissched; //TODO?
   $validfrom=@$rqst_validfrom;
   $formname=isset($rqst_formname) ? trim($rqst_formname) : 'contents';
   tws_check_elname($formname);
   $display="yes";
   $action = @strtoupper(tws_gpc_get($rqst_action));
   if($action != 'SUBMIT')
      $action = 'LIST';

   if ((strpos($fieldname,"[") !== FALSE) && (strpos($fieldname,"]") !== FALSE)) {
      $jsfieldname="elements['" . $fieldname . "']";
   }
   else {
      $jsfieldname = $fieldname;
   }
?>
<script type="text/javascript">

function updateValue(val, txt) {
   <?php
      if (isset($fieldid)) {
         echo '$(window.document).find(\'input[id="'.addcslashes($fieldid,'\'').'"]\').last().attr(\'value\', val);',"\n";
         echo '$(window.document).find(\'input[id="'.addcslashes($fieldid,'\'').'"]\').last().attr(\'title\', txt);',"\n";
      } else {
         echo 'window.document.'.$formname.'.'.$jsfieldname.'.value = val;',"\n";
         echo 'window.document.'.$formname.'.'.$jsfieldname.'.title = txt;',"\n";
      }
   ?>
   $('[name="<?=$fieldname?>"]').keyup();
}

function sendValue(formsel) {
   if (formsel){
      var selectionval = "";
      var selectiontxt = "";
      for (var i = 0; i < formsel.options.length; i++)
         if (formsel.options[i].selected) {
            selectionval = selectionval + formsel.options[i].value + ",";
            selectiontxt = selectiontxt + formsel.options[i].text + ",";
         }
      updateValue(selectionval.substr(0, selectionval.length - 1), selectiontxt.substr(0, selectiontxt.length - 1));
   }
   $("#jobstream_picker").dialog( "close" );
}

   <?php
      if (defined('IWD_PROCMAN')) {
         if (trim($fieldvalue)=='') {
            $fieldvalue=$search_elems[$iwd_class][0];
            echo "updateValue('".$fieldvalue."','');\n";
         }
      }
    ?>
</script>

<div id="jobstream_picker">

<h1>Select Jobstream</h1>
<br>


<form name="jobstream_list">

<?
if ($cpux == "") {
   echo "<center><p class=warning>No workstation name selected</p>\n";
   echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\"></center>\n";
}
else {
   if ($fieldvalue=='') {
      $arg='@';
   }
   else {
      if ((strpos($fieldvalue,'*')===FALSE) && (strpos($fieldvalue,'@')===FALSE)) {
         $arg=$fieldvalue.'@';
      } elseif (strpos($fieldvalue,'*')!==FALSE) {
         $arg=strtr($fieldvalue,'*','@');
      } else {
         $arg=$fieldvalue;
      }
   }

   echo "<select id=\"sel\" name=\"selection\" class=\"picker\" size=14 onDblClick=\"sendValue(this.form.selection);\"";
   if ($allowmultiple == "yes") {
      echo " multiple";
   }
   echo ">\n";

   $select_options = '';
   if (defined('IWD_PROCMAN')) { //IWD/ProcMan
      $arg=strtr($arg,"@","*");
      $cpux=strtr($cpux,"@","*");
      if (($objs=iwd_dbjs::get_listing($cpux.'#'.$arg, 'ref'))!==FALSE) {
         $result['jobstream_num']=count($objs);
         foreach($objs as $obj) {
            $select_options .= '<option value="'.$obj['rname'].'" '.(($obj['rname']==$fieldvalue) ? 'selected' : '').'>'.$obj['name'].' ('.$obj['version'].')</option>'."\n";
         }
         echo $select_options;
      } else {
         echo '</select>';
         hwi_log_flush();
         $result=FALSE;
      }
   }
   else { //IWS/WebAdmin
		$xfilter = "+$cpux#$arg";
		$xfilter = tws_dbfilter_where ($xfilter, 'WKC_NAME', 'AJS_NAME');
		$xfilter .= "
         AND ".tws_where_valid_in(date('Y-m-d'));
		$xfilter .= "
         AND WS_FOL.FOL_PATH ".tws_sqllike(db_string($composer_db,$cpux_folder));
      $result=tws_get_jobstreams('@', '@', '', $xfilter, 0, 1, 'jobstream_picker_callback'); // ,$action
   }
   echo '</select>',"\n";
   if ($result===FALSE || $result['jobstream_num']==0) {
      echo '<center>';
      echo '<script type="text/javascript">',"\n",'  deleteElem(\'sel\');',"\n",'</script>',"\n";
      if ($result===FALSE)
         echo '<p class="warning">Unable to get jobstream definitions list</p>',"\n";
      else echo '<p class="warning">No qualified jobstream definition entries matching ',htmlspecialchars($cpux.'#'.$arg),'.</p>',"\n";
      echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\"></center>\n";
   } else {
      echo "<br><br>\n";
      echo "<center><input type=\"button\" value=\"OK\" onClick=\"sendValue(this.form.selection);\"></center>\n";
   }
}

function jobstream_picker_callback(&$js) {
   global $validfrom, $cpux;
   $valid_str='';
   if ($validfrom=='yes') {
      if ($js['jobstream_valid_from']) {
         $valid_str='&nbsp;(valid&nbsp;from&nbsp;'.tws_date_from_iso($js['jobstream_valid_from']);
      }
      if ($js['jobstream_valid_to']) {
         if ($js['jobstream_valid_from']) {
            $valid_str.='&nbsp;to&nbsp;'.tws_date_from_iso($js['jobstream_valid_to']).')';
         } else $valid_str='&nbsp;(valid&nbsp;to&nbsp;'.tws_date_from_iso($js['jobstream_valid_to']).')';
      } else if ($js['jobstream_valid_from']) {
         $valid_str.=')';
      }
   }
   $value = '';
   if(!empty($js['jobstream_folder']))
      $value = $js['jobstream_folder'];
   $value .= $js['jobstream_name'];
   echo '<option value="'.$value.'">'.$value.$valid_str.'</option>',"\n";
}
?>
</form>
</div>

<script type="text/javascript">

$(function() {
   tws_picker_constructor("jobstream_picker");
});

</script>
