<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add Workstation Class</title>
<?php
tws_stylesheet();
tws_show_backup();
?>
</head>
<body>
<?php tws_set_window_title(); ?>

<?php
   tws_import_request_variables("P","rqst_");
   tws_check_synchro_token();  // synchro token

   $modify=@$rqst_modify;
   $confirm=@$rqst_confirm;
   $backup=@$rqst_backup;
   $original_data=tws_gpc_get($rqst_original_data);

   if ($modify == "yes") {
      if (!tws_permit_action('database_workstation_classes','Modify'))
         tws_access_denied ();
   }
   else {
      if (!tws_permit_action('database_workstation_classes','Add'))
         tws_access_denied ();
   }

   $workstation_class = strtoupper(tws_gpc_get($rqst_workstation_class_name, 'tws_name'));
   if ($tws_config['cpuinfo']['version']>='9.5002')
      list($workstation_class_folder, $workstation_class_name) = tws_divide_folder($workstation_class);

   $description=tws_gpc_get($rqst_description);
   $setmembers=tws_gpc_get($rqst_setmembers);
   $members=explode(":",$setmembers);
   tws_check_arg($members, 'tws_name');
   $action=$rqst_action;

   if ($action=="Cancel") {
      // Unlock the object
      tws_composer_unlock("wscl=$workstation_class") or tws_dyer("Unable to unlock workstation class '$workstation_class'");
      echo "<script type='text/javascript'>\n";
         echo "closeme('tws_workstation_classesx.php');\n";
      echo "</script>\n";
      exit;
   }
   elseif($action=="Return to Modification"){
      include("tws_add_workstation_class.php");
      exit;
   }

   if (isset($rqst_ignore) ) {
      $ignore=$rqst_ignore;
   } else {
      $ignore="";
   }

// Check for existing workstation class
   $match=FALSE;
   if ($confirm != "yes") {
      if (($db_class = tws_get_workstation_classes($workstation_class)) === FALSE )
         tws_dyer("Unable to list workstation classes");
      if ($db_class['workstation_class_num'] > 1 )
         tws_dyer("Database query failed");

      if ( $db_class['workstation_class_folder'][0] == $workstation_class_folder && $db_class['workstation_class_name'][0] == $workstation_class_name ) {
         $orig_description = $db_class['workstation_class_description'][0];
         $orig_ignore = $db_class['workstation_class_ignore'][0];
         $match = TRUE;
      }
   }

   if ($match == TRUE) {
      if (($db_members = tws_get_class_members($workstation_class)) === FALSE ) {
         tws_dyer("Unable to list workstation class members");
      }
      $orig_members=Array();
      if (@is_array($db_members['workstation_name'])) {
         foreach ($db_members['workstation_name'] as $memb) {
            $orig_members[]=$memb;
         }
      }

      if ($modify == "yes") {
         echo "<h1>Confirmation</h1>\n";
      } else {
         echo "<h1>Replace Workstation Class Confirmation</h1>\n";
      }
      echo "<br><br>\n";
      echo "<h3>Confirm:</h3>\n";
      if ($modify != "yes") {
         echo "&nbsp;&nbsp;<b>The Workstation Class Name entered already exists</b>\n";
         echo "<br><br>\n";
      }


      $orig_class = Array ('class_name' => $workstation_class, 'description' => $orig_description, 'ignore' => tws_yesno($orig_ignore), 'members' => "");
      $new_class  = Array ('class_name' => $workstation_class, 'description' => $description, 'ignore' => tws_yesno($ignore), 'members' => "");
      $label_map  = Array ('class_name' => 'Workstation class', 'description' => 'Description', 'ignore' => "Ignore", 'members' => 'Members' );

      $count=0;
      foreach ($orig_members as $memb) {
         $orig_class["member$count"] = $memb;
         if (in_array($memb,$members)) {
            $new_class["member$count"] = $memb;
         } else {
            $new_class["member$count"] = "";
         }
         $count++;
      }
      foreach ($members as $memb) {
         if (!in_array($memb,$orig_members)) {
            $orig_class["member$count"] = "";
            $new_class["member$count"] = $memb;
            $count++;
         }
      }
      for ($i=0;$i<=$count;$i++) {
         $label_map["member$i"] = "&nbsp;&nbsp;&nbsp;#".($i+1);
      }

      tws_show_cmp_table("Original Workstation Class", "New Workstation Class", $orig_class, $new_class, $label_map);

// confirmation form
      echo "<form method=post name=\"confirm\" action=\"tws_add_workstation_class_exec.php\">\n";
      echo "<input type=\"hidden\" name=\"confirm\" value=\"yes\">\n";
      echo "<input type=\"hidden\" name=\"workstation_class_name\" value=\"".htmlspecialchars($workstation_class)."\">\n";
      if ($original_data=='') {
         //missing original data - this happens if user is adding job that already exists.
         if (($original_data=tws_composer_create_from("wscl=$workstation_class"))===FALSE) {
            tws_err("Unable to get original data required to create backup.");
         }
      }
      echo tws_create_hidden_inputs($_POST);
      echo "<input type=\"hidden\" name=\"original_data\" value=\"".htmlspecialchars($original_data)."\">\n";
      $url_members="";
      foreach ($members as $memb) {
         $url_members .= $memb.":";
      }
      $url_members = substr($url_members,0,-1);
      echo "<input type=\"hidden\" name=\"setmembers\" value=\"$url_members\">\n";

      if (tws_rights(SAVEBACKUPS) && $original_data!=''){
         echo "<input type='hidden' name='backup' value='yes'>";
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type='checkbox' name='backup' value='yes' checked disabled>&nbsp;Save Backup Copy of Original Workstation Class</label>\n";
      }
      else
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type=\"checkbox\" name=\"backup\" value=\"yes\" ".($original_data!='' ? 'checked' : 'disabled').">&nbsp;Save Backup Copy of Original Workstation Class</label>\n";
      echo "<br><br><br>\n";
      if ($modify == "yes") {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Update\" name=\"action\">\n";
         echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
         echo "<input type=\"hidden\" name=\"workstation_class_namex\" value=\"".htmlspecialchars($workstation_class)."\">\n";
      } else {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Replace\" name=\"action\">\n";
      }
      echo '&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Return to Modification">'."\n";
      echo '&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Cancel">'."\n";
      tws_print_synchro_token();   // synchro_token
      echo "</form>\n";

   } else {
// Create Backup Copy if option checked
      if ($backup == "yes") {
         if (($bckfilename = tws_write_backup($original_data, "workstationclass", $workstation_class)) === FALSE) {
            tws_dyer("Unable to write backup");
         }
      }

      // unlock the object
      tws_composer_unlock("wscl=$workstation_class");

      $tmpfilename="$maestro_dir/webadmin/tmp/workstationclass.".tws_rndstr().".tmp";
      $fp3=fopen($tmpfilename,'w') or tws_dyer("Unable to create temporary file");

      if (tws_yesno($ignore)=="YES") $ignore_def = "IGNORE";
         else $ignore_def = "";
      $cmd=Array();
      $cmd[]="CPUCLASS $workstation_class\n";
      $cmd[]="  DESCRIPTION \"".addcslashes($description,'"')."\"\n";
      $cmd[]="  $ignore_def\n";
      $cmd[]="  MEMBERS\n";
      foreach ($members as $member) {
         $cmd[]="    $member\n";
      }
      $cmd[]="END\n";
      foreach ($cmd as $cmdline) {
         $num_bytes=fwrite($fp3,$cmdline);
         if ($num_bytes < 0) {
            fclose($fp3);
            tws_dyer("Unable to write temporary file");
         }
      }
      fclose($fp3);
      tws_chmod($tmpfilename,0644);

      if ($confirm == "yes") {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "replace $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      } else {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "add $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      }

      $stdout3='';
      $ec_popen=tws_popen($command3, $ec3, $stdout3, $stdout3, "N");

      //remove the tmp file now
      unlink($tmpfilename);

      //testing for the AWSBIA288I Total objects updated: 0.
      //Note: This has been added on 2016-07 to fix the problem of composer updating
      //correctly objects but returning incorrect return codes (not 0 or 4)
      $not_updated=!preg_match('/AWSBIA288[^\n]+(\d+)/', $stdout3, $_r) || $_r[1]==0;

      if ($ec_popen===FALSE || ($ec3!=0 && $ec3!=4 && $not_updated)) {
         if ($modify == "yes") {
            echo "<h1>Modify Workstation Class Status</h1>\n";
         } else {
            echo "<h1>Add Workstation Class Status</h1>\n";
         }
         tws_err("Workstation class add/modify operation failed", array('twscmd'=>$command3->compile('log'), 'stdout'=>$stdout3, "EC_POPEN"=>$ec_popen, "EC_UPDATED"=>$ec3, "NOT_UPDATED"=>tws_yesno($not_updated,'YES','NO')));

         echo "<form action='tws_add_workstation_class_exec.php' method='post' onsubmit=\"if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Workstation',null)) { cancel_button_pressed=false; return false;}\">\n";
         echo tws_create_hidden_inputs($_POST);
         tws_print_synchro_token();
         echo "<input type='hidden' name='workstation_class_name' value='$workstation_class'>\n";
         echo "<input type='submit' name='action' value='Cancel' onClick='cancel_button_pressed=true;'/>\n";
         echo "<input type='submit' name='action' value='Return to Modification'/>\n";
         echo "</form>";

      } elseif (preg_match("/warnings?\s[1-9]/i",$stdout3)) {
         if ($modify == "yes") {
            $headertext="Modify Workstation Class";
         } else {
            $headertext="Add Workstation Class";
         }
         tws_err("The Workstation Class has been saved with the following warnings:", array('stdout'=>$stdout3));

         $shortwarnfilename="warn.".tws_rndstr().".txt";
         $warnfilename="$webadmin_tmp_dir/$shortwarnfilename";
         $warnfp=fopen("$warnfilename","w") or tws_dyer("Unable to create warning text file", "Warning output :\n$stdout3");
         $num_bytes=fwrite($warnfp,"$stdout3");
         if ($num_bytes < 0) {
            fclose($warnfp);
            unlink($warnfilename);
            tws_dyer("Unable to write warning text file", "Warning output :\n$stdout3");
         }
         fclose($warnfp);
         tws_dyer();
      } else {
         if ($backup == "yes") {
            if ($modify == "yes") {
               echo "<h1>Modify Workstation Class Status</h1>\n";
            } else {
               echo "<h1>Add Workstation Class Status</h1>\n";
            }
            echo "<p class=\"message\">\n";
            echo "The workstation class has been successfuly saved.&nbsp;";
            $bckfilename = preg_replace("/\\\\/", '/', $bckfilename);
            $file = explode('/',$bckfilename);
            $file = end($file);
            if(tws_profile('auth_user_group')=='admin')
               echo "<a href=\"javascript:showBackup('$file')\">Display Backup File</a>\n";
            echo "</p>\n";
            echo "<input type='button' value='OK' onClick=\"closeme('tws_workstation_classesx.php')\">\n";
         } else {
            echo "<script type='text/javascript'>\n";
               echo "closeme('tws_workstation_classesx.php');\n";
            echo "</script>\n";
         }
      }
   }
?>
</body>
</html>
