<?php
$__tlog=FALSE;

if (isset($_GET['action'])) {
   $action =  $_GET['action'];
} elseif (isset($_POST['action'])) {
   $action =  $_POST['action'];
} else {
   $action = '';
}
//if (isset($_HEADERS['__hwi_syntok']) && !isset($_POST['__hwi_syntok'])) $_POST['__hwi_syntok']=$_HEADERS['__hwi_syntok'];

//HWI6: Running ALL these small AJAX requests in R/W session for higher stability
//$hwi_session_readonly=($action!=='wai_session' || !isset($_POST['value']));
require_once 'tws_functions.php';

switch ($action) {
   case 'session_activity':
      $activity='1';
      if (isset($_GET['pid'])) {
         //special case : update the page having pid=$_GET['pid']
         session_activity::update($_GET['pid']);
      }
        if (!session_activity::is_active() ) {
         include $tws_config['base_inst_dir'].'/httpd/htdocs/tws_logout.php';
         $activity='0';
      }
      echo $activity;
      echo "\n".session_activity::debug();
      break;
}
?>
