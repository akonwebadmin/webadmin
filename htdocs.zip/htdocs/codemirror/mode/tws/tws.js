﻿CodeMirror.defineMode("tws", function(config, parserConfig) {
  var klic_slova = /^(AS|AT|CARRYFORWARD|COMMENT|CONFIRMED|CONTINUE|CRITICAL|DAY|DAYS|DOCOMMAND|DEADLINE|DESCRIPTION|DRAFT|END|EVERY|EXCEPT|FDIGNORE|FDNEXT|FDPREV|FOLLOWS|FREEDAYS|INTERACTIVE|KEYJOB|KEYSCHED|LIMIT|MATCHING|NEEDS|ON|OPENS|ONUNTIL|PREVIOUS|PRIORITY|PROMPT|RCCONDSUCC|RECOVERY|RELATIVE|RERUN|RUNCYCLE|SAMEDAY|SCHEDULE|SCHEDTIME|SCRIPTNAME|STOP|STREAMLOGON|TASKTYPE|TIMEZONE|TZ|UNTIL|VALIDFROM|VALIDTO|VARTABLE)$/; //klíčová slova tws
  var klic_slova_hodnota = /^(AT|DEADLINE|LIMIT|PRIORITY|TO|UNTIL|VALIDFROM|VALIDTO)$/; //klíčová slova po kterých následuje hodnota
  var klic_slova_identifikator = /^(AS|EVERY|RUNCYCLE|TIMEZONE|TZ|VARTABLE)$/; //klíčová slova po kterých následuje identifikátor
  var znak_identifikator = /^(@|\/)$/;  //identifikátor
  var ch = "";  //načítaný znak z proudu
  var klicove_slovo = "empty";  //proměnná k uložení předchozího klíčového slova
  var komentar = false;  //proměnná k identifikaci komentáře (hodnot atributu, textu v uvozovkách)
  var identifikator = false;  //identifikátor (příznak)
  var kvalifikator = false;  //kvalifikátor (příznak)
  
  /************************* funkce zpracuj_retezec ***********************************/
  /* Funkce slouží ke zpracování řetězce (posloupnoust znaků zakončené mezerou, nebo  */
  /* novým řádkem                                                                     */
  /* Vstup - stream                                                                   */
  /* Výstup - nic nevrací                                                             */
  /************************************************************************************/
  function zpracuj_retezec(stream)
  {
    if(!stream.skipTo(" "))//pokud slovo je na konci a není za ním mezera
      stream.skipToEnd();    
  }
  
  return{
    token: function(stream,state) {

      if (stream.eatSpace())
      { //když je mezera
        if(stream.peek()=="#")
        {  //pokud další je #, tak se jedná o komentář
          stream.skipToEnd();
          return "tws_comment";
        } //pokud další je #, tak se jedná o komentář
        return null;
      }  //když je mezera      
      
      if (stream.sol()) 
      {  //pokud se jedná o začátek řádku 
        klicove_slovo="empty";
        ch = stream.next();
        if(ch=="#")
        { //pokud na začátku je #, potom se jedná o komentář
          stream.skipToEnd();
          return "tws_comment";
        } //pokud na začátku je #, potom se jedná o komentář
      }  //pokud se jedná o začátek řádku
      else
      {  //pokud se nejedná o začátek řádku
        ch = stream.next();
      } //pokud se nejedná o začátek řádku
      
      if(identifikator)
      { //pokud se jedna o identifikator
        if(ch=="#")
        {  //pokud znak je #
          return null;
        }  //pokud znak je #
        if(!stream.skipTo(".")) //pokud indetifikátor nekončí tečkou
          stream.skipTo(" ");
        identifikator=false;
        return   "tws_identifier";
      } //pokud se jedna o identifikator
      
      if(znak_identifikator.test(ch))
      {  //identifikátor - význam wildcat
        return "tws_identifier";
      } //identifikátor - význam wildcat
      
      if(ch=="\"")
      { //pokud znak je "
        komentar=!komentar;
        return null;
      } //pokud znak je "    
      
      if(ch=="(" && klicove_slovo=="OPENS")
      {  //pokud se jedna o závorku s kvalifikátory, která patří ke klíčovému slovu OPENS
        kvalifikator=true;
        return null;
      }  //pokud se jedna o závorku s kvalifikátory, která patří ke klíčovému slovu OPENS
      
      if(kvalifikator)
      {  //pokud se jedná o kvalifikátor
        stream.skipTo(")");
        kvalifikator=false;
        return "tws_value";
      }  //pokud se jedná o kvalifikátor
      
      if(ch=="+" || ch=="-")
      { //pokud znak je + nebo -, pak se jedná o dny nebo čas (hodnota)
        zpracuj_retezec(stream);
        return "tws_value";
      } //pokud znak je + nebo -, pak se jedná o dny nebo čas (hodnota)        
      
      if(komentar)
      {  //pokud se jedná o komentar (text v uvozovkach)
        if(klicove_slovo=="DESCRIPTION" || klicove_slovo=="PROMPT")    
        {  //pokud klíčové slovo je DESCRIPTION nebo PROMPT, potom následuje řetězec
          stream.skipTo("\"");
          klicove_slovo="empty";
          return "tws_string";
        }  //pokud klíčové slovo je DESCRIPTION nebo PROMPT, potom následuje řetězec  
        stream.skipTo("\"");
        return "tws_value";
      } //pokud se jedná o komentar (text v uvozovkach)            
          
      
      if (/\w/.test(ch)) 
      {  //znak "slova" (ekvivalentní zápisu a-zA-Z0-9_)    
        stream.eatWhile(/\w/); //načíst celé "slovo"
        retezec=stream.current();
        if (klic_slova.test(retezec.toUpperCase())) 
        {  //pokud slovo se shoduje s klíčovými slovy
          klicove_slovo=retezec;  //uložení klíčového slova pro použití na následujícím spojení
          return "tws_keyword";
        }  //pokud slovo se shoduje s klíčovými slovy
        
        if(klicove_slovo!="empty")
        {  //pokud bylo předtím použito klíčové slovo
          
          if(klic_slova_hodnota.test(klicove_slovo.toUpperCase()))
          {  //pokud po klíčovém slovu následuje hodnota
            zpracuj_retezec(stream);      
            return "tws_value";
          }  //pokud klíčové slovo je AT nebo DEADLINE, potom následuje hodnota        
                    
        }  //pokud bylo předtím použito klíčové slovo
        if(stream.peek()=="#")
        { //pokud identifikátor pokračuje dále
          identifikator=true;
        } //pokud identifikátor pokračuje dále
        return "tws_identifier"; //libovolné slovo, které neprošlo kotrolou je identifikátor
      } //znak "slova" (ekvivalentní zápisu a-zA-Z0-9_)
      
      return null;
    } //token: ...
  }  //return
}); //defineMode

CodeMirror.defineMIME("text/tws", "tws");