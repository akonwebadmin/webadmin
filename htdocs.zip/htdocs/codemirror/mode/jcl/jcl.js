CodeMirror.defineMode("jcl", function() {    
    
    function get_token (stream, state) {    
        stream.eatWhile (' ');
        if (stream.eol ())
            return undefined;
        
        var x = stream.next ();
        switch (x) {            
        case '(':
            state.last_token = new Array ('lbr', '(');
            return state.last_token; 
            
        case ')':
            state.last_token = new Array ('rbr', ')');
            return state.last_token;
            
        case '=':
            state.last_token = new Array ('eq', '=');
            return state.last_token; 

        case '>':
            if (stream.peek () == '=') {
                stream.next ();    
                state.last_token = new Array ('ge', '>=');
                return state.last_token; 
            }
            else {
                state.last_token = new Array ('gt', '>');
                return state.last_token; 
            }

        case '<':
            if (stream.peek () == '=') {
                stream.next ();    
                state.last_token = new Array ('le', '<=');
                return state.last_token; 
            }
            else {
                state.last_token = new Array ('lt', '<');
                return state.last_token; 
            }
            
        case ',':
            state.last_token = new Array ('comma', ',');
            return state.last_token; 
            
        case '&':
            state.last_token = new Array ('amp', '&');
            return state.last_token; 
            
        case "'":
            var str    = "'";
            var closed = false;
            x          = stream.peek ();
            while (!stream.eol ()) {
                if (x == "'") {
                    str += x;
                    x    = stream.next ();
                    x    = stream.peek ();
                    if (x == "'") {
                        str += stream.next ();
                        x    = stream.peek ();
                    }
                    else {
                        closed = true;
                        break;
                    }
                }
                else {
                    str += stream.next ();
                    x    = stream.peek ();
                }
            }
            if (closed) {
                state.last_token = new Array ('string', ident);             
                return state.last_token; 
            }
            else {
                state.last_token = new Array ('ostring', ident);            
                return state.last_token; 
            }            
                                
        default:
            if (state.last_token != undefined && state.last_token [0] == 'ostring') {
                var str    = x;
                var closed = false;
                x          = stream.peek (); 
                while (!stream.eol ()) {
                    if (x == "'") {
                        str += x;
                        x    = stream.next ();
                        x    = stream.peek ();
                        if (x == "'") {
                            str += stream.next ();
                            x    = stream.peek ();
                        }
                        else {
                            closed = true;
                            break;
                        }
                    }
                    else {
                        str += stream.next ();
                        x    = stream.peek ();
                    }
                }
                if (closed) {
                    state.last_token = new Array ('string', ident);             
                    return state.last_token; 
                }
                else {
                    state.last_token = new Array ('ostring', ident);            
                    return state.last_token; 
                }            
            }
            else {                             
                var ident = x;                   
                while (!stream.eol ()) {
                    x = stream.peek ();
                    if (x != undefined && 
                        x != ' ' && x != '=' && x != ',' && x != ')' && x != '&' &&
                        x != '>' && x != '<') {
                          
                        ident += stream.next ();
                    }
                    else  {
                        break;
                    }
                }   
                state.last_token = new Array ('ident', ident);                
                return state.last_token; 
            }
        }
        return undefined;             
    }


    function match_cont_jes2 (stream, state) {
        var tok  = get_token (stream, state);
        var cls  = null;            
          
        switch (tok [0]) {
        case 'string':
        case 'ostring':
            cls = 'str';
            break;
            
        case 'comma':
        case 'oper':
        case 'amp':
        case 'eq':
        case 'lt':
        case 'gt':
        case 'le':
        case 'ge':
            cls = 'symbol';
            break;
            
        case 'lbr':
        case 'rbr':
            cls = 'br';
            break;                        
        }
       
        stream.eatWhile (' ');
        if (stream.eol ())
            state.exp = 'START';
            
        return cls;
    }
    

    function match_jes2 (stream, state) {
        var tok = get_token (stream, state);
        stream.eatWhile (' ');
        if (tok == undefined) {
            state.exp = 'START';
            return 'wrong';
        }
                   
        switch (tok [1]) {
        case 'JOBPARM':
        case 'MESSAGE':
        case 'NETACCT':
        case 'NOTIFY':
        case 'OUTPUT':
        case 'PRIORITY':
        case 'ROUTE':
        case 'SETUP':
        case 'SIGNOFF':
        case 'SIGNON':
        case 'XEQ':
        case 'XMIT': 
            state.exp = stream.eol () ? 'START' : 'CONT_JES2';
            return 'jes_stmt_type';
            
        default:
            state.exp = stream.eol () ? 'START' : 'CONT_JES2';            
            return (tok [1].substr (0, 1) == '$') ? 'jes_stmt_type' : 'wrong';
        }   
    }


    function match_start (stream, state) {
        var x = stream.next ();
        if (x != '/') {
            stream.skipToEnd ();
            return null;
        }
        x = stream.next ();
        p = stream.peek ();
        if (x == '*' && p != undefined && p != '' && p != ' ')
            return match_jes2 (stream, state);
            
        if (x == '*') {
            stream.eatWhile (' ');
            if (!stream.eol ()) { 
                state.exp  = 'CMT_FIELD';
                state.next = 'START';
            }
            return 'dlm_stmt_type';
        }    
          
        if (x != '/') {
            stream.skipToEnd ();
            return null;
        }
        x = stream.peek ();
        if (x == '*') {
            stream.skipToEnd ();
            return 'cmt';
        }
        if (!stream.eol () && x != ' ') {
            state.exp = 'STMT_NAME';
            return 'slash';
        }
        stream.eatWhile (' ');
        if (stream.eol ()) 
            return 'null_stmt_type';
        
        state.exp = 'STMT_TYPE';
        return 'slash';
    }
    
    
    function match_stmt_name (stream, state) {
        state.last_token = undefined;
        x = get_token (stream, state);
        stream.eatWhile (' ');        
        if (stream.eol ()) { 
            state.exp = 'START';
            stream.skipToEnd ();
        }
        else {
            state.exp = 'STMT_TYPE';
        }
        return 'jcl_stmt_name';
    }
        
    
    function match_stmt_type (stream, state) {            
        var x = get_token (stream, state);        
        if (x [0] != 'ident') {
            state = 'START';
            stream.skipToEnd ();
            return 'wrong';
        }                 

        state.stmt = x [1];                        
        switch (x [1]) {
            case 'JOB':
            case 'EXEC':
            case 'DD':    
            case 'CNTL':    
            case 'INCLUDE': 
            case 'JCLLIB':   
            case 'OUTPUT':
            case 'PROC':
            case 'SET':
            case 'XMIT':
                stream.eatWhile (' ');
                if (stream.eol ()) {
                    state.exp = 'START';
                    stream.skipToEnd ();                
                }
                else {
                    state.exp        = 'PARM';
                    state.first_parm = true;
                }
                return 'jcl_stmt_type';
                
            case 'IF':
                stream.eatWhile (' ');
                if (stream.eol ()) {
                    state.exp = 'START';
                    stream.skipToEnd ();                
                }
                else
                    state.exp = 'IF';
                return 'jcl_stmt_type';   
                
            case 'ENDIF':
            case 'ELSE':
            case 'ENDCNTL':
            case 'PEND':
                stream.eatWhile (' ');
                if (stream.eol ()) {
                    state.exp = 'START';
                    stream.skipToEnd ();                
                }
                else {
                    state.next = 'START';
                    state.exp = 'CMT_FIELD';
                }
                return 'jcl_stmt_type';                      
                
            default:   
                clear_state (state);            
                state.exp = 'START';
                return 'wrong';
        }
    }
     
    
    function match_cmt_field (stream, state) {
        stream.skipToEnd ();
        var next = state.next;        
        if (next == 'START')
            clear_state (state);        
        state.exp  = next;
        return 'cmt';
    }
    
     
    function clear_state (state) {
        state.stmt         = undefined;
        state.next         = undefined;
        state.comma        = undefined;
        state.last_token   = undefined;
        state.instream     = undefined;
        state.dlm1         = undefined;
        state.dlm2         = undefined;
        state.wait_for_dlm = undefined;
    }


    function match_cont_parm (stream, state) {
        var x = stream.next ();
        if (x != '/') {
            stream.skipToEnd ();
            state.exp = 'START';
            return null;
        }
        x = stream.next ();
        if (x != '/') {
            stream.skipToEnd ();
            state.exp = 'START';
            return null;
        }
        x = stream.peek ();
        if (x == '*') {
            stream.skipToEnd ();
            return 'cmt';
        }
        if (x != ' ') {
            stream.skipToEnd ();
            state.exp = 'START';
            return null;
        }    
            
        if (x == ' ') {
            stream.eatWhile (' ');
            if (stream.eol ()) {
                clear_state (state);
                stream.skipToEnd ();
                state.exp = 'START';
                return 'null_stmt_type';
            }
        }    
        state.exp = 'PARM';
        return 'slash';
    }
    
    
    function match_cont_if (stream, state) {
        var x = stream.next ();
                
        if (x != '/') {
            stream.skipToEnd ();
            state.exp = 'START';
            return null;
        }
        x = stream.next ();
        if (x != '/') {
            stream.skipToEnd ();
            state.exp = 'START';
            return null;
        }
        x = stream.peek ();
                
        if (x == '*') {
            stream.skipToEnd ();
            return 'cmt';
        }
        if (x != ' ') {  
            state.exp = 'STMT_NAME';
            return 'slash';
        }    
            
        stream.eatWhile (' ');
        if (stream.eol ()) {
            clear_state (state);
            stream.skipToEnd ();
            state.exp = 'START';
            return 'null_stmt_type';
        }
        else {
            state.exp = 'IF';
            return 'slash';
        }
    }
    

    function match_if (stream, state) {
        var last = state.last_token;
        var tok  = get_token (stream, state);
        var cls  = null;

        if (tok == undefined) {
            state.exp = 'CONT_IF'; 
            return null;
        }

        stream.eatWhile (' ');
        if (stream.eol ())
            state.exp = 'CONT_IF';
            
        switch (tok [0]) {
        case 'ident':
            break;
            
        case 'string':
        case 'ostring':
            cls = 'str';
            break;
            
        case 'comma':
        case 'oper':
        case 'amp':
        case 'eq':
        case 'lt':
        case 'gt':
        case 'le':
        case 'ge':
            cls = 'symbol';
            break;
            
        case 'lbr':
        case 'rbr':
            cls = 'br';
            break;                        
        }
                
        if (tok [0] == 'ident' && tok [1] == 'THEN' &&
            (last [0] == 'string' || last [0] == 'ident' || last [0] == 'rbr')) {
            
            cls = 'jcl_stmt_type';
            stream.eatWhile (' ');
            if (!stream.eol ()) {
                state.exp  = 'CMT_FIELD';
                state.next = 'START'; 
            }
            else
                state.exp = 'START';
            return cls;
        }

        return cls;
    }
    
    
    function match_parm (stream, state) {
        var last = state.last_token;
        var tok  = get_token (stream, state);
        var cls  = null;            
          
        switch (tok [0]) {
        case 'ident':
            break;
            
        case 'string':
        case 'ostring':
            cls = 'str';
            break;

        case 'comma':
        case 'oper':
        case 'amp':
        case 'eq':
        case 'lt':
        case 'gt':
        case 'le':
        case 'ge':
            cls = 'symbol';
            break;
            
        case 'lbr':
        case 'rbr':
            cls = 'br';
            break;                        
        }
       
        next = stream.peek ();
        if (next == ' ') 
            stream.eatWhile (' ');
        
        if (state.first_parm && state.stmt == 'DD') {    
            if (tok [1] == '*') { 
                state.instream = '*';
                state.dlm1     = '//';
                state.dlm2     = '/*';
            }
            if (tok [1] == 'DATA') { 
                state.instream = 'DATA';
                state.dlm1     = undefined;
                state.dlm2     = undefined;
            }
        }   
        state.first_parm = false;   
        
        if (state.wait_for_dlm == true && tok [0] == 'ident')
            state.dlm1 = tok [1];        
        if (state.stmt == 'DD' && state.instream == 'DATA' && state.dlm1 == undefined && last [0] == 'comma' && tok [1] == 'DLM') 
            state.wait_for_dlm = true;
        else if (state.wait_for_dlm == true && tok [0] != 'eq')
            state.wait_for_dlm = undefined;
            
        if (stream.eol ()) {
            if (tok [0] == 'comma' || tok [0] == 'ostring') {
                state.exp = 'CONT_PARM';
            }
            else {
                if ((state.instream == '*' || state.instream == 'DATA') && state.dlm1 != undefined)
                    state.exp = 'INSTREAM';
                else {
                    clear_state (state);
                    state.exp = 'START';
                }
            }
            return cls;
        }
        else if (next == ' ') {
            state.exp  = 'CMT_FIELD';
            if ((state.instream == '*' || state.instream == 'DATA') && state.dlm1 != undefined)
                state.next = 'INSTREAM';
            else    
                state.next = (tok [0] == 'comma') ? 'CONT_PARM' : 'START';
            return cls; 
        }
        
        return cls;
    }            
     
     
    function match_instream (stream, state) {
        var t1 = stream.next ();
        if (t1 == undefined) {
            stream.skipToEnd ();
            return 'instream';
        }
        var t2 = stream.next ();
        if (t2 == undefined) {
           stream.skipToEnd ();
           return 'instream';
        }
        var dlm = t1 + t2;
        if (state.instream == '*' && dlm == '//') {
            clear_state (state);            
            var t3 = stream.peek ();
            if (t3 != undefined && t3 != ' ' && t3 != '') {
                if (t3 == '*') {
                    stream.skipToEnd ();
                    clear_state (state);
                    state.exp = 'START';
                    return 'cmt';
                }
                state.exp = 'STMT_NAME';
                return 'slash';
            }
            else {
                stream.eatWhile (' ');
                if (stream.eol ()) {
                    clear_state (state);
                    state.exp = 'START';
                    return 'null_stmt_type';
                }
                else {
                    state.exp = 'STMT_TYPE';
                    return 'slash';
                }
            }
        }
        var t3 = stream.next ();        
        if (t3 != undefined && t3 != ' ') {
            stream.skipToEnd ();
            return 'instream';
        }
        
        stream.eatWhile (' ');
        if (dlm != state.dlm1 && dlm != state.dlm2) {
            stream.skipToEnd ();
            return 'instream';
        }        
        if (stream.eol ()) {
            clear_state (state);
            state.exp = 'START';
            return 'dlm_stmt_type';
        }
        else {
            state.exp  = 'CMT_FIELD';
            state.next = 'START';
            return 'dlm_stmt_type';
        }
    }
     
     
    return {
        startState: function () {
            return {
                exp: 'START'
            };
        },
        
        copyState: function (state) {
            exp          = state.exp;
            stmt         = state.stmt;
            next         = state.next;
            comma        = state.comma;
            last_token   = state.last_token;
            instream     = state.instream;
            dlm1         = state.dlm1;
            dlm2         = state.dlm2;
            wait_for_dlm = state.wait_for_dlm;            
        },
    
	    token: function (stream, state) {	    
	        switch (state.exp) {
	        case 'START':
	            return match_start (stream, state);
	            
	        case 'STMT_NAME':
	            return match_stmt_name (stream, state);

	        case 'STMT_TYPE':
	            return match_stmt_type (stream, state);

	        case 'PARM':
	            return match_parm (stream, state);

	        case 'CONT_PARM':
	            return match_cont_parm (stream, state);

	        case 'CMT_FIELD':
	            return match_cmt_field (stream, state);

	        case 'IF':
	            return match_if (stream, state);

	        case 'CONT_IF':
	            return match_cont_if (stream, state);

	        case 'CONT_JES2':
	            return match_cont_jes2 (stream, state);

	        case 'INSTREAM':
	            return match_instream (stream, state);
	     
	        }	     
    	    return '';
        }
    }
});

CodeMirror.defineMIME("text/jcl", "jcl");
