
var members = new Array ();
var editors = new Array ();

function initSyntaxJclView (mem) {
    var css = getSelectedCssView ();
    if (css == false) { 
        ta2DivOne (mem);
    }                
    else {
        createInstanceViewOne (mem);
        cmSetEditorsSyntax (document.getElementById ('theme').selectedIndex);
    }
    members [members.length] = mem;                
}
      

function initSyntaxJclEdit (mem) {
    createInstanceEditOne (mem);    
    updateCursorOne (mem);
    cmSetEditorsSyntax (document.getElementById ('theme').selectedIndex, 'edit');
    
    members [members.length] = mem;    
}


function ta2Div () {
    for (var mem in members) {
        ta2DivOne (members [mem]);    
    }
    editors = new Array ();
}
        

function ta2DivOne (mem) {
    var ta = document.getElementById ('ta[' + mem + ']');
    var me = document.getElementById ('mem[' + mem + ']');
    var dv = document.createElement ('div');
    dv.setAttribute ('id', 'dv[' + mem + ']');
    dv.setAttribute ('class', 'source_code'); 
    dv.innerHTML = "<pre>" + ta.value + "</pre>";            
    me.appendChild (dv);
    me.removeChild (ta);
}


function createInstanceView () {
    for (var mem in members) {
        createInstanceViewOne (members [mem]);            
    }
}


function createInstanceViewOne (mem) {
    editors [mem] = CodeMirror.fromTextArea (document.getElementById ('ta[' + mem + ']'), {
        workTime: 10,
        workDelay: 500,
        mode: "jcl",
        lineNumbers: true,
        matchBrackets: true,
        readOnly: "nocursor",
        theme: "jcl-ispf jcl-view"
    });
}


function createInstanceEdit () {
    for (var mem in members) {
        createInstanceEditOne (members [mem]);
    }
}        


function createInstanceEditOne (mem) {
    var ta = document.getElementById ('ta[' + mem + ']');
    if (ta != null) {
        editors [mem] = CodeMirror.fromTextArea (ta, {
            workTime: 30,
            workDelay: 200,
            mode: "jcl",
            lineNumbers: true,
            matchBrackets: true,
            theme: "jcl-ispf jcl-edit",
            onCursorActivity: updateCursor,
            onChange: function(editor, change) {
                from = change.from.line;
                to   = from - 1 + change.text.length;
                cmCorrectionLines (editor, from, to);
                if (change.next !== undefined) {
                    from = change.next.from.line;
                    to   = from - 1 + change.next.text.length;
                    cmCorrectionLines (editor, from, to);
                }
            }
        });
    }
    showCursorOne (mem);
}        

        
function getSelectedCssView () {
    switch (document.getElementById ('theme').selectedIndex) {
    case 1:
        return 'jcl_web_view.css';
    case 2:
        return 'jcl_ispf_view.css';
    default:
        return false;
    }
}


function getSelectedCssEdit () {
    switch (document.getElementById ('theme').selectedIndex) {
    case 1:
        return 'jcl_web_edit.css';
    case 2:
        return 'jcl_ispf_edit.css';
    default:
        return false;
    }
}


function setCssView (css) {
    for (var ss = 0; ss < document.styleSheets.length; ss++) {
        if (document.styleSheets [ss].href == null)
            continue;              
        if (document.styleSheets [ss].href.indexOf ('jcl_web_view.css', 0) > -1)
            document.styleSheets [ss].disabled = (css != 'jcl_web_view.css');       
        if (document.styleSheets [ss].href.indexOf ('jcl_ispf_view.css', 0) > -1)
            document.styleSheets [ss].disabled = (css != 'jcl_ispf_view.css');
    }       
}


function setCssEdit (css) {
    for (var ss = 0; ss < document.styleSheets.length; ss++) {
        if (document.styleSheets [ss].href == null)
            continue;              
        if (document.styleSheets [ss].href.indexOf ('jcl_web_edit.css', 0) > -1)
            document.styleSheets [ss].disabled = (css != 'jcl_web_edit.css');       
        if (document.styleSheets [ss].href.indexOf ('jcl_ispf_edit.css', 0) > -1)
            document.styleSheets [ss].disabled = (css != 'jcl_ispf_edit.css');
    }       
}


function isActive () {
    for (var mem in members) {
        if (editors [members [mem]] != undefined)
            return true;
    }
    return false;
}


function updateCursorOne (mem) { 
    var c = editors [mem].getCursor ();
    document.getElementById ('cursor_x[' + mem + ']').innerHTML = c.ch + 1;
    document.getElementById ('cursor_y[' + mem + ']').innerHTML = c.line + 1;
}                


function updateCursor () { 
    for (var mem in members) {
        updateCursorOne (members [mem]);
    }
}                


function showCursorOne (mem) {
    document.getElementById ('cursor[' + mem + ']').style.display = 'block';
}


function showCursor () {
    for (var mem in members) {
        showCursorOne (members [mem]);             
    }
}
        
        
function hideCursorOne (mem) {
    document.getElementById ('cursor[' + mem + ']').style.display = 'none';
}


function destroyInstanceView () {
    for (var mem in members) {
        var ta = document.getElementById ('ta[' + members [mem] + ']');
        if (ta != null) {                
            ne = ta.nextSibling;
            ne.parentNode.removeChild (ne);
        }
    }
    ta2Div ();
} 


function destroyInstanceEdit () {
    for (var mem in members) {             
        var ta = document.getElementById ('ta[' + members [mem] + ']');  
        if (ta != null) {          
            var ne = ta.nextSibling;
            if (ne != null && ne.className == 'CodeMirror') {
                ne.parentNode.removeChild (ne);
                ta.style.display = 'block';
            }
        }
        hideCursorOne (members [mem]);
    }
    editors = new Array ();
}


function div2Ta () {
    for (var mem in members) {
        var me = document.getElementById ('mem[' + members [mem] + ']');
        var dv = document.getElementById ('dv[' + members [mem] + ']');                
        if (me != null && dv != null) {
            var ta = document.createElement ('textarea');
            ta.setAttribute ('id', 'ta[' + members [mem] + ']');
            ta.setAttribute ('name', 'ta[' + members [mem] + ']');
            ta.setAttribute ('style', 'width: 100%');
            ta.setAttribute ('rows', '30');
            ta.setAttribute ('wrap', 'off');
            ta.value = dv.innerHTML.substr (5, dv.innerHTML.length - 11);
            me.appendChild (ta);
            me.removeChild (dv);
        }
    }           
}


function saveData () {
    for (var mem in editors) {
        editors [mem].save ();
    }            
}


function changeThemeView () {
    switch (document.getElementById ('theme').selectedIndex) {
    case 0:
        if (isActive ()) 
            destroyInstanceView ();
        break;
            
    case 1:
        if (!isActive ()) {
            div2Ta ();
            createInstanceView ();
        }
        cmSetEditorsSyntax ('web');
        break;
              
    case 2:
        if (!isActive ()) { 
            div2Ta ();
            createInstanceView ();
        } 
        cmSetEditorsSyntax ('ispf');
        break;
    }
}


function changeThemeEdit () {
    switch (document.getElementById ('theme').selectedIndex) {
    case 0:
        if (!isActive ()) 
            createInstanceEdit ();
        cmSetEditorsSyntax ('none', 'edit');
        break;
            
    case 1:
        if (!isActive ()) 
            createInstanceEdit ();
        cmSetEditorsSyntax ('web', 'edit');
        break;
              
    case 2:
        if (!isActive ()) 
            createInstanceEdit ();
        cmSetEditorsSyntax ('ispf', 'edit');
        break;
    }
}   


function enableTheme () {
    document.getElementById ('theme').disabled = false;            
}

function cmCorrectionLines (editor, fromLine, toLine) {
    var maxLineLength        = editor.getOption ("maxLineLength");
    var maxLineLengthMessage = editor.getOption ("maxLineLengthMessage");
    
    if (maxLineLength !== undefined) {
        if (toLine === undefined) {
            toLine = fromLine;
        }
        
        var cursor = editor.getCursor ();
        var long   = new Array(); 
        
        for (var lineNumber = fromLine; lineNumber <= toLine; lineNumber++) {            
            var line  = editor.getLine (lineNumber);
            var l     = line.match(new RegExp('.{1,' + maxLineLength + '}', 'g'));

            if(l !== null && l.length > 1) {
                long.push(lineNumber);                
                
                editor.setLine(lineNumber, l[0]);
                editor.setCursor(cursor);
            }
        }
        
        if (maxLineLengthMessage !== undefined && long.length > 0) {
            var i = 0;
            lines = "";
            long.forEach (function(lineNumber) {
                if (i++ == 0) {
                    lines = (lineNumber+1);
                } else {
                    lines += ", " + (lineNumber+1);
                }
            });
            
            alert (lines + ": " + maxLineLengthMessage);
        }
    }
}

function cmSetMode (mode, editor) {
    if (editor !== undefined) {
        editors [editor].setOption ('mode', mode);
    } else {
        for (var mem in editors) {
            editors [mem].setOption ('mode', mode);
        }
    }                
}

function cmSetMatchBrackets (matchBrackets, editor) {
    if (editor !== undefined) {
        editors [editor].setOption ('matchBrackets', matchBrackets);
    } else {
        for (var mem in editors) {
            editors [mem].setOption ('matchBrackets', matchBrackets);
        }
    }                
}

function cmSetTheme (theme, editor) {
    if (editor !== undefined) {
        editors [editor].setOption ('theme', theme);
    } else {
        for (var mem in editors) {
            editors [mem].setOption ('theme', theme);
        }
    }
}

function cmSetEditorsSyntax (syntax, mode) {    
    if (mode === undefined) {
        mode = "view";
    }
    switch (syntax) {
        case 'web':
        case 1:
            cmSetMode ('jcl');
            cmSetTheme ('default jcl-web jcl-' + mode);
            cmSetMatchBrackets (true);
            break;        
        case 'ispf':
        case 2:
            cmSetMode ('jcl');
            cmSetTheme ('default jcl-ispf jcl-' + mode);
            cmSetMatchBrackets (true);
            break;
        case 'none':
        default:
            cmSetMode ('text/plain');
            cmSetTheme ('default jcl-none jcl-' + mode);
            cmSetMatchBrackets (false);
    }
}
