<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');
?>
<html>
<head>
   <title>Add Event Rule Definition Help</title>
   <?php tws_stylesheet(); ?>
</head>
<body class=help>
<?php
   tws_set_window_title();
   include 'tws_help_topbar.php';
?>
<h1 class=help>Add Event Rule Definition Help</h1>
<p>The dialog consists of 3 sheets:</p>
- <b>General Options:</b> General Event Rule options - Name, description, validity range, daily activity range, default time zone, draft flag.</br>
- <b>Events:</b> Specifications of the event rule event(s) condition(s) and the events common options (timeout, correlated attributes).</br>
- <b>Actions:</b> Specifications of the actions.</br>
<p>To create a new event rule, fill in the form fields on the 3 sheets as described below. The sheets can be repeatedly switched by clicking their title. When the specification of all requested parameters is done, click the Add button to create the new event rule to the IWS database. IWS/WebAdmin automatically detects the IWS version, and only displays the fields that are available for that version.</p>

<h2 class=help>General Options Sheet Fields Descriptions</h2>

<p><strong>Event Rule Name</strong>: Name of the event rule. It can contain up to 40 characters.  The first character of the event rule name must be a letter, and it can contain alphanumeric characters, dashes ( - ), and underscores ( _ ).</p>
<p><strong>Valid From</strong>: Start date of the event rule validity range.</p>
<p><strong>Valid To</strong>: Final date of the event rule validity range.</p>
<p><strong>Daily Start</strong>: Start of the event rule daily activity time range.</p>
<p><strong>Daily End</strong>: End of the event rule daily activity time range.</p>
<p><strong>Draft</strong>: Draft flag to mark uncompleted event rule definition or to deactivate the event rule.</p>

<h2 class=help>Events Sheet Fields Descriptions</h2>

<p><strong>+ Add Event</strong>: Select a new event for addition from the drop down list. After selection, the new event specification panel is added at the bottom of the Events list.</p>
<p><strong>Type</strong>: Specifies the type of the event rule. In case of one event in the event rule, the type must be SINGLE. Multiple events can be processed as SET or as a SEQUENCE.</p>
<p><strong>Timeout</strong>: Specifies the events timeout.</p>
<p><strong>Correlate events on</strong>: Allows to join more events on their common attributes to create separate rule copy for each group of events with common attributes. </p>
<p><strong>Event panel</strong>:</p>
<p>- Each event is displayed as a panel in the Events list. The title bar of the panel contains the type of the event and 4 control buttons for expansion/collapse, moving up/down in the events list and self-removal.</p>
<p>- Bellow the title bar there is a field <b>Name</b>, where the name of the event instance can be specified for better orientation. The first version of the name is automatically generated. All events must have a unique name.</p>
<p>- Follows the list of event attributes specifications. Each event type has different set of attributes. The <b>mandatory attributes</b> are displayed automatically, additional attributes can be added from the <b>+ Additional attributes</b> drop-down list displayed at the bottom of the panel.
Non mandatory attributes can be removed by clicking the <b>X button</b> at the left side. Some attributes can appear multiple times.</p>
<p>- Each attribute condition specification starts with operator. Select the operator from the drop down list displayed at the right side of the attribute name. The operator is followed by the value. Some attribute values can have multiple values. In this case, two control buttons are displayed: <b>X button</b> for removing the value, <b>+ button</b> for adding a new value.</p>

<h2 class=help>Actions Sheet Fields Descriptions</h2>
<p><strong>+ Add Action</strong>: Select a new action to be taken from the drop down list. After selection, the new action specification panel is added at the bottom of the Actions list.</p>
<p><strong>Action panel</strong>: </p>
<p>- Each action is displayed as a panel in the Actions list. The <b>title bar</b> of the panel contains the type of the action and 4 control buttons for expansion/collapse, moving up/down in the actions list and self-removal. </p>
<p>- Bellow the title bar there is a field <b>Response Type</b> that allows to specify the type of the action, and the <b>Description</b> field that can be used to describe the task of the action. </p>
<p>- Follows the list of action attributes specifications. Each action type has different set of allowed attributes. The <b>mandatory attributes</b> are displayed automatically, additional attributes can be added from the <b>+ Additional attributes</b> drop-down list displayed at the bottom of the panel.
Non mandatory attributes can be removed by clicking the <b>X button</b> at the left side. Some attributes can appear multiple times. </p>
<p>- The attribute specification starts with value. Some attribute value can be specified using the <b>List</b> picker displayed next to the value input field. It’s also possible to variables referring to the actual event attributes. Use the <b>Variable</b> button to insert the reference.</p>

</body>
</html>
