<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_profile('opener', basename($_SERVER['REQUEST_URI']));
   tws_doctype("t");
?>
<html>
<head>
<title>IWS Database Report</title>
<?php tws_stylesheet(); ?>
<script type="text/javascript">
function submit_page2(objecttype) {
   open("tws_database_report_select.php?objecttype=" + objecttype,"_self");
}
</script>
</head>
<body>
<?php
if(tws_get_menu('TWS_Database')==0) tws_access_denied();

   tws_set_window_title();
   tws_print_head('IWS Database Report');
?>
<form name="objectselect" action="">
<table border=0 cellspacing=0>
<tr>
<td class=standard width=150>
<b>IWS Object Type:</b>
</td>
<td>
<select name="objecttype" onchange="submit_page2(document.objectselect.objecttype.options[document.objectselect.objecttype.selectedIndex].value)">
   <option value="-- Select One --">-- Select One --</option>
   <option value="Workstations">Workstations</option>
   <option value="Domains">Domains</option>
   <option value="Jobstreams">Jobstreams</option>
   <option value="Jobs">Jobs</option>
   <option value="Calendars">Calendars</option>
   <option value="Resources">Resources</option>
   <option value="Prompts">Prompts</option>
   <option value="Parameters">Parameters</option>
   <option value="Users">Users</option>
</select>
</td>
</tr>
</table>
</form>
</body>
</html>
