<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add Resource</title>
<?php
tws_stylesheet();
tws_show_backup();
?>
</head>
<body>
<?php tws_set_window_title(); ?>

<?php
   tws_check_synchro_token();  // synchro_token
   tws_import_request_variables("P","rqst_");

   if (isset($rqst_modify)) {
      if (!tws_permit_action('database_resources','Modify')) { tws_access_denied ();}
      $modify=$rqst_modify;
   } else {
         $modify="no";
         if (!tws_permit_action('database_resources','Add')) { tws_access_denied ();}
   }
   if ($modify == "yes") {
      $workstation_name=tws_gpc_get($rqst_workstationx, 'tws_name');
      $resource_name=tws_gpc_get($rqst_resource_namex, 'tws_name');
   } else {
      $workstation_name=tws_gpc_get($rqst_workstation, 'tws_name');
      $resource_name=tws_gpc_get($rqst_resource_name, 'tws_name');
   }
   $workstation_name=strtoupper($workstation_name);
   $resource_name=strtoupper($resource_name);

   if (isset($rqst_confirm)) {
      $confirm=$rqst_confirm;
   } else {
      $confirm="no";
   }
   if (isset($rqst_backup)) {
      $backup=$rqst_backup;
   } else {
      $backup="no";
   }
   $original_data=tws_gpc_get($rqst_original_data);

   if (tws_zli_module_check() && isset($rqst_called_by_netmodule))
       $called_by_netmodule = $rqst_called_by_netmodule;

   $resource_units=tws_gpc_get($rqst_resource_units, 'tws_num');
   $resource_description=tws_gpc_get($rqst_description);

   $action=$rqst_action;
   if ($action=="Cancel") {
      // Unlock the object
      tws_composer_unlock("res=$workstation_name#$resource_name") or tws_dyer("Unable to unlock resource '$workstation_name#$resource_name'");
      echo "<script type='text/javascript'>\n";
         echo "  closeme('tws_resourcesx.php');\n";
      echo "</script>\n";
      exit;
   }
   elseif($action=="Return to Modification"){
      include("tws_add_resource.php");
      exit;
   }

// Check for existing resource
   $match=FALSE;
   if ($confirm != "yes") {
      if (($db_resource = tws_get_resources($resource_name, "WKC_NAME = '$workstation_name'")) === FALSE) {
         tws_dyer("Unable to list resources");
      }
      if ($db_resource['resource_num'] > 1) {
         tws_dyer("Database query failed");
      }
      if (($db_resource['resource_num'] == 1) && ($resource_name == $db_resource['resource_name'][0])
            && ($workstation_name == $db_resource['resource_workstation'][0])  ) {
         $orig_resource_units=$db_resource['resource_quantity'][0];
         $orig_resource_description=$db_resource['resource_description'][0];
         $match = TRUE;
      }

   }

   if ($match == TRUE) {
      if ($modify == "yes") {
         echo "<h1>Confirmation</h1>\n";
      } else {
         echo "<h1>Replace Resource Confirmation</h1>\n";
      }
      echo "<br><br>\n";
      echo "<h3>Confirm:</h3>\n";
      if ($modify != "yes") {
         echo "&nbsp;&nbsp;<b>The Resource Name entered already exists</b>\n";
         echo "<br><br>\n";
      }
      $orig_resource_data = Array ( 'workstation' => $workstation_name,
                                    'resource_name' => $resource_name ,
                                    'resource_units' => $orig_resource_units,
                                    'description' => $orig_resource_description );
      $new_resource       = Array ( 'workstation' => $workstation_name,
                                    'resource_name' => $resource_name ,
                                    'resource_units' => $resource_units,
                                    'description' => $resource_description );
      $label_map        = Array ( 'workstation' => 'Workstation' ,
                                  'resource_name' => 'Name' ,
                                  'resource_units' => 'Units',
                                  'description' => 'Description' );

      tws_show_cmp_table("Original Resource", "New Resource", $orig_resource_data, $new_resource, $label_map);
// confirmation form
      echo "<form method=post name=\"confirm\" action=\"tws_add_resource_exec.php\">\n";
      echo "<input type=\"hidden\" name=\"confirm\" value=\"yes\">\n";
      if ($original_data=='') {
         //missing original data - this happens if user is adding job that already exists.
         if (($original_data=tws_composer_create_from("res=$workstation_name#$resource_name"))===FALSE) {
            tws_err("Unable to get original data required to create backup.");
         }
      }
      echo "<input type=\"hidden\" name=\"original_data\" value=\"".htmlspecialchars($original_data)."\">\n";
      foreach( $new_resource as $key=>$val ){
         echo "<input type=\"hidden\" name=\"".htmlspecialchars($key)."\" value=\"".htmlspecialchars($val)."\">\n";
      }
      if (tws_zli_module_check () && isset ($called_by_netmodule)) {
          echo "<input type=\"hidden\" name=\"called_by_netmodule\" value=\"".htmlspecialchars($called_by_netmodule)."\">\n";
      }
      if (tws_rights(SAVEBACKUPS) && $original_data!=''){
         echo "<input type='hidden' name='backup' value='yes'>";
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type='checkbox' name='backup' value='yes' checked disabled>&nbsp;Save Backup Copy of Original Resource</label>\n";
      }
      else
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type=\"checkbox\" name=\"backup\" value=\"yes\" ".($original_data!='' ? 'checked' : 'disabled').">&nbsp;Save Backup Copy of Original Resource</label>\n";
      echo "<br><br><br>\n";
      if ($modify == "yes") {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Update\" name=\"action\">\n";
         echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
         echo "<input type=\"hidden\" name=\"workstationx\" value=\"".htmlspecialchars($workstation_name)."\">\n";
         echo "<input type=\"hidden\" name=\"resource_namex\" value=\"".htmlspecialchars($resource_name)."\">\n";
      } else {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Replace\" name=\"action\">\n";
      }
      echo '&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Return to Modification">'."\n";
      echo '&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Cancel">'."\n";
      tws_print_synchro_token();   // synchro_token
      echo "</form>\n";

   } else {
// Create Backup Copy if option checked
      if ($backup == "yes") {
         if (($bckfilename = tws_write_backup($original_data, "resource", $resource_name)) === FALSE) {
            tws_dyer("Unable to write backup");
         }
      }

// unlock the object
      tws_composer_unlock("res=$workstation_name#$resource_name");

// Create random temporary filename
      $tmpfilename="$maestro_dir/webadmin/tmp/resource.".tws_rndstr().".tmp";
      $fp=fopen($tmpfilename,'w') or tws_dyer("Unable to create temporary file");

      $cmd=Array();
      $cmd[]="\$resource\n";
      $cmd[]="$workstation_name#$resource_name $resource_units \"".addcslashes($resource_description,'"')."\"\n";
      foreach ($cmd as $cmdline) {
         $num_bytes=fwrite($fp,$cmdline);
         if ($num_bytes < 0) {
            fclose($fp);
            tws_dyer("Unable to write temporary file");
         }
      }
      fclose($fp);
      tws_chmod($tmpfilename,0644);

      if ($confirm == "yes") {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "replace $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      } else {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "add $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      }

      $stdout3='';
      $ec_popen=tws_popen($command3, $ec3, $stdout3, $stdout3, "N");
     
      //remove the tmp file now
      unlink($tmpfilename);
 
      //testing for the AWSBIA288I Total objects updated: 0.
      //Note: This has been added on 2016-07 to fix the problem of composer updating 
      //correctly objects but returning incorrect return codes (not 0 or 4)
      $not_updated=!preg_match('/AWSBIA288[^\n]+(\d+)/', $stdout3, $_r) || $_r[1]==0;

      if ($ec_popen===FALSE || ($ec3!=0 && $ec3!=4 && $not_updated)) {
         if ($modify == "yes") {
            echo "<h1>Modify Resource Status</h1>\n";
         } else {
            echo "<h1>Add Resource Status</h1>\n";
         }
         tws_err("Resource add/modify operation failed", array('twscmd'=>$command3->compile('log'), 'stdout'=>$stdout3, "EC_POPEN"=>$ec_popen, "EC_UPDATED"=>$ec3, "NOT_UPDATED"=>tws_yesno($not_updated,'YES','NO')));
         echo "<form action='tws_add_resource_exec.php' method='post' onsubmit=\"if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Workstation',null)) { cancel_button_pressed=false; return false;}\">\n";
         echo tws_create_hidden_inputs($_POST);
         tws_print_synchro_token();
         echo "<input type='submit' name='action' value='Cancel' onClick='cancel_button_pressed=true;'/>\n";
         echo "<input type='submit' name='action' value='Return to Modification'/>\n";
         echo "</form>";
      } else {
          if (preg_match("/warnings?\s[1-9]/i",$stdout3)) {
              if ($modify == "yes") {
                  $headertext="Modify Resource";
              } else {
                  $headertext="Add Resource";
              }
              tws_err("The Resource has been saved with the following warnings:", array('stdout'=>$stdout3));

              $shortwarnfilename="warn.".tws_rndstr().".txt";
              $warnfilename="$webadmin_tmp_dir/$shortwarnfilename";
              $warnfp=fopen("$warnfilename","w") or tws_dyer("Unable to create warning text file", "Warning output :\n$stdout3");
              $num_bytes=fwrite($warnfp,"$stdout3");
              if ($num_bytes < 0) {
                  fclose($warnfp);
                  unlink($warnfilename);
                  tws_dyer("Unable to write warning text file", "Warning output :\n$stdout3");
              }
              fclose($warnfp);
              tws_dyer();
          }
          if (tws_zli_module_check () && isset ($called_by_netmodule)) {
              $message = urlencode ("The resource has been saved successfuly.");
              echo "<script type='text/javascript'>\n";
              echo "window.location.replace(\"zli_close_window.php?message=$message\");\n";
              echo "</script>\n";
          } else {
             if ($backup == "yes") {
                 if ($modify == "yes") {
                     echo "<h1>Modify Resource Status</h1>\n";
                 } else {
                     echo "<h1>Add Resource Status</h1>\n";
                 }
                 echo "<p class=\"message\">\n";
                 echo "The resource has been successfuly saved.&nbsp;";
                 $bckfilename = preg_replace("/\\\\/", '/', $bckfilename);
                 $file = explode('/',$bckfilename);
                 $file = end($file);
                 if(tws_profile('auth_user_group')=='admin')
                  echo "<a href=\"javascript:showBackup('$file')\">Display Backup File</a>\n";
                 echo "</p>\n";
                     echo "<input type='button' value='OK' onClick=\"closeme('tws_resourcesx.php')\" />\n";
             } else {
                 echo "<script type='text/javascript'>\n";
                     echo "closeme('tws_resourcesx.php');\n";
                 echo "</script>\n";
             }
          }
      }
   }
?>
</body>
</html>
