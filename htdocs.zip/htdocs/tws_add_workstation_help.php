<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');
?>
<html>
<head>
<?php require_once 'tws_functions.php'; tws_doctype('t'); ?><title>Add Workstation Definition Help</title>
<?php tws_stylesheet(); ?>
</head>

<body class="help">
<?php tws_set_window_title(); include 'tws_help_topbar.php'; ?>
<h1 class="help">Add/Modify Workstation definition</h1>

<p>To create a new workstation, fill in the form fields as
described below. When the specification of all requested parameters is
done, click the Add (or Update) button to create the new Workstation (or
save changes in existing one) to the IWS database.
</p>
<br>

<p><b>Workstation Name: </b> Type the name of the workstation.
The name must start with a letter and can contain alphanumeric characters, dashes, and underscores. The maximum length is 16 characters.
Workstation names must be unique and cannot be the same as workstation class names</p>

<p><b>Workstation Type: </b>The type of workstation. The possible values are:
<ul>
   <li><b>Manager</b> - An agent workstation that is the manager of a domain of workstations</li>
   <li><b>Fault Tolerant Agent</b> - An agent workstation that launches jobs and resolves local dependencies without a domain manager.
   Use this workstation type also for backup domain managers and backup master domain managers.</li>
   <li><b>Extended Agent</b> - An agent workstation that launches jobs only under the direction of its host.
   Extended agents can be used to interface Tivoli Workload Scheduler with non-Tivoli systems and applications.</li>
   <li><b>Standard Agent</b> - An agent workstation that launches jobs only under the direction of its domain manager</li>
   <li><b>Workload Broker</b> - A workstation used to communicate with Tivoli Dynamic Workload Broker.
   This is the workstation where theTivoli Workload Scheduler bridge component is installed</li>
</ul>
</p>
<? if ($tws_config['cpuinfo']['version']>='8.6') : ?>
<p>IWS 8.6 has additional workstation types:
<ul>
   <li><b>Remote Engine</b> - A workstation that manages the exchange of information about cross dependencies resolution between your environment
   and a remote IWS engine (master domain manager or backup master domain manager). This workstation is hosted by the workload broker workstation.</li>
   <li><b>Pool</b> - A logical workstation grouping a set of dynamic agents with similar hardware or software characteristics to submit jobs to.
   Tivoli Workload Scheduler balances the jobs among the dynamic agents within the pool. To create a pool of dynamic agents,
   select the dynamic agents you want to add to the pool. This workstation is hosted by the workload broker workstation.</li>
   <li><b>Dynamic Pool</b> - A logical workstation grouping a set of dynamic agents which is dynamically defined based on the resource
   requirements you specify. This workstation maps all the dynamic agents in your environment which meet the requirements you specified.
   The resulting pool is dynamically updated whenever a new suitable dynamic agent becomes available.
   Jobs scheduled on this workstation automatically inherit the requirements defined for the workstation. This workstation is hosted
by the workload broker workstation</li>
</ul>
</p>
<p>Every this workstation types has it's own parameters</p>
<? endif; ?>

<p><b>Node: </b>Specify the host name or the IP address of the workstation.</p>
<p><b>TCP Address: </b>Specify the netman TCP/IP port number that IWS uses for communication on the workstation. The default value is 31111.
This value must match the netman TCP/IP port number defined in the nm port local option.</p>
<p><b>Operating System:</b> The operating system of the workstation. Select Other for extended agents</p>
<p><b>Description:</b> Workstation description</p>
<p><b>Domain:</b> Specify the name of a domain for the workstation. Click Use MASTERDM to specify that the workstation is in the master domain</p>
<p><b>Parameter Table:</b> The name of a parameter table associated to this workstation.</p>
<p><b>Time Zone:</b> The time zone of the workstation. Select a time zone from the list.
To ensure the accuracy of scheduling times, this time zone must be the same as the computer's operating system time zone.</p>

<h2 class="help">Security Options</h2>

<p><b>SSL Communication:</b> Select the type of Secure Socket Layer (SSL) communication. Possible values are:
<ul>
   <li>Disabled - Default value. The workstation does not use SSL authentication.</li>
   <li>Enabled - The workstation uses SSL authentication only if its domain manager workstation or another workstation below it in the domain hierarchy requires it.</li>
   <li>On - The workstation uses SSL authentication when it connects with its domain manager. The workstation refuses any incoming connection from its domain manager if it is not an SSL connection.</li>
   <li>Forced - The workstation uses SSL authentication for all of its connections.   It refuses any incoming connection that is not an SSL connection. </li>
</ul>
</p>
<p><b>Secure TCP Port:</b> The secure port number to be used for SSL communication. The default value is 31113. This value must match the one defined in the local option</p>
<p><b>Behind Firewall:</b> Select this option if you have a firewall between this workstation and the master domain manager</p>
<p><b>Server:</b> Optionally select a mailman server ID on the domain manager to handle communications with this workstation.
This parameter is only available for fault-tolerant agents and standard agents.
When the domain manager starts, it creates a separate server for each unique server ID.
Using servers reduces agent initialization time and improves message efficiency.
The IDs are unique to each domain manager, so you can use the same IDs in other domains without conflict.
When a server not specified, communication with agents is handled by the main mailman process on the domain manager.
</p>

<h2 class="help">Options</h2>

<p><b>Auto Link:</b> Select this option to open a link to this workstation at startup.
For a domain manager, select this option to have its agents open links to the domain manager when they are started.
If the check box is not selected for an agent, you must manually link the agent from the agent's domain manager or from the master domain manager</p>
<p><b>Full Status:</b> Select this option if you want this workstation to be updated with full status on the scheduling activities.
In full-status mode, the agent is updated with the status of jobs and job streams running on all other workstations in its domain
and in subordinate domains.
For domain managers, this checkbox is automatically selected. Backup domain managers must always be full status.
If this check box is cleared, the agent workstation is informed only about the status of jobs and job streams that directly affect its own jobs
and jobstreams.
</p>
<p><b>Ignore:</b> Select this option if you do not want to add this workstation to the production plan</p>

<h2 class="help">Extended Agent Options</h2>

<p><b>Access Method :</b> Specify an access method for extended agents and network agents.
Access Method is the name of a method file that resides in the TWShome/methods directory on the agent host workstation.
<ul>
   <li>For local UNIX extended agents, the method name is unixlocl.</li>
   <li>For remote UNIX extended agents the method name is unixrsh.</li>
   <li>For network agents, the method name is netmth.</li>
</ul>
</p>
<p><b>Host:</b> Specify the name of the extended agent's host workstation.
The host is the workstation with which the extended agent communicates and where its access method resides.
The host for an extended agent must be a master, domain manager, or fault-tolerant agent.</p>


</body>
</html>