<?php
//   HORIZONT Software GmbH, Munich
//

require_once("tws_functions.php");
tws_import_request_variables("P","rqst_");

$action=$rqst_action;
$selection=tws_gpc_get($rqst_selection, 'tws_name');
tws_check_selection($action, $selection);

switch ($action) {
   case "Display":
   case "Definition":
      $display='yes';
      if (tws_permit_action('database_applications','Display')) include("tws_add_application.php");
      break;
   case "Add":
      $modify="no";
      $copy="no";
      if (tws_permit_action('database_applications','Add'))  include("tws_add_application.php");
      break;
   case "Modify":
      $modify="yes";
      $copy="no";
      if (tws_permit_action('database_applications','Modify')) include("tws_add_application.php");
      break;
   case "Copy":
      $modify="no";
      $copy="yes";
      if (tws_permit_action('database_applications','Add')) include("tws_add_application.php");
      break;
   case "Rename":
      if (tws_permit_action('database_applications','Rename')) include("tws_rename_application.php");
      break;
   case "Delete":
      if (tws_permit_action('database_applications','Delete')) include("tws_delete_application.php");
      break;
   case "Unlock":
      if (tws_permit_action('database_applications','Unlock')){
         foreach($selection as $app)
            tws_app_unlock($app);
      header("Location: tws_applicationsx.php");
      }
      break;
   case "Notes":
      $type="Application";
      if (tws_permit_action('database_applications','Notes')) include("tws_notes.php");
      break;
   case "Filter":
      include("tws_dbapplication_filter.php");
      break;
   case "Save Filter":
      $object='dbapplication';
      header("Location: tws_save_filter.php?object=$object");
      exit;
   case 'Layout':
      $section = 'Database Applications';
      if (tws_permit_action('common_actions','Layout')) include 'tws_layout.php';
      break;
}

?>