<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
   <title>Add Job Dependency</title>
   <?php tws_stylesheet(); ?>
   <style type="text/css">
      table.submit td { white-space: nowrap; padding-left: 20px; }
   </style>
   <script type="text/javascript" src="tws_insert_row.js"></script>
</head>
<body>
<?php
   tws_set_window_title();
   tws_print_head('Add Job Dependency');

   if (!tws_permit_action('plan_jobs','Add Dep')) {
      tws_access_denied ();
   }
   $_POST = tws_gpc_get($_POST);

   if (!isset($selection) && !isset($_POST['selection']) ){
      $error_msg = 'No objects selected!';
      echo '<p class="warning">'."\n";
      echo $error_msg."\n";
      echo '<br/><br/><a href="javascript:history.back();">Return to the previous page</a>'."\n";
      echo '</p>'."\n";
      tws_dyer();
   }

   $selection = is_array($selection) ? $selection : $_POST['selection'];
   $arg = $arg ? $arg : $_POST['arg'];
   $form_confirmation = (tws_profile('form_confirmation') == 'yes') ? true : false; ?>
<h2>Selected Object</h2>
<?php TWS_DISP_PLANJOB_SEL($selection); ?>

<form method="post" name="contents" action="tws_add_job_dependency_exec.php" onsubmit="<?php echo $form_confirmation ? 'return window.confirm(\'Are you sure you want to contiue to perform the operation?\');' : ''; ?>">
<?
foreach($selection as $val)
   echo "<input type='hidden' name='selection[]' value='". htmlspecialchars($val)."'>\n";
?>
<input type="hidden" name="arg" value="<?=htmlspecialchars($arg)?>">

<table class="submit" border="0" cellspacing="0" width="100%">
<colgroup>
   <col span="1" width="1">
</colgroup>
<tr>
   <td colspan="2" style="padding-left: 0px"><h2>Options Dependencies</h2></td>
</tr>
<tr>
   <td><b>At:</b></td>
   <td><input type="text" name="athour" class='tws_hour' size="2" maxlength="2" value="<?php echo $_POST['athour']; ?>" />:<input type="text" name="atminute" class='tws_minute' size="2" maxlength="2" value="<?php echo $_POST['atminute']; ?>" />&nbsp;plus&nbsp;<input type="text" name="atplusdays" class='tws_num' size="3" maxlength="3" value="<?php echo $_POST['atplusdays']; ?>" />&nbsp;days</td>
</tr>
<tr>
   <td><b>Until:</b></td>
   <td><input type="text" name="untilhour" class='tws_hour' size="2" maxlength="2" value="<?php echo $_POST['untilhour']; ?>" />:<input type="text" name="untilminute" class='tws_minute' size="2" maxlength="2" value="<?php echo $_POST['untilminute']; ?>" />&nbsp;plus&nbsp;<input type="text" name="untilplusdays" class='tws_num' size="3" maxlength="3" value="<?php echo $_POST['untilplusdays']; ?>" />&nbsp;days</td>
</tr>
<tr>
   <td>&nbsp;&nbsp;<b>Until Action:</b></td>
   <td>
      <select name="onuntil">
         <option value="suppr" <?php if (($_POST['onuntil'] == 'suppr') || (!$_POST['onuntil'])) echo ' selected'; ?>>Suppress</option>
         <option value="cont" <?php  if ($_POST['onuntil'] == 'cont') echo ' selected'; ?>>Continue</option>
         <option value="canc" <?php if ($_POST['onuntil'] == 'canc') echo ' selected'; ?>>Cancel</option>
      </select>
   </td>
</tr>
<tr>
   <td><b>Deadline:</b></td>
   <td><input type="text" name="deadlinehour" class='tws_hour' size="2" maxlength="2" value="<?php echo $_POST['deadlinehour']; ?>" />:<input type="text" name="deadlineminute" class='tws_minute' size="2" maxlength="2" value="<?php echo $_POST['deadlineminute']; ?>" />&nbsp;plus&nbsp;<input type="text" name="deadlineplusdays" class='tws_num' size="3" maxlength="3" value="<?php echo $_POST['deadlineplusdays']; ?>" />&nbsp;days</td>
</tr>
<?php if (tws_yesno(tws_get_tz_status(),TRUE,FALSE)) { ?>
<tr>
   <td><b>Time&nbsp;Zone:</b></td>
   <td>
      <select name="time_zone">
         <?php tws_print_timezone_options($_POST['time_zone']); ?>
      </select>
   </td>
</tr>
<?php } ?>
<tr>
   <td><b>Every:</b></td>
   <td><input type="text" name="everyhour" class='tws_hour' size="2" maxlength="2" value="<?php echo $_POST['everyhour']; ?>" />:<input type="text" name="everyminute" class='tws_minute' size="2" maxlength="2" value="<?php echo $_POST['everyminute']; ?>" /></td>
</tr>
<tr>
   <td colspan="2">&nbsp;</td>
</tr>
<tr>
   <td><b>Priority:</b></td>
   <td><input type="text" name="privalue" class='tws_priority' size="3" maxlength="3" value="<?php echo $_POST['privalue']; ?>" /></td>
</tr>
<tr>
   <td colspan="2">&nbsp;</td>
</tr>
<tr>
   <td colspan="2"><b><label><input type="checkbox" name="confirmed" value="yes"<?php if ($_POST['confirmed'] == 'yes') echo ' checked="checked";' ?> />Confirmed</label></b></td>
</tr>
<tr>
   <td colspan="2">&nbsp;</td>
</tr>
<tr>
   <td colspan="2" style="padding-left: 0px"><h2>Dependencies</h2></td>
</tr>
<? $i = 1; do { ?>
<tr>
   <td><b>Follows&nbsp;Jobstream:</b></td>
   <td>Workstation:&nbsp;<input type="text" name="followsjobstreamcpu[<?=$i?>]" class='tws_name' size="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" maxlength="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" value="<?=$_POST['followsjobstreamcpu'][$i]?>" />&nbsp;&nbsp;
   <input type="button" name="workstation_list" onClick="tws_picker_open('plan_workstation_picker.php', 'fieldname=followsjobstreamcpu[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['followsjobstreamcpu[<?=$i?>]'].value);" value="List" />&nbsp;&nbsp;&nbsp;
   Jobstream:&nbsp;<input type="text" name="followsjobstreamname[<?=$i?>]" class='tws_name_inst' size="<?=($tws_config['JOBSTREAM_MAXLENGTH']+$tws_config['SCHEDID_MAXLENGTH']+1)?>" value="<?=$_POST['followsjobstreamname'][$i]?>" />&nbsp;&nbsp;
   <input type="button" name="jobstream_list" onClick="tws_picker_open('plan_jobstream_picker.php', 'fieldname=followsjobstreamname[<?=$i?>]&amp;wksfieldname=followsjobstreamcpu[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['followsjobstreamname[<?=$i?>]'].value + '&amp;cpux=' + document.contents.elements['followsjobstreamcpu[<?=$i?>]'].value);" value="List" />
   </td>
</tr>
<? $i++; } while (isset($_POST['followsjobstreamcpu'][$i])); ?>
<tr>
   <td>&nbsp;</td>
   <td><input type="button" onclick="insertRow(this);" value=" + " title="Add Follows Jobstream" /></td>
</tr>
<? $i = 1; do { ?>
<tr>
   <td><b>Follows&nbsp;Job:</b></td>
   <td>Workstation:&nbsp;<input type="text" name="followsjobcpu[<?=$i?>]" class='tws_name' size="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" maxlength="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" value="<?=$_POST['followsjobcpu'][$i]?>" />&nbsp;&nbsp;
   <input type="button" name="workstation_list" onClick="tws_picker_open('plan_workstation_picker.php', 'fieldname=followsjobcpu[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['followsjobcpu[<?=$i?>]'].value);" value="List" />&nbsp;&nbsp;&nbsp;
   Jobstream:&nbsp;<input type="text" name="followsjobjobstream[<?php echo $i; ?>]" class='tws_name_inst' size="<?=($tws_config['JOBSTREAM_MAXLENGTH']+$tws_config['SCHEDID_MAXLENGTH']+1)?>" value="<?=$_POST['followsjobjobstream'][$i]?>" />&nbsp;&nbsp;
   <input type="button" name="jobstream_list" onClick="tws_picker_open('plan_jobstream_picker.php', 'fieldname=followsjobjobstream[<?=$i?>]&amp;wksfieldname=followsjobcpu[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['followsjobjobstream[<?=$i?>]'].value + '&amp;cpux=' + document.contents.elements['followsjobcpu[<?=$i?>]'].value);" value="List" />&nbsp;&nbsp;&nbsp;
   Job:&nbsp;<input type="text" name="followsjobname[<?=$i?>]" class='tws_name' size="<?=$tws_config['JOB_MAXLENGTH']?>" maxlength="<?=$tws_config['JOB_MAXLENGTH']?>" value="<?=$_POST['followsjobname'][$i]?>" />&nbsp;&nbsp;
   <input type="button" name="job_list" onClick="tws_picker_open('plan_job_picker.php', 'fieldname=followsjobname[<?=$i?>]&amp;wksfieldname=followsjobcpu[<?=$i?>]&amp;jsfieldname=followsjobjobstream[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['followsjobname[<?=$i?>]'].value + '&amp;cpux=' + document.contents.elements['followsjobcpu[<?=$i?>]'].value + '&amp;schedulex=' + document.contents.elements['followsjobjobstream[<?=$i?>]'].value);" value="List" />
   </td>
</tr>
<? $i++; } while (isset($_POST['followsjobcpu'][$i])); ?>
<tr>
   <td>&nbsp;</td>
   <td><input type="button" onclick="insertRow(this);" value=" + " title="Add Follows Job" /></td>
</tr>
<? $i = 1; do { ?>
<tr>
   <td><b>Global&nbsp;Prompt:</b></td>
   <td><input type="text" name="promptname[<?php echo $i; ?>]" class='tws_name' size="<?=2*$tws_config['PROMPT_MAXLENGTH']?>" maxlength="<?=$tws_config['PROMPT_MAXLENGTH']?>" value="<?php echo $_POST['promptname'][$i]; ?>" />&nbsp;&nbsp;
   <input type="button" name="prompt_list" onClick="tws_picker_open('prompt_picker.php', 'fieldname=promptname[<?php echo $i; ?>]&amp;fieldvalue=' + document.contents.elements['promptname[<?php echo $i; ?>]'].value);" value="List" />
   </td>
</tr>
<? $i++; } while (isset($_POST['promptname'][$i])); ?>
<tr>
   <td>&nbsp;</td>
   <td><input type="button" onclick="insertRow(this);" value=" + " title="Add Global Prompt" /></td>
</tr>
<? $i = 1; do { ?>
<tr>
   <td><b>Local&nbsp;Prompt:</b></td>
   <td><input type="text" name="prompttext[<?php echo $i; ?>]" class="tws_apostrof" size="80" maxlength="200" value="<?php echo $_POST['prompttext'][$i]; ?>" /></td>
</tr>
<? $i++; } while (isset($_POST['prompttext'][$i])); ?>
<tr>
   <td>&nbsp;</td>
   <td><input type="button" onclick="insertRow(this);" value=" + " title="Add Local Prompt" /></td>
</tr>
<? $i = 1; do { ?>
<tr>
   <td><b>Opens&nbsp;File:</b></td>
   <td>Workstation:&nbsp;<input type="text" name="openscpu[<?php echo $i; ?>]" class='tws_name' size="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" maxlength="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" value="<?php echo $_POST['openscpu'][$i]; ?>" />&nbsp;&nbsp;
   <input type="button" name="workstation_list" onClick="tws_picker_open('plan_workstation_picker.php', 'fieldname=openscpu[<?php echo $i; ?>]&amp;fieldvalue=' + document.contents.elements['openscpu[<?php echo $i; ?>]'].value);" value="List" />&nbsp;&nbsp;&nbsp;
   Filename:&nbsp;<input type="text" name="opensfile[<?php echo $i; ?>]" class='tws_file' size="40" maxlength="<?=$tws_config['FILENAME_MAXLENGTH']?>" value="<?php echo $_POST['opensfile'][$i]; ?>" /></td>
</tr>
<? $i++; } while (isset($_POST['openscpu'][$i])); ?>
<tr>
   <td>&nbsp;</td>
   <td><input type="button" onclick="insertRow(this);" value=" + " title="Add Opens File" /></td>
</tr>
<? $i = 1; do { ?>
<tr>
   <td><b>Needs&nbsp;Resource:</b></td>
   <td>Workstation:&nbsp;<input type="text" name="needscpu[<?php echo $i; ?>]" class='tws_name' size="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" maxlength="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" value="<?php echo $_POST['needscpu'][$i]; ?>" />&nbsp;&nbsp;
   <input type="button" name="workstation_list" onClick="tws_picker_open('plan_workstation_picker.php', 'fieldname=needscpu[<?php echo $i; ?>]&amp;fieldvalue=' + document.contents.elements['needscpu[<?php echo $i; ?>]'].value);" value="List" />&nbsp;&nbsp;&nbsp;
   Resource:&nbsp;<input type="text" name="resource[<?php echo $i; ?>]" class='tws_name' size="<?=$tws_config['RESOURCE_MAXLENGTH']?>" maxlength="<?=$tws_config['RESOURCE_MAXLENGTH']?>" value="<?php echo $_POST['resource'][$i]; ?>" />&nbsp;&nbsp;
   <input type="button" name="resource_list" onClick="tws_picker_open('resource_picker.php', 'fieldname=resource[<?php echo $i; ?>]&amp;fieldvalue=' + document.contents.elements['resource[<?php echo $i; ?>]'].value + '&amp;cpux=' + document.contents.elements['needscpu[<?php echo $i; ?>]'].value);" value="List" />&nbsp;&nbsp;&nbsp;
   Units:&nbsp;<input type="text" name="units[<?php echo $i; ?>]" class='tws_num' size="4" maxlength="4" value="<?php echo $_POST['units'][$i] ? $_POST['units'][$i] : '1'; ?>" />
   </td>
</tr>
<? $i++; } while (isset($_POST['needscpu'][$i])); ?>
<tr>
   <td>&nbsp;</td>
   <td><input type="button" onclick="insertRow(this);" value=" + " title="Add Needs Resource" /></td>
</tr>
</table>
<br/><br/>
&nbsp;&nbsp;<input type="submit" value="Submit" onclick='return tws_validate_form();'/>&nbsp;&nbsp;
<input type="button" value="Reset" onclick="window.location.reload();"/>&nbsp;&nbsp;
<?
      echo '<INPUT TYPE="button" VALUE="Cancel" onClick="closeme(\'tws_sjx.php\');"/>';
   tws_print_synchro_token();
?>
</form>
</body>
</html>
