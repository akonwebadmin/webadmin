<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Cancel Job</title>
<?php tws_stylesheet(); ?>
</head>
<body>
<?php tws_set_window_title(); ?>

<h1>Cancel Job</h1>
<br><br>
<h3>Selected Objects:</h3>

<?php
   if (!tws_permit_action('plan_jobs','Cancel')) {
      tws_access_denied ();
   }
   $num_elements=count($selection);
   if ($num_elements == 0) {
      echo "<p class=warning>&nbsp;&nbsp;&nbsp;&nbsp;No objects selected</p>\n";
   } else {
      TWS_DISP_PLANJOB_SEL($selection);

      echo "<br>\n";

      echo "<form method=post action=\"tws_cancel_job_exec.php\">\n";
      if ($num_elements >= 1) {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type=\"checkbox\" name=\"safe_mode\" value=\"yes\" checked>&nbsp;Safe Mode</label>\n";
         // Restore priority can't be set for Cancelled job
         echo "<br><br>\n";
      }
      for ($idx=0; $idx<$num_elements; ++$idx) {
         echo "<input type=\"hidden\" name=\"selection[]\" value=\"".htmlspecialchars($selection[$idx])."\">\n";
      }
      echo "<input type=\"hidden\" name=\"arg\" value=\"".htmlspecialchars($arg)."\">\n";
      echo "&nbsp;&nbsp;<input type=\"submit\" value=\"Cancel Job\">&nbsp;&nbsp;\n";
      echo '<INPUT TYPE="button" VALUE="Cancel" onClick="closeme(\'tws_sjx.php\');"/>';
      tws_print_synchro_token();  // synchro token
      echo "</form>\n";
   }
?>
</body>
</html>
