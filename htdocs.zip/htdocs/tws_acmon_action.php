<?php
//   HORIZONT Software GmbH, Munich
//

   require_once("tws_functions.php");
   tws_import_request_variables("P","rqst_");

   $action=$rqst_action;
   $selection=tws_gpc_get($rqst_selection, 'tws_name');
   $arg = tws_gpc_get($_POST['arg'], "tws_filter");
   $object='acmon';

   if ($action == 'Display Event Rule' && count($selection) == 0) {
      tws_doctype("t");
      echo "<html><body><head>".tws_stylesheet(true)."</head>";
      tws_warning("No objects selected!");
      tws_dyer ();
   }

   switch ($action) {
     case "Filter":
       include("tws_acmon_filter.php");
       break;
     case "Save Filter":
       $location = "tws_save_filter.php?object=acmon";
       if(!empty($arg)) $location .="&arg=$arg";
       header("Location: $location");
       exit;
     case "Display Event Rule":
       $evrule=$selection;
       $srcref='tws_acmonx.php';
       include("tws_display_evrule.php");
       break;
     case 'Layout':
         $section = 'Action Runs Monitor';
         include 'tws_layout.php';
         break;
     default :
         include("tws_acmonx.php");
         break;
   }
?>
