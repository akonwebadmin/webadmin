<?php

require_once ("tws_functions.php");

//	var_dump(SQLite3::version());

$db_fname = $tws_config['webadmin_tmp_dir'].'/zli.db';

$dbh = zli_create_sqlitedb($db_fname);

zli_get_jobstream_data();
/*
$dbh = new SQLite3($db_fname);

 $sql="CREATE TABLE msages(
     id INTEGER PRIMARY KEY,
     fname TEXT,
     email TEXT,
     msage TEXT,
     datetime INTEGER)";

 if($dbh->exec($sql))
	echo "Query successful";
 else 
    echo "Query failed";
*/
/*
 // GET TABLE COLUMNS
 
	$tablesquery = $dbh->query("PRAGMA table_info('js')");
	if(!$tablesquery) die("tablesquery failed");
	// var_dump($tablesquery);
	while ($table = $tablesquery->fetchArray(SQLITE3_ASSOC)) 
        echo $table['name'] . '<br />';
	var_dump($table);
	 
	$dbh->close();
	unlink($db_fname);
*/
/*
$db = zli_create_sqlitedb();



$tablesquery = $db->query("PRAGMA table_info('js');");

$table = $tablesquery->fetchArray();
*/
        //echo $table['name'] . '<br />';
//} 
//var_dump($tablesquery);



	
function zli_create_sqlitedb($db_fname){
	global $tws_config;
	
//	if(!file_exists("mydb.db")){
		$dbh = new SQLite3($db_fname);
		if(!$dbh) die("new SQLite3($db_fname) failed");

		$sql="CREATE TABLE IF NOT EXISTS js(
			id INTEGER PRIMARY KEY,
			WORKSTATION TEXT,
            JOBSTREAM TEXT,
            VALID_FROM TEXT,
            DESCRIPTION TEXT,
            ON_REQUEST TEXT,
            AT TEXT,
            TIME_DEPENDENT TEXT,
            UNTIL TEXT,
            ONUNTIL TEXT,
            DEADLINE TEXT,
            TIMEZONE TEXT,
            PRIORITY TEXT,
            CARRYFORWARD TEXT,
            MONITORED TEXT,
            DRAFT TEXT
				)";
// LIMIT field make a problem
		 if($dbh->exec($sql))
			echo "Query successful";
		 else 
		    die("Query failed");
	 return $dbh;
}

function zli_get_jobstream_data($ws='@', $js='@'){

   // get generic data
	$res = zli_get_js_generic_data($ws, $js);
   if(!$res)
      die("zli_get_js_generic_data failed");
	// zli_insert_res($res);
	
   // get_js_deps
	//run_js_deps_query();
	// get_js_jobs
	//run_js_jobs_query();
   // get_jobs_deps
	//run_jobs_deps_query();
}


function zli_run_query($query, $dbname){
	global $tws_config, $composer_db;	
	
   $dbh = db_connect($composer_db);
   if(!$dbh ){
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
	$schema = $composer_db['schema'];
	
   if( !db_query($composer_db, $query) ){
      tws_error('Error: Database query failed');
      return FALSE;
   }
	
	while ($row = db_fetch_row($composer_db)) {
		var_dump($row);
	}
}


function zli_get_js_generic_data(){
	
	$query = zli_get_js_generic_query();
	zli_run_query($query, 'js');
	
}

function zli_get_js_generic_query($ws='@', $js='@'){
   global $composer_db;
   $schema = $composer_db['schema'];
         $query = "
         SELECT
            WKC.WKC_NAME WORKSTATION,
            AJS.AJS_NAME JOBSTREAM,
            JST.JST_VALID_FROM VALID_FROM,
            JST.JST_DESCRIPTION DESCRIPTION,
            JST.JST_ON_REQUEST ON_REQUEST,
            JST.JST_START_OFFSET AT,
            JST.JST_LATEST_START_OFFSET UNTIL,
            JST.JST_LATEST_START_ACTION ONUNTIL,
            JST.JST_DEADLINE_OFFSET DEADLINE,
            JST.JST_TIMEZONE_ID TIMEZONE,
            JST.JST_PRIORITY PRIORITY,
            JST.JST_LIMIT LIMIT,
            JST.JST_CARRY_FORWARD CARRYFORWARD,
            JST.JST_MONITORED MONITORED,
            JST.JST_DRAFT DRAFT,
         FROM (($schema.JST_JOB_STREAMS JST
            JOIN $schema.AJS_ABSTRACT_JOB_STREAMS AJS
            ON AJS.AJS_ID = JST.AJS_ID)
            JOIN $schema.WKC_WORKSTATION_CLASSES WKC
            ON WKC.WKC_ID = AJS.WKC_ID)
         WHERE
            WKC_NAME ".tws_sqllike(db_string($composer_db, $ws))." AND
            AJS_NAME = ".tws_sqllike(db_string($composer_db, $js));
            
	return $query;
}

?>

