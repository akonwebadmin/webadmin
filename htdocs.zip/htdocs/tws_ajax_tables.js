

$(window).resize(tws_datatable_resize);


// redefine sorting functions for Date datetype

// Detect Date datetype
jQuery.fn.dataTableExt.aTypes.unshift(
   function (itm){
      if(!itm) return null;
      if(tws_dateformat_def != 'Y/m/d' && tws_dateformat_def != 'Y-m-d'){
         if (itm.match(/^\d\d[\/-]\d\d[\/-]\d\d\d\d \d\d:\d\d/)) return 'datetime';
         else if (itm.match(/^\d\d[\/\-]\d\d \d\d:\d\d/)) return 'datetime';
         else if (itm.match(/^\d\d[\/-]\d\d[\/-]\d\d\d\d/))  return 'date';
         else if (itm.match(/^\d\d[\/-]\d\d[\/-]\d\d/)) return 'date';
         else if (itm.match(/datetime/)) return 'datetime';    // empty field in DB jobs last run column
      }
      return null;   // default datatipe
   }
);

/* ---   SORTING DATE/TIME COLUMNS   --- */
jQuery.fn.dataTableExt.oSort['date-pre'] = function(x) {
   if(tws_dateformat_def == 'd/m/Y' || tws_dateformat_def == 'd-m-Y')
      x = x.substr(6,4)+x.substr(3,2)+x.substr(0,2);
   else if(tws_dateformat_def == 'm/d/Y' || tws_dateformat_def == 'm-d-Y')
      x = x.substr(6,4)+x.substr(0,2)+x.substr(3,2);
   return x;
};

jQuery.fn.dataTableExt.oSort['datetime-pre'] = function(x) {

   if (x.match(/^\d\d[\/-]\d\d \d\d:\d\d/)){     // dd/mm hh:mm
      if(tws_dateformat_def == 'd/m/Y' || tws_dateformat_def == 'd-m-Y')
         x = x.substr(3,2)+x.substr(0,2)+x.substr(6,5);
      else if(tws_dateformat_def == 'm/d/Y' || tws_dateformat_def != 'm-d-Y')
         x = x.substr(0,2)+x.substr(3,2)+x.substr(6,5);
   }
   else if (x.match(/^\d\d[\/-]\d\d[\/-]\d\d\d\d \d\d:\d\d/)){  // dd/mm/yyyy hh:mm
      if(tws_dateformat_def == 'd/m/Y' || tws_dateformat_def == 'd-m-Y')
         x = x.substr(6,4)+x.substr(3,2)+x.substr(0,2)+x.substr(11,5);
      else if(tws_dateformat_def == 'm/d/Y' || tws_dateformat_def != 'm-d-Y')
         x = x.substr(6,4)+x.substr(0,2)+x.substr(3,2)+x.substr(11,5);
   }
   else if(x.match(/datetime/))     // empty field in DB jobs last run column
      return '';

   return x;
};
// -----------------------------------------------------------


$(document).ready(function() {
   if(tws_table_type =='standard' || $('table.dtable').length==0 )
      return;
   // to avoid repeated initialization (e.g. in database section, modal dialog call)

   if(typeof(tws_page_size)=='undefined')
      tws_page_size = 100; // default, can't happens
   var paging = true;
   if (tws_page_size == 0)
      paging = false;

   var winh = document.documentElement.clientHeight;
   var newh = winh-$('table#__head__').height()-125;
   if($('div#__detail_info__').css('display') != 'none')
      newh  = newh  - $('div#__detail_info__').height();

   oTable.fnCreateFilterColumnSelector();

   tws_datatable_resize();

   // Color for selected String in table
   $('table.dtable tr').on('click', function() {
      $('table.dtable tr').removeClass('trSelected');
      $(this).addClass('trSelected');
      $('table.dtable tr.header').removeClass('trSelected');
   });

   // bind search fild to our functions
   $('input[type="search"]').unbind();
   $('input[type="search"]').bind('keyup.DT search.DT input.DT paste.DT cut.DT', function() {
      var val = this.value;
      var column = $('select.dataTables_filterColumnSelect').val();
      var oSettings = oTable.fnSettings();
         oSettings.oPreviousSearch.sSearch = val;
         if(column == 'all')
            oTable.fnFilter(val);
         else
            oTable.fnFilter(val, column);
      // oTable.columns.adjust().draw();
   });

   $('input[type="search"]').bind('keypress.DT', function(e) {
		// Enter key
		if ( e.keyCode == 13 ) // ignore Enter in search field in flexytables
         return false;
	} )
   // enable_action_buttons
   $('table.dtable').on( 'draw.dt', function () {
       $('input:checkbox').on("click", enable_action_buttons);
   } );

   // get script name
   pos = window.location.pathname.indexOf('.php');
   script = window.location.pathname.substring(1, pos);
   // save search on change
   if(typeof(window.sessionStorage) != "undefined"){
      search_name = script+'_search';
      $('input[type="search"]').on('change',function () {
       window.sessionStorage[search_name] = $('input[type="search"]').val();
      } );
      $('select.dataTables_filterColumnSelect').on('change',function () {
       column = $('select.dataTables_filterColumnSelect').val();
       window.sessionStorage[search_name+'_column'] = column;
      } );
   }
   // set search
   if(typeof(window.clear_search) == 'boolean' && window.clear_search == false){
      search = window.sessionStorage[search_name];
      column = window.sessionStorage[search_name+'_column'];
      // alert("'"+search+"'");
      if(search && column){
         if(column == 'all')
            oTable.fnFilter(search);
         else{
            var oSettings = oTable.fnSettings();
            oSettings.oPreviousSearch.sSearch = search;
            oTable.fnFilter(search, column);
            $('select.dataTables_filterColumnSelect').val(column);
         }
      }
   }
   else{
      window.sessionStorage[search_name] = '';
      window.sessionStorage[search_name+'_column'] = 'all';
   }

   // save current page
   if(typeof(window.sessionStorage) != "undefined"){
      $('table.dtable').on( 'page.dt', function () {
         var page = oTable.api().page();
         window.sessionStorage[script+'_page'] = page;
      } );
   // save current page_size
      $('select[name="sortable_length"]').on('change',function () {
         page_size = $('select[name="sortable_length"]').val();
         if( page_size == '-1')
            page_size = 0;
         window.sessionStorage[script+'_page_size'] = page_size;
      } );
   }

});

function tws_datatable_resize(evt){
   if(tws_table_type =='standard' || $('table.dtable').length==0 || $('#show').parents('.ui-dialog').is(':visible'))
      return;

   var winh = document.documentElement.clientHeight;
   var headh = $('div.dataTables_scrollHead').height();
   var newh = winh-$('table#__head__').height() - headh -105;
   var mywidth = $('tr.header').width();

   if($('div#__detail_info__').css('display') != 'none')
      newh  = newh  - $('div#__detail_info__').height();

   $('div.dataTables_scrollBody').height(newh);
}


   function fnResetAllFilters() {
      //var oTable = $('table.dtable').dataTable(); use global var
      var oSettings = oTable.fnSettings();
      for(iCol = 0; iCol < oSettings.aoPreSearchCols.length; iCol++) {
         oSettings.aoPreSearchCols[ iCol ].sSearch = '';
      }
      oTable.fnDraw();
   }


// create select element for search by columns
(function ($, window, document) {
   $.fn.dataTableExt.oApi.fnCreateFilterColumnSelector = function (oSettings) {
      var filterColumnSelectElement;
      $(oSettings.aanFeatures.f).each(function (index, filterDiv) {
         filterDiv = $(filterDiv);
         // see if we have a select here or not yet
         if (filterDiv.find(".dataTables_filterColumnSelect").length == 0) {
            if (filterColumnSelectElement === undefined) {
               // Create select element
               filterColumnSelectElement = $("<select></select>").addClass("dataTables_filterColumnSelect").css({ width: "120px", marginLeft: "10px" });
               $("<option>*all</option>").val("all").appendTo(filterColumnSelectElement);
               $(oSettings.aoColumns).each(function (index, column) {
                  if (column.bSearchable && column.sTitle!='' && column.sTitle!='&nbsp;'){
                     title = column.sTitle.replace(/\n/g, "");
                     title = title.replace(/&nbsp;/g, " ");
                     $("<option></option>").text(title).val(index).appendTo(filterColumnSelectElement);
                  }
               });
                // bind change event to select

               filterColumnSelectElement.change(function () {
                  fnResetAllFilters();
                  $('input[type="search"]').trigger("keyup.DT");
               });
            }
            // append a clone of our select element
            filterDiv.append(filterColumnSelectElement.clone(true));
            // filterDiv.append("<input type='button' value='->' onclick='fnSearchFilter()'>");
         }
      });
   }
})(jQuery, window, document);
