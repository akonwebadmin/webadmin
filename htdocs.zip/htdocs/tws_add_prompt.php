<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
   // Cancel button test
   $tmp_test = (isset($_POST['action']) && $_POST['action'] == 'Return to Modification') ? true : false;
   if ($tmp_test == true) {
      foreach ($_POST as $key => $val){
         $$key = tws_gpc_get($val);
      }
      tws_adjust4html($prompt_name);
      tws_adjust4html($prompt_text);
   }
?>
<html>
<head>
<?php tws_stylesheet();
   if ($copy == "yes") $h1 = "Copy Prompt";
   elseif($modify == "yes") $h1 = "Modify Prompt";
   else $h1 = "Add Prompt";
?>
<title><?=$h1 ?></title>
<script type="text/javascript">
function ConfirmCancel(objectname,url){
   $('form').unbind('submit');
   var conftext=confirm("Exit " + objectname + " Definition (Changes will be lost) ?");
   if (conftext) {
      if (url==null) return true;
         closeme(url);
   } else {
      return false;
   }
}
</script>
</head>
<body>
<?php tws_set_window_title();

$log_file_name=tws_log('', 'OPEN');

tws_print_head($h1, array('__log__' => $log_file_name));

   if ($tmp_test == false && ($copy == "yes" || $modify == "yes")) {

      $num_elements=count($selection);

      if ($num_elements == 0)
         tws_dyer("No prompt selected");
      elseif ($num_elements > 1)
         tws_dyer("Multiple prompts selected. Only one prompt can be ".($copy=="yes" ? 'copied' : 'modified')." at a time");

      if (($db_prompt=tws_get_prompts($selection[0]))===FALSE)
         tws_dyer("Unable to list prompts");

      if ($db_prompt['prompt_num'] != 1)
         tws_dyer("Database query failed: prompt_num != 1");

      tws_adjust4html($db_prompt);

      $prompt_name=$db_prompt['prompt_name'][0];
      $prompt_text=$db_prompt['prompt_text'][0];
      $prompt_folder = '';
      if(!empty($db_prompt['prompt_folder'][0]))
         $prompt_folder = $db_prompt['prompt_folder'][0];

      if ($modify=="yes") {
// lock object
         tws_composer_lock("prom=$selection[0]") or tws_dyer("Unable to lock prompt '$prompt_name'");
// backup
         if (($original_data=tws_composer_create_from("prom=$selection[0]"))===FALSE) tws_dyer("Unable to create backup");
      }
      $arr = tws_dbobject_to_array('prompt', $selection[0]);
      tws_log(" -- tws_add_prompt arr:". var_export($arr, true));
   }
?>

<br><br>
<form method=post name="contents" action="tws_add_prompt_exec.php" onsubmit="if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Prompt',null)) { cancel_button_pressed=false; return false;}">
<? // show prompt form
   tws_arr_to_form('prompt', $action, $arr);

   echo "<br><br>";

   if ($modify == "yes") {
      echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
      echo "<input type=\"hidden\" name=\"prompt_name\" value=\"$prompt_name\">\n";
      echo "<input type=\"hidden\" name=\"original_data\" value=\"".htmlspecialchars($original_data)."\">\n";
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' name='action' value='Update' onClick='tws_waiting(1); return tws_validate_form()'/>\n";
   } else {
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Add\" onClick=\"return tws_validate_form()\"/>\n";
   }

   if ($modify=="yes") {
       if (tws_zli_module_check () && isset ($netmodule_file))
           echo "<input type=\"hidden\" name=\"netmodule_file\" value=\"$netmodule_file\">\n";
       else
           echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Cancel\" onClick=\"cancel_button_pressed=true;\"/>\n";
   }
   else
       echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"button\" value=\"Cancel\" onClick=\"ConfirmCancel('Prompt','tws_promptsx.php')\"/>\n";

   tws_print_synchro_token();   // synchro_token
?>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" value="Print" onClick="window.print()">
</form>
</body>
</html>
