<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   require_once 'tws_rc_flt.php';
   tws_doctype('t');
?>
<html>
<head>
<title>Clearing <?=$flt_obj_title[$object]?> Filter</title>
<? tws_stylesheet();

if(isset($_GET['reset'])){ // from action menu
   require_once 'tws_filters_lib.php';
   $script = basename($flt_redir_to[$object], '.php');
   $_GET['arg']='';
   tws_save_filter_in_storage($script);
   echo "<script> window.location.replace('tws_run.php?run=$script')</script>";
   exit;
}
?>
</head>
<body onLoad="window.location.replace('<?=$flt_redir_to[$object]."?arg=$arg"?>')">
</body>
</html>
