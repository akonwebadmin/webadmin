<?php
//   HORIZONT Software GmbH, Munich
//
//    TODO: Info Package output format needed

   require_once 'tws_functions.php';

   tws_import_request_variables("P","rqst_");

   $formname=isset($rqst_formname) ? trim($rqst_formname) : 'contents';
   $job_type = isset($rqst_job_type) ? $rqst_job_type : 'std';
   $cpux = isset($rqst_cpux) ? $rqst_cpux : '*';
   if(trim($cpux) == '' ) $cpux = '*';
   @$fieldname=$rqst_fieldname;
   @$fieldvalue=$rqst_fieldvalue;
   $display="yes";
   @$jobid_field=$rqst_jobid_field;
   @$jobuser_field=$rqst_jobuser_field;

   if ((strpos($fieldname,"[") !== FALSE) && (strpos($fieldname,"]") !== FALSE))
      $jsfieldname="elements['" . $fieldname . "']";
   else
      $jsfieldname = $fieldname;

   if ($fieldvalue=='') {
      $arg='*';
   } else {
      if ((strpos($fieldvalue,'*')===FALSE) && (strpos($fieldvalue,'@')===FALSE)) {
         $arg=$fieldvalue.'*';
      } elseif (strpos($fieldvalue,'@')!==FALSE) {
         $arg=strtr($fieldvalue,'@','*');
      } else {
         $arg=$fieldvalue;
      }
   }
?>

<script type="text/javascript">

function sendValue(formsel) {
   var selectionval = "";
   if (formsel && formsel.selectedIndex>=0) {
      for (var i = 0; i < formsel.options.length; i++){
         if (formsel.options[i].selected)
            selectionval = selectionval + formsel.options[i].value + ",";
      }
      i = formsel.selectedIndex;
      <?php if($job_type == 'std'): ?>
         var jobid = window.document.job_list.elements["job_id["+i+"]"].value;
         var joblogin = window.document.job_list.elements["job_login["+i+"]"].value;
         window.document.<?=$formname?>.<?=$jsfieldname?>.value = selectionval.substr(0, selectionval.length - 1);
         window.document.<?=$formname?>.<?=$jobid_field?>.value = jobid;
         window.document.<?=$formname?>.<?=$jobuser_field?>.value = joblogin;
      <?php else: ?>
      <?php //if ($job_type=='bwpc'): ?>
         var tech_name = window.document.job_list.elements["job_tech_name["+i+"]"].value;
         window.document.<?=$formname?>.<?=$jsfieldname?>.value = tech_name;
      <?php endif; ?>
   }
   $('[name="<?=$fieldname?>"]').keyup();
   $( "#sapjob_picker" ).dialog( "close" );
}
</script>

<div id="sapjob_picker">
<h1>Select Job</h1>
<br>
<form name="job_list">
<?php
   $result=tws_get_sapjobs($job_type, $cpux, $arg);

   if ($result===FALSE || $result['job_num']==0) {
      if ($result===FALSE)
         echo '<center><p class="warning">Unable to get SAP job list</p>';
      else {
         if($result['err']!='')
            echo '<p class="warning">'.$result['err'].'</p>';
         else
            echo '<center><p class="warning">No jobs matching ',htmlspecialchars($arg),'.</p>';
      }
      echo '<input type="button" value="OK" onClick="sendValue(null);"></center>';
   }
   else {
      echo '<select id="sel" name="selection" class="picker" size="14" onDblClick="sendValue(this.form.selection);">',"\n";
         for($i=0; $i<$result['job_num']; $i++) {
            echo '<option value="'.$result['job_name'][$i].'">'.$result['job_name'][$i].'</option>',"\n";
         }
      echo "</select><br>\n";
      if($job_type=='std'){
         for($i=0; $i<$result['job_num']; $i++) {
            echo '<input type="hidden" name="job_id['.$i.']" value="'.$result['job_id'][$i].'"/>',"\n";
            echo '<input type="hidden" name="job_login['.$i.']" value="'.$result['job_login'][$i].'"/>',"<br>\n";
         }
      }
      elseif($job_type=='bwpc' || $job_type=='bwip') {
         for($i=0; $i<$result['job_num']; $i++) {
            echo '<input type="hidden" name="job_tech_name['.$i.']" value="'.$result['job_tech_name'][$i].'"/>',"<br>\n";
         }
      }
      echo '<br><br>';
      echo '<center><input type="button" value="OK" onClick="sendValue(this.form.selection);"></center>';
   }
?>
</form>
</div>

<script type="text/javascript">
$(function() {
   tws_picker_constructor("sapjob_picker");
});
</script>
<?php
//       TWS_GET_SAPJOBS FUNCTIONS

function tws_get_sapjobs ($job_type, $cpux, $arg) {
   global $tws_config;

   if ($tws_config['host_os'] == "win32" )
      $method=$tws_config['maestro_dir']."/methods/r3batch.exe";
   else
      $method=$tws_config['maestro_dir']."/methods/r3batch";

   $res = array();
   $res['err'] = '';

   // if r3batch exist on MDM:
   if(file_exists($method))
      $res = tws_get_sapjobs_from_mdm($job_type, $cpux, $arg);
   else
      $res = tws_get_sapjobs_from_fta($job_type, $cpux, $arg);

   return $res;
}

//       GET SAPJOBS FROM MDM

function tws_get_sapjobs_from_mdm($job_type, $cpux, $arg) {
   global $tws_config;
   $webadmin_user_home_dir = $tws_config['webadmin_user_home_dir'];

   if ($tws_config['host_os'] == "win32" )
      $method=$tws_config['maestro_dir']."/methods/r3batch.exe";
   else
      $method=$tws_config['maestro_dir']."/methods/r3batch";

   $job_num=0;

   if ($job_type=='std') { // Standard SAP Job
      $command=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), $method, '-t', 'PL', '-c', $cpux, '-l', '*', '-j', $arg);
      $stdout=array();
      if (tws_popen($command, $ec, $stdout, $stdout, 'Y')===FALSE) {
         tws_err("Unable to get SAP job list. Fail to run r3batch.", array('command'=>$command->compile('log'), 'stdout'=>$stdout) );
         return FALSE;
      }
      foreach ($stdout as $buff) {
         if (preg_match('/^%error/', $buff) ) {
            $res['err'] .= trim($buff).'<br>';
         }
         if (preg_match('/^%job/', $buff)) {
            $job_name = trim(substr($buff,6,32));
            if(!tws_jokercmp($job_name, $arg))
               continue;
            $res['job_name'][$job_num] = $job_name;
            $res['job_login'][$job_num] = trim(substr($buff,40,12));
            $res['job_id'][$job_num] = trim(substr($buff,52,9));
            $job_num++;
         }
      }
      $res['job_num'] = $job_num;
      return $res;
   }

   // Create configuration file if not exist
   $infile = "$webadmin_user_home_dir/".$_SERVER['PHP_AUTH_USER'].'/'."r3_$cpux.txt";
   if (!file_exists($infile)) {
      if (($fp=fopen($infile,'w'))!==FALSE) {
         $newline=$tws_config['host_os']!='win32' ? "\n" : "\r\n";
         if (fwrite($fp,"%mrc 0003000884.00.00".$newline."%logoninfo ".$_SERVER['PHP_AUTH_USER'].$newline) >0 ) {
            fclose($fp);
            tws_chmod($infile, 0655);
         }
         else {
            fclose($fp);
            tws_err("Unable to write configuration file '$infile'");
            return FALSE;
         }
      }
      else {
         tws_err("Unable to create configuration file '$infile'");
         return FALSE;
      }
   }

   // Info Package
   if ($job_type=='bwip') {
      // Command:
      // /opt/tws/tws86/IWS/methods/r3batch -t GI -c PC13SAP -j DMYJOB -l * -- "-t PL -infopackage" < $infile
      // Output:
      // ?????

      $command=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), $method, '-t', 'GI', '-c', $cpux, '-j', 'DMYJOB', '-l', '*', '--', "-t PL -infopackage", hwi_cmd::operator("<\"$infile\"",FALSE));
      $stdout=array();
      if (tws_popen($command, $ec, $stdout, $stdout)===FALSE) {
         tws_err("Unable to get SAP job list. Fail to run r3batch.", array('command'=>$command->compile('log'), 'stdout'=>$stdout));
         return FALSE;
      }
      foreach ($stdout as $buff) {
         if (preg_match('/^%error/', $buff) )
            $res['err'] .= trim($buff).'<br>';

         if (preg_match('/^%infopackage/', $buff)) {
            //    TODO: Info Package output format needed
            $job_tech_name = trim(substr($buff,13,24));
            $job_name = trim(substr($buff,52,56));
            if(tws_jokercmp($job_tech_name, $arg) || tws_jokercmp($job_name, $arg) ){
               $res['job_tech_name'][$job_num] = $job_tech_name;
               $res['job_name'][$job_num] = $job_name.' / '. $job_tech_name;
               $job_num++;
            }
         }
      }
      $res['job_num'] = $job_num;
      return $res;
   }

   // PChain
   if ($job_type=='bwpc') {
      // Command:
      // /opt/tws/tws86/IWS/methods/r3batch -t "GI" -c "PC13SAP" -j "DMYJOB" -l "*" -- "-t PL -pchain" < $infile
      // Output:
      // %pchain 0025TWS_TEST1234             0007pchain_0060test for IWS                                                0002DE0001M

      $command=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), $method, '-t', 'GI', '-c', $cpux, '-j', 'DMYJOB', '-l', '*', '--', "-t PL -pchain", hwi_cmd::operator("<\"$infile\"",FALSE));
      $stdout=array();
      if (tws_popen($command, $ec, $stdout, $stdout)===FALSE) {
         tws_err("Unable to get SAP job list. Fail to run r3batch.", array('command'=>$command->compile('log'), 'stdout'=>$stdout));
         return FALSE;
      }
      foreach ($stdout as $buff) {
         if (preg_match('/^%error/', $buff) )
            $res['err'] .= trim($buff).'<br>';

         if (preg_match('/^%pchain/', $buff)) {
            $job_tech_name = trim(substr($buff,12,24));
            $job_name = trim(substr($buff,52,56));
            if ( tws_jokercmp($job_tech_name, $arg) || tws_jokercmp($job_name, $arg) ) {
               $res['job_tech_name'][$job_num] = $job_tech_name;
               $res['job_name'][$job_num] = $job_name.' / '. $job_tech_name;
               $job_num++;
            }
         }
      }
      $res['job_num'] = $job_num;
      return $res;
   }
   return FALSE;
}

//       GET SAPJOBS FROM FTA
//
//    get sap job list from webadmin service job
//       $cpux_host#WEBADMIN_SYNC.WA_$cpux_XX

function tws_get_sapjobs_from_fta($job_type, $cpux, $arg){
   global $tws_config, $composer_db;

   if ($cpux == '*'){
      tws_err("Workstation not selected");
      return FALSE;
   }
   // get $cpux host
   if (($ws = tws_get_workstation_data($cpux))===false){
      tws_err("Unable to get '$cpux' workstation data");
      return FALSE;
   }
   if( empty($ws) || empty($ws['host']) ) {
      tws_err("Unable to get '$cpux' host");
      return FALSE;
   }
   $host = $ws['host'];

   if ($job_type=='std') {
      $joblist_job = 'WA_'.$cpux.'_ST';
      $find = '%job';
   }
   elseif ($job_type=='bwip'){
      $joblist_job = 'WA_'.$cpux.'_IP';
      $find = '%infopackage';

   }
   elseif ($job_type=='bwpc'){
      $joblist_job = 'WA_'.$cpux.'_PC';
      $find = '%pchain';
   }

      // TODO get last_run
      if( ($service_jobs = tws_get_jobs($host, $joblist_job)) === false || $service_jobs['job_num'] != 1) {
         tws_err("Unable to get job '$host#$joblist_job' data");
         return FALSE;
      }
      $job_last_run = $service_jobs['job_last_run'][0];
      echo "last run: ". tws_iso_to_userdate($job_last_run, null, FALSE, $composer_db['tz'], true);

   // find latest service job
   $service_jobs = tws_get_plan_job_list("$host#WEBADMIN_SYNC.$joblist_job+state=succ");
   if($service_jobs['njobs'] == 0){
      tws_err("Can't find job '$host#WEBADMIN_SYNC.$joblist_job' in success state");
      return FALSE;
   }
   if($service_jobs['njobs'] == 1){
      $jobarg = "$host#WEBADMIN_SYNC.$joblist_job;stdlist";
   }
   else {
      // find max jobnum (TODO ??)
      $jobnum = max($service_jobs['jobnum']);
      $jobarg = "$host#$jobnum;stdlist;single";
   }

   // Get stdlist
   $stdout=array();
   $command=new hwi_cmd(tws_sudo(''), $tws_config['maestro_dir']."/bin/conman", $tws_config['conman_args'], "-gui", "sj $jobarg", hwi_cmd::operator('2>&1',FALSE));
   if( tws_popen($command, $ec, $stdout, $stdout) === false ){
      tws_err("Unable to get $jobarg", array('command'=>$command->compile('log'), 'stdout'=>$stdout) );
      return FALSE;
   }
   $job_num=0;
   foreach ($stdout as $buff) {
      if (substr($buff,0,2) !== '^d')
         continue;
      else
         $buff=substr($buff,2);

      if (preg_match('/^%error/', $buff) )
         $res['err'] .= trim($buff).'<br>';

      if (preg_match("/^$find/", $buff)) {
         switch ($job_type) {
            case 'std':
               $jobname = trim(substr($buff,6,32));
               if (!tws_jokercmp($jobname, $arg))
                  continue;
               $res['job_name'][$job_num] = $jobname;
               $res['job_login'][$job_num] = trim(substr($buff,40,12));
               $res['job_id'][$job_num] = trim(substr($buff,52,9));
               $job_num++;
               break;
            case 'bwip':
               //    TODO: Info Package output format needed
               $job_name = trim(substr($buff,52,56));
               $job_tech_name = trim(substr($buff,13,24));
               if (tws_jokercmp($job_tech_name, $arg) || tws_jokercmp($job_name, $arg) ){
                  $res['job_tech_name'][$job_num] = $job_tech_name;
                  $res['job_name'][$job_num] = $job_name.' / '. $job_tech_name;
                  $job_num++;
               }
               break;
            case 'bwpc':
               $job_name = trim(substr($buff,52,56));
               $job_tech_name = trim(substr($buff,12,24));
               if (tws_jokercmp($job_tech_name, $arg) || tws_jokercmp($job_name, $arg) ){
                  $res['job_tech_name'][$job_num] = trim(substr($buff,12,24));
                  $res['job_name'][$job_num] = $job_name .' / '. $job_tech_name ;
                  $job_num++;
               }
               break;
         }
      }
   }
   $res['job_num'] = $job_num;

   return $res;
}

?>
