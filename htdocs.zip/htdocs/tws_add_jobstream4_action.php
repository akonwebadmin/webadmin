<?php
//   HORIZONT Software GmbH, Munich
//

   require_once("tws_functions.php");

   tws_import_request_variables("P","rqst_");

   switch ($rqst_action) {
     case "Return to Jobstream Modification":
       include("tws_add_jobstream.php");
       break;
     case "Preview Jobstream":
     case "Save Jobstream":
     case "Update":
     case "Replace":
       include("tws_add_jobstream_exec.php");
       break;
      /*
     case "Save Draft":
       include("tws_save_jobstream_draft.php");
       break;
       */
     case "Cancel" :
         // TODO: stylesheet. otherwise javascript error on $document.ready: "uncnown $"
      if ($rqst_modify=="yes") {
         if(!empty($rqst_jobstream_folder))
            $rqst_jobstream = $rqst_jobstream_folder.$rqst_jobstream;
         tws_composer_unlock("js=$rqst_workstation#$rqst_jobstream") or tws_dyer("Unable to unlock jobstream '$rqst_workstation#$rqst_jobstream'.");
      }
      echo "<script type='text/javascript' src='tws_js_functions.js'></script>
         <script type='text/javascript'>
         closeme('tws_jobstreamsx.php');
         </script>";
      break;
   }
?>