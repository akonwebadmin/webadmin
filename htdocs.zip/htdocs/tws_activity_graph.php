<?php
//   HORIZONT Software GmbH, Munich
//

   require_once("tws_functions.php");

   if (!isset($store_report) || $store_report!="yes"){
      tws_import_request_variables("GP","rqst_");
      $scale=$rqst_scale;
      $style=$rqst_style;
      $contents=$rqst_contents;
      $color=$rqst_color;
      $shadows=$rqst_shadows;
      $workstation=$rqst_workstation;
      $reruns=$rqst_reruns;
      $everys=$rqst_everys;
      $labels=$rqst_labels;
      $startdate=$rqst_startdate;
      $enddate=$rqst_enddate;
      $filename=tws_gpc_get($rqst_filename);

// link the database
      db_connect($webadmin_db,DB_PERSISTENT) or tws_dyer("Cannot connect to database");
      $schema = $webadmin_db['schema'];
   }

   require_once("jpgraph/jpgraph.php");
   if ($style == "bar" || $style == "multibar" || $style == "accbar") {
      require_once("jpgraph/jpgraph_bar.php");
   } elseif ($style == "line" || $style == "multiline" || $style == "accline") {
      require_once("jpgraph/jpgraph_line.php");
   }

   if ($scale == "day") {
// Begin day processing

// Get Start of Day time
      $globalopts = tws_get_globalopts();
      if(isset($globalopts['start']) && is_numeric($globalopts['start']))
         $start_of_day = $globalopts['start'];
      else tws_dyer("Start of day not defined");
      $start_hour=floor($start_of_day / 100);
      $start_minute=$start_of_day % 100;
      $chart_start=mktime($start_hour,$start_minute,0,substr($startdate,5,2),substr($startdate,8,2),substr($startdate,0,4));
      $start_of_day = $startdate ." ". sprintf("%02d",$start_hour).":".sprintf("%02d",$start_minute).":00.000000";
      
// Main database querying
      $succ_count[$startdate]=$abend_count[$startdate]=$pend_count[$startdate]=$exec_count[$startdate]=$hold_count[$startdate]=$other_count[$startdate]=0;

      $query="SELECT status,start_time,run_time 
         FROM $schema.jobhist
         WHERE sched_date='".db_string($webadmin_db,$startdate)." 00:00:00'";
      if ($workstation != "*") {
         if (strpos($workstation,",") !== FALSE) {
            $query .= " AND workstation in ('" . str_replace(",","','", db_string($webadmin_db,$workstation)) . "')";
         } else {
            $query .= " AND workstation like '" . strtr(db_string($webadmin_db,$workstation),"*","%") . "'";
         }
      }
      if ($reruns != "yes") {
         $query .= " AND rerun_flag='NO'";
      }
      if ($everys != "yes") {
         $query .= " AND every_flag='NO'";
      }

      db_query($webadmin_db,$query) or tws_dyer("Database query failed");
      $num_rows=0;
      while ($row=db_fetch_row($webadmin_db)){
         $num_rows++;
         $state=$row['STATUS'];
         $start_time=$row['START_TIME'];
         // All 'HOLD' jobs start at sstart of day (for 'all jobs' option)
         if (empty($start_time))
            $start_time = $start_of_day;
         $run_time=$row['RUN_TIME'];
         if ($start_time != "") {
            $start_timestamp=mktime(substr($start_time,11,2),substr($start_time,14,2),substr($start_time,17,2),substr($start_time,5,2),substr($start_time,8,2),substr($start_time,0,4));
            $finish_timestamp=$start_timestamp + ($run_time * 60);
            $start_slot=floor(($start_timestamp - $chart_start) / 3600);
            $finish_slot=floor(($finish_timestamp - $chart_start) / 3600);
            if ($start_slot > $finish_slot) {
               continue;
            } elseif (($start_slot < 0) && ($finish_slot < 0)) {
               continue;
            } elseif (($start_slot > 23) && ($finish_slot > 23)) {
               continue;
            }
            if ($start_slot < 0) {
               $start_slot=0;
            }
            if ($finish_slot > 23) {
               $finish_slot=23;
            }

            switch ($state) {
              case "SUCC":
              case "SUCCP":
                if ($contents == "completed") {
                   $succ_count[$finish_slot]++;
                } else {
                   for ($j=$start_slot; $j<=$finish_slot; $j++) {
                      $succ_count[$j]++;
                   }
                }
                break;
              case "ABEND":
              case "ABENP":
              case "ERROR":
              case "FAIL":
                if ($contents == "completed") {
                   $abend_count[$finish_slot]++;
                } else {
                   for ($j=$start_slot; $j<=$finish_slot; $j++) {
                      $abend_count[$j]++;
                   }
                }
                break;
              case "PEND":
                if ($contents == "completed") {
                   $pend_count[$finish_slot]++;
                } else {
                   for ($j=$start_slot; $j<=$finish_slot; $j++) {
                      $pend_count[$j]++;
                   }
                }
                break;
              case "HOLD":   
                 if ($contents == "all") 
                    $pend_count[$finish_slot]++;
                break;
            }
         }
      }

// For DAY view, set contents to "completed" now:
      $contents="completed";

      $grand_total=0;
      $counter=0;
      for ($i=0; $i<24; $i++) {
         $datax[$i]=sprintf("%02d:%02d",$start_hour,$start_minute);
         $start_hour++;
         if ($start_hour > 23) {
            $start_hour=0;
         }

         $total_count[$i]=$succ_count[$i] + $abend_count[$i] + $pend_count[$i];
         $grand_total+=$total_count[$i];
         if ($style == "bar" || $style == "line") {
            $datay[$i]=$total_count[$i];
         } else {
            $datay_succ[$i]=$succ_count[$i];
            $datay_abend[$i]=$abend_count[$i];
            $datay_pend[$i]=$pend_count[$i];
         }
      }
   } else {
// Begin week / month / year processing
// Increment enddate by one day for proper handling
      $enddate_orig=$enddate;
      $enddate=date("Y-m-d",93600 + mktime(0,0,0,substr($enddate,5,2),substr($enddate,8,2),substr($enddate,0,4)));

// Main database querying
      for ($i=$startdate; $i!=$enddate; $i=date("Y-m-d",93600 + mktime(0,0,0,substr($i,5,2),substr($i,8,2),substr($i,0,4)))) {
         $succ_count[$i]=$abend_count[$i]=$pend_count[$i]=$exec_count[$i]=$hold_count[$i]=$other_count[$i]=0;
      }

      $query="SELECT sched_date,status,count(status) as count_status FROM $schema.jobhist WHERE sched_date >= '".db_string($webadmin_db,$startdate)." 00:00:00' AND sched_date <= '".db_string($webadmin_db,$enddate_orig)." 00:00:00'";
      if ($workstation != "*") {
         if (strpos($workstation,",") !== FALSE) {
            $query .= " AND workstation in ('" . str_replace(",","','", db_string($webadmin_db,$workstation)) . "')";
         } else {
            $query .= " AND workstation like '" . strtr(db_string($webadmin_db,$workstation),"*","%") . "'";
         }
      }
      if ($reruns != "yes") {
         $query .= " AND rerun_flag='NO'";
      }
      if ($everys != "yes") {
         $query .= " AND every_flag='NO'";
      }
      $query .= " GROUP BY sched_date,status";

      $result=db_query($webadmin_db,$query) or tws_dyer("Database query failed");
      $num_rows=0;
      while ($row=db_fetch_row($webadmin_db)){
         $sched_date=tws_iso_to_userdate($row['SCHED_DATE'],"Y-m-d",TRUE);
         $state=$row['STATUS'];
         $count=$row['COUNT_STATUS'];

         if ($scale == "year") {
            $sched_date=substr($sched_date,0,7);
         }

         switch ($state) {
           case "SUCC":
           case "SUCCP":
             $succ_count[$sched_date]+=$count;
             break;
           case "ABEND":
           case "ABENP":
           case "ERROR":
           case "FAIL":
             $abend_count[$sched_date]+=$count;
             break;
           case "PEND":
             $pend_count[$sched_date]+=$count;
             break;
           case "EXEC":
           case "INTRO":
             if (($contents == "active") || ($contents == "all")) {
                $exec_count[$sched_date]+=$count;
             }
             break;
           case "ADD":
           case "HOLD":
           case "READY":
           case "SCHED":
             if ($contents == "all") {
                $hold_count[$sched_date]+=$count;
             }
             break;
           default:
             if ($contents == "all") {
                $other_count[$sched_date]+=$count;
             }
             break;
         }
      }

      $grand_total=0;
      $counter=0;
      if ($scale == "year") {
         $i=substr($startdate,0,7);
         while ($i != substr($enddate,0,7)) {
            $datax[$counter]="$i";

            $total_count[$i]=$succ_count[$i] + $abend_count[$i] + $pend_count[$i] + $exec_count[$i] + $hold_count[$i] + $other_count[$i];
            $grand_total+=$total_count[$i];
            if ($style == "bar" || $style == "line") {
               $datay[$counter]=$total_count[$i];
            } else {
               $datay_succ[$counter]=$succ_count[$i];
               $datay_abend[$counter]=$abend_count[$i];
               $datay_pend[$counter]=$pend_count[$i];
               $datay_exec[$counter]=$exec_count[$i];
               $datay_hold[$counter]=$hold_count[$i];
               $datay_other[$counter]=$other_count[$i];
            }

            $tmp_year=substr($i,0,4);
            $tmp_month=substr($i,5,2) + 1;
            if (strlen($tmp_month) < 2) {
               $tmp_month = "0" . $tmp_month;
            }
            if ($tmp_month == 13) {
               $tmp_month="01";
               $tmp_year++;
            }
            $i=$tmp_year . "-" . $tmp_month;
            $counter++;
         }
      } else {
         for ($i=$startdate; $i!=$enddate; $i=date("Y-m-d",93600 + mktime(0,0,0,substr($i,5,2),substr($i,8,2),substr($i,0,4)))) {
            $datax[$counter]="$i";
            if ($scale == "week") {
               $datax[$counter]="   " . date("D",mktime(0,0,0,substr($i,5,2),substr($i,8,2),substr($i,0,4))) . "\n" . $datax[$counter];
            }

            $total_count[$i]=$succ_count[$i] + $abend_count[$i] + $pend_count[$i] + $exec_count[$i] + $hold_count[$i] + $other_count[$i];
            $grand_total+=$total_count[$i];
            if ($style == "bar" || $style == "line") {
               $datay[$counter]=$total_count[$i];
            } else {
               $datay_succ[$counter]=$succ_count[$i];
               $datay_abend[$counter]=$abend_count[$i];
               $datay_pend[$counter]=$pend_count[$i];
               $datay_exec[$counter]=$exec_count[$i];
               $datay_hold[$counter]=$hold_count[$i];
               $datay_other[$counter]=$other_count[$i];
            }

            $counter++;
         }
      }
   }

   if (!isset($store_report)){
      db_close($webadmin_db);
   }

   if ($style == "multibar" || $style == "accbar" || $style == "multiline" || $style == "accline") {
      $graph = new Graph(670,400,"auto");
   } else {
      $graph = new Graph(600,400,"auto");
   }
   if ($scale == "day") {
      $graph->title->Set("$startdate");
   } else {
      $graph->title->Set("$startdate - $enddate_orig");
   }
   $graph->title->SetFont(FF_FONT2);
   $graph->SetShadow();
   if ($style == "multibar" || $style == "accbar" || $style == "multiline" || $style == "accline") {
      $graph->img->SetMargin(60,100,40,80);
   } else {
      $graph->img->SetMargin(60,30,40,80);
   }

   if ($color == "green") {
      $color="forestgreen";
   }

   switch($style) {
     case "bar":
       $graph->SetScale("textlin");
       $graph->yaxis->scale->SetGrace(10);
       $graph->xaxis->SetTickLabels($datax);
       if ($scale != "week") {
          $graph->xaxis->SetLabelAngle(90);
       }
       $graph->yaxis->title->Set("Activity (# Jobs)");
       $graph->yaxis->title->SetFont(FF_FONT1,FS_BOLD);

       $p1=new BarPlot($datay);
       $p1->SetFillColor("$color");
       if (($shadows == "yes") && ($color != "black")) {
          $p1->SetShadow();
       }
       if ($labels == "yes") {
          $p1->value->Show();
          $p1->value->SetAngle(90);
          $p1->value->SetFormat('%d');
       }

       if ($scale == "week") {
          $p1->SetWidth(.7);
       }

       $graph->Add($p1);

       if ($grand_total == 0) {
          $txt=new Text("  No Activity Data  ");
          $txt->SetFont(FF_FONT2,FS_BOLD);
          $txt->SetColor("red");
          $txt->SetPos(0.3,0.4,"centered");
          $txt->SetBox("white","black",true);
          $graph->AddText($txt);
       }
       break;

     case "multibar":
       $graph->SetScale("textlin");
       $graph->yaxis->scale->SetGrace(10);
       $graph->xaxis->SetTickLabels($datax);
       if ($scale != "week") {
          $graph->xaxis->SetLabelAngle(90);
       }
       $graph->yaxis->title->Set("Activity (# Jobs)");
       $graph->yaxis->title->SetFont(FF_FONT1,FS_BOLD);

       $p[0]=new BarPlot($datay_succ);
       $p[0]->SetFillColor("forestgreen");
       if ($shadows == "yes") {
          $p[0]->SetShadow();
       }
       if ($labels == "yes") {
          $p[0]->value->Show();
          $p[0]->value->SetAngle(90);
          $p[0]->value->SetFormat('%d');
       }

       $p[0]->SetLegend("Succ");

       $p[1]=new BarPlot($datay_abend);
       $p[1]->SetFillColor("red");
       if ($shadows == "yes") {
          $p[1]->SetShadow();
       }
       if ($labels == "yes") {
          $p[1]->value->Show();
          $p[1]->value->SetAngle(90);
          $p[1]->value->SetFormat('%d');
       }

       $p[1]->SetLegend("Abend");

       $p[2]=new BarPlot($datay_pend);
       $p[2]->SetFillColor("purple");
       if ($shadows == "yes") {
          $p[2]->SetShadow();
       }
       if ($labels == "yes") {
          $p[2]->value->Show();
          $p[2]->value->SetAngle(90);
          $p[2]->value->SetFormat('%d');
       }

       $p[2]->SetLegend("Pend");

       if ($contents == "active" || $contents == "all") {
          $p[3]=new BarPlot($datay_exec);
          $p[3]->SetFillColor("blue");
          if ($shadows == "yes") {
             $p[3]->SetShadow();
          }
          if ($labels == "yes") {
             $p[3]->value->Show();
             $p[3]->value->SetAngle(90);
             $p[3]->value->SetFormat('%d');
          }

          $p[3]->SetLegend("Exec");
       }

       if ($contents == "all") {
          $p[4]=new BarPlot($datay_hold);
          $p[4]->SetFillColor("yellow");
          if ($shadows == "yes") {
             $p[4]->SetShadow();
          }
          if ($labels == "yes") {
             $p[4]->value->Show();
             $p[4]->value->SetAngle(90);
             $p[4]->value->SetFormat('%d');
          }

          $p[4]->SetLegend("Hold");
       }

       if ($contents == "all") {
          $p[5]=new BarPlot($datay_other);
          $p[5]->SetFillColor("gray");
          if ($shadows == "yes") {
             $p[5]->SetShadow();
          }
          if ($labels == "yes") {
             $p[5]->value->Show();
             $p[5]->value->SetAngle(90);
             $p[5]->value->SetFormat('%d');
          }

          $p[5]->SetLegend("Other");
       }

       $p1 = new GroupBarPlot($p);
       $graph->Add($p1);

       $graph->legend->Pos(0.02,0.5,"right","center");

       if ($grand_total == 0) {
          $txt=new Text("  No Activity Data  ");
          $txt->SetFont(FF_FONT2,FS_BOLD);
          $txt->SetColor("red");
          $txt->SetPos(0.3,0.4,"centered");
          $txt->SetBox("white","black",true);
          $graph->AddText($txt);
       }

       break;

     case "accbar":
       $graph->SetScale("textlin");
       $graph->yaxis->scale->SetGrace(10);
       $graph->xaxis->SetTickLabels($datax);
       if ($scale != "week") {
          $graph->xaxis->SetLabelAngle(90);
       }
       $graph->yaxis->title->Set("Activity (# Jobs)");
       $graph->yaxis->title->SetFont(FF_FONT1,FS_BOLD);

       $p[0]=new BarPlot($datay_succ);
       $p[0]->SetFillColor("forestgreen");
       if ($labels == "yes") {
          $p[0]->value->Show();
          $p[0]->value->SetAngle(90);
          $p[0]->value->SetFormat('%d');
       }

       $p[0]->SetLegend("Succ");

       $p[1]=new BarPlot($datay_abend);
       $p[1]->SetFillColor("red");
       if ($labels == "yes") {
          $p[1]->value->Show();
          $p[1]->value->SetAngle(90);
          $p[1]->value->SetFormat('%d');
       }

       $p[1]->SetLegend("Abend");

       $p[2]=new BarPlot($datay_pend);
       $p[2]->SetFillColor("purple");
       if ($labels == "yes") {
          $p[2]->value->Show();
          $p[2]->value->SetAngle(90);
          $p[2]->value->SetFormat('%d');
       }

       $p[2]->SetLegend("Pend");

       if ($contents == "active" || $contents == "all") {
          $p[3]=new BarPlot($datay_exec);
          $p[3]->SetFillColor("blue");
          if ($labels == "yes") {
             $p[3]->value->Show();
             $p[3]->value->SetAngle(90);
             $p[3]->value->SetFormat('%d');
          }

          $p[3]->SetLegend("Exec");
       }

       if ($contents == "all") {
          $p[4]=new BarPlot($datay_hold);
          $p[4]->SetFillColor("yellow");
          if ($labels == "yes") {
             $p[4]->value->Show();
             $p[4]->value->SetAngle(90);
             $p[4]->value->SetFormat('%d');
          }

          $p[4]->SetLegend("Hold");
       }

       if ($contents == "all") {
          $p[5]=new BarPlot($datay_other);
          $p[5]->SetFillColor("gray");
          if ($labels == "yes") {
             $p[5]->value->Show();
             $p[5]->value->SetAngle(90);
             $p[5]->value->SetFormat('%d');
          }

          $p[5]->SetLegend("Other");
       }

       $p1 = new AccBarPlot($p);
       if ($shadows == "yes") {
          $p1->SetShadow();
       }
       $graph->Add($p1);

       $graph->legend->Pos(0.02,0.5,"right","center");

       if ($grand_total == 0) {
          $txt=new Text("  No Activity Data  ");
          $txt->SetFont(FF_FONT2,FS_BOLD);
          $txt->SetColor("red");
          $txt->SetPos(0.3,0.4,"centered");
          $txt->SetBox("white","black",true);
          $graph->AddText($txt);
       }

       break;

     case "line":
       $graph->SetScale("textlin");
       $graph->yaxis->scale->SetGrace(10);
       $graph->xaxis->SetTickLabels($datax);
       if ($scale != "week") {
          $graph->xaxis->SetLabelAngle(90);
       }
       $graph->yaxis->title->Set("Activity (# Jobs)");
       $graph->yaxis->title->SetFont(FF_FONT1,FS_BOLD);

       $p1=new LinePlot($datay);
       $p1->SetColor("$color");
       if ($labels == "yes") {
          $p1->mark->SetType(MARK_FILLEDCIRCLE);
          $p1->mark->SetFillColor("blue");
          $p1->mark->SetWidth(3);
          $p1->value->Show();
          $p1->value->SetAngle(90);
          $p1->value->SetFormat('%d');
       }

       $graph->Add($p1);

       if ($grand_total == 0) {
          $txt=new Text("  No Activity Data  ");
          $txt->SetFont(FF_FONT2,FS_BOLD);
          $txt->SetColor("red");
          $txt->SetPos(0.3,0.4,"centered");
          $txt->SetBox("white","black",true);
          $graph->AddText($txt);
       }
       break;

     case "multiline":
       $graph->SetScale("textlin");
       $graph->yaxis->scale->SetGrace(10);
       $graph->xaxis->SetTickLabels($datax);
       if ($scale != "week") {
          $graph->xaxis->SetLabelAngle(90);
       }
       $graph->yaxis->title->Set("Activity (# Jobs)");
       $graph->yaxis->title->SetFont(FF_FONT1,FS_BOLD);

       $p1=new LinePlot($datay_succ);
       $p1->SetColor("forestgreen");
       if ($labels == "yes") {
          $p1->mark->SetType(MARK_FILLEDCIRCLE);
          $p1->mark->SetFillColor("blue");
          $p1->mark->SetWidth(3);
          $p1->value->Show();
          $p1->value->SetAngle(90);
          $p1->value->SetFormat('%d');
       }

       $graph->Add($p1);

       $p1->SetLegend("Succ");

       $p2=new LinePlot($datay_abend);
       $p2->SetColor("red");
       if ($labels == "yes") {
          $p2->mark->SetType(MARK_FILLEDCIRCLE);
          $p2->mark->SetFillColor("blue");
          $p2->mark->SetWidth(3);
          $p2->value->Show();
          $p2->value->SetAngle(90);
          $p2->value->SetFormat('%d');
       }

       $graph->Add($p2);

       $p2->SetLegend("Abend");

       $p3=new LinePlot($datay_pend);
       $p3->SetColor("purple");
       if ($labels == "yes") {
          $p3->mark->SetType(MARK_FILLEDCIRCLE);
          $p3->mark->SetFillColor("blue");
          $p3->mark->SetWidth(3);
          $p3->value->Show();
          $p3->value->SetAngle(90);
          $p3->value->SetFormat('%d');
       }

       $graph->Add($p3);

       $p3->SetLegend("Pend");

       if ($contents == "active" || $contents == "all") {
          $p4=new LinePlot($datay_exec);
          $p4->SetColor("blue");
          if ($labels == "yes") {
             $p4->mark->SetType(MARK_FILLEDCIRCLE);
             $p4->mark->SetFillColor("blue");
             $p4->mark->SetWidth(3);
             $p4->value->Show();
             $p4->value->SetAngle(90);
             $p4->value->SetFormat('%d');
          }

          $graph->Add($p4);

          $p4->SetLegend("Exec");
       }

       if ($contents == "all") {
          $p5=new LinePlot($datay_hold);
          $p5->SetColor("yellow");
          if ($labels == "yes") {
             $p5->mark->SetType(MARK_FILLEDCIRCLE);
             $p5->mark->SetFillColor("blue");
             $p5->mark->SetWidth(3);
             $p5->value->Show();
             $p5->value->SetAngle(90);
             $p5->value->SetFormat('%d');
          }

          $graph->Add($p5);

          $p5->SetLegend("Hold");
       }

       if ($contents == "all") {
          $p6=new LinePlot($datay_other);
          $p6->SetColor("gray");
          if ($labels == "yes") {
             $p6->mark->SetType(MARK_FILLEDCIRCLE);
             $p6->mark->SetFillColor("blue");
             $p6->mark->SetWidth(3);
             $p6->value->Show();
             $p6->value->SetAngle(90);
             $p6->value->SetFormat('%d');
          }

          $graph->Add($p6);

          $p6->SetLegend("Other");
       }

       $graph->legend->Pos(0.02,0.5,"right","center");

       if ($grand_total == 0) {
          $txt=new Text("  No Activity Data  ");
          $txt->SetFont(FF_FONT2,FS_BOLD);
          $txt->SetColor("red");
          $txt->SetPos(0.3,0.4,"centered");
          $txt->SetBox("white","black",true);
          $graph->AddText($txt);
       }
       break;

     case "accline":
       $graph->SetScale("textlin");
       $graph->yaxis->scale->SetGrace(10);
       $graph->xaxis->SetTickLabels($datax);
       if ($scale != "week") {
          $graph->xaxis->SetLabelAngle(90);
       }
       $graph->yaxis->title->Set("Activity (# Jobs)");
       $graph->yaxis->title->SetFont(FF_FONT1,FS_BOLD);

       $p[0]=new LinePlot($datay_succ);
       $p[0]->SetColor("forestgreen");
       $p[0]->SetFillColor("forestgreen");
       if ($labels == "yes") {
          $p[0]->mark->SetType(MARK_FILLEDCIRCLE);
          $p[0]->mark->SetFillColor("forestgreen");
          $p[0]->mark->SetWidth(3);
          $p[0]->value->Show();
          $p[0]->value->SetAngle(90);
          $p[0]->value->SetFormat('%d');
       }

       $p[0]->SetLegend("Succ");

       $p[1]=new LinePlot($datay_abend);
       $p[1]->SetColor("red");
       $p[1]->SetFillColor("red");
       if ($labels == "yes") {
          $p[1]->mark->SetType(MARK_FILLEDCIRCLE);
          $p[1]->mark->SetFillColor("red");
          $p[1]->mark->SetWidth(3);
          $p[1]->value->Show();
          $p[1]->value->SetAngle(90);
          $p[1]->value->SetFormat('%d');
       }

       $p[1]->SetLegend("Abend");

       $p[2]=new LinePlot($datay_pend);
       $p[2]->SetColor("purple");
       $p[2]->SetFillColor("purple");
       if ($labels == "yes") {
          $p[2]->mark->SetType(MARK_FILLEDCIRCLE);
          $p[2]->mark->SetFillColor("purple");
          $p[2]->mark->SetWidth(3);
          $p[2]->value->Show();
          $p[2]->value->SetAngle(90);
          $p[2]->value->SetFormat('%d');
       }

       $p[2]->SetLegend("Pend");

       if ($contents == "active" || $contents == "all") {
          $p[3]=new LinePlot($datay_exec);
          $p[3]->SetColor("blue");
          $p[3]->SetFillColor("blue");
          if ($labels == "yes") {
             $p[3]->mark->SetType(MARK_FILLEDCIRCLE);
             $p[3]->mark->SetFillColor("blue");
             $p[3]->mark->SetWidth(3);
             $p[3]->value->Show();
             $p[3]->value->SetAngle(90);
             $p[3]->value->SetFormat('%d');
          }

          $p[3]->SetLegend("Exec");
       }

       if ($contents == "all") {
          $p[4]=new LinePlot($datay_hold);
          $p[4]->SetColor("yellow");
          $p[4]->SetFillColor("yellow");
          if ($labels == "yes") {
             $p[4]->mark->SetType(MARK_FILLEDCIRCLE);
             $p[4]->mark->SetFillColor("yellow");
             $p[4]->mark->SetWidth(3);
             $p[4]->value->Show();
             $p[4]->value->SetAngle(90);
             $p[4]->value->SetFormat('%d');
          }

          $p[4]->SetLegend("Hold");
       }

       if ($contents == "all") {
          $p[5]=new LinePlot($datay_other);
          $p[5]->SetColor("gray");
          $p[5]->SetFillColor("gray");
          if ($labels == "yes") {
             $p[5]->mark->SetType(MARK_FILLEDCIRCLE);
             $p[5]->mark->SetFillColor("gray");
             $p[5]->mark->SetWidth(3);
             $p[5]->value->Show();
             $p[5]->value->SetAngle(90);
             $p[5]->value->SetFormat('%d');
          }

          $p[5]->SetLegend("Other");
       }

       $p1 = new AccLinePlot($p);
       $graph->Add($p1);

       $graph->legend->Pos(0.02,0.5,"right","center");

       if ($grand_total == 0) {
          $txt=new Text("  No Activity Data  ");
          $txt->SetFont(FF_FONT2,FS_BOLD);
          $txt->SetColor("red");
          $txt->SetPos(0.3,0.4,"centered");
          $txt->SetBox("white","black",true);
          $graph->AddText($txt);
       }

       break;
   }
   if (isset($filename)) {
      if (dirname($filename) == ".") {
         $filename="$webadmin_user_home_dir/".tws_profile('auth_user_name')."/$filename";
      }
      $graph->Stroke($filename);
   } else {
      $graph->Stroke();
   }
?>