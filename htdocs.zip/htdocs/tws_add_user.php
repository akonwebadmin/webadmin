<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");

   if ($modify == "yes") $h1 = "Modify User";
   else $h1 = "Add User";

// Windows usernames cannot contain following characters:
// " / \ [ ] : ; | = , + * ? < >
// IWS can't work with characters: '`
?>
<html>
<head>
<title><?=$h1 ?></title>
<?php tws_stylesheet(); ?>
<script type="text/javascript">
   var ignore_err_tooltip = true;   // don't show err_tooltip

function ConfirmCancel(objectname,url){
   $('form').unbind('submit');
   var conftext=confirm("Exit " + objectname + " Definition (Changes will be lost) ?");
   if (conftext) {
      if (url==null) return true;
         closeme(url);
   } else {
      return false;
   }
}

function tws_onSubmit() {
   if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('User',null)) {
      cancel_button_pressed=false; return false;
   }
}
</script>
</head>
<body>
<?php tws_set_window_title();

   tws_print_head($h1);
   tws_nossl_warning();

   if ($modify == "yes") {

      $num_elements=count($selection);
      if ($num_elements == 0) {
         tws_dyer("No user selected");
      } elseif ($num_elements > 1) {
         tws_dyer("Multiple users selected. Only one user can be modified at a time.");
      }

      $selection[0]=str_replace("\\\\","\\",$selection[0]);

      list($dom_user,$workstation)=array_reverse(explode('#',$selection[0]));
      list($username,$domain)=array_reverse(explode("\\",$dom_user));

      if ($workstation == "") {
         $wks_query="WKC_NAME IS NULL";
      } else {
         $wks_query="WKC_NAME = '$workstation'";
      }

      if (($db_user=tws_get_users($dom_user,$wks_query))===FALSE){
         $status="error";
      }
      if ($db_user['user_num'] != 1) $status="error";

      if ($modify=="yes") {
//lock object
         tws_composer_lock("user=$selection[0]") or tws_dyer("Unable to lock user '$selection[0]'");
      }

      if (isset($status) && $status == "error") {
         tws_dyer("Unable to retrieve user definition");
      }
   }

?>

<br><br>
<form method=post name="contents" action="tws_add_user_exec.php" onsubmit="return tws_onSubmit();">
<table border=0 cellspacing=0>
<tr>
<td class=standard width=150>
&nbsp;&nbsp;<b>Workstation:</b>
</td>
<td class=standard>
<input type="text" name="workstation" class="tws_name" size=16 maxlength=16 <?php if (isset($workstation)) echo " value=\"".htmlspecialchars($workstation)."\""; ?><?php if ($modify == "yes") echo " disabled"; ?>>
<?php if ($modify != "yes") { ?>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" name="workstation_list" onClick="tws_picker_open('workstation_picker.php', 'fieldname=workstation&amp;fieldvalue=' + document.contents.workstation.value);" value="List">
<?php } ?>
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class=standard width=150>
&nbsp;&nbsp;<b>NT Domain:</b>
</td>
<td class=standard>
<input type="text" name="domain" class="tws_name" size=15 maxlength=15 <?php if (isset($domain)) echo " value=\"".htmlspecialchars($domain)."\""; ?><?php if ($modify == "yes") echo " disabled"; ?>>
</td>
</tr>
<tr>
<td class=standard width=150>
&nbsp;&nbsp;<b>User Name:</b>
</td>
<td class=standard>
<input type="text" name="username" required="required" class='tws_username' size=31 maxlength=31 <?php if (isset($username)) echo " value=\"".htmlspecialchars($username)."\""; ?><?php if ($modify == "yes") echo " disabled"; ?>>
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class=standard width=150>
&nbsp;&nbsp;<b>Password:</b>
</td>
<td class=standard>
<input type="password" name="password" autocomplete="off" size=29 maxlength=29/>
</td>
</tr>
<tr>
<td class=standard width=150>
&nbsp;&nbsp;<b>Confirm Password:</b>
</td>
<td class=standard>
<input type="password" name="confirm_password" autocomplete="off" size=29 maxlength=29/>
</td>
</tr>
</table>
<br><br>
<?
   if ($modify == "yes") {
      echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
      echo "<input type=\"hidden\" name=\"workstationx\" value=\"".htmlspecialchars($workstation)."\">\n";
      echo "<input type=\"hidden\" name=\"domainx\" value=\"".htmlspecialchars($domain)."\">\n";
      echo "<input type=\"hidden\" name=\"usernamex\" value=\"".htmlspecialchars($username)."\">\n";
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' name='action' value='Update'>\n";
   } else {
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' name='action' value='Add'>\n";
   }

   if ($modify=="yes") {
      echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' name='action' value='Cancel' onClick='cancel_button_pressed=true;'>\n";
   } else {
      echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' value='Cancel' onClick=\"ConfirmCancel('User','tws_usersx.php')\">\n";
   }
tws_print_synchro_token();  // synchro token
// ~!@%&()_-{}ksdjf
?>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" value="Print" onClick="window.print()">
</form>
   <script type="text/javascript">
   //$('.tws_username').live("keyup", valid_tws_username);
   $('.tws_username').on("keyup", valid_tws_username);

   function valid_tws_username() {
      var pattern = /^[a-z0-9_\-.!@%]*$/i;
      // tws errors with other symbols
      var field_value = this.value;
      if (field_value.search(pattern)!=-1){
         $(this).removeClass("invalid");
         remove_err_tooltip(this);
      }
      else{
         $(this).addClass("invalid");
         show_err_tooltip(this);
      }
   }
   </script>
</body>
</html>
