<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");

   // Cancel button test
   $tmp_test = (isset($_POST['action']) && $_POST['action'] == 'Return to Modification') ? true : false;
   if ($tmp_test == true) {
      foreach ($_POST as $key => $val){
         $$key = tws_gpc_get($val);
      }
   }
   if ($copy == "yes")   $h1="Copy Domain";
   elseif($modify == "yes") $h1 = "Modify Domain";
   else $h1 = "Add Domain";
?>
<html>
<head>
<title><?=$h1 ?></title>
<?php tws_stylesheet(); ?>
<script type="text/javascript">
function ConfirmCancel(objectname,url){
   $('form').unbind('submit');
   var conftext=confirm("Exit " + objectname + " Definition (Changes will be lost) ?");
   if (conftext) {
      if (url==null) return true;
      closeme(url);
   } else {
      return false;
   }
}
function enable_parent(check)
{
   if (check.checked){
      document.getElementById('parent').disabled=true;
      document.getElementById('domain_list').disabled=true;
      document.getElementById('masterdm').disabled=true;
   } else {
      document.getElementById('parent').disabled=false;
      document.getElementById('domain_list').disabled=false;
      document.getElementById('masterdm').disabled=false;
   }
}
</script>
</head>

<body>
<?php tws_set_window_title();

   tws_print_head($h1);

   if ($tmp_test == false && ($copy == "yes" || $modify == "yes")) {

      $num_elements=count($selection);

      if ($num_elements == 0) {
         tws_dyer("No domain selected");
      } elseif ($num_elements > 1) {
         tws_dyer("Multiple domains selected. Only one domain can be ".($copy=="yes" ? 'copied' : 'modified')." at a time");
      }

      if (($db_domain=tws_get_domains($selection[0]))===FALSE){
         tws_dyer("Unable to list domains");
      }
      if ($db_domain['domain_num'] != 1) {
         tws_dyer("Database query failed");
      }
      tws_adjust4html($db_domain);
      $domain = $db_domain['domain_name'][0];
      $description = $db_domain['domain_description'][0];
      $parent = $db_domain['domain_parent'][0];
      $manager = $db_domain['domain_manager'][0];

      if ($modify=="yes") {
// lock object
         tws_composer_lock("dom=$selection[0]") or tws_dyer("Unable to lock domain '$selection[0]'");
// backup
         if (($original_data=tws_composer_create_from("dom=$selection[0]"))===FALSE) tws_dyer("Unable to create backup");
      }

   }
?>

<br><br>
<form method=post name="contents" action="tws_add_domain_exec.php" onsubmit="if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Domain',null)) { cancel_button_pressed=false; return false;}">
<table border=0 cellspacing=0>
<tr>
<td class=standard width=140>
&nbsp;&nbsp;<b>Domain Name:</b>
</td>
<td class=standard>
<input type="text" name="domain_name" class="tws_name" required="required" size=20 maxlength=16<?php if (isset($domain)) echo " value=\"$domain\""; ?><?php if ($modify == "yes") echo " disabled"; ?>>
</td>
</tr>
<?
   if ($copy == "yes") {
      echo "<script type='text/javascript'>\n";
      echo "<!--\n";
      echo "document.contents.domain_name.focus();\n";
      echo "document.contents.domain_name.select();\n";
      echo "// -->\n";
      echo "</script>\n";
   }
?>
<tr>
<td class=standard width=140>
&nbsp;&nbsp;<b>Description:</b>
</td>
<td class=standard>
<input type="text" name="description" size=40 maxlength=40 <?php if (isset($description)) echo " value=\"$description\""; ?>>
</td>
</tr>
<tr>
<tr>
<td class=standard width=140>
&nbsp;&nbsp;<b>Is Master:</b>
</td>
<td class=standard>
<input type="checkbox" name="ismaster" value="yes" <?=$parent!='' ? '' : 'checked'?> onClick="enable_parent(this);">
</td>
</tr>
<? // get MasterDomain
   $md = tws_get_domains('@', 'DOM1.DOM_PARENT_ID IS NULL');
   if(!empty($md['domain_name'][0]))
      $md = $md['domain_name'][0];
   else $md = 'MASTERDM';
?>
<tr>
<td class=standard width=140>
&nbsp;&nbsp;<b>Parent Domain:</b>
</td>
<td class=standard>
<input type="text" id="parent" name="parent" class="tws_name" size=20 maxlength=16 <?=$parent!='' ? ' value="'.$parent.'"' : 'disabled'?>/>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="button" id="domain_list" name="domain_list" value="List" onClick="tws_picker_open('domain_picker.php', 'fieldname=parent&amp;fieldvalue=' + document.contents.parent.value);" <?=$parent!='' ? '' : 'disabled'?>>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" id="masterdm" name="masterdm" onClick="document.contents.parent.value='<?=$md?>'" value="Use Master Domain" <?=$parent!='' ? '' : 'disabled'?>>
</td>
</tr>
<!--  Manager is defined in Workstation definition since IWS v8.3
<tr>
<td class=standard width=140>
&nbsp;&nbsp;<b>Domain Manager:</b>
</td>
<td class=standard>
<input type="text" name="manager" size=20 maxlength=16<?php if (isset($manager)) echo " value=\"$manager\""; ?>>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" name="manager_list" onClick="tws_picker_open('workstation_picker.php', 'includexagents=no&amp;fieldname=manager&amp;fieldvalue=' + document.contents.manager.value);" value="List">
</td>
</tr>
-->
</table>
<br><br>
<?
   if ($modify == "yes") {
      echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
      echo "<input type=\"hidden\" name=\"domain_namex\" value=\"$domain\">\n";
      echo "<input type=\"hidden\" name=\"original_data\" value=\"".htmlspecialchars($original_data)."\">\n";
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Update\" onClick=\"return tws_validate_form()\"/>\n";
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Cancel\" onClick=\"cancel_button_pressed=true;\"/>\n";
   } else {
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Add\" onClick=\"return tws_validate_form()\"/>\n";
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"button\" value=\"Cancel\" onClick=\"ConfirmCancel('Domain','tws_domainsx.php')\"/>\n";
   }
   tws_print_synchro_token();  // synchro token
?>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" value="Print" onClick="window.print()">
</form>
</body>
</html>
