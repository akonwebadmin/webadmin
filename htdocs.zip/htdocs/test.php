<?php

/*
$version = '9.5.0.01';

$version = '9.5.0.02';

die;
*/

include("tws_functions.php");

$version = $tws_config['cpuinfo']['version'];

var_dump($version);

die;



require_once ("tws_composer.php");
//require_once ("tws_folders_lib.php");

$schema = $composer_db['schema'];

tws_log("1'st attempt:");

$hex = "x'E0ADA98C4F4A3B00A958940ADB40A4BF'";

   $query = "
   SELECT
      FOL.FOL_NAME FOL_NAME
   FROM $schema.AJS_ABSTRACT_JOB_STREAMS AJS
      LEFT JOIN $schema.FOL_FOLDERS FOL ON AJS.FOL_ID = FOL.FOL_ID
   WHERE
      AJS.FOL_ID = $hex";

   $r=db_query($composer_db, $query);
   
   if($r == false) {
      tws_error($query, 'Database query failed');
      die;
   }
   while ($row = db_fetch_row($composer_db)) {
      var_dump($row);
   }

die;


tws_log("2'd attempt:");

$hex = "E0ADA98C4F4A3B00A958940ADB40A4BF";
$hex2bin = hex2bin($hex);


         $query = "
         SELECT
            FOL.FOL_NAME FOL_NAME
         FROM $schema.AJS_ABSTRACT_JOB_STREAMS AJS
            JOIN $schema.FOL_FOLDERS FOL ON AJS.FOL_ID = FOL.FOL_ID
         WHERE
            AJS.FOL_ID = ?";
            

$stmt=new db_statement($composer_db, $query);
if ($stmt->prepare()==FALSE)
   tws_error('', 'Database query prepare failed: '.$query);
      
      
$values = array();
$values[]  = $hex2bin;

   if ($stmt->execute($values)==false){
      tws_error('Database query failed on execute: '.$query);
      return FALSE;
   }

   if( $stmt->fetch() ){
      $row = $stmt->row();
      var_dump($row);
   }
   else{
      tws_error('query is empty');
   }

/*
function local_get_jobstream_folder($name){


    global $tws_config, $composer_db;
    global $jobstream_folder, $jobstream_folder_id; // tws 9.5 folders:
    $jobstream_folder = $jobstream_folder_id = '';
    
    $name = strtoupper($name);
    joblog("-- tws_get_jobstream_folder. Patameter: $name");
    
    // TODO: list($jobstream_folder, $jobstream_name) = tws_explode_folder($name); instead of below
    $pos = strrpos($name, '/');
    if ($pos === false)
        return ''; // no folder
                   // folder exist
    $jobstream_folder = substr($name, 0, $pos + 1);
    $jobstream_name = substr($name, $pos + 1);
    
    joblog("-- tws_get_jobstream_folder. pos = $pos, jobstream_folder = $jobstream_folder, jobstream_name = $jobstream_name");
    
    $dbh = db_connect($composer_db, DB_PERSISTENT);
    if (!$dbh) {
        tws_error('', 'Cannot connect to database');
        return FALSE;
    }
    $schema = $composer_db['schema'];
    $hex_fce = ($composer_db['type'] == 'db2' ? 'HEX' : 'RAWTOHEX');
    
    $query = "
        SELECT
        $hex_fce ($schema.FOL_FOLDERS.FOL_ID) FOL_ID
        FROM $schema.FOL_FOLDERS
        WHERE FOL_PATH " . tws_sqllike(db_string($composer_db, $jobstream_folder));
    joblog("-- tws_get_jobstream_folder DB query: $query");
    if (!($r = db_query($composer_db, $query))) {
        tws_error('', 'Database query failed');
        return false;
    }
    $row = db_fetch_row($composer_db);
    if (empty($row)) {
        tws_error('No qualified entries');
        return false;
    }
    joblog("-- local_get_jobstream_folder Result: " . var_export($row, true));
    // $jobstream_folder_id = $row['FOL_ID'];
    $jobstream_folder_id = ($composer_db['type'] == 'db2' ? "x'" . $row['FOL_ID'] . "'" : "HEXTORAW('" . $row['FOL_ID'] . "')");
    $jobstream_folder_expr = " AND AJS.FOL_ID = $jobstream_folder_id";
    joblog("-- jobstream_folder_expr " . var_export($jobstream_folder_expr, true));
    
    
    $sql = "SELECT FOL_PATH FROM $schema.FOL_FOLDERS  WHERE FOL_ID = ?";
    $stmt = new db_statement($composer_db, $sql);
    if ($stmt->prepare() == FALSE) {
        unset($stmt);
        tws_error('', 'Database query prepare failed: ' . $query);
        return FALSE;
    }
    if ($stmt->execute(array(
            hex2bin($row['FOL_ID']) 
    )) == false) {
        joblog('Database query failed: ' . $stmt->sql());
        return FALSE;
    }
    else {
        while ($stmt->fetch()) {
            $row2 = $stmt->row();
            joblog('test hex2bin: ' . var_export($row2,true));
        }
   }

var_dump($jobstream_name);    die;
    return $jobstream_name;

}


//        [message] => [IBM][CLI Driver] CLI0109E  String data right truncation. SQLSTATE=22001 SQLCODE=-99999

/*
include("tws_test_functions.php");
require ("tws_test_composer.php");
require ("tws_folders_lib.php");

$new_sched_cpu = 'PC128';
$new_sched_schedule = '/FOLDER2/NEW_FOLDER1/KON';

$new_sched_def = tws_get_jobstream_jobs($new_sched_cpu, $new_sched_schedule);

echo "new_sched_def['jobname']: ";
    var_export($new_sched_def['jobname']); 
echo "<br>";

/*
echo "new_sched_def['jobname']: ";
    var_export($new_sched_def['jobname']); 
echo "<br>";

echo "new_sched_def['job_folder']: ";
    var_export($new_sched_def['job_folder']); 
echo "<br>";

echo "new_sched_def['def_jobname']: ";
    var_export($new_sched_def['def_jobname']); 
echo "<br>";


foreach($new_sched_def['def_jobname'] as $full_jobname=>$def_jobname)

   $job_folders['def_jobname'][$def_jobname] = $new_sched_def['job_folder'][$full_jobname];

echo "job_folders: ";
var_export($job_folders);


$arg = "x'E0ADA98C4F4A3B00A958940ADB40A4BF'";

echo "echo arg = $arg";
echo("<br> var_dump arg = : "); var_dump($arg);
echo("<br> var_export arg = : "); var_export($arg);

echo "<br><br>";

$arr = $arr1 = array();
$arr[] = $arg;
echo "<br>arr[] = arg<br>";
echo "<br>print_r(arr) = ".print_r($arr, true);
echo "<br>var_dump(arr) = <br>";
var_dump($arr);
echo("<br> var_export arr= : "); var_export($arr);


die;

$str = "ID = $arg";
echo("<br> str = $str<br> var_dump: ");  var_dump($str);

$arr = $arr1 = array();
$arr[] = $arg;
echo "<br>arr = ".var_dump($arr);

$str = "ID = $arg";
echo("<br> str = $str<br> var_dump: ");  var_dump($str);

die;

$arr1[] = stripcslashes($arg);
echo ("<br>arr1 = ".var_export($arr1, true));


// 1.  AND AJS.FOL_ID = x'E0ADA98C4F4A3B00A958940ADB40A4BF'
// 2.  
*/
/*
new_sched_def['jobname']:        array ( 0 => 'PC128#/SET', 1 => 'PC128#/KON_TEST/LS-LA', 2 => 'PC128#/MASS_TEST_F/ABEND_TEST', )
new_sched_def['job_folder']:     array ( 'PC128#/SET' => '/', 'PC128#/KON_TEST/LS-LA' => '/KON_TEST/', 'PC128#/MASS_TEST_F/ABEND_TEST' => '/MASS_TEST_F/', )
new_sched_def['def_jobname']:    array ( 'PC128#/SET' => 'SET', 'PC128#/KON_TEST/LS-LA' => 'LS-LA', 'PC128#/MASS_TEST_F/ABEND_TEST' => 'ABEND_TEST', )

job_folders:                     array ( 'def_jobname' => array ( 0 => '/', 1 => '/KON_TEST/', 2 => '/MASS_TEST_F/', ), ) 

//
 
$sched_def = array(13) {

   ["jobname"]=> array(3) { [0]=> string(10) "PC128#/SET" [1]=> string(21) "PC128#/KON_TEST/LS-LA" [2]=> string(29) "PC128#/MASS_TEST_F/ABEND_TEST" }
   
   ["job_folder"]=> array(3) { ["PC128#/SET"]=> string(1) "/" ["PC128#/KON_TEST/LS-LA"]=> string(10) "/KON_TEST/" ["PC128#/MASS_TEST_F/ABEND_TEST"]=> string(13) "/MASS_TEST_F/" }

   ["job_folder_id"]=> array(3) { ["PC128#/SET"]=> string(32) "742BA6A631AA3051B8103CED4FC624B4" ["PC128#/KON_TEST/LS-LA"]=> string(32) "FC9FEF3D5E89360A8ADD3FBD5668A34F"["PC128#/MASS_TEST_F/ABEND_TEST"]=> string(32) "69F5F2BAC9DF3BEBAB88D29928B5D88E" }
   ["job_time_dependent"]=> array(3) { ["PC128#/SET"]=> string(1) "N" ["PC128#/KON_TEST/LS-LA"]=> string(1) "N" ["PC128#/MASS_TEST_F/ABEND_TEST"]=> string(1) "N" }
   ["jobtime_zone"]=> array(3) { ["PC128#/SET"]=> NULL ["PC128#/KON_TEST/LS-LA"]=> NULL ["PC128#/MASS_TEST_F/ABEND_TEST"]=> NULL }
   ["jobpriority"]=> array(3) { ["PC128#/SET"]=> string(0) "" ["PC128#/KON_TEST/LS-LA"]=> string(0) "" ["PC128#/MASS_TEST_F/ABEND_TEST"]=> string(1) "0" }
   ["jobconfirmed"]=> array(3) { ["PC128#/SET"]=> string(2) "NO" ["PC128#/KON_TEST/LS-LA"]=> string(2) "NO" ["PC128#/MASS_TEST_F/ABEND_TEST"]=> string(2) "NO" }
   ["jobkeyjob"]=> array(3) { ["PC128#/SET"]=> string(2) "NO" ["PC128#/KON_TEST/LS-LA"]=> string(2) "NO" ["PC128#/MASS_TEST_F/ABEND_TEST"]=> string(2) "NO" }
   ["jobcritical"]=> array(3) { ["PC128#/SET"]=> string(2) "NO" ["PC128#/KON_TEST/LS-LA"]=> string(2) "NO" ["PC128#/MASS_TEST_F/ABEND_TEST"]=> string(2) "NO" }
   ["jobnop"]=> array(3) { ["PC128#/SET"]=> string(2) "NO" ["PC128#/KON_TEST/LS-LA"]=> string(2) "NO" ["PC128#/MASS_TEST_F/ABEND_TEST"]=> string(2) "NO" }

   ["def_jobname"]=> array(3) { ["PC128#/SET"]=> string(3) "SET" ["PC128#/KON_TEST/LS-LA"]=> string(5) "LS-LA" ["PC128#/MASS_TEST_F/ABEND_TEST"]=> string(10) "ABEND_TEST" }

   ["job_workstation"]=> array(3) { ["PC128#/SET"]=> string(5) "PC128" ["PC128#/KON_TEST/LS-LA"]=> string(5) "PC128" ["PC128#/MASS_TEST_F/ABEND_TEST"]=> string(5) "PC128" }
   ["job_num"]=> int(3) } 



/zli_send_data_plan.php
-- zli_print_db_deps, def: array (
  'cpu' => 'PC128',
  'schedule' => 'COND2',
  'valid_from' => '',
  'sched_date' => '2020-02-13',
  'start_time' => '2020-02-12 23:00:00.000000',
  'jobstream_folder' => '/FOLDER2/',
)


2020-02-20 18:29:13 INFO    job_folders: array (
  'STARTAPPSERVER' => '/',
  'MAKEPLAN' => '/',
  'SWITCHPLAN' => '/',
)
2020-02-20 18:29:13 INFO    new_sched_def: array (
  'jobname' =>
  array (
    0 => 'PC128#/CHECKSYNC',
    1 => 'PC128#/CREATEPOSTREPORTS',
    2 => 'PC128#/UPDATESTATS',
  ),
  'job_folder' =>
  array (
    'PC128#/CHECKSYNC' => '/',
    'PC128#/CREATEPOSTREPORTS' => '/',
    'PC128#/UPDATESTATS' => '/',
  ),
  'job_folder_id' =>
  array (
    'PC128#/CHECKSYNC' => '742BA6A631AA3051B8103CED4FC624B4',
    'PC128#/CREATEPOSTREPORTS' => '742BA6A631AA3051B8103CED4FC624B4',
    'PC128#/UPDATESTATS' => '742BA6A631AA3051B8103CED4FC624B4',
  ),
  'job_time_dependent' =>
  array (
    'PC128#/CHECKSYNC' => 'N',
    'PC128#/CREATEPOSTREPORTS' => 'N',
    'PC128#/UPDATESTATS' => 'N',
  ),
  'jobtime_zone' =>
  array (
    'PC128#/CHECKSYNC' => NULL,
    'PC128#/CREATEPOSTREPORTS' => NULL,
    'PC128#/UPDATESTATS' => NULL,
  ),
  'jobpriority' =>
  array (
    'PC128#/CHECKSYNC' => '',
    'PC128#/CREATEPOSTREPORTS' => '',
    'PC128#/UPDATESTATS' => '',
  ),
  'jobconfirmed' =>
  array (
    'PC128#/CHECKSYNC' => 'NO',
    'PC128#/CREATEPOSTREPORTS' => 'NO',
    'PC128#/UPDATESTATS' => 'NO',
  ),
  'jobkeyjob' =>
  array (
    'PC128#/CHECKSYNC' => 'NO',
    'PC128#/CREATEPOSTREPORTS' => 'NO',
    'PC128#/UPDATESTATS' => 'NO',
  ),
  'jobcritical' =>
  array (
    'PC128#/CHECKSYNC' => 'NO',
    'PC128#/CREATEPOSTREPORTS' => 'NO',
    'PC128#/UPDATESTATS' => 'NO',
  ),
  'jobnop' =>
  array (
    'PC128#/CHECKSYNC' => 'NO',
    'PC128#/CREATEPOSTREPORTS' => 'NO',
    'PC128#/UPDATESTATS' => 'NO',
  ),
  'def_jobname' =>
  array (
    'PC128#/CHECKSYNC' => 'CHECKSYNC',
    'PC128#/CREATEPOSTREPORTS' => 'CREATEPOSTREPORTS',
    'PC128#/UPDATESTATS' => 'UPDATESTATS',
  ),
  'job_workstation' =>
  array (
    'PC128#/CHECKSYNC' => 'PC128',
    'PC128#/CREATEPOSTREPORTS' => 'PC128',
    'PC128#/UPDATESTATS' => 'PC128',
  ),
  'jobdescription' =>
  array (
    'PC128#/UPDATESTATS' => '  CreatePostReports runs reporter to print post-production reports.
  UpdateStats runs logman to log job statistics, and then
  report8 to print the Job Histogram.',
  ),
  'job_num' => 3,
)




From: HORIZONT, Petr Horn [mailto:phorn@horizont-it.com] 
Sent: 27. února 2020 15:27
To: 'Artem Konev' <akonev@horizont-it.com>
Subject: reseni folder_id

function local_get_jobstream_folder($name){


    global $tws_config, $composer_db;
    global $jobstream_folder_expr, $jobstream_folder, $jobstream_folder_id; // tws 9.5 folders:
    $jobstream_folder_expr = $jobstream_folder = $jobstream_folder_id = '';
    
    $name = strtoupper($name);
    joblog("-- tws_get_jobstream_folder. Patameter: $name");
    
    // TODO: list($jobstream_folder, $jobstream_name) = tws_explode_folder($name); instead of below
    $pos = strrpos($name, '/');
    if ($pos === false)
        return ''; // no folder
                   // folder exist
    $jobstream_folder = substr($name, 0, $pos + 1);
    $jobstream_name = substr($name, $pos + 1);
    
    joblog("-- tws_get_jobstream_folder. pos = $pos, jobstream_folder = $jobstream_folder, jobstream_name = $jobstream_name");
    
    $dbh = db_connect($composer_db, DB_PERSISTENT);
    if (!$dbh) {
        tws_error('', 'Cannot connect to database');
        return FALSE;
    }
    $schema = $composer_db['schema'];
    $hex_fce = ($composer_db['type'] == 'db2' ? 'HEX' : 'RAWTOHEX');
    
    $query = "
        SELECT
        $hex_fce ($schema.FOL_FOLDERS.FOL_ID) FOL_ID
        FROM $schema.FOL_FOLDERS
        WHERE FOL_PATH " . tws_sqllike(db_string($composer_db, $jobstream_folder));
    joblog("-- tws_get_jobstream_folder DB query: $query");
    if (!($r = db_query($composer_db, $query))) {
        tws_error('', 'Database query failed');
        return false;
    }
    $row = db_fetch_row($composer_db);
    if (empty($row)) {
        tws_error('No qualified entries');
        return false;
    }
    joblog("-- local_get_jobstream_folder Result: " . var_export($row, true));
    // $jobstream_folder_id = $row['FOL_ID'];
    $jobstream_folder_id = ($composer_db['type'] == 'db2' ? "x'" . $row['FOL_ID'] . "'" : "HEXTORAW('" . $row['FOL_ID'] . "')");
    $jobstream_folder_expr = " AND AJS.FOL_ID = $jobstream_folder_id";
    joblog("-- jobstream_folder_expr " . var_export($jobstream_folder_expr, true));
    
    
    $sql = "SELECT FOL_PATH FROM $schema.FOL_FOLDERS  WHERE FOL_ID = ?";
    $stmt = new db_statement($composer_db, $sql);
    if ($stmt->prepare() == FALSE) {
        unset($stmt);
        tws_error('', 'Database query prepare failed: ' . $query);
        return FALSE;
    }
    if ($stmt->execute(array(hex2bin($row['FOL_ID']) )) == false) {
        joblog('Database query failed: ' . $stmt->sql());
        return FALSE;
    }
    else {
        while ($stmt->fetch()) {
            $row2 = $stmt->row();
            joblog('test hex2bin: ' . var_export($row2,true));
        }
    }
    
    return $jobstream_name;

}

Petr Horn
HORIZONT IT Services CZ s.r.o.
Radnicni 133/1
CZ-37001 Ceske Budejovice

HORIZONT Software GmbH
Schäufeleinstraße 7
D-80339 München

Tel           +420 391 000 715 
Email         phorn@horizont-it.com
Homepage      www.horizont-it.com
Support Email support@horizont-it.com
Support Tel   ++49 / (0)89 / 540 162 - 99

Registergericht: Amtsgericht München, HRB 103647
Geschäftsführer: Josef Dirnberger, Uwe Hahm 


*/
?>

