<?php
//   HORIZONT Software GmbH, Munich
//

require_once 'tws_functions.php';
require_once 'tws_filters_lib.php';

tws_get_filter_from_get($filter, $filter_name);

tws_profile('opener', basename($_SERVER['REQUEST_URI']));

if (tws_profile('table_type')=='flextable')
   $page_size = 0;
else {
   $page_size = tws_get_page_size();
   $__keypress_handler = true;
}
tws_set_layout('acmon');

tws_doctype('t');
?>
<html>
<head>
   <title>Action Runs Monitor</title>
   <? tws_stylesheet();
      tws_save_filter_in_storage();
   ?>
   <script type="text/javascript" src="checkbox_selection.js"></script>
   <script type="text/javascript">

   function displayEvRule(wst) {
      url = 'tws_display_evrule.php?arg=' + escape(wst);
      tws_url_open(url, '', 800);
      //window.open(url, '', 'height=600, width=800, left=60, top=50, toolbar=no, menubar=no, location=no, scrollbars=yes, resizable=yes');
   }

   function doSubmit(actionButton) {
      var action = actionButton.innerHTML;
      var form = document.displayacmon;
      form.action.value = action;

      if(action_refresh || action=='Layout'){
         form.target = '_self';
         form.submit();
      }
      else{
         var param = 'height=800, width=800, left=60, top=50, toolbar=no, menubar=no, location=no, scrollbars=yes, resizable=yes';
         window.open('', 'tws_popup', param);
         form.target = 'tws_popup';
         form.submit();
         ClearAll(form);
      }
   }

   </script>
</head>
<body onload="enable_action_buttons(); doLoaded(); restoreScroll('acmon');" onUnload="saveScroll('acmon');">
<? if (tws_profile('button_location') != 'bottom')
      echo "<div style='top:0; height:35px;'> </div>\n";
   if(tws_get_menu('Actions_Monitor')==0) tws_access_denied();

   tws_waiting(1);
   tws_set_window_title($filter_name);
   $log_file_name=tws_log('', 'OPEN');
   tws_print_head('Action Runs Monitor', array('__filter__' => $filter, '__filter_name__' => $filter_name, '__log__' => $log_file_name));

   $filter_url = '<a class="txtIcon" href="tws_acmon_filter.php">F</a>';

   tws_log('-- START ('.basename(__FILE__).'['.__LINE__.'])');
   $execution_time = tws_getmicrotime();

   //   Create where condition
   list ($xfilter, $keys) = tws_planfilter_explode_keys($filter);
   $xfilter = tws_dbfilter_where ($xfilter, 'LLRC_TEXT_1');
   if ($xfilter == false)
      tws_err('Wrong filter format');
   else
      if (($acmon = tws_get_evrule_instances_actions('@'.$keys, $xfilter, $page_size, isset($_GET['page']) ? $_GET['page'] : 1))===FALSE)
         tws_dyer('Unable to get list of events');

   foreach ($acmon as $key => $value) {
      tws_log() && tws_log('Result \$'.$key.' = '.@var_export($value, true).';');
      $$key = $value;
      unset($acmon[$key]);
   }

   $execution_time = tws_getmicrotime() - $execution_time;
   tws_print_head('Action Runs Monitor', array('__filter__' => $filter, '__filter_name__' => $filter_name, '__time__' => $execution_time, '__log__' => $log_file_name, '__count__' => $evrule_num, '__navigation__' => array($evrule_num, $filter_url)));

   echo '<form method="post" name="displayacmon" action="tws_acmon_action.php">'."\n";
   if ($evrule_num == 0) {
      echo '<p class="warning">No qualified entries.</p>'."\n";
   } else {
      tws_print_check_clear_all('document.displayacmon');
      echo '<table class="wireframe dtable" id="sortable" cellspacing="0" cellpadding="4" width="100%">'."\n";
      echo '<thead><tr class="header">'."\n";
      echo '<th width="1">&nbsp;</th>';
      foreach ($layout_column as $column)
         echo '<th title="'.$column.'">'.tws_html_column_header($column).'</th>'."\n";
      echo '</tr></thead>'."\n";

      if ($page_size) {
         $page = isset($_GET['page']) ? $_GET['page'] : 1;
         $offset = 1 + ($page - 1) * $page_size;
      } else {
         $offset = 1;
      }
      foreach ($evrule_name as $i => $tmp) {
         echo '<tr class="standard" title="['.($i + $offset).']">'."\n";
         echo '<td><input type="checkbox" name="selection[]" value="'.$evrule_name[$i].'" onclick="selectCheckboxes(this);"></td>';
         for ($c = 0; $c < count($layout_column); $c++) {
            switch ($layout_column[$c]) {
               case 'Rule Name':
                  echo '<td><a href="javascript:displayEvRule(\'',$evrule_name[$i],'\');" title="Display Event Rule Definition">',$evrule_name[$i],'</a></td>';
//                  echo '<td>',$evrule_name[$i],'</td>';
                  break;
               case 'Action Type':
                  switch (strtoupper($erac_type[$i])) {
                     case 'SBS' :
                        list ($workstation, $jobstream)=explode(';',$erac_result[$i]);
                        echo "<td><a href=\"tws_ssx.php?tmp=".urlencode("$workstation#$jobstream;schedid")."\" title=\"Show submitted jobstream\">".tws_typeval('ERAC_TYPE',$erac_type[$i])."</a></td>\n";
                        break;
                     case 'SBJ' : case 'SBD' :
                        list ($workstation, $jobstream, $job)=explode(';',$erac_result[$i]);
                        echo "<td><a href=\"tws_sjx.php?tmp=".urlencode("$workstation#$jobstream.$job;schedid")."\" title=\"Show submitted job/task\">".tws_typeval('ERAC_TYPE',$erac_type[$i])."</a></td>\n";
                        break;
                     case 'MSGLOG' :
                        echo "<td><a href=\"tws_msgmonx.php?tmp=".urlencode($evrule_name[$i])."\" title=\"Show logged message\">".tws_typeval('ERAC_TYPE',$erac_type[$i])."</a></td>\n";
                        break;
                      default:
                        echo '<td>',tws_typeval('ERAC_TYPE',$erac_type[$i]),'</td>';
                        break;
                  }
                  break;
               case 'Action Provider':
                  echo '<td>',$erac_provider[$i],'</td>';
                  break;
                case 'Time Stamp':
                  echo '<td>',tws_iso_to_userdate($erac_logtime[$i], null, FALSE, $composer_db['tz']),'</td>';
                  break;
                case 'Status':
                  switch (tws_typeval('ERI_STATUS',$erac_status[$i])) {
                     case 'SUCC' :
                        $css='class="good"';
                        break;
                     case 'ERROR' :
                        $css='class="error"';
                        break;
                     default:
                        $css='';
                        break;
                  }
                  echo '<td ',$css,'>',tws_typeval('ERI_STATUS',$erac_status[$i]),'</td>';
                  break;
                case 'Message':
                  $msg=preg_replace('/AWS[^\s]*/','',$erac_message[$i]);
                  if (($pos=strpos($msg,'...'))!==FALSE) $msg=substr($msg, $pos+3);
                  echo '<td>',htmlspecialchars(trim($msg)),'</td>';
                  break;
            }
         }
         echo '</tr>'."\n";
      }
      echo '</table>'."\n";
      tws_print_navigation($evrule_num, $filter_url);
   }
   tws_log('-- FINISH ('.basename(__FILE__).'['.__LINE__.'])', 'CLOSE');
?>
<input type="hidden" name="action" value="">
<input type='hidden' name='arg' value='<?=htmlspecialchars($filter)?>'>

<div class='buttons'>
<ul class="menu">
   <li><a href="#" onclick="return false;">Filter</a>
      <ul>
         <li><a href="tws_acmon_filter.php?arg=<?=urlencode($filter)?>">Set Filter</a></li>
         <li><a href="tws_acmon_filter.php?arg=<?=urlencode($filter)?>#load">Load Filter</a></li>
         <? if ($filter){
            echo '<li><a href="#" onclick="doSubmit(this)">Save Filter</a></li>';
            echo '<li><a href="tws_acmon_filter_action.php?action=Clear Filter&reset">Clear Filter</a></li>';
         }
         tws_draw_saved_filters('acmon');
         ?>
      </ul>
   </li>
<?
   if (!isset($evrule_num) || ($evrule_num > 0)){
      echo"<li><a href='#' onclick='return false;'>Display</a>
      <ul>\n";
      echo "<li><a href='#' onclick='doSubmit(this); return false;' class='actions' id='Display_Event_Rule'>Event Rule</a></li>\n";
      echo "</ul>
         </li>\n";
   }
   echo "<li><a href='#' onclick='return false;'>Settings</a>
         <ul>";
   if (tws_permit_action('common_actions','Layout'))  echo "<li><a href='#' onclick='doSubmit(this); return false;' >Layout</a></li>\n";
   if (tws_permit_action('common_actions','Print'))   echo "<li><a href='#' onclick='window.print(); return false;' >Print</a></li>\n";
   echo "</ul>
   </li>\n";
   if (tws_permit_action('common_actions','Refresh')) echo "<li><a href='#' onclick='location.reload(false)'>Refresh</a></li>\n";
?>
</ul>
</div>
</form>
<? tws_waiting(0); ?>
</body>
</html>
