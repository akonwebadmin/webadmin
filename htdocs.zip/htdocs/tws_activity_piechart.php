<?php
//   HORIZONT Software GmbH, Munich
//

   require_once("tws_functions.php");

   if (!isset($store_report) || $store_report!="yes"){
      tws_import_request_variables("GP","rqst_");
      $succ_count=$rqst_succ;
      $abend_count=$rqst_abend;
      $pend_count=$rqst_pend;
      $exec_count=$rqst_exec;
      $hold_count=$rqst_hold;
      $other_count=$rqst_other;
      $contents=$rqst_contents;
      $filename=tws_gpc_get($rqst_filename);
   }

   require_once("jpgraph/jpgraph.php");
   require_once("jpgraph/jpgraph_pie.php");

   $total_count=$succ_count + $abend_count + $pend_count + $exec_count + $hold_count + $other_count;

   if ($total_count == 0) {
      $graph=new PieGraph(500,200);
      $txt=new Text("  No Activity Data  ");
      $txt->SetFont(FF_FONT2,FS_BOLD);
      $txt->SetColor("red");
      $txt->SetPos(0.3,0.4,"centered");
      $txt->SetBox("white","black",true);
      $graph->AddText($txt);
   } else {

// Calculate percentages
      $succ_pct=round(($succ_count / $total_count) * 100) . "%";
      $abend_pct=round(($abend_count / $total_count) * 100) . "%";
      $pend_pct=round(($pend_count / $total_count) * 100) . "%";
      $exec_pct=round(($exec_count / $total_count) * 100) . "%";
      $hold_pct=round(($hold_count / $total_count) * 100) . "%";
      $other_pct=round(($other_count / $total_count) * 100) . "%";

// Set up array for jpgraph piechart
      switch ($contents) {
        case "completed":
          $data=array($succ_count, $abend_count, $pend_count);
          $colors=array('green', 'red', 'purple');
          break;
        case "active":
          $data=array($succ_count,$abend_count,$pend_count, $exec_count);
          $colors=array("green","red","purple", "blue");
          break;
        case "all":
          $data=array($succ_count, $abend_count, $pend_count, $exec_count, $hold_count, $other_count);
          $colors=array("green", "red", "purple", "blue", "yellow", "gray");
          break;
      }

// Create the piechart
      $graph=new PieGraph(500,200);

      $pie=new PiePlot($data);
      $pie->SetCenter(0.4);

      switch ($contents) {
        case "completed":
          $pie->SetLegends(array("Successful: $succ_count", "Abend / Fail: $abend_count", "Pend: $pend_count"));
          break;
        case "active":
          $pie->SetLegends(array("Successful: $succ_count", "Abend / Fail: $abend_count", "Pend: $pend_count", "Intro / Exec: $exec_count"));
          break;
        case "all":
          $pie->SetLegends(array("Successful: $succ_count", "Abend / Fail: $abend_count", "Pend: $pend_count", "Intro / Exec: $exec_count","Hold / Ready: $hold_count","Other: $other_count"));
          break;
      }

//FIXME: from a strange reasons the colors must be reversed to make paiechart draw it pices as required...
      //$pie->SetSliceColors(array_reverse($colors));
      $pie->SetSliceColors($colors);
      $graph->Add($pie);
   }

   if (isset($filename)) {
      if (dirname($filename)=='.') {
         $filename="$webadmin_user_home_dir/".tws_profile('auth_user_name')."/$filename";
      }
      $graph->Stroke($filename);
   } else {
      $graph->Stroke();
   }
?>