<?php 
   //ERR17367 - Unprotected folders
   header("Location: /index.php"); 
?>
