<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   require_once "tws_filters_lib.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Manage Critical Jobs Lists</title>
<?php tws_stylesheet(); ?>
<script type="text/javascript" src="checkbox_selection.js"></script>
<script type="text/javascript">
function reload_page(critical_jobs_list_select) {
   open("tws_critical_jobs_lists.php?list_number=" + critical_jobs_list_select,"_self");
}
</script>
</head>
<body>
<?
   tws_import_request_variables("GP","rqst_");
   $list_number=tws_gpc_get($rqst_list_number, 'tws_num');

   tws_set_window_title();
   $log_file_name=tws_log('', 'OPEN');
   tws_print_head('Manage Critical Jobs Lists', array('__log__' => $log_file_name, '__help__' => 'tws_critical_jobs_lists_help.php'));

/*
// list of critical job lists
   $query="SELECT listnum,listdesc FROM $schema.critical_jobs_lists ORDER BY listnum";
   db_query($webadmin_db,$query) or tws_dyer("Unable to list critical jobs lists");
   $listnum=array();
   $listdesc=array();
   $my_listnum = tws_get_user_listnums();
   while ($row=db_fetch_row($webadmin_db)) {
      if(tws_profile('is_admin') || array_key_exists($row['LISTNUM'], $my_listnum)){
         $listnum[]=$row['LISTNUM'];
         $listdesc[]=$row['LISTDESC'];
      }
   }
*/
   $my_listnum = tws_get_critical_lists(); // manage lists

   if(tws_profile('is_admin'))
      tws_get_listnums_owners($my_listnum);
tws_log(" -- tws_critical_jobs_lists.php -- my_listnum: ". var_export($my_listnum, true));
   foreach($my_listnum as $num=>$val){
      $listnum[]=$num;
      $listdesc[]=$val['desc'];
   }

   if (!isset($list_number))
      if (count($listnum)>= 1)
         $list_number=$listnum[0];

   if (isset($list_number)) {
      is_numeric($list_number) or tws_dyer("Bad list number format");
      // conect to database
      db_connect($webadmin_db, DB_PERSISTENT) or tws_dyer("Could not connect to database");
      $schema=$webadmin_db['schema'];
      $query2="SELECT workstation,jobstream,job,deadline FROM $schema.critical_jobs WHERE listnum=$list_number ORDER BY workstation,jobstream,job";
      db_query($webadmin_db,$query2) or tws_dyer("Unable to list critical jobs");
      $workstation=array();
      $jobstream=array();
      $job=array();
      $deadline=array();
      $identifier=array();
      while ($row=db_fetch_row($webadmin_db)) {
         $workstation[]=$row['WORKSTATION'];
         $jobstream[]=$row['JOBSTREAM'];
         $job[]=$row['JOB'];
         preg_match("/\d{4}-\d{2}-\d{2} (\d{2}):(\d{2}):\d{2}/",$row['DEADLINE'],$x);
         $deadline[]="$x[1]:$x[2]";
         $identifier[]="$row[WORKSTATION]#$row[JOBSTREAM].$row[JOB]";
      }
   }
   db_close($webadmin_db);
?>

<form name="critform" method="post" action="tws_critical_jobs_lists_action.php">
&nbsp;&nbsp;&nbsp;&nbsp;<b>List Number:</b>&nbsp;&nbsp;
<select name="list_number" onchange="reload_page(document.critform.list_number.options[document.critform.list_number.selectedIndex].value)" style='min-width:150px;'>

<?php

   if (count($listnum)<1) {
      echo "  <option value=\"NONE\">--- None Available ---\n";
   } else {
      for ($i=0; $i<count($listnum); $i++) {
         if($my_listnum[$listnum[$i]]['forall'])
            $forall = " (For all)";
         elseif($my_listnum[$listnum[$i]]['owner'])
            $forall = ' ('.$my_listnum[$listnum[$i]]['owner'].')';
         else $forall = '';
         if ($list_number == $listnum[$i])
            echo "  <option value=\"$listnum[$i]\" selected>".htmlspecialchars("$listdesc[$i]")."$forall\n";
         else
            echo "  <option value=\"$listnum[$i]\">".htmlspecialchars("$listdesc[$i]")."$forall\n";
      }
   }
?>

</select>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Create New List">
&nbsp;&nbsp;<input type="submit" name="action" value="Delete List">
<br><br>
<hr>

<?
   if (!isset($job) || count($job)<1) {
      echo "<p class=warning>&nbsp;&nbsp;&nbsp;No Critical Jobs Defined in List</p>\n";
   } else {
      // tws_print_check_clear_all('document.critform');
      echo '<p style="padding:0px; margin: 3px 0px;"><a class="txtIcon" style="text-decoration: none;" href="javascript:myCheckAll();">Check All</a>&nbsp;-&nbsp;<a class="txtIcon" style="text-decoration: none;" href="javascript:myClearAll();">Clear All</a></p>'."\n";
      echo "<table class=wireframe cellspacing=0 cellpadding=4>\n";
      echo "<tr class=header>\n";
      echo "<th class=wireframe>&nbsp;</th>\n";
      echo "<th class=wireframe>Workstation</th>\n";
      echo "<th class=wireframe>Jobstream</th>\n";
      echo "<th class=wireframe>Job</th>\n";
      echo "<th class=wireframe>Deadline</th>\n";
      echo "</tr>\n";

      for ($i=0; $i<count($job); $i++) {
         echo "<tr class=standard>\n";
         echo "<td class=wireframe><input type='checkbox' name='selection[]' onclick='selectCheckboxes(this);' value='".htmlspecialchars($identifier[$i])."'></td>\n";
         echo "<td class=wireframe>".htmlspecialchars($workstation[$i])."</td>\n";
         echo "<td class=wireframe>".htmlspecialchars($jobstream[$i])."</td>\n";
         echo "<td class=wireframe>".htmlspecialchars($job[$i])."</td>\n";
         echo "<td class=wireframe>".htmlspecialchars($deadline[$i])."</td>\n";
         echo "</tr>\n";
      }
      echo "</table>\n";
   }
?>

<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Add">
&nbsp;&nbsp;<input type="submit" name="action" value="Modify" disabled="disabled">
&nbsp;&nbsp;<input type="submit" name="action" value="Delete" disabled="disabled">
<br><br><br><br>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="tws_critical_jobs_report.php">Return to Critical Jobs Report</a>

</form>
<script type="text/javascript">
$(document).ready(function () {
   $('input[name$="selection[]"]').off("click");
   $('input[name$="selection[]"]').on("click", enable_actions);
});
function enable_actions(){
   // enable all
   $('input[name="action"]').prop('disabled', false);

   count = $('input[name$="selection[]"]:checked').size();

   if (count==0) {
      // disable all
      $('input[name="action"]').prop('disabled', 'disabled');
      $('input[name="action"][value="Add"]').prop('disabled', false);
      $('input[name="action"][value^="Create"]').prop('disabled', false);
   }
   //else if(count>1)
   //   $('input[name="action"][value="Modify"]').prop('disabled', 'disabled');
}

function myCheckAll(){
   $('input[type="checkbox"]').prop('checked', 'checked');
   enable_actions();
}
function myClearAll(){
   $('input[type="checkbox"]').prop('checked', false);
   enable_actions();
}

</script>

</body>
</html>
