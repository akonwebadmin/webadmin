<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");

   tws_import_request_variables("P","rqst_");
   $name = (isset($rqst_name)) ? tws_gpc_get(trim($rqst_name), 'tws_mask') : "";
   $type = (isset($rqst_type)) ? tws_gpc_get(trim($rqst_type)) : "";
   $cpu = (isset($rqst_cpu)) ? tws_gpc_get(trim($rqst_cpu), 'tws_mask') : "";
   $user = (isset($rqst_user)) ? tws_gpc_get(trim($rqst_user)) : trim($_SERVER['PHP_AUTH_USER']);
   $title = (isset($rqst_title)) ? tws_gpc_get(trim($rqst_title)) : "";
   $text = (isset($rqst_text)) ? tws_gpc_get(trim($rqst_text)) : "";
   if(isset($rqst_url) && $rqst_url!="")
      $return_url = $rqst_url;
   else
      $return_url = "tws_notes.php?type=".urlencode($type)."&cpu=".urlencode($cpu)."&name=".urlencode($name);
   $confirmed = (isset($rqst_confirmed)) ? tws_gpc_get(trim($rqst_confirmed)) : 0;
   if ($confirmed)
      $selected = $rqst_selected;
   $have_cpu=($type=='Jobstream' || $type=='Job' || $type=='Resource' || $type=='User' || $type=='Comment' || $type=='Contact Information' || $type=='Recovery Procedures');

   require($note_types_file);
   if (!isset($note_types)) {
      tws_dyer("Unable to load note types table from file '$note_types_file'.");
   }
   if(!in_array($type, $note_types))
      tws_dyer("Unsupported note type $type");
   $note_type_id = array_keys($note_types, $type);
   $note_type_id = $note_type_id[0];

?>
<html>
<head>
   <title>Create <?=htmlspecialchars($type)?> Note</title>
   <?php tws_stylesheet(); ?>
</head>
<body>
<?php tws_set_window_title(); ?>
<h1>Add <?=htmlspecialchars($type)?> Note</h1>

<?php
   if (!tws_rights(NOTES)) tws_access_denied();

   $status = true;

   db_connect($webadmin_db,DB_PERSISTENT) or tws_dyer("Cannot connect to DB.");
   $schema=$webadmin_db["schema"];

   if (!$name || !$type || !$user || !$title || !$text) {
      echo "<p class=\"warning\">Incorrect parameters for store note record to database!</p>\n";
      $status = false;
   }
   elseif(!$confirmed) {
      // Check for object existence
         $exist=0;
         switch ($type) {
            case 'Job' :
            case 'Comment' :
            case 'Contact Information' :
            case 'Recovery Procedures' :
               $dbname = tws_get_jobs($cpu, $name);
               if( $dbname!== FALSE && $dbname['job_num'] ) {
                  $exist = $dbname['job_num'];
                  $obj_name = $dbname['job_name'];
                  foreach($obj_name as $z=>$tmp)      // IWS 9.5 folders
                     if(!empty($dbname['job_folder'][$z]))
                        $obj_name[$z] = $dbname['job_folder'][$z].$obj_name[$z];
                  $obj_cpu = $dbname['job_workstation'];
               }
               else {
                  $dbname = tws_get_plan_job_list ("$cpu#@.$name");
                  $exist=$dbname['njobs'];
                  $obj_name = $dbname['job'];
                  foreach($obj_name as $z=>$tmp)      // IWS 9.5 folders
                     if(!empty($dbname['folder'][$z]))
                        $obj_name[$z] = $dbname['folder'][$z].$obj_name[$z];
                  $obj_cpu = $dbname['jobcpu'];
               }
               break;

            case 'Jobstream' :
               $dbname = tws_get_jobstreams($cpu, $name);
               if( $dbname !== FALSE && $dbname['jobstream_num'] ) {
                  $obj_name = $dbname['jobstream_name'];
                  foreach($obj_name as $z=>$tmp)      // IWS 9.5 folders
                     if(!empty($dbname['jobstream_folder'][$z]))
                        $obj_name[$z] = $dbname['jobstream_folder'][$z].$obj_name[$z];
                  $obj_cpu = $dbname['jobstream_workstation'];
                  $obj_name = array_unique($obj_name);
                  $exist = $dbname['jobstream_num'];
               }
               else {    //	PLAN
                  $dbname = tws_get_plan_jobstream_list ("$cpu#$name");
                  $exist = $dbname['nscheds'];
                  $obj_name = $dbname['schedule'];
                  $obj_cpu = $dbname['cpu'];
                  foreach($obj_name as $z=>$tmp)      // IWS 9.5 folders
                     if(!empty($dbname['jobstream_folder'][$z]))
                        $obj_name[$z] = $dbname['folder'][$z].$obj_name[$z];
               }
               break;

            case 'Workstation' :
               $dbname = tws_get_workstations($name);
               if( $dbname !== FALSE && $dbname['workstation_num'] ) {
                  $exist = $dbname['workstation_num'];
                  $obj_name = $dbname['workstation_name'];
               }
               else {
                  $dbname = tws_get_plan_workstation_list ($name);
                  $exist = $dbname['cpu_num'];
                  $obj_name = $dbname['cpu'];
               }
               break;

            case 'Workstation Class' :
               $dbname = tws_get_workstation_classes($name);
               if( $dbname !== FALSE && $dbname['workstation_class_num'] ) {
                  $exist = $dbname['workstation_class_num'];
                  $obj_name = $dbname['workstation_class_name'];
               }
               break;

            case 'Domain' :
               $dbname = tws_get_domains($name);
               if( $dbname !== FALSE && $dbname['domain_num'] ) {
                  $exist = $dbname['domain_num'];
                  $obj_name = $dbname['domain_name'];
               }
               else {
                  $dbname = tws_get_plan_domain_list ($name);
                  $exist = $dbname['domain_num'];
                  $obj_name = $dbname['domain'];
               }
               break;

            case 'Prompt' :
               $dbname = tws_get_prompts($name);
               if( $dbname !== FALSE && $dbname['prompt_num'] ) {
                  $exist = $dbname['prompt_num'];
                  $obj_name = $dbname['prompt_name'];
               }
               else {
                  $dbname = tws_get_plan_prompt_list ($name);
                  $exist = $dbname['prompt_num'];
                  $obj_name = $dbname['prompt_name'];
               }
               break;

            case 'Resource' :
               $dbname = tws_get_resources($name);
               if( $dbname !== FALSE && $dbname['resource_num'] ) {
                  $exist = $dbname['resource_num'];
                  $obj_name = $dbname['resource_name'];
                  $obj_cpu = $dbname['resource_workstation'];
               }
               else {
                  $dbname = tws_get_plan_resource_list ($name);
                  $exist = $dbname['resource_num'];
                  $obj_name = $dbname['resource'];
                  $obj_cpu = $dbname['cpu'];
               }
               break;

            case 'Calendar' :
               $dbname = tws_get_calendars($name);
               if( $dbname !== FALSE && $dbname['calendar_num'] ) {
                  $exist = $dbname['calendar_num'];
                  $obj_name = $dbname['calendar_name'];
               }
               break;

            case 'User' :
               $dbname = tws_get_users("$cpu#$name");
               if( $dbname !== FALSE && $dbname['user_num'] ) {
                  $exist = $dbname['user_num'];
                  $obj_name = $dbname['user_name'];
                  $obj_cpu = $dbname['user_workstation'];
               }
               break;

            case 'Parameter Table' :
               $dbname = tws_get_parameter_tables($name);
               if( $dbname !== FALSE && $dbname['parameter_table_num'] ) {
                  $exist = $dbname['parameter_table_num'];
                  $obj_name = $dbname['parameter_table_name'];
               }
               break;

            case 'Parameter' :
               $dbname = tws_get_parameters($name);
               if( $dbname !== FALSE && $dbname['parameter_num'] ) {
                  $exist = $dbname['parameter_num'];
                  if ($tws_config['cpuinfo']['version']<='8.4')
                     $obj_name = $dbname['parameter_name'];
                  else
                     foreach($dbname['parameter_name'] as $i=>$param)
                        $obj_name[] = $dbname['parameter_table'][$i].".".$dbname['parameter_name'][$i];
               }
               break;

            case 'Event Rule' :
               $dbname = tws_get_evrules($name);
               if( $dbname !== FALSE && $dbname['evrule_num'] ) {
                  $exist = $dbname['evrule_num'];
                  $obj_name = $dbname['evrule_name'];
               }
               break;
            // New RCG, Application
            default :
                  $exist = 1;
                  $obj_name[] = $name;
               break;
      }


      // Check for duplicate notes records
      foreach( $obj_name as $i=>$sel) {
         if ($type == "Workstation")
            $result=tws_get_notes($sel, NULL, $title, "note_type_id = $note_type_id");
         else if ($have_cpu)
            $result=tws_get_notes($obj_cpu[$i], $sel, $title, "note_type_id = $note_type_id");
         else
            $result=tws_get_notes("-", $sel, $title, "note_type_id = $note_type_id");

         if (is_array($result) && count($result)>0) {
            echo "<p class=warning>A note with the same title already exists for ".  htmlspecialchars($type) ." $sel. Unable to complete request.</p>\n";
            $status = false;
         }
      }
   }

   if ($status && $exist == 1) $confirmed = 1;

   if ($confirmed) {
      if (isset($selected)) {
         foreach($selected as $i=>$sel) {
            if($have_cpu) {
               list($obj_cpu[], $obj_name[]) = explode("#", $sel);
            }
            else {
               $obj_name[] = $sel;
            }
         }
      }

      foreach($obj_name as $i=>$sel) {

         if ($type == "Workstation") {
            $obj_name[$i] = strtoupper($obj_name[$i]);
            $query = "
            INSERT INTO $schema.notes (TSTAMP, last_updated, workstation, job, username, title, note_type_id, note_text)
            VALUES (
               CURRENT_TIMESTAMP,
               CURRENT_TIMESTAMP,
               '".db_string($webadmin_db,$obj_name[$i])."',
               '-',
               '".db_string($webadmin_db,$user)."',
               '".db_string($webadmin_db,$title)."',
               ".$note_type_id.",
               '".db_string($webadmin_db,$text)."'
            )";
         }
         else if ($cpu) {
            $obj_cpu[$i] = strtoupper($obj_cpu[$i]);
            $obj_name[$i] = strtoupper($obj_name[$i]);
            $query = "
            INSERT INTO $schema.notes (TSTAMP, last_updated, workstation, job, username, title, note_type_id, note_text)
            VALUES (
               CURRENT_TIMESTAMP,
               CURRENT_TIMESTAMP,
               '".db_string($webadmin_db,$obj_cpu[$i])."',
               '".db_string($webadmin_db,$obj_name[$i])."',
               '".db_string($webadmin_db,$user)."',
               '".db_string($webadmin_db,$title)."',
               ".$note_type_id.",
               '".db_string($webadmin_db,$text)."'
            )";
         }
         else {
            $obj_name[$i] = strtoupper($obj_name[$i]);
            $query = "
           INSERT INTO $schema.notes (TSTAMP, last_updated, workstation, job, username, title, note_type_id, note_text)
            VALUES (
               CURRENT_TIMESTAMP,
               CURRENT_TIMESTAMP,
               '-',
               '".db_string($webadmin_db,$obj_name[$i])."',
               '".db_string($webadmin_db,$user)."',
               '".db_string($webadmin_db,$title)."',
               ".$note_type_id.",
               '".db_string($webadmin_db,$text)."'
            )";
         }
         db_query($webadmin_db,$query) or tws_dyer("Create note failed");
      }
      if (isset($webadmin_db['allow_persistent']) && tws_yesno($webadmin_db['allow_persistent'])=='NO')
         db_commit($webadmin_db) or tws_dyer("Unable to COMMIT request.");

      echo "<script type='text/javascript'>\n";
      echo "window.location.replace('$return_url');\n";
      echo "</script>\n";
   }
   elseif ($status) {   // Confirmation require ( more then one object or object not exist )
      ?>
      <table border="0"><tr><td>
      <form action="tws_add_note_exec.php" method="post">
         <input type="hidden" name="name" value="<?=htmlspecialchars(strtoupper($name));?>" />
         <input type="hidden" name="type" value="<?=htmlspecialchars($type);?>" />
         <input type="hidden" name="user" value="<?=htmlspecialchars($user);?>" />
         <input type="hidden" name="title" value="<?=htmlspecialchars($title);?>" />
         <input type="hidden" name="text" value="<?=htmlspecialchars($text);?>" />
         <?php if ($have_cpu) ?>
            <input type="hidden" name="cpu" value="<?=htmlspecialchars(strtoupper($cpu));?>" />
      <?php
      if($exist==0) {   //object not exist
         $name = strtoupper($name);
         $cpu = strtoupper($cpu);
         echo "<p class=warning>No ".  htmlspecialchars($type) ." $name found.<br> Do you want to create note for ".  htmlspecialchars($type)." $name anyway?</p>\n";
      }
      elseif ($exist>1) {    // more then one object found
         if ($type=="Comment" || $type=="Contact Information" || $type=="Recovery Procedures") {
               $type_display='Job';
            } else {
               $type_display=$type;
            }
         echo 'Select '.htmlspecialchars($type_display).' to add Note<br><br>';
         foreach ($obj_name as $i=>$sel) {
            if ($have_cpu)
               echo'<input type="checkbox" name="selected[]" value="'.$obj_cpu[$i].'#'.$obj_name[$i].'" checked=""/>'.$obj_cpu[$i].'#'.$obj_name[$i].'<br/>';
            else
               echo'<input type="checkbox" name="selected[]" value="'.$obj_name[$i].'" checked=""/>'.$obj_name[$i].'<br/>';
         }
      }
      ?>
         <input type="hidden" name="url" value="<?=$return_url?>" />
         <input type="hidden" name="confirmed" value="1" /><br/>
         <input type="submit" name="action" value="Ok"/>
      </form>
      </td>
      <td valign="bottom">
      <form action="tws_add_note.php" method="post" >
         <input type="hidden" name="name" value="<?=htmlspecialchars($name);?>" />
         <input type="hidden" name="type" value="<?=htmlspecialchars($type);?>" />
         <input type="hidden" name="user" value="<?=htmlspecialchars($user);?>" />
         <input type="hidden" name="title" value="<?=htmlspecialchars($title);?>" />
         <input type="hidden" name="text" value="<?=htmlspecialchars($text);?>" />
         <?php if ($cpu) ?>
            <input type="hidden" name="cpu" value="<?=htmlspecialchars($cpu);?>" />
         <input type="hidden" name="url" value="<?=$return_url?>" />
         <input type="submit" name="action" value="Back"/>
      </form>
      </td></tr></table>
   <?php
   }
   else { ?>
      <form action="tws_add_note.php" method="post">
      <input type="hidden" name="name" value="<?=htmlspecialchars($name);?>" />
      <input type="hidden" name="type" value="<?=htmlspecialchars($type);?>" />
      <input type="hidden" name="user" value="<?=htmlspecialchars($user);?>" />
      <input type="hidden" name="title" value="<?=htmlspecialchars($title);?>" />
      <input type="hidden" name="text" value="<?=htmlspecialchars($text);?>" />
      <?php if ($cpu)  ?>
         <input type="hidden" name="cpu" value="<?=htmlspecialchars($cpu);?>" />
      <input type="hidden" name="url" value="<?=$return_url?>" />
      <input type="submit" name="action" value="Back"/>
      </form>
<?php }
   db_close($webadmin_db);
?>
</body>
</html>
