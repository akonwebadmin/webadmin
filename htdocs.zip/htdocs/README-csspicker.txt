JavaScript Date Time Picker 2.2.4
License: ../../LICENSE/CSSPICKER.txt
Local modifications:
   - added Time Zone selection possibility
   - file format converted to UNIX
   - improved intending
