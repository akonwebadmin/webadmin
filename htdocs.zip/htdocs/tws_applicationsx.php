<?php
//   HORIZONT Software GmbH, Munich
//

require_once 'tws_functions.php';
require_once 'tws_filters_lib.php';

tws_get_filter_from_get($filter, $filter_name);

tws_profile('opener', basename($_SERVER['REQUEST_URI']));

if (tws_profile('table_type')=='flextable')
   $page_size = 0;
else {
   $page_size=tws_get_page_size();
   $__keypress_handler = true;
}
   tws_set_layout('database_applications');
   $log_file_name=tws_log('', 'OPEN');

tws_doctype('t');
?>
<html>
<head>
   <title>Workload Application Definitions</title>
   <? tws_stylesheet();
      tws_save_filter_in_storage();
   ?>
   <script type="text/javascript" src="checkbox_selection.js"></script>
   <script type="text/javascript">

   function doSubmit(actionButton) {
      var action = actionButton.innerHTML;
      var form = document.displayapplications;
      form.action.value = action;

      if(action_refresh || action=='Layout'){
         form.target = '_self';
         form.submit();
      }
      else{
         var param = 'height=600, width=1000, left=60, top=50, toolbar=no, menubar=no, location=no, scrollbars=yes, resizable=yes';
         window.open('', 'tws_popup', param);
         form.target = 'tws_popup';
         form.submit();
         ClearAll(form);
      }
   }

   function displayApplication(application) {
      url = 'tws_display_application.php?arg=' + escape(application);
      tws_url_open(url, '', 800);
   }
   function displayNote(name) {
      var url = 'tws_notes.php?name=' + escape(name)+ '&type=Application&display=1';
      tws_url_open(url, '', 800);
   }
   </script>
</head>
<body onload="enable_action_buttons(); doLoaded(); restoreScroll('application');" onUnload="saveScroll('application');">
<? if (tws_profile('button_location') != 'bottom')
      echo "<div style='top:0; height:35px;'> </div>\n";
   if(tws_get_menu('Applications')==0) tws_access_denied();
   tws_set_window_title($filter_name);
   tws_waiting(1);
   tws_print_head('Workload Application Definitions', array('__filter__' => $filter, '__filter_name__' => $filter_name, '__log__' => $log_file_name));

   $filter_url = '<a class="txtIcon" href="tws_dbapplication_filter.php">F</a>';

   tws_log('-- START ('.basename(__FILE__).'['.__LINE__.'])');
   $execution_time = tws_getmicrotime();

   //   Create where condition
   $arg = '@';
   $xfilter  = tws_dbfilter_where ($filter, 'BHA_NAME');
   if ($xfilter == false)
      tws_err('Wrong filter format');
   else
      if (($applications = tws_get_applications($arg, $xfilter, $page_size, isset($_GET['page']) ? $_GET['page'] : 1)) === false)
         tws_dyer('Unable to get list of applications');

   foreach ($applications as $key => $value) {
      tws_log() && tws_log('Result \$'.$key.' = '.@var_export($value, true).';');
      $$key = $value;
   }

   // Notes
   if(in_array('Notes',$layout_column)) {
      $result=tws_get_notes_exist('-', '@', "note_type_id=17");
      foreach($applications['app_name'] as $i=>$name) {
         if(isset($result[$name]))
            $notes[$i] = "<a href='javascript:displayNote(\"$name\");'><img src='images/icons/note.gif' border=0></a>";
      }
      unset($result);
   }

   $execution_time = tws_getmicrotime() - $execution_time;
   tws_print_head('Workload Application Definitions', array('__filter__' => $filter, '__filter_name__' => $filter_name, '__time__' => $execution_time, '__log__' => $log_file_name, '__count__' => $app_num, '__navigation__' => array($app_num, $filter_url)));

   echo '<form method="post" name="displayapplications" action="tws_applications_action.php">'."\n";
   if ($app_num == 0) {
      echo '<p class="warning">No qualified entries.</p>'."\n";
   } else {
      tws_print_check_clear_all('document.displayapplications')."\n";
      echo '<table class="wireframe dtable" id="sortable" cellspacing="0" cellpadding="4" width="100%">'."\n";
      echo '<thead><tr class="header">'."\n";
      echo '<th width="1">&nbsp;</th>';
      foreach ($layout_column as $column) {
         echo '<th title="'.$column.'">'.tws_html_column_header($column).'</th>'."\n";
      }
      echo '</tr></thead>'."\n";

      if ($page_size) {
         $page = isset($_GET['page']) ? $_GET['page'] : 1;
         $offset = 1 + ($page - 1) * $page_size;
      } else {
         $offset = 1;
      }
      foreach ($app_name as $i => $tmp) {
         echo '<tr class="standard" title="['.($i + $offset).']">'."\n";
         echo '<td><input type="checkbox" name="selection[]" value="'.$app_name[$i].'" onclick="selectCheckboxes(this);"></td>';
         for ($c = 0; $c < count($layout_column); $c++) {
            switch ($layout_column[$c]) {
               case 'Application':
                  echo '<td><a href="javascript:displayApplication(\''.$app_name[$i].'\');">'.$app_name[$i].'</a></td>';
                  break;
               case 'Description':
                  echo '<td>'.(trim($app_description[$i]) == '' ? ' ' : htmlspecialchars($app_description[$i])).'</td>';
                  break;
               case 'Creator':
                  echo '<td>'.$app_creator[$i].'</td>';
                  break;
               case 'Last Update':
                  echo '<td>'.tws_iso_to_userdate($app_last_updated[$i], null, FALSE, $composer_db['tz']).'</td>';
                  break;
               case 'Lock':
                  echo '<td>'.$app_lock_by[$i].' '.tws_iso_to_userdate($app_lock_on[$i], null, FALSE, $composer_db['tz']).'</td>';
                  break;
               case 'Notes':
                  echo '<td align="center">'.$notes[$i].'</td>';
                  break;
            }
         }
         echo '</tr>'."\n";
      }
      echo '</table>'."\n";
      tws_print_navigation($app_num, $filter_url);
   }
   tws_log('-- FINISH ('.basename(__FILE__).'['.__LINE__.'])', 'CLOSE');
?>
<input type='hidden' name='action' value=''>
<input type='hidden' name='arg' value='<?=htmlspecialchars($filter)?>'>

<div class='buttons'>
<ul class="menu">
   <li><a href="#" onclick="return false;">Filter</a>
      <ul>
         <li><a href="tws_dbapplication_filter.php?arg=<?=urlencode($filter)?>">Set Filter</a></li>
         <li><a href="tws_dbapplication_filter.php?arg=<?=urlencode($filter)?>#load">Load Filter</a></li>
         <? if ($filter){
            echo '<li><a href="#" id="Save_Filter" onclick="doSubmit(this)">Save Filter</a></li>';
            echo '<li><a href="tws_dbapplication_filter_action.php?action=Clear Filter&reset">Clear Filter</a></li>';
         }
         tws_draw_saved_filters('dbapplication');
         ?>
      </ul>
   </li>
<? /*Artem: In fact, Workload Applications (WA) are used by IBM for export/import
   "workload automation solution so that the solution can be reused in one or more other IWS environments".
   So it contain not only jobstreams list, but huge of other information, e.g. dependencies, jobs in each stream, run cycles etc.
   i.e. after WA creating you have .zip file which can be used in another system

   So I can use WA created by TDWC, but TDWC raise an error for my WA.

   Possible solutions:
    - Remove possibility to Add/Modify WA

   echo "<li><a href='#' onclick='return false;'>Actions</a>
   <ul>";
   if (tws_permit_action('database_applications','Add')) echo "<li><a href='#' onclick='doSubmit(this); return false;' class='actions' id='Add'>Add</a></li>\n";
   if (!isset($app_num) || ($app_num > 0)) {
      if (tws_permit_action('database_applications','Modify'))    echo "<li><a href='#' onclick='doSubmit(this); return false;' class='actions' id='Modify'>Modify</a></li>\n";
      if (tws_permit_action('database_applications','Rename'))    echo "<li><a href='#' onclick='doSubmit(this); return false;' class='actions' id='Rename'>Rename</a></li>\n";
      if (tws_permit_action('database_applications','Delete'))    echo "<li><a href='#' onclick='doSubmit(this); return false;' class='actions' id='Delete'>Delete</a></li>\n";
      if (tws_permit_action('database_applications','Unlock'))    echo "<li><a href='#' onclick='doSubmit(this); return false;' class='actions' id='Unlock'>Unlock</a></li>\n";
   }
   echo"</ul>
   </li>";
   */
   if (!isset($app_num) || ($app_num > 0)) {
      echo"<li><a href='#' onclick='return false;'>Display</a>
      <ul>\n";
      if (tws_permit_action('database_applications','Display')) echo "<li><a href='#' onclick='doSubmit(this); return false;' class='actions' id='Display'>Definition</a></li>\n";
      if (tws_permit_action('database_domains','Notes'))     echo "<li><a href='#' onclick='doSubmit(this); return false;' class='actions' id='Notes'>Notes</a></li>\n";
      echo"</ul>
      </li>";
   }
   echo "<li><a href='#' onclick='return false;'>Settings</a>
   <ul>";
   if (tws_permit_action('common_actions','Layout'))  echo "<li><a href='#' onclick='doSubmit(this); return false;' >Layout</a></li>\n";
   if (tws_permit_action('common_actions','Print'))   echo "<li><a href='#' onclick='doSubmit(this); return false;' >Print</a></li>\n";
   echo "</ul>
   </li>\n";
   if (tws_permit_action('common_actions','Refresh')) echo "<li><a href='#' onclick='location.reload(false)'>Refresh</a></li>\n";
?>
</ul>
</div>
<? tws_waiting(0); ?>
</form>
</body>
</html>
