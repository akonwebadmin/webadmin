<?php
require_once "twazy_lib.php";

$twazy_folder = substr(dirname($_SERVER["PHP_SELF"]), 1);

$twazy_mode = function_exists('twaz_is_dev') ? (twaz_is_dev() ? 'DEV' : 'PROD') : 'PROD';

$es = twazy_stripslashes_array(twazy_get("es"));
$es_folder = "es$es";

$graph_type   = twazy_get('type');
$g_type       = (strtoupper($graph_type) === "STMON" ? "STMON" : "NETPLAN");
$syntok       = twazy_get('__hwi_syntok');
$version      = file_get_contents("version.info");
$log_level    = twazy_get('log_level');
$twazy_id     = twazy_get('twazy_id');
$action       = twazy_get('action');

if ($twazy_mode == "DEV") {
    twazy_prepare_lib("copy");
} else {
    twazy_prepare_lib("rename");
}

$data_source = twazy_load_data_source($twazy_id);

if (!isset($data_source)) {
    echo twazy_translate("Invalid_request._Please_try_again,_analyse_the_logs_or_contact_your_administrator.");
    twazy_log($twazy_id, "error", "Wrong twazy id");
    exit();
}

$lib_folder   = "lib$version";

if ($g_type == "STMON") {
    require_once '../twaz_stmon_func.php';

    $stmtname     = $data_source["param"]['stmtname'];

    $ok    = true;
    $range = "";
    $iat = $iaf  = "";
    $iaf   = "";
    $error = array();
    $param = array();

    $handle = twaz_db_conn($tws_db);
    if (!$handle) {
        echo stmon_log_error($error_msg['connection_failed']);
        $ok = false;
    }

    $stmon_treechart_running = stmon_treechart_running($stmtname);
    if ($ok) {
        stmon_dbg(1, $info_msg['connection_established']);

        $sql = "SELECT stmiadf,stmiatf,stmadjfrom,stmiadt,stmiatt,stmadjto " .
            "FROM " . stmon_table("stmconfig") . " " .
            "WHERE stmtname='" . db_string($tws_db, $stmtname) . "'";
        if (!stmon_db_query($tws_db, $sql, $msg, __FILE__, __LINE__)) { //when the query was not completed successfully
            $ok       = false;
            $error[] = stmon_log_error($error_msg['fatal']);
            if ($msg != "")
                $error[] = stmon_log_error($msg);
        } //when the query was not completed successfully
        else { //when the query was completed successfully
            $row = db_fetch_row($tws_db);
            if (($row['STMIADF'] !== null && $row['STMIATF'] !== null) ||
                ($row['STMIADT'] !== null && $row['STMIATT'] !== null)
            ) {
                $range = "[";
                if ($row['STMIADF'] != "" && $row['STMIATF'] != "") {
                    list($year, $month, $day) = explode("-", stmon_corr_db_to_form($row["STMIADF"], "date"));
                    $date   = "$day.$month.$year";
                    $time   = stmon_corr_db_to_form($row["STMIATF"], "time");
                    $range .= "$date $time";
                    $iaf    = $row["STMIADF"] . $row["STMIATF"];
                }
                $range .= " - ";
                if ($row['STMIADT'] != "" && $row['STMIATT'] != "") {
                    list($year, $month, $day) = explode("-", stmon_corr_db_to_form($row["STMIADT"], "date"));
                    $date   = "$day.$month.$year";
                    $time   = stmon_corr_db_to_form($row["STMIATT"], "time");
                    $range .= "$date $time";
                    $iat    = $row["STMIADT"] . $row["STMIATT"];
                }
                $range .= "]";
            }
        } //when the query was completed successfully
        twaz_db_close($tws_db);
    }

    if ($iat != "") {
        list($yeart, $montht, $dayt) = explode("-", stmon_corr_db_to_form(substr($iat, 0, 6), "date"));
        list($hourt, $mint)          = explode(":", stmon_corr_db_to_form(substr($iat, -4),   "time"));
    }

    if ($iaf != "") {
        list($yearf, $monthf, $dayf) = explode("-", stmon_corr_db_to_form(substr($iaf, 0, 6), "date"));
        list($hourf, $minf)          = explode(":", stmon_corr_db_to_form(substr($iaf, -4),   "time"));
    }
}

$page = new twazy_page($g_type == "NETPLAN" ? twazy_translate("Netplan") : (twazy_translate("Status_Monitor_Tree") . ' ' . $stmtname . ' ' . $range));
$page->set_doctype('HTML5');
$page->set_parent_frame(false);
$g_type !== "NETPLAN" && $page->set_timeout(0);

$js = ["../$twazy_folder/config/config.js", "../$twazy_folder/$lib_folder/$es_folder/lib.js"];

if ($twazy_mode == "DEV") {
    $js[] = "../$twazy_folder/ide-support/yfiles-typeinfo.js";
    $js[] = "../$twazy_folder/demos/resources/filesystem-warning.js";
}
if ($es == 5) {
    $js[] = "../es6-promise/es6-promise.min.js";
    $js[] = "../es6-promise/es6-promise.auto.min.js";
}
$page->set_js($js);

$page->set_css(["../$twazy_folder/css/yfiles.css", "../$twazy_folder/css/style.css"]);
$page->print_head();

twazy_prepare_dictionary();
?>

<script type="text/javascript">
    if (typeof waiHideProgressBar === "function") {
        waiHideProgressBar();
    }
    var twazyFolder = <?= json_encode($twazy_folder); ?>;
    var twazyId = <?= json_encode($twazy_id); ?>;
    var twazyMode = <?= json_encode($twazy_mode); ?>;
    var libFolder = <?= json_encode($lib_folder); ?>;

    var logText = "";
    var logNavigatorUserAgent = false;
    var logLevel = <?= $log_level !== null ? $log_level : 'config["log_level"]' ?>;
    var inputXML = false;
    var originalXML = false;
    var dataSources = <?= json_encode($data_source); ?>;

    var twazyVersion = <?= json_encode($version); ?>;

    twazyInitNetstat();

    function isSupportedColorInput() {
        twazyDebug("-->");
        var input;

        input = $('<input type="color" value="!" />')[0];

        if (input.type === 'color' && input.value !== '!') {
            twazyDebug("<--", "true");
            return true;
        } else {
            twazyDebug("<--", "false");
            return false;
        }
    };

    function isSupportedSVGForeignObject() {
        twazyDebug("-->");
        if ((typeof SVGForeignObjectElement !== 'undefined')) {
            twazyDebug("<--", "true");
            return true;
        } else {
            twazyDebug("<--", "false");
            return false;
        }
    };

    function isSupportedES6() {
        twazyDebug("-->");
        //"use strict";

        if (typeof Symbol == "undefined") {
            twazyDebug("<--", "false (symbol is undefined)");
            return false;
        }

        try {
            eval("class Foo {}");
            eval("var bar = (x) => x+1");
        } catch (e) {
            twazyDebug("<--", "false");
            return false;
        }
        twazyDebug("<--", "true");
        return true;
    };

    var isSupportedSVGForeignObject = isSupportedSVGForeignObject();
    var isSupportedColorInput = isSupportedColorInput();
    var isSupportedES6 = isSupportedES6();

    progressBar('Loading', 'Loading');
</script>
<?php

twazy_load_config();

echo "<script type='text/javascript'>";
if ($g_type == "STMON") {
    echo "var stmonTreechartRunning = " . json_encode($stmon_treechart_running) . ";";
    echo "var urlParamStmtname = " . json_encode($data_source["param"]["stmtname"]) . ";";
}
if ($g_type == "NETPLAN") {
    $areload_interval = twazy_get('reload');
    echo "var areloadEnable = false;";
    echo "var areloadInterval = 0;";
    echo "var reloadTimeout = false;";
    if ($areload_interval >= 1 && $areload_interval <= 1440) {
        echo "areloadEnable = true;";
        echo "areloadInterval = " . json_encode($areload_interval) . ";";
    }
}

echo "</script>";
?>
<?php
if ($g_type == "STMON" && $stmon_treechart_running) {
?>
    <script type="text/javascript">
        stmonTreechartRunning = <?php echo json_encode($stmon_treechart_running); ?>;

        function iaSyn(ia_type) {
            $.post("../twaz_stmon_ajax.php", {
                action: "IA_syn",
                stmtname: urlParamStmtname,
                __hwi_syntok: window.hwi_syntok
            }, function(data) {
                var response = $(data);
                var date = response.filter('#date').text().split(",");
                var time_php = new Date(date[0], date[1], date[2], date[3], date[4], date[5], 0);
                var iat = new Date(response.filter('#iat_year').text(),
                    parseInt(response.filter('#iat_month').text()) - 1,
                    response.filter('#iat_day').text(),
                    response.filter('#iat_hour').text(),
                    response.filter('#iat_minute').text(),
                    0,
                    0);
                var iaf = new Date(response.filter('#iaf_year').text(),
                    parseInt(response.filter('#iaf_month').text()) - 1,
                    parseInt(response.filter('#iaf_day').text()) + 1,
                    response.filter('#iaf_hour').text(),
                    response.filter('#iaf_minute').text(),
                    0,
                    0);
                if (ia_type == "iaf") {
                    ia = iaf;
                } else {
                    ia = iat;
                }
                var time = ia - time_php;

                document.title = response.filter('#title').text();
                if (time > 0) {
                    var syn = setTimeout(function() {
                        iaSyn(ia_type)
                    }, time + 15000);
                } else {
                    var syn = setTimeout(function() {
                        iaSyn(ia_type)
                    }, 60 * 1000); //1min
                }
            });


        }

        <?php
        if ($iat != "" && $iaf != "") {
        ?>
            $(document).ready(function() {
                var time_php = new Date(<?php echo date("Y,") . (date("n") - 1) . date(",j,G,i,s"); ?>, 0);
                var iat = new Date(<?php echo $yeart; ?>,
                    parseInt(<?php echo $montht; ?>) - 1,
                    <?php echo $dayt; ?>,
                    <?php echo $hourt; ?>,
                    <?php echo $mint; ?>,
                    0,
                    0);
                var iaf = new Date(<?php echo $yearf; ?>,
                    parseInt(<?php echo $monthf; ?>) - 1,
                    parseInt(<?php echo $dayf; ?>) + 1,
                    <?php echo $hourf; ?>,
                    <?php echo $minf; ?>,
                    0,
                    0);

                //timer for IA from
                var time = iaf - time_php;

                if (time > 0) {
                    var syn = setTimeout(function() {
                        iaSyn("iaf")
                    }, time + 15000);
                } else {
                    var syn = setTimeout(function() {
                        iaSyn("iaf")
                    }, 60 * 1000); //1min
                }

                //timer for IA to
                var time = iat - time_php;

                if (time > 0) {
                    var syn = setTimeout(function() {
                        iaSyn("iat")
                    }, time + 15000);
                } else {
                    var syn = setTimeout(function() {
                        iaSyn("iat")
                    }, 60 * 1000); //1min
                }
            });
        <?php
        }
        ?>
    </script>
<?php
}
?>
<?php
if ($g_type == "NETPLAN") {
?>
    <script type="text/javascript">
        $(document).ready(function() {
            if (areloadEnable) {
                if (areloadInterval >= 1 && areloadInterval <= 1440) {
                    reload(areloadInterval);
                }
            }
        });
    </script>
<?php
}
?>
<div id="for-calculating-size-of-nodes" style="display:none; padding: 0; margin: 0">
</div>

<div id="component-toolbar">
    <span id="component-toolbar-icon-file" class="component-toolbar-buttonws"><?= twazy_translate("File"); ?> <span id="component-toolbar-buttonws-submenu-file" class='component-toolbar-buttonws-submenu'></span></span>
    <?php
    if ($g_type == "STMON" && !$stmon_treechart_running) {
    ?>
        <span id="component-toolbar-icon-edit" class="component-toolbar-buttonws" data-used-in="STMON"><?= twazy_translate("Edit"); ?> <span id="component-toolbar-buttonws-submenu-edit" class='component-toolbar-buttonws-submenu'></span></span>
    <?php
    }
    ?>
    <span id="component-toolbar-icon-search" class="component-toolbar-buttonws"><?= twazy_translate("Search"); ?> <span id="component-toolbar-buttonws-submenu-search" class='component-toolbar-buttonws-submenu'></span></span>
    <span id="component-toolbar-icon-options" class="component-toolbar-buttonws"><?= twazy_translate("Options"); ?> <span id="component-toolbar-buttonws-submenu-options" class='component-toolbar-buttonws-submenu'></span></span>
    <span class="component-toolbar-separator"></span>
    <button id="component-toolbar-icon-zoomIn" data-command="ZoomIn" title="<?= twazy_translate("Zoom_In"); ?>"></button>
    <button id="component-toolbar-icon-zoomOriginal" data-command="ZoomOriginal" title="<?= twazy_translate("Zoom_to_original_size"); ?>"></button>
    <button id="component-toolbar-icon-zoomOut" data-command="ZoomOut" title="<?= twazy_translate("Zoom_Out"); ?>"></button>
    <button id="component-toolbar-icon-zoomFitContent" data-command="FitContent" title="<?= twazy_translate("Fit_Content"); ?>"></button>
    <span class="component-toolbar-separator"></span>

    <span id="component-toolbar-icon-html" class="component-toolbar-button" data-used-in="STMON"><?= twazy_translate("View_html"); ?></span>
    <span id="component-toolbar-icon-runlog" class="component-toolbar-button" data-used-in="STMON"><?= twazy_translate("View_runlog"); ?></span>
    <span class="component-toolbar-separator" data-used-in="STMON"></span>
    <span data-used-in="NETPLAN_TIMELINE"><?= twazy_translate("Time_axis"); ?></span>
    <select id="component-toolbar-timeaxis" data-used-in="NETPLAN_TIMELINE">
        <option value="off" selected="selected"><?= twazy_translate("Off"); ?></option>
        <option value="s"><?= twazy_translate("Second"); ?></option>
        <option value="min"><?= twazy_translate("Minute"); ?></option>
        <option value="h"><?= twazy_translate("Hour"); ?></option>
        <option value="d"><?= twazy_translate("Day"); ?></option>
        <option value="w"><?= twazy_translate("Week"); ?></option>
        <option value="2w"><?= twazy_translate("Two_weeks"); ?></option>
        <option value="m"><?= twazy_translate("Month"); ?></option>
        <option value="q"><?= twazy_translate("Quarter"); ?></option>
        <option value="y/2"><?= twazy_translate("Half_year"); ?></option>
        <option value="y"><?= twazy_translate("Year"); ?></option>
        <option value="2y"><?= twazy_translate("Two_years"); ?></option>
    </select>
    <span class="component-toolbar-separator" data-used-in="NETPLAN_TIMELINE"></span>
    <span id="reload-timer"></span>
    <span id="reload-separator" class="component-toolbar-separator"></span>

    <span class="component-toolbar-tab-default component-toolbar-tab-current" data-component-tab="default"><?= $g_type == "NETPLAN" ? twazy_translate("Netplan") : $data_source["param"]["stmtname"]; ?></span>
</div>


<div id="component-overview-section-default">
    <div class="component-overview-header"><?= twazy_translate("Overview"); ?></div>
    <div id="component-overview-body-default"></div>
</div>
<div id="timeline-graph-default" class="timeline-graph" data-used-in="NETPLAN_TIMELINE"></div>

<div id="component-graph-default" class="component-graph"></div>


<ul id="file-submenu" class="component-toolbar-submenu">
    <li id="file-submenu-open">
        <div><?= twazy_translate("Open"); ?></div>
    </li>
    <li id="file-submenu-save">
        <div><?= twazy_translate("Save"); ?></div>
    </li>
    <li id="file-submenu-reload">
        <div><?= twazy_translate("Reload"); ?></div>
    </li>
    <li id="file-submenu-areload" data-used-in="NETPLAN_TIMELINE">
        <div><?= twazy_translate("Automatic_reload"); ?></div>
    </li>
    <li>-</li>
    <li id="file-submenu-close">
        <div><?= twazy_translate("Close_page"); ?></div>
    </li>
    <li id="file-submenu-closeall">
        <div><?= twazy_translate("Close_all_pages"); ?></div>
    </li>
    <li>-</li>
    <li id="file-submenu-print">
        <div><?= twazy_translate("Print"); ?></div>
    </li>
    <li id="file-submenu-exportgraphic">
        <div><?= twazy_translate("Export_graphic"); ?></div>
    </li>
</ul>

<ul id="search-submenu" class="component-toolbar-submenu">
    <li>-</li>
    <li id="search-submenu-criticalpath" data-used-in="NETPLAN_TIMELINE">
        <div><?= twazy_translate("Critical_path"); ?></div>
    </li>
    <li id="search-submenu-cycles" data-used-in="NETPLAN NETPLAN_TIMELINE">
        <div><?= twazy_translate("Cycles"); ?></div>
    </li>
    <li id="search-submenu-rlinks" data-used-in="NETPLAN NETPLAN_TIMELINE">
        <div><?= twazy_translate("Redundant_links"); ?></div>
    </li>
    <li id="search-submenu-reset">
        <div><?= twazy_translate("Reset"); ?></div>
    </li>
</ul>

<ul id="options-submenu" class="component-toolbar-submenu">
    <li id="options-submenu-nodestyle">
        <div><?= twazy_translate("Node_marking_style"); ?></div>
    </li>
    <li id="options-submenu-linkstyle" data-used-in="NETPLAN NETPLAN_TIMELINE">
        <div><?= twazy_translate("Link_marking_style"); ?></div>
    </li>
    <!--<li class="ui-state-disabled"><div><?= twazy_translate("Progress_dialog"); ?></div></li>
            <li class="ui-state-disabled"><div><?= twazy_translate("Advanced_options"); ?></div></li>-->
    <li>-</li>
    <li id="options-submenu-versioninfo">
        <div><?= twazy_translate("Version_info"); ?></div>
    </li>
</ul>

<ul id="edit-submenu" class="component-toolbar-submenu">
    <li id="edit-submenu-insertgroup">
        <div><?= twazy_translate("Insert_group"); ?></div>
    </li>
    <li>-</li>
    <li id="edit-submenu-arrange">
        <div><?= twazy_translate("Arrange"); ?></div>
    </li>
</ul>

<div id="dialog-file-open" title="<?= twazy_translate("Open"); ?>">
    <form>
        <table class='hwiLayout border' width='100%'>
            <tr>
                <td style='font-weight:bolder'><?= twazy_translate("XML_file"); ?></td>
                <td><input id="dialog-file-open-file" type="file"></td>
            </tr>
        </table>
    </form>
</div>


<div id="dialog-options-nodestyle" title="<?= twazy_translate("Node_marking_style"); ?>">
    <form>
        <table class='hwiLayout border' width='100%'>
            <tr>
                <td style='font-weight:bolder'><?= twazy_translate("Background_color"); ?></td>
                <td><input id="dialog-options-nodestyle-bgcolor" type="color"></td>
            </tr>
            <tr>
                <td style='font-weight:bolder'><?= twazy_translate("Line_color"); ?></td>
                <td><input id="dialog-options-nodestyle-linecolor" type="color"></td>
            </tr>
            <tr>
                <td style='font-weight:bolder'><?= twazy_translate("Line_type"); ?></td>
                <td><select id="dialog-options-nodestyle-linetype"></select></td>
            </tr>
        </table>
        <hr>
        <table class='hwiLayout border' width='100%'>
            <tr>
                <td style='font-weight:bolder'><?= twazy_translate("Show_result_in_a_list"); ?></td>
                <td><input id="dialog-options-nodestyle-showlist" type="checkbox"></td>
            </tr>
            <?php
            if ($g_type == "NETPLAN") {
            ?>
                <tr>
                    <td style='font-weight:bolder'><?= twazy_translate("Show_found_nodes_as_new_graphic"); ?></td>
                    <td><input id="dialog-options-nodestyle-showgraphic" type="checkbox"></td>
                </tr>
            <?php
            }
            ?>
            <tr>
                <td style='font-weight:bolder'><?= twazy_translate("Dont_show_this_dialog_again"); ?></td>
                <td><input id="dialog-options-nodestyle-dontshowdialog" type="checkbox"></td>
            </tr>
        </table>
    </form>
</div>

<div id="dialog-options-linkstyle" title="<?= twazy_translate("Link_marking_style"); ?>">
    <form>
        <table class='hwiLayout border' width='100%'>
            <tr>
                <td style='font-weight:bolder'><?= twazy_translate("Line_color"); ?></td>
                <td><input id="dialog-options-linkstyle-linecolor" type="color"></td>
            </tr>
            <tr>
                <td style='font-weight:bolder'><?= twazy_translate("Line_type"); ?></td>
                <td><select id="dialog-options-linkstyle-linetype"></select></td>
            </tr>
        </table>
        <hr>
        <table class='hwiLayout border' width='100%'>
            <tr>
                <td style='font-weight:bolder'><?= twazy_translate("Show_result_in_a_list"); ?></td>
                <td><input id="dialog-options-linkstyle-showlist" type="checkbox"></td>
            </tr>
            <tr>
                <td style='font-weight:bolder'><?= twazy_translate("Dont_show_this_dialog_again"); ?></td>
                <td><input id="dialog-options-linkstyle-dontshowdialog" type="checkbox"></td>
            </tr>
        </table>
    </form>
</div>

<?php
if ($g_type == "NETPLAN") {
?>
    <div id="dialog-contextmenu-clustering" title="<?= twazy_translate("Set_the_cluster_type"); ?>">
    </div>
<?php
}
?>

<div id="dialog-contextmenu-linkdetails" title="<?= twazy_translate("Detailed_information"); ?>">
</div>

<div id="dialog-resultlist-criticalpath" title="<?= twazy_translate("Critical_path"); ?>">
</div>

<?php
if ($g_type == "NETPLAN") {
?>
    <div id="dialog-contextmenu-find" title="<?= twazy_translate("Specify_predecessor_and/or_successor_level"); ?>">
        <form>
            <table class='hwiLayout border' width='100%'>
                <tr>
                    <td style='font-weight:bolder'><?= twazy_translate("Predecessor_level"); ?></td>
                    <td><input id="dialog-contextmenu-find-pred" type="number" value="999" min="-1" max="1000"></td>
                    <td><?= twazy_translate("(1_-_999,_999_=_no_limit)"); ?></td>
                </tr>
                <tr>
                    <td style='font-weight:bolder'><?= twazy_translate("Successor_level"); ?></td>
                    <td><input id="dialog-contextmenu-find-succ" type="number" value="999" min="-1" max="1000"></td>
                    <td><?= twazy_translate("(1_-_999,_999_=_no_limit)"); ?></td>
                </tr>
            </table>
        </form>
    </div>
<?php
}
?>
<?php
if ($g_type == "STMON") {
?>
    <div id="dialog-move" title="<?= twazy_translate("Move"); ?>">
        <form>
            <table class='hwiLayout border' width='100%'>
                <tr>
                    <td>
                        <span id="dialog-move-below"><input name="dialog-move" type="radio" checked="checked" value="below"> <?= twazy_translate("Below_the_node"); ?><br></span>
                        <input name="dialog-move" type="radio" value="behind"> <?= twazy_translate("Behind_the_node"); ?><br>
                        <input name="dialog-move" type="radio" value="in-front-of"> <?= twazy_translate("In_front_of_the_node"); ?>
                    </td>
                </tr>
            </table>
        </form>
    </div>
    <div id="dialog-duplicate" title="<?= twazy_translate("Duplicate"); ?>">
        <form>
            <table class='hwiLayout border' width='100%'>
                <tr>
                    <td>
                        <span id="dialog-duplicate-below"><input name="dialog-duplicate" type="radio" checked="checked" value="below"> <?= twazy_translate("Below_the_node"); ?><br></span>
                        <input name="dialog-duplicate" type="radio" value="behind"> <?= twazy_translate("Behind_the_node"); ?><br>
                        <input name="dialog-duplicate" type="radio" value="in-front-of"> <?= twazy_translate("In_front_of_the_node"); ?>
                    </td>
                </tr>
            </table>
        </form>
    </div>
<?php
}
?>
<div id="dialog-contextmenu-legend" title="<?= twazy_translate("Legend"); ?>">
    <div id="dialog-contextmenu-legend-componentgraph"></div>
</div>

<div id="dialog-resultlist-nodes" title="<?= twazy_translate("Search_result_-_nodes"); ?>">
    <table id="dialog-resultlist-nodes-table" class='hwiLayout waiBorder waiNowrap cmp' style='width:100%'>
    </table>
</div>

<div id="dialog-resultlist-links" title="<?= twazy_translate("Search_result_-_links"); ?>">
    <table id="dialog-resultlist-links-table" class='hwiLayout waiBorder waiNowrap cmp' style='width:100%'>
    </table>
</div>

<div id="dialog-search-criticalpath" title="<?= twazy_translate("Searching_for_the_critical_path"); ?>">
    <form>
        <table class='hwiLayout border' width='100%'>
            <tr>
                <td style='font-weight:bolder'><?= twazy_translate("Time"); ?></td>
                <td>
                    <input name="dialog-search-criticalpath-time" type="radio" checked="checked" value="duration"> <?= twazy_translate("Duration"); ?><br>
                    <input name="dialog-search-criticalpath-time" type="radio" value="end-time"> <?= twazy_translate("End_time"); ?>
                </td>
            </tr>

            <tr>
                <td style='font-weight:bolder'><?= twazy_translate("Type"); ?></td>
                <td>
                    <input name="dialog-search-criticalpath-type" type="radio" checked="checked" value="all-operations"> <span id="dialog-search-criticalpath-type-all"><?= twazy_translate("All_Operations"); ?></span><br>
                    <input name="dialog-search-criticalpath-type" type="radio" value="non-completed"> <span id="dialog-search-criticalpath-type-non"><?= twazy_translate("Non_completed"); ?></span>
                </td>
            </tr>
        </table>
    </form>
</div>
<div id="dialog-file-areload" title="<?= twazy_translate("Automatic_reload"); ?>">
    <form>
        <table class='hwiLayout border' width='100%'>
            <tr>
                <td style='font-weight:bolder'><?= twazy_translate("Enable_automatic_reload"); ?></td>
                <td><input id="dialog-file-areload-enable" type="checkbox"></td>
            </tr>

            <tr>
                <td style='font-weight:bolder'><?= twazy_translate("Enter_the_reload_interval"); ?></td>
                <td><input id="dialog-file-areload-interval" type="number" value="1" min="-1" max="1441"></td>
            </tr>
        </table>
    </form>
</div>

<script src="<?= $lib_folder ?>/require.js" type="text/javascript"></script>
<script type="text/javascript">
    $("#component-toolbar-timeaxis").val(config["timeline"]["axis"]);

    $("#dialog-file-areload").dialog({
        autoOpen: false,
        /*show: {
          effect: "size",
          duration: 500
        },
        hide: {
          effect: "size",
          duration: 500
        },*/
        minWidth: 400,
        maxHeight: $(window).height() * 0.95,
        modal: true,
        buttons: [{
                text: "<?= twazy_translate("OK"); ?>",
                click: function() {
                    twazyDebug("--> #dialog-file-areload - button OK");

                    areloadEnable = $("#dialog-file-areload-enable").is(':checked');
                    areloadInterval = parseInt($("#dialog-file-areload-interval").val());
                    areloadInterval = isNaN(areloadInterval) ? 1 : areloadInterval;

                    if (areloadEnable) {
                        reload(areloadInterval);
                    } else {
                        stopReload();
                    }

                    $(this).dialog("close");

                    twazyDebug("<-- #dialog-file-areload - button OK");
                }
            },
            {
                text: "<?= twazy_translate("Cancel"); ?>",
                click: function() {
                    twazyDebug("--> #dialog-file-areload - button Cancel");

                    $(this).dialog("close");

                    twazyDebug("<-- #dialog-file-areload - button Cancel");
                }
            }
        ]
    });

    $("#dialog-xml").dialog({
        autoOpen: false,
        /*show: {
          effect: "size",
          duration: 500
        },
        hide: {
          effect: "size",
          duration: 500
        },*/
        width: $(window).width() * 0.95,
        height: $(window).height() * 0.95,
        modal: true,
        buttons: [{
                text: "<?= twazy_translate("Save_and_close"); ?>",
                click: function() {
                    twazyDebug("--> #dialog-xml - button Save and close");

                    download("TWAZ.xml", "text/csv", "charset=utf-8", "data:text/csv;charset=utf-8," + encodeURIComponent($("#dialog-xml-textarea").val()));
                    $(this).dialog("close");

                    twazyDebug("<-- #dialog-xml - button Save and close");
                }
            },
            {
                text: "<?= twazy_translate("Save"); ?>",
                click: function() {
                    twazyDebug("--> #dialog-xml - button Save");

                    download("TWAZ.xml", "text/csv", "charset=utf-8", "data:text/csv;charset=utf-8," + encodeURIComponent($("#dialog-xml-textarea").val()));

                    twazyDebug("<-- #dialog-xml - button Save");
                }
            },
            {
                text: "<?= twazy_translate("Close"); ?>",
                click: function() {
                    twazyDebug("--> #dialog-xml - button Close");

                    $(this).dialog("close");

                    twazyDebug("<-- #dialog-xml - button Close");
                }
            }
        ]
    });

    $("#dialog-question").dialog({
        autoOpen: false,
        /*show: {
            effect: "size",
            duration: 500
        },
        hide: {
            effect: "size",
            duration: 500
        },*/
        width: "auto",
        maxHeight: $(window).height() * 0.95,
        modal: true
    });

    if (isSupportedES6) {
        var esFolder = 'es6';
    } else {
        var esFolder = 'es5';
    }

    $("#component-toolbar-buttonws-submenu-file").on("click", function(e) {
        twazyDebug("--> #component-toolbar-buttonws-submenu-file - click");

        e.stopPropagation();

        $("#file-submenu").menu().toggle().position({
            my: "left top",
            at: "left bottom+2px",
            of: $(this).parent(),
            collision: "fit flip"
        });
        $("#search-submenu").hide();
        $("#options-submenu").hide();
        $("#edit-submenu").hide();

        twazyDebug("<-- #component-toolbar-buttonws-submenu-file - click");
    });
    $("#component-toolbar-buttonws-submenu-search").on("click", function(e) {
        twazyDebug("--> #component-toolbar-buttonws-submenu-search - click");

        e.stopPropagation();

        $("#search-submenu").menu().toggle().position({
            my: "left top",
            at: "left bottom+2px",
            of: $(this).parent(),
            collision: "fit flip"
        });
        $("#file-submenu").hide();
        $("#options-submenu").hide();
        $("#edit-submenu").hide();

        twazyDebug("<-- #component-toolbar-buttonws-submenu-search - click");
    });
    $("#component-toolbar-buttonws-submenu-options").on("click", function(e) {
        twazyDebug("--> #component-toolbar-buttonws-submenu-options - click");

        e.stopPropagation();

        $("#options-submenu").menu().toggle().position({
            my: "left top",
            at: "left bottom+2px",
            of: $(this).parent(),
            collision: "fit flip"
        });
        $("#file-submenu").hide();
        $("#search-submenu").hide();
        $("#edit-submenu").hide();

        twazyDebug("<-- #component-toolbar-buttonws-submenu-options - click");
    });
    $("#component-toolbar-buttonws-submenu-edit").on("click", function(e) {
        twazyDebug("--> #component-toolbar-buttonws-submenu-edit - click");

        e.stopPropagation();

        $("#edit-submenu").menu().toggle().position({
            my: "left top",
            at: "left bottom+2px",
            of: $(this).parent(),
            collision: "fit flip"
        });
        $("#file-submenu").hide();
        $("#search-submenu").hide();
        $("#options-submenu").hide();

        twazyDebug("<-- #component-toolbar-buttonws-submenu-edit - click");
    });

    $(document).on("click", function(e) {
        //twazyDebug("--> document - click");

        $("#file-submenu").hide();
        $("#search-submenu").hide();
        $("#options-submenu").hide();
        $("#edit-submenu").hide();

        //twazyDebug("<-- document - click");
    });

    require.config({
        baseUrl: libFolder
    });
    require(['umd/complete', esFolder + '/netstat', 'license/license.js'], function(yfiles, app) {
        app.init();
        app.run('<?php echo $g_type; ?>');
    });

    $("#file-submenu-areload").on("click", function(e) {
        twazyDebug("--> #file-submenu-areload - click");

        $("#dialog-file-areload").dialog("open");

        twazyDebug("<-- #file-submenu-areload - click");
    });

    $("#dialog-contextmenu-find-pred, #dialog-contextmenu-find-succ, #dialog-file-areload-interval").change(function() {
        twazyDebug("--> #" + $(this).attr("id") + " - change");

        var val = $(this).val();
        var min = parseInt($(this).attr("min"));
        var max = parseInt($(this).attr("max"));

        if (val <= min) {
            $(this).val(max - 1);
        } else if (val >= max) {
            $(this).val(min + 1);
        }

        twazyDebug("<-- #" + $(this).attr("id") + " - change");
    });

    initTabAction();

    function initTabAction() {
        twazyDebug("-->");

        $('#component-toolbar').on("click", ".component-toolbar-tab-close", function(e) {
            twazyDebug("--> .component-toolbar-tab-close - click");

            var componentTab = $(this).parent().data("component-tab");

            var ok = function() {
                removeGraph(componentTab);
            }
            confirmDialog(twazy_translate("Do_you_really_want_to_close_this_panel?"), ok);
            e.stopPropagation();

            twazyDebug("<-- .component-toolbar-tab-close - click");
        });

        $('#component-toolbar').on("click", ".component-toolbar-tab-default, .component-toolbar-tab", function() {
            twazyDebug("--> ." + $(this).attr('class') + " - click");

            componentToolbarTabClick($(this));

            twazyDebug("<-- ." + $(this).attr('class') + " - click");
        });

        twazyDebug("<--");
    };

    function componentToolbarTabClick(element) {
        twazyDebug("-->");

        var componentTab = element.data("component-tab");

        switchGraph(componentTab);

        $(".component-toolbar-tab, .component-toolbar-tab-default").removeClass("component-toolbar-tab-current");
        element.addClass("component-toolbar-tab-current");

        twazyDebug("<--");
    }

    function switchGraph(switchedTab) {
        twazyDebug("-->");

        backupActualGraph();

        var graphId = "#component-graph-" + switchedTab;
        var overviewId = "#component-overview-section-" + switchedTab;

        hideOverview();
        hideGraph();
        showGraph(graphId);
        if ($(overviewId).data("hidden") === undefined || $(overviewId).data("hidden") == 0) {
            showOverview(overviewId);
        }

        graphComponentSelector = graphId;

        graphComponent = graphComponents[graphId];
        cpGroups = pGroups[graphId];
        cpNodes = pNodes[graphId];
        cpLinks = pLinks[graphId];
        cHighlightedNodes = highlightedNodes[graphId];
        cHighlightedLinks = highlightedLinks[graphId];
        cClustering = clustering[graphId];
        cUsedClustering = usedClustering[graphId];

        if (timeLineMode) {
            var timelineId = "#timeline-graph-" + switchedTab;
            hideTimeline();
            showTimeline(timelineId);
            timelineGraphComponent = timelineGraphComponents[graphId];
            $("#component-toolbar-timeaxis").val(timeAxiss[graphComponentSelector]);
        }

        twazyDebug("<--");
    }

    function hideOverview(overviewId) {
        twazyDebug("-->");

        if (overviewId === undefined) {
            overviewId = "[id*='component-overview-section-']"; //ALL
        }
        $(overviewId).hide();

        twazyDebug("<--");
    }

    function showOverview(overviewId) {
        twazyDebug("-->");

        if (overviewId !== undefined) {
            $(overviewId).show();
        }

        twazyDebug("<--");
    }

    function hideGraph(graphId) {
        twazyDebug("-->");

        if (graphId === undefined) {
            graphId = ".component-graph, .component-graph-withtimeline, .component-graph-withtimeline-toptobottom"; //ALL
        }
        $(graphId).hide();

        twazyDebug("<--");
    }

    function showGraph(graphId) {
        twazyDebug("-->");

        if (graphId !== undefined) {
            $(graphId).show();
        }

        twazyDebug("<--");
    }

    function hideTimeline(graphId) {
        twazyDebug("-->");

        if (graphId === undefined) {
            graphId = ".timeline-graph, .timeline-graph-toptobottom"; //ALL
        }
        $(graphId).hide();

        twazyDebug("<--");
    }

    function showTimeline(graphId) {
        twazyDebug("-->");

        if (graphId !== undefined) {
            $(graphId).show();
        }

        twazyDebug("<--");
    }

    function getActualTab() {
        twazyDebug("-->");

        var actualTab = $(".component-toolbar-tab-current").data("component-tab");

        twazyDebug("<--", actualTab);
        return actualTab;
    }

    function removeGraph(tab) {
        twazyDebug("-->");

        if (tab != "default") {
            var graphId = "#component-graph-" + tab;
            var overviewId = "#component-overview-section-" + tab;
            var timelineId = "#timeline-graph-" + tab;
            var tabButton = $(".component-toolbar-tab[data-component-tab='" + tab + "']");
            var actualTab = false;

            if (tab == getActualTab()) {
                actualTab = tabButton.prev().data("component-tab");
            }

            graphComponents[graphId].cleanUp();
            graphOverviewComponents[graphId].cleanUp();
            $(graphId).remove();
            $(overviewId).remove();
            tabButton.remove();

            graphComponents[graphId] = undefined;
            pGroups[graphId] = undefined;
            pNodes[graphId] = undefined;
            cHighlightedNodes = undefined;
            cHighlightedLinks = undefined;
            cClustering = undefined;
            cUsedClustering = undefined;

            if (timelineGraphComponents[graphId] !== undefined) {
                timelineGraphComponents[graphId].cleanUp();
                $(timelineId).remove();
                timelineGraphComponents[graphId] = undefined;
            }

            if (actualTab !== false) {
                componentToolbarTabClick($(".component-toolbar-tab[data-component-tab='" + actualTab + "'], .component-toolbar-tab-default[data-component-tab='" + actualTab + "']"));
            }
        } else {
            showMessage("error", twazy_translate("It_is_not_allowed_to_delete_this_(default)_panel."));
        }

        twazyDebug("<--");
    }

    function backupActualGraph() {
        twazyDebug("-->");

        //backup
        var actualTab = getActualTab();
        var actualGraphId = "#component-graph-" + actualTab;
        highlightedNodes[actualGraphId] = cHighlightedNodes;
        highlightedLinks[actualGraphId] = cHighlightedLinks;
        clustering[actualGraphId] = cClustering;
        usedClustering[actualGraphId] = cUsedClustering;
        graphComponents[actualGraphId] = graphComponent;
        pGroups[actualGraphId] = cpGroups;
        pNodes[actualGraphId] = cpNodes;
        pLinks[actualGraphId] = cpLinks;

        if (timeLineMode) {
            timelineGraphComponents[actualGraphId] = timelineGraphComponent;
        }

        twazyDebug("<--");
    }

    function reload(mins) {
        twazyDebug("-->");

        $("#reload-timer").show();
        $("#reload-separator").css('display', 'inline-block');
        $("#reload-timer").data("start", mins);
        $("#reload-timer").data("mins", mins);
        $("#reload-timer").data("secs", 0);

        reloadTimer();

        twazyDebug("<--");
    }

    function updateQueryStringParameter(uri, key, value) {
        twazyDebug("-->");

        var re = new RegExp("([?&])" + key + "=.*?(&|$)", "i");
        var separator = uri.indexOf('?') !== -1 ? "&" : "?";
        var uUri;
        if (uri.match(re)) {
            uUri = uri.replace(re, '$1' + key + "=" + value + '$2');
        } else {
            uUri = uri + separator + key + "=" + value;
        }

        twazyDebug("<--", uUri);
        return uUri;
    }


    function reloadTimer() {
        twazyDebug("-->");

        var $timer = $("#reload-timer");

        var mins = $timer.data("mins");
        var secs = $timer.data("secs");
        if (mins == 0 && secs == 0) {
            twazyDebug("<--", "mins and secs are 0");

            var a = document.createElement('a');
            a.href = updateQueryStringParameter(window.location.href, "reload", $timer.data("start"));
            window.location.href = a.href;

            return;
        }

        if (secs || mins) {
            reloadTimeout = setTimeout(reloadTimer, 1000);
        }
        secs -= 1;
        if (secs < 0) {
            mins -= 1;
            secs = 59;
        }
        $timer.text((mins.toString().length < 2 ? "0" + mins : mins) + ":" + (secs.toString().length < 2 ? "0" + secs : secs)); // Pad number
        $timer.data("mins", mins);
        $timer.data("secs", secs);

        twazyDebug("<--");
    }

    function stopReload() {
        twazyDebug("-->");

        if (reloadTimeout !== false) {
            clearTimeout(reloadTimeout);

            reloadTimeout = false;
        }

        $("#reload-timer").hide();
        $("#reload-separator").hide();
        $("#reload-timer").data("mins", 0);
        $("#reload-timer").data("secs", 0);

        twazyDebug("<--");
    }

    function graphicUpdate(update) {
        twazyDebug("-->");

        require(['umd/complete', esFolder + '/netstat', 'license/license.js'], function(yfiles, app) {
            app.graphicUpdate(update);
        });

        twazyDebug("<--");
    }

    function showMessage(type, text, title) {
        twazyDebug("-->");

        var dialogId = false;
        switch (type) {
            case "info":
                dialogId = "#dialog-information";
                break;
            case "error":
                dialogId = "#dialog-error";
                break;
            case "warning":
                dialogId = "#dialog-warning";
                break;
            case "success":
                dialogId = "#dialog-success";
                break;
        }
        if (dialogId != false) {
            $(dialogId + "-text").html(text);
            $(dialogId).dialog("open");
        }

        twazyDebug("<--");
    }

    function twazy_docroot(path) {
        if (typeof hwi_docroot === "function") {
            return hwi_docroot(path);
        }

        return path;
    }

    if (window.hwi_syntok === undefined) {
        window.hwi_syntok = "without_hwi";
    }
</script>
<?php
$page->print_foot();
