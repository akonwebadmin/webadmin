(function(r){(function(f){if('function'==typeof define&&define.amd){define(['umd/lang'],function(lang){f(lang.yfiles);});}else{f(r.yfiles||(r.yfiles={}));}}(/*@yjs:keep*/function(yfiles) {
  yfiles.license = {
    "company": "HORIZONT Software GmbH",
    "contact": "Lukas Linhart",
    "date": "11/04/2019",
    "developer": "Lukas Linhart (llinhart@horizont-it.com)",
    "distribution": true,
    "domains": [
      "*"
    ],
    "email": "llinhart@horizont-it.com",
    "fileSystemAllowed": true,
    "licensefileversion": "1.1",
    "localhost": true,
    "oobAllowed": true,
    "package": "complete",
    "product": "yFiles for HTML",
    "subscription": "12/04/2020",
    "type": "singledeveloper",
    "version": "2.2",
    "key": "323433000b2307288a16fccacb3c850958d22cd7"
}}));}('undefined'!=typeof window?window:'undefined'!=typeof global?global:'undefined'!=typeof self?self:this));