<?php
if (file_exists(dirname(__FILE__) . '/../twaz_lib.php')) {
    require_once dirname(__FILE__) . '/../twaz_lib.php';
}

if (file_exists(dirname(__FILE__) . '/../tws_functions.php')) {
    require_once dirname(__FILE__) . '/../tws_functions.php';
}

define('TWAZY_DS', DIRECTORY_SEPARATOR);

function twazy_stripslashes_array($data)
{
    if (get_magic_quotes_gpc()) {
        if (is_array($data)) {
            foreach ($data as $key => $value) {
                $data[$key] = twazy_stripslashes_array($value);
            }
            return $data;
        } else {
            return stripslashes($data);
        }
    }
    return $data;
}

function twazy_get($key)
{
    if (array_key_exists($key, $_GET)) {
        if (get_magic_quotes_gpc()) {
            return stripslashes($_GET[$key]);
        } else {
            return $_GET[$key];
        }
    }

    return null;
}

function twazy_post($key)
{
    if (array_key_exists($key, $_POST)) {
        if (get_magic_quotes_gpc()) {
            return stripslashes($_POST[$key]);
        } else {
            return $_POST[$key];
        }
    }

    return null;
}

function twazy_session($name, $value = null)
{
    if (function_exists("wai_session")) {
        if ($value === null) {
            return wai_session($name);
        } else {
            wai_session($name, $value);
            return;
        }
    } else {
        if ($value === null) {
            return $_SESSION[$name];
        } else {
            $_SESSION[$name] = $value;
            return;
        }
    }
}

function twazy_set_data_source($url, $parameters)
{
    $twazy_id = uniqid();
    $twazy_session = twazy_session("twazy");
    $twazy_session["data_source"][$twazy_id] = [
        "url" => $url,
        "param" => $parameters
    ];
    twazy_session("twazy", $twazy_session);

    return $twazy_id;
}

function twazy_load_data_source($twazy_id)
{
    $twazy_session = twazy_session("twazy");
    return $twazy_session["data_source"][$twazy_id];
}

function twazy_translate($key)
{
    if (function_exists("hwi_translate")) {
        return hwi_translate("twazy_$key");
    } else {
        $keyr = preg_replace("/_/", " ", $key);
        return $keyr;
    }
}

function twazy_log($twazy_id, $log_type, $log, $local_time = false, $user_agent = false)
{
    global $hwi_config, $tws_config;

    $twazy_session = twazy_session("twazy");
    if (!isset($twazy_session["log_file"][$twazy_id])) {
        $twazy_session["log_file"][$twazy_id] = date('Y-m-d-H-i-s');
        twazy_session("twazy", $twazy_session);
    }

    $log_dir = isset($hwi_config['log_dir']) ? $hwi_config['log_dir'] : $tws_config['webadmin_log_dir'];
    $log_file = rtrim($log_dir, "\\/") . "/twazy-" . $twazy_session["log_file"][$twazy_id] . ".log";

    if ($local_time === false) {
        $local_time = date('Y-m-d H:i:s');
    }

    if ($user_agent != "false" && $user_agent != false) {
        @error_log(date('Y-m-d H:i:s') . " / $local_time --- " . str_pad("[" . $log_type . "]", 7) . " User agent header: " . $user_agent . "\r\n", 3, $log_file);
    }

    @error_log(date('Y-m-d H:i:s') . " / $local_time --- " . str_pad("[" . $log_type . "]", 7) . " " . $log . "\r\n", 3, $log_file);
}

function print_twazy_switch($twazy_type, $data_source_url, $data_source_parameters)
{
    global $twaz_config, $tws_config;
    $twaz_graphic_display = isset($twaz_config["graphic_display"]) ? $twaz_config["graphic_display"] : (isset($tws_config["graphic_display"]) ? $tws_config["graphic_display"] : "AX=>JS");

    if (function_exists("hwi_new_syntok")) {
        $data_source_parameters["__hwi_syntok"] = hwi_new_syntok('ID', 0);
    }

    $twazy_id = twazy_set_data_source($data_source_url, $data_source_parameters);

    if ($twazy_type == "barchart") {
        $href = "twazy/barchart.php?twazy_id=$twazy_id";
    } else {
        $href = "twazy/index.php?type=$twazy_type&twazy_id=$twazy_id";
    }
    if (function_exists("hwi_new_syntok")) {
        $href .= "&" . hwi_new_syntok('QUERY', 0);
    }

    echo "<div " . ($twaz_graphic_display != "AX|JS" ? "style='display:none'" : "") . "><a id='a-graphic-display' href='$href'>" . twazy_translate("Graphic_module_JS/SVG") . "</a><br><br></div>";

    echo '<script type="text/javascript">
            function isSupportedES6() {
                "use strict";

                if (typeof Symbol == "undefined") {
                    return false;
                }

                try {
                    eval("class Foo {}");
                    eval("var bar = (x) => x+1");
                } catch (e) {
                    return false;
                }

                return true;
            };
            if (!isSupportedES6()) {
                $("#a-graphic-display").attr("href", $("#a-graphic-display").attr("href") + "&es=5");
            } else {
                $("#a-graphic-display").attr("href", $("#a-graphic-display").attr("href") + "&es=6");
            }
            var twaz_graphic_display = "' . $twaz_graphic_display . '";
            if (twaz_graphic_display == "JS") {
                window.location.href = $("#a-graphic-display").attr("href");
            }
            if (twaz_graphic_display == "AX=>JS") {
                if ("ActiveXObject" in window) {

                } else {
                    window.location.href = $("#a-graphic-display").attr("href");
                }
            }
        </script>';
}

function twazy_prepare_dictionary()
{
    echo '<script type="text/javascript">';
    echo 'var twazyDictionary = {};';
    echo 'var useDictionary = false;';
    if (twazy_session('wai_dictionary') !== null) {
        echo "useDictionary = true;";
        foreach (twazy_session('wai_dictionary') as $key => $value) {
            if (substr($key, 0, 6) == "twazy_") {
                echo "twazyDictionary['$key']=" . json_encode($value) . ";";
            }
        }
    }
    echo '</script>';
}

function twazy_load_config()
{
    $netplan_options = twazy_session('netplan_options');
    $wai_options     = twazy_session('wai_options');
    if (!isset($netplan_options["show_xml_from_file"]) || !is_bool($netplan_options["show_xml_from_file"])) {
        $netplan_options["show_xml_from_file"] = false;
    }
    if (!isset($netplan_options["show_xml_from_server"]) || !is_bool($netplan_options["show_xml_from_server"])) {
        $netplan_options["show_xml_from_server"] = false;
    }

    echo "<script type='text/javascript'>";
    echo "var showXMLFromFile = " . json_encode($netplan_options["show_xml_from_file"]) . ";";
    echo "var showXMLFromServer = " . json_encode($netplan_options["show_xml_from_server"]) . ";";
    echo "var version = " . json_encode($version) . ";";
    echo "var dateFormat = " . json_encode(isset($wai_options["date_format"]) ? $wai_options["date_format"] : ((function_exists("tws_user_date_format") && tws_user_date_format('') !== null) ? tws_user_date_format('') : "DD-MM-YYYY")) . ";";
    echo "</script>";
}

function twazy_get_lib_dirs($directory)
{
    $dirs = [];
    $dirs["main_lib"] = false;
    $f = dir($directory);
    while (FALSE !== ($entry = $f->read())) {
        if ($entry != '.' && $entry != '..' && !is_file($entry) && substr($entry, 0, 3) == "lib") {
            if ($entry == "lib") {
                $dirs["main_lib"] = true;
            } else {
                $dirs["ver_lib"][$entry] = true;
            }
        }
    }
    $f->close();
    return $dirs;
}

function twazy_unlink_recursive($directory)
{
    $f = @dir($directory);
    if ($f !== false) {
        while (FALSE !== ($entry = $f->read())) {
            if ($entry == '.' || $entry == '..') {
                continue;
            }
            if (is_dir($directory . TWAZY_DS . $entry)) {
                twazy_unlink_recursive($directory . TWAZY_DS . $entry);
            }
            if (is_file($directory . TWAZY_DS . $entry)) {
                @unlink($directory . TWAZY_DS . $entry);
            }
        }
        $f->close();
        @rmdir($directory);
    }

    return true;
}

function twazy_copy_recursive($src, $dst)
{
    $f = @dir($src);
    if ($f !== false) {
        @mkdir($dst);
        while (FALSE !== ($entry = $f->read())) {
            if (($entry != '.') && ($entry != '..')) {
                if (is_dir($src . TWAZY_DS . $entry)) {
                    twazy_copy_recursive($src . TWAZY_DS . $entry, $dst . TWAZY_DS . $entry);
                } else {
                    copy($src . TWAZY_DS . $entry, $dst . TWAZY_DS . $entry);
                }
            }
        }
        $f->close();
    }
}

function twazy_prepare_lib($action = "rename")
{
    $version = file_get_contents("version.info");

    $directory = dirname(__FILE__);
    $libs = twazy_get_lib_dirs($directory);
    if ($libs["main_lib"]) {
        //remove all version libraries
        foreach ($libs["ver_lib"] as $libver => $true) {
            twazy_unlink_recursive($directory . TWAZY_DS . $libver);
        }

        if ($action == "copy") {
            //copy from lib to lib$ver
            twazy_copy_recursive($directory . TWAZY_DS . "lib", $directory . TWAZY_DS . "lib$version");
        }

        if ($action == "rename") {
			//rename from lib to lib$ver
            rename($directory . TWAZY_DS . "lib", $directory . TWAZY_DS . "lib$version");
        }                    
    }
}

//------------------------------- C L A S S E S --------------------------------

class twazy_page
{

    private $wai_page;
    private $js;
    private $css;
    private $title;

    public function __construct($title = false)
    {
        if (class_exists("wai_page")) { //TWAZ
            $this->wai_page = new wai_page($title);
        } else {                        //TWAD
            $this->wai_page = null;
        }

        $this->js = [];
        $this->css = [];
        $this->title = $title;
    }

    public function set_doctype($doctype)
    {
        if ($this->wai_page !== null) {
            $this->wai_page->set_doctype($doctype);
        }
    }

    public function set_parent_frame($parent_frame)
    {
        if ($this->wai_page !== null) {
            $this->wai_page->set_parent_frame($parent_frame);
        }
    }

    public function set_timeout($timeout)
    {    //only STMON in TWAz
        if ($this->wai_page !== null) {
            $this->wai_page->set_timeout($timeout);
        }
    }

    public function set_js($js)
    {
        if ($this->wai_page !== null) {
            $this->wai_page->set_js($js);
        } else {
            $this->js = $js;
        }
    }

    public function set_css($css)
    {
        if ($this->wai_page !== null) {
            $this->wai_page->set_css($css);
        } else {
            $this->css = $css;
        }
    }

    public function print_head()
    {
        if ($this->wai_page !== null) {
            $this->wai_page->print_head();
        } else {
            echo '<!DOCTYPE HTML>';
            echo '<html lang="en">';
            echo '<head>';
            echo '<meta http-equiv="content-type" content="text/html; charset=utf-8"/>';
            echo '<meta http-equiv="X-UA-Compatible" content="IE=edge"/>';
            echo '<title>' . $this->title . '</title>';
            foreach ($this->css as $file) {
                echo '<link rel="stylesheet" type="text/css" href="' . $file . '?mt=' . filemtime($file) . '"/>';
            }
            foreach ($this->js as $file) {
                echo '<script type="text/javascript" src="' . $file . '?mt=' . filemtime($file) . '"></script>';
            }
            //jquery
            echo '<script type="text/javascript" src="../jquery/js/jquery-3.3.1.min.js"></script>';

            //jquery UI
            echo '<link rel="stylesheet" type="text/css" href="../jquery/css/smoothness/v1.11.4/jquery-ui.min.css"/>';
            echo '<script type="text/javascript" src="../jquery/js/jquery-ui-1.11.4.custom.min.js"></script>';
            echo '<script type="text/javascript" src="../jquery/js/jquery.migrate-3.0.1.js"></script>';

            //TWAD css
            echo '<link rel="stylesheet" type="text/css" href="../default.css?mt=' . filemtime("../default.css") . '"/>';

            echo '</head>';
            echo '<body>';
        }
    }

    public function print_foot()
    {
        if ($this->wai_page !== null) {
            $this->wai_page->print_foot();
        } else {
            echo '</body>';
            echo '</html>';
        }
    }
}
