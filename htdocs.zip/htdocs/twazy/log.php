<?php

if (isset($_SERVER["HTTP_X_REQUESTED_WITH"]) && ($_SERVER["HTTP_X_REQUESTED_WITH"] == "XMLHttpRequest")) {
    require_once "twazy_lib.php";


    $twazy_id = twazy_post("twazyId");
    $log = twazy_post("log");
    $log_type = twazy_post("type");
    $local_time = twazy_post("localTime");
    $user_agent = twazy_post("userAgent");

    twazy_log ($twazy_id, $log_type, $log, $local_time, $user_agent);
} else {

}
