var config = {
    node: {
        frame_shape: {
           rounded: {
               rx: 1/4,            //The rx and the ry attributes rounds the corners of the rectangle
               ry: 1/4,            //The rx and the ry attributes rounds the corners of the rectangle
               calc_rx_from: "H",   //rx will be calculated from height of table (H) - rx*height, width of table (W) - rx*width or value will be in px - rx
               calc_ry_from: "H"    //ry will be calculated from height of table (H) - ry*height, width of table (W) - ry*width or value will be in px - ry
           },
           ellipse : {

           },
           arrow_left: {
               modification: 1/3,   //The x-distance of vertex from table
               calc_mod_from: "H"   //Modification will be calculated from height of table (H) - modification*height, width of table (W) - modification*width or value will be in px - modification
           },
           arrow_right: {
               modification: 1/3,   //The x-distance of vertex from table
               calc_mod_from: "H"   //Modification will be calculated from height of table (H) - modification*height, width of table (W) - modification*width or value will be in px - modification
           },
           parallelogram: {
               modification: 1/2,   //The x-distance of vertex from table
               calc_mod_from: "H"   //Modification will be calculated from height of table (H) - modification*height, width of table (W) - modification*width or value will be in px - modification
           },
           pointed: {
               modification: 1/4,   //The x-distance of vertex from table
               calc_mod_from: "H"   //Modification will be calculated from height of table (H) - modification*height, width of table (W) - modification*width or value will be in px - modification
           },
           triangle_left: {
               modification: 1/2,   //The y-distance of vertex from table
               calc_mod_from: "H"   //Modification will be calculated from height of table (H) - modification*height, width of table (W) - modification*width or value will be in px - modification
           },
           equi_triangle_up: {
               modification: 1/2,   //The y-distance of vertex from table
               calc_mod_from: "H"   //Modification will be calculated from height of table (H) - modification*height, width of table (W) - modification*width or value will be in px - modification
           }
        }
    },
    node_shadow: {
        x: 5,           //position x shifting shadow compared to the node
        y: 5,           //position y shifting shadow compared to the node
        color: "black", //color of shadow "color_name"/"R;G;B"/"node" - e.g. "black"/"155;195;255"/"node" (when using of key word node, it will be used background color of node)
        opacity : 0.5   //opacity of shadow
    },
    highlighting: {
        node: {
            line_type: {
                solid: "Solid",
                dashed: "Dashed",
                dotted: "Dotted",
                dashed_dotted: "Dashed_and_dotted"
            },
            background_color: {
                "#FF0000": "red",
                "#008000": "green",
                "#0000FF": "blue",
                "#FFFF00": "yellow",
                "#FF00FF": "fuchsia",
                "#00FFFF": "aqua",
                "#800000": "maroon",
                "#FFFFFF": "white",
                "#C0COCO": "silver",
                "#808080": "gray",
                "#000000": "black",
                "#FFA500": "orange",
                "#808000": "olive",
                "#800080": "purple",
                "#00FF00": "lime",
                "#008080": "teal",
                "#000080": "navy"
            },
            line_color: {
                "#FF0000": "red",
                "#008000": "green",
                "#0000FF": "blue",
                "#FFFF00": "yellow",
                "#FF00FF": "fuchsia",
                "#00FFFF": "aqua",
                "#800000": "maroon",
                "#FFFFFF": "white",
                "#C0COCO": "silver",
                "#808080": "gray",
                "#000000": "black",
                "#FFA500": "orange",
                "#808000": "olive",
                "#800080": "purple",
                "#00FF00": "lime",
                "#008080": "teal",
                "#000080": "navy"
            },
            default: {
                background_color: "#008000",//default background color for highlighting
                line_color: "#FF0000",      //default line color for highlighting
                line_type: "solid"          //default line type for highlighting
            }
        },
        link: {
            line_type: {
                solid: "Solid",
                dashed: "Dashed",
                dotted: "Dotted",
                dashed_dotted: "Dashed_and_dotted"
            },
            line_color: {
                "#FF0000": "red",
                "#008000": "green",
                "#0000FF": "blue",
                "#FFFF00": "yellow",
                "#FF00FF": "fuchsia",
                "#00FFFF": "aqua",
                "#800000": "maroon",
                "#FFFFFF": "white",
                "#C0COCO": "silver",
                "#808080": "gray",
                "#000000": "black",
                "#FFA500": "orange",
                "#808000": "olive",
                "#800080": "purple",
                "#00FF00": "lime",
                "#008080": "teal",
                "#000080": "navy"
            },
            default: {
                line_color: "#0000FF",  //default line color for highlighting
                line_type: "dashed"     //default line type for highlighting
            }
        }
    },
    flow_group: {
        row_insets: 10,     //padding
        column_insets: 10,  //padding
        min_row_size: 0,
        min_column_size: 0,
        "stroke-color": "black",
        "stroke-width": 1
    },
    timeline: {                 //sizez in 100%
        height: 30,             //css (height+top[graph]) must be changed with it!!! - left to right
        "margin-top": 0,        //css (height+top[graph]) must be changed with it!!! - left to right
        width: 160,             //css (width+left[graph]) must be changed with it!!! - top to bottom
        "margin-left": 0,       //css (width+left[graph]) must be changed with it!!! - top to bottom
        "padding-left": 9,
        "stroke-color": "black",
        "stroke-width": 1,
        "font-size": 12,
        axis: "off"
    },
    log_level : 0,              //0 - off, 1 - log, 2 - debug, 3 - trace
    overview: {
        default: {
            show: false
        }
    },
    barchart: {
        table_area: {
            group_styles: {
                default: {
                    background_color: "white",
                    text_color: "black",
                    alignment: "left",
                    expandable: true,
                    font_name: "Arial",
                    font_size: 12, //px
                    font_italic: false,
                    font_bold: false,
                    font_underlined: false,
                    font_strikethrough: false,
                    padding: 5
                }
            },
            data_line_styles: {
                default: {
                    default_group_color: "#808080",
                    background_color: "white",
                    text_color: "black",
                    font_name: "Arial",
                    font_size: 12, //px
                    font_italic: false,
                    font_bold: false,
                    font_underlined: false,
                    font_strikethrough: false
                }
            },
            header:  {
                default: {
                    line_color: "black",
                    background_color: "#C0C0C0",
                    text_color: "black",                    
                    width: 80, //px
                    alignment: "left",
                    font_name: "Arial",
                    font_size: 12, //px
                    font_italic: false,
                    font_bold: false,
                    font_underlined: false,
                    font_strikethrough: false
                }
            }
        },
        bar_area: {
            default: {
                background_color: "white",
                header_background_color_top: "white",
                header_background_color_bottom: "white",
                header_text_color_top: "black",
                header_text_color_bottom: "black",
                line_color: "black",
                font_name_top: "Arial",
                font_size_top: 10, //px
                font_italic_top: false,
                font_bold_top: false,
                font_underlined_top: false,
                font_strikethrough_top: false,
                font_name_bottom: "Arial",
                font_size_bottom: 10, //px
                font_italic_bottom: false,
                font_bold_bottom: false,
                font_underlined_bottom: false,
                font_strikethrough_bottom: false
            },
            bar_styles: {
                default: {
                    background_color: "blue",
                    text_color: "black",
                    line_color: "black",
                    line_type: "solid",
                    alignment: "center",
                    percent_height: 80,
                    font_name: "Arial",
                    font_size: 10, //px
                    font_italic: false,
                    font_bold: false,
                    font_underlined: false,
                    font_strikethrough: false
                }   
            }            
        },
        histogram_area: {
            default: {
                histogram_height: 300, //px
                minValue: 10,
                valueMaxMul: [2,2.5,2]
            }, 
            curve_styles: {
                default: {
                    line_color: "black",
                    fill_color: "black"
                }   
            },
            graph_styles: {
                default: {
                    background_color: "transparent",
                    line_color: "black",
                    text_color: "black",
                    legend_color: "black",
                    box_background_color: "transparent",
                    box_text_color: "black",
                    box_shade_color: "black",
                    box_padding: 10, //px
                    font_name_text: "Arial",
                    font_size_text: 10, //px
                    font_italic_text: false,
                    font_bold_text: false,
                    font_underlined_text: false,
                    font_strikethrough_text: false,
                    font_name_legend: "Arial",
                    font_size_legend: 10, //px
                    font_italic_legend: false,
                    font_bold_legend: false,
                    font_underlined_legend: false,
                    font_strikethrough_legend: false
                }   
            }               
        }            
    },
    dash_array: {
        dashed:         "8 4",
        dotted:         "1 2",
        dashed_dotted:  "12 2 1 2",
        solid:          "0",
        0:              "0",
        1:              "8 4",
        2:              "1 2",
        3:              "3 1",
        4:              "4 2",
        5:              "7 3",
        6:              "7 7",
        7:              "3 3",
        8:              "5 3",
        9:              "11 1 3 1 3 1 3 1",
        10:             "8 1 1 1 1 1 1 1",
        11:             "9 1 2 1 2 1",
        12:             "9 1 1 1 1 1",
        13:             "12 1 3 1",
        14:             "10 1 1 2",
        15:             "14 1 1 2",
        16:             "5 1",
        17:             "7 1",
        18:             "9 1 1 1 1 1 1 1 1 1"            
    }
};


