<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');
?>
<html>
<head>
   <title>Manage Critical Jobs Lists Help</title>
   <?php tws_stylesheet(); ?>
</head>
<body class=help>
<?php
   tws_set_window_title();
   include 'tws_help_topbar.php';
?>
<h1 class=help>Manage Critical Jobs Lists Help</h1>

<p>This page allows to add new or modify existing lists of critical jobs. Use the <strong>List Number</strong> combo box to select one of the existing critical jobs lists or the <strong>Create New List</strong> to create new one.

<p>Critical jobs of the selected list is possible to manage using the job table and three action buttons:
<ul>
 <li><strong>Add</strong> : Add a new job entry to the list</li>
 <li><strong>Modify</strong> : Modify the selected<sup>*</sup> job</li>
 <li><strong>Delete</strong> : Delete the selected<sup>*</sup> job</li>
</ul>
</p>

<p>
<sup>*</sup>Use the radio buttons in the first column of the critcal jobs table to select jobs for modification or deletion.
<p>
</body>
