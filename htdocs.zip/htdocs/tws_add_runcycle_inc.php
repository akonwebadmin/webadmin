

<table border=0 cellspacing=0 class="transparent">
<tr>
<td class="standard"></td>
<td class="standard">
   <input type="button" value="Preview" onclick="rc_preview();">
   <input type="button" value="Export" onclick="rc_preview('send');">
</td>
</tr>
<tr>
<td class="standard" width=150><h3>Run Date Rules</h3></td>
<td class="standard" align="left"> <input type="button" name="add" value=" + " onClick="addruncyclerow('rdrs');"/></td>
</tr>
<tr><td class="standard" colspan=2>

 <table id="rdrs" border=0 style="border:0px none; border-collapse:collapse;" class="transparent">
<?
   $i=0;
   while (isset($rc_type[$i])) {
      // if ($rc_type[$i]=="G") { $i++; continue;}  // Skip RC Groups if RC Group is edited

      if (isset($rc_on_except[$i]) && ($rc_on_except[$i]=="EXCEPT") )
         $on_except="EXCEPT";
      else
         $on_except="ON";
?>
  <tr class="standard <?=(($i%2) ? 'even' : 'odd');?>">
   <td class="standard" width=100 align=right valign=top nowrap>
      <input type="button" name="delete" value=" - " onClick="deleteruncyclerow('rdrs','<?=$i?>');"/>&nbsp;(<?=$i+1;?>)&nbsp;
   </td>
   <td class="standard" nowrap>
      <table border=0 cellspacing=0 style="border:0px none; border-collapse:collapse;" class="transparent">
      <tr>
         <td class="standard" style="width:10em">Type:</td>
         <td class="standard">
            <select name="rc_on_except[<?=$i;?>]" onChange="on_except_diffs(this, <?=$i;?>)">
               <option value="ON" <? if ($on_except=="ON") echo "selected";?>>On</option>
               <option value="EXCEPT" <? if ($on_except=="EXCEPT") echo "selected";?>>Except</option>
            </select>

            <select name="rc_type[<?=$i;?>]" onChange="spec_fields(this,<?=$i;?>)">
               <option value="R" <? if ($rc_type[$i]=="R") echo "selected";?>>Run Cycle</option>
               <option value="C" <? if ($rc_type[$i]=="C") echo "selected";?>>Calendar</option>
               <option value="S" <? if ($rc_type[$i]=="S") echo "selected";?>>Single Date(s)</option>
               <? if( $tws_config['cpuinfo']['version']>='9.1' && empty($add_runcycle)){ // if not from add/edit runcycle ?>
               <option value="G" <? if ($rc_type[$i]=="G") echo "selected";?>>Run Cycle Group</option>
               <? } ?>
            </select>
         </td>
      </tr>
      <tr>
         <td class="standard">Rule name *:</td>
         <td class="standard">
            <input type="text" name="rc_name[<?=$i?>]" class="tws_name" size=16 maxlength=40 value="<? if (isset($rc_name[$i])) echo htmlspecialchars($rc_name[$i]);?>"/>
         </td>
      </tr>
      <tr>
         <td class="standard">Description:</td>
         <td class="standard">
            <input type="text" name="rc_description[<?=$i;?>]" size=70 maxlength=120 class="tws_alfanum" value="<? if (isset($rc_description[$i])) echo htmlspecialchars($rc_description[$i]);?>"/>
         </td>
      </tr>
      <? if( $tws_config['cpuinfo']['version']>='9.1' && !empty($add_runcycle)){ // if we are in edit runcycle ?>
      <tr><td>Subset:</td>
         <td class="standard">
            <input type="text" name="rc_subset[<?=$i?>]" class="tws_name" size=16 maxlength=40 value="<? if (isset($rc_subset[$i])) echo htmlspecialchars($rc_subset[$i]);?>">&nbsp;&nbsp;
            <select name="rc_and[<?=$i?>]">
               <option value="-" <? if($rc_and[$i]!='A') echo 'selected';?>>OR</option>
               <option value="A" <? if($rc_and[$i]=='A') echo 'selected';?>>AND</option>
            </select>
         </td>
      </tr>
      <? } ?>

      <?php if ($tws_config['cpuinfo']['version']>=8.5) : ?>
      <tr>
         <td class="standard">Parameter Table:</td>
         <td class="standard">
            <input type="text" name="rc_parameter_table[<?=$i?>]" class="tws_name" style="width:20em;" value="<? if (isset($rc_parameter_table[$i])) echo htmlspecialchars($rc_parameter_table[$i]);?>" <? if ($on_except=="EXCEPT") echo " disabled";?>/>&nbsp;
            <input type="button" name="parameter_table_picker[<?=$i?>]" value="List" onClick="tws_picker_open('parameter_table_picker.php', 'fieldname=rc_parameter_table[<?=$i;?>]&amp;fieldvalue=' + document.contents.elements['rc_parameter_table[<?=$i;?>]'].value);" <? if ($on_except=="EXCEPT") echo " disabled";?>/>
         </td>
      </tr>
      <?php endif; ?>
<!-- RCG -->
      <tr id='rcg_spec[<?=$i?>]' <? if ($rc_type[$i]!="G") echo 'style="display:none"';?>>
      <td class="standard">Run Cycle Group:</td>
         <td class="standard">
            <input type="text" name="rcg[<?=$i?>]" class="tws_name" <? if (!empty($rcg[$i])) echo "value='$rcg[$i]'";?>>&nbsp;
            <input type="button" class ="list" name="runcycle_list" value="List" onClick="tws_picker_open('runcycle_picker.php', 'fieldname=rcg[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['rcg[<?=$i?>]'].value);">
            <input type="button" class ="list" name="runcycle_view" value="View" onClick="display_rcg('rcg[<?=$i?>]');">&nbsp;&nbsp;
            Offset:&nbsp;<input type="text" name="rcg_offsetvalue[<?=$i?>]" class="tws_num" size="4" maxlength="4" value="<? if (isset($rcg_offsettype[$i]) && $rcg_offsetvalue[$i]!='0') echo htmlspecialchars($rcg_offsetvalue[$i]);?>"/>
            <select name="rcg_offsettype[<?=$i?>]"><?
               foreach (array_unique($tws_types['CAL_OFFSET_TYPE']) as $val)
                  echo "<option value='$val' ".($rcg_offsetvalue[$i]!='0' && $rcg_offsettype[$i]==$val ? 'selected':'').">$val</option>";?>
            </select>
         </td>
      </tr>

<!-- Run Cycle definition -->
      <tr id="r_spec[<?=$i?>]" <? if (isset($rc_type[$i]) && $rc_type[$i]!="R") echo 'style="display:none"';?>>
         <td class="standard">Frequency *:</td>
         <td class="standard">
            <select name="rc_freq[<?=$i;?>]" onchange="set_byday_options(this,<?=$i;?>);">
               <option value=""></option>
               <option value="DAILY" <? if (isset($rc_freq[$i]) &&($rc_freq[$i]=="DAILY")) echo "selected";?>>Daily</option>
               <option value="WEEKLY" <? if (isset($rc_freq[$i]) &&($rc_freq[$i]=="WEEKLY")) echo "selected";?>>Weekly</option>
               <option value="MONTHLY" <? if (isset($rc_freq[$i]) &&($rc_freq[$i]=="MONTHLY")) echo "selected";?>>Monthly (m)</option>
               <option value="MONTHLY2" <? if (isset($rc_freq[$i]) &&($rc_freq[$i]=="MONTHLY2")) echo "selected";?>>Monthly (w)</option>
               <option value="YEARLY" <? if (isset($rc_freq[$i]) &&($rc_freq[$i]=="YEARLY")) echo "selected";?>>Yearly</option>
            </select>
            &nbsp;Interval:&nbsp;<input type="text" name="rc_interval[<?=$i?>]" class="tws_num" size=3 value="<? if (isset($rc_interval[$i])) echo htmlspecialchars($rc_interval[$i]);?>" oninput="rc_interval_changed(<?=$i?>);"/>
            <span class="rc_bydays_group" <?=($rc_freq[$i]=='YEARLY' ? 'style="display:none"' : '')?>>
            &nbsp;Days:&nbsp;<input type="text" name="rc_bydays[<?=$i;?>]" size=15 class="tws_alfanum_list" value="<?=htmlspecialchars($rc_bydays[$i]);?>" onkeyup="enable_freedays_rules();"/>&nbsp;
            <input type="button" name="rc_bydays_pick"  value="List"
               onClick="tws_picker_open('byday_picker.php', 'fieldname=rc_bydays[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['rc_bydays[<?=$i;?>]'].value + '&amp;freq=' + document.contents.elements['rc_freq[<?=$i;?>]'].value);" />
               </span>
            <div name='interval_warning[<?=$i?>]' style="display:none;" class='warning'></div>
         </td>
      </tr>

<!-- Single Dates -->
<tr id="s_spec[<?=$i;?>]" <? if ($rc_type[$i]!="S") echo "style=\"display:none\"";?>>
   <td class="standard" valign="top">Single&nbsp;Date(s):</td>
   <td class="standard" align="left">
      <input type="button" name="add" value=" + " onClick="adddaterow('<?=$i?>');"/>
      <br/>
      <table id="date<?=$i?>" border=0 cellpadding=0 cellspacing=0 class="transparent">
<?
   $s=0;
   do {
?>
 <tr>
   <td class="standard" align="left">
      <input type="button" name="delete" value=" - " onClick="deletedaterow('<?=$i?>','<?=$s+1;?>');"/>&nbsp;(<?=$s+1;?>)&nbsp;
   </td>
   <td class="standard" nowrap>
   <?=tws_datetime_picker('date_day['.$i.']['.$s.']',$date_day[$i][$s],'','',"'dropdown',false,'24',true,false,false");?>
   </td>
 </tr>
<?
      $s++;
   } while (isset($date_day[$i][$s]));
?>
      </table>
   </td>
</tr>

<!-- Calendar -->
<tr id="c_spec[<?=$i;?>]" <? if ($rc_type[$i]!="C") echo "style=\"display:none\"";?>>
   <td class="standard">Calendar name:</td>
   <td class="standard">
      <input type="text" name="calendar[<?=$i;?>]" class="tws_name" style="width:20em;" value="<? if (isset($calendar[$i])) echo htmlspecialchars($calendar[$i]);?>"/>
      <input type="button" name="calendar_list" value="List" onClick="tws_picker_open('calendar_picker.php', 'includestock=no&amp;fieldname=calendar[<?=$i;?>]&amp;fieldvalue=' + document.contents.elements['calendar[<?=$i;?>]'].value);" />
      &nbsp;&nbsp;Offset:&nbsp;<input type="text" name="offsetvalue[<?=$i?>]" class="tws_num" size="4" maxlength="4" value="<? if (isset($offsettype[$i]) && $offsetvalue[$i]!='0') echo htmlspecialchars($offsetvalue[$i]);?>">
      <select name="offsettype[<?=$i?>]"><?
         foreach (array_unique($tws_types['CAL_OFFSET_TYPE']) as $val){
            if(empty($val)) continue;
            echo "<option value=\"".htmlspecialchars($val)."\" ".($offsetvalue[$i]!='0' && $offsettype[$i]==$val ? 'selected' : '').">".htmlspecialchars($val)."</option>";
         }
         ?>
      </select>
   </td>
</tr>


      <tr>
         <td class="standard">Freedays rule:</td>
         <td class="standard">
            <label><input type="radio" name="rc_freedaysrule[<?=$i?>]" value="" <? if (!isset($rc_freedaysrule[$i]) || $rc_freedaysrule[$i]=="") echo "checked";?>>&nbsp;Ignore</label>&nbsp;&nbsp;&nbsp;
            <label><input type="radio" name="rc_freedaysrule[<?=$i?>]" value="fdignore" <? if ($rc_freedaysrule[$i] == "fdignore") echo "checked";?>>&nbsp;Don't run</label>&nbsp;&nbsp;&nbsp;
            <label><input type="radio" name="rc_freedaysrule[<?=$i?>]" value="fdprev" <? if ($rc_freedaysrule[$i] == "fdprev") echo "checked";?>>&nbsp;Run previous day</label>&nbsp;&nbsp;&nbsp;
            <label><input type="radio" name="rc_freedaysrule[<?=$i?>]" value="fdnext" <? if ($rc_freedaysrule[$i] == "fdnext") echo "checked";?>>&nbsp;Run next day</label>&nbsp;&nbsp;&nbsp;
         </td>
      </tr>
         <tr><td class="standard">
            <? // if($rc_validfrom[$i] == '' && $rc_interval[$i]>1)  $rc_validfrom[$i] = date(tws_profile("date_format")); ?>
            Valid from:</td><td class="standard">
               <?=tws_datetime_picker('rc_validfrom['.$i.']',$rc_validfrom[$i],'','',"'dropdown',false,'24',true,false,false");?>&nbsp;&nbsp;
            Valid to:
               <?=tws_datetime_picker('rc_validto['.$i.']',$rc_validto[$i],'','',"'dropdown',false,'24',true,false,false");?>
            </td>
         </tr>
      </table>

   <!-- Time dependent -->

      <table id="rc_times[<?=$i;?>]" border=0 cellspacing=0 style="border:0px none; border-collapse:collapse; margin-bottom:20px; background-color:#e9e9e9">
         <tr>
            <td class="standard" style="width:10em;"><?=($rc_time_dep[$i]=="YES" ? "At:" : "Schedtime:")?></td>
            <td class="standard">
               <input type="text" name="rc_athour[<?=$i;?>]" class="tws_hour" size=2 maxlength=2 value="<? if (isset($rc_athour[$i])) echo htmlspecialchars($rc_athour[$i]);?>"/>&nbsp;:
               <input type="text" name="rc_atminute[<?=$i;?>]" class="tws_minute" size=2 maxlength=2 value="<? if (isset($rc_atminute[$i])) echo htmlspecialchars($rc_atminute[$i]);?>"/>&nbsp;+&nbsp;
               <input type="text" name="rc_atplusdays[<?=$i;?>]" class="tws_num" size=2 maxlength=2 value="<? if (isset($rc_atplusdays[$i])) echo htmlspecialchars($rc_atplusdays[$i]);?>"/>&nbsp;days
               <label style="margin-left:20px"><input type="checkbox" name="rc_time_dep[<?=$i;?>]" value="YES" <? if ($rc_time_dep[$i]=="YES") echo "checked";?> onClick="rc_at_time_type(this,<?=$i?>);">&nbsp;Use as time dependency</label>
            </td>
         </tr>
<? if ($tws_config['cpuinfo']['version']>=9.3){ ?>
         <tr class='on<?=$i?>'>
            <td class="standard">Every:</td>
            <td class="standard">
               <input type="text" name="rc_everyhour[<?=$i?>]" class="tws_hour" size=2 maxlength=2 onchange='set_every_req(<?=$i?>)' value="<? if (isset($rc_everyhour[$i])) echo htmlspecialchars($rc_everyhour[$i]); ?>" <? if ($on_except=="EXCEPT") echo "disabled"; ?>/>&nbsp;:
               <input type="text" name="rc_everyminute[<?=$i?>]" class="tws_minute every_req<?=$i?>" size=2 maxlength=2 value="<? if (isset($rc_everyminute[$i])) echo htmlspecialchars($rc_everyminute[$i]);?>" <? if ($on_except=="EXCEPT") echo "disabled"; ?>/>&nbsp;&nbsp;
               End Time:
               <input type="text" name="rc_everyendhour[<?=$i?>]" class="tws_hour every_req<?=$i?>" size=2 maxlength=2 value="<? if (isset($rc_everyendhour[$i])) echo htmlspecialchars($rc_everyendhour[$i]); ?>" <? if ($on_except=="EXCEPT") echo "disabled"; ?>/>&nbsp;:
               <input type="text" name="rc_everyendminute[<?=$i?>]" class="tws_minute every_req<?=$i?>" size=2 maxlength=2 value="<? if (isset($rc_everyendminute[$i])) echo htmlspecialchars($rc_everyendminute[$i]);?>" <? if ($on_except=="EXCEPT") echo "disabled";?>/>&nbsp;+
               <input type="text" name="rc_everyendplusdays[<?=$i;?>]" class="tws_num" size=2 maxlength=2 value="<? if (isset($rc_everyendplusdays[$i])) echo htmlspecialchars($rc_everyendplusdays[$i]);?>" <? if ($on_except=="EXCEPT") echo "disabled";?>/>&nbsp;days
<script type="text/javascript">
   function set_every_req(i){
      if($('input[name="rc_everyhour['+i+']"]').val() !== '' )
         $('input.every_req'+i).addClass('required');
      else
         $('input.every_req'+i).removeClass('required');
   }
</script>
            </td>
         </tr>
<? } ?>
         <tr>
            <td class="standard">Until:</td>
            <td class="standard">
               <input type="text" name="rc_untilhour[<?=$i;?>]" class="tws_hour" size=2 maxlength=2 value="<? if (isset($rc_untilhour[$i])) echo htmlspecialchars($rc_untilhour[$i]); ?>" <? if ($on_except=="EXCEPT") echo "disabled"; ?>/>&nbsp;:
               <input type="text" name="rc_untilminute[<?=$i;?>]" class="tws_minute" size=2 maxlength=2 value="<? if (isset($rc_untilminute[$i])) echo htmlspecialchars($rc_untilminute[$i]);?>" <? if ($on_except=="EXCEPT") echo "disabled"; ?>/>&nbsp;+&nbsp;
               <input type="text" name="rc_untilplusdays[<?=$i;?>]" class="tws_num" size=2 maxlength=2 value="<? if (isset($rc_untilplusdays[$i])) echo htmlspecialchars($rc_untilplusdays[$i]);?>" <? if ($on_except=="EXCEPT") echo "disabled"; ?>/>&nbsp;days
               <span style="margin:20px">Until action:</span><select name="rc_onuntil[<?=$i;?>]"<? if ($on_except=="EXCEPT") echo " disabled";?> >
                  <option value="SUPPR" <?php if (strtoupper($rc_onuntil[$i]) == "SUPPR") echo " selected"; ?>>Suppress</option>
                  <option value="CONT" <?php if (strtoupper($rc_onuntil[$i]) == "CONT") echo " selected"; ?>>Continue</option>
                  <option value="CANC" <?php if (strtoupper($rc_onuntil[$i]) == "CANC") echo " selected"; ?>>Cancel</option>
               </select>
               <? if ($tws_config['cpuinfo']['version']>'9.4') { ?>
                     <label><input type='checkbox' name='rc_jsuntil[<?=$i?>]' value='Y' <?=(strtoupper($rc_jsuntil[$i]=='Y')?'checked':'')?>>Apply to each job</label>
               <? } ?>

            </td>
         </tr>
         <tr>
            <td class="standard">Deadline:</td>
            <td class="standard">
               <input type="text" name="rc_deadlinehour[<?=$i;?>]" class="tws_hour" size=2 maxlength=2 value="<? if (isset($rc_deadlinehour[$i])) echo htmlspecialchars($rc_deadlinehour[$i]);?>" <? if ($on_except=="EXCEPT") echo "disabled"; ?>/>&nbsp;:
               <input type="text" name="rc_deadlineminute[<?=$i;?>]" class="tws_minute" size=2 maxlength=2 value="<? if (isset($rc_deadlineminute[$i])) echo htmlspecialchars($rc_deadlineminute[$i]);?>" <? if ($on_except=="EXCEPT") echo "disabled"; ?>/>&nbsp;+&nbsp;
               <input type="text" name="rc_deadlineplusdays[<?=$i;?>]" class="tws_num" size=2 maxlength=2 value="<? if (isset($rc_deadlineplusdays[$i])) echo htmlspecialchars($rc_deadlineplusdays[$i]);?>" <? if ($on_except=="EXCEPT") echo "disabled"; ?>/>&nbsp;days
            </td>
         </tr>
      </table>
   </td>
  </tr>
<?
      $i++;
   }
?>
 </table>
</td></tr>
</table>
<? // TODO: add freedays calendars and sat/sun here !!!  ?>
<script type="text/javascript">
function rc_interval_changed(i){
   var el = document.contents.elements['rc_validfrom['+i+']'];    // RC Valid From
   if (document.contents.elements['rc_interval['+i+']'].value > 1 &&  document.contents.elements['rc_validfrom['+i+']'].value=='' ){
      $(el).addClass('required');
      $(el).val("<?=date(tws_profile("date_format"))?>");
      $('div[name="interval_warning['+i+']"]').text("'Valid from' parameter is required. The parameter was set as <?=date(tws_profile("date_format"))?>");

      $('div[name="interval_warning['+i+']"]').stop(true,true).fadeIn().delay(2500).fadeOut();
   }

   else if(document.contents.elements['rc_interval['+i+']'].value <= 1 || document.contents.elements['rc_interval['+i+']'].value == ''){
      $(el).removeClass('required');
   }
}

function display_rcg(fname){
   var val = document.contents.elements[fname].value;
   var parenthight = $(window).height()-30;
   if( $.trim(val) != '')
      window.open('tws_display_runcycle.php?arg='+val+'&amp;popup=yes', '', 'height='+parenthight+', width=960, left=10, top=50, toolbar=no, menubar=no, location=no, scrollbars=yes, resizable=yes');
      //tws_url_open('tws_display_runcycle.php?arg='+ val, 'showrc', 800);
}

</script>
