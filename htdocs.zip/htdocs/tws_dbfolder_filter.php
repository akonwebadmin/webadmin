<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   require_once 'tws_filters_lib.php';
   tws_doctype("t");
?>
<html>
<head>
   <title>Folder Filter</title>
   <? tws_stylesheet();
   tws_get_filter_from_storage('tws_foldersx');

   $dbfolderfilter = tws_gpc_get($_GET['arg'], 'tws_filter');
   if (strpos($dbfolderfilter, 'expert:')!==false) {
      $radio_id = "expert_radio";
      $dbfolderfilter = str_replace('expert:', '', $dbfolderfilter);
      $dbfolderfilter = $dbfolderfilter ? $dbfolderfilter : null;
   }
   else $radio_id = "basic_radio";
?>
</head>

<body onload="changeDisabling(document.getElementById('<? echo $radio_id; ?>'));">
<? tws_set_window_title();
   tws_print_head('Database Folder Filter');

   tws_check_arg($dbfolderfilter, 'tws_filter');
   // Set arrays values for formfields
   $values = array();
   $inc_values = array();
   $xxx=NULL;
   $dbfolderfilter = strtr($dbfolderfilter, '|', ',');
   if(tws_dbfilter_formfields($dbfolderfilter, $values, $xxx, $inc_values)==false)
      tws_err('Wrong filter format');
?>
<br>
<div id='tabs'>
   <ul>
      <li><a href='#filter'>Set Filter</a></li>
      <li><a href='#load'>Load Filter</a></li>
   </ul>

<div id="filter">
<form method=post name="contents" action="tws_dbfolder_filter_action.php">
<fieldset>
<legend><label><input id="basic_radio" type="radio" name="filter_type" style="margin: 0 5px 0 0; padding: 0" value="basic" onclick="changeDisabling(this);" /> basic filter setting</label></legend>
<div id="basic">

<table class="filter_tbl" border="0" cellspacing="0">

<!-- Folder -->
<? for ($i=0; $i<count($values); $i++) { ?>
<tr class='values' name='values_tr[<?=$i?>]'>
   <td class='standard head' style="padding-right:10px">Folder:</td>
   <td class='standard head' style="padding-right:10px">
      <table name='inc_values[<?=$i?>]'><tr><td height='22px'>
      <select id='inc_values' name='inc_values[<?=$i?>]' onchange="inc_change('inc_values[<?=$i?>]');">
         <option value='eq' <? if ($inc_values[$i]=='eq') echo "selected";?>>=</option>
         <option value='ne' <? if ($inc_values[$i]=='ne') echo "selected";?>>≠</option></select>
      </td></tr></table>
      <? for ($j=1; $j<count($values[$i]); $j++) { ?>
         <table name='inc_values[<?=$i?>]'>
         <td style="padding-right:10px">
               <? if ($inc_values[$i]=='eq') echo "OR"; else echo "AND"; ?>
         </td></tr></table>
      <? } ?>
   </td>
   <td class='standard head'>
   <? for ($j=0; $j<count($values[$i]); $j++) { ?>
   <table class='values' name='values_table[<?=$i?>]'><tr><td>
<script>
   function show_values(){
      alert('fieldname=values[<?=$i?>][<?=$j?>]');
      alert('fieldvalue=' + document.contents.elements['values[<?=$i?>][<?=$j?>]'].value);
   }
</script>
         <input type="text" id="values" name="values[<?=$i?>][<?=$j?>]" class="tws_mask" style="width:20em;" <? if (isset($values[$i][$j])) echo "value=\"".htmlspecialchars($values[$i][$j])."\""; ?> />
         <input type="button" class ="list" name="folder_list" value="List" onClick="tws_picker_open('folder_picker.php', 'fieldname=values[<?=$i?>][<?=$j?>]&amp;fieldvalue=' + document.contents.elements['values[<?=$i?>][<?=$j?>]'].value);">
   </td></tr></table>
   <? } ?>
   </td>
   <td style="vertical-align: bottom;">
      <input type="button" class="button plusbutton" name="OR[<?=$i?>]" value="+" title="OR" onclick="insertTable('values[<?=$i?>]');"/>
   </td>
</tr>
<tr class="delim" <? if( ($i+1) >= count($values)  ) {echo ' style="display:none;"';}?> >
   <td></td>
   <td class='foot'></td>
   <td class='foot'></td>
   <td class='foot'></td>
</tr>
<? } ?>
<tr>
   <td class='standard'><input type="button" class="button plusbutton" name="AND" title="AND" value="+" onclick="insertRow('values');"/></td>
   <td class='standard'>&nbsp;</td>
   <td class='standard'>&nbsp;</td>
</tr>

</table>
</div>
</fieldset>

<br/>

<fieldset>
<legend><label><input id="expert_radio" type="radio" name="filter_type" style="margin: 0 5px 0 0; padding: 0;" value="expert" onclick="changeDisabling(this);" /> expert filter setting</label> (recommended for experts only)</legend>
<div id="expert">
   <input type="text" name="expert_filter" class='tws_filter' value="<? echo $dbfolderfilter; ?>" style="display: block; width: 63%;" disabled="disabled" />
</div>
</fieldset>

<br/><br/>

<input type="submit" value="Set Filter" name="action" onclick='return tws_validate_form();'>
&nbsp;&nbsp;&nbsp;<input type="submit" value="Clear Filter" name="action">
&nbsp;&nbsp;&nbsp;<input type="submit" value="Save Filter" name="action" onclick='return tws_validate_form();'>
&nbsp;&nbsp;&nbsp;<input type="submit" value="Reset Filter" name="action">
&nbsp;&nbsp;&nbsp;<input type="submit" value="Send as CSV" name="action" title="Tab delimited">
<? if(@$_GET['edit_file']!='') echo "<input type=\"hidden\" name=\"edit_file\" value=\"".htmlspecialchars($_GET['edit_file'])."\">\n";?>
</form>
</div>
<div id="load">
<?
   $object='dbfolder';
   include "tws_load_filter.php";
?>
</div>
</div>

<script>
$(function() {
   $('#tabs').tabs();
   $('#tabs').css('background-color','inherit');
   $('#tabs').css('border','none 0px');
   $('#tabs ul').css('font-size', '140%');
});
</script>
</body>
</html>