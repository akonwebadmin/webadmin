<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");

   // Cancel button test
   $tmp_test = (isset($_POST['action']) && (($_POST['action'] == 'Cancel') || ($_POST['action'] == 'Return to Workstation Modification'))) ? true : false;
   if ($tmp_test == true) {
      foreach ($_POST as $key => $val)
         $$key = tws_gpc_get($val);
   }

   if( $copy=="yes" ) $h1 = "Copy Workstation";
   else if( $modify=="yes" ) $h1 = "Modify Workstation";
   else if( $display=="yes" ) $h1 = "Display Workstation Definition";
   else $h1 = "Add Workstation";

   $log_file_name=tws_log('', 'OPEN');
   tws_print_head($h1, array('__log__' => $log_file_name, '__help__' => 'tws_add_workstation_help.php'));
?>
<html>
<head>
<title><?=$h1;?></title>
<?php tws_stylesheet(); ?>
<script type="text/javascript">
function type_change() {
var obj = document.getElementById('workstation_type');
   var cputype = obj.options[obj.selectedIndex].value;

show_all();
protocol(0);
   $('tr#tr_license_type').hide();
   $('select#license_type').prop( "disabled", true );

switch (cputype) {
   case "F":   // FTA
     method(0);
     host(0);
     $('input#domain').addClass('tws_node required');
     $('select#os_type option[value="Z"]').prop("disabled", "disabled");
     $('tr#tr_license_type').show();
     $('select#license_type').prop( "disabled", false );
     break;
   case "S":   // Standart agent
     fullstatus(0);
     method(0);
     $('input#domain').addClass('tws_node required');
     <?php
     if($tws_config['cpuinfo']['version']>='8.6')
         echo "host(0);";
     ?>
     $('tr#tr_license_type').show();
     $('select#license_type').prop( "disabled", false );

     break;
   case "X":   // ext-agent
     autolink(0);
     fullstatus(0);
     firewall(0);
     server(0);
     securitylevel(0);
     secureaddr(0);
     $('input#domain').removeClass('tws_node required');
     <?php if($tws_config['cpuinfo']['version']<'8.6') echo"domain(0);";?>
     <?php if($tws_config['cpuinfo']['version']<'8.6') echo"os(0);";?>
     $('select#os_type option[value="Z"]').prop("disabled", "disabled");
     $('tr.secoptionsdiv').css('display', 'none');
     break;

   case "M":   // Manager
      document.contents.fullstatus.checked = true;
      document.contents.fullstatus.disabled = true;
      $('input#domain').removeClass('tws_node required');
      server(0);
      host(0);
      method(0);
      $('tr#tr_license_type').show();
      $('select#license_type').prop( "disabled", false );
     break;

   case "B":   // Broker
     fullstatus(0);
     method(0);
     os(0);
     securitylevel(0);
     $('input#domain').addClass('tws_node required');
     <?php if($tws_config['cpuinfo']['version']>='8.6') echo "host(0);"; ?>
     break;

   case "A":   // Agent
      autolink(0);
      domain(0);
      firewall(0);
      fullstatus(0);
      host(1, "readonly", "true");
      method(0);
      node(1, "readonly", "true");
      os(0);
      securitylevel(0);
      protocol(1);
      server(0);
      tcpaddr(1, "readonly", "true");
      secureaddr(1, "readonly", "true");
      ws_type(0);
     break;

   case "E":   // rem-eng
     $('select#os_type option[value="I"]').prop("disabled", "disabled");
     $('select#os_type option[value="O"]').prop("disabled", "disabled");
     $('select#os_type option[value="Z"]').removeProp("disabled");
     fullstatus(0);
     server(0);
     method(0);
     domain(0);
     firewall(0);
     autolink(0);
     securitylevel(0);
     protocol(1);
     secureaddr(1);
     break;

   case "L":      // PooL
     node(0);
     tcpaddr(0);
     secureaddr(0);
     domain(0);
     method(0);
     autolink(0);
     firewall(0);
     securitylevel(0);
     fullstatus(0);
     server(0);
     $('tr.secoptionsdiv').css('display', 'none');
     members(1);
     break;

   case "Y":      // Dynamic Pool
     node(0);
     tcpaddr(0);
     secureaddr(0);
     domain(0);
     method(0);
     autolink(0);
     firewall(0);
     securitylevel(0);
     fullstatus(0);
     server(0);
     $('tr.secoptionsdiv').css('display', 'none');
     requirements(1);
     break;
 }
}

function sec_change() {
   var obj = document.getElementById('securitylevel');
   var seclev = obj.options[obj.selectedIndex].value;
   if (seclev == "NULL") secureaddr(0);
   else secureaddr(1);
}

function ConfirmCancel(objectname,url) {
   $('form').unbind('submit');
 var conftext=confirm("Exit " + objectname + " Definition (Changes will be lost) ?");
 if (conftext) {
   if (url==null) return true;
      closeme(url);
 } else {
   return false;
 }
}

function os_change() {
   document.contents.os_typex.value = document.contents.os_type.value;
   document.contents.os_typexx.value = document.contents.os_type.value;
}

/***   Enable / Disable fields   ***/

function show_all() {
   autolink(1);
   domain(1);
   firewall(1);
   fullstatus(1);
   host(1);
   method(1);
   node(1);
   os(1);
   securitylevel(1);
   server(1);
   tcpaddr(1);
   members(0);
   requirements(0);
     $('select#os_type option[value="Z"]').prop("disabled", "disabled");
     $('select#os_type option[value="O"]').removeProp("disabled");
     $('select#os_type option[value="I"]').removeProp("disabled");
     $('tr.secoptionsdiv').css('display', '');
}
function autolink(on, prop, val) {
   if(on) {
     $('tr.autolinkdiv').css("display", "");
     <?php if ($display!='yes') : ?>
     document.contents.autolink.disabled = false;
     <? endif;?>
   } else {
     document.contents.autolink.disabled = true;
     $('tr.autolinkdiv').css("display", "none")
   }
   if(typeof(prop) != "undefined")
      $('input#autolink').prop(prop, val);

}
function fullstatus(on, prop, val) {
   if(on) {
     $('tr.fullstatusdiv').css("display", "");
     <?php if ($display!='yes') : ?>
     document.contents.fullstatus.disabled = false;
     <? endif;?>
   } else {
     $('tr.fullstatusdiv').css("display", "none");
     document.contents.fullstatus.disabled = true;
   }
   if(typeof(prop) != "undefined")
      $('input#fullstatus').prop(prop, val);
}
function server(on, prop, val) {
   if(on) {
     $('tr.serverdiv').css("display", "");
     <?php if ($display!='yes') : ?>
     document.contents.server.disabled = false;
     <? endif;?>
   } else {
     $('tr.serverdiv').css("display", "none");
     document.contents.server.disabled = true;
   }
   if(typeof(prop) != "undefined")
      $('input#server').prop(prop, val);
}
function method (on, prop, val) {
   if(on) {
     $('tr.methoddiv').css("display", "");
     document.contents.method.disabled = false;
   } else {
     $('tr.methoddiv').css("display", "none");
     document.contents.method.disabled = true;
   }
   if(typeof(prop) != "undefined")
      $('input#method').prop(prop, val);
}
function host (on, prop, val) {
   if(on) {
     $('tr.hostdiv').css("display", "");
     document.contents.host.disabled = false;
   } else {
     $('tr.hostdiv').css("display", "none");
     document.contents.host.disabled = true;
   }
   if(typeof(prop) != "undefined")
      $('input#host').prop(prop, val);
}
function os (on) {
   if(on) {
     $('tr.osdiv').css("display", "");
     <?php if ($display!='yes') : ?>
     document.contents.os_type.disabled = false;
     <? endif;?>
     document.contents.os_typex.value = document.contents.os_type.value;
     document.contents.os_typexx.value = document.contents.os_type.value;
     $('input#os_typexx').css("display", "none");
   } else {
     $('tr.osdiv').css("display", "none");
     document.contents.os_type.disabled = true;
      var obj = document.getElementById('workstation_type');
      var cputype = obj.options[obj.selectedIndex].value;
      if(cputype!="A") {
         document.contents.os_type.value = "O";
         document.contents.os_typex.value = "O";
     } else {
        obj = document.getElementById('os_type');
        document.contents.os_typex.value = obj.options[obj.selectedIndex].value;
     }
     $('input#os_typexx').css("display", "block");
     switch (document.contents.os_typex.value) {
      case "U": document.contents.os_typexx.value ="UNIX"; break;
      case "W": document.contents.os_typexx.value ="Windows NT"; break;
      case "O": document.contents.os_typexx.value ="Other"; break;
      case "Z": document.contents.os_typexx.value ="ZOS"; break;
      case "I": document.contents.os_typexx.value ="IBM_i"; break;
     }
   }
}
function domain (on, prop, val) {
   if(on) {
     $('tr.domaindiv').css("display", "");
     document.contents.domain.disabled = false;
   } else {
     $('tr.domaindiv').css("display", "none");
     document.contents.domain.disabled = true;
   }
   if(typeof(prop) != "undefined")
      $('input#domain').prop(prop, val);
}
function ws_type(on) {
   if(on) {
     document.contents.workstation_type.disabled = false;
     $('input#workstation_typex').val('');
   }
   else {
      $('input#workstation_typex').val($('select#workstation_type').val());
      document.contents.workstation_type.disabled = true;
   }
}
function node(on, prop, val){
   if(on) {
     $('tr.nodediv').css("display", "");
     document.contents.node.disabled = false;
   } else {
     $('tr.nodediv').css("display", "none");
     document.contents.node.disabled = true;
   }
   if(typeof(prop) != "undefined")
      $('input#node').prop(prop, val);
}
function tcpaddr(on, prop, val){
   if(on) {
     $('tr.tcpaddrdiv').css("display", "");
     document.contents.tcpaddr.disabled = false;
   } else {
     $('tr.tcpaddrdiv').css("display", "none");
     document.contents.tcpaddr.disabled = true;
   }
   if(typeof(prop) != "undefined")
      $('input#tcpaddr').prop(prop, val);
}
function firewall(on, prop, val){
   if(on) {
     $('tr.behindfirewalldiv').css("display", "");
     <?php if ($display!='yes') : ?>
     document.contents.behindfirewall.disabled = false;
     <? endif;?>
   } else {
     $('tr.behindfirewalldiv').css("display", "none");
     document.contents.behindfirewall.disabled = true;
   }
   if(typeof(prop) != "undefined")
      $('input#behindfirewall').prop(prop, val);
}
function securitylevel(on, prop, val){
   if(on) {
     $('tr.securityleveldiv').css("display", "");
     <?php if ($display!='yes') : ?>
     document.contents.securitylevel.disabled = false;
     <? endif;?>
   } else {
     $('tr.securityleveldiv').css("display", "none");
     document.contents.securitylevel.disabled = true;
   }
   if(typeof(prop) != "undefined")
      $('input#securitylevel').prop(prop, val);
}
function protocol(on){
   if(on) {
     $('tr.protocoldiv').css("display", "");
     <?php if ($display!='yes') : ?>
     document.contents.protocol.disabled = false;
     <? endif;?>
   } else {
     $('tr.protocoldiv').css("display", "none");
     document.contents.protocol.disabled = true;
   }
}
function secureaddr (on, prop, val){
   if(on) {
     $('tr.secureaddrdiv').css("display", "");
     document.contents.secureaddr.disabled = false;
   } else {
     document.contents.secureaddr.disabled = true;
     $('tr.secureaddrdiv').css("display", "none");
   }
   if(typeof(prop) != "undefined")
      $('input#secureaddr').prop(prop, val);
}
function members(on){
   if(on) {
      $('tr.membersdiv').css("display", "");
   } else {
      $('tr.membersdiv').css("display", "none");
   }
}
function requirements(on){
   if(on) {
      $('tr.requirementsdiv').css("display", "");
   } else {
      $('tr.requirementsdiv').css("display", "none");
   }
}
</script>
</head>

<body style="padding-left:10px;">
   <div id="show">
<?php tws_set_window_title();

   if ($display == 'yes')
      echo "<h1>$h1</h1>";
   else {
      $log_file_name=tws_log('', 'OPEN');
      tws_print_head($h1, array('__log__' => $log_file_name, '__help__' => 'tws_add_workstation_help.php'));
   }

   if( $copy=="yes") { if (!tws_permit_action('database_workstations','Copy') ) tws_access_denied ();  }
   elseif( $modify=="yes" ) { if ( !tws_permit_action('database_workstations','Modify') ) tws_access_denied (); }
   else { if ( !tws_permit_action('database_workstations','Add') ) tws_access_denied (); }

// Get the data in case of Copy or Modify
   if ( $tmp_test == false && ($copy == "yes" || $modify == "yes" || $display == "yes")) {
// check the selection first
      $num_elements=count($selection);
      if ($num_elements == 0)
         tws_dyer("No workstation selected");
      elseif ($num_elements > 1)
         tws_dyer("Multiple workstations selected. Only one workstation can be ".($copy=="yes" ? 'copied' : 'modified')." at a time");

      $workstation=$selection[0];

      if( ($workstation_data = tws_get_workstation_data($workstation))===FALSE || !count($workstation_data))
         tws_dyer("Unable to get workstation data");

      if ($modify=="yes") {
         //lock object
         if( tws_composer_lock("ws=$selection[0]")==false){
            echo "</div>";
            tws_dyer("Unable to lock workstation ".$selection[0]);
         }
         //backup
         if (($original_data=tws_composer_create_from("ws=$selection[0]"))===FALSE)
            tws_dyer("Unable to get workstation data");
      }
      foreach( $workstation_data as $key=>$val ) {
         $$key=$val;
         //echo "$key=$val<br>";
      }
   }
   if ($_POST['action'] == 'Return to Workstation Modification') {
		if ($tws_config['cpuinfo']['version']>='9.5002') {
			list($workstation_folder, $workstation_name) = tws_divide_folder($workstation_name);
		}
   }
/*       ????
  else {
      $workstation_data = tws_get_workstation_data("");
      $workstation_data['securitylevel']="0";
      $workstation_data['workstation_type']="F";
   }
*/
   $tz_status_warning=(!tws_yesno(tws_get_tz_status(),TRUE,FALSE) && $time_zone!="" ) ? TRUE : FALSE;
?>

<br/><br/>
<form method="post" name="contents" action="tws_add_workstation_exec.php" onsubmit="if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Workstation',null)) { cancel_button_pressed=false; return false;}">
<table border=0 cellspacing=7>
   <? if ($tws_config['cpuinfo']['version']>='9.5002'){
         if (empty($workstation_folder)) $workstation_folder = '/';
   ?>
   <tr>
      <td class="standard"><b>Workstation Folder:</b></td>
      <td>
         <input type="text" name="workstation_folder" class="tws_name" required="required" style="width:20em;" value="<?=htmlspecialchars($workstation_folder)?>" <? if ($modify == "yes" || $display == "yes") echo " disabled"; ?> />
         <? if ($modify != "yes"){ ?>
            &nbsp;&nbsp;&nbsp;&nbsp;<input type="button" name="workstation_list" onClick="tws_picker_open('folder_picker.php', 'fieldname=workstation_folder&amp;fieldvalue=' + document.contents.workstation_folder.value);" value="List">
         <? } ?>
      </td>
   </tr>
<? } ?>

<tr>
   <td class="standard"><b>Workstation Name:</b></td>
   <td>
   <input type="text" name="workstation_name" class="tws_name" required="required" style="width:15em;" value="<?=htmlspecialchars($workstation_name)?>" <? if ($modify == "yes" || $display == "yes") echo " disabled"; ?> />
<?
   if ($copy == "yes") {
      echo "<script type='text/javascript'>\n";
      echo "document.contents.workstation_name.focus();\n";
      echo "document.contents.workstation_name.select();\n";
      echo "</script>\n";
   }
?>
   </td>
</tr>
<tr>
<td class="standard"><b>Workstation Type:</b></td>
<td class="standard">
<select name="workstation_type" id="workstation_type" onChange="type_change()" <?php if ($display == "yes") echo " disabled"; ?>>
<option value="F" <?php if (@$workstation_type == "F") echo " selected"; ?>>Fault Tolerant Agent</option>
<option value="S" <?php if (@$workstation_type == "S") echo " selected"; ?>>Standard Agent</option>
<option value="X" <?php if (@$workstation_type == "X") echo " selected"; ?>>Extended Agent</option>
<option value="M" <?php if (@$workstation_type == "M") echo " selected"; ?>>Manager</option>
<?php if($tws_config['cpuinfo']['version']>='8.5'): ?>
<option value="B" <?php if (@$workstation_type == "B") echo " selected"; ?>>Broker</option>
<?php endif; ?>
<?php if($tws_config['cpuinfo']['version']>='8.6'): ?>
<?php if (isset($workstation_type) && $workstation_type == "A") echo "<option value='A' selected>Dynamic Agent</option>";?>
<option value="E" <?php if (@$workstation_type == "E") echo " selected"; ?>>Remote Engine</option>
<option value="L" <?php if (@$workstation_type == "L") echo " selected"; ?>>Pool</option>
<option value="Y" <?php if (@$workstation_type == "Y") echo " selected"; ?>>Dynamic Pool</option>
<?php endif; ?>
</select>
<input type="hidden" name="workstation_typex" id="workstation_typex" />
</td>
</tr>

<tr class="nodediv">
<td class="standard"><b>Node:</b></td>
<td class="standard">
<input type="text" name="node" required="required" id="node" class="tws_node" style="width:15em;" maxlength="120" value="<?=htmlspecialchars(@$node)?>" <?php if($display == "yes") echo " readonly";?>/>
</td>
</tr>

<tr class="tcpaddrdiv">
<td class="standard"><b>TCP Address:</b></td>
<td class="standard">
<input type="text" name="tcpaddr" id="tcpaddr" class="tws_num" size="6" maxlength="5" value="<?=($tcpaddr ? htmlspecialchars($tcpaddr) : ($secureaddr ? "" : "31111"))?>" <?php if($display == "yes") echo " readonly";?>/>
</td>
</tr>

<tr class="osdiv">
<td class="standard"><b>Operating System:</b></td>
<td class="standard">
   <select name="os_type" id="os_type" onChange="os_change();" <?php if($display == "yes") echo " disabled";?> >
   <option value="U" <?php if (@$os_type == "U") echo "selected"; ?>>UNIX</option>
   <option value="W" <?php if (@$os_type == "W") echo "selected"; ?>>Windows NT</option>
   <option value="O" <?php if (@$os_type == "O") echo "selected"; ?>>Other</option>
   <?php if($tws_config['cpuinfo']['version']>='8.6'): ?>
   <option value="Z"<?php if (@$os_type == "Z") echo " selected"; ?>>ZOS</option>
   <option value="I"<?php if (@$os_type == "I") echo " selected"; ?>>IBM_i</option>
   <?php endif; ?>
   </select>
   <input type="text" name="os_typexx" id="os_typexx" readonly="readonly" />
   <input type="hidden" name="os_typex" value="<?=(((@$workstation_type == "X") && (@$os_type == "O")) ? "O" : "NULL")?>"/>
</td>
</tr>

<tr>
<td class="standard"><b>Description:</b></td>
<td class="standard"><input type="text" name="description" size="60" maxlength="120" value="<?=htmlspecialchars(@$description)?>" <?php if($display == "yes") echo " readonly";?>/></td>
</tr>
<? // get MasterDomain
   $md = tws_get_domains('@', 'DOM1.DOM_PARENT_ID IS NULL');
   if(!empty($md['domain_name'][0]))
      $md = $md['domain_name'][0];
   else $md = 'MASTERDM';
?>
<tr class="domaindiv">
<td class="standard"><b>Domain:</b></td>
<td class="standard">
   <input type="text" name="domain" id="domain" class="tws_name" style="width:15em;" maxlength="16" value="<?=htmlspecialchars(@$domain)?>" <?php if($display == "yes") echo " readonly";?>/>
   <?php if($display != "yes"): ?>&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="button" name="domain_list" id="domain_list" value="List" onClick="tws_picker_open('domain_picker.php', 'fieldname=domain&amp;fieldvalue=' + document.contents.domain.value);"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="button" name="masterdm" id="masterdm" onClick="document.contents.domain.value='<?=$md?>'" value="Use Master Domain"/>
   <? endif; ?>
</td>
</tr>

<?php if($tws_config['cpuinfo']['version']>='8.5'): ?>
<tr>
   <td class="standard"><b>Parameter Table:</b></td>
   <td class="standard">
      <input type="text" name="parameter_table" id="parameter_table" class="tws_name" style="width:20em;" value="<?=htmlspecialchars(@$parameter_table)?>"<?php if ($display=='yes') echo " readonly";?> />
      <?php if ($display!='yes') : ?>&nbsp;&nbsp;&nbsp;&nbsp;
      <input type="button" name="parameter_table_list" id="parameter_table_list" value="List" onClick="tws_picker_open('parameter_table_picker.php', 'fieldname=parameter_table&amp;fieldvalue=' + document.contents.parameter_table.value);" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <input type="button" name="default_parameter_table" id="default_parameter_table" onClick="document.contents.parameter_table.value='MAIN_TABLE'" value="Use MAIN_TABLE" />
      <? endif;?>
   </td>
</tr>
<?php endif; ?>

<tr>
<td class="standard">
<b><?php if (!tws_yesno(tws_get_tz_status(),TRUE,FALSE)) echo "<font color=\"#808080\">"; ?>Time Zone:<?php if (!tws_yesno(tws_get_tz_status(),TRUE,FALSE)) echo "</font>"; ?></b>
</td>
<td class="standard">
<select name="time_zone"<?php if (!tws_yesno(tws_get_tz_status(),TRUE,FALSE) || $display == "yes") echo " disabled"; ?>>
<?php tws_print_timezone_options(@$time_zone); ?>
</select>
<?php if ($tz_status_warning) echo "<br/><font color=\"#ff0000\"><b>Warning: Time Zone is set in Workstation definition, but Time Zones are not enabled</b></font>"; ?>
</td></tr>

<? if($tws_config['cpuinfo']['version']>='9.4' && $tws_config['optmanopts']['licensetype'] == 'BYWORKSTATION' ){ ?>
<tr id="tr_license_type" style="display:none;"><td><b>License type</b></td>
<td>
   <select name="license_type" id="license_type" disabled>
      <option value="S">Per Server</option>
      <option value="J">Per Job</option>
   </select>
</td></tr>
   <? if(isset($license_type) && $license_type == 'J'){ ?>
   <script>
      $('select#license_type').val('J');
   </script>
   <? } ?>
<? } ?>
<tr class="secoptionsdiv">
<td class="standard" colspan="2">
<h3>Security Options</h3>
</td>
</tr>

<tr class="securityleveldiv">
   <td class="standard"><b>SSL Communication:</b></td>
   <td class="standard">
<select name="securitylevel" id="securitylevel" onChange="sec_change()" <?php if($display == "yes") echo " disabled";?>>
<option value="NULL"<?php if (@$securitylevel=='' || strpos("EOF",@$securitylevel)===FALSE) echo " selected"; ?>> </option>
<option value="E"<?php if (@$securitylevel == "E") echo " selected"; ?>>Enabled</option>
<option value="O"<?php if (@$securitylevel == "O") echo " selected"; ?>>On</option>
<option value="F"<?php if (@$securitylevel == "F") echo " selected"; ?>>Force</option>
</select>
</td>
</tr>

<tr class="secureaddrdiv">
   <td class="standard"><b>Secure TCP Port:</b></td>
   <td class="standard">
   <input type="text" name="secureaddr" id="secureaddr" class="tws_num" size="6" maxlength="5" <?php if($secureaddr) echo " value=\"".htmlspecialchars($secureaddr)."\""; elseif (strpos("EOF",$securitylevel)!==FALSE) echo " value=\"31113\""; else echo " disabled"; ?><?php if($display == "yes") echo " readonly";?>/>
</td>
</tr>

<tr class="protocoldiv">
   <td class="standard"><b>Protocol:</b></td>
   <td class="standard">
<select name="protocol" id="protocol" <?php if($display == "yes") echo " disabled";?>>
<option value="HTTP"<? if(empty($secureaddr)) echo " selected"; ?>>HTTP</option>
<option value="HTTPS"<?if(!empty($secureaddr)) echo " selected"; ?>>HTTPS</option>
</select>
</td>
</tr>

<tr class="behindfirewalldiv">
<td class="standard" colspan="2">
   <label><input type="checkbox" name="behindfirewall" value="yes"<?php if (strtoupper($behindfirewall{0}) == "Y") echo " checked";?><?php if($display == "yes") echo " disabled";?>>
   <b>Behind Firewall</b></label>
</td>
</tr>

<tr><td class="standard" colspan="2"><h3>Options</h3></td></tr>

<tr class="autolinkdiv">
<td class="standard" colspan="2">
   <label><input type="checkbox" name="autolink" value="yes"<?php if (strtoupper($autolink{0}) == "Y") echo " checked";?> <?php if($display == "yes") echo " disabled";?>/>
   <b>Auto Link</b></label>
</td>
</tr>

<tr class="fullstatusdiv">
<td class="standard" colspan="2">
   <label><input type="checkbox" name="fullstatus" value="yes"<?php if (strtoupper($fullstatus{0}) == "Y") echo " checked";?><?php if($display == "yes") echo " disabled";?>/>
   <b>Full Status</b></label>
</td>
</tr>

<tr>
<td class="standard" colspan="2">
<label><input type="checkbox" name="ignore" value="yes" <?php if (strtoupper($ignore{0})=='Y') echo "checked";?><?php if($display == "yes") echo " disabled";?>/>
   <b>Ignore</b></label>
</td>
</tr>

<tr class="serverdiv">
<td class="standard">
<b>Server:</b>
</td>
<td class="standard">
<select name="server" id="server" <?php if($display == "yes") echo " disabled";?>>
<option value="NULL">&nbsp;</option>
<option value="A"<?php if ($server == "A") echo " selected"; ?>>A</option>
<option value="B"<?php if ($server == "B") echo " selected"; ?>>B</option>
<option value="C"<?php if ($server == "C") echo " selected"; ?>>C</option>
<option value="D"<?php if ($server == "D") echo " selected"; ?>>D</option>
<option value="E"<?php if ($server == "E") echo " selected"; ?>>E</option>
<option value="F"<?php if ($server == "F") echo " selected"; ?>>F</option>
<option value="G"<?php if ($server == "G") echo " selected"; ?>>G</option>
<option value="H"<?php if ($server == "H") echo " selected"; ?>>H</option>
<option value="I"<?php if ($server == "I") echo " selected"; ?>>I</option>
<option value="J"<?php if ($server == "J") echo " selected"; ?>>J</option>
<option value="K"<?php if ($server == "K") echo " selected"; ?>>K</option>
<option value="L"<?php if ($server == "L") echo " selected"; ?>>L</option>
<option value="M"<?php if ($server == "M") echo " selected"; ?>>M</option>
<option value="N"<?php if ($server == "N") echo " selected"; ?>>N</option>
<option value="O"<?php if ($server == "O") echo " selected"; ?>>O</option>
<option value="P"<?php if ($server == "P") echo " selected"; ?>>P</option>
<option value="Q"<?php if ($server == "Q") echo " selected"; ?>>Q</option>
<option value="R"<?php if ($server == "R") echo " selected"; ?>>R</option>
<option value="S"<?php if ($server == "S") echo " selected"; ?>>S</option>
<option value="T"<?php if ($server == "T") echo " selected"; ?>>T</option>
<option value="U"<?php if ($server == "U") echo " selected"; ?>>U</option>
<option value="V"<?php if ($server == "V") echo " selected"; ?>>V</option>
<option value="W"<?php if ($server == "W") echo " selected"; ?>>W</option>
<option value="X"<?php if ($server == "X") echo " selected"; ?>>X</option>
<option value="Y"<?php if ($server == "Y") echo " selected"; ?>>Y</option>
<option value="Z"<?php if ($server == "Z") echo " selected"; ?>>Z</option>
<option value="0"<?php if ($server == "0") echo " selected"; ?>>0</option>
<option value="1"<?php if ($server == "1") echo " selected"; ?>>1</option>
<option value="2"<?php if ($server == "2") echo " selected"; ?>>2</option>
<option value="3"<?php if ($server == "3") echo " selected"; ?>>3</option>
<option value="4"<?php if ($server == "4") echo " selected"; ?>>4</option>
<option value="5"<?php if ($server == "5") echo " selected"; ?>>5</option>
<option value="6"<?php if ($server == "6") echo " selected"; ?>>6</option>
<option value="7"<?php if ($server == "7") echo " selected"; ?>>7</option>
<option value="8"<?php if ($server == "8") echo " selected"; ?>>8</option>
<option value="9"<?php if ($server == "9") echo " selected"; ?>>9</option>
</select>
</td>
</tr>

<tr class="methoddiv">
<td class="standard">
<b>Access Method:</b>
</td>
<td class="standard">
<input type="text" name="method" id="method" class="tws_file" required="required" style="width:15em;" maxlength="16" value="<?=htmlspecialchars($method)?>" <?php if($display == "yes") echo " readonly";?>/>
<?php if($display != "yes"):?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="button" name="method_list" id="method_list" value="List" onClick="tws_picker_open('method_picker.php', 'fieldname=method');"/>
<? endif;?>
</td>
</tr>

<tr class="hostdiv">
<td class="standard">
<b>Host:</b>
</td>
<td class="standard">
<input type="text" name="host" id="host" class="" <? if($tws_config['cpuinfo']['version']>='8.6') echo' required="required"'; ?> style="width:20em;" value="<?=htmlspecialchars($host)?>" <?php if($display == "yes") echo " readonly";?>/>
<?php if($display != "yes"): ?>&nbsp;&nbsp;&nbsp;&nbsp;
<? if($workstation_type == 'A' || $workstation_type == 'E' || $workstation_type == 'L' || $workstation_type == 'Y' ) : ?>
<input type="button" name="host_list" id="host_list" value="List" onClick="tws_picker_open('workstation_picker.php', 'type=b&amp;fieldname=host&amp;fieldvalue=' + document.contents.host.value);" />
<? else :?>
<input type="button" name="host_list" id="host_list" value="List" onClick="tws_picker_open('workstation_picker.php', 'fieldname=host&amp;fieldvalue=' + document.contents.host.value);" />
<input type="button" name="use_master" id="use_master" onClick="document.contents.host.value='$MASTER'; $(document.contents.host).keyup();" value="Use Master"/>
<? endif; ?>
<? endif; ?>
</td>
</tr>

<!-- POOL MEMBERS -->
<?php if($tws_config['cpuinfo']['version']>='8.6'): ?>
<tr class="membersdiv">
   <td class="standard" colspan="2"><h3>Members</h3></td>
</tr>

<tr class="membersdiv">
<td class="standard">
   <?php   // Get available pool's members
      $avail = tws_get_available_members();
      if(!is_array($members))
         $members = array();
   ?>
</td>
<td class="standard">
   <?php
   if (is_array($avail)) {
      echo"<table class='wireframe'>";
         for ($i=0; $i<count($avail); $i++) {
            echo "<tr>";
            echo "<td><input type='checkbox' name='members[]' value='$avail[$i]'"; if(in_array($avail[$i], $members)) echo" checked=''"; if($display == "yes") echo " disabled"; echo"></td>";
            echo "<td> $avail[$i]</td>\n";
            echo "</tr>";
         }
      echo"</table>";
      }
   else echo"No available members";
   ?>
</td>
</tr>
<? endif; ?>

<!-- DYNAMIC POOL REQUIREMENTS -->
<?php if($tws_config['cpuinfo']['version']>='8.6'): ?>
<tr class="requirementsdiv">
   <td class="standard" colspan="2"><h3>Requirements</h3></td>
</tr>
<tr class="requirementsdiv">
<td class="standard" valign="top">
   <?php
   // READ Requirements from XML to variables
if($workstation_type == 'Y' && isset($requirements) && $tmp_test == false) {
   $jsdl_data = tws_get_jsdl_requirements($requirements);
         foreach ($jsdl_data as $key => $value) {
            $$key=$value;
         }
}
elseif($tmp_test == true){
   $candidateOperatingSystems = $availableOS;
   $candidatedWorkstations = $workstations;
   foreach($resources as $key=>$val){
      if(isset($val['reserve']) && isset($val['name']))
         $reservedResources[] = $val;
      elseif(isset($val['name']))
         $relatedResources[] = $val;
   }
}

   // Get all selected logical resources (relatedResources + reservedResources)
   $display_name_resources = array();
   $i=0;
   if(is_array($relatedResources)){
      foreach($relatedResources as $resource) {
         $display_name_resources[$i] = strtoupper($resource['DisplayName']);
         $display_resources[$i]['name'] = $resource['DisplayName'];
         $display_resources[$i]['type'] = @$resource['subType'];
         $display_resources[$i]['quantity'] = @$resource['Quantity'];
         $display_resources[$i]['reserve'] = 0;
         $i++;
      }
   }
   if(is_array($reservedResources)){
      foreach($reservedResources as $resource) {
         $display_name_resources[$i] = strtoupper($resource['name']);
         $display_resources[$i]['name'] = $resource['name'];
         $display_resources[$i]['type'] = @$resource['subType'];
         $display_resources[$i]['quantity'] = @$resource['quantity'];
         $display_resources[$i]['reserve'] = 1;
      }
   }
   // get available resources
   $availableWorkstations = tws_get_available_members();
   $availableResources = tws_get_req_availableResources();
   if(!isset($candidateOperatingSystems))
      $candidateOperatingSystems = array();
   ?>
</td>
<td class="standard">
 <b>Operating Systems:</b>
   <table><tr>
     <td><input type='checkbox' name='availableOS[]' id="AIX" value="AIX" <?php if(in_array('AIX', $candidateOperatingSystems)) echo" checked"; if($display == "yes") echo " disabled";?> ></td><td> <label for="AIX">AIX</label></td>
     <td><input type='checkbox' name='availableOS[]' id="HPUX" value="HPUX" <?php if(in_array('HPUX', $candidateOperatingSystems)) echo" checked"; if($display == "yes") echo " disabled";?> ></td><td> <label for="HPUX">HP-UX</label></td>
     <td><input type='checkbox' name='availableOS[]' id="LINUX" value="LINUX" <?php if(in_array('LINUX', $candidateOperatingSystems)) echo" checked"; if($display == "yes") echo " disabled";?> ></td><td> <label for="LINUX">Linux</label></td>
     <td><input type='checkbox' name='availableOS[]' id="Solaris" value="Solaris" <?php if(in_array('Solaris', $candidateOperatingSystems)) echo" checked"; if($display == "yes") echo " disabled";?> ></td><td> <label for="Solaris">Solaris</label></td>
     <td><input type='checkbox' name='availableOS[]' id="Windows" value="Windows" <?php if(in_array('Windows', $candidateOperatingSystems)) echo" checked"; if($display == "yes") echo " disabled";?> ></td><td> <label for="Windows">Windows</label></td>
     <td><input type='checkbox' name='availableOS[]' id="ZOS" value="ZOS" <?php if(in_array('ZOS', $candidateOperatingSystems)) echo" checked"; if($display == "yes") echo " disabled";?> ></td><td> <label for="ZOS">z/OS</label></td>
     <td><input type='checkbox' name='availableOS[]' id="OS400" value="OS400" <?php if(in_array('OS400', $candidateOperatingSystems)) echo" checked"; if($display == "yes") echo " disabled";?> ></td><td> <label for="OS400">IBM i</label></td>
   </tr></table><br/>
   <b>CPU Utilization:</b><br/>
   Maximum value percentage <input type='text' size='5' class="tws_num" name='CPUUtilization' <?php if(isset($CPUUtilization)) echo" value='".htmlspecialchars($CPUUtilization)."'"; if($display == "yes") echo " readonly"; ?> /><br/><br/>
   <b>Include Logical Resources:</b>
   <?php
   if (is_array($availableResources)) {
      $key=0;
      echo"<table class='wireframe'><tr class='header'><th> </th><th>Resource name</th><th>Resource type</th><th>Quantity</th><th>Reserve resource</th></tr>";
         foreach ($availableResources as $resource) {
            $i = array_search(strtoupper($resource['name']), $display_name_resources);
            echo "<tr>";
            echo "<td><input type='checkbox' name='resources[$key][name]' value='$resource[name]'"; if($i!==false) echo" checked=''"; if($display == "yes") echo " disabled"; echo"/></td>";
            echo "<td> $resource[name]</td>\n";
            echo "<td> $resource[type] <input type='hidden' name='resources[$key][type]' value='$resource[type]'/></td>\n";
            if($i!==false) {
               $quantity = $display_resources[$i]['quantity'];
               echo "<td> <input type='text' size='5' class='tws_num' name='resources[$key][quantity]' value='".htmlspecialchars($quantity)."'";  if($display == "yes") echo " readonly"; echo"/></td>\n";
               echo "<td> <input type='checkbox' name='resources[$key][reserve]'"; if($display_resources[$i]['reserve']) echo " checked=''";  if($display == "yes") echo " disabled"; echo"/></td>";
            }
            else {
               echo "<td> <input type='text' size='5' class='tws_num' name='resources[$key][quantity]'";  if($display == "yes") echo " readonly"; echo"/></td>\n";
               echo "<td> <input type='checkbox' name='resources[$key][reserve]'";  if($display == "yes") echo " disabled"; echo"/></td>";
            }
            echo "</tr>";
            $key++;
         }
      echo"</table>";
      }
   else echo"No Logical Resources available<br>";
   ?>
   <br><b>Include Workstations:</b>
   <?php
   if (is_array($availableWorkstations)) {
      if(!isset($candidatedWorkstations))
         $candidatedWorkstations = array();
      echo"<table class='wireframe'>";
         foreach ($availableWorkstations as $ws) {
            echo "<tr>";
            echo "<td><input type='checkbox' name='workstations[]' value='$ws'"; if(in_array($ws, $candidatedWorkstations)) echo" checked=''";  if($display == "yes") echo " disabled"; echo"/></td>";
            echo "<td> $ws</td>\n";
            echo "</tr>";
         }
      echo"</table>";
   }
   else echo"No appropriate Workstations available<br>";
   ?>
   <br><b>Optimization:</b><br/>
      <table><tr><td colspan='2' align='left'>Select the best workstation for</td></tr>
      <tr>
      <td><label><input type="radio" name="optimization" value="WorkloadBalance" <?php if($optimization=="WorkloadBalance" || $optimization=='' || !isset($optimization)) echo " checked"; if($display == "yes") echo " disabled";?>/>
         Workload Balance</label></td>
      <td><label><input type="radio" name="optimization" value="CPUUtilization" <?php if($optimization=="CPUUtilization") echo " checked"; if($display == "yes") echo " disabled";?>/>
         CPU Utilization</label></td>
      </tr></table>
      <table><tr><td colspan='2'  align='left'>or Logical Resources</td></tr>
      <tr>
      <td><label><input type="radio" name="optimization" value="HighestQuantity" <?php if($optimization=="HighestQuantity") echo " checked"; if($display == "yes") echo " disabled";?>/>
         Highest Quantity</label></td>
      <td><label><input type="radio" name="optimization" value="HighestUtilization" <?php if($optimization=="HighestUtilization") echo " checked"; if($display == "yes") echo " disabled";?>/>
         Highest Utilization</label></td>
      </tr>
      <tr>
      <td><label><input type="radio" name="optimization" value="LowestQuantity" <?php if($optimization=="LowestQuantity") echo " checked"; if($display == "yes") echo " disabled";?>/>
         Lowest Quantity</label></td>
      <td><label><input type="radio" name="optimization" value="LowestUtilization"<?php if($optimization=="LowestUtilization") echo " checked"; if($display == "yes") echo " disabled";?>/>
         Lowest Utilization</label></td>
      </tr>
      </table>
</td>
</tr>
<? endif; ?>
</table>

<?
   if ($modify == "yes") {
      echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
      echo "<input type=\"hidden\" name=\"workstation_namex\" value=\"$workstation\">\n";
      echo "<input type=\"hidden\" name=\"original_data\" value=\"".htmlspecialchars($original_data)."\"/>\n";
      echo "&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Update\" onClick=\"return tws_validate_form()\"/>\n";
      echo "&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Cancel\" onclick=\"cancel_button_pressed=true\"/>\n";
      echo '&nbsp;&nbsp;<input type="button" value="Print" onClick="window.print()">';
      tws_print_synchro_token();
   }
   elseif($display == "yes") {
      echo '<input type="button" value="Print" onClick="tws_url_print();">';
      echo "&nbsp;&nbsp;&nbsp;<input type=\"button\" value=\"Close\" onClick=\"tws_url_close();\"/>\n";
   }
   else {
      echo "&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Add\" onClick=\"return tws_validate_form()\"/>\n";
      echo "&nbsp;&nbsp;<input type=\"button\" value=\"Cancel\" onClick=\"ConfirmCancel('Workstation','tws_workstationsx.php')\"/>\n";
      echo '&nbsp;&nbsp;<input type="button" value="Print" onClick="window.print()">';
      tws_print_synchro_token();
   }
?>
</form>
   <script type="text/javascript">
    sec_change();
    type_change();
   $('.tws_node').on("keyup", valid_tws_node);

   function valid_tws_node() {
      var pattern = /^[a-z0-9\-_.$]*$/i;
      var field_value = this.value;
      if (field_value.search(pattern)!=-1){
         $(this).removeClass("invalid");
         remove_err_tooltip(this);
      }
      else{
         $(this).addClass("invalid");
         show_err_tooltip(this);
      }
   }
   </script>
</div>
</body>
</html>