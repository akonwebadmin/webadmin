<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add Prompt</title>
<?php
tws_stylesheet();
tws_show_backup();
?>
</head>
<body>
<?
   tws_set_window_title();
   tws_check_synchro_token();  // synchro_token
   tws_import_request_variables("P","rqst_");

   if (isset($rqst_modify)) {
         if (!tws_permit_action('database_prompts','Modify')) { tws_access_denied ();}
         $modify=$rqst_modify;
   } else {
         if (!tws_permit_action('database_prompts','Add')) { tws_access_denied ();}
         $modify="no";
   }
   if (isset($rqst_confirm)) {
      $confirm=$rqst_confirm;
   } else {
      $confirm="no";
   }
   if (isset($rqst_backup)) {
      $backup=$rqst_backup;
   } else {
      $backup="no";
   }
   $original_data=tws_gpc_get($rqst_original_data);

/*   if ($modify == "yes") {
      $prompt_name=tws_gpc_get($rqst_prompt_namex, 'tws_name');
   } else */
   $prompt_name = tws_gpc_get($rqst_prompt_name, 'tws_name');
   $prompt_name=strtoupper($prompt_name);
   $prompt_folder = '';
   if(!empty($rqst_prompt_folder)){
      $prompt_folder = tws_gpc_get($rqst_prompt_folder, 'tws_name');
      $prompt_name = $prompt_folder.$prompt_name;
   }
   $prompt_text=tws_gpc_get($rqst_prompt_text);

   if (tws_zli_module_check () && isset ($rqst_netmodule_file))
       $netmodule_file = tws_gpc_get($rqst_netmodule_file, 'tws_file');

   $action=$rqst_action;
   if ($action=="Cancel") {
      // Unlock the object
      tws_composer_unlock("prom=$prompt_name") or tws_dyer("Unable to unlock prompt '$prompt_name'");
      echo "<script type='text/javascript'>\n";
         echo "  closeme('tws_promptsx.php');\n";
      echo "</script>\n";
      exit;
   }
   elseif($action=="Return to Modification"){
      include("tws_add_prompt.php");
      exit;
   }


// Check for existing prompt
   $match=FALSE;
   if ($confirm != "yes") {
      if (($db_prompt = tws_get_prompts($prompt_name)) === FALSE)
         tws_dyer("Unable to list prompts");
      if ($db_prompt['prompt_num'] > 1)
         tws_dyer("Database query failed");

      if(!empty($db_prompt['prompt_folder'][0]))
         $db_prompt['prompt_name'][0] = $db_prompt['prompt_folder'][0].$db_prompt['prompt_name'][0];

      if (($db_prompt['prompt_num'] == 1) && ($prompt_name == $db_prompt['prompt_name'][0])) {
         $orig_prompt_text = $db_prompt['prompt_text'][0];
         $match = TRUE;
      }
   }

   if ($match == TRUE) {
      if ($modify == "yes") {
         echo "<h1>Confirmation</h1>\n";
      } else {
         echo "<h1>Replace Prompt Confirmation</h1>\n";
      }
      echo "<br><br>\n";
      echo "<h3>Confirm:</h3>\n";
      if ($modify != "yes") {
         echo "&nbsp;&nbsp;<b>The Prompt Name entered already exists</b>\n";
         echo "<br><br>\n";
      }

      $orig_prompt_data = Array ( 'prompt_name' => $prompt_name , 'prompt_text' => $orig_prompt_text );
      $new_prompt       = Array ( 'prompt_name' => $prompt_name , 'prompt_text' => $prompt_text );
      $label_map        = Array ( 'prompt_name' => 'Name' , 'prompt_text' => 'Text' );

      tws_show_cmp_table("Original Prompt", "New Prompt", $orig_prompt_data, $new_prompt, $label_map);

// confirmation form

      echo "<form method=post name=\"confirm\" action=\"tws_add_prompt_exec.php\">\n";
      echo "<input type=\"hidden\" name=\"confirm\" value=\"yes\">\n";
      if ($original_data=='') {
         //missing original data - this happens if user is adding job that already exists.
         if (($original_data=tws_composer_create_from("prom=$prompt_name"))===FALSE) {
            tws_err("Unable to get original data required to create backup.");
         }
      }
      echo "<input type=\"hidden\" name=\"original_data\" value=\"".htmlspecialchars($original_data)."\">\n";
      foreach( $new_prompt as $key=>$val ){
         echo "<input type=\"hidden\" name=\"".htmlspecialchars($key)."\" value=\"".htmlspecialchars($val)."\">\n";
      }
      if (tws_zli_module_check () && isset ($netmodule_file)) {
          echo "<input type=\"hidden\" name=\"netmodule_file\" value=\"".htmlspecialchars($netmodule_file)."\">\n";
      }
      if (tws_rights(SAVEBACKUPS) && $original_data!=''){
         echo "<input type='hidden' name='backup' value='yes'>";
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type='checkbox' name='backup' value='yes' checked disabled>&nbsp;Save Backup Copy of Original Prompt</label>\n";
      }
      else
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type=\"checkbox\" name=\"backup\" value=\"yes\" ".($original_data!='' ? 'checked' : 'disabled').">&nbsp;Save Backup Copy of Original Prompt</label>\n";
      echo "<br><br><br>\n";

      if ($modify == "yes") {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' value='Update' name='action' onclick='tws_waiting(1)'>\n";
         echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
         echo "<input type=\"hidden\" name=\"prompt_namex\" value=\"".htmlspecialchars($prompt_name)."\">\n";
      }
      else {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' value='Replace' name='action' onclick='tws_waiting(1)'>\n";
      }
      echo '&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Return to Modification">'."\n";
      echo '&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Cancel">'."\n";
      tws_print_synchro_token();   // synchro_token
      echo "</form>\n";

      echo "<br><br>";
      echo "\$prompt\n"."$prompt_name \"".addcslashes($prompt_text,'"')."\"\n";
   }
   else {
// Create Backup Copy if option checked
      if ($backup == "yes") {
         if (($bckfilename = tws_write_backup($original_data, "prompt", $prompt_name)) === FALSE) {
            tws_dyer("Unable to write backup");
         }
      }
      // unlock the object
      tws_composer_unlock("prom=$prompt_name");

      $cmd = tws_prompt_to_composer($_POST, true);

//       OLD VERSION
/*
      $cmd=Array();
      $cmd[]="\$prompt\n";
      $cmd[]="$prompt_name  \"".addcslashes($prompt_text,'"')."\"\n";

      foreach ($cmd as $cmdline) {
         $num_bytes=fwrite($fp,$cmdline);
         if ($num_bytes < 0) {
            fclose($fp);
            tws_dyer("Unable to write temporary file");
         }
      }
*/

//    NEW VERSION

// Create random temporary filename
      $tmpfilename="$maestro_dir/webadmin/tmp/prompt.".tws_rndstr().".tmp";
      $fp=fopen($tmpfilename,'w') or tws_dyer("Unable to create temporary file");

         $num_bytes=fwrite($fp,$cmd);
         if ($num_bytes < 0) {
            fclose($fp);
            tws_dyer("Unable to write temporary file");
         }
      fclose($fp);
      tws_chmod($tmpfilename,0644);

      if ($confirm == "yes") {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "replace $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      } else {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "add $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      }

      $stdout3='';
      $ec_popen=tws_popen($command3, $ec3, $stdout3, $stdout3, "N");

      //remove the tmp file now
      unlink($tmpfilename);

      //testing for the AWSBIA288I Total objects updated: 0.
      //Note: This has been added on 2016-07 to fix the problem of composer updating
      //correctly objects but returning incorrect return codes (not 0 or 4)
      $not_updated=!preg_match('/AWSBIA288[^\n]+(\d+)/', $stdout3, $_r) || $_r[1]==0;

      if ($ec_popen===FALSE || ($ec3!=0 && $ec3!=4 && $not_updated)) {
         if ($modify == "yes") {
            echo "<h1>Modify Prompt Status</h1>\n";
         } else {
            echo "<h1>Add Prompt Status</h1>\n";
         }
         tws_err("Prompt add/modify operation failed", array('twscmd'=>$command3->compile('log'), 'stdout'=>$stdout3, "EC_POPEN"=>$ec_popen, "EC_UPDATED"=>$ec3, "NOT_UPDATED"=>tws_yesno($not_updated,'YES','NO')));
         echo "<form action='tws_add_prompt_exec.php' method='post' onsubmit=\"if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Workstation',null)) { cancel_button_pressed=false; return false;}\">\n";
         echo tws_create_hidden_inputs($_POST);
         tws_print_synchro_token();
         echo "<input type='submit' name='action' value='Cancel' onClick='cancel_button_pressed=true;'/>\n";
         echo "<input type='submit' name='action' value='Return to Modification'/>\n";
         echo "</form>";
      } else {
         if (preg_match("/warnings?\s[1-9]/i",$stdout3)) {
             if ($modify == "yes") {
                 $headertext="Modify Prompt";
             } else {
                 $headertext="Add Prompt";
             }
            tws_err("The Prompt has been saved with the following warnings:", array('stdout'=>$stdout3));
             $shortwarnfilename="warn.".tws_rndstr().".txt";
             $warnfilename="$webadmin_tmp_dir/$shortwarnfilename";
             $warnfp=fopen("$warnfilename","w") or tws_dyer("Unable to create warning text file", "Warning output :\n$stdout3");
             $num_bytes=fwrite($warnfp,"$stdout3");
             if ($num_bytes < 0) {
                 fclose($warnfp);
                 unlink($warnfilename);
                 tws_dyer("Unable to write warning text file", "Warning output :\n$stdout3");
            }
            fclose($warnfp);
            tws_dyer();
         }
         if (tws_zli_module_check () && isset ($netmodule_file)) {
             require_once ("zli_lib.php");
             zli_netmod_file_editprompt($prompt_name, $prompt_text, $netmodule_file);
             $message = urlencode ("The prompt has been saved successfuly.");
             echo "<script type='text/javascript'>\n";
             echo "window.location.replace(\"zli_close_window.php?message=$message\");\n";
             echo "</script>\n";
         }
         else {
            if ($backup == "yes") {
               if ($modify == "yes") {
                  echo "<h1>Modify Prompt Status</h1>\n";
               } else {
                  echo "<h1>Add Prompt Status</h1>\n";
               }
               echo "<p class=\"message\">\n";
               echo "The prompt has been successfuly saved.&nbsp;";
               $bckfilename = preg_replace("/\\\\/", '/', $bckfilename);
               $file = explode('/',$bckfilename);
               $file = end($file);
               if(tws_profile('auth_user_group')=='admin')
                  echo "<a href=\"javascript:showBackup('$file')\">Display Backup File</a>\n";
               echo "</p>\n";
               echo "<input type='button' value='OK' onClick=\"closeme('tws_promptsx.php')\" />\n";
            }
            else {
               echo "<script type='text/javascript'>\n";
               echo "closeme('tws_promptsx.php');\n";
               echo "</script>\n";
            }
         }
      }
   }
?>
</body>
</html>
