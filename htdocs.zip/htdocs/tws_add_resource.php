<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");

   // Cancel button test
   $tmp_test = (isset($_POST['action']) && $_POST['action'] == 'Return to Modification') ? true : false;
   if ($tmp_test == true) {
      foreach ($_POST as $key => $val){
         $$key = tws_gpc_get($val);
      }
   }
   if ($copy == "yes") $h1 = "Copy Resource";
   elseif ($modify == "yes") $h1 = "Modify Resource";
   else $h1 = "Add Resource";
?>
<html>
<head>
<title><?=$h1 ?></title>
<?php tws_stylesheet(); ?>
<script type="text/javascript">
function ConfirmCancel(objectname,url){
   $('form').unbind('submit');
   var conftext=confirm("Exit " + objectname + " Definition (Changes will be lost) ?");
   if (conftext) {
      if (url==null) return true;
      closeme(url);
   } else {
      return false;
   }
}
</script>
</head>
<body>
<?
   tws_set_window_title();
   $log_file_name=tws_log('', 'OPEN');
   tws_print_head($h1, array('__log__' => $log_file_name, '__help__' => 'tws_add_resources_help.php'));

   if ($tmp_test == false && ($copy == "yes" || $modify == "yes")) {

      $num_elements=count($selection);
      if ($num_elements == 0) {
         tws_dyer("No resource selected");
      } elseif ($num_elements > 1) {
         tws_dyer("Multiple resources selected. Only one resource can be copied at a time.");
      }

   tws_log('-- START ('.basename(__FILE__).'['.__LINE__.'])');
   tws_log(" -- tws_add_resource.php selection parameter: $selection[0]");


      $workstation=strtok($selection[0],"#");
      $resource=strtok("\n");
   tws_log(" -- tws_add_resource.php: workstation = $workstation, resource = $resource");

      if (($db_resource=tws_get_resources($workstation."#".$resource))===FALSE){
         tws_dyer("Unable to list resources");
      }
      if ($db_resource['resource_num'] != 1) {
         tws_dyer("Database query failed");
      }
      tws_adjust4html($db_resource);
      tws_log(" -- tws_add_resource. Result: ". var_export($db_resource, true));

      $workstation_folder = '';
      if(!empty($db_resource['workstation_folder'][0]) )
         $workstation_folder = $db_resource['workstation_folder'][0];

      $resource_folder = '';
      if(!empty($db_resource['resource_folder'][0]) )
         $resource_folder = $db_resource['resource_folder'][0];

      tws_log(" -- tws_add_resource: workstation_folder = $workstation_folder, resource_folder = $resource_folder");

      $workstation_name = $workstation_folder.$db_resource['resource_workstation'][0];
      //$resource_name = $resource_folder.$db_resource['resource_name'][0];
      $resource_name = $db_resource['resource_name'][0];
      $resource_units = $db_resource['resource_quantity'][0];
      $resource_description = $db_resource['resource_description'][0];

      if ($modify=="yes") {
// lock object
         tws_composer_lock("res=$selection[0]") or tws_dyer("Unable to lock resource '$selection[0]'");
//backup
         if (($original_data=tws_composer_create_from("res=$selection[0]"))===FALSE) tws_dyer("Unable to create backup");
      }

   }
?>

<br><br>
<form method=post name="contents" action="tws_add_resource_exec.php" onsubmit="if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Resource',null)) { cancel_button_pressed=false; return false;}">

<table border=0 cellspacing=0>
<tr>
<td class=standard>
&nbsp;&nbsp;<b>Workstation:</b>
</td>
<td class=standard>
<input type="text" name="workstation" class="tws_name" required="required" size="60" <? if (isset($workstation_name)) echo " value=\"$workstation_name\""; ?><?php if ($modify == "yes") echo " disabled"; ?>>
<? if ($modify != "yes") { ?>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" name="workstation_list" onClick="tws_picker_open('workstation_picker.php', 'fieldname=workstation&amp;fieldvalue=' + document.contents.workstation.value);" value="List">
<? } ?>
</td>
</tr>
<? if ($tws_config['cpuinfo']['version']>='9.5002'){ ?>
      <tr>
      <td class=standard>&nbsp;&nbsp;<b>Resource Folder:</b></td>
      <td><input type="text" name="resource_folder" class="tws_name" required="required" size="60" value="<?=htmlspecialchars($resource_folder)?>" <? if ($modify == "yes" || $display == "yes") echo " disabled"; ?> />
         <? if ($modify != "yes") { //&& $display != "yes") { ?>
         &nbsp;&nbsp;&nbsp;&nbsp;<input type="button" name="resource_folder_list" onClick="tws_picker_open('folder_picker.php', 'fieldname=resource_folder&amp;fieldvalue=' + document.contents.resource_folder.value);" value="List">
         <? } ?>
      </td>
      </tr>
   <? } ?>

<tr>
<td class=standard>
&nbsp;&nbsp;<b>Resource Name:</b>
</td>
<td class=standard>
<input type="text" name="resource_name" class="tws_name" required="required" <?if (isset($resource_name)) echo " value='$resource_name'"; ?> <?if ($modify == "yes") echo " disabled";?> >
</td>
</tr>
<?
   if ($copy == "yes") {
      echo "<script type='text/javascript'>\n";
      echo "<!--\n";
      echo "document.contents.resource_name.focus();\n";
      echo "document.contents.resource_name.select();\n";
      echo "// -->\n";
      echo "</script>\n";
   }
?>
<tr>
<td class=standard>
&nbsp;&nbsp;<b>Units:</b>
</td>
<td class=standard>
<input type="text" name="resource_units" required="required" class="tws_num" size=4 maxlength=4 <? if (isset($resource_units)) echo " value=\"$resource_units\""; ?> >
</td>
</tr>
<tr>
<td class=standard>
&nbsp;&nbsp;<b>Description:</b>
</td>
<td class=standard>
<input type="text" name="description" size=64 maxlength=64 <? if (isset($resource_description)) echo " value=\"$resource_description\""; ?> >
</td>
</tr>
</table>
<br><br>
<?
   if ($modify == "yes") {
      echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
      echo "<input type=\"hidden\" name=\"workstation\" value=\"$workstation_name\">\n";
      echo "<input type=\"hidden\" name=\"resource_folder\" value=\"$resource_folder\">\n";
      echo "<input type=\"hidden\" name=\"resource_name\" value=\"$resource_name\">\n";
      echo "<input type=\"hidden\" name=\"original_data\" value=\"".htmlspecialchars($original_data)."\">\n";
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Update\" onClick=\"return tws_validate_form()\"/>\n";
   } else {
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Add\" onClick=\"return tws_validate_form()\"/>\n";
   }

   if ($modify=="yes") {
      if (tws_zli_module_check () && isset ($called_by_netmodule))
          echo "<input type=\"hidden\" name=\"called_by_netmodule\" value=\"$called_by_netmodule\">\n";
      else
          echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Cancel\" onClick=\"cancel_button_pressed=true;\"/>\n";
   } else {
      echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"button\" value=\"Cancel\" onClick=\"ConfirmCancel('Resource','tws_resourcesx.php')\"/>\n";
   }
   tws_print_synchro_token();   // synchro_token
?>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" value="Print" onClick="window.print()">
</form>
</body>
</html>
