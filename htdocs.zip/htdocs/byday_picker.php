<?php
//   HORIZONT Software GmbH, Munich
//
   $__tlogmode='APPEND';
   require_once "tws_functions.php";

   tws_import_request_variables("P","rqst_");

   $fieldname=$rqst_fieldname;
   tws_check_elname($fieldname);
   $fieldvalue=@$rqst_fieldvalue;
   $freq=$rqst_freq;
   $display="yes";

   $values=explode(",",$fieldvalue);

   if (!isset($fieldname)) {
      $fieldname="calendar";
   }
   if ((strpos($fieldname,"[") !== FALSE) && (strpos($fieldname,"]") !== FALSE)) {
      $jsfieldname="elements['" . $fieldname . "']";
   }
   else {
      $jsfieldname = $fieldname;
   }
?>

<script type="text/javascript">

function sendValue(formsel) {
   var selectionval = "";
   for (var i = 0; i < formsel.options.length; i++)
      if (formsel.options[i].selected)
         selectionval = selectionval + formsel.options[i].value + ",";
   window.document.contents.<?=$jsfieldname ?>.value = selectionval.substr(0, selectionval.length - 1);

   $('[name="<?=$fieldname?>"]').keyup();
   $("#byday_picker").dialog( "close" );
}

</script>

<div id="byday_picker">

<h1>Select day(s)</h1>

<form name="day_list">

<?
switch ($freq) {
   case "" : echo "Frequency not selected"; break;
   case "DAILY" : echo "Daily"; break;
   case "WEEKLY" : echo "Weekly";break;
   case "MONTHLY" : echo "Monthly by month days"; break;
   case "MONTHLY2" : echo "Monthly by week days"; break;
   case "YEARLY" : echo "Yearly - nothing to select";
}
?>
<br /><br />
<select name="selection" size=14 class="picker" onDblClick="sendValue(this.form.selection);" <?if ($freq!="DAILY") echo " multiple";?>>
<?
switch ($freq) {
   case "DAILY": ?>
      <option value=""<?php if (in_array('',$values)) echo " selected"; ?>>Everyday</option>
      <option value=BYWORKDAY<?if (in_array('BYWORKDAY',$values)) echo " selected";?>>Workdays</option>
      <option value=BYFREEDAY<?if (in_array('BYFREEDAY',$values)) echo " selected";?>>Freedays</option>
<?php   break;
   case "WEEKLY": ?>
      <option value=MO<?if (in_array('MO',$values)) echo " selected";?>>Monday</option>
      <option value=TU<?if (in_array('TU',$values)) echo " selected";?>>Tuesday</option>
      <option value=WE<?if (in_array('WE',$values)) echo " selected";?>>Wednesday</option>
      <option value=TH<?if (in_array('TH',$values)) echo " selected";?>>Thursday</option>
      <option value=FR<?if (in_array('FR',$values)) echo " selected";?>>Friday</option>
      <option value=SA<?if (in_array('SA',$values)) echo " selected";?>>Saturday</option>
      <option value=SU<?if (in_array('SU',$values)) echo " selected";?>>Sunday</option>
<?php   break;
   case "MONTHLY":
      for ($i=-10;$i<=31;$i++) {
         if ($i !=0) {
            echo "<option value=$i";
            if (in_array($i,$values)) echo " selected";
            echo ">$i</option>";
         }
      }
      break;
   case "MONTHLY2":
      $month_wdays=Array('1MO','1TU','1WE','1TH','1FR','1SA','1SU',
                         '2MO','2TU','2WE','2TH','2FR','2SA','2SU',
                         '3MO','3TU','3WE','3TH','3FR','3SA','3SU',
                         '4MO','4TU','4WE','4TH','4FR','4SA','4SU',
                         '-1MO','-1TU','-1WE','-1TH','-1FR','-1SA','-1SU');
      foreach ($month_wdays as $day) {
         echo "<option value=$day";
         if (in_array($day,$values)) echo " selected";
         echo ">";
         switch (substr($day,0,-2)) {
            case "1": echo "1st"; break;
            case "2": echo "2nd"; break;
            case "3": echo "3rd"; break;
            case "-1": echo "Last"; break;
            default: echo substr($day,0,-2)."th";
         }
         echo " ";
         switch (substr($day,-2)){
            case "MO": echo "Monday";break;
            case "TU": echo "Tuesday";break;
            case "WE": echo "Wednesday";break;
            case "TH": echo "Thursday";break;
            case "FR": echo "Friday";break;
            case "SA": echo "Saturday";break;
            case "SU": echo "Sunday";break;
         }
         echo "</option>\n";
      }
}
?>
</select>
<br><br>
<center><input type="button" value="OK" onClick="sendValue(this.form.selection);"></center>
</form>
</div>

<script type="text/javascript">

$(function() {
   tws_picker_constructor("byday_picker");
});

</script>
