<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add Critical Jobs List</title>
<?php tws_stylesheet(); ?>
</head>
<body>
<?php tws_set_window_title(); ?>

<h1>Add Critical Jobs List</h1>
<br>

<?php
   tws_import_request_variables("P","rqst_");

   $description=tws_gpc_get($rqst_description);

// Make sure database variables are set
   // conect to database
   db_connect($webadmin_db, DB_PERSISTENT) or tws_dyer("Cannot connect to database");
   $schema=$webadmin_db['schema'];

// Get next critical jobs list number
   $query="SELECT MAX(listnum) AS max_listnum FROM $schema.critical_jobs_lists";
   db_query($webadmin_db,$query) or tws_dyer("Unable to determine next critical jobs list number");
   $row=db_fetch_row($webadmin_db);
   $list_number=$row['MAX_LISTNUM'] + 1;

// Insert deadline
   $query="INSERT INTO $schema.critical_jobs_lists (listnum,listdesc) VALUES ($list_number,'".db_string($webadmin_db,$description)."')";
   db_query($webadmin_db,$query) or tws_dyer("Insert into table 'critical_jobs_lists' failed - unable to complete request.");
   if (isset($webadmin_db['allow_persistent']) && tws_yesno($webadmin_db['allow_persistent'])=='NO')
      db_commit($webadmin_db) or tws_dyer("Insert into table 'critical_jobs_lists' failed - unable to COMMIT request.");
   db_close($webadmin_db);

   if(isset($rqst_forall))
      tws_add_critical_listnum($tws_config['webadmin_all_user_dir'].$tws_config['user_setting_dir'].'/critical_lists.php', $list_number);
   else tws_add_critical_listnum($tws_config['webadmin_user_home_dir'].'/'.tws_profile('auth_user_name').$tws_config['user_setting_dir'].'/critical_lists.php', $list_number);
?>
   
<script type='text/javascript'>
   window.location.replace("tws_critical_jobs_lists.php?list_number=<?=$list_number?>");
</script>

</body>
</html>

<?
function tws_add_critical_listnum($fname, $num){
   $fp = fopen($fname, 'a');
   fwrite($fp, $num."\n");
   fclose($fp);
}
?>