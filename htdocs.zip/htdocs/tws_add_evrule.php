<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   require_once "tws_evt.php";
   tws_doctype("t");

   $log_file_name=tws_log('', 'OPEN');
   tws_log('-- START ('.basename(__FILE__).'['.__LINE__.'])');
   $execution_time = tws_getmicrotime();
?>
<html>
<head>
<title>Add Event Rule</title>
<?php tws_stylesheet(); ?>
<script type="text/javascript">
var ignore_err_tooltip = true;   // don't show err_tooltips

function ConfirmCancel(objectname,url){
   $('form').unbind('submit');
   var conftext=confirm("Exit " + objectname + " Definition (Changes will be lost) ?");
   if (conftext) {
      if (url==null) return true;
         closeme(url);
   } else {
      return false;
   }
}
function setPrio(val){
   document.contents.priority.value=val;
}
</script>
<?php
   evt_js();
?>
</head>
<body>
<?php
   tws_set_window_title();
   tws_import_request_variables("P","rqst_");
   if (!isset($copy)) { @$copy=$rqst_copy;  }
   if (!isset($modify)) { @$modify=$rqst_modify; }
   @$override=$rqst_override;

   if ($copy=="yes") {
      $h1="Copy Event Rule";
      $action_verb="copied";
   } elseif ($modify=="yes") {
      $h1="Modify Event Rule";
      $action_verb="modified";
   } else {
      $h1="Add Event Rule";
      $action_verb="added";
   }

   tws_print_head($h1, array('__help__' => 'tws_add_evrule_help.php', '__log__' => $log_file_name));

   if (isset($rqst_action) && preg_match('/return/i',$rqst_action)) {   // return from exec
      $evrule=tws_gpc_get($_POST['evrules']['evrule_name'][0], 'tws_name');
      $evrules=tws_gpc_get($_POST['evrules']);
      $events=tws_gpc_get($_POST['events']);
      $actions=tws_gpc_get($_POST['actions']);
      $original_data=tws_gpc_get($_POST['original_data']);
   } elseif ($modify=="yes" || $copy=="yes") {
      $num_elements=count($selection);
      if ($num_elements == 0) {
         tws_dyer("No event rule selected");
      } elseif ($num_elements > 1) {
         tws_dyer("Multiple even rules selected - Only one event rule can be $action_verb at a time");
      }

      if (isset($selection[0])) {
         $evrule=$selection[0];
      } else {
         tws_dyer("Unable to read selected event rule name");
      }

      if ($modify=="yes" && !$original_data) {
         tws_composer_lock("erule=$evrule") or tws_dyer("Unable to lock event rule");
         if (($original_data=tws_get_evrule_definition_text($evrule))===FALSE) {
            tws_dyer("Unable to get event rule original data for backup");
         }
      }

      //------------------------------------------------------------------------------
      if (($evrules=tws_get_evrules($evrule))===FALSE) {
         tws_err('Unable to get event rule general data','event rule: '.$evrule);
      }
      if (($events=tws_get_evrule_conditions($evrule))===FALSE) {
         tws_err('Unable to get event rule conditions','event rule: '.$evrule);
      }
      if (($actions = tws_get_evrule_actions($evrule))===FALSE)  {
         tws_err('Unable to get event rule actions','event rule: '.$evrule);
      }
   }
?>
<form method="post" name="contents" action="tws_add_evrule_action.php" onsubmit="if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Event Rule',null)) { cancel_button_pressed=false; return false;}">
<div id="tabs">
   <ul>
      <li><a href="#general">General Options</a></li>
      <li><a href="#events">Events</a></li>
      <li><a href="#actions">Actions</a></li>
   </ul>
   <!--========================================================================-->
   <div id="general">
      <?=tws_get_evt_form_general($evrules,TRUE,'div#tabs',FALSE);?>
   </div>
   <!--========================================================================-->
   <div id="events" style="display:none">
   <?=tws_get_evt_form('cond',$evrules,$events,TRUE,'div#tabs');?>
   </div>
   <!--========================================================================-->
   <div id="actions" style="display:none">
   <?=tws_get_evt_form('act',$evrules,$actions,TRUE,'div#tabs');?>
   </div>
</div>
<br>
<?php tws_err(); ?>
<br>
<?
   if ($modify=="yes") {
      echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
      echo "<input type=\"hidden\" name=\"locked\" value=\"yes\">\n";
      echo "<input type=\"hidden\" name=\"evrule_namex\" value=\"".htmlspecialchars($evrule)."\">\n";
      echo "<input type=\"hidden\" name=\"original_data\" value=\"".htmlspecialchars($original_data)."\"/>\n";
      echo "&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Update\" onClick=\"return tws_validate_form()\"/>\n";
   } else {
      echo "<input type=\"hidden\" name=\"modify\" value=\"no\">\n";
      echo "&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Add\" onClick=\"return tws_validate_form()\"/>\n";
   }
   if ($copy=="yes") {
      echo "<input type=\"hidden\" name=\"original_data\" value=\"".htmlspecialchars($original_data)."\"/>\n";
      echo "<input type=\"hidden\" name=\"copy\" value=\"yes\">\n";
   } else {
      echo "<input type=\"hidden\" name=\"copy\" value=\"no\">\n";
   }
   echo "<input type=\"hidden\" name=\"override\" value=\"".htmlspecialchars($override)."\">\n";
?>
<?php
   if ($modify=="yes") {
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Cancel\" onClick=\"cancel_button_pressed=true;\"/>\n";
   } else {
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"button\" value=\"Cancel\" onClick=\"ConfirmCancel('Event Rule','tws_evrulesx.php')\"/>\n";
   }
   tws_print_synchro_token();  // synchro token
?>
</form>
<script>
   $(function() {
      <?php
         if ($modify=='yes') {
			echo '      $(\'input[name="evrules[evrule_name][0]"]\').attr(\'disabled\',\'disabled\');'."\n";
			echo '      $(\'input[name="evrules[evrule_folder][0]"]\').attr(\'disabled\',\'disabled\');'."\n";  //jozsef
		 }
         if ($copy=='yes')  echo '      $(\'input[name="evrules[evrule_name][0]"]\').focus();'."\n";
      ?>
      $("#tabs").tabs();
      $("#tabs").css("background-color","transparent");
      $("#tabs").css("border","none 0px");
   });
</script>

</body>
</html>
