<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";

   if (defined('IWD_PROCMAN')) {
      $iwd_class='iwd_cpjb';
      $search_elems=array();
      $search=$iwd_class::get_search_elems($search_elems, 'ref');
   }

   tws_import_request_variables("P","rqst_");

   $cpux=strtoupper(trim($rqst_cpux));
   $schedulex=strtoupper(trim($rqst_schedulex));
   $fieldname=$rqst_fieldname;
   $wksfieldname=$rqst_wksfieldname;
   $jsfieldname=$rqst_jsfieldname;
   $fieldvalue=trim($rqst_fieldvalue);
   $allowmultiple=@$rqst_allowmultiple;
   $display="yes";
   tws_check_elname($wksfieldname);
   tws_check_elname($jsfieldname);
   tws_check_elname($fieldname);

   if (!isset($fieldname))
      $fieldname='job';

   $show_full_name = false;
   if (preg_match('/[*@]/', $cpux) || preg_match('/[*@]/', $schedulex))
      $show_full_name = true;
?>
<script type="text/javascript">
function updateValue(val) {
	// TODO:  send values to WS and JS field with folders
   <? if(!empty($wksfieldname)): ?>
//      if (val.indexOf('#')>0)
//         $('[name="<?//=$wksfieldname?>"]').val(val.substr(0, val.indexOf('#')));
   <? endif; ?>
   <? if(!empty($jsfieldname)): ?>
//      if (val.indexOf('#')>0 && val.indexOf('.')>0)
//         $('[name="<?//=$jsfieldname?>"]').val(val.substr(val.indexOf('#')+1, val.indexOf('.')-val.indexOf('#')-1));
   <? endif; ?>

   if (val.indexOf('#')>0 && val.indexOf('.')>0)
      $('[name="<?=$fieldname?>"]').val(val.substr(val.indexOf('.')+1, val.length - val.indexOf('.')-1) );
   else
      $('[name="<?=$fieldname?>"]').val(val);
   <? if(!empty($wksfieldname)): ?> $('[name="<?=$wksfieldname?>"]').keyup(); <? endif; ?>
   <? if(!empty($jsfieldname)): ?> $('[name="<?=$jsfieldname?>"]').keyup(); <? endif; ?>
   $('[name="<?=$fieldname?>"]').keyup();
}

function sendValue(formsel) {
   var selval = "";
   if (formsel) {
      for (var i = 0; i < formsel.options.length; i++) {
         if (formsel.options[i].selected) {
            selval = selval + formsel.options[i].value + ",";
         }
      }
      if(selval != "") updateValue(selval.substr(0,selval.length-1));
   }
   $("#plan_job_picker").dialog( "close" );
}

   <?php
      if (defined('IWD_PROCMAN')) {
         if (trim($fieldvalue)=='') {
            $fieldvalue=$search_elems[$iwd_class][0];
            echo "updateValue('".$fieldvalue."');\n";
         }
      }
   ?>
</script>

<div id="plan_job_picker">

<h1>Select Job</h1>
<br>

<form name="job_list">

<?php
   if ($cpux=='') {
      echo "<center><p class=warning>No workstation name selected</p>\n";
      echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\"></center>\n";
   } elseif ($schedulex=='') {
      echo "<center><p class=warning>No jobstream name selected</p>\n";
      echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\"></center>\n";
   } else {
      if ($fieldvalue=='') {
         $arg='@';
      } else {
         if ((strpos($fieldvalue,'*')===FALSE) && (strpos($fieldvalue,'@')===FALSE)) {
            $arg=$fieldvalue.'@';
         } elseif (strpos($fieldvalue,'*')!==FALSE) {
            $arg=strtr($fieldvalue,'*','@');
         } else {
            $arg=$fieldvalue;
         }
      }

      @list($schedulex_name,$schedulex_id)=explode(';',$schedulex);
      if ($schedulex_id)
         $arg="$cpux#$schedulex_id.$arg;schedid";
      else {
      $arg="$cpux#$schedulex_name.$arg";
         $show_full_name = true;
      }
      echo "<select id='sel' name='selection' class='picker' size=14 onDblClick='sendValue(this.form.selection);'";
      if ($allowmultiple == "yes") {
         echo " multiple";
      }
      echo ">\n";

      function plan_job_picker_callback(&$sjs,$ia,$ib) {
         global $show_full_name;
         for ($i=$ia; $i<=$ib; $i++) {
            if ($sjs['entry_type'][$i]=='job' && !isset($sjs['x'][$i])){
               echo '<option value="'.$sjs['cpu'][$sjs['sched_idx'][$i]].'#'.$sjs['schedule'][$sjs['sched_idx'][$i]].';'.$sjs['schedid'][$sjs['sched_idx'][$i]].'.'.$sjs['job'][$i].'">'.($show_full_name? $sjs['cpu'][$sjs['sched_idx'][$i]].'#'.$sjs['schedule'][$sjs['sched_idx'][$i]].'  [('.$sjs['schedtime'][$sjs['sched_idx'][$i]].') ('.$sjs['schedid'][$sjs['sched_idx'][$i]].')].':'').$sjs['job'][$i].'</option>',"\n";
            }
         }
      }

      if (defined('IWD_PROCMAN')) { //IWD/ProcMan
         $arg=strtr($arg,"@","*");
         if (($objs=$iwd_class::get_listing($arg, 'ref'))!==FALSE) {
            foreach($objs as $obj) {
               echo '<option value="'.$obj['rname'].'" '.(($obj['rname']==$fieldvalue) ? 'selected' : '').'>'.$obj['name'].'</option>'."\n";
            }
            $result['nrows']=count($objs);
            echo "</select>\n";
         } else {
            echo '</select>';
            hwi_log_flush();
            $result=FALSE;
         }
      }
      else { //IWS/WebAdmin
         $result=tws_get_plan_job_list($arg, 0, 0, 1, 'plan_job_picker_callback');
         echo "</select>\n";
      }

      if ($result===FALSE || $result['nrows']==0) {
         echo "<center>";
         echo '<script type="text/javascript">',"\n",'  deleteElem(\'sel\');',"\n",'</script>',"\n";
         if ($result===FALSE)
            echo '<p class="warning">Unable to get plan job list.</p>',"\n";
         else echo '<p class="warning">No qualified entries matching ',htmlspecialchars($cpux.'#'.$schedulex),'.',($fieldvalue=='' ? '@' : htmlspecialchars($fieldvalue)),'.</p>',"\n";
         echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\"></center>\n";
      } else {
         echo "<br><br>\n";
         echo "<center><input type=\"button\" value=\"OK\" onClick=\"sendValue(this.form.selection);\"></center>\n";
      }
   }
?>
</form>
</div>

<script type="text/javascript">

$(function() {
   tws_picker_constructor("plan_job_picker");
});

</script>
