<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
   tws_profile('opener', basename($_SERVER['REQUEST_URI']));
?>
<html>
<head>
<title>Calendar Date Cross Reference Report Design</title>
<?php tws_stylesheet(); ?>
<script type="text/javascript" src="tws_js_xref_functions.js"></script>
<script type="text/javascript">
   function y2k(number) { return (number < 1000) ? number + 1900 : number; }

   var today = new Date();
   var day   = today.getDate();
   var month = today.getMonth();
   var year  = y2k(today.getYear());
   var showtoday = '#e0e0e0';

   function padout(number) { return (number < 10) ? '0' + number : number; }

   function restart() {
    document.contents.date.value = '' + year + '-' + padout(month - 0 + 1) + '-' + padout(day);
    datewindow.close();
   }
   function dateWindow() {
    datewindow=open('date_picker.html','date_picker','width=350,height=270,toolbar=no,menubar=no,location=no,scrollbars=no,resizable=no');
    datewindow.location.href = 'date_picker.html';
    if (datewindow.opener == null) datewindow.opener = self;
   }
</script>
</head>
<body>
<?php tws_set_window_title();
tws_print_head("Calendar Date Cross Reference Report Design");
?>
<br>

<form method=post name="contents" action="tws_view_dates_xref_report.php">
<table border=0 cellspacing=0>
<tr>
<td class=standard width=140>
<h3>Criteria</h3>
</td>
</tr>
<tr>
<td class=standard width=140>
&nbsp;&nbsp;<b>Date:</b>
</td>
<td class=standard><?=tws_datetime_picker('date', '', '', '', "'dropdown',false,'24',true,false,false");?></td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class=standard width=140>
<h3>Contents</h3>
</td>
</tr>
<tr>
<td class=standard colspan=2>
&nbsp;&nbsp;<label><input type="checkbox" name="include" value="calendars" id="calendars" checked disabled>Calendars</label>
<input type="hidden" name="include" value="calendars">
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class=standard colspan=2>
&nbsp;&nbsp;&nbsp;<a href="Javascript:XCheckOne();">Check All</a>&nbsp;&nbsp;-&nbsp;&nbsp;<a href="Javascript:XClearOne();">Clear All</a>
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class=standard width=140>
<h3>Options</h3>
</td>
</tr>
<tr>
<td class=standard>
&nbsp;&nbsp;<b><label><input type="checkbox" name="title" value="yes">
Set Title:</label></b>
</td>
<td><input type="text" name="titletext" size=40 maxlength=100 onkeyup="set_titlebox();"></td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr><td class=standard colspan=2>
&nbsp;&nbsp;<b><label><input type="checkbox" name="show_stats" id="show_stats" value="yes" checked='checked'/>
Show Query Statistics</label></b>
</td></tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class=standard colspan=2>
&nbsp;&nbsp;<b><label><input type="checkbox" name="opennew" value="yes" onClick="XChngTarg(this.checked)">
Open Report in New Window</label></b>
</td>
</tr>
</table>
<br><br>
<input type='hidden' name='home' value='tws_dates_xref_report.php'/>
<input type="submit" value="Generate Report" name="action" onclick="return tws_validate_form();">

</form>
</body>
</html>
