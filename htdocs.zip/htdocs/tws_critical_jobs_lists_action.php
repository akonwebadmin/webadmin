<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_import_request_variables("P","rqst_");

   $action=tws_gpc_get($rqst_action);
   $list_number=tws_gpc_get($rqst_list_number);
   $selection=tws_gpc_get($rqst_selection, 'tws_filter'); // ws#js.job

   switch ($action) {
     case "Create New List":
       include("tws_add_critical_jobs_list.php");
       break;
     case "Delete List":
       include("tws_delete_critical_jobs_list.php");
       break;
     case "Add":
       include("tws_add_critical_job.php");
       break;
     case "Modify":
       include("tws_modify_critical_job.php");
       break;
     case "Delete":
       include("tws_delete_critical_job.php");
       break;
   }
?>