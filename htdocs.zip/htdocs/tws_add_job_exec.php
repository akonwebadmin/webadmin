<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add Job</title>
<?php
tws_stylesheet();
tws_show_backup();
tws_set_window_title();
?>
<script type="text/javascript">
   function ConfirmCancel(objectname, url) {
   tws_waiting(0);
      var conftext = confirm("Exit " + objectname + " Definition (Changes will be lost) ?");
      if (conftext) {
         if (url==null) return true;
            closeme(url);
      } else {
         return false;
      }
   }
</script>
</head>
<body>
<?php
   if ($modify == "yes") {
      if (!tws_permit_action('database_jobs','Modify')) { tws_access_denied ();}
      //$workstation=$workstationx;
      //$job=$jobx;
      if(isset($passwordx) && $passwordx != '******') {
         $password = $passwordx;
         $myPost['password'] = $passwordx;
      }
      if(isset($rem_passwordx) && $rem_passwordx != '******') {
         $rem_password = $rem_passwordx;
         $myPost['rem_password'] = $rem_passwordx;
      }
      if(isset($loc_passwordx) && $loc_passwordx != '******') {
         $loc_password = $loc_passwordx;
         $myPost['loc_password'] = $loc_passwordx;
      }
   }
   else {
      if (!tws_permit_action('database_jobs','Add')) { tws_access_denied ();}
   }
      $workstation = trim("$workstation");
      $job = trim("$job");
   tws_check_arg($workstation, 'tws_name');
   tws_check_arg($job, 'tws_name');
   tws_log(" -- tws_add_job_exec Params: workstation_folder = $workstation_folder, workstation = $workstation");
   tws_log(" -- tws_add_job_exec Params: job_folder = $job_folder, job = $job");
   if(empty($workstation_folder)) $workstation_folder = '';
   if(empty($job_folder)) $job_folder = '';
   $workstation = $workstation_folder.$workstation;
   $job = $job_folder.$job;

   if (!isset($newjob) || $newjob != 'yes')
      tws_check_synchro_token();  // synchro_token

// Check for existing job
   $match=FALSE;
   if ($confirm != "yes") {
      if (($db_job=tws_get_jobs($workstation, $job)) === FALSE) {
         tws_dyer("Unable to list jobs");
      }
      if ($db_job['job_num'] > 1) {
         tws_dyer("Database query failed: job_num > 1: $workstation, $job");
      }
      if (($db_job['job_num'] == 1) && ($db_job['job_name'][0] == $job_name) && ($db_job['job_workstation'][0] == $workstation)){
         $match=TRUE;
      }
   }

   // Confirmation Require
   // (Update or new job with existing name)  // TODO smth. with existing name ???
   if ($match == TRUE) {
      if ($modify == "yes") {
         echo "<h1>Confirmation</h1>\n";
      } else {
         echo "<h1>Replace Job Confirmation</h1>\n";
      }
      echo "<br><br>\n";
      echo "<h3>Confirm:</h3>\n";
      if ($modify != "yes") {
         echo "&nbsp;&nbsp;<b>The Job Name entered already exists</b>\n";
         echo "<br><br>\n";
      }

//    prepare original job to compare
      $orig_job=tws_get_job_def_data($workstation, $job);
      if ($orig_job['task_type']=='SAP') {
         $ex_job = tws_get_job_sap_data($orig_job['script']);
         $orig_job = array_merge($orig_job, $ex_job);
         unset($orig_job['job_type']);
         unset($orig_job['script']);
         $orig_job['r3_logon'] = $orig_job['logon'];
         unset($orig_job['logon']);
      }
      elseif ($orig_job['task_type']!='WINDOWS' && $orig_job['task_type']!='UNIX' && $orig_job['task_type']!='OTHER') {
         $ex_job = tws_get_job_jsdl_data($orig_job['script']);
         $orig_job = array_merge($orig_job, $ex_job);
         unset($orig_job['job_type']);
         unset($orig_job['script']);
         unset($orig_job['logon']);
      }
      if($orig_job['task_type']!='WINDOWS') {
         unset($orig_job['interactive']);
      }
      if($orig_job['task_type']=='zShadowJob') {
         if($orig_job['exitcodemap'] == 'COMPLETE_IF_BIND_FAILS')
            $orig_job['zshadow_complete'] = 'YES';
         unset($orig_job['exitcodemap']);
      }
      elseif($orig_job['task_type']=='distributedShadowJob'){
         if($orig_job['exitcodemap'] == 'COMPLETE_IF_BIND_FAILS')
            $orig_job['dshadow_complete'] = 'YES';
         unset($orig_job['exitcodemap']);
      }

//    prepare new job to compare
      foreach($myPost as $key=>$val) {
         $val = str_replace("\r\n", "\n", $val);
         if($key == 'job')
            $new_job['name'] = $val;
         else
            $new_job[$key] = $val;
         //echo "$key: '$new_job[$key]'<br>";
      }
      if($task_type=='WINDOWS' && (!isset($new_job['interactive']) || trim($new_job['interactive'])=='') ) $new_job['interactive'] = 'NO';

//    prepare label_map
      foreach($orig_job as $key=>$val) {
         $label_map[$key] = '';
      }
      $label_map = tws_get_job_label_map($label_map);
      // labels for new job
      $new_label_map = array();
      foreach($new_job as $key=>$val) {
         $new_label_map[$key] = '';
      }
      $new_label_map = tws_get_job_label_map($new_label_map);
      $new_fields = array_diff_key($new_label_map, $label_map);
      foreach($new_fields as $key=>$val) {
         $orig_job[$key] = null;
         $label_map[$key] = $val;
      }

//    Compare Table
      tws_show_cmp_table("Original Job", "New Job", $orig_job, $new_job, $label_map);

      echo "<form method=post name=\"confirm\" action=\"tws_add_job_action.php\" onsubmit=\"if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Job',null)) { cancel_button_pressed=false; return false;}\">\n";
      echo "<input type=\"hidden\" name=\"confirm\" value=\"yes\">\n";
      if ($original_data=='') {
//missing original data - this happens if user is adding job that already exists.
         if (($original_data=tws_composer_create_from("jd=$workstation#$job"))===FALSE) {
            tws_err("Unable to get original data required to create backup.");
         }
      }
//    prepare hidden inputs
      //echo "<input type=\"hidden\" name=\"original_data\" value=\"".htmlspecialchars($original_data)."\">\n";
      echo tws_create_hidden_inputs($myPost, '', null);

      if (tws_zli_module_check ()) {
          echo "<input type=\"hidden\" name=\"netmodule_file\" value=\"".htmlspecialchars($netmodule_file)."\">\n";
          echo "<input type=\"hidden\" name=\"netmodule_addjob\" value=\"".htmlspecialchars($netmodule_addjob)."\">\n";
      }
      if (tws_rights(SAVEBACKUPS) && $original_data!=''){
         echo "<input type='hidden' name='backup' value='yes'>";
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type='checkbox' name='backup' value='yes' checked disabled>&nbsp;Save Backup Copy of Original Job</label>\n";
      }
      else
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type=\"checkbox\" name=\"backup\" value=\"yes\" ".($original_data!='' ? 'checked' : 'disabled').">&nbsp;Save Backup Copy of Original Job</label>\n";
      echo "<br><br><br>\n";
      if ($modify == "yes") {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Update\" name=\"action\">\n";
         echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
         echo "<input type=\"hidden\" name=\"workstationx\" value=\"".htmlspecialchars($workstation)."\">\n";
         echo "<input type=\"hidden\" name=\"jobx\" value=\"".htmlspecialchars($job)."\">\n";

      } else {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Replace\" name=\"action\">\n";
      }
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Return to Job Modification\" name=\"action\">\n";
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Cancel\" name=\"action\" onClick=\"cancel_button_pressed=true;\">\n";
      tws_print_synchro_token();   // synchro_token
      echo "</form>\n";

   }
   else {
// Create Backup Copy if option checked
      if ($backup == "yes") {
         if (($bckfilename = tws_write_backup($original_data, "job", "$workstation#$job")) === FALSE) {
            tws_dyer("Unable to write backup");
         }
      }
// Prepare command for composer

      $cmd = tws_job_to_composer($myPost, true);
	  
/*
      if($task_type=='WINDOWS' || $task_type=='UNIX' || $task_type=='OTHER') {
         if ($job_type == "command") {
            $job_type_string="DOCOMMAND";
         } else {
            $job_type_string="SCRIPTNAME";
         }
         $interactive = tws_yesno($interactive);
         $description=str_replace('\"', '"', $description);
         $script=str_replace('\"', '"', $script);
         $script = addcslashes($script, '"');
      }
      elseif ($task_type=='SAP') {
         $job_type_string="SCRIPTNAME";
         $logon = $r3_logon;
         $script = tws_sap_geather_string($myPost);
      }
      else {
         $job_type_string="TASK";
         $script = tws_jsdl_geather_string($myPost);

         if($dshadow_complete == "YES" || $zshadow_complete == "YES")
            $exitcodemap = 'COMPLETE_IF_BIND_FAILS';
      }

      $description = addcslashes($description, '"');
      if(isset($logon)) $logon = addcslashes($logon, '"');
      if(isset($recovery_prompt)) $recovery_prompt = addcslashes($recovery_prompt, '"');
      if(isset($exitcodemap)) $exitcodemap = addcslashes($exitcodemap, '"');
*/
// unlock the object
      tws_composer_unlock("jd=$workstation#$job");

      $tmpfilename="$maestro_dir/webadmin/tmp/job.".tws_rndstr().".tmp";
      $fp=fopen($tmpfilename,'w') or tws_dyer("Unable to create temporary file");
	  
/*
      $cmd=Array();
      $cmd[]="\$JOBS\n";
      $cmd[]="$workstation#$job\n";
      tws_check_arg($job_type_string, 'tws_name');
      if ($job_type_string == 'TASK')
         $cmd[]="  $job_type_string $script\n";
      else {
         $cmd[]="  $job_type_string \"$script\"\n";
      }
      if(isset($logon) && $logon!='')
         $cmd[]="  STREAMLOGON \"$logon\"\n";
      $cmd[]="  DESCRIPTION \"$description\"\n";
      if (isset($task_type) && $job_type_string != 'TASK' && tws_check_arg($task_type, 'tws_name'))
         $cmd[]="  TASKTYPE $task_type\n";
      if (isset($interactive) && strtoupper($interactive) == "YES")
         $cmd[]="  INTERACTIVE\n";

   if($tws_config['cpuinfo']['version']>='9.4'){
      foreach($joc_mapping_expression as $j=>$expression){
         if(empty($expression) || empty($joc_name[$j]))
            continue;
         if($joc_succ_condition[$j] == 'Y')
            $cmd[] = 'SUCCOUTPUTCOND '.$joc_name[$j].'"'.$expression.'"'."\n";
         else $cmd[] = 'OUTPUTCOND '.$joc_name[$j].'"'.$expression.'"'."\n";
      }
   }
   elseif (isset($exitcodemap) && $exitcodemap != "")
      $cmd[] = "  RCCONDSUCC \"$exitcodemap\"\n";

      if (isset($affinity) && $affinity != "" && tws_check_arg($affinity, 'tws_name'))
         $cmd[]="  TWSAFFINITY \"$affinity\"\n";
      tws_check_arg($recovery_option, 'tws_name');
      $cmd[]="  RECOVERY $recovery_option\n";
      if ($recovery_workstation != "" && $recovery_job != "" && tws_check_arg($recovery_workstation, 'tws_name') && tws_check_arg($recovery_job, 'tws_name'))
         $cmd[]="    AFTER $recovery_workstation#$recovery_job\n";
      if ($recovery_prompt != "")
         $cmd[]="    ABENDPROMPT \"$recovery_prompt\"\n";
      $cmd[]="";
      $cmd[]="";

      foreach ($cmd as $cmdline) {
         $num_bytes=fwrite($fp,$cmdline);
         if ($num_bytes < 0) {
            fclose($fp);
            tws_dyer("Unable to write temporary file");
         }
      }
*/
      $num_bytes=fwrite($fp,$cmd);
         if ($num_bytes < 0) {
            fclose($fp);
            tws_dyer("Unable to write temporary file");
         }

      fclose($fp);
      tws_chmod($tmpfilename,0644);

      if ($confirm == "yes") {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "replace $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      } else {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "add $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      }

      $stdout3='';
      $ec_popen=tws_popen($command3, $ec3, $stdout3, $stdout3, "N");

      //testing for the AWSBIA288I Total objects updated: 0.
      //Note: This has been added on 2016-07 to fix the problem of composer updating
      //correctly objects but returning incorrect return codes (not 0 or 4)
      $not_updated=!preg_match('/AWSBIA288[^\n]+(\d+)/', $stdout3, $_r) || $_r[1]==0;

      if ($ec_popen===FALSE || ($ec3!=0 && $ec3!=4 && $not_updated)) {
         if ($modify == "yes") {
            echo "<h1>Modify Job Status</h1>\n";
         } else {
            echo "<h1>Add Job Status</h1>\n";
         }
         tws_err("Job add/modify operation failed: $cmd", array('twscmd'=>$command3->compile('log'), 'stdout'=>$stdout3, "EC_POPEN"=>$ec_popen, "EC_UPDATED"=>$ec3, "NOT_UPDATED"=>tws_yesno($not_updated,'YES','NO')));

         if (tws_zli_module_check () && ($netmodule_file != "" || $netmodule_addjob != ""))
             ;
         else {
            echo "<form action=\"tws_add_job_action.php\" method=\"post\" onsubmit=\"if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Job',null)) { cancel_button_pressed=false; return false;}\">\n";
            echo tws_create_hidden_inputs($myPost, '', null);
            tws_print_synchro_token();
            echo "<input type=\"submit\" name=\"action\" value=\"Cancel\" onClick=\"cancel_button_pressed=true;\"/>\n";
            echo "<input type=\"submit\" name=\"action\" value=\"Return to Job Modification\"/>\n";
            echo "</form>";
         }
      }
      else {
         //remove the tmp file now
         unlink($tmpfilename);

          if (preg_match("/warnings?\s[1-9]/i",$stdout3)) {
              if ($modify == "yes") {
                  $headertext="Modify Job";
              } else {
                  $headertext="Add Job";
              }
              tws_err("The job has been saved with the following warnings:", array('stdout'=>$stdout3));

              $shortwarnfilename="warn.".tws_rndstr().".txt";
              $warnfilename="$webadmin_tmp_dir/$shortwarnfilename";
              $warnfp=fopen("$warnfilename","w") or tws_dyer("Unable to create warning text file", "Warning output :\n$stdout3");
              $num_bytes=fwrite($warnfp,$stdout3);
              if ($num_bytes < 0) {
                  fclose($warnfp);
                  unlink($warnfilename);
                  tws_dyer("Unable to write warning text file", "Warning output :\n$stdout3");
              }
              fclose($warnfp);
              tws_dyer();
          }
          if (tws_zli_module_check () && ($netmodule_file != "" || $netmodule_addjob != "")) {
              if ($netmodule_file != "") {
                  require_once ("zli_lib.php");
                  zli_netmod_file_editjob($workstation, $job, $netmodule_file);
              }
              $message = urlencode ("The job has been saved successfuly.");
              echo "<script type='text/javascript'>\n";
              echo "window.location.replace(\"zli_close_window.php?message=$message\");\n";
              echo "</script>\n";
          }
          else {
              if ($newjob == "yes") {
                  echo "<script type='text/javascript'>\n";
                  echo "temptext='".htmlspecialchars($workstation)."#".htmlspecialchars($job)."';\n";
                  echo "tempvalue='".htmlspecialchars($workstation)."#".htmlspecialchars($job)."';\n";
                  echo "rc=window.opener.addJob(temptext,tempvalue);\n";
                  echo "window.close();\n";
                  echo "</script>\n";
              } else {
                  if ($backup == "yes") {
                      if ($modify == "yes") {
                          echo "<h1>Modify Job Status</h1>\n";
                      } else {
                          echo "<h1>Add Job Status</h1>\n";
                      }
                      echo "<p class=\"message\">\n";
                      echo "The job has been successfuly saved.&nbsp;";
                      $bckfilename = preg_replace("/\\\\/", '/', $bckfilename);
                      $file = explode('/',$bckfilename);
                      $file = end($file);
                      if(tws_profile('auth_user_group')=='admin')
                        echo "<a href=\"javascript:showBackup('$file')\">Display Backup File</a>\n";
                      echo "</p>\n";
                        echo "<input type=\"button\" value=\"OK\" onClick=\"closeme('tws_jobsx.php')\" />\n";
                  } else {
                      echo "<script type='text/javascript'>\n";
                        echo "closeme(\"tws_jobsx.php\");\n";
                      echo "</script>\n";
                  }
              }
          }
      }
   }
?>
</body>
</html>
<?php

/// Return label map for compare table.
/// \param $label_map with needed keys (function fill this array with values)
// !!! If $label_map contains keys which not define here - it will be deleted !!!
function tws_get_job_label_map($label_map) {
   if(empty($label_map)) $label_map = array();
      
   foreach($label_map as $key=>$val){
      switch($key) {
         case 'workstation': $label_map[$key] = 'Workstation'; break;
         case 'name': $label_map[$key] = 'Job Name'; break;
         case 'description': $label_map[$key] = 'Description'; break;
         case 'script': $label_map[$key] = 'Script / Command'; break;
         case 'exitcodemap': $label_map[$key] = 'Exit Code Mapping'; break;
         case 'interactive': $label_map[$key] = 'Interactive'; break;
         case 'recovery_option': $label_map[$key] = 'Recovery Action'; break;
         case 'recovery_job_workstation': $label_map[$key] = 'Recovery Job Workstation'; break;
         case 'recovery_workstation': $label_map[$key] = 'Recovery Job Workstation'; break;
         case 'recovery_job': $label_map[$key] = 'Recovery Job'; break;
         case 'recovery_prompt': $label_map[$key] = 'Recovery Prompt'; break;
         case 'logon': $label_map[$key] = 'Logon'; break;
         case 'job_type': $label_map[$key] = 'Job Type'; break;
         case 'task_type': $label_map[$key] = 'Task type'; break;
         case 'rem_user': $label_map[$key] = 'Remote User'; break;
         case 'loc_user': $label_map[$key] = 'Local User'; break;
         case 'rem_password': $label_map[$key] = 'Remote Password'; break;
         case 'loc_password': $label_map[$key] = 'Local Password'; break;
         case 'stdin': $label_map[$key] = 'Standard Input'; break;
         case 'stdout': $label_map[$key] = 'Standard Output'; break;
         case 'stderr': $label_map[$key] = 'Standard Error'; break;
         case 'ft_type': $label_map[$key] = 'File Transfer Type'; break;
         case 'ft_protocol': $label_map[$key] = 'Protocol'; break;
         case 'ft_server': $label_map[$key] = 'Server'; break;
         case 'ft_remfile': $label_map[$key] = 'Remote file'; break;
         case 'ft_locfile': $label_map[$key] = 'Local file'; break;
         case 'ft_mode': $label_map[$key] = 'Transfer mode'; break;
         case 'rem_codepage': $label_map[$key] = 'Remote codepage'; break;
         case 'loc_codepage': $label_map[$key] = 'Local codepage'; break;
         case 'affinity': $label_map[$key] = 'Affinity Job Name'; break;
         case 'ex_directory': $label_map[$key] = 'Working Directory'; break;
         case 'ex_script': $label_map[$key] = 'Script / Command'; break;
         case 'ex_interactive': $label_map[$key] = 'Interactive'; break;
         case 'ws_url': $label_map[$key] = 'Web Service URL'; break;
         case 'ws_operation': $label_map[$key] = 'Web Service Command'; break;
         case 'r3_logon': $label_map[$key] = 'Logon'; break;
         case 'r3job_type': $label_map[$key] = 'Job Type'; break;
         case 'r3job_name': $label_map[$key] = 'Job Name'; break;
         case 'r3job_id': $label_map[$key] = 'Job ID'; break;
         case 'r3job_user': $label_map[$key] = 'User Name'; break;
         case 'r3job_trace': $label_map[$key] = 'Trace'; break;
         case 'r3job_debug': $label_map[$key] = 'Debug'; break;
         case 'r3job_diswa': $label_map[$key] = 'Disable BDC Wait'; break;
         case 'r3job_immed': $label_map[$key] = 'Launch Immediately'; break;
         case 'r3job_cmd': $label_map[$key] = 'R/3 Command Line'; break;
         case 'r3job_spool': $label_map[$key] = 'Job Spoollist'; break;
         case 'r3job_log': $label_map[$key] = 'Job Log'; break;
         case 'r3job_class': $label_map[$key] = 'Job Class'; break;
         case 'r3job_chlog': $label_map[$key] = 'PChain Log'; break;
         case 'dshadow_workstation': $label_map[$key] = 'Remote Workstation'; break;
         case 'dshadow_jobstream': $label_map[$key] = 'Remote Jobstream'; break;
         case 'dshadow_job': $label_map[$key] = 'Remote Job'; break;
         case 'dshadow_complete': $label_map[$key] = 'Complete if bind fails'; break;
         case 'zshadow_jobstream': $label_map[$key] = 'Remote Jobstream'; break;
         case 'zshadow_job': $label_map[$key] = 'Remote Job Number'; break;
         case 'zshadow_complete': $label_map[$key] = 'Complete if bind fails'; break;
         case 'db_query': $label_map[$key] = 'SQL Query'; break;
         case 'db_dbms': $label_map[$key] = 'DBMS'; break;
         case 'db_server': $label_map[$key] = 'Server'; break;
         case 'db_port': $label_map[$key] = 'Port'; break;
         case 'db_name': $label_map[$key] = 'Database name'; break;
         case 'db_jdbc_driver': $label_map[$key] = 'JDBC driver class'; break;
         case 'db_jdbc_string': $label_map[$key] = 'JDBC connection string'; break;
         case 'db_jar_path': $label_map[$key] = 'JDBC jar class path'; break;
         case 'j2ee_operation': $label_map[$key] = 'JMS Operation'; break;
         case 'j2ee_message': $label_map[$key] = 'Message'; break;
         case 'j2ee_timeout': $label_map[$key] = 'Timeout'; break;
         case 'j2ee_factory': $label_map[$key] = 'Connection Factory'; break;
         case 'j2ee_destination': $label_map[$key] = 'Destination'; break;
         case 'j2ee_url': $label_map[$key] = 'Connection URL'; break;
         case 'java_path': $label_map[$key] = 'Jar Path'; break;
         case 'java_class': $label_map[$key] = 'Class Name'; break;
         case 'ibm_command': $label_map[$key] = 'IBM i Command'; break;
         case 'xa_method': $label_map[$key] = 'Access Method'; break;
         case 'xa_target': $label_map[$key] = 'Option file'; break;
         case 'xa_string': $label_map[$key] = 'Task String'; break;
         case 'xa_step': $label_map[$key] = 'Step'; break;
         case 'jcl_created': $label_map[$key] = 'JCL Created'; break;
         case 'jcl_dataset': $label_map[$key] = 'JCL Dataset'; break;
         case 'jcl_member': $label_map[$key] = 'JCL Member'; break;
         case 'jcl_definition': $label_map[$key] = 'JCL Definition'; break;
         case 'matching': $label_map[$key] = 'Matching'; break;
         case 'relative_from': $label_map[$key] = 'From'; break;
         case 'relative_fromhour': $label_map[$key] = '   hour'; break;
         case 'relative_frommin': $label_map[$key] = '   minute'; break;
         case 'relative_to': $label_map[$key] = 'To'; break;
         case 'relative_tohour': $label_map[$key] = '   hour'; break;
         case 'relative_tomin': $label_map[$key] = '   minute'; break;
         case 'absolute_fromhour': $label_map[$key] = 'From: hour'; break;
         case 'absolute_frommin': $label_map[$key] = '   minute'; break;
         case 'absolute_from': $label_map[$key] = '   +/-'; break;
         case 'absolute_fromdays': $label_map[$key] = '   days'; break;
         case 'absolute_tohour': $label_map[$key] = 'To: hour'; break;
         case 'absolute_tomin': $label_map[$key] = '   minute'; break;
         case 'absolute_to': $label_map[$key] = '   +/-'; break;
         case 'absolute_todays': $label_map[$key] = '   days'; break;
         case 'user': $label_map[$key] = 'User'; break;
         case 'password': $label_map[$key] = 'Password'; break;
         case 'arguments': $label_map[$key] = 'Arguments'; break;
         case 'variables': $label_map[$key] = 'Variables'; break;
         default : $label_map[$key]=FALSE; //avoid showing additional keys in the comparison table !!!
      }
   }
   return $label_map;
}

?>
