<?php
//   HORIZONT Software GmbH, Munich
//
    $__tlogmode='APPEND';
   require_once 'tws_functions.php';

   if (defined('IWD_PROCMAN')) {
      $iwd_class='iwd_dbjd';
      $search_elems=array();
      $search=$iwd_class::get_search_elems($search_elems, 'default'); //'default'=we want the initial filter is equal as the 'defau;t filtrer for dbjd object type
   }

   tws_import_request_variables("P","rqst_");

   $allowmultiple=$rqst_allowmultiple;
   $addjobcpufilter=tws_gpc_get(@$rqst_addjobcpufilter, 'tws_mask');
   $addjobfilter=tws_gpc_get(@$rqst_addjobfilter, 'tws_mask');
   $action=@$rqst_action;
   $display="yes";

   if (trim($addjobcpufilter)=='')
      $workstation=defined('IWD_PROCMAN') ? $search_elems['iwd_dbws'][0] : "@";
   else $workstation=$addjobcpufilter;

   if (trim($addjobfilter)=='')
      $job=defined('IWD_PROCMAN') ? $search_elems['iwd_dbjd'][0] : "@";
   else $job=$addjobfilter;
?>

<script type="text/javascript">

function sendValue(formsel) {
   if (formsel) {
      for (var i = 0; i < formsel.options.length; i++) {
         if (formsel.options[i].selected) {
            temptext=formsel.options[i].text;

            //IWD/ProcMan is adding some additional notes to the round bracquets
            //which makes problem to the javaqscript behind the "Job Properties" dialog
            //see ERR16310 for more details
            //example: CPU#JOBNAME (INTERIM-0.0.1) => CPU#JOBNAME
            temptext=temptext.replace(/\s+\(.*\)/,'');

            tempvalue=formsel.options[i].value;
            rc=window.addJob(temptext,tempvalue);
            if (rc == false) {
               window.focus();
               return;
            }
         }
      }
   }
   $( "#addjob_picker" ).dialog( "close" );
}

function setValue() {
    var param = 'allowmultiple=yes&action=set&addjobcpufilter='+ document.filter_list.addjobcpufilter.value +'&addjobfilter='+ document.filter_list.addjobfilter.value;
   $('#addjob_picker').dialog('close');
   tws_picker_open('addjob_picker.php', param);
}

function onEnterKey(e) {   // Submit form on Enter Key
   if(e.keyCode == 13)  //
      setValue();
}
</script>

<style type="text/css">
input, select, textarea, button {
   font-family: Verdana,Arial,sans-serif;
   font-size:13px;
}

</style>

<div id="addjob_picker">

<h1>Select Job</h1>
<br>

<form name="filter_list">
<table border=0 cellspacing=0 align=center name="seltable">
<tr><td class=standard colspan=2><b>Filter:</b></td></tr>
<tr>
   <td class=standard>&nbsp;&nbsp;Workstation:&nbsp;</td>
   <td class=standard>
      <input type="text" name="addjobcpufilter" class='tws_mask' size="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" maxlength="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" value="<?=htmlspecialchars($workstation)?>" onkeypress = "onEnterKey(event)">
   </td>
</tr>
<tr>
   <td class=standard>&nbsp;&nbsp;Job:&nbsp;</td>
   <td class=standard>
      <input type="text" name="addjobfilter" class='tws_mask' size="<?=$tws_config['JOB_MAXLENGTH']?>" maxlength="<?=$tws_config['JOB_MAXLENGTH']?>" value="<?=htmlspecialchars($job)?>" onkeypress = "onEnterKey(event)">
   </td>
</tr>
<tr>
   <td class=standard colspan=2 align=center>&nbsp;&nbsp;
      <input type="button" name="action" value=" Set " onClick="setValue();"/>
   </td>
</tr>
</table>
<?php
   if ($allowmultiple == "yes") {
      echo "<input type=\"hidden\" name=\"allowmultiple\" value=\"yes\">\n";
   }
?>
</form>
<br>

<?php
   if ((isset($action) && strtolower(trim($action))=='set')) {
      echo '<form name="job_list">',"\n";
      $result=TRUE;
      if (defined('IWD_PROCMAN')) { //IWD/ProcMan
         $arg=strtr($job,"@","*");
         $cpux=strtr($workstation,"@","*");
         if (($objs=$iwd_class::get_listing($cpux.'#'.$arg, 'ref'))!==FALSE) {
            $jobs['job_num']=count($objs);
         } else {
            $result=FALSE;
            hwi_log_flush();
         }
      }
      else { //IWS/WebAdmin
         if (($jobs=tws_get_jobs($workstation,$job))===FALSE) $result=FALSE;
      }

      if ($result===FALSE) {
         echo "<center><p class=warning>Unable to list jobs.</p>\n";
         echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\"></center>\n";
      }

      if (isset($jobs) && $jobs['job_num'] == 0) {
         echo "<center><p class=warning>No job entries matching the filtering criteria has been found.</p>\n";
         echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\"></center>\n";
      } else {
         echo "<select name=\"selection\" size=14 onDblClick=\"sendValue(this.form.selection);\"";
         if ($allowmultiple == "yes") {
            echo " multiple";
         }
         echo ">\n";

         if (defined('IWD_PROCMAN')) {
            foreach($objs as $obj) {
               echo '<option value="'.$obj['name'].'">'.$obj['name'].' ('.$obj['version'].')</option>'."\n";
            }
         }
         else {
            for ($i=0; $i<$jobs['job_num']; $i++) {
               $job_folder = '';
               if(!empty($jobs['job_folder'][$i]))
                  $job_folder = $jobs['job_folder'][$i];

               $job_workstation_folder = '';
               if(!empty($jobs['job_workstation_folder'][$i]))
                  $job_workstation_folder = $jobs['job_workstation_folder'][$i];

               echo "<option value=\"".$job_workstation_folder.$jobs['job_workstation'][$i]."#".$job_folder.$jobs['job_name'][$i]."\""; if($jobs['job_num']==1) echo " selected"; echo">".$job_workstation_folder.$jobs['job_workstation'][$i]."#".$job_folder.$jobs['job_name'][$i]."</option>\n";
            }
         }
         echo "</select>\n";
         echo "<br><br>\n";
         echo "<center><input type=\"button\" value=\"OK\" onClick=\"sendValue(this.form.selection);\"></center>\n";
      }
      echo '</form>',"\n";
   } else {
      echo "<p class=\"message\">Confirm the filtering critera first (wildcards or empty values allowed).</p>\n";
   }
?>
</div>

<script type="text/javascript">

$(function() {
   tws_picker_constructor("addjob_picker", "seltable");
});

</script>
