<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Delete IWS/WebAdmin Master</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<h1>Delete IWS/WebAdmin Master</h1>
<br><br>
<h3>Confirm Master Delete:</h3>

<?php

   if (!isset($selection)) {
      echo "<p class=warning>&nbsp;&nbsp;&nbsp;&nbsp;No master selected</p>\n";
      tws_dyer();
   }
      echo "<form method=\"post\" action=\"tws_delete_master_exec.php\">\n";;
      echo "&nbsp;&nbsp;&nbsp;&nbsp;".htmlspecialchars($selection)."\n";
      echo "<input type=\"hidden\" name=\"mastername\" value='".htmlspecialchars($selection)."'>\n";
      echo "<br><br><br>\n";
      if ($num_masters == 1) {
         echo "<input type=\"hidden\" name=\"num_masters\" value=\"$num_masters\">\n";
         echo "<p class=warning>&nbsp;&nbsp;You are deleting the last remaining IWS/WebAdmin Master. <b>This will DISABLE Multiple Master mode!</b></p>\n<br>\n";
      } elseif ($selection == $localmaster) {
         echo "<p class=warning>&nbsp;&nbsp;<b><font color=\"#800000\">Warning:</font></b> You are deleting the Local Primary IWS/WebAdmin Master</p>\n<br>\n";
      }
?>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Delete" name="action">
<input type="button" value="Cancel" onclick="window.location.replace('tws_masters_configuration.php');">
<? tws_print_synchro_token();     // synchro_token
?>
</form>

</body>
</html>
