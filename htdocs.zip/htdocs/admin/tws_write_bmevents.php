<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Save Event Configuration</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>
<h1>Save Event Configuration</h1>
<br><br>
<?php
   tws_import_request_variables("P","rqst_");

   $event=tws_gpc_get($rqst_event, 'tws_num');
   $sel_severity=tws_gpc_get($rqst_sel_severity, 'tws_num');
      tws_check_synchro_token();  //    synchro_token

   $num_events=count($event);

// Begin modify BmEvents.conf file
    if ($tws_config['cpuinfo']['version'] >= '9.5')
        $dir = $tws_config["twsenv"]["UNISONWORK"];
    else
        $dir = $tws_config['maestro_dir'];
   $filename="$dir/BmEvents.conf";
   $bakfilename="$dir/BmEvents.conf.bak";
   $newfilename="$webadmin_tmp_dir/BmEvents.conf";

   if (!file_exists("$filename")) {
      if ($num_events == 0) {
         tws_dyer("The BmEvents.conf file does not exist and no events were selected.  No changes have been made.");
      }
      $distfilename="$maestro_dir/webadmin/build/BmEvents.conf.dist";
      if (!file_exists("$distfilename")) {
         tws_dyer("Unable to read file $distfilename");
      }
      $distfp=fopen("$distfilename","r") or tws_dyer("Unable to read file $distfilename");
      $newfp=fopen("$newfilename","w") or tws_dyer("Unable to write file $newfilename");
      while (!feof($distfp)) {
         $buffer=fgets($distfp,4096);
         $buffer=str_replace("<MAESTRO_HOME>","$maestro_dir",$buffer);
         fwrite($newfp,$buffer);
      }
      fclose($distfp);
      fclose($newfp);
      // copy new file from tmp dir into maestro_dir
         $cpcmd = isset($tws_config['cp']) ? $tws_config['cp'] : ($tws_config['host_os'] !== 'win32' ? '/bin/cp' : 'copy');
         $stdout='';
         if($tws_config['host_os']=='win32'){
            $newfilename = str_replace('/','\\',$newfilename);
            $filename = str_replace('/','\\',$filename);
         }
         $cmd=new hwi_cmd(tws_sudo('',$tws_config['maestro_user']), $cpcmd, $newfilename, $filename);
         tws_popen($cmd, $ec, $stdout, $stdout);
         if ($ec!='0')
            tws_dyer("Cannot install new configuration file '$target_file'.", array('stdout'=>$stdout));
   }

   if ($host_os == "win32") {
      if (file_exists($bakfilename)) {
         unlink($bakfilename);
      }
      if (!copy($filename,$bakfilename)) {
         tws_dyer("Unable to copy $filename to $bakfilename");
      }
      /*   can't delete BmEvents.conf, but can rewrite it
      if (!unlink($filename)) {
         tws_err("Unable to move $filename to $bakfilename");
         tws_warning("Hint: You must STOP an IBM WebSphere Application Server Service before saving the event configuration");
         tws_dyer();
      }*/
   } else {
      if (!rename($filename,$bakfilename)) {
         tws_dyer("Error: Unable to move $filename to $bakfilename");
      }
   }

   if ($num_events == 0) {
      echo "IWS events are disabled.  The BmEvents.conf configuration file has been renamed to BmEvents.conf.bak.  Changes will not take effect until JnextPlan runs or IWS is stopped and restarted\n<br>\n";
   } else {
      $event_list=implode(" ",$event);
      $event_line="EVENTS = $event_list\n";

      $srcfp=fopen($bakfilename,"r") or tws_dyer("Unable to read file $bakfilename");
      $dstfp=fopen($filename,"w") or tws_dyer("Unable to write file $bakfilename");
      $done=0;

      while (!feof($srcfp)) {
         $buffer=fgets($srcfp,4096);
         $tok=strtok($buffer,"=");
         if (trim($tok) == "EVENTS") {
            fwrite($dstfp,$event_line);
            $done=1;
         } else {
            fwrite($dstfp,$buffer);
         }
      }

      if ($done == 0) {
         fwrite($dstfp,$event_line);
      }

      fclose($srcfp);
      fclose($dstfp);

      echo "Event configuration saved.  Changes will not take effect until JnextPlan runs or IWS is stopped and restarted\n<br>\n";

      // get types and DEFAULT SEVERITIES
      include($event_types_file);
      $content="<?\n";
      foreach ($sel_severity as $event_num => $severity_num) {
         if ($default_severity[$event_num] != $severity_num) {
            $content .= "\$event_severity[$event_num]=$severity_num;\n";
         }
      }
      $content .= "?>\n";
      $fp = fopen("$custom_severities_file","w");
      if ($fp) {
         $numbytes=fwrite($fp,$content);
      } else {
         fclose($fp);
         echo "<p class=warning> Error: unable to save custom severities<p>";
      }
      if ($numbytes==0) {
         fclose($fp);
         echo "<p class=warning> Error: unable to save custom severities<p>";
      }
      fclose($fp);
   }
?>
<br><br>
<a href="tws_event_configuration.php">Return to Event Configuration</a>
</body>
</html>
