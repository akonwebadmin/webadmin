<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype("t");
?>
<html>
<head>
<title>IWS/WebAdmin Configuration</title>
<?php tws_adminstylesheet();?>
</head>
<body>
<?php

      tws_check_synchro_token();  //    synchro_token

if($_POST['action']=='Save') {
   $err_status = 0;

   // REWRITE DB_CONFIG.PHP

   // check if there are some changes made in db_config
   $save_db_config=0;

   $new_composer_db = tws_gpc_get($_POST['composer_db']);
   foreach($new_composer_db as $key=>$val){
      if($val != $composer_db[$key]) {
         $save_db_config = 1;
         $new_composer_db = array_merge($composer_db, $new_composer_db);
         break;
      }
   }
   $new_webadmin_db = tws_gpc_get($_POST['webadmin_db']);
   foreach($new_webadmin_db as $key=>$val){
      if($val != $webadmin_db[$key]) {
         $save_db_config = 1;
         $new_webadmin_db = array_merge($webadmin_db, $new_webadmin_db);
         break;
      }
   }

   // rewrite db_config
   if($save_db_config) {
      $dbconfig = $tws_config['maestro_dir']."/webadmin/etc/db_config.php";
      $bak_dbconfig = $tws_config['maestro_dir']."/webadmin/backup/db_config.php".'-'.date('Ymd_His'). ".bak";
      $new_dbconfig = $dbconfig . ".tmp";

      $buffer = "<?php\n\n";
      $str = var_export($new_composer_db, true);
         $buffer .= '$composer_db = '. $str .";\n\n";
      $str = var_export($new_webadmin_db, true);
         $buffer .= '$webadmin_db = '. $str .";\n";
      $coment = tws_gpc_get($_POST['comment']);
      $coment = preg_replace('/\r/', '', $coment);
      $buffer .= "\n/*\n". $coment ."\n*/\n?>";
      if($tws_config['host_os']=='win32'){
         $buffer .= "\n";     // otherwise while encoding the last string is removed in win32
         $buffer = preg_replace('/\\n/', PHP_EOL, $buffer);
      }

      $fp=fopen($new_dbconfig, "w") or tws_dyer("can't open $new_dbconfig");
         fwrite($fp, $buffer) or tws_dyer("can't write to $new_dbconfig");
      fclose($fp);

      copy($dbconfig, $bak_dbconfig) or tws_dyer("can't copy $dbconfig to $bak_dbconfig");
      copy($new_dbconfig, $dbconfig) or tws_dyer("can't copy $new_dbconfig to $dbconfig");
      unlink($new_dbconfig);
   }

// REWRITE TWS_CONFIG.PHP

//****** CHECK GLOBALS ******//

//if(!isset($base_inst_dir) || preg_match('/<[A-Z_]+>/', $base_inst_dir)!= 0)
//   $base_inst_dir = "$maestro_dir/webadmin";
$maestro_dir = $tws_config['maestro_dir'];
$base_inst_dir = $tws_config['base_inst_dir'];
$hwf_root = $tws_config['hwf_root'];

if(empty($hwf_root) || preg_match('/<[A-Z_]+>/', $hwf_root)!= 0)
   $hwf_root = $base_inst_dir;

$tws_superglobals = array(
   'base_inst_dir' => $base_inst_dir,
   'maestro_dir' => $maestro_dir,
   'hwf_root' => $hwf_root,
);

// can't be empty, directory must exist
foreach($tws_superglobals as $key=>$val){
   if(empty($val) || preg_match('/<[A-Z_]+>/', $val)!= 0 || !file_exists($val) )
      tws_dyer("'$key' value is not set! It's strongly recommended to set '$key' value in etc/tws_config.php", '', 'admin_home.php');
}

$tws_paths = array(
   'webadmin_backup_dir' => $tws_config['webadmin_backup_dir'],
   'webadmin_tmp_dir' => $tws_config['webadmin_tmp_dir'],
   'webadmin_draft_dir' => $tws_config['webadmin_draft_dir'],
   'user_setting_dir' => $tws_config['user_setting_dir'],

   'webadmin_user_home_dir' => $tws_config['webadmin_user_home_dir'],
   'webadmin_all_user_dir' => $tws_config['webadmin_all_user_dir'],
);
// if emty or dir not exist - set defaults value, generate warning.
$tmp_status=0;
foreach($tws_paths as $key=>$val){
   if(empty($val) || preg_match('/<[A-Z_]+>/', $val)!= 0 || !file_exists($val)){
      switch ($key){
         case 'webadmin_backup_dir':
            $tws_paths[$key] = "$maestro_dir/webadmin/backup/composer";
            $tmp_status = 1;
            break;
         case 'webadmin_tmp_dir':
            $tws_paths[$key] = "$maestro_dir/webadmin/tmp";
            $tmp_status = 1;
            break;
         case 'webadmin_draft_dir':
            $tws_paths[$key] = "$maestro_dir/webadmin/backup/drafts";
            $tmp_status = 1;
            break;
         case 'user_setting_dir':
            if(empty($val) || preg_match('/<[A-Z_]+>/', $val)!= 0) {
               $tws_paths[$key] = "/.settings";
               $err_status = 1;
               tws_warning("'$key' value was not set. New value for '$key' is set to '$tws_paths[$key]'");
            }
            break;
         case 'webadmin_user_home_dir':
            $tws_paths[$key] = "$maestro_dir/webadmin/home";
            $tmp_status = 1;
            break;
         case 'webadmin_all_user_dir':
            $tws_paths[$key] = "$maestro_dir/webadmin/home/all_users";
            $tmp_status = 1;
            break;
      }
   }
   if($tmp_status){
      $err_status = 1;
      tws_warning("Path '$val' is not found or '$key' value is not set. New value for '$key' is set to '$tws_paths[$key]'");
      $tmp_status=0;
   }
}
arsort($tws_paths);


$tws_globals = array(
   'maestro_user' => $tws_config['maestro_user'],
   'host_os' => $tws_config['host_os'],
   'virtual_hosts' => $tws_config['virtual_hosts'],
   'kernel' => $tws_config['kernel'],

   'note_types_file' => $tws_config['note_types_file'],
   'severities_file' => $tws_config['severities_file'],
   'event_types_file' => $tws_config['event_types_file'],
   'custom_severities_file' => $tws_config['custom_severities_file'],
   'custom_events_file' => $tws_config['custom_events_file'],
   'url_webadmin_root' => $url_webadmin_root,
   '_last_error' => $_last_error,
);

// if emty or file not exist - set defaults value, generate warning.
$tmp_status=0;
foreach($tws_globals as $key=>$val){
   if(empty($val) || preg_match('/<[A-Z_]+>/', $val)!= 0 || !file_exists($val)) {
      switch ($key){
         case 'note_types_file':
            $tws_globals[$key] = "$maestro_dir/webadmin/etc/note_types.php";
            $tmp_status=1;
            break;
         case 'severities_file':
            $tws_globals[$key] = "$maestro_dir/webadmin/etc/severities.php";
            $tmp_status=1;
            break;
         case 'event_types_file':
            $tws_globals[$key] = "$maestro_dir/webadmin/etc/event_types.php";
            $tmp_status=1;
            break;
         case 'custom_severities_file':
            $tws_globals[$key] = "$maestro_dir/webadmin/etc/custom_severities.php";
            $tmp_status=1;
            break;
         case 'custom_events_file':
            $tws_globals[$key] = "$maestro_dir/webadmin/etc/custom_events.php";
            $tmp_status=1;
            break;
         case 'url_webadmin_root':
            if(empty($val) || preg_match('/<[A-Z_]+>/', $val)!= 0) {
               $tws_globals[$key] = "/";
               $err_status = 1;
               tws_warning("'$key' value was not set. New value for '$key' is set to '$tws_globals[$key]'");
            }
            break;
         case '_last_error':
            if(empty($val) || preg_match('/<[A-Z_]+>/', $val)!= 0) {
               $tws_globals[$key] = "tws_error";
               $err_status = 1;
               tws_warning("'$key' value was not set. New value for '$key' is set to '$tws_globals[$key]'");
            }
            break;
         default:
            if(!isset($val) || preg_match('/<[A-Z_]+>/', $val)!= 0) {
               $tws_globals[$key] = "";
               $err_status = 1;
               tws_warning("'$key' value is not set! New value is set to empty string. It's strongly recommended to set '$key' value in etc/tws_config.php");
            }
      }
   }
   if($tmp_status){
      $err_status = 1;
      tws_warning("Path '$val' is not found or '$key' value is not set. New value for '$key' is set to '$tws_globals[$key]'");
      $tmp_status=0;
   }
}

   $fname = "$maestro_dir/webadmin/etc/tws_config.php";
   $bak_name = "$maestro_dir/webadmin/backup/tws_config.php".'-'.date('Ymd_His').".bak";
   $new_name = $fname.".tmp";
   //$new_name = "$maestro_dir/webadmin/tmp/tws_config.php.tmp";

   if($tws_config['host_os']=='win32')
      $tmpl_fname = "$base_inst_dir/etc/templates/tws_config-win.php";
   else
      $tmpl_fname = "$base_inst_dir/etc/templates/tws_config-unix.php";

   if(!file_exists($tmpl_fname))
      tws_dyer("template file '$tmpl_fname' not exist", '', 'admin_home.php');

include $tmpl_fname;
include $fname;

//$tws_config = array_merge($tws_config_tmpl, $tws_config);
// instead of merge:
foreach($tws_config_tmpl as $key=>$val){
   if(isset($tws_config[$key]))
      $tws_config_tmpl[$key] = $tws_config[$key];
}

   foreach($_POST['config'] as $key=>$val){
      $val = tws_gpc_get($val);
      $tws_config_tmpl[$key] = $val;
      // check paths
      if( trim($val) !='' && (preg_match('/^.*_file$/',$key)==1 || preg_match('/^.*_dir$/',$key)==1) )
         if(!file_exists($val)){
            $tws_config_tmpl[$key] = '';
            tws_warning("path '$val' is not found for '$key' value. '$key' is not set.");
            $err_status = 1;
         }
   }

//****** CHECK $tws_config ******//

// check if some <PATTERNS> exists (may be if $tws_config have no some field)
foreach($tws_config_tmpl as $key=>$val){
   if(is_string($val) && preg_match('/<([A-Z_]+)>/',$val, $arr)) {
      $new_val = strtolower($arr[1]);
      if($new_val == 'maestro_home')
         $new_val = $maestro_dir;
      else
         $new_val = $$new_val;
      $tws_config_tmpl[$key] = preg_replace('/<[A-Z_]+>/', $new_val, $val);
   }
   elseif(is_array($val)) {
      foreach($val as $akey=>$aval){
         if(is_string($aval) && preg_match('/<([A-Z_]+)>/',$aval, $arr)) {
            $new_val = strtolower($arr[1]);
            if($new_val == 'maestro_home')
               $new_val = $maestro_dir;
            else
               $new_val = $$new_val;
            $tws_config_tmpl[$key][$akey] = preg_replace('/<[A-Z_]+>/', $new_val, $aval);
         }
      }
   }
}

//****** WRITE tws_config.php ******//

   $fp=fopen($new_name, "w") or tws_dyer("can't create $new_name", '', 'tws_set_conf.php#main');
      fwrite($fp, "<?php".PHP_EOL) or tws_dyer("can't write to $new_name", '', 'tws_set_conf.php#main');
// "superglobals"
      foreach ($tws_superglobals as $key=>$val){
         $buffer = '$'.$key.' = '. var_export($val, true) .';'.PHP_EOL;
         fwrite($fp, $buffer);
      }
      fwrite($fp, PHP_EOL);
// paths
      foreach ($tws_paths as $key=>$val){
         foreach ($tws_superglobals as $path=>$find){
            if( strpos($val ,$find ) !== false) {
               $val = str_replace($find, '$'.$path, $val);
               break;
            }
         }
         $buffer = '$'.$key.' = "'. $val .'";'.PHP_EOL;
         fwrite($fp, $buffer);
      }
      fwrite($fp, PHP_EOL);
// other globals
      foreach ($tws_globals as $key=>$val){
         foreach ($tws_paths as $path=>$find){
            if( strpos($val ,$find ) !== false) {
               $val = str_replace($find, '$'.$path, $val);
               break;
            }
         }
         foreach ($tws_superglobals as $superglobal=>$find){
            if( strpos($val ,$find ) !== false) {
               $val = str_replace($find, '$'.$superglobal, $val);
               break;
            }
         }
         $buffer = '$'.$key.' = "'. $val .'";'.PHP_EOL;
         fwrite($fp, $buffer);
      }
      fwrite($fp, PHP_EOL);

// $tws_config array
      fwrite($fp, '$tws_config = Array ('.PHP_EOL);

      foreach ($tws_config_tmpl as $key=>$val) {
         if(is_array($val)) {
            $str = "'$key' => ".var_export($val, true).",\n";
            $str = preg_replace('/\\n/', PHP_EOL, $str);
            fwrite( $fp, $str );
            continue;
         }
         foreach ($tws_paths as $path=>$find){
            if( strpos($val ,$find ) !== false) {
               $val =  str_replace($find, '$'.$path, $val);
               break;
            }
         }
         foreach ($tws_superglobals as $path=>$find){
            if( strpos($val ,$find ) !== false) {
               $val =  str_replace($find, '$'.$path, $val);
               break;
            }
         }
         if($key=='maestro_user' || $key=='host_os' || $key=='virtual_hosts' || $key=='kernel')
            $buffer = "   '$key' => ".'"$'.$key.'",'.PHP_EOL;
         else
            $buffer = "   '$key' => ".'"'. $val .'",'.PHP_EOL;
         fwrite($fp, $buffer);
      }

      fwrite($fp, ");".PHP_EOL."?>");
   fclose($fp);

   copy($fname, $bak_name) or tws_dyer("can't copy $fname to $bak_name", '', 'tws_set_conf.php#main');
   copy($new_name, $fname) or tws_dyer("can't copy $new_name to $fname", '', 'tws_set_conf.php#main');
   unlink($new_name);
}


if($err_status==0) {
   echo "<p class='message'>Configuration files were saved successfully</p>";
   if(!empty($bak_dbconfig))
      tws_warning("db_config backup was  saved as $bak_dbconfig");
   tws_warning("tws_config backup was  saved as $bak_name");
   tws_dyer("", '', 'admin_home.php');
}
else{
   tws_dyer("", '', 'admin_home.php');
}
?>
</body>
</html>