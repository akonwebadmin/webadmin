<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Setting Menu Configuration</title>
<?php tws_adminstylesheet(); ?>

<script type="text/javascript">
function goback() {
window.location.replace("tws_user_administration.php");
}
</script>

</head>
<body>
<?php
   tws_import_request_variables("P","rqst_");

   $menu_item=tws_gpc_get($rqst_menu_item, 'tws_name');
   $selection = tws_gpc_get($rqst_selection, 'tws_alfanum\\tws_alfanum', '\\');
   tws_check_synchro_token();     // synchro_token

   if (!isset($menu_item)) {
      $menu_item[]="_NULL_";
   }
   if ($rqst_action == "Save Changes") {
      tws_print_head("Menu Configuration saved",'','../');
      foreach($selection as $user) {
         if (!tws_save_menu_configuration($menu_item,$user))
            tws_err("Saving configuration failed for user '$user'");
      }
      if(count($selection)==1)
         echo "<p class=warning>Menu Configuration saved for user $user</p>";
      else
         echo "<p class=warning>Menu Configuration saved for selected users</p>";
      echo "<br><br><input type='Button' name='action' value=' Ok ' onClick='goback()'>";
   }
   elseif ($rqst_action == "Remove Custom Profile") {
      foreach($selection as $user) {
         if (is_file($webadmin_user_home_dir."/".$user.$user_setting_dir."/menu.php"))
            unlink($webadmin_user_home_dir."/".$user.$user_setting_dir."/menu.php");
      }
      echo "<script language='Javascript'>\n";
      echo "window.location.replace('tws_user_administration.php');\n";
      echo "</script>\n";
   }
   elseif ($rqst_action  == "Use Default Values" || $rqst_action  == "Use Group Default Values" ) {
      $user = $selection[0];
      echo "<script language='Javascript'>\n";
      echo "window.location.replace('tws_define_user_menu.php?user=".urlencode($user)."&action=".urlencode($rqst_action)."');\n";
      echo "</script>\n";
   }
?>
</body>
</html>