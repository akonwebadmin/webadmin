<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
   <title>SAP jobs access</title>
   <?php tws_adminstylesheet(); ?>
</head>
<body style="padding:10px;">
<? tws_print_head("Set up Access to SAP R/3 on FTA's", '', '../'); ?>
<br>
<br>
<?
$filled=false;
$confirmed=false;

foreach($_POST as $key=>$val)
   $$key = tws_gpc_get($val);

if(isset($_POST['action'])) {
   tws_check_synchro_token();
   if($_POST['action'] == 'Continue'){
      $filled=true;
      $confirmed=true;
   }
   elseif($_POST['action'] == 'Next')
      $filled = true;
}

//             INPUT FORM

if(!$filled):

echo "<p class='message'>Since there is generally no remote access to SAP R/3 access methods (r3batch) available from the IWS domain manager, IWS/WebAdmin uses a special jobs to propagate the r3batch output from the agent.
The jobs are periodically running on the FTA's while providing the data about SAP jobs.</p>";
?>
<h3>Create source job for a SAP agent:</h3>
<br>
<form method="post" action="" name="contents">
  <table border=0 width="90%">
    <tbody>
      <tr>
        <td width='150px'>&nbsp;&nbsp;Sap-Agent:</td>
        <td>
        <input value="<?=htmlspecialchars($agent)?>" name="agent" required="required" class="tws_name">
        <input type="button" name="agent_list" value="List" onClick="tws_picker_open('../workstation_picker.php', 'os=O&type=X&method=r3batch&fieldname=agent&amp;fieldvalue='+document.contents.agent.value);">
        </td>
        <td>Select the SAP extended agent</td>
      </tr>
      <tr>
        <td>&nbsp;&nbsp;Logon:</td>
        <td>
        <input value="<?=htmlspecialchars($logon)?>" name="logon" required="required" class="tws_alfanum"></td>
        <td>Specify a user name who is able to execute the r3batch method on the selected FTA </td>
      </tr>
      <tr>
        <td>&nbsp;&nbsp;IWS directory:</td>
        <td>
        <input value="<?=htmlspecialchars($tws_dir)?>" name="tws_dir" required="required" class="tws_file"></td>
        <td>Specify the path to the IWS directory at the FTA workstation (e.g. /opt/ibm/maestro/IWS)</td>
      </tr>
      <tr>
        <td>&nbsp;&nbsp;Temporary directory:</td>
        <td>
        <input value="<?=htmlspecialchars($tmp_dir)?>" name="tmp_dir" required="required" class="tws_file"></td>
        <td>Specify the path to a temporary directory at the FTA workstation (e.g. /tmp)</td>
      </tr>
    </tbody>
  </table>

<? tws_print_synchro_token(); ?>
<br><br>
<input type="submit" name="action" value="Next" onClick="return tws_validate_form();">
   <? tws_print_synchro_token();     // synchro_token ?>
</form>

<? elseif(!$confirmed):

// get FTA from Agent definition
   $res = tws_get_workstation_data($agent);
   if ($res == false) tws_dyer("Can't get '".htmlspecialchars($agent)."' data");
   $fta = $res['host'];
// get MDM
   $mdm=isset($tws_config['cpuinfo']['host']) ? $tws_config['cpuinfo']['host'] : $tws_config['localopts']['thiscpu'];


      // CONFIRMATION FORM
?>
<h2>Create jobs:</h2>
<?
   if ($tws_config['host_os'] == "win32" )
      $tasktype = 'WINDOWS';
   else
      $tasktype = 'UNIX';

   $cmd=Array();

   $cmd[]='$JOBS'."\n\n";

   //       STD
   $cmd[]="# Get Standard sap jobs list \n\n";
   $cmd[]=$fta.'#WA_'.$agent.'_ST'."\n";
   $cmd[]='SCRIPTNAME "\"'.$tws_dir.'/methods/r3batch\" -t PL -c '.$agent.' -l * -j *"'."\n";
   $cmd[]='STREAMLOGON "'.$logon.'"'."\n";
   $cmd[]='DESCRIPTION "Get Standard sap jobs list"'."\n";
   $cmd[]="TASKTYPE $tasktype\n";
   $cmd[]='RECOVERY STOP'."\n\n";

   //    FILE
   $cmd[]="# Create input file for r3batch in FTA/tmp dir \n\n";
   $cmd[]=$fta.'#WA_'.$agent.'_F'."\n";
   $cmd[]='DOCOMMAND "echo -e \"%mrc 0003000884.00.00\n%logoninfo '.$logon.'\" > \"'.$tmp_dir.'/r3_'.$agent.'.txt\""'."\n";
   $cmd[]='STREAMLOGON "'.$logon.'"'."\n";
   $cmd[]='DESCRIPTION "Create input file for r3batch in FTA/tmp dir"'."\n";
   $cmd[]="TASKTYPE $tasktype\n";
   $cmd[]='RECOVERY STOP'."\n\n";

   //    INFOPACKAGE
   $cmd[]="# Get Infopackage sap jobs list\n\n";
   $cmd[]=$fta.'#WA_'.$agent.'_IP'."\n";
   $cmd[]='SCRIPTNAME "\"'.$tws_dir.'/methods/r3batch\" -t GI -c '.$agent.' -j DMYJOB -l * -- \'-t PL -infopackage\' <\"'.$tmp_dir.'/r3_'.$agent.'.txt\""'."\n";
   $cmd[]='STREAMLOGON "'.$logon.'"'."\n";
   $cmd[]='DESCRIPTION "Get Infopackage sap jobs list"'."\n";
   $cmd[]="TASKTYPE $tasktype\n";
   $cmd[]='RECOVERY STOP'."\n\n";

   //    PCHAIN
   $cmd[]="# Get Process chain sap jobs list"."\n\n";
   $cmd[]=$fta.'#WA_'.$agent.'_PC'."\n";
   $cmd[]='SCRIPTNAME "\"'.$tws_dir.'/methods/r3batch\" -t GI -c '.$agent.' -j DMYJOB -l * -- \'-t PL -pchain\' <\"'.$tmp_dir.'/r3_'.$agent.'.txt\""'."\n";
   $cmd[]='STREAMLOGON "'.$logon.'"'."\n";
   $cmd[]='DESCRIPTION "Get Process chain sap jobs list"'."\n";
   $cmd[]="TASKTYPE $tasktype\n";
   $cmd[]='RECOVERY STOP'."\n\n";

   foreach($cmd as $str)
      echo nl2br(htmlspecialchars($str));

$original_data = tws_composer_create_from("js=$mdm#WEBADMIN_SYNC");
$cmd2=Array();

   if($original_data == false){
      echo "<h2>Create jobstream:</h2>";

      $cmd2[]="# WebAdmin Syncronization Jobstream\n\n";
      $cmd2[]="SCHEDULE $mdm#WEBADMIN_SYNC\n";
      $cmd2[]='DESCRIPTION "WebAdmin SAP job list"'."\n";
      $cmd2[]='ON RUNCYCLE RULE1 "FREQ=DAILY;"'."\n";
      $cmd2[]=":\n";
      $cmd2[]=$fta.'#WA_'.$agent.'_ST'."\n";
      $cmd2[]=$fta.'#WA_'.$agent.'_F'."\n";
      $cmd2[]=$fta.'#WA_'.$agent.'_IP'."\n";
      $cmd2[]='   FOLLOWS WA_'.$agent.'_F'."\n";
      $cmd2[]=$fta.'#WA_'.$agent.'_PC'."\n";
      $cmd2[]='   FOLLOWS WA_'.$agent.'_F'."\n";
      $cmd2[]="END\n";
   }
   else{
      echo "<h2>Modify jobstream:</h2>";

      $cmd2 = explode("\n", $original_data);
      foreach($cmd2 as $i=>$line){
         $line = trim($line);

         if ($line == 'END'){
            array_splice($cmd2, $i);
            break;
         }
         if($line == $fta.'#WA_'.$agent.'_ST'){
            //tws_warning( $fta.'#WA_'.$agent."_ST is already exist in $mdm#WEBADMIN_SYNC jobstream");
            $st_exist = true;
         }
         if($line == $fta.'#WA_'.$agent.'_F'){
            //tws_warning( $fta.'#WA_'.$agent."_F is already exist in $mdm#WEBADMIN_SYNC jobstream");
            $f_exist = true;
         }
         if($line == $fta.'#WA_'.$agent.'_IP'){
            //tws_warning($fta.'#WA_'.$agent."_IP is already exist in $mdm#WEBADMIN_SYNC jobstream");
            $ip_exist = true;
         }
         if($line == $fta.'#WA_'.$agent.'_PC'){
            //tws_warning($fta.'#WA_'.$agent."_PC is already exist in $mdm#WEBADMIN_SYNC jobstream");
            $pc_exist = true;
         }

         $cmd2[$i] = trim($cmd2[$i])."\n";
      }
      if (!$st_exist)
         $cmd2[]=$fta.'#WA_'.$agent.'_ST'."\n";
      if (!$f_exist)
         $cmd2[]=$fta.'#WA_'.$agent.'_F'."\n";
      if (!$ip_exist){
         $cmd2[]=$fta.'#WA_'.$agent.'_IP'."\n";
         $cmd2[]='   FOLLOWS WA_'.$agent.'_F'."\n";
      }
      if (!$pc_exist){
         $cmd2[]=$fta.'#WA_'.$agent.'_PC'."\n";
         $cmd2[]='   FOLLOWS WA_'.$agent.'_F'."\n";
      }
      $cmd2[]="END\n";
   }

   foreach($cmd2 as $str)
      echo nl2br(str_replace(' ', "&nbsp;", htmlspecialchars($str)));

?>
<form method="post" action="" name="contents">
   <? echo tws_create_hidden_inputs($_POST);
   echo "<input type='hidden' name='mdm' value='$mdm'>";
   echo "<input type='hidden' name='fta' value='$fta'>";
   echo tws_create_hidden_inputs($cmd, 'cmd', null);
   echo tws_create_hidden_inputs($cmd2, 'cmd2', null);
   ?>
<br><br>
<input type="submit" name="action" value="Back">&nbsp;&nbsp;
<input type="submit" name="action" value="Continue">

<? tws_print_synchro_token(); ?>
</form>

<? else:
      //  CREATE JOBS etc.
   $maestro_dir = $tws_config['maestro_dir'];

   $tmpfilename="$maestro_dir/webadmin/tmp/job.".tws_rndstr().".tmp";
   $fp=fopen($tmpfilename,'w') or tws_dyer("Unable to create temporary file '$tmpfilename'", "", "tws_sapjob_config.php");

   foreach ($cmd as $cmdline) {
      if (fwrite($fp, $cmdline."\n") < 0) {
         fclose($fp);
         tws_dyer("Unable to write temporary file '$tmpfilename'", "", "tws_sapjob_config.php");
      }
   }
   fclose($fp);
   tws_chmod($tmpfilename,0644);

   set_time_limit(600);

   $command=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), "$maestro_dir/bin/composer", $tws_config['composer_args'], "replace $tmpfilename", hwi_cmd::operator('2>&1',FALSE));

   $stdout='';
   if (tws_popen($command, $ec, $stdout, $stdout )===FALSE)
      tws_dyer("Add jobs failed", array('cmd'=>$command->compile('log'), 'stdout'=>$stdout), "tws_sapjob_config.php");

   if( "$ec"!="0" && "$ec"!="4" ){
      echo "<form method='post' action=''>\n";
      tws_err("Add jobs failed", array('cmd'=>$command->compile('log'), 'stdout'=>$stdout));
      echo tws_create_hidden_inputs($_POST);
      tws_print_synchro_token();
      echo "<input type='submit' name='action' value='Back'/>\n";
      echo "<input type='button' name='action' value='Cancel' onClick='window.location.replace(\"tws_sapjob_config.php\");'>\n";
      echo "</form>";
      die("\n</body>\n</html>");
   }
   unlink($tmpfilename);
   echo "<h3>Jobs were created successfuly.</h3>\n";

   $original_data = tws_composer_create_from("js=$mdm#WEBADMIN_SYNC");

   $tmpfilename="$maestro_dir/webadmin/tmp/jobstream.".tws_rndstr().".tmp";
   $fp=fopen($tmpfilename,'w') or tws_dyer("Unable to create temporary file '$tmpfilename'", "", "tws_sapjob_config.php");

   foreach ($cmd2 as $cmdline) {
      if (fwrite($fp, $cmdline."\n") < 0) {
         fclose($fp);
         tws_dyer("Unable to write temporary file '$tmpfilename'", "", "tws_sapjob_config.php");
      }
   }
   fclose($fp);
   tws_chmod($tmpfilename,0644);

   $command=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), "$maestro_dir/bin/composer", $tws_config['composer_args'], "replace $tmpfilename", hwi_cmd::operator('2>&1',FALSE));

   $stdout='';
   if (tws_popen($command, $ec, $stdout, $stdout )===FALSE)
      tws_dyer("Add jobstream failed", array('cmd'=>$command->compile('log'), 'stdout'=>$stdout), "tws_sapjob_config.php");

   if( "$ec"!="0" && "$ec"!="4" ){
      echo "<form method='post' action=''>\n";
      tws_err("Add jobstream failed", array('cmd'=>$command->compile('log'), 'stdout'=>$stdout) );
      echo tws_create_hidden_inputs($_POST);
      tws_print_synchro_token();
      echo "<input type='submit' name='action' value='Back'/>\n";
      echo "<input type='button' name='action' value='Cancel' onClick='window.location.replace(\"tws_sapjob_config.php\");'>\n";
      echo "</form>";
      die("\n</body>\n</html>");
   }

   unlink($tmpfilename);
   echo "<h3>Jobstream was created successfuly.</h3>\n";
?>
<br><br>
<? if($original_data===false)
      tws_warning("To apply changes it's necessary to submit '$mdm#WEBADMIN_SYNC' jobstream.");
   else
      tws_warning("To apply changes it's necessary to cancel '$mdm#WEBADMIN_SYNC' jobstream and submit it again.");
?>
   <input type="button" name="action" value="Ok" onclick="window.location.replace('tws_sapjob_config.php');">&nbsp;&nbsp;
<? endif; ?>

</body>
</html>
