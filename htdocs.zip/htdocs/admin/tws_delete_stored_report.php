<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t"); 
?>
<html>
<head>
   <title>Delete Stored Report</title>
   <?php tws_adminstylesheet(); ?>
</head>
<body>
   <h1>Script was removed since TWA 3.1.4</h1>
</body>
</html>
