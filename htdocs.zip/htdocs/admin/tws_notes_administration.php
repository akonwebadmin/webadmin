<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t"); 
?>
<html>
<head>
<title>Notes Administration</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<?php
tws_set_window_title();
tws_print_head("Notes Administration"); ?>
<br>

<h2>Job Notes</h2>
<form method="post" name="jobcnt" action="tws_job_notes_admin.php">
<table border=0 cellspacing=0>
   <tr>
      <td class=standard width=120>Workstation:</td>
      <td class=standard>
         <input type="text" name="cpu" size=16 maxlength=16>&nbsp;&nbsp;
         <input type="button" name="workstation_list" onClick="tws_picker_open('../workstation_picker.php', 'formname=jobcnt&amp;fieldname=cpu');" value="List">
      </td>
   </tr>
   <tr>
      <td class=standard width=120>Job:</td>
      <td class=standard>
         <input type="text" name="job" size=40 maxlength=40>&nbsp;&nbsp;
         <input type="button" name="job_list" onClick="tws_picker_open('../job_picker.php', 'formname=jobcnt&amp;fieldname=job&amp;fieldvalue=' + document.jobcnt.job.value + '&amp;cpux=' + document.jobcnt.cpu.value);" value="List">
      </td>
   </tr>
   <tr><td>&nbsp;</td><td class="standard"><a href="#" onclick="document.jobcnt.cpu.value='@';document.jobcnt.job.value='@'">Select All</a></td></tr>
   <tr><td colspan="2" class="standard">&nbsp;</td></tr>
   <tr>
      <td class="standard" colspan="2">
         <input type="submit" value="View Notes" name="action" onclick="if (trim(document.jobcnt.cpu.value)=='') document.jobcnt.cpu.value='@'; if (trim(document.jobcnt.job.value)=='') document.jobcnt.job.value='@';">&nbsp;&nbsp;
         <input type="submit" value="List Notes" name="action" onclick="if (trim(document.jobcnt.cpu.value)=='') document.jobcnt.cpu.value='@'; if (trim(document.jobcnt.job.value)=='') document.jobcnt.job.value='@';">
      </td>
   </tr>
</table>
</form>

<br><br>

<h2>Workstation Notes</h2>
<form method="post" name="wkstcnt" action="tws_workstation_notes_admin.php">
<table border=0 cellspacing=0>
   <tr>
      <td class=standard width=120>Workstation:</td>
      <td class=standard>
         <input type="text" name="cpu" size=16 maxlength=16>&nbsp;&nbsp;
         <input type="button" name="workstation_list" onClick="tws_picker_open('../workstation_picker.php', 'formname=wkstcnt&amp;fieldname=cpu&amp;fieldvalue=' + document.wkstcnt.cpu.value);" value="List">
      </td>
   </tr>
   <tr><td>&nbsp;</td><td class="standard"><a href="#" onclick="document.wkstcnt.cpu.value='@'">Select All</a></td></tr>
   <tr><td colspan="2">&nbsp;</td></tr>
   <tr>
      <td class="standard" colspan="2">
         <input type="submit" value="View Notes" name="action" onclick="if (trim(document.wkstcnt.cpu.value)=='') document.wkstcnt.cpu.value='@';">&nbsp;&nbsp;
         <input type="submit" value="List Notes" name="action" onclick="if (trim(document.wkstcnt.cpu.value)=='') document.wkstcnt.cpu.value='@';">
      </td>
   </tr>
</table>
</form>


</body>
</html>
