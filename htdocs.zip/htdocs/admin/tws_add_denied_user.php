<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add Denied User</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<h1>Add Denied User</h1>
<br><br>

<form method=post name="contents" action="tws_add_denied_user_exec.php">
<table border=0 cellspacing=0>
<tr>
<td class=standard width=120>
&nbsp;&nbsp;<b>Username:</b>
</td>
<td class=standard>
<input type="text" name="username" required='required' size=16 maxlength=60>
</td>
</tr>
</table>

<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Add" name="action">&nbsp;&nbsp;
<input type="button" value="Cancel" onclick="window.location.replace('tws_auth_configuration.php');">
<? tws_print_synchro_token();     // synchro_token
?>
</form>
</body>
</html>
