<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
   tws_profile('opener', basename($_SERVER['SCRIPT_NAME']) );
?>
<html>
<head>
<title>IWS Report Administration</title>
<?php tws_adminstylesheet();
   tws_set_window_title();
?>
</head>
<body>
<h1>IWS Report Administration</h1>
<br>
<h3>Saved Reports:</h3>
<br>
<?php
function table_start(){
   echo "<table class='wireframe sortable' cellspacing=0 cellpadding=4 cols=6>\n";
   echo "<tr class=header>\n";
   echo "<th class=wireframe>&nbsp;</th>\n";
   echo "<th class=wireframe>Report Filename</th>\n";
   echo "<th class=wireframe>Type</th>\n";
   echo "<th class=wireframe>Creator</th>\n";
   echo "<th class=wireframe>For all users</th>\n";
   echo "<th class=wireframe>Description</th>\n";
   echo "</tr>\n";
}

   $users = tws_get_user_dirs();
   $table_started=FALSE;
   $all="yes";
   foreach ($users as $user) {
      $files = tws_get_reports($user,$all);
      $all="no";
      foreach ($files as $f => $val ) {
         $$f = $val;
      }
      if ($report_num > 0) {
         if (!$table_started) {
            table_start();
            $table_started = TRUE;
         }
         for ($i=1;$i<=$report_num;$i++) {
            echo "<tr>\n";
            echo "<td class=code><a href=\"tws_delete_report.php?filename=".urlencode($file[$i])."&amp;user=".urlencode($user)."&amp;forall=$forall[$i]\">Delete</a></td>\n";
            echo "<td class=code>".htmlspecialchars($file_stripped[$i])."</td>\n";
            echo "<td class=code>".htmlspecialchars($type[$i])."</td>\n";
            echo "<td class=code>".htmlspecialchars($creator[$i])."</td>\n";
            echo "<td class=code>".htmlspecialchars($forall[$i])."</td>\n";
            echo "<td class=code>".htmlspecialchars($comment[$i])."</td>\n";
            echo "</tr>\n";
         }
      }
   }
   if ($table_started) {
      echo "</table>\n";
   } else {
      echo "<p class=warning>No reports saved</p>\n";
   }

?>
<!--
<br><br>
<h3>Stored Reports:</h3>

<p class=warning>&nbsp;&nbsp;&nbsp; Users can administrate own stored reports.
-->
<?php
/*   clearstatcache();
   $num_stored_reports=0;
// TODO change spool dir - complete rework
   $dp=opendir("$base_inst_dir/httpd/htdocs/spool");
   while ($fn=readdir($dp)) {
      if ((substr($fn,0,4) == "rep.") && (substr($fn,-5) == ".html")) {
         $num_stored_reports++;
         $stored_filename[$num_stored_reports]=$fn;
         $filesize[$num_stored_reports]=filesize("$base_inst_dir/httpd/htdocs/spool/$stored_filename[$num_stored_reports]");
         $fp=fopen("$base_inst_dir/httpd/htdocs/spool/$stored_filename[$num_stored_reports]","r") or die("<p class=warning>Unable to open file $stored_filename for reading</p>\n</body>\n</html>\n");
         while (!feof($fp)) {
            $buffer=fgets($fp,4096);
            if (substr($buffer,0,4) == "<!--") {
               $line=trim(substr($buffer,4,-4));
               $key=strtok($line,":");
               switch ($key) {
                 case "Created By":
                   $report_creator[$num_stored_reports]=strtok("\n");
                   break;
                 case "Creation Date":
                   $creation_date[$num_stored_reports]=strtok("\n");
                   break;
                 case "Report Type":
                   $report_type[$num_stored_reports]=strtok("\n");
                   break;
               }
            } elseif (trim($buffer) == "<body>") {
               break;
            }
         }
         fclose($fp);
      }
   }

   if ($num_stored_reports == 0) {
      echo "<p class=warning>&nbsp;&nbsp;&nbsp;&nbsp;No stored reports</p>\n";
   } else {
      echo "<table class=wireframe cellspacing=0 cellpadding=4 width=\"100%\" cols=6>\n";
      echo "<tr class=header>\n";
      echo "<th class=wireframe>&nbsp;</th>\n";
      echo "<th class=wireframe>Report Filename</th>\n";
      echo "<th class=wireframe>Type</th>\n";
      echo "<th class=wireframe>Creator</th>\n";
      echo "<th class=wireframe>Creation Date</th>\n";
      echo "<th class=wireframe>Size</th>\n";
      echo "</tr>\n";

      for ($i=1;$i<=$num_stored_reports;$i++) {
         echo "<tr>\n";
         echo "<td class=code><a href=\"tws_delete_stored_report.php?filename=$stored_filename[$i]\">Delete</a></td>\n";
         echo "<td class=code><a href=\"/spool/$stored_filename[$i]\">$stored_filename[$i]</a></td>\n";
         if (isset($report_type[$i])) {
            echo "<td class=code>$report_type[$i]</td>\n";
         } else {
            echo "<td class=code>&nbsp;</td>\n";
         }
         if (isset($report_creator[$i])) {
            echo "<td class=code>$report_creator[$i]</td>\n";
         } else {
            echo "<td class=code>&nbsp;</td>\n";
         }
         if (isset($creation_date[$i])) {
            echo "<td class=code>$creation_date[$i]</td>\n";
         } else {
            echo "<td class=code>&nbsp;</td>\n";
         }
         if (isset($filesize[$i])) {
            echo "<td class=code>$filesize[$i]</td>\n";
         } else {
            echo "<td class=code>&nbsp;</td>\n";
         }
         echo "</tr>\n";
      }
      echo "</table>\n";
   }
*/
?>

</body>
</html>
