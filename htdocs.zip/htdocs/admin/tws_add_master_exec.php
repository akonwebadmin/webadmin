<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add IWS/WebAdmin Master</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<?php
   tws_import_request_variables("P","rqst_");

   $mastername=tws_gpc_get($rqst_mastername, 'tws_alfanum');
   $href=tws_gpc_get($rqst_href, 'tws_file');
      tws_check_synchro_token();     // synchro_token

   if ($mastername == "")
      tws_dyer("Master Name cannot be blank");
   elseif ($href == "")
      tws_dyer("Web Server URL cannot be blank");

   $fp=fopen("$maestro_dir/webadmin/etc/masters.xml","r") or tws_dyer("Unable to open $maestro_dir/webadmin/etc/masters.xml file.");
   $num_masters=0;
   while (!feof($fp)) {
      $buffer=fgets($fp,4096);
      if (substr($buffer,0,1) == "<") {
         $tok=strtok($buffer," >");
         if ($tok == "<master") {
            $file_href=strtok(">");
            $master_name[$num_masters]=strtok("<");
            $junk=strtok($file_href,"=");
            $href_location[$num_masters]=strtok("\n");
            $href_location[$num_masters]=trim($href_location[$num_masters],'"');
            if ($href_location[$num_masters] == "#local") {
               $href_location[$num_masters]="# LOCAL #";
            } else {
               $href_location[$num_masters]="http://" . $href_location[$num_masters];
            }
            $num_masters++;
         }
      }
   }
   fclose($fp);

   if (in_array($mastername,$master_name)) {
      tws_dyer("Master $mastername already exists");
   }

   $mastersxml="$maestro_dir/webadmin/etc/masters.xml";
   $mastersxmlbak="$maestro_dir/webadmin/etc/masters.xml.bak";

   if (!copy($mastersxml,$mastersxmlbak)) {
      tws_dyer("Unable to make backup copy of masters configuration file 'masters.xml'");
   }

   $fp=fopen("$maestro_dir/webadmin/etc/masters.xml","a") or tws_dyer("Unable to open masters.xml file");
   $num_bytes=fwrite($fp,"<master href=\"$href\">$mastername</master>\n");
   if ($num_bytes < 0) {
      fclose($fp);
      unlink($mastersxml);
      copy($mastersxmlbak,$mastersxml);
      tws_dyer("Unable to write file 'masters.xml' - Original file restored</p>");
   }
   fclose($fp);

   echo "<script language=\"Javascript\">\n";
   echo "window.location.replace(\"tws_masters_configuration.php\");\n";
   echo "</script>\n";
?>
</body>
</html>