<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
   tws_profile('opener', basename($_SERVER['SCRIPT_NAME']) );
?>
<html>
<head>
<title>IWS/WebAdmin Authentication Configuration</title>
<?php
   tws_adminstylesheet();
   tws_set_window_title();
   tws_import_request_variables("GP","rqst_");
?>
<script type="text/javascript">
function reloadx(authval) {
 open("tws_auth_configuration.php?authtype=" + authval,"_self");
}
</script>
</head>
<body>
<h1>IWS/WebAdmin Authentication Configuration</h1>
<br><br><br>
<?php
   if (tws_yesno($tws_config['virtual_hosts'],TRUE,FALSE)) {
      echo "<p class=\"warning\">This is a client instance of the shared instances installation model.
Any modification of the authentication setup will affect all other instances, including
the <b>Master</b> IWS/WebAdmin instance</p>\n";
   }

   if (file_exists("$base_inst_dir/etc/authconf.php")) {
      include("$base_inst_dir/etc/authconf.php");
   }

   if (isset($rqst_authtype)) {
      $authtype=$rqst_authtype;
   } else {
      $current_setup=1;
   }
   $authldapurl=$rqst_authldapurl;
?>

<form method="post" name="contents" action="tws_auth_configuration_action.php">

<table border=0 cellspacing=0>
<tr>
<td class=standard colspan=2>
<h3>Authentication Options<?=($current_setup ? ' (current setup)' : '')?></h3>
</td>
</tr>
<tr>
<td class=standard width=180>
&nbsp;&nbsp;<b>Authentication Method:</b>
</td>
<td class=standard>
<select name="authtype_option" onChange="reloadx(document.contents.authtype_option.options[document.contents.authtype_option.selectedIndex].value)">
  <option value="apache"<?php if ($authtype == "apache") echo " selected" ?>>Apache
  <option value="os"<?php if ($authtype == "os") echo " selected" ?>>Operating System (default)
  <option value="ldap"<?php if ($authtype == "ldap") echo " selected" ?>>LDAP (+Apache)
</select>
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class=standard colspan=2>
<h3>Security Options</h3>
</td>
</tr>
<tr><td>&nbsp;</td></tr>

<?php if ($authtype=='os') { ?>
<tr>
<td class=standard colspan=2>
&nbsp;&nbsp;<input type="checkbox" name="lockout_option" value="yes" <?=isset($lockout) ? 'checked' : ''?>>
Lock users out after&nbsp;&nbsp;<input type="text" name="lockout_attempts" class="tws_num" size=3 maxlength=3 value="<?php echo "$lockout" ?>">&nbsp;&nbsp;failed login attempts
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<?php } ?>

<?php if ($authtype=='os' || $authtype=='apache') { ?>
<tr>
<td class=standard colspan=2>
&nbsp;&nbsp;<input type="checkbox" name="authusers_option" value="yes" <?=(($authtype=='apache' || isset($use_authusers)) ? 'checked' : '').' '.(($authtype=='apache') ? 'disabled' : '')?>>Only allow users that are defined in authusers (entered via <a href="tws_user_administration.php">User Administration</a>)
</td>
</tr>
<?php }  ?>

<?php if ($authtype=='ldap') { ?>
<tr>
<td class=standard colspan=2>
&nbsp;&nbsp;Apache users or their administration membership are defined in authusers file (entered via <a href="tws_user_administration.php">User Administration</a>)
</td>
</tr>
<tr><td>&nbsp;</td></tr>

<tr>
<td class=standard colspan=2>
<h3>LDAP Parameters</h3>
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<?php
if (!isset($authldapurl) && $authfile=file($base_inst_dir."/httpd/conf/auth.conf")) {
   foreach ($authfile as $row) {
      if (preg_match('/^\s*authldapurl(.*)$/i', $row, $_r)) {
         $authldapurl=trim($_r[1],' "');
      }
   }
}
?>
<tr>
   <td class=standard valign=top>&nbsp;&nbsp;<b>LDAP Search URL:</b></td>
   <td class=standard valign=top>
      <input name="authldapurl" size=50 maxlength=100 value="<?=$authldapurl?>"><br>
      <p style="margin:0; padding:0; color:#808080; font-size:0.8em">URL specifying the LDAP search parameters in form <b><u>ldap://</u><u>host</u>:port/<u>basedn</u>?attribute?scope?filter</b>. Underlined parts are mandatory.<br>Example: <i>ldap://demo:389/dc=horizont,dc=com</i></p>
   </td>
</tr>
<?php } ?>

</table>

<?php if ($authtype=="os") { ?>
<table border=0 cellspacing=0>
<tr>
<td class=standard colspan=2>
<h3>Denied Users</h3>
</td>
</tr>
</table>
<?php
   $user_num=0;
   $denyusers="$base_inst_dir/httpd/conf/denyusers";
   if (file_exists($denyusers)) {
      $fp=fopen($denyusers,"r") or tws_dyer("Unable to open file '$denyusers'");
      while ($buffer=fgets($fp,4096)) {
         $user_num++;
         $username[$user_num]=trim($buffer);
      }
      fclose($fp);
   }
   if ($user_num == 0) {
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<i>None</i><br>\n";
   } else {
      echo "<table class=wireframe cellspacing=0 cellpadding=4 cols=2 style=\"margin-left:15px\">\n";
      echo "<tr class=header>\n";
      echo "<th class=wireframe>&nbsp;</th>\n";
      echo "<th class=wireframe>Username</th>\n";
      echo "</tr>\n";
      for ($i=1; $i<=$user_num; $i++) {
         echo "<tr class=standard>\n";
         echo "<td class=wireframe><input type=\"radio\" name=\"selection\" value=\"$username[$i]\"></td>\n";
         echo "<td class=wireframe>".htmlspecialchars($username[$i])."</td>\n";
         echo "</tr>\n";
      }
      echo "</table>\n";
   }
?>
&nbsp;&nbsp;&nbsp;&nbsp;<input type=submit name=action value="Add User">&nbsp;<input type=submit name=action value="Remove User">
<?php }
tws_print_synchro_token();     // synchro_token
?>

<br><br><br><br>
<input type=submit name=action value="Save">
<br><br>
</form>
</body>
</html>
