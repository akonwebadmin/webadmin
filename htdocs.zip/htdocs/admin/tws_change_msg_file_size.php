<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Change IWS Mailbox File Size</title>
<?php tws_adminstylesheet()  ?>
</head>
<body>
<h1>Change IWS Mailbox File Size</h1>
<br><br>
<h3>Selected Objects:</h3>
<?php
   $num_elements=count($selection);
   if ($num_elements == 0) {
      echo "<p class=warning>&nbsp;&nbsp;&nbsp;&nbsp;No objects selected</p>\n";
      tws_dyer();
   }

   for ($idx=0; $idx<$num_elements; ++$idx) {
      echo "&nbsp;&nbsp;&nbsp;&nbsp;".htmlspecialchars($selection[$idx])."\n";
      echo "<br>\n";
   }
   echo "<br>\n";

   echo "<form method=post action=\"tws_set_msg_file_size.php\">\n";
   for ($idx=0; $idx<$num_elements; ++$idx) {
      echo "<input type=\"hidden\" name=\"selection[]\" value=\"".htmlspecialchars($selection[$idx])."\">\n";
   }
   echo "New Mailbox File Size:&nbsp;<input type=\"text\" name=\"filesize\" class='tws_num' size=10 maxlength=10>&nbsp;&nbsp;Bytes<br><br>";
   echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Submit\">\n";
   echo "&nbsp;&nbsp;<input type='button' value='Cancel' onclick=\"window.location.replace('tws_msg_files.php')\">\n";
   tws_print_synchro_token();  // synchro_token
   echo "</form>\n";
?>
</body>
</html>
