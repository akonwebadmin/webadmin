<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   $path = '../';
   tws_doctype('t');
   tws_profile('opener', basename($_SERVER['SCRIPT_NAME']) );
?>
<html>
<head>
   <title>Miscellaneous Configuration</title>
   <meta name="author" content="HORIZONT - Software for Data Centers; www.horizont-it.com" />
   <meta name="copyright" content="HORIZONT - Software for Data Centers; www.horizont-it.com" />
   <?php tws_adminstylesheet(); ?>
   <script type="text/javascript">
   function showColorPicker() {
      document.getElementById('colorPicker').style.display = 'block';
   }
   function hideColorPicker() {
      document.getElementById('colorPicker').style.display = 'none';
   }
   function changeColor(element) {
      var newColor = element.style.backgroundColor;
      document.getElementById('colorPreview').style.backgroundColor = newColor;
      document.getElementById('colorPreview').innerHTML = '&nbsp;';
      document.getElementById('colorRadio').value = newColor;
   }

   var linkNum;
   function addRow(tableId, linkNumOffset) {
      if (linkNum == undefined) {
         linkNum = linkNumOffset + 1;
      } else {
         linkNum = linkNum + 1;
      }

      var table = document.getElementById(tableId);
      var index = table.rows.length;
      var newRow = table.insertRow(index);

      var cell;
      cell = newRow.insertCell(0);
      cell.innerHTML = '<input type="text" name="url' + linkNum + '" value="http://www." style="width: 200px;" />';
      cell = newRow.insertCell(1);
      cell.innerHTML = '<input type="text" name="title' + linkNum + '" value="" style="width: 200px;" />';
      cell = newRow.insertCell(2);
      cell.innerHTML = '<select name="target' + linkNum + '"><option value="_blank">_blank<\/option><option value="_top">_top<\/option><option value="_parent">_parent<\/option><option value="_self">_self<\/option><\/select>';
      cell = newRow.insertCell(3);
      cell.innerHTML = '<button onclick="javascript:removeRow(this); return false;"><img src="<?php echo $path; ?>images/icons/link_delete.gif" alt="Delete Link" title="Delete Link" /><\/button>';

      document.getElementById('linkMaxNum').value = linkNum;
      return;
   }

   function removeRow(button) {
      cell = button.parentNode;
      row = cell.parentNode;
      table = row.parentNode;
      table.removeChild(row);
      var index = table.rows.length;
      return;
   }

   </script>
   <style type="text/css">
      div.color {
         float: left;
         margin: 1px;
         height: 10px;
         width: 10px;
         border: 1px solid #CCCCCC;
      }
      #colorPreview {
         margin: 0 10px;
         padding: 0 10px;
         background-color: White;
         border: 1px solid Black;
         display: inline;
      }
      #colorPicker {
         position: absolute;
         left: 230px;
         display: none;
         background: #EEEEEE;
         border: 1px solid #DDDDDD;
         width: 252px;
      }
   </style>
</head>
<body>
<?php
   tws_print_head('Miscellaneous Configuration', array('__help__' => 'tws_miscconf_help.php'), '../');

   $file = $maestro_dir.'/webadmin/etc/tws_miscconf.dat';

   if ($_POST['action'] == 'Save') {
      tws_check_synchro_token();  // synchro_token
      $settings = array('links' => array(), 'color' => '');
   
      $link_max_num = $_POST['link_max_num'];
      for ($i = 1; $i <= $link_max_num; $i++) {
      if ($_POST['url'.$i] && ($_POST['url'.$i] != 'http://www.')) {
               $settings['links'][$i]['url'] = $_POST['url'.$i];
               $settings['links'][$i]['title'] = $_POST['title'.$i] ? stripslashes($_POST['title'.$i]) : $_POST['url'.$i];
               $settings['links'][$i]['target'] = $_POST['target'.$i] ? stripslashes($_POST['target'.$i]) : '_top';
      } else {
         continue;
      }
      }
   
      $settings['topbar_title'] = stripslashes($_POST['topbar_title']);
      $settings['color'] = $_POST['color'];
   
         if (tws_yesno($tws_config['virtual_hosts'],TRUE,FALSE)) {
            $target_file=$file;
            $file="$webadmin_tmp_dir/tws_miscconf.dat.tmp";
         }
   
       $fp = fopen($file, 'w');
        $num_bytes=fwrite($fp, serialize($settings));
        fclose($fp);
         if ($num_bytes<=0) {
            fclose($fp);
            tws_dyer("Cannot write configuration file '$file'.");
         }
   
         if (tws_yesno($tws_config['virtual_hosts'],TRUE,FALSE)) {
            $cpcmd = isset($tws_config['cp']) ? $tws_config['cp'] : ($tws_config['host_os'] !== 'win32' ? '/bin/cp' : 'copy');
            $stdout='';
            $cmd=new hwi_cmd(tws_sudo('',$tws_config['maestro_user']), $cpcmd, $file, $target_file);
            tws_popen($cmd, $ec, $stdout, $stdout);
            if ($ec!='0') {
               tws_dyer("Cannot install new configuration file '$target_file'.", array('stdout'=>$stdout));
            }
         }
   
      echo '<script type="text/javascript">',"<br/>\n";
         echo '   window.parent.topbar.location.reload(false)',"<br/>\n"; //refresh topbar
         echo '</script>',"<br/>\n";
   }

   if (file_exists($file)) {
      $fp = fopen($file, 'r');
      $settings = unserialize(fread($fp, filesize($file)));
      fclose($fp);
   } else {
      $settings = null;
   }
?>
<form name="contents" method="post" action="">
<h2>Additional Banner Links</h2>
<table id="linkTable" cellspacing="2" cellpadding="2">
   <colgroup span="4">
      <col width="210">
      <col width="210">
      <col width="80">
      <col width="50">
   </colgroup>
   <tr class="header"><th class="wireframe">URL</th><th class="wireframe">Title</th><th class="wireframe">Target</th><th class="wireframe">&nbsp;</th></tr>
<?php
   $links = $settings['links'] ? $settings['links'] : null;
   $link_num = 0;
   if (is_array($links) && count($links)) {
   foreach($links as $link) {
     $link_num++; ?>
         <tr>
         <td><input type="text" name="url<?php echo $link_num; ?>" value="<?=htmlspecialchars($link['url'])?>" style="width: 200px;" /></td>
         <td><input type="text" name="title<?php echo $link_num; ?>" value="<?=htmlspecialchars($link['title'])?>" style="width: 200px;" /></td>
         <td>
            <select name="target<?php echo $link_num; ?>" style="width: 70px;">
               <option value="_blank"<?php if('_blank' == $link['target']) echo ' selected="selected"';?>>_blank</option>
               <option value="_top"<?php if('_top' == $link['target']) echo ' selected="selected"';?>>_top</option>
               <option value="_parent"<?php if('_parent' == $link['target']) echo ' selected="selected"';?>>_parent</option>
               <option value="_self"<?php if('_self' == $link['target']) echo ' selected="selected"';?>>_self</option></select></td>
         <td><button onclick="javascript:removeRow(this); return false;" style="width: 40px;"><img src="<?php echo $path; ?>images/icons/link_delete.gif" alt="Delete Link" title="Delete Link" /></button></td>
         </tr>
<?php
      }
   } ?>
</table>
<button onclick="javascript:addRow('linkTable', <?php echo $link_num; ?>); return false;"><img src="<?php echo $path; ?>images/icons/link_add.gif" alt="Add Next Table Row" title="Add Next Table Row" /></button>
<h2>Top Bar Background Color</h2>
<?php $color = ($settings['color'] && ($settings['color'] != 'skin variable color')) ? $settings['color'] : ''; ?>
<?php if ($color) { ?>
<input type="radio" name="color" value="skin variable color" />&nbsp;Use Default Theme Color<br/>
<input id="colorRadio" type="radio" name="color" value="<?=htmlspecialchars($color)?>" checked="checked"/>&nbsp;<a href="javascript:showColorPicker()">Choose Another Color</a><div id="colorPreview" style="background-color: <?php echo $color; ?>;">&nbsp;</div>
<?php } else { ?>
<input type="radio" name="color" value="skin variable color" checked="checked"/>&nbsp;Use Default Theme Color<br/>
<input id="colorRadio" type="radio" name="color" value="White" />&nbsp;<a href="javascript:showColorPicker()">Choose Another Color</a><div id="colorPreview">X</div>
<?php } ?>
<div id="colorPicker" onclick="hideColorPicker();">
<?php
   for ($i = 0; $i < 256; ($i = $i + 51)) {
      for ($j = 0; $j < 256; ($j = $j + 51)) {
         for ($k = 0; $k < 256; ($k = $k + 51)) {
            echo '<div onclick="changeColor(this);" class="color" style="background-color: rgb('.$i.', '.$j.', '.$k.')"></div>';
         }
      }
   }
?>
<a href="javascript:hideColorPicker()" style="float: right; font-size: 0.8em;">[close color picker]</a>
</div>
<input type="hidden" id="linkMaxNum" name="link_max_num" value="<?php echo $link_num; ?>" />
<br/>
<br/>
<h2>Custom Title & Logo</h2>
<table>
<tr><td>Top&nbsp;Bar&nbsp;Title:</td><td><input type="text" name="topbar_title" value="<? echo isset($settings['topbar_title']) ? htmlspecialchars($settings['topbar_title']) : 'IWS/WebAdmin' ?>" size="50" maxlength="50"/>&nbsp;<input type="button" name="default_topbar_title" onClick="document.contents.topbar_title.value='IWS/WebAdmin'" value="Use Default"/></td></tr>
<tr><td style="vertical-align:top">Custom&nbsp;Logo:</td>
<td>
   <?php
      echo '<i>',$tws_config['maestro_dir'].'/webadmin/etc/custom_logo.gif','</i>';
      if (file_exists($tws_config['maestro_dir'].'/webadmin/etc/custom_logo.gif')) {
         echo '<br/><img src="',$path,'tws_get_image.php?obj=custom_logo','">';
      } else {
         echo ' -&nbsp;<b>Not&nbsp;present</b>';
      }
   ?>
</td>
</tr>
</table>
<br/>
<br/>
<br/>
<br/>
<input type="submit" name="action" value="Save" />
<? tws_print_synchro_token();   // synchro_token ?>
</form>
</body>
</html>
