<?php
//   HORIZONT Software GmbH, Munich
//

   require_once("tws_functions.php");
   tws_import_request_variables("P","rqst_");

   $action=$rqst_action;
   @$selection=$rqst_selection;

   switch ($action) {
     case "Add":
       $modify="no";
       include("tws_add_notification.php");
       break;
     case "Delete":
       include("tws_delete_notification.php");
       break;
     case "Modify":
       $modify = "yes";
       include("tws_add_notification2.php");
       break;
   }
?>