<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_config.php';

   if (!isset($base_inst_dir) && isset($tws_config['base_inst_dir'])) $base_inst_dir=$tws_config['base_inst_dir'];

   if ($host_os!='win32') {
      ini_set('include_path', ini_get('include_path').":$base_inst_dir/inc:$base_inst_dir/inc/PEAR");
   } else {
      ini_set('include_path', ini_get('include_path').";$base_inst_dir/inc;$base_inst_dir/inc/PEAR");
   }
   require_once 'tws_rc.php';
   require_once 'tws_lib.php';
   require_once 'tws_lib_admin.php';
   require_once 'tws_libui.php';

   if (!isset($__ob_init) || !$__ob_init) {
      if (!compression_enabled()) {
         $__ob_init=ob_start();
      } else {
         $__ob_init=ob_start('ob_gzhandler');
      }
   }

   // Ticket 15891, 15892: Missing HttpOnly Attribute in Session Cookie, Missing Secure Attribute in Encrypted Session	
   if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']!='' && $_SERVER['HTTPS']!='off') {
      ini_set('session.cookie_secure', true);      //
      ini_set('session.cookie_httponly', true);    // If flag is on, the cookie cannot be accessed through client side script
   } else {
      ini_set('session.cookie_secure', false);
   }
   ini_set('session.use_only_cookies', true);   // will be used only cookies to store the session id on the client side (Defaults to 1 since PHP 5.3.0.)
   ini_set('session.gc_maxlifetime', $tws_config['session_maxlifetime']>0 ? $tws_config['session_maxlifetime'] : 7200); 
   ini_set('session.gc_probability', 5);
   ini_set('session.gc_divisor', 100);

   session_cache_limiter('no-headers'); //PHP-5.2.2 workaround
   session_start();

   //final $tws_config initialization
   tws_config_init();

   require_once 'PEAR.php';
   $__pear=new PEAR();
   $__pear->setErrorHandling(PEAR_ERROR_CALLBACK, 'tws_error');

   require_once 'db_config.php';
   require_once 'db_functions.php';
   require_once 'tws_sec.php';
   require_once 'tws_composer.php';
   require_once 'tws_utils.php';
   require_once 'hwi_wrapper.php';
   require_once 'hwi_lib_sys.php';

   register_shutdown_function('tws_finalize');

   preg_match('/tws_display_log_file.php/',$_SERVER['SCRIPT_NAME']) || tws_log('', 'OPEN');
   tws_log('Starting initialization');

   //authentification
   tws_log('Authenticating requests...');
   tws_auth();
   if (tws_profile('is_admin')!=TRUE) {
      echo "Not an Admin user.\n";
      echo "<script language=\"Javascript\">\n";
      echo "   parent.navbar.location.replace(\"$url_webadmin_root/tws_navbar.php\");\n";
      echo "   parent.view_window.location.replace(\"$url_webadmin_root/tws_home.php\");\n";
      echo "</script>\n";
      exit;
   }

   //setup IWS CLI connection parameters
   tws_log('Preparing IWS connection parameters...');
   tws_connparms();

   //check and process db connection parameters
   tws_log('Preparing DB connection parameters...');
   tws_dbprms(preg_match('/admin_home.php/',$_SERVER['SCRIPT_NAME']));

   //get localopts
   tws_log('Processing IWS localopts...');
   tws_get_localopts();

   //get localopts
   tws_log('Processing IWS globallopts...');
   tws_get_globalopts();
   tws_get_optmanopts();

   //get iws cpu info
   tws_log('Procesing IWS cpuinfo...');
   tws_get_cpuinfo();

   //initialize the timezone
   $tz=(!empty($_ENV['TZ']) ? $_ENV['TZ'] : (!empty($tws_config['cpuinfo']['time_zone']) ? $tws_config['cpuinfo']['time_zone'] :  ''));
   if(!empty($tz)) {
      ini_set('date.timezone', $tz);
      $tmp = date_default_timezone_get();
      if($tmp != $tz){
         tws_error("Invalid timezone value '$tz', selected timezone is '$tmp'.");
         tws_log("Invalid timezone value '$tz', selected timezone is '$tmp'.");
      }
      tws_log("Server Timezone: $tz");
   }
   else{
      tws_log("Server Timezone undefined");
      tws_error("Server Timezone undefined");
   }

   //get time zone status
   tws_log('Checking IWS timezne status...');
   tws_get_tz_status();

   //REQ15889: Security Assessment: Cross-site request forgery. Check Referer
   if (!empty($_SERVER['HTTP_REFERER']) && !empty($_SERVER['HTTP_HOST'])) {
      if (strpos($_SERVER['HTTP_REFERER'], $_SERVER['HTTP_HOST'])===FALSE && (!empty($_POST) || !empty($_GET))) {
         tws_dyer('FATAL ERROR: This requset has been evaluated as a cross site request forgery.');
      }
   }

   //ERR17372 - Input Text Manipulation: Character Set
   tws_input_charset_validation();
?>
