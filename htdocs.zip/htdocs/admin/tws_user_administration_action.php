<?php
//   HORIZONT Software GmbH, Munich
//

   require_once("tws_functions.php");
      tws_check_synchro_token();  // synchro_token
   $selection=tws_gpc_get($_POST['selection']);

   switch ($_POST['action']) {
      case "Add New User":
         include("tws_add_user.php");
         break;
      case "Modify User":
         if ( empty($selection) ) empty_selection();
         include("tws_modify_user.php");
         break;
      case "Delete User":
         if ( empty($selection) ) empty_selection();
         include("tws_delete_user.php");
         break;
      case "Advanced User Rights":
         if ( empty($selection) ) empty_selection();
         include("tws_advanced_user_rights.php");
         break;
      case "Define User Menu":
         if ( empty($selection) ) empty_selection();
         include("tws_define_user_menu.php");
         break;
      case "Define User Action Buttons":
         if ( empty($selection) ) empty_selection();
         $groupname = "";
         include("tws_define_action_buttons.php");
         break;
      case "Import accounts from IWS Security file":
         include("tws_user_import.php");
         break;
      case "Set Default Filters":
         if ( empty($selection) ) empty_selection();
         $groupname='';
         $username = $selection;
         include("tws_define_default_filters.php");
         break;

   }

function empty_selection() {
   tws_doctype('t');
   echo "<html><head>";
   tws_adminstylesheet();
   echo "</head><body>";
   tws_print_head('No user selected', '', '../');
   echo "<p class=warning>No user selected</p>\n";
   echo "<input type='button' value='Ok' name='Back' onClick='window.location.replace(\"tws_user_administration.php\");'>";
   die("</body></html>\n");
}
?>