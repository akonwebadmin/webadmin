<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t"); 
?>
<html>
<head>
<title>Modify Job Note</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<?php
   tws_import_request_variables("P","rqst_");

   $cpu=$rqst_cpu;
   $job=$rqst_job;
   $user=$rqst_user;
   $title=stripslashes($rqst_title);
   $note_type=$rqst_note_type;
   $note_type_id=$rqst_note_type_id;
   $note_text=stripslashes($rqst_note_text);
   $action=$rqst_action;

   tws_update_note($cpu,$job,$title,$user,$note_type_id,$note_text) or tws_dyer("Unable to update note");

   echo "<script language=\"Javascript\">\n";
   if (isset($job) && $job!="") {
      echo "window.location.replace(\"tws_job_notes_admin.php?action=$action\");\n";
   } else {
      echo "window.location.replace(\"tws_workstation_notes_admin.php?action=$action\");\n";
   }
   echo "</script>\n";
?>
</body></html>
