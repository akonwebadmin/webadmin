<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Modify Event Severity Level</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<h1>Modify Event Severity Level</h1>
<br><br>

<?php
   tws_import_request_variables("P","rqst_");

   $severity_index=$rqst_severity_index;

// Do some error checking
   if (!isset($severity_index)) {
      die("<p class=warning>Error: No event severity level selected</p>\n</body>\n</html>\n");
   }

// Only allow color change for "base" severities (1-5)
   if (($severity_index >= 0) && ($severity_index <= 4)) {
      $base=TRUE;
   } else {
      $base=FALSE;
   }

// Get severities
   include($severities_file);

   $severity_label = $severity[$severity_index];
?>

<form method=post action="tws_modify_severity_level_exec.php">
<input type="hidden" name="severity_index" value="<?=$severity_index?>" >
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Severity Label:&nbsp;&nbsp;
<input type="text" name="severity_label" size=20 maxlength=20 value="<?=htmlspecialchars($severity_label)?>" <?php if($base) echo " disabled"; ?>>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Display Color:&nbsp;&nbsp;
<select name="color">
  <option style="background-color: red" value="red" <?php if ($color == "red") echo "selected"; ?>>Red</option>
  <option style="background-color: orange" value="orange" <?php if ($color == "orange") echo "selected"; ?>>Orange</option>
  <option style="background-color: yellow" value="yellow" <?php if ($color == "yellow") echo "selected"; ?>>Yellow</option>
  <option style="background-color: green" value="green" <?php if ($color == "green") echo "selected"; ?>>Green</option>
  <option style="background-color: blue" value="blue" <?php if ($color == "blue") echo "selected"; ?>>Blue</option>
  <option style="background-color: purple" value="purple" <?php if ($color == "purple") echo "selected"; ?>>Purple</option>
  <option style="background-color: firebrick" value="firebrick" <?php if ($color == "firebrick") echo "selected"; ?>>FireBrick</option>
  <option style="background-color: orangered" value="orangered" <?php if ($color == "orangered") echo "selected"; ?>>OrangeRed</option>
  <option style="background-color: darkorange" value="darkorange" <?php if ($color == "darkorange") echo "selected"; ?>>DarkOrange</option>
  <option style="background-color: gold" value="gold" <?php if ($color == "gold") echo "selected"; ?>>Gold</option>
  <option style="background-color: lime" value="lime" <?php if ($color == "lime") echo "selected"; ?>>Lime</option>
  <option style="background-color: skyblue" value="skyblue" <?php if ($color == "skyblue") echo "selected"; ?>>SkyBlue</option>
  <option style="background-color: mediumblue" value="mediumblue" <?php if ($color == "mediumblue") echo "selected"; ?>>MediumBlue</option>
  <option style="background-color: blueviolet" value="blueviolet" <?php if ($color == "blueviolet") echo "selected"; ?>>BlueViolet</option>
  <option style="background-color: darkviolet" value="darkviolet" <?php if ($color == "darkviolet") echo "selected"; ?>>DarkViolet</option>
  <option style="background-color: magenta" value="magenta" <?php if ($color == "magenta") echo "selected"; ?>>Magenta</option>
</select>
<?php if ($base) echo "<input type=\"hidden\" name=\"severity_label\" value=\"$severity_label\">\n"; ?>

<br><br>

<?php
   if ($base) {
      echo "<p>&nbsp;&nbsp;<b>Warning</b>: Modifying a base severity level !</p>\n<br>\n";
   }
   tws_print_synchro_token();  // synchro_token
?>

&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Modify">&nbsp;&nbsp;
<input type="button" value="Cancel" onclick="window.location.replace('tws_edit_severity_levels.php')">

</form>
</body>
</html>
