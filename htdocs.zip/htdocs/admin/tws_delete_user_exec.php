<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Delete IWS/WebAdmin User</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<?php
   tws_import_request_variables("P","rqst_");

   $username = tws_gpc_get($rqst_username, 'tws_alfanum\\tws_alfanum', '\\');
   tws_check_synchro_token();     // synchro_token

foreach($username as $i=>$val) {
// Remove from authusers file
   $authusers="$base_inst_dir/httpd/conf/authusers";
   $newauthusers=$authusers . ".tmp";
   $bakauthusers=$authusers . ".bak";
   $change="yes";

   $fp=fopen($authusers,"r") or tws_error("Can't open file $authusers");
   $newfp=fopen($newauthusers,"w") or tws_error("Can't open file $newauthusers");
   while ($buffer=fgets($fp,4096)) {
      $user=strtok($buffer,":");
      if ($user != $username[$i]) {
         fputs($newfp,$buffer);
      }
   }
   fclose($fp);
   fclose($newfp);

   copy($authusers,$bakauthusers) or tws_error("Can't copy file $authusers to $bakauthusers");
   copy($newauthusers,$authusers) or tws_error("Can't copy file $newauthusers to $authusers");
   unlink($newauthusers);

// Remove from authusers_desc file
   $authusers_desc="$base_inst_dir/httpd/conf/authusers_desc";
   $newauthusers_desc=$authusers_desc . ".tmp";
   $bakauthusers_desc = $authusers_desc . ".bak";

   $fp=fopen($authusers_desc,"r") or tws_error("Can't open file $authusers_desc");
   $newfp=fopen($newauthusers_desc,"w") or tws_error("Can't open file $newauthusers_desc");
   while ($buffer=fgets($fp,4096)) {
      $user=strtok($buffer,":");
      if ($user != $username[$i]) {
         fputs($newfp,$buffer);
      }
   }
   fclose($fp);
   fclose($newfp);

   copy($authusers_desc,$bakauthusers_desc) or tws_error("Can't copy file $authusers_desc to $bakauthusers_desc");
   copy($newauthusers_desc,$authusers_desc) or tws_error("Can't copy file $newauthusers_desc to $authusers_desc");
   unlink($newauthusers_desc);

// Remove from authgroups file
   $authgroups="$base_inst_dir/httpd/conf/authgroups";
   $newauthgroups=$authgroups . ".tmp";
   $bakauthgroups=$authgroups . ".bak";

   $fp=fopen($authgroups,"r") or tws_error("Can't open file $authgroups");
   $newfp=fopen($newauthgroups,"w") or tws_error("Can't open file $newauthgroups");

   while ($buffer=fgets($fp,4096)) {
      $group=strtok($buffer,":");
      $members=trim(strtok(":"));
      $members_array=explode(' ' ,$members);

      if (in_array($username[$i], $members_array)) {
         fputs($newfp,$group . ":");
         foreach ($members_array as $user) {
            if ($user != $username[$i]) {
               fputs($newfp, " $user");
            }
         }
         fputs($newfp,"\n");
      } else {
         fputs($newfp,$buffer);
      }
   }
   fclose($fp);
   fclose($newfp);

   copy($authgroups,$bakauthgroups) or tws_error("Can't copy file $authgroups to $bakauthgroups");
   copy($newauthgroups,$authgroups) or tws_error("Can't copy file $newauthgroups to $authgroups");

   unlink($newauthgroups);

// Remove from usersec.php
   $usersec="$base_inst_dir/etc/usersec.php";
   $newusersec=$usersec . ".tmp";
   $bakusersec=$usersec.".bak";

   $fp=fopen($usersec,"r") or tws_error("Can't open file $usersec");
   $newfp=fopen($newusersec,"w") or tws_error("Can't open file $newusersec");
   $pattern = "/^\\\$rights\['$username[$i]'\]/";
   while ($buffer=fgets($fp,4096)) {
      if ( !preg_match($pattern, $buffer)) {
         fputs($newfp,$buffer);
      }
   }
   fclose($fp);
   fclose($newfp);

   copy($usersec,$bakusersec) or tws_error("Can't copy file $usersec to $bakusersec");
   copy($newusersec,$usersec) or tws_error("Can't copy file $newusersec to $usersec");
   unlink($newusersec);


// Remove home directory
   if (!file_exists($base_inst_dir."/backup/home")) {
      tws_mkdir($base_inst_dir."/backup/home")===FALSE && tws_dyer("Cannnot create '/backup/home' directory.", "", "tws_user_administration.php");
      tws_chmod($base_inst_dir."/backup/home", 0755)===FALSE && tws_err("Cannnot set up permissions for '/backup/home' directory.");
   }
   if(file_exists($base_inst_dir."/backup/home/$username[$i]"))
      tws_rmdir ($base_inst_dir."/backup/home/$username[$i]");
   rename ($webadmin_user_home_dir."/$username[$i]", $base_inst_dir."/backup/home/$username[$i]");
   //tws_rmdir($webadmin_user_home_dir."/$username");
}
   echo "<script language=\"Javascript\">\n";
   echo "window.location.replace(\"tws_user_administration.php\");\n";
   echo "</script>\n";
?>
</body>
</html>
