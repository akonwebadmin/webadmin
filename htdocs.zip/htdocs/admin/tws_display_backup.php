<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_import_request_variables("GP","rqst_");
   $file = tws_gpc_get($rqst_file, 'tws_file');
   $file = basename($file);
   tws_doctype("s");
?>
<html>
<head>
   <meta http-equiv="content-type" content="text/html; charset=utf-8" />
   <title>Display Backup File '<?php echo $file; ?>'</title>
   <?php tws_adminstylesheet(); ?>
   <style type="text/css" media="all">
      html, body { height: 100%; width: 100%; margin: 0px; padding: 0px; overflow: hidden; }
      h1 { font-size: 1.4em; margin: 5px 0px 5px 5px; padding: 0; white-space: nowrap; }
      #logForScreenDiv { display: block; top: 40px;}
      #logForPrint { display: none; }
      #form { position: absolute; bottom: 5px; left: 5px; height: 25px; display: block; padding: 0px; margin: 0px;}
   </style>
   
   <style type="text/css" media="print">
      html, body { overflow: visible; }
      h1 { font-size: 25pt; margin-bottom: 20px; white-space: normal; }
      #logForScreenDiv { display: none; }
      #logForPrint { display: block; }
      #form { display: none; }
   </style>
   <?php if (isset($_SERVER['HTTP_USER_AGENT']) && (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== false) && (strpos($_SERVER['HTTP_USER_AGENT'], 'Opera') === false)) { ?>
   <script type="text/javascript">
   function copyToClipboard() {
      var source = document.getElementById('logForScreen');
      Copied = source.createTextRange();
      Copied.execCommand("Copy");
   }
   </script> 
   <?php } ?>
</head>
<body>
<?php tws_set_window_title(); ?>
<h1>Display Backup File <i>'<?php echo preg_replace("/\\\\/", '/', $maestro_dir.'/webadmin/backup/composer/'.$file); ?>'</i></h1>
<?php
   /* version for print */
   echo "<pre id=\"logForPrint\">";
   if (($result = tws_get_backupfile($maestro_dir.'/webadmin/backup/composer/'.$file)) !== FALSE) {
      echo htmlspecialchars($result['content']);
   }
   echo "</pre>";

   /* version for screen and other */
   echo "<div id=\"logForScreenDiv\"><textarea id=\"logForScreen\"  style=\"_height: expression(document.body.clientHeight - 80);\" readonly=\"readonly\">";
   if (($result = tws_get_backupfile($maestro_dir.'/webadmin/backup/composer/'.$file)) !== FALSE) {
      echo htmlspecialchars($result['content']);
   }
   echo "</textarea></div>\n";
    
?>
<br/>
<form id="form" action="">
   <input type="button" value="Print" onClick="Javascript:window.print()">
   <input type="button" value="Close Window" onClick="Javascript:window.close();">
   <?php if (isset($_SERVER['HTTP_USER_AGENT']) && (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== false) && (strpos($_SERVER['HTTP_USER_AGENT'], 'Opera') === false)) { ?>
   <input type="button" value="Copy to Clipboard" onClick="copyToClipboard();">
   <?php } ?>
</form>
</body>
</html>
