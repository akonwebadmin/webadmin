<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Modify IWS/WebAdmin User</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>
<?php
   tws_import_request_variables("P","rqst_");

   if(isset($rqst_username)){
      $username=tws_gpc_get($rqst_username, 'tws_alfanum\\tws_alfanum', '\\');
      $description = tws_gpc_get($rqst_description);
      if(isset($rqst_password)) {
         $password=tws_gpc_get($rqst_password);
         $confirm_password=tws_gpc_get($rqst_confirm_password);
      }
      else
         $password=$confirm_password='';
   }
   else {   // multiply users
      $selection=tws_gpc_get($rqst_selection, 'tws_alfanum\\tws_alfanum', '\\');
      $cnt = count($selection);
   }
   $newgroup = tws_gpc_get($rqst_group, 'tws_alfanum');      // new user's group

   tws_check_synchro_token();     // synchro_token

   if ($password!=$confirm_password) {
      echo "<p class=warning>Password fields do not match</p>\n";
      echo "<input type='button' value='Ok' name='Back' onClick='history.back()'>";
      echo "</body></html>";
      exit;
   }
   $authusers="$base_inst_dir/httpd/conf/authusers";
   $authusers_desc="$base_inst_dir/httpd/conf/authusers_desc";
   $authgroups="$base_inst_dir/httpd/conf/authgroups";

   $bakauthusers=$authusers . ".bak";
   $bakauthusers_desc=$authusers_desc . ".bak";
   $bakauthgroups=$authgroups . ".bak";

// Change description
if(!isset($selection)) {
   $newauthusers_desc=$authusers_desc . ".tmp";
   $newfp=fopen($newauthusers_desc,"w");
   if (file_exists($authusers_desc)) {
      $fp=fopen($authusers_desc,"r") or tws_error("Can't open file $authusers_desc");
      if ($fp) {
         $have_desc = false;
         while ($buffer=fgets($fp,4096)) {
           $user = strtok($buffer,":");
           if ($user == $username) {
              fputs($newfp, $username .': '. $description . "\n");
              $have_desc = true;
           }
           else
              fputs($newfp, $buffer);
         }
         if (!$have_desc)
            fputs($newfp, $username .': '. $description . "\n");
         fclose($fp);
      }
      copy($authusers_desc, $bakauthusers_desc) or tws_error("Can't copy $authusers_desc to $bakauthusers_desc");
   }
   else
      fputs($newfp, $username .': '. $description . "\n");

   fclose($newfp);
   copy($newauthusers_desc,$authusers_desc) or tws_error("Can't copy file $newauthusers_desc to $authusers_desc");
   unlink($newauthusers_desc);
}

// Change Group
   if (isset($username))
      $selection[0] = $username;
   foreach($selection as $username) {
      $newauthgroups=$authgroups . ".tmp";
      $change="no";

      $fp=fopen($authgroups,"r") or tws_dyer("Can't open file $authgroups", '', "tws_user_administration.php");
      $newfp=fopen($newauthgroups,"w") or tws_dyer("Can't open file $newauthgroups", '', "tws_user_administration.php");
      while ($buffer=fgets($fp,4096)) {
         $group = strtok($buffer,":");
         $memberstr = trim(strtok(":"));
         $members = explode(" ",$memberstr);
         if ($group == $newgroup) {
            if ( in_array($username, $members) )
               break;
            else {
               fputs($newfp,substr($buffer,0,-1) . " " . $username . "\n");
               $change="yes";
            }
         }
         else {
            if ( in_array($username, $members) ) {
               fputs($newfp, $group . ":");
               $arr = array();
               foreach ($members as $user) {
                  if ($user != $username)
                     fputs($newfp, " $user");
               }
               fputs($newfp,"\n");
               $change="yes";
            }
            else
               fputs($newfp,$buffer);
         }
      }
      fclose($fp);
      fclose($newfp);

      if ($change == "yes") {
         copy($authgroups,$bakauthgroups) or tws_dyer("Can't copy $authgroups to $bakauthgroups", '', "tws_user_administration.php");
         copy($newauthgroups,$authgroups) or tws_dyer("Can't copy $newauthgroups to $authgroups", '', "tws_user_administration.php");
      }
      unlink($newauthgroups);
   }

// Change password if new password specified
   if (isset($password) && $password != "") {
      copy($authusers,$bakauthusers);

      if(!empty($tws_config['hwf_root']))
         $hwf_root = $tws_config['hwf_root'];
      else $hwf_root = $base_inst_dir;

      if ($host_os == "win32")
         $command=new hwi_cmd("$hwf_root/httpd/bin/htpasswd", "-b", $authusers, $username, hwi_cmd::hidden($password), hwi_cmd::operator('2>&1',FALSE));
      else
         $command=new hwi_cmd("$hwf_root/httpd/bin/htpasswd", "-b", $authusers, $username, hwi_cmd::hidden($password), hwi_cmd::operator('2>&1',FALSE));

      $stdout=array(); $ec='';
      tws_popen($command,$ec,$stdout,$stdout);
      $status=1;
      foreach ($stdout as $buffer) {
         if (substr($buffer,0,17) == "Updating password") {
            $status=0;
            break;
         }
      }
      if ($status == 1) {
         copy($bakauthusers,$authusers);
         tws_dyer("Unable to modify user password. Original authusers file restored.", $stdout, "tws_user_administration.php");
      }
   }
?>
   <script language="Javascript">
      window.location.replace("tws_user_administration.php")
   </script>
</body>
</html>
