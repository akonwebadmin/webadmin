<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Cleanup Job History Table</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>
<h1>Cleanup Job History Table</h1>
<br><br>

<?php
      tws_check_synchro_token();     // synchro_token
   tws_import_request_variables("P","rqst_");

   $jobhist_age=tws_gpc_get($rqst_jobhist_age, 'tws_num');

   if ($jobhist_age == "") {
      tws_warning("Record age not specified");
      tws_dyer();
   } elseif (!is_numeric($jobhist_age)) {
      tws_dyer("Record age is invalid");
   }

   set_time_limit(600);

   db_connect($webadmin_db,DB_PERSISTENT) or tws_dyer("Could not connect to database");
   $schema=$webadmin_db['schema'];

   $age_datestamp=mktime(12,0,0,date("m"),date("d") - $jobhist_age,date("Y"));
   $age_date=date("Y-m-d 23:59:59",$age_datestamp);

   $check_query="SELECT COUNT(*) AS NUMROWS FROM $schema.jobhist WHERE sched_date < '$age_date'";

   db_query($webadmin_db,$check_query) or tws_dyer("Database query failed");

   if ($row=db_fetch_row($webadmin_db)) {
      $num_records=$row['NUMROWS'];
      echo "&nbsp;&nbsp;&nbsp;&nbsp;All records older than <b>$age_date</b> will be deleted from the <b>jobhist</b> table\n";
      echo "<br><br>\n";
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<b>$num_records</b> records selected for deletion\n";
      echo "<br><br><br>\n";
      echo "<form method=post action=\"tws_cleanup_jobhist_exec.php\">\n";
      echo "<input type=\"hidden\" name=\"age_date\" value=\"$age_date\">\n";
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Proceed\" name=\"action\">\n";
      echo "&nbsp;&nbsp;<input type='button' value='Cancel' onclick=\"window.location.replace('tws_database_cleanup.php')\">\n";
         tws_print_synchro_token();  // synchro_token
      echo "</form>\n";
   }

   db_close($webadmin_db);
?>
</body>
</html>
