<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');
   tws_profile('opener', basename($_SERVER['SCRIPT_NAME']) );
?>
<html>
<head>
<title>View IWS Logfile</title>
<?php tws_adminstylesheet(); ?>
<script type="text/javascript">
   // JavaScript prepared for date picker - not used now
   var today = new Date();
   var day   = today.getDate();
   var month = today.getMonth();
   var year  = y2k(today.getYear());
   var showtoday = '#e0e0e0';

   function y2k(number) {
      return (number < 1000) ? number + 1900 : number;
   }

   function padout(number) {
      return (number < 10) ? '0' + number : number;
   }
   function restart() {
      document.tws_log.date.value = '' + year + '-' + padout(month - 0 + 1) + '-' + padout(day);
      datewindow.close();
   }

   function dateWindow() {
      datewindow=open('../date_picker.html','date_picker','width=350,height=270,toolbar=no,menubar=no,location=no,scrollbars=no,resizable=no');
      datewindow.location.href = '../date_picker.html';
      if (datewindow.opener == null)
         datewindow.opener = self;
   }

   function KeyEventFunction(e) {
      var mykey;
      if (window.Event) {
         mykey = e.which;
      } else {
         mykey = window.event.keyCode;
      }
      mykey = String.fromCharCode(mykey);
      if ((mykey == "r") || (mykey == "R")) {
         document.location.reload();
      } else if ((mykey == "l") || (mykey == "L")) {
         history.go();
      }
   }
</script>
<style type="text/css">
   table {width:100%}
   a {text-decoration:none;font-size:0.8em}
</style>
</head>
<body>
<?php
   tws_set_window_title();
   tws_print_head('IWS Logfile', 'tws_log_help.php', '../');

   tws_import_request_variables('GP', 'rqst_');

   if (isset($rqst_twslogfilter) && ($rqst_twslogfilter !== '')) {
      $tws_log_filter = tws_gpc_get($rqst_twslogfilter, 'tws_filter');
   }

   if (isset($rqst_date) && ($rqst_date !== '')) {
      $date = tws_gpc_get($rqst_date, 'tws_datetime');
   } else {
      $date = date('Y-m-d');
   }
   $date2 = substr($date,0,4).substr($date,5,2).substr($date,8,2);
   // $date_dir=substr($date,0,4) . "." . substr($date,5,2) . "." . substr($date,8,2);
?>
<form method="post" name="tws_log" action="tws_log.php" onsubmit="if (document.getElementById('date').value != '' && !document.getElementById('date').value.match(/[0-9]{4}-(0|1)[0-9]-[0-3][0-9]/)) {document.getElementById('date').style.background='#FFDDDD';window.alert('Invalid date!');return false;}">
<table border="0" cellspacing="1" cellpadding="0">
<tr>
   <td width="50">
      <b>Filter:</b>
   </td>
   <td>
      <input id="filter" type="text" name="twslogfilter"<?php if (isset($tws_log_filter)) echo ' value="',$tws_log_filter,'"'; ?> size="20" maxlength="40"/>
      <select name="predefined_values" style="color:gray" onchange="if (this.value != '') document.getElementById('filter').value = this.value; this.options[0].selected = true;">
         <option style="display:none;color:black" value="">predefined</option>
         <option style="color:black" value="APPSRVMN">APPSRVMN</option>
         <option style="color:black" value="BATCHMAN">BATCHMAN</option>
         <option style="color:black" value="CONNECTR">CONNECTR</option>
         <option style="color:black" value="JOBMAN">JOBMAN</option>
         <option style="color:black" value="MAILMAN">MAILMAN</option>
         <option style="color:black" value="MONMAN">MONMAN</option>
      </select>
      &nbsp;&nbsp;&nbsp;
      <input type="hidden" name="twslogfilter_sensitive" value="case_sensitive"<?php if (isset($rqst_twslogfilter_sensitive)) echo ' checked="checked"'; ?>/>
      <input type="checkbox" name="twslogfilter_sensitive" value="case_insensitive"<?php if (isset($rqst_twslogfilter_sensitive) && ($rqst_twslogfilter_sensitive === 'case_insensitive')) echo ' checked="checked"'; ?>/>&nbsp;case&nbsp;insensitive
   </td>
</tr>
<tr>
   <td colspan="2">&nbsp;</td>
</tr>
<tr>
   <td>
      <b>Date:</b>
   </td>
   <td>
      <input id="date" type="text" name="date" size="10" maxlength="10" value="<?php echo $date; ?>"><!-- &nbsp;<input type="button" name="date_list" onClick="dateWindow()" value=" List "> -->&nbsp;(YYYY-MM-DD)
   </td>
</tr>
<tr>
   <td colspan="2">&nbsp;</td>
</tr>
<tr>
   <td colspan="2">
<?php
   if ($date > date('Y-m-d')) {
      echo '<span style="font-size:0.8em">&lt;&lt;&nbsp;Prev</span>&nbsp;|';
   } else {
      $prev_date = date('Y-m-d', mktime(0,0,0,substr($date,5,2),substr($date,8,2) - 1,substr($date,0,4)));
      echo '<a href="tws_log.php" onclick="document.getElementById(\'date\').value = \'',$prev_date,'\'; document.tws_log.submit();return false;">&lt;&lt;&nbsp;Prev</a>&nbsp;|';
   }
   if ($date >= date('Y-m-d')) {
      echo '&nbsp;<span style="font-size:0.8em">Next&nbsp;&gt;&gt;</span>'."\n";
   } else {
   $next_date = date('Y-m-d', mktime(0,0,0,substr($date,5,2),substr($date,8,2) + 1,substr($date,0,4)));
   echo '&nbsp;<a href="tws_log.php" onclick="document.getElementById(\'date\').value = \'',$next_date,'\'; document.tws_log.submit();return false;">Next&nbsp;&gt;&gt;</a>'."\n";
   }
?>
      &nbsp;&nbsp;&nbsp;
      <input type="submit" name="action" value=" Go "/>
      <input type="button" value=" Print " onclick="javascript:window.print();"/>
   </td>
</tr>
</table>
</form>
<hr/>
<?php
   $maestro_user_uc = strtoupper($maestro_user);
   $logfilename = $maestro_dir.'/stdlist/logs/'.$date2.'_TWSMERGE.log';

   if (!file_exists($logfilename)) {
      echo '<p class="warning">No IWS Logfile for \'',$date,'\' date</p>',"\n";
   } else {
      if (tws_yesno($tws_config['virtual_hosts'],TRUE,FALSE)) {
         $catcmd = isset($tws_config['cat']) ? $tws_config['cat'] : ($tws_config['host_os'] !== 'win32' ? '/bin/cat' : "$tws_config[maestro_dir]/webadmin/bin/type");
         $stdout=$stderr=FALSE;
         $last_buffer=NULL;
         $cmd = new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), $catcmd, $logfilename);
         $pipes=tws_popen($cmd, $ec, $stdout, $stderr);
         $fp=$pipes[1];
      } else {
         $fp = fopen($logfilename, 'r');
      }

      if (!$fp) {
         tws_err('Unable to display IWS Logfile');
      } else {
         echo '<pre>',"\n";
         if (isset($tws_log_filter)) {
         $tws_log_filter = '/('.addcslashes($tws_log_filter, '{}[]()*+?.|/^').')+/'.(isset($rqst_twslogfilter_sensitive) && ($rqst_twslogfilter_sensitive === 'case_insensitive') ? 'i' : '');
            while (!feof($fp)) {
               $buffer=fgets($fp, 4096);
               if (tws_yesno($tws_config['virtual_hosts'],TRUE,FALSE) && $tws_config['host_os']=='win32') {
                  if ($last_buffer!==NULL && preg_match($tws_log_filter, $last_buffer)) echo htmlspecialchars($last_buffer);
                  $last_buffer=$buffer;
               } else {
                  if (preg_match($tws_log_filter, $buffer)) echo htmlspecialchars($buffer);
               }
            }
         } else {
            while (!feof($fp)) {
               $buffer=fgets($fp, 4096);
               if (tws_yesno($tws_config['virtual_hosts'],TRUE,FALSE) && $tws_config['host_os']=='win32') {
                  if ($last_buffer!==NULL) echo htmlspecialchars($last_buffer);
                  $last_buffer=$buffer;
               } else {
                  echo htmlspecialchars($buffer);
               }
            }
         }

         if ($tws_config['virtual_hosts'] == TRUE) {
            $tws_config['host_os']=='win32' && $pipes['last_buffer']=$last_buffer;
            $rc=tws_pclose($pipes);
         } else {
            fclose($fp);
         }
         echo '</pre>',"\n";
      }
   }
?>
</body>
</html>
