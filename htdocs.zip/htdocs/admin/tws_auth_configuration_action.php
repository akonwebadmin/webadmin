<?php
//   HORIZONT Software GmbH, Munich
//

   require_once("tws_functions.php");
   tws_import_request_variables("P","rqst_");

   $action=$rqst_action;
   @$selection=tws_gpc_get($rqst_selection);

   switch ($action) {
     case "Save":
       include("tws_set_auth_configuration.php");
       break;
     case "Add User":
       include("tws_add_denied_user.php");
       break;
     case "Remove User":
       include("tws_remove_denied_user.php");
       break;
     case "Back":
       include("tws_auth_configuration.php");
       break;
     case "Continue":
       $confirm_status='confirmed';
       include("tws_set_auth_configuration.php");
       break;
   }
?>