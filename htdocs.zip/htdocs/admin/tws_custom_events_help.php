<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');
?>
<html>
<head>
   <title>IWS Custom Events Help</title>
   <?php tws_adminstylesheet(); ?>
</head>
<body class=help>
<?php
   tws_set_window_title();
   $path = '../';
   include $path.'tws_help_topbar.php';
?>
<h1 class=help>IWS Custom Events Help</h1>
<p>The IWS Custom Events page is used to define custom severity levels for specific events. For example, you might want jobs named TEST* to generate and INFO severity event if they abend, and jobs named CRT* to generate a CRITICAL severity event when they abend. A table of currently defined custom events is displayed with the following fields:
<ul>
  <li><strong>Event Type</strong> : Event Type: Job Abend, Job Failed, Jobstream Launched, etc.</li>
  <li><strong>Conditions</strong> : Custom Event Criteria: Workstation name, job name, etc.</li>
  <li><strong>Severity</strong> : Custom Event Severity level.</li>
</ul>
<h2 class=help>Actions</h2>
<p><strong>Add</strong> : Add a new custom event
<p><strong>Delete</strong> : Delete the selected custom event
</body>
</html>
