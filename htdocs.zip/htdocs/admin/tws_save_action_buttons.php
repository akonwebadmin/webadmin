<?php
//   HORIZONT Software GmbH, Munich
//

require_once("tws_functions.php");
tws_doctype("t");
?>
<html>
<head>
<?php tws_adminstylesheet(); ?>
<script type="text/javascript">
function goback() {
window.location.replace("tws_user_administration.php");
}
</script>
</head>
<body>
<?php
tws_import_request_variables("P","rqst_");

$action = tws_gpc_get($rqst_action);
$username = tws_gpc_get($rqst_username, 'tws_alfanum\\tws_alfanum', '\\');
$groupname = tws_gpc_get($rqst_groupname, 'tws_alfanum');
$selection = tws_gpc_get($rqst_selection, 'tws_alfanum\\tws_alfanum', '\\');
   tws_check_synchro_token();     // synchro_token

$edit_default_actions = false;// curently editing default actions
$edit_user_actions = false;// curently editing user actions
$edit_group_actions = false;// curently editing group actions

if ($username != '' || is_array($selection) )
   $edit_user_actions = true;
elseif ($groupname !='')
   $edit_group_actions = true;
else
   $edit_default_actions = true;

if ($action == "Save Changes") {                /// ********* Save Changes ********** ///
   if(is_array($selection)) {
      foreach($selection as $name)
         $mkdir[] = $webadmin_user_home_dir."/".$name;
   }
   elseif($username !='')
      $mkdir[] = $webadmin_user_home_dir."/".$username;
   elseif($groupname !='')
      $mkdir[] = $webadmin_user_home_dir."/groups/".$groupname;
   else // default values
         $mkdir[] = $webadmin_user_home_dir."/all_users";

   // Create directories if needed
   foreach($mkdir as $dir) {
      if (!is_dir($dir)) {
         if (!tws_mkdir($dir))
            tws_dyer ("Unable to create $dir directoty!", '', "tws_user_administration.php");
      }
      if (!is_dir($dir.$user_setting_dir)) {
         if (!tws_mkdir($dir.$user_setting_dir))
            tws_dyer ("Unable to create ".$dir.$user_setting_dir." directoty!", '', "tws_user_administration.php");
      }

      // Write posted values
      $fname = $dir.$user_setting_dir."/actions.php";
      $newfname=$fname . ".tmp";
      $bakfname=$fname . ".bak";

      if (is_file($fname)) {
         copy($fname,$bakfname);
      }
      $newfp=fopen($newfname,"w") or tws_dyer("Unable to create file $newfname", "", "tws_user_administration.php");
      fputs($newfp,"<?php\n");

      foreach($tws_default_actions as $section => $actions) {
         eval( "\$posted_sel = \$rqst_".$section.";" );
         eval( "\$changed = \$rqst_".$section."_changed;" );

         //echo "changed = $changed<br>\n";
         if (is_array($posted_sel))
            $strActions = implode(':', $posted_sel);
         else $strActions = '';
         $str = '$tws_actions [\''. $section . '\'] = \'' . $strActions .'\';';
         fputs($newfp, $str ."\n");
      }
      fputs($newfp,"?>\n");
      fclose ($newfp);

      copy($newfname,$fname) or tws_dyer("Unable to copy $newfname to $fname");
      unlink($newfname);
   }

   tws_print_head("Action Buttons saved",'','../');
   if ($username !='')
      echo "<p class=warning>Action Buttons Configuration saved for user $username</p>";
   elseif(is_array($selection) )
      echo "<p class=warning>Action Buttons Configuration saved for selected users</p>";
   elseif ($groupname !='')
      echo "<p class=warning>Action Buttons Configuration saved for group $groupname</p>";
   else
      echo "<p class=warning>Default Action Buttons Configuration saved</p>";

   if ($edit_user_actions )
      echo "<br><br><input type='Button' name='action' value=' Ok ' onClick='window.location.replace(\"tws_user_administration.php\")'>";
   elseif ($edit_group_actions )
      echo "<br><br><input type='Button' name='action' value=' Ok ' onClick='window.location.replace(\"tws_user_administration.php#groups\")'>";
   else
      echo "<br><br><input type='Button' name='action' value=' Ok ' onClick='window.location.replace(\"tws_user_administration.php#defaults\")'>";

   //   echo "<script language='Javascript'>\n";
   //   echo "window.location.replace('tws_user_administration.php');\n";
   //   echo "</script>\n";
}
elseif ($action == "Remove Custom Profile" ) {
   if(is_array($selection)) {
      foreach($selection as $user)
         tws_ab_RemoveCustomProfile($user, '');
   }
   elseif($username!='')
      tws_ab_RemoveCustomProfile($username, '');
   elseif($groupname!='')
      tws_ab_RemoveCustomProfile('', $groupname);

   echo "<script language='Javascript'>\n";
   if ($edit_user_actions)
      echo "window.location.replace('tws_user_administration.php');\n";
   elseif($edit_group_actions )
      echo "window.location.replace('tws_user_administration.php#groups');\n";
   else
      echo "window.location.replace('tws_user_administration.php#defaults');\n";
   echo "</script>\n";
}
elseif ($action == "Use Group Default Values" || $action == "Use Default Values") {
   echo "<script language='Javascript'>\n";
   echo "window.location.replace('tws_define_action_buttons.php?user=".urlencode($username)."&group=".urlencode($groupname)."&action=".urlencode($action)."');\n";
   echo "</script>\n";
}
echo "</body></html>";


// *****************


function tws_ab_RemoveCustomProfile($username, $groupname='') {   // remove actions.php file from home directory
   global $user_setting_dir, $webadmin_user_home_dir;

   if ($username != '') {
      $myfile = $webadmin_user_home_dir."/".$username.$user_setting_dir."/actions.php";
      if ( is_file($myfile) )
         unlink ($myfile);
   }
   elseif($groupname != '') {
      $myfile = $webadmin_user_home_dir."/groups/".$groupname.$user_setting_dir."/actions.php";
      if ( is_file($myfile) )
         unlink ($myfile);
   }
}
?>