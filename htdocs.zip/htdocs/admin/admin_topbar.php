<?php
//   HORIZONT Software GmbH, Munich
//

   $path = '../';
   require_once 'tws_functions.php';
   tws_doctype('t');
?>
<html>
<head>
   <title>IWS/WebAdmin Navigation</title>
   <?php tws_csssheet(false, '../'); ?>

   <script type="text/javascript">
      var timer;
      var menuStatus = 'expand';
      var menuMaxWidth = 0;
      var menuMinWidth = 0;
      var frameset = window.parent.document.getElementById('frameset');
      var framemenu = window.parent.document.getElementById('navbar');

      /*
       * Function can expand or collapse frame with menu.
       */
      function menu() {
         window.clearTimeout(timer);
         var i;
         var image = document.getElementById('bar_menu');

         if (menuStatus == 'expand') {
            menuMaxWidth = Number(frameset.cols.match(/(\s*)(\d+)(\s*)/)[0]);
            // for (i = 1; (i + menuMinWidth) < menuMaxWidth; i++) {
            for (i = 1; i < menuMaxWidth; i++) {
               cols = (menuMaxWidth - i) + ', *';
               timer = window.setTimeout("resizeMenu('" + cols + "')", i * 2);
            }
            image.src = '../images/icons/bar_menu_expand.gif';
            menuStatus = 'collapse';
         }
         else {
            menuMinWidth = Number(frameset.cols.match(/(\s*)(\d+)(\s*)/)[0]);
            for (i = 1; (i + menuMinWidth) < menuMaxWidth; i++) {
               cols = (menuMinWidth + i) + ', *';
               timer = window.setTimeout("resizeMenu('" + cols + "')", i * 2);
            }
            image.src = '../images/icons/bar_menu_collapse.gif';
            menuStatus = 'expand';
         }
      }

      function resizeMenu(cols) {
         frameset.cols = cols;
      }

      function openHelp() {
         var url_none_help = '<?php echo $path; ?>tws_none_help.php?admin=true';
         open(url_none_help, '', 'height=400, width=600, toolbar=no, menubar=no, location=no, scrollbars=yes, resizable=yes');
      }

      function print() {
         var printObject = window.parent.view_window;
         if ((printObject.data != undefined) && (printObject.data != null))
            printObject = printObject.data;
         printObject.print();
      }

      function reload() {
         var reloadObject = window.parent.view_window;
         if ((reloadObject.data != undefined) && (reloadObject.data != null))
            reloadObject = reloadObject.data;
         reloadObject.location.reload();
      }
   </script>
</head>
<?php
   $file = $maestro_dir.'/webadmin/etc/tws_miscconf.dat';

   if (file_exists($file)) {
      $fp = fopen($file, 'r');
      $settings = unserialize(fread($fp, filesize($file)));
      fclose($fp);
   } else {
      $settings = null;
   }
   $color = ($settings['color'] && ($settings['color'] != 'skin variable color')) ? $settings['color'] : ''; ?>
<body class="topbar" style="background-color: <?php echo $color; ?>;">
   <?php
      if (isset($settings['topbar_title']) && strtolower(trim($settings['topbar_title']))!=='tws/webadmin') {
         echo '<a style="font-family: Arial, Helvetica, sans-serif; float: left; font-size: 14px; line-height:17px; margin: 0 0 0 0; padding: 0 5px; font-weight: bold; color:#606060; background-color: white; text-decoration: none;" target="_top" title="',htmlspecialchars($settings['topbar_title']),'" href="',$path,'index.php">',htmlspecialchars($settings['topbar_title']),'</a>';
      } else {
         echo '<a style="float: left; margin: 1px 10px" href="',$path,'index.php" target="_top"><img src="',$path,'images/iws_webadmin.gif" alt="IWS/WebAdmin logo" title="IWS/WebAdmin Home Page" /></a>';
      }
   ?>
   <a href="http://www.horizont-it.com" style="font-family: Arial, Helvetica, sans-serif; float: right; font-size: 15px; margin: 0 0 0 5px; padding: 0 5px; font-weight: normal; color: Black; background-color: White; text-decoration: none;" target="_top" title="HORIZONT">H<span style="color: Red;">O</span>RIZONT</a>
   <a style="float: right; margin: 0 0 0 5px" href="javascript:openHelp();"><img src="<?php echo $path; ?>images/icons/bar_help.gif" alt="Help" title="Open help window" /></a>
   <a style="float: right; margin: 0 0 0 5px" href="javascript:reload();"><img src="<?php echo $path; ?>images/icons/bar_refresh.gif" alt="Refresh" title="Refresh main page" /></a>
   <a style="float: right; margin: 0 0 0 5px" href="javascript:print();"><img src="<?php echo $path; ?>images/icons/bar_print.gif" alt="Print" title="Print main page" /></a>
   <a style="float: right; margin: 0 0 0 5px" href="admin_home.php" target="view_window"><img src="<?php echo $path; ?>images/icons/bar_admin.gif" alt="IWS/WebAdmin Administration Page" title="IWS/WebAdmin Administration Page" /></a>
   <a style="float: right; margin: 0 0 0 5px" href="<?php echo $path; ?>index.php" target="_top"><img src="<?php echo $path; ?>images/icons/bar_home.gif" alt="Home" title="IWS/WebAdmin Home Page" /></a>
   <a style="float: right; margin: 0 0 0 5px" href="javascript:menu();"><img id="bar_menu" src="<?php echo $path; ?>images/icons/bar_menu_collapse.gif" alt="Menu arrow" title="Expand/collapse menu" /></a>
</body>
</html>
