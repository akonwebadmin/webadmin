<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Delete Report</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<h1>Delete Report</h1>
<br><br>
<h3>Confirm Report Delete:</h3>

<?php
   tws_import_request_variables("GP","rqst_");

   $filename=tws_gpc_get($rqst_filename, 'tws_file');
   $filename = urldecode($filename);
   $filename = basename($filename);

   if (!isset($filename)) {
      tws_warning("No report selected");
      tws_dyer();
   }
   echo "<form method=\"post\" action=\"tws_delete_report_exec.php\">\n";;
   echo "&nbsp;&nbsp;&nbsp;&nbsp;<b>".htmlspecialchars($filename)."</b>&nbsp;&nbsp;from";
   echo "<input type=\"hidden\" name=\"filename\" value=\"".htmlspecialchars($filename)."\">\n";
   if (isset($rqst_forall) && ($rqst_forall=='YES')) {
      echo "<input type=\"hidden\" name=\"forall\" value=\"YES\">\n";
      echo "<b>all_users</b>";
   } else {
      if (isset($rqst_user)) {
         echo "<input type=\"hidden\" name=\"user\" value=\"".htmlspecialchars($rqst_user)."\">\n";
         echo "<b>".htmlspecialchars($rqst_user)."</b>";
      } else {
         echo "<input type=\"hidden\" name=\"user\" value=\"".tws_profile('auth_user_name')."\">\n";
         echo "<b>".tws_profile('auth_user_name')."</b>";
      }
   }
   tws_print_synchro_token();  // synchro_token
?>
<br><br><br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" value="Delete" name="action">&nbsp;&nbsp;
<input type="button" value="Cancel" onclick="window.location.replace('tws_report_administration.php');">
</form>
</body>
</html>
