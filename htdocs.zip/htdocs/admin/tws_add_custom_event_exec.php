<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add Custom Event</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<h1>Add Custom Event</h1>
<br>

<?php
   tws_import_request_variables("P","rqst_");

   $event_num=tws_gpc_get($rqst_event_type, 'tws_num');
   $workstation=tws_gpc_get($rqst_workstation, 'tws_mask');
   $jobstream=tws_gpc_get($rqst_jobstream, 'tws_mask');
   $job_workstation=tws_gpc_get($rqst_job_workstation, 'tws_mask');
   $job=tws_gpc_get($rqst_job, 'tws_mask');
   @$logon=$rqst_logon;
   @$script=$rqst_script;
   $prompt=tws_gpc_get($rqst_prompt, 'tws_mask');
   $severity=tws_gpc_get($rqst_severity);
      tws_check_synchro_token();  //    synchro_token

// Do some sanity checking - Custom Job Event must have workstation, jobstream, job_workstation, job, logon, or script set
   if (tws_event_type($event_num,"job")) {
      if (($workstation == "") && ($jobstream == "") && ($job_workstation == "") && ($job == "") && ($logon == "") && ($script == "")) {
         tws_warning("For custom Job events, one of the following criteria must be specified: Job, Logon, or Script");
         tws_dyer('', '', 'back');
      }
// Custom Jobstream Event must have workstation or jobstream set
   } elseif (tws_event_type($event_num,"jobstream")) {
      if (($workstation == "") && ($jobstream == "")) {
         tws_warning("For Jobstream alerts, Jobstream must be specified");
         tws_dyer('', '', 'back');
      }
// Custom Prompt Event must have prompt set
   } elseif (tws_event_type($event_num,"prompt")) {
      if ($prompt == "") {
         tws_warning("For Prompt alerts, Prompt name must be specified");
         tws_dyer('', '', 'back');
      }
   }
// Severity must be set
   if ($severity == "-- Select One --") {
      tws_warning("Severity not specified");
      tws_dyer('', '', 'back');
   }
   tws_check_arg($severity, 'tws_num');

// get custom events
   include($custom_events_file);

   $custom_event[] = Array (
      'event_num' => $event_num,
      'workstation' => $workstation,
      'jobstream' => $jobstream,
      'job_workstation' => $job_workstation,
      'job' => $job,
      'logon' => $logon,
      'script' => $script,
      'prompt_name' => $prompt,
      'severity_level' => $severity
   );

   tws_save_custom_events($custom_event);

   echo "<script language=\"Javascript\">\n";
   echo "window.location.replace(\"tws_custom_events.php\");\n";
   echo "</script>\n";
?>
</body>
</html>
