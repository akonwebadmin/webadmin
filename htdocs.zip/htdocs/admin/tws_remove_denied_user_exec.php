<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Remove Denied User</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<?php
   tws_import_request_variables("P","rqst_");

   $username=tws_gpc_get($rqst_username, 'tws_alfanum\\tws_alfanum', '\\');
   tws_check_synchro_token();     // synchro_token

   $denyusers="$base_inst_dir/httpd/conf/denyusers";
   $newdenyusers="$base_inst_dir/httpd/conf/denyusers.new";
   $bakdenyusers="$base_inst_dir/httpd/conf/denyusers.bak";

// Modify denyusers file
   $fp=fopen($denyusers,"r") or tws_dyer("Can't open file '$denyusers'");
   $newfp=fopen($newdenyusers,"w") or tws_dyer("Can't open file '$newdenyusers'");
   while ($buffer=fgets($fp,4096)) {
      $user=trim($buffer);
      if ($user != $username) {
         fputs($newfp,$buffer);
      }
   }
   fclose($fp);
   fclose($newfp);

   copy($denyusers,$bakdenyusers) or tws_dyer("Can't copy $denyusers to $bakdenyusers");
   copy($newdenyusers,$denyusers) or tws_dyer("Can't copy $newdenyusers to $denyusers");
   unlink($newdenyusers);

   echo "<script language=\"Javascript\">\n";
   echo "window.location.replace(\"tws_auth_configuration.php?authtype=os\");\n";
   echo "</script>\n";
?>
</body>
</html>
