<?php
//   HORIZONT Software GmbH, Munich
//

   require_once("tws_functions.php");
   tws_import_request_variables("P","rqst_");

   @$type = $rqst_type;
   @$obj_name = $rqst_obj_name;
   @$creator = $rqst_creator;
   @$createdfrom = $rqst_createdfrom;
   @$createdto = $rqst_createdto;
   @$search = $rqst_search;
   @$case_sensitive = $rqst_case_sensitive;
   @$edit_file = $rqst_edit_file;
   $action = $rqst_action;
   $object = 'backup';
   $path='../';

   switch ($action) {
      case "Set Filter":
         include("tws_set_backup_filter.php");
         break;
      case "Clear Filter":
         tws_profile($object.'filter','');
         header("Location: tws_backup_administration.php");
         break;
      case "Load Filter":
         include($path."tws_load_filter.php");
         break;
      case "Save Filter":
         $redirect = false;                           // flag for set function, not redirect at end - continue
         include('tws_set_backup_filter.php');
         header("Location: /tws_save_filter.php?object=$object&edit_file=".urlencode($edit_file));
         header("Connection: close");
         exit;
   }
?>