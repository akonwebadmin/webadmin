<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html><head>
<title>Add Alert</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<?php
   tws_import_request_variables("P","rqst_");

   $modify=$rqst_modify;
   $alert_id=tws_gpc_get($rqst_alert_id, 'tws_num');
   $event_num=tws_gpc_get($rqst_event_type, 'tws_num');
   $severity=tws_gpc_get($rqst_severity, 'tws_num');
   $workstation=tws_gpc_get($rqst_workstation, 'tws_mask');
   $jobstream=tws_gpc_get($rqst_jobstream, 'tws_mask');
   $job_workstation=tws_gpc_get($rqst_job_workstation, 'tws_mask');
   $job=tws_gpc_get($rqst_job, 'tws_mask');
   $logon=tws_gpc_get($rqst_logon);
   $script=tws_gpc_get($rqst_script);
   $recipient=tws_gpc_get($rqst_recipient);
   $subject=tws_gpc_get($rqst_subject);
   $email_text=tws_gpc_get($rqst_email_text);
   $command=tws_gpc_get($rqst_command);
   $description=tws_gpc_get($rqst_description);
   $filer_type=tws_gpc_get($rqst_filter_type);
      tws_check_synchro_token();  //    synchro_token

   $twa_meta='';

   echo "<h1>".( @$modify=="yes" ? "Modify Alert" : "Add Alert" )."</h1>\n";
   echo "<br>\n";


// Do some sanity checking - Job Alert must have job, logon, or script set
   if (tws_event_type($event_num,"job")) {
      if (($job == "") && ($logon == "") && ($script == "")) {
         tws_warning("For Job alerts, one of the following criteria must be specified: 'Job', 'Logon', or 'Script'");
         tws_dyer('', '', 'back');
      }
// Jobstream Alert must have jobstream set
   } elseif (tws_event_type($event_num,"jobstream")) {
      if ($jobstream == "") {
         tws_warning("For Jobstream alerts, 'jobstream' must be specified.");
         tws_dyer('', '', 'back');
      }
// Severity based alert must have severity set
   } elseif ($event_num == 0) {
      if ($severity == "") {
         tws_warning("For Severity alerts, 'severity' must be specified.");
         tws_dyer('', '', 'back');
      }
   }

// If recipient is set, it must contain a '@'
   if ($filer_type=='basic' && trim($recipient)!='') {
      if (strpos($recipient,"@") === FALSE) {
         tws_warning("Invalid email address: '$recipient'");
         tws_dyer('', '', 'back');
      } else {
         $alert_type="'EMAIL'";
      }
// If recipient is not set, then command must be set
   } elseif ($filer_type=='expert' && trim($command)!='') {
      $alert_type="'COMMAND'";
   } else {
      tws_warning("Uncomplete alert definition. 'Recipient' or 'command' must be set.");
      tws_dyer('', '', 'back');
   }

// Now, set NULL values for any blank (but valid) fields
   if ($severity == "") {
      $severity="NULL";
   } else {
      $severity="$severity";
   }
   if ($workstation == "") {
      $workstation="NULL";
   } else {
      $workstation="'$workstation'";
   }
   if ($jobstream == "") {
      $jobstream="NULL";
   } else {
      $jobstream="'$jobstream'";
   }
   if ($job_workstation == "") {
      $job_workstation="NULL";
   } else {
      $job_workstation="'$job_workstation'";
   }
   if ($job == "") {
      $job="NULL";
   } else {
      $job="'$job'";
   }
   if ($logon == "") {
      $logon="NULL";
   } else {
      $logon="'$logon'";
   }
   if ($script == "") {
      $script="NULL";
   } else {
      $script="'$script'";
   }
   if ($subject!='') {
      $twa_meta.='<EMAIL_SUBJ>'.htmlspecialchars($subject).'</EMAIL_SUBJ>';
   }
   if ($twa_meta!='') {
      $description.='<!--TWA_METADATA--'.$twa_meta.'--TWA_METADATA-->';
   }
   if ($description == "") {
      $description="NULL";
   } else {
      $description="'".db_string($webadmin_db, $description)."'";
   }
   if ($recipient == "") {
      $recipient="NULL";
   } else {
      $recipient="'$recipient'";
   }
   if ($email_text == "") {
      $email_text="NULL";
   } else {
      $email_text="'".db_string($webadmin_db, $email_text)."'";
   }
   if ($command == "") {
      $command="NULL";
   } else {
      $command="'".db_string($webadmin_db, $command)."'";
   }

   $event_num="$event_num";

   db_connect($webadmin_db,DB_PERSISTENT) or tws_dyer("Cannot connect to database");
   $schema=$webadmin_db['schema'];

   if( $modify=="yes" ){
      $query = "UPDATE $schema.alerts SET event_num=$event_num, severity=$severity, workstation=$workstation, jobstream=$jobstream, job_workstation=$job_workstation, job=$job, logon=$logon, script=$script, alert_type=$alert_type, recipient=$recipient, email_text=$email_text, command=$command, description=$description WHERE alert_id=$alert_id";
   } else {
      $query = "INSERT into $schema.alerts (alert_id,event_num,severity,workstation,jobstream,job_workstation,job,logon,script,alert_type,recipient,email_text,command,description) VALUES ((select max(alert_id)+1 from $schema.alerts),$event_num,$severity,$workstation,$jobstream,$job_workstation,$job,$logon,$script,$alert_type,$recipient,$email_text,$command,$description)";
   }

   db_query($webadmin_db,$query) or tws_dyer("Update of alerts table failed. Unable to complete request.");
   if (isset($webadmin_db['allow_persistent']) && tws_yesno($webadmin_db['allow_persistent'])=='NO')
      db_commit($webadmin_db) or tws_dyer("Unable to COMMIT request.");

   echo "<script language=\"Javascript\">\n";
   echo "window.location.replace(\"tws_alert_configuration.php\");\n";
   echo "</script>\n";
?>
</body>
</html>
