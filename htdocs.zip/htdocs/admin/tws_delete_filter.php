<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Delete Filter</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<h1>Delete Filter</h1>
<br><br>
<h3>Confirm Filter Delete:</h3>

<?php
   tws_import_request_variables("GP","rqst_");

   $filename=tws_gpc_get($rqst_filename, 'tws_file');
   $filename = urldecode($filename);
   $filename = basename($filename);

   if (!isset($filename)) {
      tws_warning("No filter selected");
      tws_dyer();
   }
   echo "<form method=\"post\" action=\"tws_delete_filter_exec.php\">\n";;
   echo "&nbsp;&nbsp;&nbsp;&nbsp;<b>".htmlspecialchars($filename)."</b> &nbsp;&nbsp;\n";

   echo "<input type=\"hidden\" name=\"filename\" value=\"".htmlspecialchars($filename)."\">\n";
   if (isset($rqst_for_all) && ($rqst_for_all == "YES")) {
      echo "<input type=\"hidden\" name=\"for_all\" value=\"YES\">\n";
      echo "from <b>all_users</b>\n";
   } else {
      if (isset($rqst_user)) {
         echo "<input type=\"hidden\" name=\"user\" value=\"".htmlspecialchars($rqst_user)."\">\n";
         echo "from <b>".htmlspecialchars($rqst_user)."</b>";
      } else {
         echo "<input type=\"hidden\" name=\"user\" value=\"".tws_profile('auth_user_name')."\">\n";
         echo "from <b>".tws_profile('auth_user_name')."</b>";
      }
   }
   tws_print_synchro_token();  // synchro_token
?>
<br><br><br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" value="Delete" name="action">&nbsp;&nbsp;
<input type="button" value="Cancel" onclick="window.location.replace('tws_filter_administration.php');">
</form>
</body>
</html>
