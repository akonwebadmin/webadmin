<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
   tws_profile('opener', basename($_SERVER['SCRIPT_NAME']) );
?>
<html>
<head>
<title>IWS Mailbox Files</title>
<?php
   $__keypress_handler=TRUE;
   tws_adminstylesheet(); ?>
</head>
<body>
<?php
   tws_set_window_title();
   tws_print_head('IWS Mailbox Files', 'tws_msg_files_help.php', '../');

   $catcmd=isset($tws_config['cat']) ? $tws_config['cat'] : ($tws_config['host_os']!='win32' ? "/bin/cat" : "$tws_config[maestro_dir]/webadmin/bin/type");

   $file_num=0;

// Process maestro_dir/*.msg files
   $dp=opendir("$maestro_dir");
   while ($filename=readdir($dp)) {
      if (substr($filename,-4) == ".msg") {
         $file_num++;
         $file[$file_num]=$filename;
         $file_size[$file_num]=filesize("$maestro_dir/$filename");

         if (tws_yesno($tws_config['virtual_hosts'],TRUE,FALSE)) {
            $stdout=$stderr=FALSE; //manuall tws_popen mode
            $cmd=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), "$catcmd", "$maestro_dir/$filename");
            $pipes = tws_popen($cmd, $ec, $stdout, $stderr);
            $fp = @$pipes[1];
         } else {
            $fp = fopen("$maestro_dir/$filename","rb");
         }

         if (!$fp) {
            $max_size[$file_num]="?";
         } else {
            $contents=fread($fp,20);

            if (tws_yesno($tws_config['virtual_hosts'],TRUE,FALSE)) {
               tws_pclose($pipes);
            } else {
               fclose($fp);
            }

            $contents_array=unpack("L*",$contents);
            $max_size[$file_num]=$contents_array[5];
         }
      }
   }

   closedir($dp);

// Process maestro_dir/network/*.msg files (only for IWS 8.2+)
// Check for existence of maestro_dir/network directory first
   if (is_dir("$maestro_dir/network")) {
      $dp=opendir("$maestro_dir/network");
      while ($filename=readdir($dp)) {
         if (substr($filename,-4) == ".msg") {
            $file_num++;
            $file[$file_num]="network/$filename";
            $file_size[$file_num]=filesize("$maestro_dir/network/$filename");

            if (tws_yesno($tws_config['virtual_hosts'],TRUE,FALSE)) {
               $stdout=$stderr=FALSE; //manuall tws_popen mode
               $cmd=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), $catcmd, "$maestro_dir/network/$filename");
               $pipes = tws_popen($cmd, $ec, $stdout, $stderr);
               $fp = @$pipes[1];
            } else {
               $fp = fopen("$maestro_dir/network/$filename","rb");
            }

            if (!$fp) {
               $max_size[$file_num]="?";
            } else {
               $contents=fread($fp,20);

               if (tws_yesno($tws_config['virtual_hosts'],TRUE,FALSE)) {
                  tws_pclose($pipes);
               } else {
                  fclose($fp);
               }

               $contents_array=unpack("L*",$contents);
               $max_size[$file_num]=$contents_array[5];
            }
         }
      }
      closedir($dp);
   }

// Process maestro_dir/pobox/*.msg files
   $dp=opendir("$maestro_dir/pobox");
   while ($filename=readdir($dp)) {
      if (substr($filename,-4) == ".msg") {
         $file_num++;
         $file[$file_num]="pobox/$filename";
         $file_size[$file_num]=filesize("$maestro_dir/pobox/$filename");

         if (tws_yesno($tws_config['virtual_hosts'],TRUE,FALSE)) {
            $stdout=$stderr=FALSE; //manuall tws_popen mode
            $cmd=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), $catcmd, "$maestro_dir/pobox/$filename");
            $pipes = tws_popen($cmd, $ec, $stdout, $stderr);
            $fp = @$pipes[1];
         } else {
            $fp = fopen("$maestro_dir/pobox/$filename","rb");
         }

         if (!$fp) {
            $max_size[$file_num]="?";
         } else {
            $contents=fread($fp,20);

            if (tws_yesno($tws_config['virtual_hosts'],TRUE,FALSE)) {
               tws_pclose($pipes);
            } else {
               fclose($fp);
            }

            $contents_array=unpack("L*",$contents);
            $max_size[$file_num]=$contents_array[5];
         }
      }
   }
   closedir($dp);

   echo "<form method=post action=\"tws_msg_files_action.php\">\n";
   echo "<table class=wireframe cellspacing=0 cellpadding=4 cols=3>\n";
   echo "<tr class=header>\n";
   echo "<th class=wireframe>&nbsp;</th>\n";
   echo "<th class=wireframe>Mailbox File</th>\n";
   echo "<th class=wireframe>Size</th>\n";
   echo "<th class=wireframe>Max Size</th>\n";
   echo "</tr>\n";

   for ($i=1; $i<=$file_num; $i++) {
      echo "<tr class=standard>\n";
      echo "<td class=wireframe><input type=\"checkbox\" name=\"selection[]\" value=\"$file[$i]\"></td>\n";
      echo "<td class=wireframe>$file[$i]</td>\n";
      if ($file_size[$i] <= 48) {
         echo "<td class=wireframe>";
      } elseif ($max_size[$i] == "?") {
         echo "<td class=warning>";
      } elseif (($file_size[$i] / $max_size[$i]) > .75) {
         echo "<td class=error>";
      } else {
         echo "<td class=warning>";
      }
      echo "$file_size[$i]</td>\n";
      if ($max_size[$i] == "?") {
         echo "<td class=warning>";
      } else {
         echo "<td class=wireframe>";
      }
      echo "$max_size[$i]</td>\n";
      echo "</tr>\n";
   }
?>

</table>
<br>

<input type=submit name=action value="Change Max Size">
   <? tws_print_synchro_token();     // synchro_token ?>
</form>
</body>
</html>
