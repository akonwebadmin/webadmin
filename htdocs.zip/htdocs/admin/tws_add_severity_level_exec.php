<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add Event Severity Level</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>
<h1>Edit Event Severity Levels</h1>
<br>
<?php
   tws_import_request_variables("P","rqst_");

   $severity_label=tws_gpc_get($rqst_severity_label, 'tws_alfanum');
   $severity_color=tws_gpc_get($rqst_color, 'tws_name');
      tws_check_synchro_token();  //    synchro_token

   if(empty($severity_label)){
      tws_warning("Severity Label can't be empty");
      tws_dyer('', '', "tws_edit_severity_levels.php");
   }

   include("$severities_file");
   $severity[]=$severity_label;
   $color[]=$severity_color;

   tws_save_severities($severity,$color);

   echo "<script language=\"Javascript\">\n";
   echo "window.location.replace(\"tws_edit_severity_levels.php\");\n";
   echo "</script>\n";
?>
</body>
</html>
