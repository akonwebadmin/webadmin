<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Delete IWS/WebAdmin User</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<?php tws_print_head('Delete IWS/WebAdmin User','','../'); ?>
<br><br>
<?php

   if (!isset($selection) || count($selection) == 0)  {
      tws_dyer("No user selected", "", "tws_user_administration.php");
   }

   echo "<form method='post' action='tws_delete_user_exec.php'>\n";
   echo "<h3>Confirm User Delete: </h3>\n";

foreach($selection as $i=>$val) {

   // check if Apache User
   $find=0;
   $authusers="$base_inst_dir/httpd/conf/authusers";
   $authgroups="$base_inst_dir/httpd/conf/authgroups";

   $fp=fopen($authusers,"r") or tws_dyer("Can't open file '$authusers'", '', "tws_user_administration.php");
   if ($fp) {
      while ($buffer=fgets($fp,4096)) {
         $username=strtok($buffer,":");
         if($username == $selection[$i]) {
            $find=1;
            break;
         }
      }
      fclose($fp);
   }

   // or in authgroups
   $fp=fopen($authgroups,"r") or tws_err("Can't open file '$authgroups'");
   if ($fp) {
      while ($buffer=fgets($fp,4096)) {
         $group=strtok($buffer,":");
         $members=trim(strtok(":"));
         $members=explode(" ",$members);
         foreach ( $members as $member) {
           if ($member == $selection[$i])
            $find=1;
            break;
         }
      }
      fclose($fp);
   }

   if($find==0) {
      echo "User '<b>".htmlspecialchars($selection[$i])."</b>' was imported from the IWS security user sections. It is impossible to remove the account.<br>";
   }
   else {
      echo "<b>".htmlspecialchars($selection[$i])."</b></br>\n";
      echo "<input type='hidden' name='username[]' value=\"".htmlspecialchars($selection[$i])."\">\n";
   }
}
   tws_print_synchro_token();     // synchro_token
   echo "<br>
      <input type='submit' value='Delete' name='action'>
      <input type='button' name='action' value='Cancel' onClick=\"window.location.replace('tws_user_administration.php');\">
      </form>";
?>
</body>
</html>
