<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t"); 
?>
<html>
<head>
<title>IWS/WebAdmin License Entry</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<?php
   tws_import_request_variables("P","rqst_");
   $license_key_name=$rqst_license_key_name;

   switch ($license_key_name) {

// General IWS/WebAdmin license
      case "IWS/WebAdmin" :
         $license_key_file="$maestro_dir/webadmin/etc/license.key";
         break;

// zli_module license (netplans)
      case "IWS/WebAdmin Netplan Module" :
         $license_key_file="$maestro_dir/webadmin/etc/zli_license.key";
         break;

      default :
         tws_dyer("Unknown license key name", "license key name='$license_key_name'");
         break;
   } //switch
?>

<h1><?=$license_key_name?> License Administration</h1>
<br><br>
<?php
clearstatcache();
if (is_file("$license_key_file")) {
   if ($license_key_fp = fopen("$license_key_file","r")) {
      $license_key = trim(fgets($license_key_fp,4096));
      fclose($license_key_fp);

      echo "<p class=\"warning\"><font color=\"#800000\">Warning: A license key for $license_key_name already exists.  Entering a new license key will overwrite the current key.</font></p>\n";
   }
}
?>
<form method="post" name="license_data" action="tws_webadmin_submit_license.php">
<table border=0 cellspacing=0>
<tr>
<td class=standard width=180>
&nbsp;&nbsp;Enter License Key:
</td>
<td class=standard>
<input type="hidden" name="license_key_name" value="<?=$license_key_name?>"/>
<input type="text" name="license_key" size="60" maxlength="60"/>
</td>
</tr>
</table>
<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Submit" name="action">
   <? tws_print_synchro_token();     // synchro_token ?>
</form>
</body>
</html>
