<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_profile('opener', basename($_SERVER['SCRIPT_NAME']) );
   tws_doctype("t");
?>
<html>
<head>
<title>IWS/WebAdmin Configuration</title>
<?php tws_adminstylesheet();?>
<script type="text/javascript">
   var ignore_err_tooltip = true;   // don't show err_tooltips
</script>
<style type="text/css">
p.warning {
   font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
   font-size: 10pt;
   font-weight: bold;
}

</style>
</head>
<body>
<?php
   tws_print_head("IWS/WebAdmin Environment Configuration", '', '../');
   tws_nossl_warning();

   $fname = "$maestro_dir/webadmin/etc/tws_config.php";
   if($tws_config['host_os']=='win32')
      $tmpl_fname = "$base_inst_dir/etc/templates/tws_config-win.php";
   else
      $tmpl_fname = "$base_inst_dir/etc/templates/tws_config-unix.php";

   if(!file_exists($tmpl_fname))
      tws_dyer("template file '$tmpl_fname' not exist", '', 'admin_home.php');

   include $tmpl_fname;
   include $fname;

   $tws_config = array_merge($tws_config_tmpl, $tws_config);
   ?>

<script>
$(function() {
   $('#tabs').tabs();
   $('#tabs').css('background-color','inherit');
   $('#tabs').css('border','none 0px');
});
</script>
<div id='tabs'>
   <ul>
      <li><a href='#db'>Database Configuration</a></li>
      <li><a href='#main'>IWS/WebAdmin Configuration</a></li>
   </ul>

<form method='post' action='tws_save_conf.php'>

<!-- Web/Admin Configuration -->

   <div id='main'>
<?
/*    TZ removed
$tz = array();
foreach($tws_types['TIMEZONE'] as $key=>$val){
   if($key == 'NULL') $key = '';
   $tz[$val] = $key;
}
'tz' => array('title'=>'timezone', 'comment'=>"server timezone", 'values'=>$tz),
*/

// All options needed are here only
// can contain: title, values, comment
$options = array(
'webadmin_log_dir' => array('title'=> 'webadmin_log dir', 'class'=>'tws_file'),
'webadmin_log_file' => array('title'=> 'webadmin_error.log file', 'class'=>'tws_file'),
'webadmin_log_file_max_size' => array('title'=> 'webadmin_error.log max size','comment'=>""),
'webadmin_audit_log_file' => array('title'=> 'webadmin_audit.log file', 'class'=>'tws_file'),
'webadmin_audit_log_file_max_size' => array('title'=> 'webadmin_audit.log max size', 'comment'=>""),

/*    New HWF make it itself
'apache_access_log_file' => array('title'=> 'apache_access.log file', 'class'=>'tws_file'),
'apache_access_log_max_size' => array('title'=> 'apache_access.log max size', 'comment'=>""),
'apache_error_log_file' => array('title'=> 'apache_error.log file', 'class'=>'tws_file'),
'apache_error_log_max_size' => array('title'=> 'apache_error.log max size', 'comment'=>""),
*/
'jobhist_cleanup' => array('title'=> 'Delete Records in Job History Table older than', 'comment'=>"days", 'class'=>'tws_num'),
'events_cleanup' =>  array('title'=> 'Delete Records in Events Table older than', 'comment'=>"days", 'class'=>'tws_num'),

'webadmin_log_file_max_age' => array('title'=> 'trace_logs max age', 'comment'=>"hours", 'class'=>'tws_num'),
'pagesize' => array('title'=> 'page size', 'comment'=>"Number of resultant rows on one page. <br>Set 0 to disable paging.", 'class'=>'tws_num'),
'sudo_mode' => array('title'=> 'sudo mode', 'values'=>array('Enabled'=>'os,apache,ldap', 'OS authentication only'=>'os'), 'comment'=>"Select the mode of using sudo when calling external commands"),
'secure_notes' => array('title'=> 'secure notes', 'values'=>array('ON', 'OFF'), 'comment'=>"ON means R/W access for owners and adminisrators; <br>OFF means R/W access for every user"),
'secure_drafts' => array('title'=> 'secure drafts', 'values'=>array('ON', 'OFF'), 'comment'=>""),
'tws_secfile' => array('title'=> 'tws_secfile', 'values'=>array('ON', 'OFF'), 'comment'=>"Access to IWS objects along the IWS securities"),
'conn_passwords_plain' => array('title'=> 'DB passwords in plain text', 'values'=>array('OFF', 'ON'), 'comment'=>"ON - passwords in db_config.php in plain text, <br>OFF - crypted"),
'password_strong' => array('title'=>'user passwords strength', 'values'=>array('OFF', 'PCI', 'MS'), 'comment'=>"see note 1"),
);

$file_size = array('Disabled'=>'0', 'No limit'=>'-1','0.5M'=>'0.5M','1M'=>'1M','5M'=>'5M','10M'=>'10M','20M'=>'20M','30M'=>'30M','40M'=>'40M','50M'=>'50M');
?>
   <table class='wireframe' id='sortable'>
   <tr class='header'><th class='wireframe'> Name </th><th class='wireframe'> Value </th><th class='wireframe'> Comment </th>
   </tr>
   <?
      foreach($options as $name=>$val) {
         if(isset($val['title'])) $title = $val['title'];
         else $title = $name;
         if(isset($val['comment'])) $comment = $val['comment'];
         else $comment = '';
         $value = $tws_config[$name];
         if($value === true) $value = "ON";
         elseif($value === false) $value = "OFF";
         $size = strlen($value);
         if($size < 25) $size = 25;
         else $size += 2;
         if(strpos($name, '_max_size')!==false){
            $val['values'] = $file_size;
            if (!isset($value) || $value=='') $value = '0';
            if ($value != '0' && $value != '-1') {
               $value = tws_max_size_to_bytes($value) / pow(1024, 2);
               $value = round($value,1);
               $value .= 'M';
            }
            if(!in_array($value, $file_size))
               $val['values'][$value] = $value;
         }
         if (!empty($val['class'])) $class=$val['class']; else $class='';
         if (!isset($val['values']) ) { ?>
            <tr><td><b><?=$title?></b></td><td><input type="text" name="config[<?=$name?>]" class="<?=$class?>" value="<?=$value?>" size="<?=$size?>" /></td><td><?=$comment?></td></tr>
         <? } else { ?>
            <tr><td><b><?=$title?></b></td><td><select name="config[<?=$name?>]">
            <? foreach ($val['values'] as $label=>$values) { ?>
               <option value="<?=$values?>" <? if($values==$value) echo " selected";?> ><?=(is_string($label)? $label : $values)?></option>
            <? } ?>
         </select></td>
         <td style="word-wrap:break-word;"><?=$comment?></td></tr>
         <? }
      }
   ?>
   </table>
<textarea name="main_comments" cols="110" rows="15" readonly="readonly" style="font-size:small;">
Configuration notes:
--------------------
1. Password Strength:
Payment Card Industry (PCI) Requirements:
Require a minimum password length of at least seven characters.
Use passwords containing both numeric and alphabetic characters.

MS Windows Server Requirements:
Is at least seven characters long.
Passwords must contain characters from three of the following four categories:
 - Uppercase characters of European languages (A through Z)
 - Lowercase characters of European languages (a through z)
 - Base 10 digits (0 through 9)
 - Nonalphanumeric characters: ~!@#$%^&*_-+=`|\(){}[]:;\"'<>,.?/",
</textarea><br>
<p class='warning'>IWS/Webadmin configuration is saved in '<?=$fname?>'</p>
</div>

<!-- DATABASE CONFIGURATION -->

   <div id='db'>
      <table class="standard" border=1>
         <tr><td valign="top">
      <table class="standard" >
         <tr><td colspan=3><h3>IWS database connection configuration</h3></td></tr>
         <tr><td><b>Type:</b></td><td><select name="composer_db[type]">
            <option value="db2" <? if($composer_db['type']=='db2') echo ' selected';?> >IBM DB2</option>
            <option value="oracle" <? if($composer_db['type']=='oracle') echo ' selected';?> >Oracle</option>
            </select></td><td>Supported values: oracle, db2</td></tr>
         <tr><td><b>Name:</b></td><td><input type="text" name="composer_db[name]" value="<?=$composer_db['name']?>"/></td><td>Name of the database used for IWS, e.g. TWS_DB</td> </tr>
         <tr><td><b>Host:</b></td><td><input type="text" name="composer_db[host]" value="<?=$composer_db['host']?>"/></td><td>DB client host name <i>(see note 1)</i></td></tr>
         <tr><td><b>Port:</b></td><td><input type="text" name="composer_db[port]" class="tws_num" value="<?=$composer_db['port']?>"/></td><td>DB client port <i>(see note 1)</i></td></tr>
         <tr><td><b>User:</b></td><td><input type="text" name="composer_db[user]" value="<?=$composer_db['user']?>"/></td><td>IWS database account user name</td></tr>
         <tr><td><b>Password:</b></td><td><input type="password" autocomplete="off" name="composer_db[pass]" value="<?=$composer_db['pass']?>"/></td><td>IWS database account password <i>(see note 2)</i></td></tr>
         <tr><td><b>DB Schema:</b></td><td><input type="text" name="composer_db[schema]" value="<?=$composer_db['schema']?>"/></td>
             <td>Schema name. Default values: "MDL" for DB2, user name for ORACLE</td></tr>
         <tr><td><b>Plan Schema:</b></td><td><input type="text" name="composer_db[pln_schema]" value="<?=$composer_db['pln_schema']?>"/></td>
            <td>Schema name. Default values: "PLN" for DB2, user name for ORACLE</td></tr>
         <tr><td><b>Persistent:</b></td><td><select name="composer_db[allow_persistent]">
            <option value="ON" <? if($composer_db['allow_persistent']=='ON') echo ' selected';?> >On</option>
            <option value="OFF" <? if($composer_db['allow_persistent']=='OFF') echo ' selected';?> >Off</option>
            </select></td><td>Allow persistent connection to DB</td></tr>

      </table>
      </td><td valign="top">
      <table class="standard" >
         <tr><td colspan=3><h3>IWS/WebAdmin database connection configuration</h3></td>  </tr>
         <tr><td><b>Type:</b></td><td><select name="webadmin_db[type]">
            <option value="db2" <? if($webadmin_db['type']=='db2') echo ' selected';?> >IBM DB2</option>
            <option value="oracle" <? if($webadmin_db['type']=='oracle') echo ' selected';?> >Oracle</option>
            </select></td> <td>Supported values: oracle, db2, pgsql</td>  </tr>
         <tr><td><b>Name:</b></td><td><input type="text" name="webadmin_db[name]" value="<?=$webadmin_db['name']?>"/></td> <td>Name of the database used for IWS/WebAdmin tables e.g. WEBADMIN</td> </tr>
         <tr><td><b>Host:</b></td><td><input type="text" name="webadmin_db[host]" value="<?=$webadmin_db['host']?>"/></td> <td>DB client host name <i>(see note 1)</i></td> </tr>
         <tr><td><b>Port:</b></td><td><input type="text" name="webadmin_db[port]" class="tws_num" value="<?=$webadmin_db['port']?>"/></td> <td>DB client port <i>(see note 1)</i></td> </tr>
         <tr><td><b>User:</b></td><td><input type="text" name="webadmin_db[user]" value="<?=$webadmin_db['user']?>"/></td> <td>Webadmin database account user name</td> </tr>
         <tr><td><b>Password:</b></td><td><input type="password" autocomplete="off" name="webadmin_db[pass]" value="<?=$webadmin_db['pass']?>"/></td> <td>Webadmin database account password <i>(see note 2)</i></td> </tr>
         <tr><td><b>Schema:</b></td><td><input type="text" name="webadmin_db[schema]" value="<?=$webadmin_db['schema']?>"/></td> <td>Schema name. Default values: "WEBADMIN" for DB2, user name for ORACLE</td> </tr>
         <tr><td><b>Persistent:</b></td><td><select name="webadmin_db[allow_persistent]">
            <option value="ON" <? if($webadmin_db['allow_persistent']=='ON') echo ' selected';?> >On</option>
            <option value="OFF" <? if($webadmin_db['allow_persistent']=='OFF') echo ' selected';?> >Off</option>
            </select></td><td>Allow persistent connection to DB</td></tr>
      </table>
         </td></tr>
      </table>


<textarea name="comment" cols="110" rows="15" readonly="readonly" style="font-size:small;">
Configuration notes:
--------------------
1. Cataloged connections (oracle, db2)

Defining parameters 'host' and 'port' is not the best way for using to configure the DB connection.
Better is to configure your database client so it knows connection parameters by given *database name*.
In case of DB2 the database must be _cataloged_, in case of Oracle the databse connection is defined in the tnsnames.ora file.
Set the 'host' and 'port' items as empty strings in case you want to use cataloged connection.


2. Encrypt Text Passwords

The passwords will be encrypted if 'conn_passwords_plain' option is set to FALSE.
</textarea><br>
<p class='warning'>Database configuration is saved in '<?=$tws_config['maestro_dir']."/webadmin/etc/db_config.php"?>'</p>
   </div>

<p>
<input type="submit" name="action" value="Save"/>
</p>
<? tws_print_synchro_token();  // synchro_token
?>
</form>
</body>
</html>
