<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');
?>
<html>
<head>
   <title>IWS Edit Severity Levels Help</title>
   <?php tws_adminstylesheet(); ?>
</head>
<body class=help>
<?php
   tws_set_window_title();
   $path = '../';
   include $path.'tws_help_topbar.php';
?>
<h1 class=help>IWS Edit Severity Levels Help</h1>
<p>The IWS Edit Severity Levels page is used to add, modify, and delete severity levels. The default severity levels are:
<ul>
  <li><strong>Info</strong></li>
  <li><strong>Warning</strong></li>
  <li><strong>Error</strong></li>
  <li><strong>Severe</strong></li>
  <li><strong>Critical</strong></li>
</ul>
<h2 class=help>Actions</h2>
<p><strong>Add</strong> : Add a new severity level
<p><strong>Modify</strong> : Modify the selected severity level
<p><strong>Delete</strong> : Delete the selected severity level
</body>
</html>
