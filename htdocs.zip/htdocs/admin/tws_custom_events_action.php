<?php
//   HORIZONT Software GmbH, Munich
//

   require_once("tws_functions.php");
   tws_import_request_variables("P","rqst_");

   $action=$rqst_action;

   switch ($action) {
// TODO:     case "Modify":
     case "Add":
       include("tws_add_custom_event.php");
       break;
     case "Delete":
       include("tws_delete_custom_event.php");
       break;
   }
?>