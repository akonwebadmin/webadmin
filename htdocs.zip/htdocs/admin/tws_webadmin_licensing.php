<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
   tws_profile('opener', basename($_SERVER['SCRIPT_NAME']) );
?>
<html>
<head>
<title>IWS/WebAdmin License Administration</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<h1>IWS/WebAdmin License Administration</h1>
<br>

<?php
   tws_nossl_warning();

   clearstatcache();
   $license_status=-1;
   if (!is_file("$maestro_dir/webadmin/etc/license.key")) {
      $license_key="Unlicensed";
   } elseif (!$license_key_fp = fopen("$maestro_dir/webadmin/etc/license.key","r")) {
      $license_key="Unlicensed";
   } else {
      $license_key = trim(fgets($license_key_fp,4096));

      fclose($license_key_fp);

      $printlic_command=new hwi_cmd("$base_inst_dir/bin/printlic", $license_key);

      $stdout=array();
      tws_popen($printlic_command,$ec,$stdout,$stdout) or tws_dyer("Unable to read license key", $stdout);
      foreach ($stdout as $buffer){
         if (substr($buffer,0,10) == "System ID:") {
            $license_system_id=trim(substr($buffer,11));
         } elseif (substr($buffer,0,10) == "Max Nodes:") {
            $license_node_count=trim(substr($buffer,11));
         } elseif (substr($buffer,0,16) == "Expiration Date:") {
            $license_expiration_date=trim(substr($buffer,17));
         }
      }

      $license_status=0;
      if (!is_numeric($license_expiration_date)) {
         $license_status=1;
         $license_system_id="???";
         $license_node_count="???";
         $license_expiration_date="???";
      } elseif ($license_expiration_date == "99999999") {
         $license_expiration_date="permanent";
      }
   }

   if (($get_system_id=tws_get_sysid_command())===FALSE) {
      $system_id="UNKNOWN";
   } else {
      $stdout=array();
      tws_popen($get_system_id,$ec,$stdout,$stdout) or tws_dyer("Unable to get system ID", $stdout);
      $system_id=trim($stdout[0]);
      if ($host_os == "win32") {
         $tok=strtok($system_id,":");
         $tok=trim(strtok("\n"));
         $system_id=$tok;
         $system_id=str_replace("-",NULL,$system_id);
      }
      $length=strlen($system_id);
      if (($length < 4) || ($length > 40)) {
         tws_error(array('command'=>$get_system_id, 'stdout'=>$stdout, 'tws_config'=>$tws_config), "Getting system ID failed.");
         $system_id="UNKNOWN";
      }
   }

// Get the nodes count

// IMPORTANT!!! Do not call this command with "conman_args". Reason: It is called as the MAESTRO user, the parameters, credentials
// stored in tws_config['conman_args'] are designed for commands executed by IWS/WebAdmin users. This is not the case. This is
// an auxiliar command running at the backgorund. MAESTRO user should have its IWS credentials (useropts) in its home directory
   $node_count_command=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), "$maestro_dir/bin/conman", "-gui", "sc @!@", hwi_cmd::operator('2>&1',FALSE));
   $node_type_counts=array();
   $licensed_types=array('MASTER', 'S-AGENT', 'FTA');
   $other_types=array('X-AGENT', 'AGENT','MANAGER','BROKER','POOL','REM-ENG');
   foreach (array_merge($licensed_types, $other_types) as $type) $node_type_counts[$type]=0;
   $stdout=Array();
   tws_popen($node_count_command,$ec,$stdout,$stdout) or tws_dyer("Unable to get node count", $stdout);
   foreach ($stdout as $buffer){
      if (substr($buffer,0,2) == "^d") {
         $node_type=trim(substr($buffer,25,16));
         $node_type_alias=$node_type;
         foreach (array_merge($licensed_types,$other_types) as $type) {
            if (preg_match('/'.$type.'/', $node_type)) {
               $node_type_alias=$type;
               break;
            }
         }
         if (!isset($node_type_counts[$node_type_alias])) $node_type_counts[$node_type_alias]=0;
         $node_type_counts[$node_type_alias]++;
      }
   }
   $licensed_node_count=0;
   $licensed_nodes_string='Workstation types requiring license:';
   $licensefree_nodes_string='Other workstation types:';
   foreach ($node_type_counts as $type=>$count) {
      if (in_array($type, $licensed_types)) {
         $licensed_node_count+=$count;
         $licensed_nodes_string.="\n".str_pad($type.' ',20,'.').' '.$node_type_counts[$type];
      } else {
         $licensefree_nodes_string.="\n".str_pad($type.' ',20,'.').' '.$node_type_counts[$type];
      }
   }
   $request_string="Request string: $system_id $licensed_node_count\n\n$licensed_nodes_string\n\n$licensefree_nodes_string";

// zli_module license check in case that zli_module is present
   if (@tws_zli_module_check()){
      $zli_license_status=-1;
      if (!is_file("$maestro_dir/webadmin/etc/zli_license.key")) {
         $zli_license_key="Unlicensed";
      } elseif (!$zli_license_key_fp = fopen("$maestro_dir/webadmin/etc/zli_license.key","r")) {
         $zli_license_key="Unlicensed";
      } else {
         $zli_license_key = trim(fgets($zli_license_key_fp,4096));

         fclose($zli_license_key_fp);

         $printlic_command=new hwi_cmd("$base_inst_dir/bin/printlic", $zli_license_key);
         $stdout=array();
         tws_popen($printlic_command,$ec,$stdout,$stdout) or tws_dyer("Unable to read zli license key", $stdout);
         foreach ($stdout as $buffer){
            if (substr($buffer,0,10) == "System ID:") {
               $zli_license_system_id=trim(substr($buffer,11));
            } elseif (substr($buffer,0,10) == "Max Nodes:") {
               $zli_license_node_count=trim(substr($buffer,11));
            } elseif (substr($buffer,0,16) == "Expiration Date:") {
               $zli_license_expiration_date=trim(substr($buffer,17));
            }
         }

         $zli_license_status=0;
         if (!is_numeric($zli_license_expiration_date)) {
            $zli_license_status=1;
            $zli_license_system_id="???";
            $zli_license_node_count="???";
            $zli_license_expiration_date="???";
         } elseif ($zli_license_expiration_date == "99999999") {
            $zli_license_expiration_date="permanent";
         }
      }
   }

   // neplan yfiles check
   $ylicver = trim(file_get_contents("$base_inst_dir/httpd/htdocs/twazy/version.info"));
   $ylicfile =file_get_contents("$base_inst_dir/httpd/htdocs/twazy/lib$ylicver/license.js");
   $ymatches = array();
   $ym = preg_match('/"subscription":\s*"\d{2}\/\d{2}\/\d{4}/',$ylicfile, $ymatches);
   if($ym=== 1 && !empty($ymatches)){
       $ylicexp = substr($ymatches[0], -10,10);
       $ylicdate = DateTime::createFromFormat('m/d/Y', $ylicexp);
       $ynow = new DateTime('NOW');
   } else {
       $ylicdate = '';
   }

?>

<h3>License Status</h3>
<table border=0 cellspacing=0>
<tr>
<td class=standard width=180>
&nbsp;&nbsp;<b>License Key:</b>
</td>
<td class=standard>
<?php echo htmlspecialchars($license_key); ?>
</td>
</tr>
<tr>
<td class=standard width=180>
&nbsp;&nbsp;<b>System ID:</b>
</td>
<td class=standard>
<?php
   if ($license_status == 0) {
      echo htmlspecialchars($license_system_id);
   }
?>
</td>
</tr>
<tr>
<td class=standard width=180>
&nbsp;&nbsp;<b>Node Limit:</b>
</td>
<td class=standard>
<?php
   if ($license_status == 0) {
      echo htmlspecialchars($license_node_count);
   }
?>
</td>
</tr>
<tr>
<td class=standard width=180>
&nbsp;&nbsp;<b>Expiration Date:</b>
</td>
<td class=standard>
<?php
    if ($license_status == 0) {
       if ($license_expiration_date == "99999999") {
          echo "permanent";
       } else {
          echo htmlspecialchars($license_expiration_date);
       }
    }
?>
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td>
<form method="post" name="enter_license" action="tws_webadmin_enter_license.php">
   <input type="hidden" name="license_key_name" value="IWS/WebAdmin"/>
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Enter License Key" name="enter">
</form>
</td>
</tr>

<tr><td>&nbsp;</td></tr>
<form name="license_request">
<tr>
<td class=standard width=180>
<h3>License Request</h3>
</td>
</tr>
<tr>
<td class=standard width=180 style="vertical-align:top">
&nbsp;&nbsp;Generate Request String:<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" value="Generate" name="action" onClick="javascript:$('input[name=request_string]').hide();$('textarea[name=request_string]').show();">
</td>
<td class=standard style="vertical-align:top"><input type="text" name="request_string" size=40 maxlength=80 readonly><textarea name="request_string" style="display:none;font-family:courier;font-size:0.9em" rows="<?=substr_count($request_string,"\n")+1?>" cols="60" readonly="readonly"><?=htmlspecialchars($request_string)?></textarea></td>
</tr>
<tr><td>&nbsp;</td></tr>
</table>
</form>

<br>
<br>

<h3>Netplan JS/SVG Module License Status</h3>
<?php
if (empty($ylicdate)) {
    tws_error('License no found');
}

?>
	<table border=0 cellspacing=0>
		<tr>
		<td class="standard" width="180">&nbsp;&nbsp;<b>Expiration Date:</b></td>
		<td class="standard">unlimited</td>
		</tr>
	</table>

<br>
<br>

<?php
//print the zli_module license status
   if (@tws_zli_module_check()) {
?>
<h3>Netplan ActiveX Module License Status</h3>

<table border=0 cellspacing=0>
<tr>
   <td class="standard" width="180">&nbsp;&nbsp;<b>License Key:</b></td>
   <td class="standard"><?=htmlspecialchars($zli_license_key);?></td>
</tr>
<tr>
   <td class="standard" width="180">&nbsp;&nbsp;<b>System ID:</b></td>
   <td class="standard">
<?php
    if ($zli_license_status == 0) {
      echo htmlspecialchars($zli_license_system_id);
    }
?>
   </td>
</tr>
<tr>
   <td class="standard" width="180">&nbsp;&nbsp;<b>Node Limit:</b></td>
   <td class="standard">
<?php
    if ($zli_license_status == 0) {
      echo htmlspecialchars($zli_license_node_count);
    }
?>
   </td>
</tr>
<tr>
   <td class="standard" width="180">&nbsp;&nbsp;<b>Expiration Date:</b></td>
   <td class="standard">
<?php
    if ($zli_license_status == 0) {
      echo htmlspecialchars($zli_license_expiration_date);
    }
?>
   </td>
</tr>
<tr><td colspan="2">&nbsp;</td></tr>
<tr>
   <td colspan="2">
      <form method="post" name="enter_license" action="tws_webadmin_enter_license.php">
      <input type="hidden" name="license_key_name" value="IWS/WebAdmin Netplan Module"/>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Enter License Key" name="enter">
      </form>
   </td>
</tr>
<tr><td colspan="2">&nbsp;</td></tr>
<?php /*
<tr>
   <form name="zli_license_request">
   <td class="standard" colspan="2"><h3>License Request</h3></td>
</tr>
<tr>
   <td class="standard" width="180">&nbsp;&nbsp;Generate Request String:</td>
   <td class=standard><input type="text" name="zli_request_string" size=40 maxlength=80 readonly></td>
</tr>
<tr><td colspan="2">&nbsp;</td></tr>
<tr>
   <td class="standard" colspan="2">
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" value="Generate" name="action" onClick="document.zli_license_request.zli_request_string.value='<?php echo "$zli_request_string"; ?>'">
   </td>
</tr>
</form>
*/ ?>
</table>

<?php } ?>


</body>
</html>
