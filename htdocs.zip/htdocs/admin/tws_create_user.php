<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add IWS/WebAdmin User</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>
<?php
   tws_import_request_variables("P","rqst_");

   $username = tws_gpc_get($rqst_username, 'tws_alfanum\\tws_alfanum', '\\');

   if(strpos($username, '@')){
      list($u, $d) = explode('@', $username);
      $username = $d.'\\'.$u;
   }
   if( strpos($username, '\\')!==false){
      list($d, $u) = explode('\\', $username);
      if( ($pos=strpos($d, '.'))!==false )
         $d = substr($d,0,$pos);
      $username = $d.'\\'.$u;
   }

   $authusers="$base_inst_dir/httpd/conf/authusers";
   $fp=fopen($authusers,"r");
   if ($fp) {
      while ($buffer=fgets($fp,4096))
         $apachusers[] = strtok($buffer,":");
      fclose($fp);
   }
   if(in_array($username, $apachusers))
      tws_err("User '$username' is already defined");
   unset($apachusers);

   $description = tws_gpc_get($rqst_description);
   if(!empty($rqst_password)) {
      $password = tws_gpc_get($rqst_password);
      $confirm_password = tws_gpc_get($rqst_confirm_password);
   }
   else {
      $password = $confirm_password = rand (1000, 10000);
   }
   $group = tws_gpc_get($rqst_group, 'tws_alfanum');
   tws_check_synchro_token();     // synchro_token

   if (trim($username) == '' || strtolower($username) == 'groups' || strtolower($username) == 'all_users' )
      tws_dyer("Illegal user name '$username'", "", "back");

   if ($password!=$confirm_password) {
      echo "<p class=warning>Password fields do not match</p>\n";
      echo "<input type='button' value='Ok' name='Back' onClick='history.back()'>";
   }
   else {
      // create home directory
      if (!file_exists($webadmin_user_home_dir."/$username")) {
         tws_mkdir($webadmin_user_home_dir."/$username")===FALSE && tws_dyer("Cannnot create IWS/WebAdmin user '$username' home directory.", "", "tws_user_administration.php");
         tws_chmod($webadmin_user_home_dir."/$username", 0755)===FALSE && tws_err("Cannnot set up required permissions on IWS/WebAdmin user '$username' home directory.");
      }
      if (!file_exists($webadmin_user_home_dir."/$username".$user_setting_dir)) {
         tws_mkdir($webadmin_user_home_dir."/$username".$user_setting_dir)===FALSE && tws_dyer("Cannnot create '$username.$user_setting_dir' directory.", "", "tws_user_administration.php");
         tws_chmod($webadmin_user_home_dir."/$username".$user_setting_dir, 0755)===FALSE && tws_err("Cannnot set up required permissions on '$username$user_setting_dir' directory.");
      }

      $authusers="$base_inst_dir/httpd/conf/authusers";
      $bakauthusers=$authusers . ".bak";

      copy($authusers,$bakauthusers);

      if(!empty($tws_config['hwf_root']))
         $hwf_root = $tws_config['hwf_root'];
      else $hwf_root = $base_inst_dir;

      $command=new hwi_cmd($hwf_root."/httpd/bin/htpasswd", "-b", $authusers, $username, hwi_cmd::hidden($password), hwi_cmd::operator('2>&1',FALSE));
      if ($host_os == "win32")
         putenv("TEMP=$maestro_dir\\webadmin\\tmp");

      $stdout=array(); $ec='';
      tws_popen($command,$ec,$stdout,$stdout);
      $status=1;
      foreach ($stdout as $buffer) {
         if (substr($buffer,0,15) == "Adding password") {
            $status=0;
            break;
         }
      }

      if ($status==1 || $ec!=0) {
         copy($bakauthusers,$authusers);
         //delete user home directory created above
         tws_rmdir($webadmin_user_home_dir."/$username") or tws_error('',"Unable to delete IWS/WebAdmin user '$username' home directory");
         tws_dyer("Unable to create user. Original authusers file restored.", array('stdout'=>$stdout), "tws_user_administration.php");
      }
      else {
         if (isset($group) && $group!='NULL') {
            $authgroups="$base_inst_dir/httpd/conf/authgroups";
            $newauthgroups=$authgroups . ".tmp";
            $bakauthgroups=$authgroups . ".bak";

            $fp=fopen($authgroups,"r") or tws_err("Can't open file $authgroups");
            $newfp=fopen($newauthgroups,"w") or tws_err("Can't open file $newauthgroups");
            while ($buffer=fgets($fp,4096)) {
               $curgroup=strtok($buffer,":");
               if ($curgroup == $group) {       // add user to $group
                  fputs($newfp,substr($buffer,0,-1) . " $username"."\n");
               } else {
                  fputs($newfp, $buffer);
               }
            }
            fclose($fp);
            fclose($newfp);

            copy($authgroups,$bakauthgroups);
            copy($newauthgroups,$authgroups);
            unlink($newauthgroups);
         }
         // Add description
         if (trim($description) != '') {
            $authusers_desc="$base_inst_dir/httpd/conf/authusers_desc";
            $bakauthusers_desc=$authusers_desc . ".bak";
            copy($authusers_desc, $bakauthusers_desc);

            $fp=fopen($authusers_desc,"a") or tws_error("Can't open file $authusers_desc");;
            fputs($fp, $username.': '.$description."\n");
            fclose($fp);
         }

         echo "<script language=\"Javascript\">\n";
         echo "window.location.replace(\"tws_user_administration.php\");\n";
         echo "</script>\n";
      }
   }
?>
</body>
</html>
