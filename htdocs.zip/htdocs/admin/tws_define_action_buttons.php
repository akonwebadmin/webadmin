<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");

tws_import_request_variables('GP', 'rqst_');

if (isset($rqst_group)) { /* self call from "User currently has <a href='tws_define_action_buttons.php?group=$groupname'>$groupname</a> group permissions" */
   $groupname = tws_gpc_get($rqst_group, 'tws_alfanum');
}

if (isset($rqst_action)) { /* back call from tws_save_action_button.php When 'Set Default ...' clicked */
   $action = urldecode($rqst_action);
   if(isset($rqst_user))
      $username = tws_gpc_get(urldecode($rqst_user), 'tws_alfanum\\tws_alfanum', '\\');
   if (isset($rqst_group))
      $groupname = tws_gpc_get(urldecode($rqst_group), 'tws_alfanum');
}
// Normal way
$cnt = 0;
if(isset($selection)){ // From User Administration
   $cnt = count($selection);
   if($cnt>1)
      $username = "";
   else
      $username = $selection[0];
   $groupname = "";
}

/******  $groupname & $username defined in tws_user_administration_actions.php & tws_group_administration_actions.php */

$edit_default_actions = false;// curently editing default actions
$edit_user_actions = false;// curently editing user actions
$edit_group_actions = false;// curently editing group actions

if ($username != '') {
   $edit_user_actions = true;
   $groupname = tws_groupname($username);
}
elseif($cnt>1)
   $edit_user_actions = true;
elseif ($groupname !='')
   $edit_group_actions = true;
else
   $edit_default_actions = true;
?>
<html>
<head>
   <title>Define Action Buttons</title>
<?php tws_adminstylesheet(); ?>
<script type="text/javascript">

function bodyonload() {
document.actionsForm['section'].selectedIndex = 0;
setSectionActions ();
}

function setSectionActions () {
   sel=document.actionsForm['section'].selectedIndex;
   var selsection = document.actionsForm['section'].options[sel].value;
   hideAllDivs();
   showDiv(selsection + "_div");
}

function hideAllDivs() {
   var f = document.actionsForm.getElementsByTagName("div");
var len = f.length;
   for(var i=0; i<len; i++) {
      var e = f[i];
      e.style.display="none";
   }
}

function showDiv(divname) {
   document.getElementById(divname).style.display = "block";
}


function removeField(section) {
var destcontrol = $("#exclude", "div#"+section+"_div").get(0);
var srccontrol =  $('div#'+ section + '_div #'+section).get(0);
var sel=srccontrol.selectedIndex;
while (sel != -1 && srccontrol.options[sel].value > "") {
var temptext=srccontrol.options[sel].text;
var tempvalue=srccontrol.options[sel].value;
var destpos=destcontrol.length;
if (destpos == 1) {
if (destcontrol.options[0].value == "-NULL-") {
destcontrol.options[0]=null;
destpos=0;
}
}
destcontrol.options[destpos]=new Option(temptext,tempvalue);
srccontrol.options[sel]=null;
sel=srccontrol.selectedIndex;
var str = 'div#'+ section + '_div #'+ section + '_changed';
$(str).attr('value','1');
}
}

function addField(section) {
var destcontrol = $('div#'+ section + '_div #'+ section).get(0);
var srccontrol = $("#exclude", "div#"+section+"_div").get(0);
var sel=srccontrol.selectedIndex;
while (sel != -1 && srccontrol.options[sel].value > "") {
temptext=srccontrol.options[sel].text;
tempvalue=srccontrol.options[sel].value;
   destpos=destcontrol.length;
   if (destpos == 1) {
if (destcontrol.options[0].value == "-NULL-") {
destcontrol.options[0]=null;
destpos=0;
}
   }
   destcontrol.options[destpos]=new Option(temptext,tempvalue);
   srccontrol.options[sel]=null;
sel=srccontrol.selectedIndex;
$('div#'+ section + '_div #'+ section + '_changed').attr('value','1');
}
}

function goback() {
window.location.replace("tws_user_administration.php");
}

//
function frm_onSubmit() {
   <?php
   foreach($tws_default_actions as $section => $buttons) {
echo "var list = document.getElementById('".$section."');
for (i = 0; i < list.options.length; i++) {
            list.options[i].selected = true; }\n";
}
?>
}

</script>
</head>

<body onload="bodyonload();">
<?php
   tws_set_window_title();
// Header
if ($groupname != '' && $username != '') {
   tws_print_head('Customize Action Buttons for User: '.htmlspecialchars($username) . " (". htmlspecialchars($groupname) ." group)", '', '../');
   if($groupname == 'admin')
      echo "<p class=warning>Admin user selected. Layout settings will not take effect. Admin users have full rights always.</p>";
}
elseif ($username != '' && $groupname == '')
      tws_print_head('Customize Action Buttons for User: '.htmlspecialchars($username), '', '../');
elseif ($groupname != '' && $username=='') {
   //$twssec = tws_get_twssec_groups();
   //if(array_key_exists($groupname, $twssec) )
   //   tws_print_head('Customize Action Buttons for IWS Security User Section: '.htmlspecialchars($groupname));
   //else
      tws_print_head("Customize Action Buttons for '".htmlspecialchars($groupname). "' group", '', '../');
}
elseif($cnt>1){
   tws_print_head('Customize Action Buttons for selected users', '', '../');
   echo '<p class=warning>Multiply users selected. Layout settings starts with the default layout and will overwrite settings for all selected users.</p>',"\n";
}
else
   tws_print_head('Customize Default Action Buttons.', '', '../');

?>
<form method="post" name="actionsForm" action="tws_save_action_buttons.php" onsubmit="frm_onSubmit();">
<table border="0" cellpadding='0' cellspacing='0'>
<tbody>
   <tr>
      <td class=standard align="center" valign="top">
         <h2>Select Section</h2>
      </td>
      <td width='30'>&nbsp;</td>
      <td>&nbsp;</td>
</tr>
<tr>
      <td>
         <select name="section" size=23 style="width: 16em;" onclick="setSectionActions();" onchange="setSectionActions();" >
         <?php
         foreach($tws_section_names as $section => $section_name) {
            if($section_name == 'optgroup')
               echo "<optgroup label=\"$section\"> />\n";
            else
               echo "<option value=\"$section\">$section_name</option>\n";
         }
         ?>
         </select>
      </td>
      <td>&nbsp;</td>

      <td class=standard align="center" valign="top">
<?php

//************ Read Permissions ************** //
foreach($tws_section_names as $section => $section_name) {
   if (trim($section_name) == 'optgroup') continue;

   if ($action == 'Use Group Default Values') { // set Default Values
      if ($groupname !='')
         $arr_permit = tws_get_group_actions($section, $groupname);
      else
         tws_dyer("Group is empty while attemting to use Group Default Values", "", "tws_user_administration.php");
   }
   elseif ($action == 'Use Default Values') {
      $arr_permit = tws_get_default_actions($section);
   }
   else { // Normal way
      if ($username != '')
         $arr_permit = tws_get_user_actions($section, $username);
      elseif ($groupname !='')
         $arr_permit = tws_get_group_actions($section, $groupname);
      else
         $arr_permit = tws_get_default_actions($section);
   }
   $all_permit = tws_get_all_actions($section);
   if($arr_permit=='')
      $exclude_column = $all_permit;
   else
      $exclude_column = array_diff($all_permit, $arr_permit);

   echo "<div id='".$section."_div' style='display:none'>\n\n";

   echo "<h2>$section_name </h2>
      <table border='0' cellpadding='10' cellspacing='0'>
        <tbody>
          <tr>
            <td class=standard align='center' valign='top'><b>Available Actions</b></td>
            <td class=standard align='center' valign='top'><b>Selected Actions</b></td>
          </tr>
          <tr>
            <td class=standard align='center' valign='top'>
            <select name='exclude' id='exclude' multiple='multiple' size='13' style='width: 12em;' onDblClick=\"addField('$section')\">\n";
   foreach($exclude_column as $exclude_column_name) {
      echo "<option value=\"$exclude_column_name\">$exclude_column_name</option>\n";
   }
   echo "</select>
   <p><input type='Button' name='addcolumn' value='Add &gt;&gt;' onClick=\"addField('$section')\"></p>
               </td>
               <td class=standard align='center' valign='top'>
               <select name='".$section."[]' id='$section' multiple='multiple' size='13' style='width: 12em;' onDblClick=\"removeField('$section')\">\n";
   $i=0;
   if(is_array($arr_permit)) {
      foreach($arr_permit as $buttons) {
         echo "<option value=\"$buttons\">$buttons</option>\n";
         $i++;
      }
   }
   echo "</select>
   <p><input type='Button' name='removecolumn' value='&lt;&lt; Remove' onClick=\"removeField('$section')\"></p>\n";
   echo "</td>
             </tr>
           </tbody>
         </table>
         <input type='hidden' name='".$section."_changed' id='".$section."_changed' value=''>
      </div>\n\n";
}
?>
</td>
   </tr>
  </tbody>
</table>
<input type='hidden' name='groupname' value='<?php echo $groupname; ?>' />
   <input type='hidden' name='username' value='<?php echo $username; ?>' />
<br/><br/>
<?php
echo tws_create_hidden_inputs($selection, 'selection', null);

//*********** Massages ************* //

$using_defaults = false;   //flags to determine necessary buttons above
$using_group_defaults = false;
$using_custom_profile = false;

if ($edit_default_actions) {
   echo '<p class=warning>You are currently modifying default Action Button settings. Saving will affect all users who don\'t have custom action buttons settings.</p>',"\n";
}
elseif ($edit_user_actions && $username!='') {
   if($groupname == 'admin')
      echo "<p class=warning>Admin user selected. Layout settings will not take effect. Admin users have full rights always.</p>";
   else {
      if (tws_UserHaveCustomActions($username)) {
         echo '<p class=warning>User already has a custom action buttons settings.</p>',"\n";
         $using_custom_profile = true;
      }
      elseif(tws_GroupHaveCustomActions($groupname)) {
         echo "<p class=warning>User currently has <a href='tws_define_action_buttons.php?group=$groupname'>$groupname group permissions</a> - Saving will create a custom action buttons settings for the user.</p>\n";
         $using_group_defaults = true;
      }
      else {
         echo '<p class=warning>User currently has default permissions - Saving will create a custom action buttons settings for the user.</p>',"\n";
         $using_defaults = true;
      }
   }
}
elseif($groupname!='') {   // group actions
   if (tws_GroupHaveCustomActions($groupname)) {
      echo "<p class=warning>Group currently has a custom action buttons settings.</p>\n";
      $using_custom_profile = true;
      $using_group_defaults = true;
   }
   else {
      echo '<p class=warning>Group currently has default permissions - Saving will create custom action buttons settings for the group.</p>',"\n";
      $using_defaults = true;
      $using_group_defaults = true;
   }
}

// ******* Buttons ********** //

if (!$edit_default_actions) {
   if (!$using_defaults && $cnt<2 )
      echo "<input type='submit' value='Use Default Values' name='action'>&nbsp;";
   if ($groupname!='' and $groupname!='admin' and $using_group_defaults == FALSE)
      echo "<input type='submit' value='Use Group Default Values' name='action'>&nbsp;";
   if ( $using_custom_profile || $cnt>1 )
      echo "<input type='submit' value='Remove Custom Profile' name='action'>&nbsp;";
   echo "<br/><br/>";
}
?>

<input type='Submit' name='action' value='Save Changes'>&nbsp;
<?
if ($edit_default_actions)
   echo"<input type='Button' name='action' value='Cancel' onClick='window.location.replace(\"tws_user_administration.php#defaults\");'>&nbsp;";
elseif ($edit_user_actions)
   echo"<input type='Button' name='action' value='Cancel' onClick='window.location.replace(\"tws_user_administration.php\");'>&nbsp;";
else
   echo"<input type='Button' name='action' value='Cancel' onClick='window.location.replace(\"tws_user_administration.php#groups\");'>&nbsp;";
tws_print_synchro_token();     // synchro_token
?>
</form>

</body>
</html>
<?php

function tws_UserHaveCustomActions($username) {
   global $user_setting_dir, $webadmin_user_home_dir;
   $useractions_fn = $webadmin_user_home_dir.'/'.$username.$user_setting_dir.'/actions.php';
   if (file_exists($useractions_fn))
      return true;
   return false;
}

function tws_GroupHaveCustomActions($groupname) {
   global  $user_setting_dir, $webadmin_user_home_dir;
   $groupactions_fn = $webadmin_user_home_dir.'/groups/'.$groupname.$user_setting_dir.'/actions.php';
   if (file_exists($groupactions_fn))
      return true;
   return false;
}
?>
