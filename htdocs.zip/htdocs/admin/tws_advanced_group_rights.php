<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');
?>
<html>
<head>
   <title>Advanced Group Rights</title>
   <?php tws_adminstylesheet(); ?>
</head>
<body>
<?php
   tws_import_request_variables('GP','rqst_');

   $using_defaults = false;     // Group have no own settings
   $using_custom_profile = false;

   // ********  Actions   ******** //
   if (urldecode($rqst_action) == 'Use Default Values') {
      $selection = tws_gpc_get($rqst_groupname, 'tws_alfanum');
      if ( !isset($selection) || trim($selection)==='' ) {tws_dyer("groupname is empty!", '', 'back');}
      $set_rights = tws_set_default_rights();
   }
   if (urldecode($rqst_action) == 'Advanced Group Rights')
      $selection = tws_gpc_get($rqst_selection, 'tws_alfanum');

   if ( !isset($selection) || trim($selection)==='' ) {
      tws_dyer( "Advanced Group Rights : No group selected");
   }

   $groupname = $selection;
      tws_print_head("Advanced Group Rights for '".htmlspecialchars($groupname)."' group",'','../');

   if (file_exists($tws_config['base_inst_dir'].'/etc/usersec.php'))       // FIX etc
      include $tws_config['base_inst_dir'].'/etc/usersec.php';

//  Read Rights
   if (!isset($default_rights))  //$default_rights is (should be)  defined in the usersec.php
      $default_rights='abcdefghijklmnopqrt'; //factory settings

   if (!isset($group_rights[$groupname])) {
      $using_defaults=TRUE;
      $group_rights[$groupname]=$default_rights;
   }
   else {
      $using_custom_profile = true;
   }

   if(isset($set_rights))
      $group_rights[$groupname] = $set_rights;

//build the array of rights from the rights string
   for ($i=0; $i<strlen($group_rights[$groupname]); $i++)
      $right[$group_rights[$groupname]{$i}]=1;
// max rows returned from server
   if(isset($group_limit[$groupname]))
      $limit = $group_limit[$groupname];
   else $limit = 0;
?>
<form method=post action="tws_save_advanced_group_rights.php">
<h3> Plan</h3>
&nbsp;&nbsp;<label><input type="checkbox" name="right[a]" value="1"<?php if (isset($right['a'])) echo " checked" ?>/> View Job Output</label><br>
&nbsp;&nbsp;<label><input type="checkbox" name="right[b]" value="1"<?php if (isset($right['b'])) echo " checked" ?>/> Save Filters</label><br>
&nbsp;&nbsp;<label><input type="checkbox" name="right[c]" value="1"<?php if (isset($right['c'])) echo " checked" ?>/> Generate Forecasts</label><br>
<h3> Notes</h3>
&nbsp;&nbsp;<label><input type="checkbox" name="right[d]" value="1"<?php if (isset($right['d'])) echo " checked" ?>/> View Notes</label><br>
&nbsp;&nbsp;<label><input type="checkbox" name="right[e]" value="1"<?php if (isset($right['e'])) echo " checked" ?>/> Create / Modify Notes</label><br>
<h3> Reports</h3>
&nbsp;&nbsp;<label><input type="checkbox" name="right[f]" value="1"<?php if (isset($right['f'])) echo " checked" ?>/> Generate Reports</label><br>
&nbsp;&nbsp;<label><input type="checkbox" name="right[q]" value="1"<?php if (isset($right['q'])) echo " checked" ?>/> Generate SQL Query Reports</label><br>
&nbsp;&nbsp;<label><input type="checkbox" name="right[g]" value="1"<?php if (isset($right['g'])) echo " checked" ?>/> Save Reports</label><br>
&nbsp;&nbsp;<label><input type="checkbox" name="right[h]" value="1"<?php if (isset($right['h'])) echo " checked" ?>/> Store Reports</label><br>
<h3> Log / Alert</h3>
&nbsp;&nbsp;<label><input type="checkbox" name="right[i]" value="1"<?php if (isset($right['i'])) echo " checked" ?>/> View Events with Event Monitor</label><br>
&nbsp;&nbsp;<label><input type="checkbox" name="right[l]" value="1"<?php if (isset($right['l'])) echo " checked" ?>/> View Audit Logs</label><br>
<h3> Miscellaneous</h3>
&nbsp;&nbsp;<label><input type="checkbox" name="right[p]" value="1"<?php if (isset($right['p'])) echo " checked" ?>/> Change Password</label> (Users can change own passwords)<br>
&nbsp;&nbsp;<label><input type="checkbox" name="right[t]" value="1"<?php if (isset($right['t'])) echo " checked" ?>/> Hide Advanced Options</label><br>
&nbsp;&nbsp;<label><input type="checkbox" name="right[s]" value="1"<?php if (isset($right['s'])) echo " checked" ?>/> Save for all users</label><br>
&nbsp;&nbsp;<label><input type="checkbox" name="right[w]" value="1"<?php if (isset($right['w'])) echo " checked" ?>/> Always save backups</label><br>
&nbsp;&nbsp;&nbsp;Error Level: <select name="right[u]">
   <option value="0" <?php if (!isset($right['u']) ) echo " selected" ?> >user</option>
   <option value="1" <?php if ( isset($right['u']) ) echo " selected" ?> >admin</option>
</select><br>
&nbsp;&nbsp;Returned Results Limit: <input type="text" name="limit" value="<?=$limit?>" size=10>&nbsp;&nbsp;(For Flexible Tables only. 0 ≡ unlimited)<br>
<input type="hidden" name="groupname" value="<?=htmlspecialchars($groupname);?>"/>
<input type="hidden" name="defaults_rights" value="<?=$default_rights;?>"/>
<br>

<?php
   tws_print_synchro_token();   //   synchro_token

   if ($using_defaults)
      echo "<p class=warning>Group currently has default rights - Saving will create a custom profile for the group.</p>\n";
   else
      echo "<p class=warning>Group already has a custom profile.</p>\n";

   if (!$using_defaults)
      echo "<input type='submit' value='Use Default Values' name='action'>&nbsp;";

   if ( $using_custom_profile )
      echo "<input type='submit' value='Remove Custom Profile' name='action'>&nbsp;";

   echo "<br><br>";
?>
<input type="submit" value="Save Changes" name="action">&nbsp;
<input type='Button' name='action' value='Cancel' onClick='window.location.replace("tws_user_administration.php#groups");'>&nbsp;
</form>
</body>
</html>
<?php

function tws_set_default_rights() {
   global $tws_config;

   $usersec = $tws_config['maestro_dir']."/webadmin/etc/usersec.php"; //FIXME etc
   if (file_exists($usersec)) {
      include $usersec;
   }
   else { tws_dyer("Unable to open file $usersec", "", "tws_user_administration.php"); }

  $str_rights=$default_rights;
  return $str_rights;
}
?>
