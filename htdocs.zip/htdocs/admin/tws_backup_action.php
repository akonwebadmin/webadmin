<?php
//   HORIZONT Software GmbH, Munich
//

   require_once("tws_functions.php");
   tws_import_request_variables("P","rqst_");
   $action = $rqst_action;
   $selection = tws_gpc_get($rqst_selection, 'tws_file');
   $inline = @$rqst_inline;
   $tc = @$rqst_tc;

   tws_doctype('t');
   echo "<html>\n";
   echo "<head>\n";
   tws_adminstylesheet();

   if(count($selection)==0 && !preg_match('/filter/i', $action)) {
      tws_warning("No object selected");
      tws_dyer();
   }

   switch ($action) {
      case 'Delete' :
         echo "<title>Delete backup file</title>\n";
         echo "</head>\n";
         echo "<body>\n";
         tws_set_window_title();
         tws_print_head('Delete backup file',array(),'../');
         echo "<br>\n";
         echo "<h3>Selected backup files:</h3>\n";
         echo "<form method=post action=\"\">\n";
         for ($i = 0; $i < count($selection); $i++) {
            echo "&nbsp;&nbsp;&nbsp;&nbsp;".preg_replace("/\\\\/", '/', $maestro_dir.'/webadmin/backup/composer/')."<b>".htmlspecialchars($selection[$i])."</b>\n";
            echo "<input type=\"hidden\" name=\"selection[]\" value=\"".htmlspecialchars($selection[$i])."\">\n";
            echo "<br>\n";
         }
         echo "<br>\n";
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Delete\">&nbsp;&nbsp;\n";
         echo "<input type='button' value='Cancel' onclick=\"window.location.replace('tws_backup_administration.php');\">\n";
         echo "<input type=\"hidden\" name=\"action\" value=\"DeleteExec\">\n";
         tws_print_synchro_token();  // synchro_token
         echo "</form>\n";
         break;


      case 'DeleteExec' :
         $undeleted = array();
         $ch_folder = @chdir($maestro_dir.'/webadmin/backup/composer/');
         if ($ch_folder) {
            $backup_dir = dir($tws_config["maestro_dir"]."/webadmin/backup/composer");
            while (($file = $backup_dir->read()) !== FALSE) {
               if (substr($file,0,1) === '.')
                  continue;
               if (in_array($file,$selection) === TRUE) {
                  chmod($file, 0755);
                  if (@unlink($file) === FALSE) {
                     $undeleted[] = preg_replace("/\\\\/", '/', $maestro_dir.'/webadmin/backup/composer/')."$file\n";
                  }
               }
            }
            $backup_dir->close();
         }

         if (count($undeleted) === 0 && $ch_folder === TRUE) {
            header('Location: tws_backup_administration.php');
            header('Connection: close');
            exit;
         } else {
            echo "<title>Delete backup file</title>\n";
            echo "</head>\n";
            echo "<body>\n";
            tws_set_window_title();
            tws_print_head('Delete backup file',array(),'../');
            echo "<br>\n";
            if ($ch_folder) {
               for ($i=0; $i < count($undeleted); $i++) {
                  echo "Deleting <em>".htmlspecialchars($undeleted[$i])."</em> ... <span class=\"err\">ERROR</span><br/>\n";
               }
               echo "<p class=\"error\">Error: Unable to delete the files, operation failured.</p>\n";
            } else {
               echo "<p class=\"error\">Error: Unable to find the folder ".preg_replace("/\\\\/", '/', $maestro_dir.'/webadmin/backup/composer/')."</p>\n";
            }
            echo "<a href=\"tws_backup_administration.php\">Return to Backup Administration</a>\n";
         }
         break;


      case 'Display' :
         echo "<title>Display backup file</title>\n";
         ?>

         <script type="text/javascript">
            function copyToClipboard(id) {
            var text = document.getElementById(id).innerHTML;
              if (window.clipboardData) {
                 window.clipboardData.setData("Text",text);
              }
           }
         </script>
            <!--  CODEMIRROR  -->
            <script type="text/javascript" src="/codemirror/lib/codemirror.js"></script>
            <script type="text/javascript" src="/codemirror/mode/tws/tws.js"></script>
            <link rel="stylesheet" type="text/css" href="/codemirror/lib/codemirror.css"/>
            <link rel="stylesheet" type="text/css" href="/codemirror/mode/tws/tws.css"/>
            <script type="text/javascript">
            $( document ).ready(function() {
               $('textarea.tws_code').each(function () {
                  CodeMirror.fromTextArea($(this).get(0), { lineNumbers: true, matchBrackets: true, mode:'tws'});
               });
            });
            </script>
            <style type="text/css">
               form#TEXTEDIT.CodeMirror-scroll { height:calc(80vh) !important }
            </style>         
         </head>
         <body>
         <?php
         tws_set_window_title();
         tws_print_head('Selected backup files content',array(),'/');
         for ($i = 0; $i < count($selection); $i++) {
            echo "<table class=\"wireframe\" id=\"sortable\" cellspacing=0 cellpadding=4 width=\"100%\" cols=1>\n";
            echo "<colgroup span=\"1\" width=\"1\">\n";
            echo "<tr class=header>\n";
            echo "<th>".preg_replace("/\\\\/", '/', $maestro_dir.'/webadmin/backup/composer/').htmlspecialchars($selection[$i])."</th>\n";
            echo "</tr>\n";
            echo "<tr class=standard>\n";
            echo "<td>\n";
            $info = explode(".",$selection[$i]);
            $result = tws_get_backupfile("$maestro_dir/webadmin/backup/composer/$selection[$i]");
            $rows = substr_count($result['content'], "\n");
            $rows = $rows + 2;
            echo "<textarea id=\"$info[2]\" class='tws_code' style=\"width: 99%; _width: expression(document.body.clientWidth - 5); overflow: auto;\" rows=\"$rows\" readonly=\"readonly\">";
            echo htmlspecialchars($result['content']);
            echo "</textarea>\n";
            echo "</td>\n";
            echo "</tr>\n";
            echo "</table>\n";
            if (isset($_SERVER['HTTP_USER_AGENT']) && (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== false) && (strpos($_SERVER['HTTP_USER_AGENT'], 'Opera') === false)) {
               echo "<form id=\"form\" action=\"\">\n";
               echo "<input type=\"button\" value=\"&nbsp;Copy To Clipboard&nbsp;\" onclick=\"copyToClipboard('$info[2]');\" \>\n";
               echo "</form>\n";
            }
            echo "<br>\n";
         }
         echo "<a href=\"tws_backup_administration.php\">Return to Backup Administration</a>\n";
         break;

      case 'Compare':// Compare
         echo "<title>Compare backup files</title>\n";
         tws_show_backup();
         //if (isset($inline)) {
         ?>
         <style type="text/css">
            del {color:red;}
            ins {color:green; font-weight:bold;}
            .changed {color:blue; font-weight:bold; background-color: rgb(255, 255, 0);}
         </style>
         <?php
         //}
         echo "</head>\n";
         echo "<body>\n";
         tws_set_window_title();
         tws_print_head('Compare two backup files',array(),'../');
         if (!isset($selection)) {
            tws_dyer( "No backup files selected.", "", "tws_backup_administration.php");
         }
            if (count($selection) != 2) {
            tws_dyer( "Only two backup files can be compared at a time.", "", "tws_backup_administration.php");
         }
         tws_compare_backup_files($selection[0], $selection[1]);
         break;

      case 'Compare With Current':// Compare With Current
         echo "<title>Compare with current definition</title>\n";
         tws_show_backup();
         ?>
         <style type="text/css">
            del {color:red;}
            ins {color:green; font-weight:bold;}
            .changed {color:blue; font-weight:bold; background-color: rgb(255, 255, 0);}
         </style>
         </head>
         <body>
         <?php
         tws_set_window_title();

         if (!isset($selection))
            tws_dyer( "No backup files selected.", "", "tws_backup_administration.php");
         else if (count($selection) > 1)
            tws_dyer( "Only one backup file can be compared at a time.", "", "tws_backup_administration.php");

         tws_compare_with_current($selection[0]);
         break;

      case 'Filter':
         header('Location: tws_backup_filter.php');
         header('Connection: close');
         exit;
         break;

      case 'Save Filter':
         $object='backup';
         header("Location: /tws_save_filter.php?object=$object");
         header('Connection: close');
         exit;
         break;
   }

   echo "</body>\n";
   echo "</html>\n";


function tws_compare_with_current($filename) {
global $maestro_dir;

$filename = basename($filename);

$file1 = preg_replace("/\\\\/",'/',$maestro_dir)."/webadmin/backup/composer/".$filename;
if ((($result1 = tws_get_backupfile($file1)) !== FALSE) ) {
// get obj type
$info = explode(".",$filename);
$objtype = $info[0];

$result_data1['Backup filename']  = "<a href=\"javascript:showBackup('$filename')\">$filename</a>";
$result_data1['Created date'] = tws_iso_to_userdate(date('Y-m-d H:i:s', $result1['timestamp']));
$result_data1['Creator'] = $result1['creator'];
if (!isset($result1['object'])) {
   tws_dyer("Can't get object name or object name is not available in $filename");
}
$left = $result1['content'];
$leftdata = $result_data1;
}
else {
   tws_dyer("Can't find file $file1", "", "tws_backup_administration.php");
}

// get current content (for all objects in array $result1['object'])
$right = tws_backup_get_current_content($objtype, $result1['object']);
$rightdata['Current definition'] = " ";
$rightdata['Object'] = $result1['object'];

if (strpos('<?xml', $left)===0 || strpos('<?xml', $right)===0) {
   require_once "Text/Highlighter.php";
   require_once "Text/Highlighter/Renderer/Html.php";
   $renderer = new Text_Highlighter_Renderer_Html(); //array("numbers" => HL_NUMBERS_LI, "tabsize" => 3));
   $hlxml =& Text_Highlighter::factory("XML");
   $hlxml->setRenderer($renderer);

   if (strpos('<?xml', $left)===0) $left=$hlxml->highlight($left);
   if (strpos('<?xml', $right)===0) $right=$hlxml->highlight($right);
}

$left=explode("\n",$left);
$right=explode("\n",$right);

tws_print_head('Compare with current definition',
array('Backup file' => $rightdata['Backup filename'] . ", <strong>Creator</strong>: " . $rightdata['Creator'] . ", <strong>Created date</strong>: " . $rightdata['Created date']), '/');

foreach ($left as $key => $value)
$left[$key] = rtrim($value);
foreach ($right as $key => $value)
$right[$key] = rtrim($value);
echo "
<!--  Tabs. -->
<script>
$(function() {
   $('#tabs').tabs();
});
</script>
<div id='tabs'>
   <ul>
      <li><a href='#tc'>Two-column</a></li>
      <li><a href='#inline'>In-line</a></li>
   </ul>

   <div id='tc'>";

$result = tws_compare($left, $right, "TC", array($leftdata,$rightdata) );
if ($result !== FALSE) {
if (strstr($result, "<span style=\"color:red\">") === FALSE &&
 strstr($result, "<ins>") === FALSE &&
 strstr($result, "<del>") === FALSE &&
 strstr($result, '<span class="changed">') === FALSE ) {
echo "<p class=\"message\">Backup file is identical with current definition</p>\n";
}
echo "<br>\n";
echo "<pre>".$result."</pre>";
}
else {
 echo "<p class=\"error\">Unable to use PEAR Text_Diff Class function</p>\n";
}
echo "
</div>

   <div id='inline'>";

$result = tws_compare($left, $right, "INLINE", array($leftdata,$rightdata) );
if ($result !== FALSE) {
if (strstr($result, "<span style=\"color:red\">") === FALSE &&
 strstr($result, "<ins>") === FALSE &&
 strstr($result, "<del>") === FALSE &&
 strstr($result, '<span class="changed">') === FALSE ) {
echo "<p class=\"message\">Backup file is identical with current definition</p>\n";
}
echo "<br>\n";
echo "<pre>".$result."</pre>";
}
else {
 echo "<p class=\"error\">Unable to use PEAR Text_Diff Class function</p>\n";
}
echo "
   </div>
</div>
<br>\n";
echo "<a href=\"tws_backup_administration.php\">Return to Backup Administration</a>\n";

}

function tws_compare_backup_files($filename1, $filename2) {
global $maestro_dir;

$filename1 = basename($filename1);
$filename2 = basename($filename2);

$file1 = preg_replace("/\\\\/",'/',$maestro_dir)."/webadmin/backup/composer/".$filename1;
$file2 = preg_replace("/\\\\/",'/',$maestro_dir)."/webadmin/backup/composer/".$filename2;

tws_print_head('Compare two backup files',
   array('Original file' => $leftdata['Backup filename'] . ", <strong>Creator</strong>: " . $leftdata['Creator'] . ", <strong>Created date</strong>: " . $leftdata['Created date'],
   'New file' => $rightdata['Backup filename'] . ", <strong>Creator</strong>: " . $rightdata['Creator'] . ", <strong>Created date</strong>: " . $rightdata['Created date']), '/');

if ((($result1 = tws_get_backupfile($file1)) !== FALSE) && (($result2 = tws_get_backupfile($file2)) !== FALSE)){
   $result_data1['Backup filename']  = "<a href=\"javascript:showBackup('$filename1')\">$filename1</a>";
   $result_data1['Created date'] = tws_iso_to_userdate(date('Y-m-d H:i:s', $result1['timestamp']));
   $result_data1['Creator'] = $result1['creator'];

   $result_data2['Backup filename'] = "<a href=\"javascript:showBackup('$filename2')\">$filename2</a>";
   $result_data2['Created date'] = tws_iso_to_userdate(date('Y-m-d H:i:s', $result2['timestamp']));
   $result_data2['Creator'] = $result2['creator'];

   if ($result1['timestamp'] <= $result2['timestamp']) {
   $left = $result1['content'];
   $right = $result2['content'];
   $leftdata = $result_data1;
   $rightdata = $result_data2;
   } else {
   $left = $result2['content'];
   $right = $result1['content'];
   $leftdata = $result_data2;
   $rightdata = $result_data1;
   }
} else {
   tws_dyer("Can't get file content");
}
if (strpos('<?xml', $left)===0 || strpos('<?xml', $right)===0) {
   require_once "Text/Highlighter.php";
   require_once "Text/Highlighter/Renderer/Html.php";
   $renderer = new Text_Highlighter_Renderer_Html(); //array("numbers" => HL_NUMBERS_LI, "tabsize" => 3));
   $hlxml =& Text_Highlighter::factory("XML");
   $hlxml->setRenderer($renderer);

   if (strpos('<?xml', $left)===0) $left=$hlxml->highlight($left);
   if (strpos('<?xml', $right)===0) $right=$hlxml->highlight($right);
}

$left=explode("\n",$left);
$right=explode("\n",$right);

foreach ($left as $key => $value)
$left[$key] = rtrim($value);
foreach ($right as $key => $value)
$right[$key] = rtrim($value);

echo "
<!--  Tabs. -->
<script>
$(function() {
   $('#tabs').tabs();
});
</script>
<div id='tabs'>
   <ul>
      <li><a href='#tc'>Two-column</a></li>
      <li><a href='#inline'>In-line</a></li>
   </ul>

   <div id='tc'>";

$result = tws_compare($left, $right, "TC", array($leftdata,$rightdata) );
if ($result !== FALSE) {
if (strstr($result, "<ins>") === FALSE &&
 strstr($result, "<del>") === FALSE &&
 strstr($result, '<span class="changed">') === FALSE ) {
echo "<p class=\"message\">The both backup files are identical</p>\n";
}
echo "<br>\n";
echo "<pre>".$result."</pre>";
}
else {
 echo "<p class=\"error\">Unable to use PEAR Text_Diff Class function</p>\n";
}

echo "
</div>

   <div id='inline'>";

$result = tws_compare($left, $right, "INLINE", array($leftdata,$rightdata) );
if ($result !== FALSE) {
if (strstr($result, "<ins>") === FALSE &&
 strstr($result, "<del>") === FALSE &&
 strstr($result, '<span class="changed">') === FALSE ) {
echo "<p class=\"message\">The both backup files are identical</p>\n";
}
echo "<br>\n";
echo "<pre>".$result."</pre>";
}
else {
 echo "<p class=\"error\">Unable to use PEAR Text_Diff Class function</p>\n";
}
echo "
   </div>
</div>
<br>\n";
   echo "<a href=\"tws_backup_administration.php\">Return to Backup Administration</a>\n";
}
?>