<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';

   if (!empty($type)) {
      $filter .= "+type=$type";
   }

   if (!empty($obj_name)) {
      $filter .= "+obj_name=$obj_name";
   }

   if (!empty($creator)) {
      $filter .= "+creator=$creator";
   }

   if (!empty($createdfrom) || !empty($createdto)) {
      $filter.='+'."created=".trim(tws_userdate_add_default_tz($createdfrom) . ',' . tws_userdate_add_default_tz($createdto));
   }

   if (!empty($search)) {
      $filter .= "+search=$search";

      if (!empty($case_sensitive)) {
         $filter .= "+case_sensitive=$case_sensitive";
      }
   }

   tws_profile('backupfilter', $filter);


   header("Location: tws_backup_administration.php?arg=".urlencode($filter));
   header('Connection: close');
?>