<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
   tws_profile('opener', basename($_SERVER['SCRIPT_NAME']) );
?>
<html>
<head>
<title>IWS/WebAdmin Menu Configuration</title>
<script type="text/javascript">
function MenuCheckAll() {
 selection = document.menu.elements['menu_item[]'];
 selection.checked=true;
 for (i=0; i<selection.length; i++) {
  selection[i].checked=true;
 }
}
function MenuClearAll() {
 selection = document.menu.elements['menu_item[]'];
 selection.checked=false;
 for (i=0; i<selection.length; i++) {
  selection[i].checked=false;
 }
}

function checkSection(el, num) {
   if( $(el).is(':checked') )
      $('input:checkbox.'+num).attr('checked','checked');
   else
      $('input:checkbox.'+num).removeAttr('checked');
}

function goback() {
window.location.replace("tws_user_administration.php#defaults");
}
</script>
<?php tws_adminstylesheet();
   tws_set_window_title();
?>
</head>
<body>
<?php tws_print_head('IWS/WebAdmin Menu Configuration','','../'); ?>
<p class="warning">This administration tool is affecing all IWS/WebAdmin users. Use the <i>Define User Menu</i> in the <a href="tws_user_administration.php">IWS/WebAdmin User Administration</a> panel in case that customization of only some user accounts is needed.</p>
<br>
<form method=post name="menu" action="tws_set_menu_configuration.php">
<table border=0 cellspacing=0>
<tr>
<td class=standard>
<h3>Menu Items:</h3>
</td>
</tr>
<?php
   if (!tws_display_menu_configuration()) {
      die("<p class=warning>An Error occured when reading menu configuration</p></body></html>");
   }
?>
</table>
<br>
<a href="Javascript:MenuCheckAll();">Check All</a>&nbsp;&nbsp;-&nbsp;&nbsp;<a href="Javascript:MenuClearAll();">Clear All</a>
<br><br>
<input type="submit" value="Save Changes" name="action">&nbsp;
<input type='Button' name='action' value='Cancel' onClick='goback()'>&nbsp;
<? tws_print_synchro_token();     // synchro_token ?>
</form>
</body>
</html>
