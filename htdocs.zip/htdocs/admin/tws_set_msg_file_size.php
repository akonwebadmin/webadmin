<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Set IWS Mailbox File Size</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>
<?php
   tws_import_request_variables("P","rqst_");

   $selection=tws_gpc_get($rqst_selection, 'tws_file');
   $filesize=tws_gpc_get($rqst_filesize, 'tws_num');
      tws_check_synchro_token();  //    synchro_token

   if(!is_numeric($filesize))
      tws_dyer('Bad format of filesize');

   $status=0;
   $num_elements=count($selection);
   for ($idx=0; $idx<$num_elements; ++$idx) {
      $command=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), "$maestro_dir/bin/evtsize", "$maestro_dir/$selection[$idx]", $filesize);
      if (tws_popen($command,$ec,$stdout,$stdout)===FALSE || $ec!=0) {
         tws_dyer("Unable to set message file size on '$maestro_dir/$selection[$idx]' file", $stdout);
      }
   }

   if ($status==0) {
      echo "<script language=\"Javascript\">\n";
      echo "window.location.replace(\"tws_msg_files.php\");\n";
      echo "</script>\n";
   }
?>
</body>
</html>
