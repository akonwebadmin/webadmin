<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
   tws_profile('opener', basename($_SERVER['SCRIPT_NAME']) );
?>
<html>
<head>
<title>Event Configuration</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>
<?php
   tws_set_window_title();
   tws_print_head('Event Configuration', 'tws_event_configuration_help.php', '../');

   if (($event_list_array=tws_get_enabled_events())===FALSE) {
      tws_dyer('Unable to get events configuration');
   }

// Get event types
// default severities are also read here
   include ($event_types_file);
   foreach ($event_type as $key => $val) {
      $event_num[]=$key;
   }

// Get events from BmEvents.conf
   for ($i=0; $i<count($event_num); $i++) {
      $checked[$event_num[$i]]=NULL;
   }
   foreach ($event_list_array as $value) {
      $checked[$value]="checked";
   }

// Get severities
   include($severities_file);

// Get custom severities
   include($custom_severities_file);
?>

<form method=post action="tws_event_configuration_action.php">
<table border=0 cellspacing=0>
<tr>
<td class=standard width="260">
<h2>Events</h2>
</td>
</tr>
<tr>
<td class=standard valign="top" width="260">
<b>Reported Events:</b>
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<?php
   for ($i=0; $i<count($event_num); $i++) {
      echo "<tr>\n";
      echo "<td class=standard width=\"300\">&nbsp;&nbsp;";
      echo "<label><input type=\"checkbox\" name=\"event[]\" value=\"".htmlspecialchars($event_num[$i])."\"" . $checked[$event_num[$i]] . ">" . htmlspecialchars($event_type[$event_num[$i]]) . "</label></td>\n";
      echo "<td class=standard><select name=\"sel_severity[$event_num[$i]]\">\n";
      foreach ($severity as $severity_num => $severity_label) {
         echo "  <option value=\"$severity_num\"";
         if ($event_severity[$event_num[$i]] == $severity_num) {
            echo "selected";
         }
         echo ">".htmlspecialchars($severity_label);
         if ($default_severity[$event_num[$i]] == $severity_num) {
            echo " *";
         }
         echo "\n";
      }
      echo "</select>\n</td>\n</tr>\n";
   }
?>

</table>

<br><br>

&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Save" name="action">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Custom Events" name="action">
&nbsp;&nbsp;<input type="submit" value="Edit Severity Levels" name="action">

</form>
</body>
</html>
