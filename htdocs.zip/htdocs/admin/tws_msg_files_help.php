<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');
?>
<html>
<head>
   <title>IWS Mailbox Files Help</title>
   <?php tws_adminstylesheet(); ?>
</head>
<body class=help>
<?php
   tws_set_window_title();
   $path = '../';
   include $path.'tws_help_topbar.php';
?>
<h1 class=help>IWS Mailbox Files Help</h1>
<p>The IWS Mailbox Files page displays the current sizes of IWS message files and allows modification of the maximum size settings. IWS mailbox files are used for interprocess communication and message queuing. <strong>It is highly recommended that you understand the IWS message files facility prior to performing any modifications.</strong>
<p>The IWS Mailbox Files table contains the following columns:
<ul>
  <li><strong>Mailbox File</strong> : IWS Mailbox filename</li>
  <li><strong>Size</strong> : Current size in bytes</li>
  <li><strong>Max Size</strong> : Maximum size setting</li>
</ul>
<p>To change the maximum size setting of a mailbox file, select its checkbox, then click the <strong>Change Size</strong> button. Enter the new size in bytes, then click <strong>Submit</strong>.
</body>
</html>
