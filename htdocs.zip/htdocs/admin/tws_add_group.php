<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add IWS/WebAdmin Group</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<?php tws_print_head('Add IWS/WebAdmin Group','','../');?>

<br><br>

<form method='post' action='tws_create_group.php'>
   <table border='0' cellspacing='0'>
   <tr>
      <td class='standard' width='120'>Group name:</td>
      <td class='standard'><input type='text' name='groupname' class="tws_alfanum" required='required' size='16' maxlength='60'></td>
   </tr>
   <tr>
         <td>&nbsp;</td>
         <td>&nbsp;</td>
   </tr>
   </table>
   <br><br>
   <input type='submit' name='action' value='Create Group'>&nbsp;
   <input type='button' name='action' value='Cancel' onClick='window.location.replace("tws_user_administration.php#groups");'>
<? tws_print_synchro_token();     // synchro_token
?>
</form>
</body>
</html>
