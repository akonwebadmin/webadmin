<?php
//   HORIZONT Software GmbH, Munich
//

require_once("tws_functions.php");
require_once 'tws_rc_flt.php';
require_once '../tws_filters_lib.php';

tws_import_request_variables("P","");

// set selected filter as default
if (isset($selection) && isset($action) && $action == 'Set as Default') {
   $fdir = $webadmin_all_user_dir; 
              
   $selection = basename($selection);
   $ffile = $fdir."/".$selection;
   $fcontents = file_get_contents($ffile);
   if (!file_exists($ffile) || $fcontents===FALSE) tws_error("The filter file '$filter_file' is not accessible");

   $fstart=strpos($fcontents,"<selection>");
   if ($fstart !== FALSE) {
      $fend=strpos($fcontents,"</selection>");
      if ($fend !== FALSE)
         $filter=trim(substr($fcontents, $fstart+11, $fend-$fstart-11));
   }
   if (isset($filter)){
      if ( !empty($groupname) && empty($username) )
         tws_set_default_filter($object, $filter, '', $groupname);
      elseif (empty($groupname) && !empty($username)){
         foreach($username as $user)
            tws_set_default_filter($object, $filter, $user);
      }
      else tws_set_default_filter($object, $filter, 'all_users');
   }
}
tws_doctype("t");
?>
<html>
<head>
<title>Set Default Filters</title>
<? tws_adminstylesheet();?>

<script type="text/javascript">
$(function() {
<? if(!isset($filtertype) || $filtertype == 'plan')
      echo "var cur = window.localStorage.plantab;";
   else echo "var cur = window.localStorage.dbtab;";
?>
   if(typeof(cur) !='undefined')
      $( "div#tabs" ).tabs({ active: cur});
   else $('div#tabs').tabs();
   $('div#tabs').css('background-color','inherit');
   $('div#tabs').css('border','none 0px');
});
</script>

</head>
<body>
<?
if ( !empty($groupname) && empty($username) )
   tws_print_head("Set Default Filters for '$groupname' group", '', '../');
elseif (empty($groupname) && !empty($username)){
   if(count($username) >1 )
      tws_print_head('Set Default Filters for selected users', '', '../');
   else tws_print_head("Set Default Filters for '$username[0]' user", '', '../');
}
else tws_print_head('Set Default Filters for all users', '', '../');
?>

<form name='typeform' method='post' action="tws_define_default_filters.php">

<select name="filtertype" onchange="tws_waiting(1, '../'); typeform.submit()">
<option value="plan">Plan Filters</option>
<option value="db" <?=($filtertype=='db' ? ' selected': '')?> >Database Filters</option>
</select>
<input type='hidden' name='groupname' value='<?=htmlspecialchars($groupname)?>'>
<?=tws_create_hidden_inputs($username, 'username');?>
</form>
<?

// PLAN
if(!isset($filtertype) || $filtertype == 'plan'):
?>
<div id='tabs'>
   <ul>
      <li><a href='#domains'      onclick="window.localStorage.plantab=0">Domains</a></li>
      <li><a href='#workstations' onclick="window.localStorage.plantab=1">Workstations</a></li>
      <li><a href='#jobstreams'   onclick="window.localStorage.plantab=2">Jobstreams</a></li>
      <li><a href='#jobs'         onclick="window.localStorage.plantab=3">Jobs</a></li>
      <li><a href='#resources'    onclick="window.localStorage.plantab=4">Resources</a></li>
      <li><a href='#prompts'      onclick="window.localStorage.plantab=5">Prompts</a></li>
      <li><a href='#files'        onclick="window.localStorage.plantab=6">Files</a></li>
   </ul>


<div id='domains'>
<? $object='domain';
   include "tws_set_default_filter.php";
?>
</div>
<div id='workstations'>
<? $object='workstation';
   include "tws_set_default_filter.php";
?>
</div>
<div id='jobstreams'>
<? $object='jobstream';
   include "tws_set_default_filter.php";
?>
</div>
<div id='jobs'>
<? $object='job';
   include "tws_set_default_filter.php";
?>
</div>
<div id='resources'>
<? $object='resource';
   include "tws_set_default_filter.php";
?>
</div>
<div id='prompts'>
<? $object='prompt';
   include "tws_set_default_filter.php";
?>
</div>
<div id='files'>
<? $object='file';
   include "tws_set_default_filter.php";
?>
</div>

</div>
<? else:
// DATABASE
?>

<div id='tabs'>
   <ul>
      <li><a href='#domains'        onclick="window.localStorage.dbtab='0'">Domains</a></li>
      <li><a href='#workstations'   onclick="window.localStorage.dbtab='1'">Workstations</a></li>
      <li><a href='#workstation_classes' onclick="window.localStorage.dbtab='2'">Workstation Classes</a></li>
      <li><a href='#jobstreams'  onclick="window.localStorage.dbtab='3'">Jobstreams</a></li>
      <li><a href='#jobs'        onclick="window.localStorage.dbtab='4'">Jobs</a></li>
      <li><a href='#calendars'   onclick="window.localStorage.dbtab='5'">Calendars</a></li>
      <li><a href='#resources'   onclick="window.localStorage.dbtab='6'">Resources</a></li>
      <li><a href='#prompts'     onclick="window.localStorage.dbtab='7'">Prompts</a></li>
      <li><a href='#parameters'  onclick="window.localStorage.dbtab='8'">Parameters</a></li>
      <li><a href='#users'       onclick="window.localStorage.dbtab='9'">Users</a></li>
      <li><a href='#evrules'     onclick="window.localStorage.dbtab='10'">Event Rules</a></li>
   <? if ($tws_config['cpuinfo']['version']>='8.5')
         echo "<li><a href='#parameter_tables' onclick=\"window.localStorage.dbtab='11'\">Parameter Tables</a></li>";
      if ($tws_config['cpuinfo']['version']>='9.1')
         echo "<li><a href='#applications' onclick=\"window.localStorage.dbtab='12'\">Applications</a></li>";
      if ($tws_config['cpuinfo']['version']>='9.1')
         echo "<li><a href='#runcycles'   onclick=\"window.localStorage.dbtab='13'\">Run Cycles</a></li>"; ?>
   </ul>

<div id='domains'>
<? $object='dbdomain';
   include "tws_set_default_filter.php";
?>
</div>
<div id='workstations'>
<? $object='dbworkstation';
   include "tws_set_default_filter.php";
?>
</div>
<div id='workstation_classes'>
<? $object='dbworkstationclass';
   include "tws_set_default_filter.php";
?>
</div>

<div id='jobstreams'>
<? $object='dbjobstream';
   include "tws_set_default_filter.php";
?>
</div>
<div id='jobs'>
<? $object='dbjob';
   include "tws_set_default_filter.php";
?>
</div>
<div id='calendars'>
<? $object='dbcalendar';
   include "tws_set_default_filter.php";
?>
</div>
<div id='resources'>
<? $object='dbresource';
   include "tws_set_default_filter.php";
?>
</div>
<div id='prompts'>
<? $object='dbprompt';
   include "tws_set_default_filter.php";
?>
</div>

<div id='parameters'>
<? $object='dbparameter';
   include "tws_set_default_filter.php";
?>
</div>
<div id='users'>
<? $object='dbuser';
   include "tws_set_default_filter.php";
?>
</div>
<div id='evrules'>
<? $object='dbevrule';
   include "tws_set_default_filter.php";
?>
</div>
<?
if ($tws_config['cpuinfo']['version']>='8.5') {
   echo"<div id='parameter_tables'>";
   $object='dbparameter_table';
   include "tws_set_default_filter.php";
   echo "</div>\n";
}
if ($tws_config['cpuinfo']['version']>='9.1'){
   echo "<div id='applications'>\n";
   $object='dbapplication';
   include "tws_set_default_filter.php";
   echo "</div>\n";
}
if ($tws_config['cpuinfo']['version']>='9.1'){
   echo "<div id='runcycles'>\n";
   $object='dbruncycle';
   include "tws_set_default_filter.php";
   echo "</div>\n";
}
?>

</div>

<? endif; ?>
</body>
</html>