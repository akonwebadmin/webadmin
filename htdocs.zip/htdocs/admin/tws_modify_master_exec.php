<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Modify IWS/WebAdmin Master</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<?php
   tws_import_request_variables("P","rqst_");

   $mastername=tws_gpc_get($rqst_mastername, 'tws_alfanum');
   $orig_mastername=tws_gpc_get($rqst_orig_mastername, 'tws_alfanum');
   $href=tws_gpc_get($rqst_href, 'tws_file');
      tws_check_synchro_token();     // synchro_token

   if ($href == "# LOCAL #") {
      $href="#local";
   }

   $mastersxml="$maestro_dir/webadmin/etc/masters.xml";
   $mastersxmlbak="$maestro_dir/webadmin/etc/masters.xml.bak";

   if (!copy($mastersxml,$mastersxmlbak)) {
      tws_dyer("Unable to make backup copy of masters configuration file 'masters.xml'");
   }

   $fp=fopen($mastersxmlbak,"r") or tws_dyer("Unable to open $mastersxmlbak file");
   $fp2=fopen($mastersxml,"w") or tws_dyer("Unable to open $mastersxml file");

   while (!feof($fp)) {
      $buffer=fgets($fp,4096);
      if (substr($buffer,0,1) == "<") {
         $tok=strtok($buffer," >");
         if ($tok == "<master") {
            $file_href=strtok(">");
            $master_name=strtok("<");
            if ($master_name != $orig_mastername) {
               $num_bytes=fwrite($fp2,$buffer);
               if ($num_bytes < 0) {
                  fclose($fp);
                  fclose($fp2);
                  unlink($mastersxml);
                  copy($mastersxmlbak,$mastersxml);
                  tws_dyer("Unable to write 'masters.xml' file. Original file restored.");
               }
            } else {
               $num_bytes=fwrite($fp2,"<master href=\"$href\">$mastername</master>\n");
               if ($num_bytes < 0) {
                  fclose($fp);
                  fclose($fp2);
                  unlink($mastersxml);
                  copy($mastersxmlbak,$mastersxml);
                  tws_dyer("Unable to write 'masters.xml' file. Original file restored.");
               }
            }
         }
      }
   }
   fclose($fp);
   fclose($fp2);

   echo "<script language=\"Javascript\">\n";
   echo "window.location.replace(\"tws_masters_configuration.php\");\n";
   echo "</script>\n";
?>
</body>
</html>
