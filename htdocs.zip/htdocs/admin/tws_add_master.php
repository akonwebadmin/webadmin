<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add IWS/WebAdmin Master</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<h1>Add IWS/WebAdmin Master</h1>
<br><br>

   <form method="post" action="tws_add_master_exec.php">
   <table border=0 cellspacing=0>
   <tr>
   <td class=standard width=120>Master Name:</td>
   <td class=standard>
      <input type="text" name="mastername" class="tws_alfanum" required='required' size=20 maxlength=40></td>
   </tr>
   <tr><td>&nbsp;</td></tr>
   <tr>
   <td class=standard width=120>Web Server URL:</td>
   <td class=standard>
      <input type="text" name="href" class="tws_file" required='required' size=40 maxlength=100></td>
   </tr>

</table>
<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Add Master" name="action">&nbsp;&nbsp;
<input type="button" value="Cancel" onclick="window.location.replace('tws_masters_configuration.php');">
<? tws_print_synchro_token();     // synchro_token
?>
</form>
</body>
</html>
