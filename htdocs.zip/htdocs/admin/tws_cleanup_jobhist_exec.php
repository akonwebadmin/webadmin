<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Cleanup Job History Table</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>
<h1>Cleanup Job History Table</h1>
<br><br>

<?php
   tws_import_request_variables("P","rqst_");

   set_time_limit(600);

   $age_date=tws_gpc_get($rqst_age_date, 'tws_datetime');
      tws_check_synchro_token();  //    synchro_token

   db_connect($webadmin_db,DB_PERSISTENT) or tws_dyer("Could not connect to database");
   $schema = $webadmin_db['schema'];

   $query="DELETE FROM $schema.jobhist WHERE sched_date < '$age_date'";
   db_query($webadmin_db,$query) or tws_dyer("Database query failed");
   if (isset($webadmin_db['allow_persistent']) && tws_yesno($webadmin_db['allow_persistent'])=='NO')
      db_commit($webadmin_db) or tws_dyer("Unable to COMMIT request.");

   db_close($webadmin_db);
?>

&nbsp;&nbsp;&nbsp;&nbsp;Records Successfully deleted - <a href="tws_database_cleanup.php">Return to Database Cleanup</a>

</body>
</html>
