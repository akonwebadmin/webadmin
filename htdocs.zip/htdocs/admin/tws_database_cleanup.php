<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
   tws_profile('opener', basename($_SERVER['SCRIPT_NAME']) );

   $jobhist_age = (!empty($tws_config['jobhist_cleanup']) ? $tws_config['jobhist_cleanup'] : '90');
   $events_age = (!empty($tws_config['events_cleanup']) ? $tws_config['events_cleanup'] : '90');

?>
<html>
<head>
<title>Database Cleanup</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>
<h1>Database Cleanup</h1>
<br><br>
<form method="post" action="tws_cleanup_jobhist.php">
<table border=0 cellspacing=0>
<tr>
<td class=standard colspan=2>
<h3>Job History Table</h3>
</td>
</tr>
<tr>
<td class=standard width=200>
&nbsp;&nbsp;Delete Records older than:
</td>
<td class=standard>
<input type="text" name="jobhist_age" class="tws_num" required='required' size=6 maxlength=6>&nbsp;&nbsp;&nbsp;Days
</td>
</tr>

<tr>
   <td colspan='2'>
      The Job History Table is automatically cleaned up after <?=$jobhist_age?> days<br>
      This parameter may be changed in <a href = "tws_set_conf.php#main">WebAdmin Configuration</a> dialog
   </td>
</tr>
</table>
<br><br>
<?php
   $now=date('Y-m-d H:i:s');

   switch (strtolower($webadmin_db['type'])) {
      case 'db2' :
         $jobhist_query="SELECT DATE(sched_date) AS &quot;Schedule Date&quot;,(DAYS(TIMESTAMP('$now')) - DAYS(sched_date)) AS &quot;Age (Days)&quot;, COUNT(*) AS &quot;Number of Records&quot; FROM $webadmin_db[schema].jobhist GROUP BY sched_date ORDER BY sched_date ASC";
         $events_query="SELECT DATE(tstamp) AS &quot;Event Date&quot;,(DAYS(TIMESTAMP('$now')) - DAYS(DATE(tstamp))) AS &quot;Age (Days)&quot;, COUNT(*) AS &quot;Number of Records&quot; FROM $webadmin_db[schema].events WHERE event_id!=0 GROUP BY DATE(tstamp) ORDER BY DATE(tstamp) ASC";
         break;

      case 'oracle' :
         $jobhist_query="SELECT TO_CHAR(sched_date,'YYYY-MM-DD') AS &quot;Schedule Date&quot;, EXTRACT(DAY FROM (TO_TIMESTAMP('$now','YYYY-MM-DD HH24:MI:SS') - sched_date)) AS &quot;Age (Days)&quot;, COUNT(*) AS &quot;Number of Records&quot; FROM $webadmin_db[schema].jobhist GROUP BY sched_date ORDER BY sched_date ASC";
         $events_query="SELECT eventdate AS &quot;Event Date&quot;,EXTRACT(DAY FROM (TO_TIMESTAMP('$now','YYYY-MM-DD HH24:MI:SS') - TO_TIMESTAMP(eventdate,'YYYY-MM-DD'))) as &quot;Age (Days)&quot;, COUNT(*) AS &quot;Number of Records&quot; FROM (SELECT TO_CHAR(tstamp,'YYYY-MM-DD') AS eventdate FROM $webadmin_db[schema].events WHERE event_id!=0) GROUP BY eventdate ORDER BY eventdate ASC";
         break;

      case 'pgsql' :
         $jobhist_query="SELECT sched_date AS &quot;Schedule Date&quot;, FLOOR(EXTRACT(EPOCH FROM '$now' - sched_date) / 86400) AS &quot;Age (Days)&quot;,count(*) AS &quot;Number of Records&quot; FROM $webadmin_db[schema].jobhist GROUP BY sched_date ORDER BY sched_date ASC";
         $events_query="SELECT tstamp AS &quot;Event Date&quot;, FLOOR(EXTRACT(EPOCH FROM '$now' - tstamp) / 86400) AS &quot;Age (Days)&quot;, COUNT(*) AS &quot;Number of Records&quot; FROM $webadmin_db[schema].events GROUP BY tstamp ORDER BY tstamp ASC";
         break;
   }

?>

&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Delete Records" name="action">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="../tws_execute_db_query.php?title=yes&amp;titletext=Job History Records by Date&amp;query=<?=$jobhist_query?>&amp;records=ALL&amp;database=webadmin_db&amp;opennew=yes" target='_blank'>Show Job History Records by Date</a>
   <? tws_print_synchro_token();     // synchro_token ?>
</form>

<br>
<hr>
<br>

<form method=post action="tws_cleanup_events.php">
<table border=0 cellspacing=0>
<tr>
<td class=standard colspan=2>
<h3>Events Table</h3>
</td>
</tr>
<tr>
<td class=standard width=200>
&nbsp;&nbsp;Delete Records older than:
</td>
<td class=standard>
<input type="text" name="events_age" class="tws_num" required='required' size=6 maxlength=6>&nbsp;&nbsp;&nbsp;Days
</td>
</tr>
<tr>
   <td colspan='2'>
      The Events Table is automatically cleaned up after <?=$events_age?> days.<br>
      This parameter may be changed in <a href = "tws_set_conf.php#main">WebAdmin Configuration</a> dialog
   </td>
</tr>   </table>
<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Delete Records" name="action">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="../tws_execute_db_query.php?title=yes&amp;titletext=Event Records by Date&amp;query=<?=$events_query?>&amp;records=ALL&amp;database=webadmin_db&amp;opennew=yes" target='_blank'>Show Event Records by Date</a>
   <? tws_print_synchro_token();     // synchro_token ?>
</form>
</body>
</html>
