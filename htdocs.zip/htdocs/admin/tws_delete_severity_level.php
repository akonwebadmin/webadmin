<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Delete Event Severity Level</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<h1>Delete Event Severity Level</h1>
<br><br>

<?php
   tws_import_request_variables("P","rqst_");

   $severity_index=tws_gpc_get($rqst_severity_index, 'tws_num');
      tws_check_synchro_token();  //    synchro_token

// Do some error checking
   if (!isset($severity_index)) {
      die("<p class=warning>Error: No event severity level selected</p>\n</body>\n</html>\n");
   }

// Don't allow deletion of "base" severities (1-5)
   if (($severity_index >= 0) && ($severity_index <= 4)) {
      tws_warning("The standard severity levels 0-4 cannot be deleted");
      tws_dyer('', '', "tws_edit_severity_levels.php");
   }

   include($severities_file);
   unset($severity[$severity_index]);
   unset($color[$severity_index]);

   tws_save_severities($severity,$color);

   echo "<script language=\"Javascript\">\n";
   echo "window.location.replace(\"tws_edit_severity_levels.php\");\n";
   echo "</script>\n";
?>

</body>
</html>
