<?php
//   HORIZONT Software GmbH, Munich
//
// is always used as tab on set default filters page

require_once 'tws_rc_flt.php';
require_once '../tws_filters_lib.php';

$files = tws_get_filter_list($object, 'all_users', 'no');
foreach ($files as $f => $val )
   $$f = $val;

$default = array();
if(!empty($groupname) )
   $default[] = tws_get_default_filter($object, '', $groupname);
elseif(is_array($username))
   foreach($username as $user)
      $default[] = tws_get_default_filter($object, $user);
else $default[] = tws_get_default_filter($object, 'all_users');
?>

<h3>Available <?=$flt_object_title[$object]?> Filters:</h3>

<? if (empty($files['file_num'])) {
      echo "None";
      return;
   }
?>
<form name='content' method='post' action='tws_define_default_filters.php'>

      <table class='wireframe' id='sortable' cellspacing=0 cellpadding=4>
      <thead><tr class=header>
      <th> </th>
      <th>Filter Filename</th>
      <th>Description</th>
      <th>Default</th>
      <th>Filter</th>
      </tr></thead>
<?
      for ($i=1; $i<=$file_num; $i++) {
?>
         <tr>
         <td><input type='radio' name='selection' value='<?=$file[$i]?>'></td>
         <td><?=$file_stripped[$i]?></td>
         <td><?=$comment[$i]?></td>
         <td><?=(in_array( $selection[$i], $default) ? 'YES' : '')?></td>
         <td><?=$selection[$i]?></td>
         </tr>
<? } ?>
      </table>
      <br><br>
   <input type='hidden' name='groupname' value='<?=$groupname?>'>
   <?=tws_create_hidden_inputs($username, 'username');?>
   <input type='hidden' name='object' value='<?=$object?>'>
   <input type='submit' name='action' value='Set as Default'>
   <input type='button' name='action' value=' Ok ' onclick='window.location.replace("tws_user_administration.php<?=(empty($groupname)?'':'#groups')?>")'>
</form>