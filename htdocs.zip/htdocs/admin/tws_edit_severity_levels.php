<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Edit Event Severity Levels</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>
<?php
   tws_set_window_title();
   tws_print_head('Edit Event Severity Levels', 'tws_edit_severity_levels_help.php', '../');

   unset($severity);
// Get severities
   include($severities_file);
?>

<form method=post action="tws_edit_severity_levels_action.php">
<table class=wireframe cellspacing=0 cellpadding=4 width="300" cols=2>
<tr class=header>
<th class=wireframe>&nbsp;</th>
<th class=wireframe>Severity Label</th>
<th class=wireframe>Display Color</th>
</tr>
<?php
   foreach ($severity as $severity_num => $severity_label) {
      echo "<tr class=standard>\n";
      echo "<td class=wireframe><input type=\"radio\" name=\"severity_index\" value=\"$severity_num\"";
      if ($severity_num==0) echo " checked";
      echo ">\n";
      echo "<td class=wireframe>".htmlspecialchars($severity_label)."</td>\n";
      echo "<td class=wireframe style=\"background-color: $color[$severity_num]\">$color[$severity_num]</td>\n";
      echo "</tr>\n";
   }
?>
</table>

<br><br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" name="action" value="Add">&nbsp;&nbsp;
<input type="submit" name="action" value="Modify">&nbsp;&nbsp;
<input type="submit" name="action" value="Delete">&nbsp;&nbsp;
<input type="button" value="Cancel" onclick="window.location.replace('tws_event_configuration.php')">&nbsp;&nbsp;
<?  tws_print_synchro_token();  // synchro_token for delete
?>
</form>
</body>
</html>
