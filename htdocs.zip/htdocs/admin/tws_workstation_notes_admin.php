<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t"); 
?>
<html>
<head>
<title>Workstation Notes Administration</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<h1>Workstation Notes Administration</h1>

<?php
   tws_import_request_variables("GP","rqst_");

   $action=$rqst_action;
   
   if (isset($rqst_cpu) && trim($rqst_cpu)!='') {
      $cpu=strtoupper(trim($rqst_cpu));
      $filter=$cpu;
      tws_profile('notesadminfilter',$filter);
   } elseif (!isset($rqst_cpu) && $filter=tws_profile('notesadminfilter')) {
      $cpu=$filter;
   } else {
      tws_dyer("No objects selected");
   }

   if ($filter!="@") {
      tws_display_filterinfo($cpu);
   }

   if (!tws_workstation_notes_enabled()) tws_dyer("Workstation notes are not enabled");

   if (($notes=tws_get_notes($cpu,NULL))===FALSE) {
      tws_dyer("Error while querying 'notes' table");
   }

   if (count($notes) > 0) {

//group notes by cpu name
      $wkstnotes=array();
      foreach ($notes as $note) {
         $wkstnotes[$note['WORKSTATION']][] = $note;
      }
      unset($notes);

      switch ($action) {

      case "List Notes" :
         echo "<table class=wireframe cellspacing=0 cellpadding=4 width=\"100%\" cols=9>\n";
         echo "<tr class=header>\n";
         echo "<th class=wireframe>&nbsp;</th>\n";
         echo "<th class=wireframe>&nbsp;</th>\n";
         echo "<th class=wireframe>Created</th>\n";
         echo "<th class=wireframe>Last Updated</th>\n";
         echo "<th class=wireframe>Workstation</th>\n";
         echo "<th class=wireframe>Creator</th>\n";
         echo "<th class=wireframe>Title</th>\n";
         echo "<th class=wireframe>Note Type</th>\n";
         echo "</tr>\n";
         foreach ($wkstnotes as $wkstname=>$notes) {
            foreach ($notes as $note) {
               $tstamp=tws_iso_to_userdate($note['TSTAMP']);
               $last_updated=tws_iso_to_userdate($note['LAST_UPDATED']);
               $workstation=$note['WORKSTATION'];
               $username=$note['USERNAME'];
               $title=$note['TITLE'];
               $note_type=$note['NOTE_TYPE'];
               $urlparms="note_type=$note_type&amp;cpu=$workstation&amp;job=&amp;user=$username&amp;title=".urlencode($title)."&amp;action=$action";

               echo "<tr class=standard>\n";
               echo "<td class=code><a href=\"tws_edit_note.php?$urlparms\">Edit</a></td>\n";
               echo "<td class=code><a href=\"tws_delete_note.php?$urlparms\">Delete</a></td>\n";
               echo "<td class=code>$tstamp</td>\n";
               echo "<td class=code>$last_updated</td>\n";
               echo "<td class=code>$workstation</td>\n";
               echo "<td class=code>$username</td>\n";
               echo "<td class=code>$title</td>\n";
               echo "<td class=code>$note_type</td>\n";
               echo "</tr>\n";
            }
         }
         echo "</table>\n";
         break;

      case "View Notes" :
         foreach ($wkstnotes as $wkstname=>$notes) {

            echo "<h2>$wkstname</h2>\n";

            foreach ($notes as $note) {
               $tstamp=tws_iso_to_userdate($note['TSTAMP']);
               $last_updated=tws_iso_to_userdate($note['LAST_UPDATED']);
               $workstation=$note['WORKSTATION'];
               $username=$note['USERNAME'];
               $title=$note['TITLE'];
               $note_type=$note['NOTE_TYPE'];
               $note_text=$note['NOTE_TEXT'];
               $urlparms="note_type=$note_type&amp;cpu=$workstation&amp;job=&amp;user=$username&amp;title=".urlencode($title)."&amp;action=$action";

               echo "<table class=wireframe cellspacing=0 cellpadding=4 width=400 cols=2>\n";
               echo "<tr class=standard>\n";
               echo "<td class=noteheader colspan=2>$title&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[<a href=\"tws_edit_note.php?$urlparms\">Edit</a>]&nbsp;&nbsp;&nbsp;&nbsp;[<a href=\"tws_delete_note.php?$urlparms\">Delete</a>]</td>\n";
               echo "</tr>\n";
               echo "<tr class=standard>\n";
               echo "<td class=note width=\"100\">Creator</td>\n";
               echo "<td class=wireframe>$username</td>\n";
               echo "</tr>\n";
               echo "<tr class=standard>\n";
               echo "<td class=note width=\"100\">Created</td>\n";
               echo "<td class=wireframe>$tstamp</td>\n";
               echo "</tr>\n";
               echo "<tr class=standard>\n";
               echo "<td class=note width=\"100\">Last Updated</td>\n";
               echo "<td class=wireframe>$last_updated</td>\n";
               echo "</tr>\n";
               echo "<tr class=standard>\n";
               echo "<td colspan=2>\n";
               echo "<pre>$note_text</pre>\n";
               echo "</td>\n";
               echo "</tr>\n";
               echo "</table>\n";
               echo "<br>\n";
               $total_num_notes++;
            }
   
            echo "<br><br><br>\n\n";

         }
         break;
      }//switch
      
   } else {
      echo "<p class=warning>No Notes for selected workstation</p>\n";
   }
/*
   echo "<br><br>\n";
   echo "<form method=\"post\" action=\"tws_add_workstation_note.php\">\n";
   echo "<input type=\"hidden\" name=\"cpu\" value=\"$cpu\">\n";
   echo "<input type=\"submit\" name=\"action\" value=\"Add Note\">\n";
   echo "</form>\n";
*/
?>
</body>
</html>
