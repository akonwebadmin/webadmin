<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add Event Severity Level</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<h1>Add Event Severity Level</h1>
<br><br>

<form method=post action="tws_add_severity_level_exec.php">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Severity Label:&nbsp;&nbsp;
<input type="text" name="severity_label" class="tws_alfanum" required='required' size=20 maxlength=20>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Display Color:&nbsp;&nbsp;
<select name="color">
  <option style="background-color: red" value="red">Red</option>
  <option style="background-color: orange" value="orange">Orange</option>
  <option style="background-color: yellow" value="yellow">Yellow</option>
  <option style="background-color: green" value="green">Green</option>
  <option style="background-color: blue" value="blue">Blue</option>
  <option style="background-color: purple" value="purple">Purple</option>
  <option style="background-color: firebrick" value="firebrick">FireBrick</option>
  <option style="background-color: orangered" value="orangered">OrangeRed</option>
  <option style="background-color: darkorange" value="darkorange">DarkOrange</option>
  <option style="background-color: gold" value="gold">Gold</option>
  <option style="background-color: lime" value="lime">Lime</option>
  <option style="background-color: skyblue" value="skyblue">SkyBlue</option>
  <option style="background-color: mediumblue" value="mediumblue">MediumBlue</option>
  <option style="background-color: blueviolet" value="blueviolet">BlueViolet</option>
  <option style="background-color: darkviolet" value="darkviolet">DarkViolet</option>
  <option style="background-color: magenta" value="magenta">Magenta</option>
</select>

<br><br>

&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Add">&nbsp;&nbsp;
<input type="button" value="Cancel" onclick="window.location.replace('tws_edit_severity_levels.php')">
<?    tws_print_synchro_token();  // synchro_token
?>
</form>
</body>
</html>
