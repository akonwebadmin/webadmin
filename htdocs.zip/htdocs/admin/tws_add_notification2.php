<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
   $path = '../';

   if (@$modify!="yes") $modify="no";
?>
<html>
<head>
   <title><?=(@$modify=="yes" ? "Modify Alert" : "Add Alert")?></title>
   <?php tws_adminstylesheet(); ?>
   <script type="text/javascript" src="../tws_js_filters.js"></script>
</head>
<body>
<?php
   tws_set_window_title();
   tws_print_head((@$modify == 'yes' ? 'Modify Alert' : 'Add Alert'), 'tws_add_notification2_help.php', '../');

   tws_import_request_variables("GP", "rqst_");

   if ($modify=="yes") {
      if (!@$rqst_selection) {
         echo "<p class=warning>&nbsp;&nbsp;&nbsp;&nbsp;No alert selected</p>\n";
         echo "<form action=\"tws_alert_configuration.php\">\n";
         echo "<input type=\"submit\" value=\"Back\">\n";
         echo "</form>\n";
         echo "</body></html>\n";
         exit;
      } else {
         $selection = unserialize(urldecode($rqst_selection));
         tws_check_arg($selection['alert_id'], 'tws_num');
         tws_check_arg($selection['event_num'], 'tws_num');
      }
   }

   db_connect($webadmin_db, DB_PERSISTENT) or tws_dyer("Cannot connect to database");
   $schema = $webadmin_db['schema'];

// Get severities
   include($severities_file);

   if ($modify=="yes") {
   // TODO modify
      $query="SELECT event_num, severity, workstation, jobstream, job_workstation, job, logon, script, alert_type, recipient, email_text, command, description FROM $schema.alerts WHERE alert_id=$selection[alert_id]";
      db_query($webadmin_db,$query) or tws_dyer("Unable to retrieve alert data");
      $row=db_fetch_row($webadmin_db);
      if (!$row) {
         tws_dyer("Unable to retrieve informations about the alert");
      }
      $selection['event_num']       = $row['EVENT_NUM'];
      $selection['severity']        = $row['SEVERITY'];
      $selection['workstation']     = $row['WORKSTATION'];
      $selection['jobstream']       = $row['JOBSTREAM'];
      $selection['job_workstation'] = $row['JOB_WORKSTATION'];
      $selection['job']             = $row['JOB'];
      $selection['logon']           = $row['LOGON'];
      $selection['script']          = $row['SCRIPT'];
      $selection['alert_type']      = $row['ALERT_TYPE'];
      $selection['recipient']       = $row['RECIPIENT'];
      $selection['email_text']      = $row['EMAIL_TEXT'];
      $selection['command']         = $row['COMMAND'];
      $selection['description']     = $row['DESCRIPTION'];

      $twa_meta='';

      $selection['description']=preg_replace_callback('/<!--TWA_METADATA--.*--TWA_METADATA-->/',create_function('$matches','global $twa_meta; $twa_meta=$matches[0]; return "";'),$selection['description']);

      if ($twa_meta!='') {
         if (preg_match('!<EMAIL_SUBJ>(.*)</EMAIL_SUBJ>!',$twa_meta,$_r)) {
            $selection['email_subj']=$_r[1];
         }
      }

      $event_num = $selection['event_num'];
      if ($selection['event_num']>0) {
         require_once($event_types_file);
      }

      if ($selection['alert_type']=='COMMAND') $filter_type='expert_radio';
      else $filter_type='basic_radio';
   } else {
      $filter_type='basic_radio'; //$rqst_filter_type;
   }
?>

<form name="contents" method="post" action="tws_add_notification_exec.php">
<table border=0 cellspacing=0>
<tr>
<td class=standard colspan="2">
<h2>Event Information</h2>
</td>
</tr>
<tr>
<td class=standard>
&nbsp;&nbsp;<b>Event Type:</b>
</td>
<td><select name="event_type">
<?php
   if ($modify!="yes") {
      $event_num=strtok($rqst_event_type,"_");
      $event_type=strtok("\n");
      echo "  <option value=\"$event_num\" selected>" . strtok($event_type,"_") . "</option>\n";
   } else {
      if( $selection['event_num'] > 0 ){
         foreach( $event_type as $key=>$value ){
            if ($key==$event_num)
               echo "  <option value=\"$key\" selected>".htmlspecialchars($value)."</option>";
         }
      } else {
         echo "  <option value=\"0\" selected>Severity</option>\n";
      }
   }
?>
  </select>
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<?php
   if ($event_num == 0) {
?>
<tr>
<td class=standard>
&nbsp;&nbsp;<b>Severity:</b>
</td>
<td>
<select name="severity">
<?php
   foreach ($severity as $severity_key => $severity_label) {
      echo "<option value=\"$severity_key\"".($selection['severity']==$severity_key ? "selected" : "").">".htmlspecialchars($severity_label)."</option>\n";
   }
?>
</td>
</tr>
<?php
//TODO: use function to determine the event type (job/jobstream/others)
   } elseif (intval($event_num)>=100 && intval($event_num<=200) || intval($event_num)==1001) {
?>
<tr>
<td class=standard>
&nbsp;&nbsp;<b>Workstation:</b>
</td>
<td>
<input type="text" name="workstation" class="tws_mask" size=16 maxlength=16 value="<?=htmlspecialchars($selection['workstation'])?>">
&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" name="workstation_list" onClick="tws_picker_open('../workstation_picker.php', 'fieldname=workstation&amp;fieldvalue='+document.contents.workstation.value);" value="List">
</td>
</tr>
<tr>
<td class=standard>
&nbsp;&nbsp;<b>Jobstream:</b>
</td>
<td>
<input type="text" name="jobstream" class="tws_mask" size=50 maxlength=128 value="<?=htmlspecialchars($selection['jobstream'])?>">
&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" name="jobstream_list" onClick="tws_picker_open('../jobstream_picker.php', 'fieldname=jobstream&amp;fieldvalue='+document.contents.jobstream.value+'&amp;cpux=' + document.contents.workstation.value);" value="List">
</td>
</tr>

<?php
//job events
//TODO: use function to determine the event type (job/jobstream/others)
      if (intval($event_num)>=101 && intval($event_num)<=150 || intval($event_num)==1001) {
?>

<tr>
<td class=standard>
&nbsp;&nbsp;<b>Job Workstation:</b>
</td>
<td>
<input type="text" name="job_workstation" class="tws_mask" size=16 maxlength=16 value="<?=htmlspecialchars($selection['job_workstation'])?>">
&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" name="job_workstation_list" onClick="tws_picker_open('../workstation_picker.php', 'fieldname=job_workstation&amp;fieldvalue='+document.contents.job_workstation.value);" value="List">
</td>
</tr>
<tr>
<td class=standard>
&nbsp;&nbsp;<b>Job:</b>
</td>
<td>
<input type="text" name="job" class="tws_mask" size=40 maxlength=255 value="<?=htmlspecialchars($selection['job'])?>">&nbsp;&nbsp;&nbsp;&nbsp;
<input type="button" name="job_list" onClick="tws_picker_open('../job_picker.php', 'fieldname=job&amp;fieldvalue='+document.contents.job.value+'&amp;cpux='+document.contents.job_workstation.value);" value="List">
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class=standard>
&nbsp;&nbsp;<b>Logon:</b>
</td>
<td>
<input type="text" name="logon" size=32 maxlength=32 value="<?=@htmlspecialchars($selection['logon'])?>">
</td>
</tr>
<tr>
<td class=standard>
&nbsp;&nbsp;<b>Script:</b>
</td>
<td>
<input type="text" name="script" size=64 maxlength=255 value="<?=@htmlspecialchars($selection['script'])?>">
</td>
</tr>

<?php
      }
   }
?>

<tr><td>&nbsp;</td></tr>
<tr><td>&nbsp;</td></tr>

<tr>
<td class=standard colspan="2">
<h2>Alert Configuration</h2>
</td>
</tr>
</table>
<fieldset>
<legend><input id="basic_radio" type="radio" name="filter_type" style="margin: 0 5px 0 0; padding: 0" value="basic" onclick="changeDisabling(this);" /> E-mail</legend>
<div id="basic">
<table border=0 cellspacing=0>
<tr>
<td class=standard width=120>
&nbsp;&nbsp;<b>Recipient:</b>
</td>
<td>
<input type="text" name="recipient" size=64 maxlength=255 value="<?=@htmlspecialchars($selection['recipient'])?>">
</td>
</tr>
<tr>
<td class=standard width=120>
&nbsp;&nbsp;<b>Custom&nbsp;Subject:</b><br>&nbsp;&nbsp;&nbsp;<i>(optional)</i>
</td>
<td>
<input type="text" name="subject" size=64 maxlength=500 value="<?=$selection['email_subj']; /*email_subject is already stored in html format*/?>">
</td>
</tr>
<tr>
<td class=standard width=120 valign="top">
<br>&nbsp;&nbsp;<b>Custom</b><br>&nbsp;&nbsp;<b>Email&nbsp;Text:</b><br>&nbsp;&nbsp;&nbsp;<i>(optional)</i>
</td>
<td>
<textarea name="email_text" cols="80" rows="6" wrap="soft"><?=@htmlspecialchars($selection['email_text'])?></textarea>
</td>
</tr>
</table>
</div>
</fieldset>
<fieldset>
<legend><input id="expert_radio" type="radio" name="filter_type" style="margin: 0 5px 0 0; padding: 0;" value="expert" onclick="changeDisabling(this);" /> Command</legend>
<div id="expert">
<table border=0 cellspacing=0>
<tr>
<td class=standard width=120>
&nbsp;&nbsp;<b>Command:</b>
</td>
<td>
<input type="text" name="command" size=64 maxlength=255 value="<?=@htmlspecialchars($selection['command'])?>">
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class=standard width=120 valign="top">
<br>&nbsp;&nbsp;<b>Description:</b>
<br>
&nbsp;&nbsp;&nbsp;<i>(optional)</i>
</td>
<td>
<textarea name="description" cols="80" rows="5" wrap="soft"><?=@htmlspecialchars($selection['description'])?></textarea>
</td>
</tr>
</table>
</div>
</fieldset>
<br><br>

<input type="hidden" name="modify" value="<?=htmlspecialchars($modify)?>"/>
<input type="hidden" name="alert_id" value="<?=( $modify=="yes" ? htmlspecialchars($selection['alert_id']) : "0")?>"/>

&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="<?=( $modify=="yes"  ? "Update" : "Submit" )?>">&nbsp;&nbsp;
<input type="button" value="Cancel" onclick="window.location.replace('tws_alert_configuration.php');">
<?   tws_print_synchro_token();  // synchro_token
?>
</form>
<script type="text/javascript">
   changeDisabling(document.getElementById('<?=$filter_type?>'));
</script>
</body>
</html>
