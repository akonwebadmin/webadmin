<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
   $filter_type='basic_radio';
?>
<html>
<head>
<title>Add Alert</title>
<?php tws_adminstylesheet(); ?>
<script type="text/javascript">
function add_page2(event_type_select) {
   open("tws_add_notification2.php?event_type=" + event_type_select,"_self");
}
</script>
</head>
<body>
<?php
   tws_set_window_title();
   tws_print_head('Add Alert', 'tws_add_notification2_help.php', '../');

   //$event_types_file included from etc/tws_config.php
   require_once($event_types_file);
?>

<form name="type_select" method="post" action="tws_add_notification_exec.php">
<table border=0 cellspacing=0>
<tr>
<td class=standard colspan="2">
<h3>Event Information</h3>
</td>
</tr>
<tr>
<td class=standard width=120>
&nbsp;&nbsp;<b>Event Type:</b>
</td>
<td><select name="event_type" onchange="add_page2(document.type_select.event_type.options[document.type_select.event_type.selectedIndex].value)">
  <option selected value="-- Select One --">-- Select One --
  <option value="0_Severity">Severity</option>
<?php
//$event_type included from $event_types_file
   foreach ($event_type as $key=>$val) {
      echo "  <option value=\"".$key."_".$val."\">$val</option>\n";
   }
?>
  </select>
</td>
</tr>
</table>
</form>
<br><br>
&nbsp;&nbsp;<input type="button" value="Cancel" onclick="window.location.replace('tws_alert_configuration.php');">
</body>
</html>
