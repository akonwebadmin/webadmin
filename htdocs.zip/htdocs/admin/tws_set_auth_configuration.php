<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Save Authentication Configuration</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<h1>Save Authentication Configuration</h1>
<br><br>

<?php
   tws_import_request_variables("P","rqst_");

   @$authtype_option=tws_gpc_get($rqst_authtype_option, 'tws_name');
   @$lockout_option=tws_gpc_get($rqst_lockout_option, 'tws_name');
   $lockout_attempts=tws_gpc_get($rqst_lockout_attempts, 'tws_num');
   @$authusers_option=tws_gpc_get($rqst_authusers_option, 'tws_name');
   @$authldapurl=$rqst_authldapurl;
   tws_check_synchro_token();     // synchro_token

   if ($confirm_status!='confirmed') {

      switch ($authtype_option) {

//ldap extra tests
         case "ldap";
            if (extension_loaded('ldap') && function_exists('ldap_connect') && function_exists('ldap_bind')) {
               if (preg_match('/^(\w+):\/\/([^: \/]+)(:\d+)?/', $authldapurl, $_r)) {
                  $ldap_type=$_r[1];
                  $ldap_host=$_r[2];
                  $ldap_port=$_r[3];

                  $ldap=$ldap_type.'://'.$ldap_host.$ldap_port;
                  if (!($ds=@ldap_connect($ldap)) || !@ldap_bind($ds)) {
                     $confirm_status='require';
                     tws_err("WARNING: Unable to connect to the LDAP server on $ldap.", array('authldapurl'=>$authldapurl, 'ldap'=>$ldap, 'ldap_error'=>ldap_error($ds)));
                  }
               } else {
                  $confirm_status='require';
                  tws_err("WARNING: Unknown format of LDAP URL specified.", array('authldapurl'=>$authldapurl));
               }
            } else {
               $confirm_status='require';
               tws_err("WARNING: Cannot verify the AuthLDAPUrl address. LDAP extensionof LDAP not loaded.");
            }

            if ($confirm_status=='require') {
               echo "<p class=warning>IWS/WebAdmin was not successfull with testing accessibility of the specified LDAP server. You can still continue to switch to LDAP authentication method, but be aware of the possible unavailability of the IWS/WebAdmin webserver. Fatal problems with LDAP athentication can cause lack of all other authenication methods (i.e. Apache file authentication), su manual correction of the <i>$base_inst_dir/httpd/conf/auth.conf</i> will be neccessary.</p>\n";
            }
            break;
         case "apache":
            echo "<p class=warning>The Apache authentication mode accepts only users defined in its internal database (unless manually customized), see the user database at the <a href='tws_user_administration.php'>User Administration dialog</a>.  Check the list of defined users is complete and their passwords are correct before switching the authentication type.
            </p>\n";
            $confirm_status='require';
            $authusers_file="$base_inst_dir/httpd/conf/authusers";
            $authgroups_file="$base_inst_dir/httpd/conf/authgroups";
            $authusers = array();
            $admins = array();

            // Users from authusers file
            $fp=fopen($authusers_file,"r");
            if ($fp) {
               while ($buffer = fgets($fp,4096)) {
                  $username = strtok($buffer,":");
                  $authusers[] = $username;
               }
               fclose($fp);
            }
            else tws_err("Can't open '$authusers_file' file");
            if(empty($authusers)){
               $confirm_status='require';
               echo "<p class=warning>There are no users defined in the Apache user database. It is stronlgy recommended to add some users accounts before switching to Apache authentication at the <a href='tws_user_administration.php'>User Administration dialog</a>.
               </p>\n";
               break;
            }
            
            // Apache Groups
            $fp=fopen($authgroups_file,"r");
            if ($fp) {
               while ($buffer=fgets($fp,4096)) {
                  $group=strtok($buffer,":");
                  if($group == 'admin'){     // get admin users
                     $members=trim(strtok(":"));
                     $members=explode(" ",$members);
                     foreach ( $members as $member) 
                        $admins[] = $member;
                  }
               }
               fclose($fp);
            }
            else tws_err("Can't open '$authgroups_file' file");
            
            $intersect = array_intersect($authusers, $admins);
            if(empty($intersect)){
               $confirm_status='require';
               echo "<p class=warning>No IWS/WebAdmin administation account is defined in the Apache user database. It is recommended to make some Apache's user a member of the Admin group to keep access to the IWS/WebAdmin administration section after switching to the Apache authentication at the <a href='tws_user_administration.php'>User Administration dialog</a>.
               </p>\n";
               break;
            }
            break;

      }//switch

      if ($confirm_status=='require') {
         echo "<p>Click the button <b>Continue</b> in case you want to set the new authenitcation method, or <b>Back</b> if you want to return on the previous screen without any modification.</p>\n";
         echo "<form method=\"post\" name=\"contents\" action=\"tws_auth_configuration_action.php\">\n";
         echo "<input type=\"hidden\" name=\"authtype\" value='".htmlspecialchars($authtype_option)."'>\n"; //!
         echo "<input type=\"hidden\" name=\"authtype_option\" value='".htmlspecialchars($authtype_option)."'>\n";
         echo "<input type=\"hidden\" name=\"lockout_option\" value='".htmlspecialchars($lockout_option)."'>\n";
         echo "<input type=\"hidden\" name=\"lockout_attempts\" value='".htmlspecialchars($lockout_attempts)."'>\n";
         echo "<input type=\"hidden\" name=\"lockout\" value='".htmlspecialchars($lockout_attempts)."'>\n"; //!
         echo "<input type=\"hidden\" name=\"authusers_option\" value='".htmlspecialchars($authusers_option)."'>\n";
         echo "<input type=\"hidden\" name=\"use_authusers\" value='".htmlspecialchars($authusers_option)."'>\n"; //!
         echo "<input type=\"hidden\" name=\"authldapurl\" value='".htmlspecialchars($authldapurl)."'>\n";
         echo "<input type=\"submit\" name=\"action\" value=\"Back\">\n";
         echo "<input type=\"submit\" name=\"action\" value=\"Continue\">\n";
         tws_print_synchro_token();     // synchro_token
         echo "</form>\n";
         echo "</body></html>";
         exit;
      }
   }

// Set and check httpd/conf/auth.conf filenames
   $src_filename="$base_inst_dir/httpd/conf/auth.conf.$authtype_option";
   $dst_filename="$base_inst_dir/httpd/conf/auth.conf";
   $bak_filename="$base_inst_dir/httpd/conf/auth.conf-".date('Ymd_His').".bak";

   if (!file_exists($src_filename)) {
      tws_dyer("Unable to locate the template $src_filename. Cannot install the authentication method.");
   }

// Begin modify webadmin/etc/authconf.php file
   $filename="$base_inst_dir/etc/authconf.php";
   $bakfilename="$base_inst_dir/etc/authconf-".date('Ymd_His').".bak";

   if (file_exists("$filename")) {
      if ($host_os == "win32") {
         if (file_exists($bakfilename)) {
            unlink($bakfilename);
         }
         if (!copy($filename,$bakfilename)) {
            tws_dyer("Unable to copy $filename to $bakfilename.");
         }
         if (!unlink($filename)) {
            tws_dyer("Unable to delete $filename.");
         }
      } else {
         if (!rename($filename,$bakfilename)) {
            tws_dyer("Unable to move $filename to $bakfilename");
         }
      }
   }
   $dstfp=fopen($filename,"w") or tws_dyer("Unable to write file $filename");
   fwrite($dstfp,"<?php\n");
   fwrite($dstfp,"\$authtype=\"$authtype_option\";\n");
   if (($authtype_option == "os") && ($lockout_option == "yes")) {
      if ($lockout_attempts != "") {
         fwrite($dstfp,"\$lockout=\"$lockout_attempts\";\n");
      }
   }
   if (($authtype_option == "os") && ($authusers_option == "yes")) {
      fwrite($dstfp,"\$use_authusers=\"yes\";\n");
   }
   fwrite($dstfp,"?>\n");
   fclose($dstfp);
// End modify authconf.php file


// Begin swap httpd/conf/auth.conf file
   //Backup the current configuration first
   if ($host_os == "win32") {
      if (file_exists($bak_filename)) {
         unlink($bak_filename);
      }
   }
   if (!copy($dst_filename,$bak_filename)) {
      tws_err("Warning: Cannot write backup of the current authentication configuration ($dst_filename -> $bak_filename).");
   }

// Copy the new auth type template to the auth.conf
   if ($host_os == "win32") {
      if (file_exists($dst_filename)) {
         unlink($dst_filename);
      }
   }
   if (!copy($src_filename,$dst_filename)) {
      tws_dyer("Unable to copy template $src_filename to $dst_filename. New authentication method was not set up completelly.");
   }

//install new auth.conf file
   $authconf=file($dst_filename) or tws_dyer("Unable to configure authentication method.");
   foreach($authconf as $key=>$row) {
      if (preg_match('/^\s*#/', $row)) continue; //skip comments
      $row=preg_replace('/<MAESTRO_HOME>/', preg_replace('/[\/]?webadmin[\/]*$/i','',$base_inst_dir ), $row);
      $row=preg_replace('/<LDAP_URL>/', $authldapurl, $row);
      $authconf[$key]=$row;
   }
   $fp_authconf=fopen($dst_filename,'w') or tws_dyer("Unable to write configuration of the authentication method");
   fwrite($fp_authconf, implode('',$authconf)) or tws_dyer("Unable to write configuration of the authentication method");
   fclose($fp_authconf);

// End swap httpd/conf/auth.conf file
   echo "<p class=\"info\">Authentication configuration saved. Changes will not take effect until the IWS/WebAdmin HTTPD service is stopped and restarted.</p>\n";
?>
<br><br>
<a href="tws_auth_configuration.php">Return to Authentication Configuration</a>
</body>
</html>
