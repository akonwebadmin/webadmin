<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');
?>
<html>
<head>
   <title>IWS Event Configuration Help</title>
   <?php tws_adminstylesheet(); ?>
</head>
<body class=help>
<?php
   tws_set_window_title();
   $path = '../';
   include $path.'tws_help_topbar.php';
?>
<h1 class=help>IWS Event Configuration Help</h1>
<p>The IWS Event Configuration page is used to define which events are captured by IWS/WebAdmin, and to set a severity level for each event type.
<p>To enable an event, mark the checkbox to the left of the event, and select a severity level from the drop-down menu on the right. The default severity for each event type is marked with an asterisk (*). When finished, click the <strong>Save</strong> button to save the configuration.
<p>Click the <strong>Custom Events</strong> button to go to the Custom Events Configuration page, where custom severity levels can be set for specific events.
<p>Click the <strong>Edit Severity Levels</strong> button to go to the Edit Event Severity Levels page, where severity levels can be added or modified.
</body>
</html>
