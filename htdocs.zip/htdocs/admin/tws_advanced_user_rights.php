<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');
?>
<html>
<head>
   <title>Advanced User Rights</title>
   <?php tws_adminstylesheet(); ?>

<script type="text/javascript">

   function goback() {
window.location.replace("tws_user_administration.php");
}
</script>

</head>
<body>
<?php
   tws_import_request_variables('GP','rqst_');

// ********  Actions   ******** //
if (urldecode($rqst_action) == 'Use Group Default Values') {
   $username = urldecode($rqst_username);
   $username = tws_gpc_get($username, 'tws_alfanum\\tws_alfanum', '\\');
   $selection[0] = $username;
   if(isset($username) && trim($username)!='')
      $set_rights = tws_get_group_rights($username);
}
elseif (urldecode($rqst_action) == 'Use Default Values') {
   $username = urldecode($rqst_username);
   $username = tws_gpc_get($username, 'tws_alfanum\\tws_alfanum', '\\');
   $selection[0] = $username;
   if ( isset($username) && trim($username)!='' )
      $set_rights = tws_get_default_rights($username);
}

   $using_defaults=FALSE;     // User have no own settings
   $using_group_defaults=FALSE;     // User have no group settings
   $using_custom_rights = FALSE;    // User have no custom settings

// Header
   if ($rqst_default_user_rights=='yes') {
      $default_user_rights=TRUE;             // Set rights for all !!!
      $username='';
      tws_print_head('Default Advanced User Rights', '', '../');
   }
   else {
      if ( !isset($selection) || count($selection)==0 ) {
         tws_dyer('No user selected', "", "tws_user_administration.php");
      }
      $cnt = count($selection);
      if($cnt>1){
         tws_print_head('Advanced User Rights for selected users : ', '', '../');
         echo '<p class=warning>Multiply users selected. Layout settings starts with the default layout. Settings for all selected users will be overwriten.</p>',"\n";
         foreach($selection as $user){
            $group = tws_groupname($user);
            if ($group == 'admin')
               tws_dyer("Some user selected is administrator. Administrator's rights can't be changed.", "", "tws_user_administration.php");
         }
      }
      else {
       $username = $selection[0];
       $groupname = tws_groupname($username);
       if( $groupname == '' )
          tws_print_head('Advanced User Rights : '.htmlspecialchars($username), '', '../' );
       else
          tws_print_head('Advanced User Rights : '.htmlspecialchars($username) . " (". htmlspecialchars($groupname) ." Group)",'','../');
       if ($groupname == 'admin')
          tws_dyer("User has administrator's rights.", "", "tws_user_administration.php");
      }
      $default_user_rights=FALSE;
   }


//Read Rights
   if (file_exists($base_inst_dir.'/etc/usersec.php')) {
      include $base_inst_dir.'/etc/usersec.php';
   }
   if (!isset($default_rights)) { //$default_rights is (should be)  defined in the usersec.php
      $default_rights='abcdefghijklmnopqrt'; //factory settings
   }

   if ($default_user_rights) {            // for all - set default flags
     $rights['']=$default_rights; //factory settings
     if(isset($default_limit))
         $limit = $default_limit;
      else $limit = 0;
   }
   elseif($cnt==1) {
      if (!isset($rights[$username])) {
         if (isset($group_rights[$groupname])) {     // if exist group rights
            $using_group_defaults = TRUE;
            $rights[$username]=$group_rights[$groupname];
         }
         else {
            $using_defaults=TRUE;
            $rights[$username]=$default_rights;
         }
      }
      else {
         $using_custom_rights = TRUE;
      }
   }
   else{
      $username = '';
      $rights['']=$default_rights;
      $using_defaults=TRUE;
   }

   if(isset($set_rights)) {
      $rights[$username] = $set_rights;
   }

//build the array of rights from the rights string
   for ($i=0; $i<strlen($rights[$username]); $i++) {
      $right[$rights[$username]{$i}]=1;
   }
?>
<form method="post" action="tws_save_advanced_user_rights.php">
<h3> Plan</h3>
&nbsp;&nbsp;<label><input type="checkbox" name="right[a]" value="1"<?php if (isset($right['a'])) echo " checked" ?>/> View Job Output</label><br>
&nbsp;&nbsp;<label><input type="checkbox" name="right[b]" value="1"<?php if (isset($right['b'])) echo " checked" ?>/> Save Filters</label><br>
&nbsp;&nbsp;<label><input type="checkbox" name="right[c]" value="1"<?php if (isset($right['c'])) echo " checked" ?>/> Generate Forecasts</label><br>
<h3> Notes</h3>
&nbsp;&nbsp;<label><input type="checkbox" name="right[d]" value="1"<?php if (isset($right['d'])) echo " checked" ?>/> View Notes</label><br>
&nbsp;&nbsp;<label><input type="checkbox" name="right[e]" value="1"<?php if (isset($right['e'])) echo " checked" ?>/> Create / Modify Notes</label><br>
<h3> Reports</h3>
&nbsp;&nbsp;<label><input type="checkbox" name="right[f]" value="1"<?php if (isset($right['f'])) echo " checked" ?>/> Generate Reports</label><br>
&nbsp;&nbsp;<label><input type="checkbox" name="right[q]" value="1"<?php if (isset($right['q'])) echo " checked" ?>/> Generate SQL Query Reports</label><br>
&nbsp;&nbsp;<label><input type="checkbox" name="right[g]" value="1"<?php if (isset($right['g'])) echo " checked" ?>/> Save Reports</label><br>
&nbsp;&nbsp;<label><input type="checkbox" name="right[h]" value="1"<?php if (isset($right['h'])) echo " checked" ?>/> Store Reports</label><br>
<h3> Log / Alert</h3>
&nbsp;&nbsp;<label><input type="checkbox" name="right[i]" value="1"<?php if (isset($right['i'])) echo " checked" ?>/> View Events with Event Monitor</label><br>
&nbsp;&nbsp;<label><input type="checkbox" name="right[l]" value="1"<?php if (isset($right['l'])) echo " checked" ?>/> View Audit Logs</label><br>
<h3> Miscellaneous</h3>
&nbsp;&nbsp;<label><input type="checkbox" name="right[p]" value="1"<?php if (isset($right['p'])) echo " checked" ?>/> Change Password</label> (User can change own password)<br>
&nbsp;&nbsp;<label><input type="checkbox" name="right[t]" value="1"<?php if (isset($right['t'])) echo " checked" ?>/> Hide Advanced Options</label><br>
&nbsp;&nbsp;<label><input type="checkbox" name="right[s]" value="1"<?php if (isset($right['s'])) echo " checked" ?>/> Save for all users</label><br>
<? if ($default_user_rights){ ?>
&nbsp;&nbsp;<label><input type="checkbox" name="right[w]" value="1"<?php if (isset($right['w'])) echo " checked" ?>/> Always save backups</label><br>
&nbsp;&nbsp;Returned Results Limit: <input type="text" name="default_limit" value="<?=$limit?>" size=10>&nbsp;&nbsp;(For Flexible Tables only. 0 ≡ unlimited)<br>
<? } ?>
<input type="hidden" name="username" value="<?=htmlspecialchars($username);?>"/>
<input type="hidden" name="defaults_rights" value="<?=$default_rights;?>"/>
<?php echo tws_create_hidden_inputs($selection, 'selection', null); ?>
<br/>
<?php
// ******* Massages ********* //
   if ($default_user_rights) {
      echo '<p class=warning>You are currently modifying the default user rights settings. Saving will affect all users who don\'t have a custom profile.</p>',"\n";
   }
   elseif($cnt==1) {
      if ($groupname == 'admin' && $using_custom_rights == FALSE) {
         echo "<p class=warning>User currently has default rights (admin group) - Saving will create a custom profile for the user.</p>\n";
      }
      elseif ($using_defaults == TRUE) {
         echo '<p class=warning>User currently has default rights - Saving will create a custom profile for the user.</p>',"\n";
      }
      elseif ($using_group_defaults) {
         echo "<p class=warning>User currently has <a href='tws_advanced_group_rights.php?action=Advanced Group Rights&selection=$groupname'>$groupname group rights</a> - Saving will create a custom profile for the user.</p>\n";
      }
      else {
         echo '<p class=warning>User already has a custom profile.</p>',"\n";
         $using_custom_rights = TRUE;
      }
   }
// ******* Buttons ********* //
   if (!$default_user_rights) {
      if (!$using_defaults) {
         echo "<input type='submit' value='Use Default Values' name='action'>&nbsp;\n";
      }
      if ( $groupname!='' && $groupname!='admin' && $using_group_defaults == FALSE ) {
         echo "<input type='submit' value='Use Group Default Values' name='action'>&nbsp;\n";
      }
      if ( $using_custom_rights || $cnt>1) {
         echo "<input type='submit' value='Remove Custom Profile' name='action'>&nbsp;\n";
      }
   }
?>
<br><br>
<input type="submit" value="Save Changes" name="action">&nbsp;
<?
if ($default_user_rights)
echo"<input type='Button' name='action' value='Cancel' onClick='window.location.replace(\"tws_user_administration.php#defaults\");'>&nbsp;";
else
echo"<input type='Button' name='action' value='Cancel' onClick='window.location.replace(\"tws_user_administration.php\");'>&nbsp;";
   tws_print_synchro_token();     // synchro_token
?>
</form>
</body>
</html>
<?php

function tws_remove_custom_rights ($username) {
   global $base_inst_dir;

   $usersec = $base_inst_dir."/etc/usersec.php";
   $newusersec=$usersec . ".tmp";
   $bakusersec=$usersec . ".bak";

   $fp=fopen($usersec,"r") or tws_dyer("Unable to open file '$usersec'", "", "tws_user_administration.php");
   $newfp=fopen($newusersec,"w") or tws_dyer("Unable to open file '$newusersec'", "", "tws_user_administration.php");
   $str = "['".$username."']";
   while (!feof($fp)) {
      $buffer=fgets($fp,4096);
      if ( strpos($buffer, $str) === false ) {
         fputs($newfp, $buffer);
      }
   }

   fclose($fp);
   fclose($newfp);

   copy($usersec,$bakusersec) || tws_dyer("Unable to make backup copy of user rights configuration file", "src=$usersec, target=$bakusersec", "tws_user_administration.php");
   copy($newusersec,$usersec) || tws_dyer("Unable to copy user rights configuration file", "src=$newusersec, target=$usersec", "tws_user_administration.php");
   unlink($newusersec);
}

function tws_get_group_rights($username) {
   global $base_inst_dir;

   $usersec = $base_inst_dir."/etc/usersec.php";
   if (file_exists($usersec)) {
      include $usersec;
   }
   else { tws_dyer("Unable to open file $usersec", "", "tws_user_administration.php"); }

   $groupname = tws_groupname ($username);
   if( isset($group_rights[$groupname]) ) {
      $str_rights=$group_rights[$groupname];
   }
   else {
      $str_rights=$default_rights;
   }
  return $str_rights;
}

function tws_get_default_rights() {
   global $base_inst_dir;

   $usersec = $base_inst_dir."/etc/usersec.php";
   if (file_exists($usersec)) {
      include $usersec;
   }
   else { tws_dyer("Unable to open file $usersec", "", "tws_user_administration.php"); }

  $str_rights=$default_rights;
  return $str_rights;
}

?>
