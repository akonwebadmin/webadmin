<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Delete Custom Event</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>
<?php
   tws_import_request_variables("P","rqst_");

   $event_num=tws_gpc_get($rqst_event_num, 'tws_num');
      tws_check_synchro_token();  //    synchro_token

   include($custom_events_file);

   unset($custom_event[$event_num]);

   tws_save_custom_events($custom_event);
?>
<script type="text/javascript">
   window.location.replace("tws_custom_events.php");
</script>
</body>
</html>
