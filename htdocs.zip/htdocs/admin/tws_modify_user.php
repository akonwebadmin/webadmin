<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
   if (file_exists("$base_inst_dir/etc/authconf.php")) {
      include("$base_inst_dir/etc/authconf.php");
   }
?>
<html>
<head>
<title>Modify IWS/WebAdmin User</title>
<?php tws_adminstylesheet(); ?>
<script type="text/javascript">
function setPwd() {
   if($('input:password').attr('disabled') =='disabled') {
      $('input:password').removeAttr('disabled');
      $('tr.pwd').css('display', '');
   }
   else {
      $('input:password').attr('disabled', 'disabled');
      $('tr.pwd').css('display', 'none');
   }
}
</script>
</head>
<body>
<?php tws_print_head('Modify IWS/WebAdmin User','','../');?>
<?php
   $cnt = count($selection);
   if (!isset($selection) || $cnt == 0) {
      tws_dyer("No user selected", "", "tws_user_administration.php");
   }

   $authusers="$base_inst_dir/httpd/conf/authusers";
   $authgroups="$base_inst_dir/httpd/conf/authgroups";

if($cnt==1) {     // One user selected
   $selection = $selection[0];

   // check if Apache User
   $find=0;
   $fp=fopen($authusers,"r");
   if ($fp) {
      while ($buffer=fgets($fp,4096)) {
         $username=strtok($buffer,":");
         if($username == $selection) {
            $find=1;
            break;
         }
      }
      fclose($fp);
   }
   unset($buffer);

   if($find==0) {
      // if not apache user check if not in apache group
      $fp=fopen($authgroups,"r");
      while ($buffer=fgets($fp,4096)) {
         $group=strtok($buffer,":");
         $members=trim(strtok(":"));
         $members=explode(" ",$members);
         foreach ( $members as $member) {
           if ($member == $selection)
            $find=1;
         }
      }
      fclose($fp);
      unset($members);
      if ($find==1)
         tws_dyer("It is not possible to modify/delete '$selection' user account, as it is not a regular IWS/WebAdmin account, only it's group membership was declared in the IWS/WebAdmin user database", "", "tws_user_administration.php");
      else
         tws_dyer("User '$selection' was imported from the IWS security user sections. It doesn't exist in the IWS/WebAdmin user database, therefore it is not possible to remove/modify the account.", "", "tws_user_administration.php");
   }

   // Read description
   $authusers_desc="$base_inst_dir/httpd/conf/authusers_desc";
   $description = '';
   if (file_exists($authusers_desc)) {
      $fp=fopen($authusers_desc,"r");
      if ($fp) {
         while ($buffer=fgets($fp,4096)) {
           $user = trim(strtok($buffer,":"));
           $desc = trim(strtok("\n"));
           if ($user == $selection) {
              $description = $desc;
              break;
           }
         }
         fclose($fp);
      }
   }
   // ***** Groups **** //
   $fp=fopen($authgroups,"r");
   while ($buffer=fgets($fp,4096)) {
      $group = strtok($buffer,":");
      $groups[] = $group;     // all groups
      $memberstr=trim(strtok(":"));
      $members=explode(" ", $memberstr);
      if ( in_array($selection,$members) ) {
         $curgroup = $group;
      }
   }
   fclose($fp);

   echo "<br><br>";
   echo "<h3>User Configuration:</h3>";
   echo "<form method=\"post\" action=\"tws_modify_user_exec.php\">\n";
   echo "<table border=0 cellspacing=0>\n";
   echo "<tr>\n";
   echo "<td class=standard width=120>Username:</td>\n";
   echo "<td class=standard><b>".htmlspecialchars($selection)."</b></td>\n";
   echo "</tr>\n";
   echo "<tr>\n";
   echo "<td class=standard width=120>Description:</td>\n";
   echo "<td class=standard><input type=\"text\" name=\"description\" value=\"".htmlspecialchars($description)."\" size=60 /></td>\n";
   echo "</tr>\n";
   echo "<tr><td>&nbsp;</td><td>";
      if (isset($authtype) && $authtype == "os")
         echo '<a href="javascript:setPwd();">click here</a> to set password (not needed with OS authentication)';
   echo "</td></tr>\n";
   echo "<tr class='pwd'><td class='standard' width=120>New Password:</td>\n";
   echo "<td class=standard><input type=\"password\" name=\"password\" autocomplete=\"off\" size=20 maxlength=40>&nbsp;&nbsp;&nbsp;&nbsp;<i>Leave blank to keep current password</i></td>\n";
   echo "</tr>\n";
   echo "<tr class='pwd'>\n";
   echo "<td class=standard width=120>Confirm Password:</td>\n";
   echo "<td class=standard><input type=\"password\" name=\"confirm_password\" autocomplete=\"off\" size=20 maxlength=40></td>\n";
   echo "</tr>\n";
   echo "<tr><td>&nbsp;</td></tr>\n";
   echo "<tr>\n";
//  ******* Groups *******
   echo "<td class=standard>Group:</td>\n";
   echo "<td class=standard>
         <select name=\"group\">";
   if (!$curgroup) {echo "<option value=\"NULL\" selected>&nbsp;</option>\n"; }
   else { echo "<option value=\"NULL\">&nbsp;</option>\n"; }
   foreach($groups as $group) {
      if ($curgroup == $group)
         echo "<option value='$group' selected>".htmlspecialchars($group)."</option>";
      else echo "<option value='$group'>".htmlspecialchars($group)."</option>";
   }
   echo "</select></td>\n";

   echo "</tr>\n";
   echo "</table>\n";
   echo "<input type=\"hidden\" name=\"username\" value=\"".htmlspecialchars($selection)."\">\n";
   tws_print_synchro_token();     // synchro_token
   echo "<br><br>
      <input type='submit' value='Save Changes' name='action'>&nbsp;
      <input type='Button' name='action' value='Cancel' onClick='window.location.replace(\"tws_user_administration.php\");'>
      </form>";
}
else {   // few users selected - can change group only
   $fp=fopen($authgroups,"r");
   while ($buffer=fgets($fp,4096)) {
      $group = strtok($buffer,":");
      $groups[] = $group;
   }
   fclose($fp);

   echo "<h3>Change Group for selected users:</h3>";
   echo "<form method=\"post\" action=\"tws_modify_user_exec.php\">\n";
   foreach($selection as $tmp)
      echo "<b>".htmlspecialchars($tmp)."</b><br>";
   echo "<br>";
   echo "<table border=0 cellspacing=0>\n";
   echo "<tr>\n";
   echo "<td class=standard>Group:</td>\n";
   echo "<td class=standard>
         <select name=\"group\">";
   echo "<option value=\"NULL\" selected>&nbsp;</option>\n";
   foreach($groups as $group) {
      echo "<option value='$group'>".htmlspecialchars($group)."</option>";
   }
   echo "</select></td>\n";
   echo "</tr>\n";
   echo "</table>\n";
   echo tws_create_hidden_inputs($selection, 'selection', null);
   tws_print_synchro_token();     // synchro_token
   echo "<br><br>
      <input type='submit' value='Save Changes' name='action'>&nbsp;
      <input type='button' name='action' value='Cancel' onClick=\"window.location.replace('tws_user_administration.php');\">
      </form>";
}
?>
   <? if (isset($authtype) && $authtype == "os"): ?>
       <script type="text/javascript">
         $('input:password').attr('disabled', "disabled");
         $('tr.pwd').css('display', 'none');
       </script>
   <? endif; ?>

</body>
</html>
