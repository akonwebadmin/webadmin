<?php
//   HORIZONT Software GmbH, Munich
//

   tws_doctype("t"); 
?>
<html>
<head>
<title>Delete Note</title>
</head>
<body>
   <h1>Script was removed since TWA 3.1.4</h1>
</body>
</html>