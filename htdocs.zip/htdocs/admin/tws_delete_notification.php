<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Delete Alert</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<h1>Delete Alert</h1>
<br><br>
<h3>Confirm Alert Delete:</h3>

<?php

   if (!isset($selection)) {
      echo "<p class=warning>&nbsp;&nbsp;&nbsp;&nbsp;No alert selected</p>\n";
      echo "<form action=\"tws_alert_configuration.php\">\n";
      echo "<input type=\"submit\" value=\"Back\">\n";
      echo "</form>\n";
      echo "</body></html>\n";
      exit;
   } else {
// Get event num, condition, recipient / command, alert_id
      $selection = unserialize( urldecode( $selection ) );
      $alert_id=tws_gpc_get($selection['alert_id'], 'tws_num');
      $event_num=tws_gpc_get($selection['event_num'], 'tws_num');
      $alert_type=tws_gpc_get($selection['alert_type']);
      $recipient_command=tws_gpc_get($selection['recipient_command']);
      $condition=tws_gpc_get($selection['condition']);

      if ($event_num == 0) {
         $event_type="Severity";
      } else {
         include($event_types_file);
         $event_type=$event_type[$event_num];
      }

      echo "<form method=\"post\" action=\"tws_delete_notification_exec.php\">\n";
      echo "<table border=0 cellspacing=0>\n";
      echo "<tr>\n";
      echo "<td class=standard width=120>\n";
      echo "&nbsp;&nbsp;<b>Event Type:</b>\n";
      echo "</td>\n";
      echo "<td class=standard>\n";
      echo htmlspecialchars($event_type)."\n";
      echo "</td>\n";
      echo "</tr>\n";
      echo "<tr>\n";
      echo "<td class=standard width=120>\n";
      echo "&nbsp;&nbsp;<b>Condition:</b>\n";
      echo "</td>\n";
      echo "<td class=standard>\n";
      echo htmlspecialchars($condition)."\n";
      echo "</td>\n";
      echo "</tr>\n";
      echo "<tr>\n";
      echo "<td class=standard width=120>\n";
      echo "&nbsp;&nbsp;<b>Alert Type:</b>\n";
      echo "</td>\n";
      echo "<td class=standard>\n";
      echo htmlspecialchars($alert_type)."\n";
      echo "</td>\n";
      echo "</tr>\n";
      echo "<tr>\n";
      echo "<td class=standard width=120>\n";
      if ($alert_type == "EMAIL") {
         echo "&nbsp;&nbsp;<b>Recipient:</b>\n";
      } else {
         echo "&nbsp;&nbsp;<b>Command:</b>\n";
      }
      echo "</td>\n";
      echo "<td class=standard>\n";
      echo htmlspecialchars($recipient_command)."\n";
      echo "</td>\n";
      echo "</tr>\n";
      echo "</table>\n";

      echo "<input type=\"hidden\" name=\"alert_id\" value=\"$alert_id\">\n";
      echo "<input type=\"hidden\" name=\"event_num\" value=\"$event_num\">\n";
      echo "<input type=\"hidden\" name=\"recipient_command\" value=\"" . htmlentities($recipient_command) . "\">\n";
   }
   tws_print_synchro_token();  // synchro_token
?>

<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Delete" name="action">&nbsp;&nbsp;
<input type="button" value="Cancel" onclick="window.location.replace('tws_alert_configuration.php');">
</form>
</body>
</html>
