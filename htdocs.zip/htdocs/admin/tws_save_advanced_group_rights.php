<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');
?>
<html>
<head>
<title>Save Advanced Group Rights</title>
<?php tws_adminstylesheet(); ?>

<script type="text/javascript">
function goback() {
window.location.replace("tws_user_administration.php#groups");
}
</script>

</head>
<body>
<?php
   tws_import_request_variables("P","rqst_");

   $groupname = tws_gpc_get($rqst_groupname, 'tws_alfanum');
   $default_rights=tws_gpc_get($rqst_default_rights, 'tws_alfanum');
   $action=tws_gpc_get($rqst_action);
   $right=tws_gpc_get($rqst_right, 'tws_alfanum');
   if(trim($rqst_limit)=='') $rqst_limit = 0;
   $limit = tws_gpc_get($rqst_limit, 'tws_num');
   if(isset($rqst_default_limit)) $default_limit = $rqst_default_limit;
   tws_check_synchro_token();  // synchro_token

   if(!isset($groupname) || trim($groupname)==='') tws_dyer("Groupname is empty!");

if ($action == "Use Default Values") {
   $action = urlencode($action);
   echo "<script language='Javascript'>\n";
   echo "window.location.replace('tws_advanced_group_rights.php?groupname=".$groupname."&action=".$action."');\n";
   echo "</script>\n";
   exit;
}
   // $action = "Save Changes" || $action = "Remove Custom Prifile"

   $fn_usersec = $tws_config['base_inst_dir'].'/etc/usersec.php';
   $fn_usersecbak = $tws_config['base_inst_dir'].'/etc/usersec.php.bak';

   if (file_exists($fn_usersec)) {
      include $fn_usersec;
      if (!copy($fn_usersec,$fn_usersecbak)) {
         tws_dyer("Unable to make backup copy of group rights configuration file", "", "tws_user_administration.php");
      }
   }

   //prepare the string of advanced rights for the selected group (groupname)
   $rights_string='';
   if (count($right)) {
      ksort($right);
      foreach ($right as $key =>$val) {
         $val==1 && $rights_string.=$key;
      }
   }

   $group_rights[$groupname]=$rights_string;
   $group_limit[$groupname]=$limit;

   $fp=fopen($fn_usersec,"w") or tws_dyer("Unable to create user rights configuration file", "", "tws_user_administration.php");

   //write the default rights (header)
   fwrite($fp,"<?php\n\$default_rights='$default_rights';\n")<0 && tws_dyer("Unable to write user rights configuration file", "header, $fn_usersec", "tws_user_administration.php");
   //write the $rights array (body)
   if(is_array($rights)){
      foreach ($rights as $key=>$val) {
         if (trim($key)==='') continue;
         fwrite($fp,"\$rights['".addcslashes($key,'\'')."']='".trim($val)."';\n")<0 && tws_dyer("Unable to write user rights configuration file", "body, $fn_usersec", "tws_user_administration.php");
      }
   }
   if(is_array($group_rights)){
      foreach ($group_rights as $key=>$val) {
         if (trim($key)==='') continue;
         if ($action == 'Remove Custom Profile' && trim($key) == $groupname) continue;
         fwrite($fp,"\$group_rights['".addcslashes($key,'\'')."']='".trim($val)."';\n")<0 && tws_dyer("Unable to write user rights configuration file", "body, $fn_usersec", "tws_user_administration.php");
      }
   }
   if(is_array($group_limit)){
      foreach ($group_limit as $key=>$val) {
         if (trim($key)==='') continue;
         if ($action == 'Remove Custom Profile' && trim($key) == $groupname) continue;
         fwrite($fp,"\$group_limit['".addcslashes($key,'\'')."']=".trim($val).";\n")<0 && tws_dyer("Unable to write user rights configuration file", "body, $fn_usersec", "tws_user_administration.php");
      }
   }
   if(isset($default_limit))
      fwrite($fp,"\$default_limit=$default_limit;\n")<0 && tws_dyer("Unable to write user rights configuration file", "header, $fn_usersec", "tws_user_administration.php");
   //write footer
   fwrite($fp,"?>")<0 && tws_dyer("Unable to write user rights configuration file", "footer, $fn_usersec", "tws_user_administration.php");
   fclose($fp);

   if ($action == 'Remove Custom Profile') {
      echo "<script language=\"Javascript\">\n";
      echo "  window.location.replace(\"tws_user_administration.php#groups\");\n";
      echo "</script>\n";
   }
   else {
      tws_print_head("Advanced Group Rights saved",'','../');
      echo "<p class=warning>Advanced Group Rights saved for group $groupname</p>";
      echo "<br><br><input type='Button' name='action' value=' Ok ' onClick='goback()'>";
   }

?>
</body>
</html>
