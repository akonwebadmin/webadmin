<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Delete IWS/WebAdmin Group</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<?php
   tws_import_request_variables("P","rqst_");
   $groupname = tws_gpc_get($rqst_groupname, 'tws_alfanum');
   tws_check_synchro_token();     // synchro_token

   $authgroups="$base_inst_dir/httpd/conf/authgroups";
   $newauthgroups=$authgroups . ".tmp";
   $bakauthgroups=$authgroups . ".bak";
   $change="yes";

// Modify authgroups file
   $fp=fopen($authgroups,"r") or tws_dyer("Can't open $authgroups file");
   $newfp=fopen($newauthgroups,"w") or tws_dyer("Can't open $newauthgroups file");
   while ($buffer=fgets($fp,4096)) {
      $group=strtok($buffer,":");
      if ($group != $groupname) {
         fputs($newfp, $buffer);
      }
   }
   fclose($fp);
   fclose($newfp);

   copy($authgroups,$bakauthgroups) or tws_dyer("Can't copy $authgroups to $bakauthgroups");
   copy($newauthgroups,$authgroups) or tws_dyer("Can't copy $newauthgroups to $authgroups");

   unlink($newauthgroups);

   // Remove files to backup
   if (!file_exists($base_inst_dir."/backup/home/groups")) {
      tws_mkdir($base_inst_dir."/backup/home/groups")===FALSE && tws_dyer("Cannnot create '/backup/home/groups' directory.", "", "tws_user_administration.php");
      tws_chmod($base_inst_dir."/backup/home/groups", 0755)===FALSE && tws_err("Cannnot set up permissions for '/backup/home/groups' directory.");
   }
   if(file_exists($base_inst_dir."/backup/home/groups/$groupname"))
      tws_rmdir($base_inst_dir."/backup/home/groups/$groupname");
   rename ($webadmin_user_home_dir."/groups/$groupname", $base_inst_dir."/backup/home/groups/$groupname");

   echo "<script language=\"Javascript\">\n";
   echo "window.location.replace(\"tws_user_administration.php#groups\");\n";
   echo "</script>\n";
?>
</body>
</html>
