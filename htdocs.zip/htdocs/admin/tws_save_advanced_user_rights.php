<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');
?>
<html>
<head>
<title>Save Advanced User Rights</title>
<?php tws_adminstylesheet(); ?>

<script type="text/javascript">
function goback() {
window.location.replace("tws_user_administration.php");
}
</script>

</head>
<body>
<?php
   tws_import_request_variables("P","rqst_");

   $username = tws_gpc_get($rqst_username, 'tws_alfanum\\tws_alfanum', '\\');
   $selection = tws_gpc_get($rqst_selection, 'tws_alfanum\\tws_alfanum', '\\');
   $default_rights=tws_gpc_get($rqst_default_rights, 'tws_name');
   $action = tws_gpc_get($rqst_action);
   $right=tws_gpc_get($rqst_right, 'tws_num');
   tws_check_synchro_token();     // synchro_token

   $rights=array();

   $fn_usersec=$tws_config['maestro_dir']."/webadmin/etc/usersec.php";
   $fn_usersecbak=$fn_usersec.".bak";


   if (file_exists($fn_usersec)) {
      //at this moment, the $default_rights in the usersec.php overwrite the $default_rights
      //obtained from the POST input. A small trick allowing to spare one variable...
      //we also load the current values of $rights array now
      @include $fn_usersec;

      //make a backup of the current usersec.php file (if exists)
      if (!copy($fn_usersec,$fn_usersecbak)) {
         tws_dyer("Unable to make backup copy of user rights configuration file", "src=$fn_usersecbak, target=$fn_usersecbak", "tws_user_administration.php");
      }
   }

   if(isset($rqst_default_limit))
      $default_limit = $rqst_default_limit;
   if(trim($default_limit)=='') $default_limit = 0;

//prepare the string of advanced rights for the selected user (username)
   if ($action=='Use Default Values' || $action=='Use Group Default Values') {
      echo "<script language='Javascript'>\n";
      echo "window.location.replace('tws_advanced_user_rights.php?username=".urlencode($username)."&action=".urlencode($action)."');\n";
      echo "</script>\n";
   }
   else {                  // $action = "Save Changes" || $action = "Remove Custom Prifile"
     $rights_string='';
      if (count($right)) {
         ksort($right);
         foreach ($right as $key =>$val) {
            $val==1 && $rights_string.=$key;
         }
      }

   //assign the updated rights to the right variable, depends on the mode
   $cnt=0;
   if(is_array($selection)) $cnt = count($selection);
   if ($username==='') {
      if (is_array($selection) && $cnt>0){
         foreach($selection as $username)
         $rights[$username]=$rights_string;
      }
      else      //modify default righs mode
         $default_rights=$rights_string;
   } else      //modify custom user rights
      $rights[$username]=$rights_string;

   $fp=fopen($fn_usersec,"w") or tws_dyer("Unable to create user rights configuration file", "", "tws_user_administration.php");

//write the default rights (header)
   fwrite($fp,"<?php\n\$default_rights='$default_rights';\n")<0 && tws_dyer("Unable to write user rights configuration file", "header, $fn_usersec", "tws_user_administration.php");
//write the $rights array (body)
   foreach ($rights as $key=>$val) {
      if (trim($key)==='') continue;
      if ($action == 'Remove Custom Profile' && in_array(trim($key), $selection)) continue;
      fwrite($fp,"\$rights['".addcslashes($key,'\'')."']='".trim($val)."';\n")<0 && tws_dyer("Unable to write user rights configuration file", "body, $fn_usersec", "tws_user_administration.php");
   }
   if(is_array($group_rights)) {
      foreach ($group_rights as $key=>$val) {
         if (trim($key)==='') continue;
         fwrite($fp,"\$group_rights['".addcslashes($key,'\'')."']='".trim($val)."';\n")<0 && tws_dyer("Unable to write group rights configuration file", "body, $fn_usersec", "tws_user_administration.php");
      }
   }
   if(is_array($group_limit)){
      foreach ($group_limit as $key=>$val) {
         if (trim($key)==='') continue;
         if ($action == 'Remove Custom Profile' && trim($key) == $groupname) continue;
         fwrite($fp,"\$group_limit['".addcslashes($key,'\'')."']=".trim($val).";\n")<0 && tws_dyer("Unable to write user rights configuration file", "body, $fn_usersec", "tws_user_administration.php");
      }
   }
   if(isset($default_limit))
      fwrite($fp,"\$default_limit=$default_limit;\n")<0 && tws_dyer("Unable to write user rights configuration file", "header, $fn_usersec", "tws_user_administration.php");
   
//write footer
   fwrite($fp,"?>")<0 && tws_dyer("Unable to write user rights configuration file", "footer, $fn_usersec", "tws_user_administration.php");
   fclose($fp);

   if ($action == 'Remove Custom Profile') {
      echo "<script language=\"Javascript\">\n";
      echo "  window.location.replace(\"tws_user_administration.php\");\n";
      echo "</script>\n";
   }
   else {
      tws_print_head("Advanced User Rights saved",'','../');
      if($cnt>1){
         echo "<p class=warning>Advanced User Rights saved for selected users</p>";
         echo "<br><br><input type='Button' name='action' value=' Ok ' onClick='window.location.replace(\"tws_user_administration.php\");'>";
      }
      elseif($username!=''){
         echo "<p class=warning>Advanced User Rights saved for user $username</p>";
         echo "<br><br><input type='Button' name='action' value=' Ok ' onClick='window.location.replace(\"tws_user_administration.php\");'>";
      }
      else {
         echo "<p class=warning>Default Advanced Rights saved</p>";
         echo "<br><br><input type='Button' name='action' value=' Ok ' onClick='window.location.replace(\"tws_user_administration.php#defaults\");'>";
      }
   }
}
?>
</body>
</html>
