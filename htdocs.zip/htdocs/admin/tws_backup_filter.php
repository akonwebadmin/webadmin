<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
   
   $backupfilter = tws_profile('backupfilter');
   if ($backupfilter) {
      $filterchunks = explode("+",$backupfilter);
      foreach ($filterchunks as $key => $value) {
         if (strstr($value,'created')) {
            list($createdfrom,$createdto) = explode(',',substr($value,8));
         } else {
            $filterchunk = explode("=",$value);
            $f = $filterchunk[0];
            $$f = $filterchunk[1];
         }
      }
   }
   
   echo "<html>\n";
   echo "<head>\n";
   echo "<title>Backup Administration Filter</title>\n";
   tws_adminstylesheet();
   echo "</head>\n";
   echo "<body>\n";
   tws_set_window_title();
   tws_print_head('Set Backup Administration Filter',array(),'/');
?>
<br/>
<form method="post" name="contents" action="tws_backup_filter_action.php">
<fieldset>
<legend>&nbsp;basic filter setting&nbsp;</legend>
   <table border=0 cellspacing=0>
      <tr>
         <td class="standard" width=150>Type:</td>
         <td class="standard"><input type="text" name="type" <?php if (isset($type)) echo "value=\"$type\""; ?> size="16" maxlength="16"/></td>
      </tr>
      <tr>
         <td class="standard" width=150>Object name:</td>
         <td class="standard"><input type="text" name="obj_name" <?php if (isset($obj_name)) echo "value=\"$obj_name\""; ?> size="16" /></td>
      </tr>
      <tr>
         <td class="standard" width=150>Creator:</td>
         <td class="standard"><input type="text" name="creator" <?php if (isset($creator)) echo "value=\"$creator\""; ?> size="16" maxlength="16"/></td>
      </tr>
      <tr><td colspan="2">&nbsp;</td>
      <tr>
         <td class="standard" valign="top">Created date:</td>
         <td>
            <table border=0 cellspacing=0>
               <tr>
                  <td class=standard nowrap>From:&nbsp;</td>
                  <td class=standard nowrap colspan="3"><?=tws_datetime_picker('createdfrom',$createdfrom,'','/',"'dropdown',true,'24',true,true");?></td>
               </tr>
               <tr>
                  <td class=standard nowrap>To:&nbsp;</td>
                  <td class=standard nowrap colspan="3"><?=tws_datetime_picker('createdto',$createdto,'','/',"'dropdown',true,'24',true,true");?></td>
               </tr>
            </table>
         </td>
      </tr>
   </table>
</fieldset>

<br/>

<fieldset>
<legend>&nbsp;full-text search&nbsp;</legend>
   <table border=0 cellspacing=0 width="100%">
      <tr>
         <td class="standard" width=150>File contains:</td> 
         <td class="standard">
            <input type="text" name="search" <?php if (isset($search)) echo "value=\"$search\"";?> style="display: block; width: 63%;"/>
         </td>
      </tr>
      <tr>
         <td class="standard" width=150>Search option:</td> 
         <td class="standard">
            <input type="checkbox" name="case_sensitive" value="yes" <?php if (isset($case_sensitive)) echo "checked";?>/>&nbsp;Case sensitive
         </td>
      </tr>
   </table>
</fieldset>

<br/><br/>

<input type="submit" value="Set Filter" name="action">
&nbsp;&nbsp;&nbsp;<input type="submit" value="Clear Filter" name="action">
&nbsp;&nbsp;&nbsp;<input type="submit" value="Load Filter" name="action">
&nbsp;&nbsp;&nbsp;<input type="submit" value="Save Filter" name="action">
<?php if(@$_GET['edit_file']!='') echo "<input type=\"hidden\" name=\"edit_file\" value=\"".htmlspecialchars($_GET['edit_file'])."\">\n";?>
</form>
</body>
</html>