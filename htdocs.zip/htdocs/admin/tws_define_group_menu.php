<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
   tws_adminstylesheet();
?>
<html>
<head>
<title>Advanced Group Rights</title>

<script type="text/javascript">

function MenuCheckAll() {
   selection = document.menu.elements['menu_item[]'];
   selection.checked=true;
   for (i=0; i<selection.length; i++) {
      selection[i].checked=true;
   }
}

function MenuClearAll() {
   selection = document.menu.elements['menu_item[]'];
   selection.checked=false;
   for (i=0; i<selection.length; i++) {
      selection[i].checked=false;
   }
}

   function checkSection(el, num) {
      if( $(el).is(':checked') )
         $('input:checkbox.'+num).attr('checked','checked');
      else
         $('input:checkbox.'+num).removeAttr('checked');
   }

</script>
</head>
<body>
<?php
   global $tws_config;

   $user_setting_dir = $tws_config['user_setting_dir'];
   $webadmin_user_home_dir = $tws_config['webadmin_user_home_dir'];

   tws_import_request_variables("GP","rqst_");
   $action = tws_gpc_get($rqst_action);
//$action = urldecode($action);
  if (urldecode($action) == "Use Default Values") // back call from tws_save_group_menu.php
      $selection = tws_gpc_get($rqst_group);
  if (urldecode($action) == "Define Group Menu")
      $selection = tws_gpc_get($rqst_selection);

   if (!isset($selection) || ($selection == "") ) {
      tws_print_head('Define Group Rights','','../');
      echo "<p class=warning>No group selected</p>\n";
      echo "<input type='button' value='Ok' name='Back' onClick='window.location.replace(\"tws_user_administration.php#groups\");'>";
      die("</body></html>\n");
   }

   $groupname=$selection;
      tws_print_head("Define Group Rights for '".htmlspecialchars($groupname). "' group",'','../');

   if (is_file($webadmin_user_home_dir."/groups/".$groupname.$user_setting_dir."/menu.php")) {
         $using_defaults = false;}
   else {$using_defaults = true;}
?>

<form method=post name=menu action="tws_save_group_menu.php">
<input type="hidden" name="groupname" value="<?echo $groupname?>">
<table border=0 cellspacing=0>
<tr>
<td class=standard>
<h3>Menu Items:</h3>
</td>
</tr>
<?php
   if(urldecode($action) == "Use Default Values") {
      $res = tws_display_group_menu_configuration('default');
   }
   else {
      $res = tws_display_group_menu_configuration($groupname);
   }
   if (!$res) {
      tws_dyer("An Error occured when reading menu configuration", "", "tws_user_administration.php");
   }
?>
</table>
<br>
<a href="Javascript:MenuCheckAll();">Check All</a>&nbsp;&nbsp;-&nbsp;&nbsp;<a href="Javascript:MenuClearAll();">Clear All</a>
<br>
<?php
   if ($using_defaults) {
      echo "<p class=warning>Group currently has default menu - Saving will create a custom menu for the group</p>";
   }
   else {
      echo "<p class=warning>Group currently has custom menu</p>";
   }
?>
<br>
<?php
   if ($using_defaults==false) {
      echo "<input type='submit' name='action' value='Use Default Values'>&nbsp;";
      echo "<input type='submit' name='action' value='Remove Custom Profile'>&nbsp;<br>";
   }
?>
<br>
<input type="submit" name="action" value="Save Changes">&nbsp;
<input type='Button' name='action' value='Cancel' onClick='window.location.replace("tws_user_administration.php#groups");'>&nbsp;

</form>
</body>
</html>
