<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');
?>
<html>
<head>
   <title>IWS Alert Configuration Help</title>
   <?php tws_adminstylesheet(); ?>
</head>
<body class=help>
<?php
   tws_set_window_title();
   $path = '../';
   include $path.'tws_help_topbar.php';
?>
<h1 class=help>IWS Alert Configuration Help</h1>
<p>The IWS Alert Configuration page is used to configure automatic email notification for IWS events such as job abends. In addition to email notification, it is also possible to define custom alerts that execute system commands. The Alert Configuration page displays a table of the currently defined alerts with the following fields:
<ul>
  <li><strong>Event Type</strong> : The event type - Job Abend, Job Suspended, Jobstream Abend, etc.</li>
  <li><strong>Conditions</strong> : Matching conditions for the event - Workstation name, Job name, etc.</li>
  <li><strong>Recipient / Command</strong> : Email address of recipient (for email alerts) / Command text (for command alerts)</li>
  <li><strong>Description</strong> : The description entered for the alert when it was created</li>
</ul>
<p>Click the <strong>Add</strong> button to define a new alert.
<p><strong>Note</strong> : The IWS/WebAdmin event collector must be properly configured in order for alerts to function correctly.
</body>
</html>
