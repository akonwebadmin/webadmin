<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add IWS/WebAdmin Group</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<?php
   tws_import_request_variables("P","rqst_");

   $groupname= tws_gpc_get($rqst_groupname, 'tws_alfanum');
   tws_check_synchro_token();     // synchro_token
   
   if ($groupname == '' || strtolower($groupname) == 'groups' || strtolower($groupname) == 'all_users' || $groupname == '0') {
      echo "<p class=warning>Illegal group name '$groupname'</p>\n";
      echo "<input type='button' value='Ok' name='Back' onClick='history.back()'>";
      die("</body></html>\n");
   }

   $twssec = tws_get_twssec_groups();
   if(array_key_exists( strtoupper($groupname), $twssec) && !isset($rqst_continue)) {
      $rqst_continue = 0;
   }
   else {
      $rqst_continue = 1;
   }

if ($rqst_continue) {
   $status=1;
   // create home directory
   if (!file_exists($webadmin_user_home_dir."/groups/$groupname")) {
      tws_mkdir($webadmin_user_home_dir."/groups/$groupname")===FALSE && tws_dyer("Cannnot create IWS/WebAdmin group '$groupname' home directory.", "", "tws_user_administration.php");
      tws_chmod($webadmin_user_home_dir."/groups/$groupname", 0755)===FALSE && (tws_err("Cannnot set up permissions of the IWS/WebAdmin group '$groupname' home directory.") && $status=0);
   }
   if (!file_exists($webadmin_user_home_dir."/groups/".$groupname.$user_setting_dir)) {
      tws_mkdir($webadmin_user_home_dir."/groups/".$groupname.$user_setting_dir)===FALSE && tws_dyer("Cannnot create '$groupname.$user_setting_dir' directory.", "", "tws_user_administration.php");
      tws_chmod($webadmin_user_home_dir."/groups/".$groupname.$user_setting_dir, 0755)===FALSE && (tws_err("Cannnot set up permissions for '".$groupname.$user_setting_dir."' directory.") && $status=0);
   }
   $authgroups="$base_inst_dir/httpd/conf/authgroups";
   $bakauthgroups=$authgroups . ".bak";

   copy($authgroups,$bakauthgroups) or tws_dyer("Cannnot copy $authgroups to $bakauthgroups");

   $fp=fopen($authgroups,"a")or tws_dyer("Cannnot open $authgroups");
      fputs($fp,$groupname.":\n");
   fclose($fp);

   if($status){
      echo "<script language=\"Javascript\">\n";
      echo "window.location.replace(\"tws_user_administration.php#groups\");\n";
      echo "</script>\n";
   }
   else tws_dyer('');
}
else {
      echo "<p class=warning>There is currently exist IWS Security User Section '". strtoupper($groupname) ."'!<br>
      Creating of new group '$groupname' will replace all IWS/WebAdmin settings for IWS Security User Section '".strtoupper($groupname)."'!</p>";      // FIXME translate

      echo "<form method='post' action='tws_create_group.php'>";
      echo "<input type='hidden' name='groupname' value='$groupname'>";
      echo "<input type='hidden' name='continue' value='1'>";

      echo "<input type='submit' name='action' value='Create Group'>&nbsp;";
      echo "<input type='button' name='action' value='Cancel' onClick='window.location.replace(\"tws_user_administration.php#groups\");'>";
      tws_print_synchro_token();
      echo "</form>";
   }

?>
</body>
</html>
