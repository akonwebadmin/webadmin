<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Delete Report</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<?php
   tws_import_request_variables("P","rqst_");

   $filename = tws_gpc_get($rqst_filename, 'tws_file');
   $filename = basename($filename);
   $user = tws_gpc_get($rqst_user, 'tws_alfanum\\tws_alfanum', '\\');
      tws_check_synchro_token();  //    synchro_token

// Check characteristics of filename
   if (substr($filename,-4) != ".rpt") {
      die ("<p class=warning>Bad report filename specified</p>\n</body>\n</html>\n");
   }
   if ((strpos($filename,"/") !== FALSE) || (strpos($user,"/") !== FALSE)) {
      die ("<p class=warning>Bad report filename specified</p>\n</body>\n</html>\n");
   }

  if (isset($rqst_forall) && $rqst_forall == "YES") {
      $dir = $webadmin_all_user_dir;
   } else {
      $dir = "$webadmin_user_home_dir/".$user;
   }

   if(file_exists("$dir/$filename"))
      unlink("$dir/$filename") or tws_dyer("Delete report file $filename failed");
   else
      tws_dyer("Bad report filename specified");

   echo "<script language=\"Javascript\">\n";
   echo "window.location.replace(\"tws_report_administration.php\");\n";
   echo "</script>\n";
?>
</body>
</html>
