<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');
?>
<html>
<head>
   <title>IWS Logfile Help</title>
   <?php tws_adminstylesheet(); ?>
</head>
<body class="help">
<?php
   tws_set_window_title();
   $path = '../';
   include $path.'tws_help_topbar.php';
?>
<h1 class=help>IWS Logfile Help</h1>
<p>The IWS Logfile, located in the stdlist directory, contains a running log of IWS operations, including errors and warnings. It is useful for tracking events and troubleshooting. The IWS/WebAdmin Logfile viewer displays the IWS logfile and allows filtering and navigation by date.
<p>By default, the IWS logfile for the current day is displayed. To move forward and back to logfiles for other dates, click the <strong>Prev</strong> and <strong>Next</strong> links. Or, enter a date in the <strong>Date</strong> field and click the <strong>Go</strong> button. Click the <strong>List</strong> button to choose the desired date from a calendar.
<p>To set a filter, enter the desired text to search for in the <strong>Filter</strong> field and click <strong>Set</strong>. The display will update to show only lines that contain the search text.
<p>Click the <strong>Print</strong> button to print the page.
</body>
</html>
