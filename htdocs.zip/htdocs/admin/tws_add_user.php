<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");

   if (file_exists("$base_inst_dir/etc/authconf.php")) {
      include("$base_inst_dir/etc/authconf.php");
   }
?>
<html>
<head>
<title>Add IWS/WebAdmin User</title>
<?php tws_adminstylesheet(); ?>
<script type="text/javascript">
function setPwd() {
   if($('input:password').attr('disabled') =='disabled') {
      $('input:password').removeAttr('disabled');
      $('tr.pwd').css('display', '');
   }
   else {
      $('input:password').attr('disabled', 'disabled');
      $('tr.pwd').css('display', 'none');
   }
}
</script>
</head>
<body>

<?php
   tws_print_head('Add IWS/WebAdmin User','','../');
   tws_nossl_warning();
?>
   <form method='post' action='tws_create_user.php'>
   <table border='0' cellspacing='0'>
   <tr>
   <td class='standard' width='120'>Username:</td>
   <td class='standard'><input type='text' name='username' required='required' size='16' maxlength='60'></td>
   </tr>
   <tr>
   <td class='standard' width='120'>Description:</td>
   <td class='standard'>
      <input type='text' size=60 name='description'/>
   </td>
   </tr>

   <tr><td></td><td>
      <? if (isset($authtype) && $authtype == "os"): ?>
         <a href="javascript:setPwd();">click here</a> to set password (not needed with OS authentication)
      <? endif; ?>
   </td></tr>
   <tr class='pwd'>
      <td class='standard' width='120'>Password:</td>
      <td class='standard'><input type='password' name='password' autocomplete="off" size='20' maxlength='40'/></td>
   </tr>
   <tr class='pwd'>
      <td class='standard' width='120'>Confirm Password:</td>
      <td class='standard'><input type='password' name='confirm_password' autocomplete="off" size='20' maxlength='40'/></td>
   </tr>

   <tr><td>&nbsp;</td></tr>
   <tr>
<?php
//  ******* Groups *******
//   echo "<td class=standard colspan=2>&nbsp;<input type=\"checkbox\" name=\"admin\" value=\"yes\">&nbsp;Administrator</td>\n";
   $authgroups="$base_inst_dir/httpd/conf/authgroups";
   $fp=fopen($authgroups,"r") or tws_error($authgroups, "Can't open file $authgroups");
   $groups = array();
   while ($buffer=fgets($fp,4096)) {
      $groups[]=strtok($buffer,":");
   }
   echo "<td class=standard>Group:</td>\n";
   echo "<td class=standard>
         <select name='group'>
         <option value='NULL'>&nbsp;</option>\n";
   foreach($groups as $group) {
      echo "<option value='$group'>".htmlspecialchars($group)."</option>";
   }
   echo "</select></td>\n";
?>
</tr>
</table>
<br><br>
<input type='submit' value='Create User' name='action'>&nbsp;
<input type='button' value='Cancel' name='Back' onClick="window.location.replace('tws_user_administration.php');">
<? tws_print_synchro_token();     // synchro_token
?>
</form>

   <? if (isset($authtype) && $authtype == "os"): ?>
       <script type="text/javascript">
         $('input:password').attr('disabled', "disabled");
         $('tr.pwd').css('display', 'none');
       </script>
   <? endif; ?>
</body>
</html>
