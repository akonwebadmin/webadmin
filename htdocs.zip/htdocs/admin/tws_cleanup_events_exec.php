<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Cleanup Events Table</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>
<h1>Cleanup Events Table</h1>
<br><br>

<?php
   tws_import_request_variables("P","rqst_");
      // TODO:   tws_check_synchro_token();     // synchro_token

   set_time_limit(600);

   $age_date=tws_gpc_get($rqst_age_date, 'tws_datetime');
      // tws_check_synchro_token();  //    synchro_token

   db_connect($webadmin_db,DB_PERSISTENT) or tws_dyer("Cannot connect to database");
   $schema=$webadmin_db['schema'];

   $query="DELETE FROM $schema.events WHERE tstamp < '$age_date' AND event_id!=0";
   db_query($webadmin_db,$query) or tws_dyer("Database query failed");
   if (isset($webadmin_db['allow_persistent']) && tws_yesno($webadmin_db['allow_persistent'])=='NO')
      db_commit($webadmin_db) or tws_dyer("Unable to COMMIT request.");
?>

&nbsp;&nbsp;&nbsp;&nbsp;Records Successfully deleted - <a href="tws_database_cleanup.php">Return to Database Cleanup</a>

</body>
</html>
