<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Modify IWS/WebAdmin Master</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<h1>Modify IWS/WebAdmin Master</h1>
<br><br>
<h3>Master Configuration:</h3>

<?php

   if (!isset($selection)) {
      echo "<p class=warning> No master selected</p>\n";
      tws_dyer();
   }
   if ($selection == $localmaster){
      echo "<p class=warning> The Local Primary IWS/WebAdmin Master can't be modified</p>\n";
      tws_dyer();
   }

   $fp=fopen("$maestro_dir/webadmin/etc/masters.xml","r") or tws_dyer("Unable to open masters.xml file");
   while (!feof($fp)) {
      $buffer=fgets($fp,4096);
      if (substr($buffer,0,1) == "<") {
         $tok=strtok($buffer," >");
         if ($tok == "<master") {
            $href=strtok(">");
            $master_name=strtok("<");
            if ($master_name == $selection) {
               $junk=strtok($href,"=");
               $href_location=strtok("\n");
               $href_location=trim($href_location,'"');
               if ($href_location == "#local") {
                  $href_location="# LOCAL #";
               }
               $display_href=$href_location;
               break;
            }
         }
      }
   }
   fclose($fp);

   echo "<form method=\"post\" action=\"tws_modify_master_exec.php\">\n";;
   echo "<input type=\"hidden\" name=\"orig_mastername\" value='".htmlspecialchars($selection)."'>\n";
   echo "<table border=0 cellspacing=0>\n";
   echo "<tr>\n";
   echo "<td class=standard width=120>Master Name:</td>\n";
   echo "<td class=standard><input type=\"text\" name=\"mastername\" class='tws_alfanum' required='required' value='".htmlspecialchars($selection)."' size=20 maxlength=40></td>\n";
   echo "</tr>\n";
   echo "<tr><td>&nbsp;</td></tr>\n";
   echo "<tr>\n";
   echo "<td class=standard width=120>Web Server URL:</td>\n";
   if (isset($display_href)) {
      echo "<td class=standard><input type=\"text\" name=\"href\" class='tws_file' required='required' value='".htmlspecialchars($display_href)."' size=40 maxlength=100></td>\n";
   } else {
      echo "<td class=standard><input type=\"text\" name=\"href\" size=40 maxlength=100></td>\n";
   }
?>
</tr>
</table>
<br><br>
<?php
?>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Modify" name="action">
&nbsp;&nbsp;<input type="button" value="Cancel" onclick="window.location.replace('tws_masters_configuration.php');">
<? tws_print_synchro_token();     // synchro_token
?>
</form>
</body>
</html>