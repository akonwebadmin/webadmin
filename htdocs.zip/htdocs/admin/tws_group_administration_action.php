<?php
//   HORIZONT Software GmbH, Munich
//

   require_once("tws_functions.php");
   tws_import_request_variables("P","rqst_");

   $action=$rqst_action;
   $selection=tws_gpc_get($rqst_selection, 'tws_alfanum');

   switch ($action) {
      case "Add New Group":
         include("tws_add_group.php");
         break;
      case "Delete Group":
         if ( !isset($selection) || trim($selection)==='' )
            empty_selection();
         include("tws_delete_group.php");
         break;
      case "Advanced Group Rights":
         if ( !isset($selection) || trim($selection)==='' )
            empty_selection();
         include("tws_advanced_group_rights.php");
         break;
      case "Define Group Menu":
         if ( !isset($selection) || trim($selection)==='' )
            empty_selection();
         include("tws_define_group_menu.php");
         break;
      case "Define Group Action Buttons":
         if ( !isset($selection) || trim($selection)==='' )
            empty_selection();
         $groupname=$selection;
         $username = "";
         unset($selection);
         include("tws_define_action_buttons.php");
         break;
      case "Set Default Filters":
         if ( !isset($selection))
            empty_selection();
         $groupname=$selection;
         $username = "";
         include("tws_define_default_filters.php");
         break;
   }

function empty_selection() {
   tws_doctype('t');
   echo "<html><head>";
   tws_adminstylesheet();
   echo "</head><body>";
   tws_print_head('No group selected', '', '../');
   echo "<p class=warning>No group selected</p>\n";
   echo "<input type='button' value=' Ok ' name='Back' onClick='window.location.replace(\"tws_user_administration.php#groups\");'>";
   die("</body></html>\n");
}
?>