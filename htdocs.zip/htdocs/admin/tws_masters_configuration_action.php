<?php
//   HORIZONT Software GmbH, Munich
//

   require_once("tws_functions.php");
      tws_check_synchro_token();     // synchro_token
   tws_import_request_variables("P","rqst_");

   $action=$rqst_action;
   $selection=tws_gpc_get($rqst_selection, 'tws_alfanum');

   switch ($action) {
     case "Add":
       include("tws_add_master.php");
       break;
     case "Modify":
       $localmaster=tws_gpc_get($rqst_localmaster, 'tws_alfanum');
       include("tws_modify_master.php");
       break;
     case "Delete":
       $num_masters=tws_gpc_get($rqst_num_masters, 'tws_num');
       $localmaster=tws_gpc_get($rqst_localmaster, 'tws_alfanum');
       include("tws_delete_master.php");
       break;
     case "Enable":
       include("tws_enable_multiple_masters.php");
       break;
   }
?>