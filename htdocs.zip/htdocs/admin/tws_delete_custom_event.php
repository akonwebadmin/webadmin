<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Delete Custom Event</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<h1>Delete Custom Event</h1>
<br><br>
<h3>Confirm Delete:</h3>

<?php
   tws_import_request_variables("P","rqst_");

   $selection=$rqst_selection;
   $event_num = strtok($selection,":");
   $conditions=strtok("\n");
   tws_check_arg($event_num, 'tws_num');

// get data
   include($event_types_file);
   include($severities_file);
   include($custom_events_file);

$event_type=$event_type[$custom_event[$event_num]['event_num']];
$severity_label=$severity[$custom_event[$event_num]['severity_level']];
?>

<form method="post" action="tws_delete_custom_event_exec.php">
<table border=0 cellspacing=0>
<tr>
<td class=standard width=120>
&nbsp;&nbsp;<b>Event Type:</b>
</td>
<td class=standard>
<?php echo htmlspecialchars($event_type)."\n"; ?>
</td>
</tr>
<tr>
<td class=standard width=120>
&nbsp;&nbsp;<b>Conditions:</b>
</td>
<td class=standard>
<?php echo htmlspecialchars($conditions)."\n"; ?>
</td>
</tr>
<tr>
<td class=standard width=120>
&nbsp;&nbsp;<b>Severity:</b>
</td>
<td class=standard>
<?php echo htmlspecialchars($severity_label); ?>
</td>
</tr>
</table>
<br><br>
<?php
   echo "<input type=\"hidden\" name=\"event_num\" value=\"$event_num\">\n";
   tws_print_synchro_token();  // synchro_token
?>
&nbsp;&nbsp;<input type="submit" name="action" value="Delete">&nbsp;&nbsp;
<input type="button" value="Cancel" onclick="window.location.replace('tws_custom_events.php');">
</form>
</body>
</html>
