<?php
//   HORIZONT Software GmbH, Munich
//

   require_once("tws_functions.php");
      tws_check_synchro_token();     // synchro_token
   tws_import_request_variables("P","rqst_");

   $action=$rqst_action;
   $selection=$rqst_selection;

   switch ($action) {
     case "Change Max Size":
       include("tws_change_msg_file_size.php");
       break;
   }
?>