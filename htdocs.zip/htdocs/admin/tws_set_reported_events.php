<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Set Reported Events</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>
<h1>Set Reported Events</h1>
<br>
<?php
// Get event types
   include($event_types_file);
// Get severities
   include($severities_file);

// Count number of events selected
   $num_elements=count($event);

// Check for BmEvents.conf file
    if ($tws_config['cpuinfo']['version'] >= '9.5')
        $dir = $tws_config["twsenv"]["UNISONWORK"];
    else
        $dir = $tws_config['maestro_dir'];
    $bmevents=file_exists("$dir/BmEvents.conf");

   echo "<h3>Selected Events</h3>\n";

   if ($num_elements == 0) {
      if ($bmevents) {
         echo "<form method=post action=\"tws_write_bmevents.php\">\n";
         echo "<p class=warning>&nbsp;&nbsp;&nbsp;&nbsp;<b>Warning:</b> No events selected.  Clicking Save will <b>Delete</b> the BmEvents.conf file - a copy of the original file will be saved to BmEvents.conf.bak</p>\n";
      } else {
         die("<p class=warning>&nbsp;&nbsp;&nbsp;&nbsp;The BmEvents.conf file does not exist, and no events were selected.  No changes will be made.</p>\n</body>\n</html>\n");
      }
   } else {
      echo "<form method=post action=\"tws_write_bmevents.php\">\n";
      echo "<table class=wireframe cellspacing=0 cellpadding=3 width=400 cols=2>\n";
      echo "<tr class=header>\n";
      echo "<th class=wireframe>Event Number</th>\n";
      echo "<th class=wireframe>Event</th>\n";
      echo "<th class=wireframe>Severity</th>\n";
      echo "</tr>\n";
      for ($idx=0; $idx<$num_elements; ++$idx) {
         echo "<tr class=standard>\n";
         echo "<td class=wireframe>" . htmlspecialchars($event[$idx]) . "</td>\n";
         echo "<td class=wireframe width=260>" . htmlspecialchars($event_type[$event[$idx]]) . "</td>\n";
         echo "<td class=wireframe>" . htmlspecialchars($severity[$sel_severity[$event[$idx]]]) . "</td>\n";
         echo "</tr>\n";
         echo "<input type=\"hidden\" name=\"event[]\" value=\"$event[$idx]\">\n";
         echo "<input type=\"hidden\" name=\"sel_severity[$event[$idx]]\" value=\"" . htmlspecialchars($sel_severity[$event[$idx]]) . "\">\n";
      }
      echo "</table>\n";
      echo "<br>";
   }
   tws_print_synchro_token();  // synchro_token
?>
<br>

&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Save">&nbsp;&nbsp;
<input type="button" value="Cancel" onclick="window.location.replace('tws_event_configuration.php')">
</form>

<?php
   if (!$bmevents) {
?>
<br>
<b>Note:</b> The BmEvents.conf file does not exist - Clicking <i>Save</i> will create the file
<?php
   } elseif ($num_elements != 0) {
?>
<br>
<b>Note:</b> Clicking <i>Save</i> will write changes to the BmEvents.conf file - a copy of the original file will be saved to BmEvents.conf.bak
<?php
   }
?>
</body>
</html>
