<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Custom Event Configuration</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>
<?php
   tws_set_window_title();
   tws_print_head('Custom Event Configuration', 'tws_custom_events_help.php', '../');
?>
<h2>Custom Events:</h2>
<form method=post action="tws_custom_events_action.php">

<?php
// Get event types
   include($event_types_file);
// Get severity levels
   include($severities_file);
// Get custom events
   include($custom_events_file);

   if (count($custom_event) == 0) {
      echo "<p class=warning>&nbsp;&nbsp;&nbsp;&nbsp;No custom events configured</p>\n";
   } else {
      echo "<table class='wireframe' id='sortable' cellspacing=0 cellpadding='4'>\n";
      echo "<tr class=header>\n";
      echo "<th class=wireframe>&nbsp;</th>\n";
      echo "<th class=wireframe>Event Type</th>\n";
      echo "<th class=wireframe>Conditions</th>\n";
      echo "<th class=wireframe>Severity</th>\n";
      echo "</tr>\n";

      $num_custom_events=0;

      foreach ($custom_event as $num => $event) {
         foreach ($event as $key => $value) {
            $$key = $value;
         }

         $condition="";
         if ($workstation != NULL) {
            $condition .= "WORKSTATION=$workstation, ";
         }
         if ($jobstream != NULL) {
            $condition .= "JOBSTREAM=$jobstream, ";
         }
         if ($job_workstation != NULL) {
            $condition .= "JOB_WORKSTATION=$job_workstation, ";
         }
         if ($job != NULL) {
            $condition .= "JOB=$job, ";
         }
         if ($logon != NULL) {
            $condition .= "LOGON=$logon, ";
         }
         if ($script != NULL) {
            $condition .= "SCRIPT=$script, ";
         }
         if ($prompt_name != NULL) {
            $condition .= "PROMPT=$prompt_name, ";
         }

         if ($condition == "") {
            $condition="<i>none</i>\n";
         } else {
            $condition=substr($condition,0,-2);
         }

         echo "<tr class=standard>\n";
         echo "<td class=wireframe><input type=\"radio\" name=\"selection\" value=\"$num:$condition\"></td>\n";
         echo "<td class=wireframe>".htmlspecialchars($event_type[$event_num])."</td>\n";
         echo "<td class=wireframe>".htmlspecialchars($condition)."</td>\n";
         echo "<td class=wireframe style=\"background-color: $color[$severity_level]\"><center>".htmlspecialchars($severity[$severity_level])."</center></td>\n";
      }
      echo "</table>\n";

   }
?>

<br><br>

&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Add" name="action">&nbsp;&nbsp;
// TODO: <input type="submit" value="Modify" name="action">&nbsp;&nbsp;
<input type="submit" value="Delete" name="action">&nbsp;&nbsp;
<input type="button" value="Cancel" onclick="window.location.replace('tws_event_configuration.php');">

</form>
</body>
</html>
