<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
   $path = '../';
?>
<html>
<head>
   <title>IWS/WebAdmin Navigation</title>
   <meta name="author" content="HORIZONT - Software for Data Centers; www.horizont-it.com" />
   <meta name="copyright" content="HORIZONT - Software for Data Centers; www.horizont-it.com" />
   <base target="view_window" />
   <?php tws_csssheet(false, '../'); ?>
   <script type="text/javascript" src="<?php echo $path; ?>tws_switch_menu.js"></script>
</head>
<body class="navbar">
<a href="admin_home.php">Home</a>
<br/>
<h1 onclick="switch_menu('id1');">Administration</h1>
   <div id="id1" style="display: block;">
   <a href="tws_auth_configuration.php">Authentication&nbsp;Conf.</a>
   <a href="tws_user_administration.php">User&nbsp;Administration</a>
   <a href="tws_menu_configuration.php">Menu&nbsp;Administration</a>
   <!--a href="tws_masters_configuration.php">Masters&nbsp;Configuration</a-->
   <a href="tws_report_administration.php">Report&nbsp;Administration</a>
   <a href="../tws_notes_control.php">Notes&nbsp;Administration</a>
   <a href="tws_filter_administration.php">Filter&nbsp;Administration</a>
   <a href="tws_backup_administration.php">Backup&nbsp;Administration<span style="right: 3px; _right: 14px;" title="Set Backup&nbsp;Administration Filter" onClick="parent.view_window.location='tws_backup_filter.php'; return false;">F</span></a>
   <a href="tws_miscconf.php">Misc.&nbsp;Configuration</a>
   <a href="tws_set_conf.php">WebAdmin Configuration</a>
   <a href="tws_sapjob_config.php">SAP jobs access</a>
   <br/>
   </div>
<h1 onclick="switch_menu('id2');">Log&nbsp;/&nbsp;Alert</h1>
   <div id="id2" style="display: block;">
   <a href="tws_event_configuration.php">Event&nbsp;Configuration</a>
   <a href="tws_alert_configuration.php">Alert&nbsp;Configuration</a>
   <a href="tws_log.php">IWS&nbsp;Logfile</a>
   <br/>
   </div>
<h1 onclick="switch_menu('id3');">Maintenance</h1>
   <div id="id3" style="display: block;">
   <a href="tws_msg_files.php">IWS&nbsp;Mailbox&nbsp;Files</a>
   <!--
   <a href="tws_database_file_maintenance.php">IWS Database Files</a>
   <a href="tws_pgsql_maintenance.php">PostgreSQL Maintenance</a>
   -->
   <a href="tws_database_cleanup.php">Database&nbsp;Cleanup</a>
   <a href="tws_webadmin_licensing.php">License&nbsp;Administration</a>
   <br/>
   </div>
</body>
</html>
