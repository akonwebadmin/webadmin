<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add Custom Event</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>
<?php tws_print_head('Add Custom Event', '', '../'); ?>
<br>
<?php
// Get severities
   include($severities_file);
?>
<form name="contents" method="post" action="tws_add_custom_event_exec.php">
<table border=0 cellspacing=0>
<tr>
<td class=standard colspan="2">
<h3>Event Information</h3>
</td>
</tr>
<tr>
<td class=standard>
&nbsp;&nbsp;<b>Event Type:</b>
</td>
<td><select name="event_type">
<?php
   tws_import_request_variables("GP","rqst_");
   $event_num=strtok($rqst_event_type,"_");
   $event_type=strtok("\n");
   tws_check_arg($event_num, 'tws_num');
   echo "  <option value=\"$event_num\" selected>" . htmlspecialchars(strtok($event_type,"_")) . "</option>\n";
?>
  </select>
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<?php
   if (tws_event_type($event_num,'job') || tws_event_type($event_num,'jobstream') || tws_event_type($event_num,'prompt'))  {
?>
<tr>
<td class=standard>
&nbsp;&nbsp;<b>Workstation:</b>
</td>
<td>
<input type="text" name="workstation" class='tws_mask' size=16 maxlength=16>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="button" name="workstation_list" onClick="tws_picker_open('../workstation_picker.php', 'fieldname=workstation&amp;fieldvalue='+document.contents.workstation.value);" value="List">
</td>
</tr>
<tr>
<td class=standard>
&nbsp;&nbsp;<b>Jobstream:</b>
</td>
<td>
<input type="text" name="jobstream" class='tws_mask' size=16 maxlength=16>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" name="jobstream_list" onClick="tws_picker_open('../jobstream_picker.php', 'fieldname=jobstream&amp;fieldvalue=' + document.contents.jobstream.value+'&amp;cpux=' + document.contents.workstation.value);" value="List">
</td>
</tr>
<?php
      if (tws_event_type($event_num,'job')) {
?>
<tr>
<td class=standard>
&nbsp;&nbsp;<b>Job Workstation:</b>
</td>
<td>
<input type="text" name="job_workstation" class='tws_mask' size=16 maxlength=16>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" name="job_workstation_list" onClick="tws_picker_open('../workstation_picker.php', 'fieldname=job_workstation&amp;fieldvalue='+document.contents.job_workstation.value);" value="List">
</td>
</tr>
<tr>
<td class=standard>
&nbsp;&nbsp;<b>Job:</b>
</td>
<td>
<input type="text" name="job" class='tws_mask' size=40 maxlength=255>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" name="job_list" onClick="tws_picker_open('../job_picker.php', 'fieldname=job&amp;fieldvalue='+document.contents.job.value+'&amp;cpux=' + document.contents.job_workstation.value);" value="List">
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class=standard>
&nbsp;&nbsp;<b>Logon:</b>
</td>
<td>
<input type="text" name="logon" size=32 maxlength=32>
</td>
</tr>
<tr>
<td class=standard >
&nbsp;&nbsp;<b>Script:</b>
</td>
<td>
<input type="text" name="script" size=64 maxlength=255>
</td>
</tr>
<?php
      }
   }
   if (tws_event_type($event_num,'prompt')) {
?>
<tr>
<td class=standard >
&nbsp;&nbsp;<b>Prompt Name:</b>
</td>
<td>
<input type="text" name="prompt" class='tws_mask' size=8 maxlength=8>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" name="prompt_list" onClick="window.open('../prompt_picker.php', 'fieldname=prompt');" value="List">
</td>
</tr>
<?php
   }
?>

<tr><td>&nbsp;</td></tr>
<tr><td>&nbsp;</td></tr>

<tr>
<td class=standard colspan="2">
<h3>Severity</h3>
</td>
</tr>
<tr>
<td class=standard >
&nbsp;&nbsp;<b>Severity:</b>
</td>
<td>
<select name="severity">
<option selected value="-- Select One --">-- Select One --</option>
<?php
   foreach ($severity as $severity_key => $severity_label) {
      echo "<option value=\"$severity_key\">".htmlspecialchars($severity_label)."</option>\n";
   }
?>
</td>
</tr>

</table>
<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Submit" onclick='return tws_validate_form();'>&nbsp;&nbsp;
<input type="button" value="Cancel" onclick="window.location.replace('tws_custom_events.php');">
<?   tws_print_synchro_token();  // synchro_token
?>
</form>
</body>
</html>
