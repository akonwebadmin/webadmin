<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Delete Alert</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<?php
   tws_import_request_variables("P","rqst_");

   $alert_id=tws_gpc_get($rqst_alert_id, 'tws_num');
   $event_num=tws_gpc_get($rqst_event_num, 'tws_num');
      tws_check_synchro_token();  //    synchro_token

   db_connect($webadmin_db,DB_PERSISTENT) or tws_dyer("Cannot connect to database");
   $schema=$webadmin_db['schema'];
   $query="DELETE FROM $schema.alerts WHERE alert_id=$alert_id AND event_num=$event_num";

   db_query($webadmin_db,$query) or tws_dyer("Deletion from alerts table failed. Unable to complete request");
   if (isset($webadmin_db['allow_persistent']) && tws_yesno($webadmin_db['allow_persistent'])=='NO')
      db_commit($webadmin_db) or tws_dyer("Unable to COMMIT request.");
?>

<script type="text/javascript">
window.location.replace("tws_alert_configuration.php");
</script>

</body>
</html>
