<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_profile('opener', basename($_SERVER['SCRIPT_NAME']) );

   function table_start() {
      echo "<table class=\"wireframe\" id=\"sortable\" cellspacing=0 cellpadding=4 width=\"100%\" cols=6>\n";
      echo "<colgroup span=\"1\" width=\"1\">\n";
      echo "<tr class=header>\n";
      echo "<th>&nbsp;</th>\n";
      echo "<th>Type</th>\n";
      echo "<th>Object name</th>\n";
      echo "<th>Created date</th>\n";
      echo "<th>Creator</th>\n";
      echo "<th>Rows</th>\n";
      echo "<th style=\"text-align:left;\" width=\"50%\">&nbsp;Backup filename</th>\n";
      echo "</tr>\n";
   }

   $display_mode = isset($_GET['display_mode']) ? $_GET['display_mode'] : 'frames';
   if ($display_mode === 'frames')
      tws_doctype('f');
   else
      tws_doctype('t');
   echo "<html>\n";
   echo "<head>\n";
   echo "<title>Backup Admnistration</title>\n";
   tws_adminstylesheet();

   if ($display_mode === 'frames') {
      ?>
      <script type="text/javascript">
         function doSubmit(actionButton) {
           if (window.data.document.displaybackup) {
           window.data.document.displaybackup.action.value = actionButton.value;
           window.data.document.displaybackup.submit();
        }
         }
      </script>
      <?php
      echo "</head>\n";
      tws_set_button_location();
      if (($button_location == 'top') || ($button_location == 'bottom')) {
         if ($button_location == 'top') {
            echo "<frameset rows=\"80,*\">\n";
            echo "<frame name=\"buttons\" src=\"tws_backup_administration.php?display_mode=buttons\" frameborder=\"0\">\n";
            echo "<frame name=\"data\" src=\"tws_backup_administration.php?display_mode=data\" frameborder=\"0\">\n";
         } else {
            echo "<frameset rows=\"*,80\">\n";
            echo "<frame name=\"data\" src=\"tws_backup_administration.php?display_mode=data\" frameborder=\"0\">\n";
            echo "<frame name=\"buttons\" src=\"tws_backup_administration.php?display_mode=buttons\" frameborder=\"0\">\n";
         }
         echo "<noframes>\n";
         echo "<p>Sorry, anchored buttons can only be used in a frames capable browser.</p>\n";
         echo "</noframes>\n";
         echo "</frameset>\n";
         echo "</html>\n";
      } else {
         header('Location: tws_backup_administration.php?display_mode=all');
         header('Connection: close');
         exit;
      }
   } else {
      echo "<script type=\"text/javascript\" src=\"../checkbox_selection.js\"></script>\n";
      tws_show_backup();
      ?>
      </head>
      <body<?php if ($display_mode == 'buttons') echo ' style="margin: 0; padding: 0 10px;"'; ?> onload="doLoaded();">
      <?php
      tws_set_window_title();
      $backupfilter = tws_profile('backupfilter');
      if ($display_mode === 'data' || $display_mode === 'all') {
         if ($backupfilter) {
            $filterchunks = explode("+",$backupfilter);
            foreach ($filterchunks as $key => $value) {
               if (strstr($value,'created')) {
                  list($createdfrom,$createdto) = explode(',',substr($value,8));
                  if (!isset($createdto) || empty($createdto)) {
                    if ($createdfrom = strtotime(($iso=tws_userdate_to_iso($createdfrom)) === FALSE ? trim($createdfrom) : $iso)) {
                      $createdto = $createdfrom + 86400;
                    }
                  } else {
                     $createdfrom = strtotime(($iso=tws_userdate_to_iso($createdfrom)) === FALSE ? trim($createdfrom) : $iso);
                     $createdto = strtotime(($iso=tws_userdate_to_iso($createdto)) === FALSE ? trim($createdto) : $iso);
                  }
               } else {
                  $filterchunk = explode("=",$value);
                  $f = $filterchunk[0];
                  $$f = $filterchunk[1];
               }
            }
         }
         tws_waiting(1,'../');
         $target = ($display_mode == 'all') ? '' : ' target="_parent"';
         tws_print_head('IWS Backup Administration',array('__filter__' => $backupfilter),'/');
         echo "<br>\n";
         echo '<form method="post" name="displaybackup" action="tws_backup_action.php"',$target,'>',"\n";
         $backup_dir = dir($tws_config["maestro_dir"]."/webadmin/backup/composer");
         while (($file = $backup_dir->read()) !== FALSE) {
            if (substr($file,0,1) === '.')
               continue;
            if (($result = tws_get_backupfile($tws_config["maestro_dir"]."/webadmin/backup/composer/".$file)) !== FALSE) {
               $rows = count(explode("\n",$result['content'])) - 1;
               $info = explode(".",$file);
if (!isset($result['object'][0]) || trim ($result['object'][0]) == "") {
//$result['object'] = tws_backup_parse_name($result['content'], $info[0]);
$result['object'][0] = "n/a";
}
               // filter for type
               if (isset($type) && !tws_jokercmp($info[0],$type)) {
                  continue;
               }

               // filter for object name
               if (isset($obj_name)) {
$match = 0;
foreach($result['object'] as $name) {
if(tws_jokercmp($name, "@".$obj_name, false, "tws")) {$match = 1;}
}
if(!$match) {continue;}
               }

               // filter for creator
               if (isset($creator) && !tws_jokercmp($result['creator'],$creator)) {
                  continue;
               }

               // filter for fulltext search
               if ((isset($search)) &&
                   ((isset($case_sensitive) && (strstr($result['content'],$search) === FALSE)) ||
                    (!isset($case_sensitive) && (stristr($result['content'],$search) === FALSE)))) {
                  continue;
               }

               //filter for a created datetime
               if ((isset($createdfrom) && $result['timestamp'] < $createdfrom) ||
                   (isset($createdto) && $result['timestamp'] > $createdto)) {
                  continue;
               }

               if (!$table_started) {
                  table_start();
                  $table_started = TRUE;
               }

               echo "<tr class=standard>\n";
               echo "<td><input type=\"checkbox\" name=\"selection[]\" value=\"$file\" onclick=\"selectCheckboxes(this);\"/></td>\n";
               echo "<td>".htmlspecialchars($info[0])."</td>\n";
echo "<td>";
for($i=0; $i<count($result['object']); $i++) {
                  echo htmlspecialchars($result['object'][$i])."\n";
               }
echo "</td>\n";
               echo "<td>".tws_iso_to_userdate(date('Y-m-d H:i:s', $result['timestamp']))."</td>\n";
               echo "<td>$result[creator]</td>\n";
               if ($rows > 0) echo "<td>".htmlspecialchars($rows)."</td>\n";
               else echo "<td class=error>".htmlspecialchars($rows)."</td>\n";
               echo "<td><a href=\"javascript:showBackup('".urlencode($file)."')\">".htmlspecialchars($file)."</a></td>\n";
               echo "</tr>\n";
            }
         }
         $backup_dir->close();

         if ($table_started) {
            echo "</table>\n";
         } else {
            echo "<p class=warning>No backup file found</p>\n";
         }
         echo '<input type="hidden" name="action" value="">';
      }

      if ($display_mode === 'buttons' || $display_mode === 'all') {
         $anchored = '';
         if ($display_mode === 'buttons') {
            echo '<form onsubmit="return false;" action="" style="margin: 5px 0 0 0; padding: 0;">'."\n";
            $anchored = ' onclick="window.parent.doSubmit(this)"';
            tws_print_check_clear_all('window.parent.data.document.displaybackup')."\n";
         } else {
            tws_print_check_clear_all('window.document.displaybackup')."\n";
         }
         echo "<input type=\"submit\" name=\"action\" value=\"Filter\"$anchored />\n";
         if ($backupfilter) {
            echo "<input type=\"submit\" name=\"action\" value=\"Save Filter\"$anchored/>\n";
         }
         echo "<input type=\"submit\" name=\"action\" value=\"Display\"$anchored />\n";
         echo "<input type=\"submit\" name=\"action\" value=\"Delete\"$anchored />\n";
         echo "<input type=\"submit\" name=\"action\" value=\"Compare\"$anchored />\n";
         echo "<input type=\"submit\" name=\"action\" value=\"Compare With Current\"$anchored />\n";

         if ($display_mode === 'all') {
            echo '<input type="button" value="Refresh" onClick="javascript:window.location.reload(false)" />'."\n";
            echo '<input type="button" value="Print" onclick="javascript:window.print()" />';
         } else {
            echo '<input type="button" value="Refresh" onClick="javascript:window.parent.data.location.reload(false)" />'."\n";
            echo '<input type="button" value="Print" onclick="javascript:window.parent.data.focus(); window.parent.data.print();" />'."\n";
         }
      }

      echo "</form>\n";
      echo "</body>\n";
      echo "</html>\n";
   }

   tws_waiting(0,'../');
?>