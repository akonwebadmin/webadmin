<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Setting Menu Configuration</title>
<?php tws_adminstylesheet(); ?>

<script type="text/javascript">
function goback() {
window.location.replace("tws_user_administration.php#defaults");
}
</script>

</head>
<body>

<h1>Setting Menu Configuration</h1>
<br>
<?php
   tws_import_request_variables("P","rqst_");
   tws_check_synchro_token();     // synchro_token

   $menu_item=$rqst_menu_item;
   if (!isset($menu_item)) {
      $menu_item[]="_NULL_";
   }

   if (tws_save_menu_configuration($menu_item,'all_users')) {
      echo '<p class="message">Default menu configuration for all user has been updated.</p>'."\n";
      echo "<br><br><input type='Button' name='action' value=' Ok ' onClick='goback()'>";
   } else {
      tws_err('Saving failed');
   }
?>
</body>
</html>
