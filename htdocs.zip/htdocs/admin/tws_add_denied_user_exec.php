<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add Denied User</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>
<?php
   tws_import_request_variables("P","rqst_");

   $username=tws_gpc_get($rqst_username, 'tws_alfanum\\tws_alfanum', '\\');
   tws_check_synchro_token();     // synchro_token

   $denyusers="$base_inst_dir/httpd/conf/denyusers";
   $newdenyusers="$base_inst_dir/httpd/conf/denyusers.new";
   $bakdenyusers="$base_inst_dir/httpd/conf/denyusers.bak";

   if (!file_exists($denyusers)) {
      $fp=fopen($denyusers,"w") or tws_dyer("Unable to create file '$denyusers'");
      fclose($fp);
   }
// Modify denyusers file
   $found=FALSE;
   $fp=fopen($denyusers,"r") or tws_dyer("Unable to open file $denyusers");
   $newfp=fopen($newdenyusers,"w") or tws_dyer("Unable to open file $newdenyusers");
   while ($buffer=fgets($fp,4096)) {
      $user=trim($buffer);
      if ($user == $username) {
         $found=TRUE;
      }
      fputs($newfp,$buffer);
   }
   fclose($fp);
   if ($found != TRUE) {
      fputs($newfp,"$username\n");
   }

   fclose($newfp);

   copy($denyusers,$bakdenyusers);
   copy($newdenyusers,$denyusers);
   unlink($newdenyusers);

   echo "<script language=\"Javascript\">\n";
   echo "window.location.replace(\"tws_auth_configuration.php?authtype=os\");\n";
   echo "</script>\n";
?>
</body>
</html>
