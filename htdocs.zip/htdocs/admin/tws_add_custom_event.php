<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add Custom Event</title>
<script type="text/javascript">
function add_page2(event_type_select) {
   open("tws_add_custom_event2.php?event_type=" + event_type_select,"_self");
}
</script>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<h1>Add Custom Event</h1>
<br><br>

<?php
// Get event types
   include($event_types_file);

// Get severities
   include($severities_file);

// TODO: select onchange opens new page = rework it to hide appropriate fields and work woth one file
?>
<form name="type_select" method="post" action="tws_add_custom_event_exec.php">
<table border=0 cellspacing=0>
<tr>
<td class=standard colspan="2">
<h3>Event Information</h3>
</td>
</tr>
<tr>
<td class=standard width=120>
&nbsp;&nbsp;<b>Event Type:</b>
</td>
<td><select name="event_type" onchange="add_page2(document.type_select.event_type.options[document.type_select.event_type.selectedIndex].value)">
  <option selected value="-- Select One --">-- Select One --</option>
<?php
   foreach ($event_type as $each_event_num => $each_event_type) {
      if (tws_event_type($each_event_num,'job') || tws_event_type($each_event_num,'jobstream') || tws_event_type($each_event_num,'prompt')) {
         echo "  <option value=\"" . $each_event_num . "_" . $each_event_type . "\">".htmlspecialchars($each_event_type)."</option>\n";
      }
   }
?>
  </select>
</td>
</tr>
</table>
<br><br>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="button" value="Cancel" onclick="window.location.replace('tws_custom_events.php');">
</form>
</body>
</html>
