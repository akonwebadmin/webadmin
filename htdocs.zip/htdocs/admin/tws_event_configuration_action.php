<?php
//   HORIZONT Software GmbH, Munich
//

   require_once("tws_functions.php");
   tws_import_request_variables("P","rqst_");

   $action=$rqst_action;
   $event=tws_gpc_get($rqst_event, 'tws_num');
   $sel_severity=tws_gpc_get($rqst_sel_severity, 'tws_num');

   switch ($action) {
     case "Save":
       include("tws_set_reported_events.php");
       break;
     case "Custom Events":
       include("tws_custom_events.php");
       break;
     case "Edit Severity Levels":
       include("tws_edit_severity_levels.php");
       break;
   }
?>