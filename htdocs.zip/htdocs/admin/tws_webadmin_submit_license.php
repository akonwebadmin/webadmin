<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t"); 
?>
<html>
<head>
<title>IWS/WebAdmin License Accepted</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<H1>Submitting New License Key</h1>

<?php
      tws_check_synchro_token();     // synchro_token
   tws_import_request_variables("P","rqst_");
   
   $license_key_name=$rqst_license_key_name;
   $license_key=$rqst_license_key;

   switch ($license_key_name){
//
// IWS/WebAdmin license key check
      case "IWS/WebAdmin" :
// Verify license key
         $printlic_command=new hwi_cmd("$base_inst_dir/bin/printlic", $license_key);
         $stdout=Array();
         tws_popen($printlic_command,$ec,$stdout,$stdout) or tws_dyer("Unable to print license key", $stdout);
         foreach ($stdout as $buffer){
            if (substr($buffer,0,10) == "System ID:") {
               $license_system_id=trim(substr($buffer,11));
            } elseif (substr($buffer,0,10) == "Max Nodes:") {
               $license_node_count=trim(substr($buffer,11));
            } elseif (substr($buffer,0,16) == "Expiration Date:") {
               $license_expiration_date=trim(substr($buffer,17));
            }
         }

// Verify expiration date is realistic
         if (!is_numeric($license_expiration_date)) {
            tws_dyer("License key entered is invalid",$stdout);
         }

         // Verify system_id matches this system's ID
         if (($get_system_id=tws_get_sysid_command())===FALSE) {
            tws_dyer("Cannot determine the system ID of this machine");
         } else {
            $stdout=$stderr=array();
            tws_popen($get_system_id,$ec,$stdout,$stderr) or tws_dyer("Unable to get system id", array('stdout'=>$stdout,'stderr'=>$stderr));
            $system_id=trim($stdout[0]);
            if ($host_os == "win32") {
               $tok=strtok($system_id,":");
               $tok=trim(strtok("\n"));
               $system_id=$tok;
               $system_id=str_replace("-",NULL,$system_id);
            }
            $length=strlen($system_id);
            if (($length < 4) || ($length > 40)) {
               tws_dyer("Cannot determine required system ID of this machine");
            } elseif (($system_id != $license_system_id) && ($license_system_id != "any") && ($license_system_id != "ANY") && (substr($license_system_id,0,1) != "*")) {
               tws_dyer("License key system ID ($license_system_id) does not match the system ID ($system_id). Cannot continue.");
            }
         }
// Done with license key verification
         $license_key_file="$maestro_dir/webadmin/etc/license.key";
         $license_key_tmpfile="$webadmin_tmp_dir/license.key.tmp";
         break;

//
// zli_module (netplans) license key validity check       
      case "IWS/WebAdmin Netplan Module" :
// Verify license key
         $printlic_command=new hwi_cmd("$base_inst_dir/bin/printlic", $license_key);
         $stdout=Array();
         tws_popen($printlic_command,$ec,$stdout,$stdout) or tws_dyer("Unable to print zli license key", $stdout);
         foreach ($stdout as $buffer){
            if (substr($buffer,0,10) == "System ID:") {
               $license_system_id=trim(substr($buffer,11));
            } elseif (substr($buffer,0,10) == "Max Nodes:") {
               $license_node_count=trim(substr($buffer,11));
            } elseif (substr($buffer,0,16) == "Expiration Date:") {
               $license_expiration_date=trim(substr($buffer,17));
            }
         }

// Verify expiration date is realistic
         if (!is_numeric($license_expiration_date)) {
            tws_dyer("License key entered is invalid",$stdout);
         }

         $license_key_file="$maestro_dir/webadmin/etc/zli_license.key";
         $license_key_tmpfile="$webadmin_tmp_dir/zli_license.key.tmp";
         break;

      default :
         tws_dyer("Unknown license key name");
         break;
   }//switch

//
// Create or update the the license key file
//
   if (tws_yesno($tws_config['virtual_hosts'],TRUE,FALSE)) {
      $cpcmd = isset($tws_config['cp']) ? $tws_config['cp'] : ($tws_config['host_os'] !== 'win32' ? '/bin/cp' : 'copy');
      if (is_file("$license_key_file")) {
         $stdout='';
         $cmd = new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), $cpcmd, $license_key_file, $license_key_file.'.old');
         tws_popen($cmd, $ec, $stdout, $stdout);
      }
      if (!$fp=fopen($license_key_tmpfile,"w")) {
         tws_dyer("Cannot create temporary license key file $license_key_tmpfile.");
      }
      $num_bytes=fwrite($fp,$license_key);
      if ($num_bytes < 0) {
         fclose($fp);
         tws_dyer("Cannot write temporary license key file $license_key_tmpfile.");
      }
      //install the license key file
      $stdout='';
      tws_popen(tws_sudo($cpcmd.' "'.$license_key_tmpfile.'" "'.$license_key_file.'"', $tws_config['maestro_user']), $ec, $stdout, $stdout);
      if ($ec!='0') {
         tws_dyer("Cannot install license key file $license_key_file.", $stdout);
      }
   } else {
      if ($host_os == "win32") {
         if (copy($license_key_file, $license_key_file.".old")) {
            unlink($license_key_file);
         }
      } else {
         rename($license_key_file, $license_key_file.".old");
      }
      if (!$fp=fopen($license_key_file,"w")) {
         tws_dyer("Cannot create license key file $license_key_file.");
      }
      //write the license key file
      $num_bytes=fwrite($fp,$license_key);
      if ($num_bytes < 0) {
         fclose($fp);
         tws_dyer("Cannot write license key file $license_key_file.");
      }
   }

// reload licenses to the cache
   tws_license_check('enflic', 1);
   tws_license_check('enf', 1);

   echo "<script language=\"Javascript\">\n";
   echo "window.location.replace(\"tws_webadmin_licensing.php\");\n";
   echo "</script>\n";
?>
</body>
</html>
