<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Cleanup Events Table</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>
<h1>Cleanup Events Table</h1>
<br><br>

<?php
   // TODO:  tws_check_synchro_token();     // synchro_token
   tws_import_request_variables("P","rqst_");

   $events_age=tws_gpc_get($rqst_events_age, 'tws_num');

   if ($events_age == "") {
      tws_warning("Record age not specified");
      tws_dyer();
   } elseif (!is_numeric($events_age)) {
      tws_dyer("Record age is invalid");
   }

   set_time_limit(600);

   db_connect($webadmin_db,DB_PERSISTENT) or tws_dyer("Could not connect to database");
   $schema=$webadmin_db['schema'];

   $age_datestamp=mktime(12,0,0,date("m"),date("d") - $events_age,date("Y"));
   $age_date=date("Y-m-d 23:59:59",$age_datestamp);
   $disp_age_date = substr($age_date,0,10);

   $check_query="SELECT COUNT(*) AS NUMROWS FROM $schema.events WHERE tstamp < '$age_date' AND event_id!=0";

   if (!db_query($webadmin_db,$check_query)) {
      tws_dyer("Database query error");
   }

   $row=db_fetch_row($webadmin_db);
   if ($row) {
      $num_records=$row['NUMROWS'];
      echo "&nbsp;&nbsp;&nbsp;&nbsp;All records older than <b>$disp_age_date</b> will be deleted from the <b>events</b> table\n";
      echo "<br><br>\n";
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<b>$num_records</b> records selected for deletion\n";
      echo "<br><br><br>\n";
      echo "<form method=\"post\" action=\"tws_cleanup_events_exec.php\">\n";
      echo "<input type=\"hidden\" name=\"age_date\" value=\"$age_date\">\n";
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Proceed\" name=\"action\">\n";
      echo "&nbsp;&nbsp;<input type='button' value='Cancel' onclick=\"window.location.replace('tws_database_cleanup.php')\">\n";
         tws_print_synchro_token();  // synchro_token
      echo "</form>\n";
   }
?>
</body>
</html>
