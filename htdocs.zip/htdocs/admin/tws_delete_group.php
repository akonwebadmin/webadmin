<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Delete IWS/WebAdmin Group</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<?php tws_print_head('Delete IWS/WebAdmin Group','','../'); ?>
<br><br>
<?php

   if (!isset($selection) || ($selection == "") ) {
      echo "<p class=warning>No group selected</p>\n";
      echo "<input type='button' value='Ok' name='Back' onClick='history.back()'>";
   }
   // Read Apache Groups
   $authgroups = $tws_config['base_inst_dir']."/httpd/conf/authgroups";
   $fp=fopen($authgroups,"r") or tws_dyer("Can't open $authgroups file");
   while ($buffer=fgets($fp,4096)) {
      $group = strtok($buffer,":");
      if($group == $selection){
         $members = strtok("\n");
         if (trim($members)!='')
            echo "<p class=warning>".htmlspecialchars($selection)." group contains some users. Do you realy want to delete it?</p>\n";
      }
   }
   fclose($fp);

   echo "<form method='post' action='tws_delete_group_exec.php'>
   <h3>Confirm Group Delete: <b>".htmlspecialchars($selection)."</b></h3>\n";
   echo "<input type='hidden' name='groupname' value='".htmlspecialchars($selection)."'>\n";
   tws_print_synchro_token();     // synchro_token
   echo "<br>
      <input type='submit' name='action' value='Delete'>&nbsp;
      <input type='button' name='action' value='Cancel' onClick='window.location.replace(\"tws_user_administration.php#groups\");'>
      </form>";
?>
</body>
</html>
