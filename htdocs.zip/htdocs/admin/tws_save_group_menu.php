<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Saving Group Menu Configuration</title>
<?php tws_adminstylesheet(); ?>

<script type="text/javascript">
function goback() {
window.location.replace("tws_user_administration.php#groups");
}
</script>
</head>
<body>

<?php
   tws_import_request_variables("P","rqst_");

   $menu_item = tws_gpc_get($rqst_menu_item);
   $groupname = tws_gpc_get($rqst_groupname);
   $action = tws_gpc_get($rqst_action);

   if ($action == "Save Changes") {
      if (!isset($menu_item)) {
         $menu_item[]="_NULL_";
      }
      if (tws_save_group_menu_configuration($menu_item,$groupname)) {
         tws_print_head("Menu Configuration saved",'','../');
         echo "<p class=warning>Menu Configuration saved for group $groupname</p>";
         echo "<br><br><input type='Button' name='action' value=' Ok ' onClick='goback();'>";
      }
      else {
         tws_dyer('Saving failed', '', "tws_user_administration.php");
      }
   }
   elseif ($action == "Use Default Values") {
      $action = urlencode($action);
      echo "<script language='Javascript'>\n";
      echo "window.location.replace('tws_define_group_menu.php?group=".$groupname."&action=".$action."');\n";
      echo "</script>\n";
   }
   elseif ($action == "Remove Custom Profile") {
      tws_RemoveCustomGroupMenu($groupname);
      echo "<script language='Javascript'>\n";
      echo "window.location.replace('tws_user_administration.php#groups');\n";
      echo "</script>\n";
   }
?>
</body>
</html>
<?php

function tws_RemoveCustomGroupMenu($groupname) {   // remove menu.php file from home directory
   global $tws_config;
   $user_setting_dir = $tws_config['user_setting_dir'];
   $webadmin_user_home_dir = $tws_config['webadmin_user_home_dir'];

   if($groupname != '') {
      $myfile = $webadmin_user_home_dir."/groups/".$groupname.$user_setting_dir."/menu.php";
      if ( is_file($myfile) ) {
         $bakfile=$myfile .".bak";
         copy($myfile,$bakfile);
         unlink ($myfile);
      }
   }
}


//    *********************
//    save menu for group
//

function tws_save_group_menu_configuration($menu_item, $groupname) {
   global $tws_config;
   $user_setting_dir = $tws_config['user_setting_dir'];
   $webadmin_user_home_dir = $tws_config['webadmin_user_home_dir'];
   $webadmin_all_user_dir = $tws_config['webadmin_all_user_dir'];
   $base_inst_dir = $tws_config['base_inst_dir'];

   $dir=$webadmin_user_home_dir."/groups/".$groupname;

   if (!is_dir($dir)) {
      if (!tws_mkdir($dir)) {
         tws_dyer ("Unable to create $dir directory!", '', "tws_user_administration.php");
         return FALSE;
      }
   }
   if (!is_dir($dir.$user_setting_dir)) {
      if (!tws_mkdir($dir.$user_setting_dir)) {
         tws_dyer ("Unable to create ".$dir.$user_setting_dir." directory!", '', "tws_user_administration.php");
         return FALSE;
      }
   }
   $dir = $dir.$user_setting_dir;
   $filename = $dir."/menu.php";
   $filename2="$base_inst_dir/etc/menu.xml";

   if (!$fp2=fopen($filename2,"r")) {
      tws_dyer('', 'Unable to open '.$filename2, '', "tws_user_administration.php");
      return FALSE;
   }
   else {
      while ($buffer=fgets($fp2,4096)) {
         if (substr($buffer,0,1) == "<") {
            $tok=strtok($buffer," >");
            switch($tok) {
              case "<menu":
              case "<br":
              case "<heading":
                  break;
              case "<item":
                $attrs=strtok(">");
                $item=strtok("<");
                //support of INIAS attribute (see menu.xml)
                $item_check = strtr(preg_match('/inias\s*=\s*"([^"]+)/i', $attrs, $inias) ? $inias[1] : $item, " ", "_");
                $endtag=strtok("\n");
                if (preg_match("/( )*href=( )*\"([^\"]*)(\"){1}/", $attrs, $href) && $endtag=="/item>") {
                  $href=$href[3];
                  $all_items[]=$item_check;
                }
                break;
            }
         }
      }
   }
   fclose($fp2);

   if (is_file($filename)) {
      copy($filename, $filename.'.bak');
   }
   $fp=fopen($filename,'w');
   if (!$fp) {
      tws_dyer("Unable to create group's menu configuration file", array('groupname'=>$groupname, 'userdir'=>$dir.$user_setting_dir, 'filename'=>$filename), "tws_user_administration.php");
      return FALSE;
   }
   $content[]="<?php\n";
   foreach ($all_items as $item) {
      if (in_array($item,$menu_item)) {
         $content[]='$'.$item."=1;\n";
      }
      else {
         $content[]='$'.$item."=0;\n";
      }
   }
   $content[]="?>\n";
   foreach ($content as $line) {
      $num_bytes=fwrite($fp,$line);
      if ($num_bytes < 0) {
         fclose($fp);
         tws_dyer("Unable to write user's menu configuration file", array('groupname'=>$groupname, 'userdir'=>$dir.$user_setting_dir, 'filename'=>$filename),  "tws_user_administration.php");
         return FALSE;
      }
   }
   fclose($fp);
   tws_chmod($filename,0644);
// remove menu from Session
$my_groupname = tws_profile('auth_user_group');
if($my_groupname == $groupname)
tws_profile("menu", '');
   return TRUE;
}

?>