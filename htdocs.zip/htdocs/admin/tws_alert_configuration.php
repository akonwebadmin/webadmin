<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
   tws_profile('opener', basename($_SERVER['SCRIPT_NAME']) );
?>
<html>
<head>
<title>Alert Configuration</title>
<?php
   tws_adminstylesheet();
   tws_import_request_variables("P","rqst_");
?>
</head>
<body>
<?php
   tws_set_window_title();
   tws_print_head('Alert Configuration', 'tws_alert_configuration_help.php', '../');
?>

<h2>Configured Alerts:</h2>
<form method=post action="tws_alert_configuration_action.php">

<?php
   db_connect($webadmin_db,DB_PERSISTENT) or tws_dyer("Cannot connect to DB");
   $schema = $webadmin_db['schema'];

// Get event_types
   include($event_types_file);
// Get severity levels
   include($severities_file);
// Get alerts
   $query="SELECT event_num,severity,workstation,jobstream,job_workstation,job,logon,script,alert_type,recipient,command,description,alert_id FROM $schema.alerts where alert_id > 0 ORDER BY alert_id DESC";
   db_query($webadmin_db,$query) or tws_dyer("Unable to retrieve alert list");
   $row = db_fetch_row($webadmin_db);
   if (!$row) {
      echo "<p class=warning>No alerts configured</p>\n";
   } else {
      echo "<table class='wireframe sortable' cellspacing=0 cellpadding=4>\n";
      echo "<tr class=header>\n";
      echo "<th class=wireframe>&nbsp;</th>\n";
      echo "<th class=wireframe>Event Type</th>\n";
      echo "<th class=wireframe>Conditions</th>\n";
      echo "<th class=wireframe>Recipient / Command</th>\n";
      echo "<th class=wireframe>Description</th>\n";
      echo "</tr>\n";
      $first=true;

      do {
         $event_num=$row['EVENT_NUM'];
         $severity=$row['SEVERITY'];
         $workstation=$row['WORKSTATION'];
         $jobstream=$row['JOBSTREAM'];
         $job_workstation=$row['JOB_WORKSTATION'];
         $job=$row['JOB'];
         $logon=$row['LOGON'];
         $script=$row['SCRIPT'];
         $alert_type=$row['ALERT_TYPE'];
         $recipient=$row['RECIPIENT'];
         $command=$row['COMMAND'];

         $description=$row['DESCRIPTION'];
         $description=preg_replace_callback('/<!--TWA_METADATA--.*--TWA_METADATA-->/',create_function('$matches','global $twa_meta; $twa_meta=$matches[0]; return "";'),$description);
         $description=trim($description);
         if (trim($description) == "") {
            $description="";
         }

         $alert_id=$row['ALERT_ID'];

         echo "<tr class=standard>\n";

         $condition="";
         if ($severity != NULL) {
            if (isset($severity_label[$severity])) {
               $condition .= "SEVERITY=$severity_label[$severity]($severity), ";
            } else {
               $condition .= "SEVERITY=($severity), ";
            }
         }
         if ($workstation != NULL) {
            $condition .= "WORKSTATION=$workstation, ";
         }
         if ($jobstream != NULL) {
            $condition .= "JOBSTREAM=$jobstream, ";
         }
         if ($job_workstation != NULL) {
            $condition .= "JOB_WORKSTATION=$job_workstation, ";
         }
         if ($job != NULL) {
            $condition .= "JOB=$job, ";
         }
         if ($logon != NULL) {
            $condition .= "LOGON=$logon, ";
         }
         if ($script != NULL) {
            $condition .= "SCRIPT=$script, ";
         }
         if ($condition == "") {
            $condition=" ";
         } else {
            $condition=substr($condition,0,-2);
         }

         $selection = Array(
            "alert_id" => $alert_id,
            "event_num" => $event_num,
            "condition" => $condition,
            "alert_type" => $alert_type,
            "recipient_command" => ( $alert_type=='EMAIL' ? $recipient : $command )
         );

         echo "<td class=wireframe><input type=\"radio\" name=\"selection\" value=\"".urlencode(serialize($selection))."\"";
         if ($first) echo " checked";
         echo "></td>\n";
         $first=false;

         if ($event_num == 0) {
            echo "<td class=wireframe>Severity</td>\n";
         } else {
            echo "<td class=wireframe>".htmlspecialchars($event_type[$event_num])."</td>\n";
         }

         echo "<td class=wireframe>".htmlspecialchars($condition)."</td>\n";
         if ($alert_type == "EMAIL") {
            echo "<td class=wireframe>".htmlspecialchars($recipient)."</td>\n";
         } elseif ($alert_type == "COMMAND") {
            echo "<td class=wireframe>".htmlspecialchars($command)."</td>\n";
         }

         echo "<td class=wireframe>".htmlspecialchars($description)."</td>\n";
      } while ($row = db_fetch_row($webadmin_db));
      echo "</table>\n";
      if ($row===FALSE) tws_err('Unable to fetch all alert data');
   }
?>

<br><br>

&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Add" name="action">
&nbsp;&nbsp;<input type="submit" value="Modify" name="action">
&nbsp;&nbsp;<input type="submit" value="Delete" name="action">

</form>
</body>
</html>
