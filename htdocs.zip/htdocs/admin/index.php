<?php
//   HORIZONT Software GmbH, Munich
//


   if (@$_GET['logout']==1) {
      $oldauth=str_replace("\\\\","\\",@$_GET['oldauth']);
      if ($oldauth==$_SERVER['PHP_AUTH_USER']) {
         header('WWW-Authenticate: Basic realm="IWS/WebAdmin"');
         header('HTTP/1.0 401 Unauthorized');
         session_start();
         $_SESSION = array();
         if (isset($_COOKIE[session_name()]))
            setcookie(session_name(), '', time()-42000, '/');
         session_destroy();
      }
      echo "<script language=\"Javascript\">\n";
      echo "  location.replace('/admin/');";
      echo "</script>\n";
      exit;
   }
   require_once 'tws_functions.php';
   tws_doctype('f');
?>
<html>
<head>
<title>IWS/WebAdmin Administration</title>
<script type="text/javascript">if(self!=top) top.location = self.location;</script>
</head>
<frameset rows="17, *" frameborder="0" border="0" framespacing="0">
   <frame id="topbar" name="topbar" src="admin_topbar.php" scrolling="no" noresize />
   <frameset id="frameset" cols="187, *" frameborder="0" border="0" framespacing="0">
      <frame id="navbar" name="navbar" src="admin_navbar.php" />
      <frame id="view_window" name="view_window" src="admin_home.php" />
    </frameset>
</frameset>
<noframes>
   <p>
      Sorry, this document can only be viewed in a frames capable browser
   </p>
</noframes>
</html>
