<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');
?>
<html>
<head>
   <title>Add/Modify Alert Help</title>
   <?php tws_adminstylesheet(); ?>
</head>
<body class=help>
<?php
   tws_set_window_title();
   $path = '../';
   include $path.'tws_help_topbar.php';
?>
<h1 class=help>Add/Modify Alert Help</h1>
<p>Use the <strong>Add Alert</strong> or <strong>Modify Alert</strong> page to define a new or modify an existing alert by filling in the fields:
<p><strong>Event Type</strong> : The event type, one of:
<ul>
  <li><strong>Severity</strong> (All events matching the selected severity level)</li>
<?php
   include "event_types.php";
   foreach ($event_type as $val) {
      echo "  <li><strong>$val</strong></li>";
   }
?>
</ul>
<p><strong>Workstation</strong> : Workstation name. Wildcards can be used: * matches any string of characters and ? matches any single character.
<p><strong>Jobstream</strong> : Jobstream name. Wildcards can be used: * matches any string of characters and ? matches any single character.
<p><strong>Job Workstation</strong> : Job Workstation name - for job event types only. Wildcards can be used: * matches any string of characters and ? matches any single character.
<p><strong>Job</strong> : Job name - for job event types only. Wildcards can be used: * matches any string of characters and ? matches any single character.
<p><strong>Logon</strong> : Job Logon ID - for job event types only. Wildcards can be used: * matches any string of characters and ? matches any single character.
<p><strong>Script</strong> : Job Script - for job event types only. Wildcards can be used: * matches any string of characters and ? matches any single character.
<p><strong>Severity</strong> : Severity Level - for Severity event type only.
<p><strong>Recipient</strong> : To generate an email alert when the event occurs, enter an email address in the <strong>Recipient</strong> field.
<p><strong>Custom Subject</strong> : To customize the email subject, enter the desired content in the <strong>Suctom Subject</strong> field.
<p><strong>Custom Email Text</strong> : To customize the email message text, enter the desired message in the <strong>Custom Email Text</strong> field. If the email text is not specified, a generic message format will be used that includes the event type, workstation name, job name, etc. If a custom email message text is specified, the following variables can be used:
<ul>
  <li><b>${workstation}</b> : Workstation Name</li>
  <li><b>${jobstream}</b> : Jobstream Name</li>
  <li><b>${jobstream_original_name}</b> : Jobstream Original Name</li>
  <li><b>${job_workstation}</b> : Job Workstation Name</li>
  <li><b>${job}</b> : Job Name</li>
  <li><b>${logon}</b> : Logon</li>
  <li><b>${script}</b> : Script name</li>
  <li><b>${scheduled_time}</b> : Scheduled time of a jobstream</li>
  <li><b>${event_time}</b> : Time when the event has occurred</li>
</ul>
<p>The variables will be substitued when the email message is sent by IWS/WebAdmin.
<p><strong>Command</strong> : To execute a custom action when the event occurs, enter a command in the <strong>Command</strong> field. The command specified can be any executable script or program, including command line arguments. Always use a full path name, for example: /usr/local/bin/paging_script.sh ${job}
<p>The variables listed for <strong>Custom Email Text</strong> may also be used in the <strong>Command</strong> and <strong>Custom Subject</strong> fields, and will be substituted by IWS/WebAdmin when it executes the command.
<p><strong>Description</strong> : An optional description of the alert.
<p>Click the <strong>Submit</strong> button to save the alert.
</body>
</html>
