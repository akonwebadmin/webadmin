<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
   tws_profile('opener', basename($_SERVER['SCRIPT_NAME']) );
?>
<html>
<head>
<title>IWS/WebAdmin Masters Configuration</title>
<?php tws_adminstylesheet();
   tws_set_window_title();
?>
</head>
<body>

<h1>IWS/WebAdmin Masters Configuration</h1>
<br><br>

<form method=post action="tws_masters_configuration_action.php">

<?php
   if (!file_exists("$maestro_dir/webadmin/etc/masters.xml")) {
?>

<p class=warning>Multiple Master mode is not enabled</p>
<p class=warning>Click here to enable:&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Enable" name="action"></p>

<?php
   } else {
?>

<h3>Masters:</h3>

<?php
      $fp=fopen("$maestro_dir/webadmin/etc/masters.xml","r") or die("<p class=warning>Unable to open masters.xml file</p>\n</body>\n</html>\n");
      $num_masters=0;
      while (!feof($fp)) {
         $buffer=fgets($fp,4096);
         if (substr($buffer,0,1) == "<") {
            $tok=strtok($buffer," >");
            if ($tok == "<master") {
               $href=strtok(">");
               $master_name[$num_masters]=strtok("<");
               $junk=strtok($href,"=");
               $href_location[$num_masters]=strtok("\n");
               $href_location[$num_masters]=trim($href_location[$num_masters],'"');
               if ($href_location[$num_masters] == "#local") {
                  $href_location[$num_masters]="# LOCAL #";
                  if (!isset($localmaster)) {
                     $localmaster=$master_name[$num_masters];
                  }
               } else {
                  if(stripos($href_location[$num_masters], 'http://')===false && stripos($href_location[$num_masters], 'https://')===false)
                     $href_location[$num_masters]="http://" . $href_location[$num_masters];
               }
               $num_masters++;
            }
         }
      }
      fclose($fp);

      if ($num_masters == 0) {
         echo "<p class=warning>&nbsp;&nbsp;&nbsp;&nbsp;No masters defined</p>\n";
      } else {
         echo "<table class=wireframe cellspacing=0 cellpadding=4 cols=3>\n";
         echo "<tr class=header>\n";
         echo "<th class=wireframe>&nbsp;</th>\n";
         echo "<th class=wireframe>Master</th>\n";
         echo "<th class=wireframe>Web Server URL</th>\n";
         echo "</tr>\n";

         for ($i=0;$i<$num_masters;$i++) {
            echo "<tr>\n";
            echo "<td class=wireframe><input type=\"radio\" name=\"selection\" value=\"".htmlspecialchars($master_name[$i])."\"";
               if ($i==0) echo " checked";
               echo "></td>\n";
            echo "<td class=wireframe>".htmlspecialchars($master_name[$i])."</td>\n";
            echo "<td class=wireframe>".htmlspecialchars($href_location[$i])."</td>\n";
            echo "</tr>\n";
         }
         echo "</table>\n";
      }

      echo "<br><br>\n";

      echo "<input type=\"hidden\" name=\"num_masters\" value=\"".htmlspecialchars($num_masters)."\">\n";
      if (isset($localmaster)) {
         echo "<input type=\"hidden\" name=\"localmaster\" value=\"".htmlspecialchars($localmaster)."\">\n";
      }

      echo "<input type=\"submit\" value=\"Add\" name=\"action\">\n";
      if ($num_masters != 0) {
         echo "&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Modify\" name=\"action\">\n";
         echo "&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Delete\" name=\"action\">\n";
      }
   }
   tws_print_synchro_token();     // synchro_token
?>
</form>
</body>
</html>
