<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Define User Menu</title>
<script type="text/javascript">

function MenuCheckAll() {
 selection = document.menu.elements['menu_item[]'];
 selection.checked=true;
 for (i=0; i<selection.length; i++) {
  selection[i].checked=true;
 }
}

function MenuClearAll() {
 selection = document.menu.elements['menu_item[]'];
 selection.checked=false;
 for (i=0; i<selection.length; i++) {
  selection[i].checked=false;
 }
}

function goback() {
   window.location.replace("tws_user_administration.php");
}

function checkSection(el, num) {
   if( $(el).is(':checked') )
      $('input:checkbox.'+num).attr('checked','checked');
   else
      $('input:checkbox.'+num).removeAttr('checked');
}

</script>
<?php tws_adminstylesheet(); ?>
</head>
<body>
<?php
   tws_import_request_variables("GP","rqst_");

   if (urldecode($rqst_action) == "Use Default Values" || urldecode($rqst_action) == "Use Group Default Values" ) {  // back call from tws_save_user_menu.php
      $selection[0] = tws_gpc_get(urldecode($rqst_user), 'tws_alfanum\\tws_alfanum', '\\');
      $action = urldecode($rqst_action);
   }

   if (!isset($selection) || count($selection) == 0 ) {
      tws_dyer('No user selected','','tws_user_administration.php');
   }
   $cnt=count($selection);

   // Header
   if($cnt==1) {
      $username=$selection[0];
      $groupname = tws_groupname($username);
      if( $groupname == '' ) {
         tws_print_head('Define User Rights: '.htmlspecialchars($username), '', '../');
      }
      else {
         tws_print_head('Define User Rights: '.htmlspecialchars($username) . " (". htmlspecialchars($groupname) ." Group)",'','../');
      }
      if($groupname == 'admin')
         echo "<p class=warning>Admin user selected. Layout settings will not take effect. Admin users have full rights always.</p>";
   }
   else {
      $username='';
      tws_print_head('Define User Rights for selected users:', '', '../' );
      echo "<p class=warning>Multiply users selected. Layout settings starts with the default layout and will overwrite settings for all selected users.</p>";
   }


   $using_custom=false;
   $using_group_defaults = false;
   $using_defaults=false;

   if($cnt==1) {
      if (is_file($webadmin_user_home_dir."/".$username.$user_setting_dir."/menu.php")){
         $using_custom = true;
      }
      elseif(is_file($webadmin_user_home_dir."/groups/".$groupname.$user_setting_dir."/menu.php")) {
         $using_group_defaults = true;
      }
      else {$using_defaults = true;}
   }
?>
<form method='post' name='menu' action='tws_save_user_menu.php'>
<table border='0' cellspacing='0'>
<tr>
<td class='standard'>
<h3>Menu Items:</h3>
</td>
</tr>
<?php
   if($action == "Use Default Values") {
      $res = tws_display_group_menu_configuration('default');
   }
   elseif ($action == "Use Group Default Values") {
      $res = tws_display_group_menu_configuration($groupname);
   }
   else {   // Normal way
      if($using_group_defaults) {
         $res = tws_display_group_menu_configuration($groupname);
      }
      elseif($cnt==1) {
         $res = tws_display_menu_configuration($username);
      }
      else
         $res = tws_display_menu_configuration();
   }
   if (!$res) {
      die("<p class=warning>An Error occured when reading menu configuration</p></body></html>");
   }
?>
</table>
&nbsp;&nbsp;&nbsp;<a href="Javascript:MenuCheckAll();">Check All</a>&nbsp;&nbsp;-&nbsp;&nbsp;<a href="Javascript:MenuClearAll();">Clear All</a>
<br><br>
<?php
// ****** Massages *********** //
   if($groupname == 'admin')
      echo "<p class=warning>Admin user selected. Layout settings will not take effect. Admin users have full rights always.</p>";
   else {
      if ($using_custom) {
         echo "<p class=warning>User currently has custom menu profile</p>";
      }
      elseif ($using_group_defaults) {
         echo "<p class=warning>User currently has <a href='tws_define_group_menu.php?action=Define Group Menu&selection=$groupname'>$groupname group's rights</a> - Saving will create a custom menu for the user</p>";
      }
      elseif ($using_defaults) {
         echo "<p class=warning>User currently has default menu rights - Saving will create a custom menu for the user</p>";
      }
   }
// ****** Buttons *********** //
   if($using_custom) {
      echo "<input type='submit' name='action' value='Use Default Values'>&nbsp;";
      echo "<input type='submit' name='action' value='Use Group Default Values'>&nbsp;";
      echo "<input type='submit' name='action' value='Remove Custom Profile'>&nbsp;";
   }
   elseif($cnt>1) {
      echo "<input type='submit' name='action' value='Remove Custom Profile'>&nbsp;";
   }
   echo tws_create_hidden_inputs($selection, 'selection', null);

   tws_print_synchro_token();     // synchro_token
?>
<input type='hidden' name='user' value='<?=$username?>'>
<br><br>
<input type="submit" value="Save Changes" name="action">&nbsp;
<input type='Button' name='action' value='Cancel' onClick='goback()'>&nbsp;
</form>
</body>
</html>
