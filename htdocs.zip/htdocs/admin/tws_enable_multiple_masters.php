<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t"); 
?>
<html>
<head>
<title>Enable IWS/WebAdmin Multiple Masters</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<?php

      $file="$maestro_dir/localopts";
      if($tws_config['host_os']=='win32')  $file = str_replace('/','\\',$file); 
      $cmd=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), $tws_config['cat'], $file);
      $stdout=array(); $stderr='';
      if (tws_popen($cmd, $ec, $stdout, $stderr)===FALSE || $ec!=0) 
         $mastername="MASTER";      
      else {
      foreach ($stdout as $buffer) {
         if (substr($buffer,0,7) == "thiscpu") {
            $mastername=strtok($buffer,"=");
            $mastername=strtok("\n");
            $mastername=strtoupper(trim($mastername));
            break;
         }
      }
      if (!isset($mastername)) {
         $mastername="MASTER";
      }
   }

   $fp=fopen("$maestro_dir/webadmin/etc/masters.xml","w") or tws_dyer("Unable to create $maestro_dir/webadmin/etc/masters.xml file");
   $num_bytes=fwrite($fp,"<master href=\"#local\">$mastername</master>\n");
   if ($num_bytes < 0) {
      fclose($fp);
      unlink($mastersxml);
      tws_dyer("Unable to write file $maestro_dir/webadmin/etc/masters.xml file");
   }
   fclose($fp);

   echo "<script language=\"Javascript\">\n";
   echo "window.location.replace(\"tws_masters_configuration.php\");\n";
   echo "</script>\n";
?>
</body>
</html>
