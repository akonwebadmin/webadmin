<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add IWS/WebAdmin User</title>
<? tws_adminstylesheet(); ?>
   <script type="text/javascript" src="../checkbox_selection.js"></script>
</head>
<body>
<?
   $authgroups = $tws_config['base_inst_dir']."/httpd/conf/authgroups";
   $authusers = $tws_config['base_inst_dir']."/httpd/conf/authusers";
   $apache_groups = array();
   $apache_users = array();

   // Read Apache Groups
   $fp=fopen($authgroups,"r") or tws_dyer("Can't open $authgroups file");
   while ($buffer=fgets($fp,4096)) {
      $group = strtok($buffer,":");
      if(empty($group)) continue;
      $members = explode(' ', strtok("\n"));
      foreach($members as $i=>$member){
         if(empty($member))
            unset($members[$i]);
      }
      $apache_groups[$group] = $members;
   }
   fclose($fp);

   // Read Apache Users
   $fp=fopen($authusers,"r") or tws_dyer("Can't open $authusers file");
   while ($buffer=fgets($fp,4096)) {
      $apache_users[] = strtok($buffer,":");
   }
   fclose($fp);

   // read IWS groups
   $twssec = tws_get_twssec_groups();
   if(empty($twssec))
      tws_dyer("Can't read IWS Secutity file");

   if (!isset($_POST['confirmed']) ) {
      // confirmation page
      $forimport = get_import_user_list();
      if(is_null($forimport)){
            tws_warning("There are no users to import from IWS Security file");
            echo "<input type='button' value='Back' onclick='window.location.replace(\"tws_user_administration.php\");'/>\n";
            exit;
      }
      if(empty($forimport)){
            tws_warning("All users are already imported");
            echo "<input type='button' value='Back' onclick='window.location.replace(\"tws_user_administration.php\");'/>\n";
            exit;
      }
      else{
      echo "<form action='tws_user_import.php' method='post' name='select_user'>";
         print_import_user_list($forimport);
         echo"<br><input type='submit' name='confirmed' value='Import'/>  ";
         echo "  <input type='button' name='cancel' value='Cancel' onclick='window.location.replace(\"tws_user_administration.php\");'/>\n";
         tws_print_synchro_token();     // synchro_token
         echo "</form>\n";
      }
   }  // CONFIRMED
   else {
      tws_check_synchro_token();     // synchro_token
      $forimport = tws_gpc_get($_POST['selection'], 'tws_alfanum\\tws_alfanum', '\\');
      if(empty($forimport)) 
         echo "<script> window.location.replace('tws_user_administration.php'); </script>";
      // import groups from tws
      create_apache_groups();

      // create selected users
      $authusers = $tws_config['base_inst_dir']."/httpd/conf/authusers";
      $bakauthusers=$authusers . ".bak";
      copy($authusers,$bakauthusers);

      foreach ($forimport as $member) {
         if(create_apache_user($member)==false){
            copy($bakauthusers,$authusers);
            tws_rmdir($webadmin_user_home_dir."/$member") || tws_error('',"Unable to delete IWS/WebAdmin user '$member' home directory");
            tws_dyer("Unable to create user '$member'. Original authusers file restored.", '', "tws_user_administration.php");
         }
      }
      echo "<script> window.location.replace('tws_user_administration.php'); </script>";
   }
?>
</body>
</html>
<?php

function get_import_user_list() {
   global $tws_config, $twssec;
   $base_inst_dir = $tws_config['base_inst_dir'];
   $webadmin_user_home_dir = $tws_config['webadmin_user_home_dir'];

   $forimport = array();
   foreach (array_reverse($twssec) as $group => $members) {
      foreach ($members as $member){
         if (strpos($member, '@') === false)
            $forimport[$member]=$group;
      }
   }

   $authusers="$base_inst_dir/httpd/conf/authusers";
   $fp=fopen($authusers,"r");
   if ($fp==false) tws_dyer("Can't open file $authusers");

   foreach ($forimport as $member=>$val) {
      // check if Apache User
      rewind($fp);
      $find=0;
      while ($buffer=fgets($fp,4096)) {
         $username=strtok($buffer,":");
         if($username == $member) {
            $find=1;
            break;
         }
      }
      if($find==1){
         $notempty = true;
         unset ($forimport[$member]);
      }
   }
   fclose($fp);
   if(!empty($forimport) || !empty($notempty)) 
      return $forimport;
   else return NULL;
}

function create_apache_user($username) {
   global $tws_config, $twssec;
   $authusers= $tws_config['base_inst_dir']."/httpd/conf/authusers";
   $webadmin_user_home_dir = $tws_config['webadmin_user_home_dir'];
   $user_setting_dir = $tws_config['user_setting_dir'];

   // create home directory
   if (!file_exists($webadmin_user_home_dir."/$username")) {
      tws_mkdir($webadmin_user_home_dir."/$username")===FALSE && tws_dyer("Cannnot create IWS/WebAdmin user '$username' home directory.", "", "tws_user_administration.php");
      tws_chmod($webadmin_user_home_dir."/$username", 0755)===FALSE && tws_err("Cannnot set up permissions of the IWS/WebAdmin user '$username' home directory.");
   }
   if (!file_exists($webadmin_user_home_dir."/$username".$user_setting_dir)) {
      tws_mkdir($webadmin_user_home_dir."/$username".$user_setting_dir)===FALSE && tws_dyer("Cannnot create '$username.$user_setting_dir' directory.", "", "tws_user_administration.php");
      tws_chmod($webadmin_user_home_dir."/$username".$user_setting_dir, 0755)===FALSE && tws_err("Cannnot set up permissions for '$username.$user_setting_dir' directory.");
   }
   // write to authusers without password (htpasswd don't take empty passwpord)
   $fp2 = fopen($authusers, 'a');
   if($fp2==false) return false;
   if (fwrite($fp2, "$username:\n") == false) { fclose($fp2); return false; }
   fclose($fp2);

   // Add description
   $authusers_desc = $tws_config['base_inst_dir']."/httpd/conf/authusers_desc";
   $bakauthusers_desc=$authusers_desc . ".bak";
   copy($authusers_desc, $bakauthusers_desc);

   $fp=fopen($authusers_desc,"a");
   fputs($fp, $username.": Imported from IWS Security\n");
   fclose($fp);

// Add user to authgroups
   $find=0;
   foreach($twssec as $group=>$members){
      foreach($members as $member) {
         if($member == $username){
           $find=1;
           break;
         }
      }
      if($find==1) break;
   }

   $authgroups=$tws_config['base_inst_dir']."/httpd/conf/authgroups";
   $newauthgroups=$authgroups . ".tmp";
   $bakauthgroups=$authgroups . ".bak";

   $fp=fopen($authgroups,"r");
   $newfp=fopen($newauthgroups,"w");
   while ($buffer=fgets($fp,4096)) {
      $curgroup=strtok($buffer,":");
      if ($curgroup == $group) {       // add user to $group
         $members = strtok("\n");
         $members = explode(' ', $members);
         if(!in_array($username, $members) )
            fputs($newfp,substr($buffer,0,-1) . " $username"."\n");
         else
            fputs($newfp, $buffer);
      } else {
         fputs($newfp, $buffer);
      }
   }
   fclose($fp);
   fclose($newfp);

   copy($authgroups,$bakauthgroups);
   copy($newauthgroups,$authgroups);
   unlink($newauthgroups);


   return true;
}

//
function create_apache_groups() {
   global $apache_groups, $forimport, $twssec;

   $list = array();
   
   foreach($twssec as $group=>$members)
      foreach($forimport as $user)
         if(in_array($user, $members))
            $list[$group][] = $user;
  
   foreach ($list as $group=>$members)
      if (!array_key_exists($group, $apache_groups) )
            create_apache_group($group, $members);
}


function create_apache_group($groupname, $members) {
   global $tws_config, $apache_users, $apache_groups;

   $webadmin_user_home_dir = $tws_config['webadmin_user_home_dir'];
   $user_setting_dir = $tws_config['user_setting_dir'];
   $base_inst_dir = $tws_config['base_inst_dir'];

   // create home directory
   if (!file_exists($webadmin_user_home_dir."/groups/$groupname")) {
      tws_mkdir($webadmin_user_home_dir."/groups/$groupname")===FALSE && tws_dyer("Cannnot create IWS/WebAdmin group '$groupname' home directory.", "", "tws_user_administration.php");
      tws_chmod($webadmin_user_home_dir."/groups/$groupname", 0755)===FALSE && tws_err("Cannnot set up permissions of the IWS/WebAdmin group '$groupname' home directory.");
   }
   if (!file_exists($webadmin_user_home_dir."/groups/".$groupname.$user_setting_dir)) {
      tws_mkdir($webadmin_user_home_dir."/groups/".$groupname.$user_setting_dir)===FALSE && tws_dyer("Cannnot create '$groupname.$user_setting_dir' directory.", "", "tws_user_administration.php");
      tws_chmod($webadmin_user_home_dir."/groups/".$groupname.$user_setting_dir, 0755)===FALSE && tws_err("Cannnot set up permissions for '$groupname.$user_setting_dir' directory.");
   }
   $authgroups=$tws_config['base_inst_dir']."/httpd/conf/authgroups";
   $bakauthgroups=$authgroups . ".bak";
   copy($authgroups,$bakauthgroups);

   // if user have group - remove him from list // ?????
   foreach($members as $key=>$member){
      foreach($apache_groups as $apgroup=>$apmembers){
         if(in_array($member, $apmembers))
            unset($members[$key]);
      }
   }
   $str_members = implode(' ', $members);

   $fp=fopen($authgroups,"a");
      fputs($fp,$groupname.": $str_members\n");
   fclose($fp);
}

function print_import_user_list ($forimport) {
   global $apache_groups, $twssec;

   echo "<h2>Select users for import</h2>\n";
   tws_print_check_clear_all('window.document.select_user')."\n";
   echo "<table><tr><th> </th> <th>User</th> <th>Group</th></tr>\n";
   foreach ($forimport as $user=>$group){
      echo "<tr>\n";
         echo "<td><input type='checkbox' name='selection[]' value='$user' checked onclick='selectCheckboxes(this);'></td> <td>$user</td> <td>$group</td>\n";
      echo "</tr>\n";
   }
   echo "</table><br>\n";
}
?>