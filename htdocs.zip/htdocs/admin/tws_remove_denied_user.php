<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Remove Denied User</title>
<?php tws_adminstylesheet(); ?>
</head>
<body>

<h1>Remove Denied User</h1>
<br><br>
<h3>Confirm Remove Denied User:</h3>

<?php

   if (!isset($selection)) {
      echo "<p class=warning>&nbsp;&nbsp;&nbsp;&nbsp;No user selected</p>\n";
   } else {
      echo "<form method=\"post\" action=\"tws_remove_denied_user_exec.php\">\n";;
      echo "&nbsp;&nbsp;&nbsp;&nbsp;".htmlspecialchars($selection)."\n";
      echo "<input type=\"hidden\" name=\"username\" value='".htmlspecialchars($selection)."'>\n";
   }
?>

<br><br><br>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Delete" name="action">&nbsp;&nbsp;
<input type="button" value="Cancel" onclick="window.location.replace('tws_auth_configuration.php');">
<? tws_print_synchro_token();     // synchro_token
?>
</form>
</body>
</html>
