<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
   tws_profile('opener', basename($_SERVER['SCRIPT_NAME']) );
?>
<html>
<head>
<title>IWS Filter Administration</title>
<?php tws_adminstylesheet();
   tws_set_window_title();
?>
</head>
<body>
<h1>IWS Filter Administration</h1>
<br>
<?php
function table_start(){
   echo "<table class=\"wireframe\" id=\"sortable\" cellspacing=0 cellpadding=4 width=\"100%\" cols=6>\n";
   echo "<tr class=header>\n";
   echo "<th class=wireframe>&nbsp;</th>\n";
   echo "<th class=wireframe>Filter Filename</th>\n";
   echo "<th class=wireframe>Type</th>\n";
   echo "<th class=wireframe>Creator</th>\n";
   echo "<th class=wireframe>Owner</th>\n";
   echo "<th class=wireframe>Description</th>\n";
   echo "<th class=wireframe>Selection</th>\n";
   echo "</tr>\n";
}

   $users = tws_get_user_dirs();

   $table_started=FALSE;
   $all="yes";
   foreach($users as $user) {
      $files=tws_get_filter_list('',$user,$all);
      $all="no";
      foreach ($files as $f => $val) {
         $$f = $val; //this creates file_stripped dynamic variable
      }
      if ($file_num>0) {
         foreach ($file_stripped as $key => $val){
            $pos=strpos($val,".");
            $type[$key]=substr($val,$pos+1);
            $file_stripped[$key] = substr($val,0,$pos);
         }
         if (!$table_started) {
            table_start();
            $table_started=TRUE;
         }
         for ($i=1;$i<=$file_num;$i++) {
            echo "<tr class=standard>\n";
            echo "<td><a href=\"tws_delete_filter.php?filename=$file[$i]&amp;user=$user&amp;for_all=$for_all[$i]\">Delete</a></td>\n";
            echo "<td>".htmlspecialchars($file_stripped[$i])."</td>\n";
            echo "<td>".htmlspecialchars($type[$i])."</td>\n";
            echo "<td>".htmlspecialchars($creator[$i])."</td>\n";
            echo "<td>".($for_all[$i] ? "<i>ALL USERS</i>" : "$user" )."</td>\n";
            echo "<td>".htmlspecialchars($comment[$i])."</td>\n";
            echo "<td>".htmlspecialchars($selection[$i])."</td>\n";
            echo "</tr>\n";
         }
      }
   }
   if ($table_started) {
      echo "</table>\n";
   } else {
      echo "<p class=warning>No filters defined</p>\n";
   }
?>
</body>
</html>
