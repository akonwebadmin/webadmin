<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
   tws_profile('opener', basename($_SERVER['SCRIPT_NAME']) );
?>
<html>
<head>
<title>IWS/WebAdmin User Administration</title>
<?php tws_adminstylesheet(); ?>
<style type="text/css">
   table.wireframe td, table.wireframe th {
      border-collapse: collapse;
      padding-left:7px;
      padding-right:7px;
   }
</style>
   <script type="text/javascript" src="../checkbox_selection.js"></script>
</head>
<body>
<?php
   tws_set_window_title();
   //$log_file_name=tws_log('', 'OPEN');
   tws_print_head('IWS/WebAdmin User and Group Administration', '', '../');
?>
<br><br>
<?php
   if (tws_yesno($tws_config['virtual_hosts'],TRUE,FALSE)) {
      echo "<p class=\"warning\">This is a client instance of the shared instances installation model.
Modification may affect all other instances, including the <b>Master</b> IWS/WebAdmin instance</p>\n";
   }

   tws_import_request_variables("P","rqst_");

   if (file_exists("$maestro_dir/webadmin/etc/usersec.php")) {
      include("$maestro_dir/webadmin/etc/usersec.php");
   }

   $authusers="$base_inst_dir/httpd/conf/authusers";
   $authgroups="$base_inst_dir/httpd/conf/authgroups";

   $groups = array();
   $apachusers = array();

// ******  All Users from authusers  ****** //
   $fp=fopen($authusers,"r");
   if ($fp) {
      while ($buffer=fgets($fp,4096)) {
         $username=strtok($buffer,":");
         $groups[$username] = '';
         $apachusers[] = $username;
      }
   	  fclose($fp);
   }
   else tws_err("Can't open '$authusers' file");

   unset($buffer, $username);

// ******  User Description  ****** //
   $fdesription = "$base_inst_dir/httpd/conf/authusers_desc";
   if (file_exists($fdesription)) {
      $fp=fopen($fdesription,"r");
      if ($fp) {
         while ($buffer=fgets($fp,4096)) {
            $username = trim(strtok($buffer,":"));
            $desript = trim(strtok("\n"));
            $description[$username] = $desript;
         }
      }
      fclose($fp);
      unset($buffer, $desript);
   }
// ******  IWS Groups  ****** //
   $twssec = tws_get_twssec_groups();
   foreach (array_reverse($twssec) as $group => $members) {
      $twsgroupslist[] = strtoupper($group);    // ******   All IWS Groups
   }
   unset($twssec, $member, $group, $members);

// ******  Apache Groups  ****** //

   $fp=fopen($authgroups,"r");
   while ($buffer=fgets($fp,4096)) {
      $group=strtok($buffer,":");
      $groupslist[] = $group;    // ******   All Apache Groups
      $members=trim(strtok(":"));
      $members=explode(" ",$members);
      foreach ( $members as $member) {
         if($group=='admin')
            $group = "<b>admin</b>";
         $groups[$member] = $group;    // Rewrite IWS group if have Apache group
      }
   }
   fclose($fp);
   unset($member, $group, $members);

// remove users which are not in apache
   foreach ($groups as $username => $group) {
      if ( !in_array($username, $apachusers) )
         unset($groups[$username]);
   }

// ******  Denied Users  ****** //
   $deniedusers = array();
   $denyusers="$base_inst_dir/httpd/conf/denyusers";
   if (file_exists($denyusers)) {
      $fp=fopen($denyusers,"r");
      while ($buffer=fgets($fp,4096)) {
         $user_num++;
         $deniedusers[$user_num]=trim($buffer);
      }
      fclose($fp);
   }

// $authtype && $use_authusers
   if (file_exists("$base_inst_dir/etc/authconf.php")) {
      include("$base_inst_dir/etc/authconf.php");
   }

// Can Logon
   $cantlogon = array();
   foreach ($groups as $username => $group) {
      if($authtype == 'os') {
         if (in_array($username, $deniedusers) ) {
            $cantlogon[] = $username;
            continue;
         }
         if (isset($use_authusers) ) {
            if (!in_array($username, $apachusers) ) {
               $cantlogon[] = $username;
               continue;
            }
         }
      }
      else {
         if (!in_array($username, $apachusers) ) {
            $cantlogon[] = $username;
            continue;
         }
      }
   }
?>

<div id='tabs'>
   <ul>
      <li><a href='#users'>User Administration</a></li>
      <li><a href='#groups'>Group Administration</a></li>
      <li><a href='#defaults'>Default Settings</a></li>
   </ul>

<? // ****** Users Control Tab ******// ?>
   <div id='users'>

   <h3>User Administration</h3><br>
   <form method='post' action='tws_user_administration_action.php' name='user_admin'>

<? tws_print_check_clear_all('window.document.user_admin') ?>
   <table class='wireframe sortable' cellspacing='0' cellpadding='3'>
   <thead><tr class='header'>
   <th class='wireframe'> </th>
   <th class='wireframe'>Username</th>
   <th class='wireframe'>Potential Log on</th>
   <th class='wireframe'>Description</th>
   <th class='wireframe'>Group</th>
   <th class='wireframe'>User Rights Customized</th>
   <th class='wireframe'>User Menu Customized</th>
   <th class='wireframe'>User Actions Customized</th>
   </tr></thead>
<?
   foreach ($groups as $username => $group) {
      if (trim ($username) == '') continue;

      echo "<tr class='standard'>\n";
      echo "<td><input type='checkbox' name='selection[]' value='$username' onclick='selectCheckboxes(this);'></td>\n";
      echo "<td>$username</td>\n";

      if ( in_array($username, $cantlogon) )
         echo "<td align='center'><b>NO</b></td>\n";
      else echo "<td align='center'>YES</td>\n";

      echo "<td>$description[$username]</td>\n";

      if($group) echo "<td align='center'>$group</td>\n";
      else echo "<td> </td>\n";

      if (isset($rights[$username]))
         echo "<td align='center'>YES</td>\n";
      else echo "<td align='center'> </td>\n";

      if (is_file($webadmin_user_home_dir."/".$username.$user_setting_dir."/menu.php"))
         echo "<td class='wireframe' align=\"center\">YES</td>\n";
      else echo "<td class='wireframe' align=\"center\">&nbsp;</td>\n";

      if (is_file($webadmin_user_home_dir."/".$username.$user_setting_dir."/actions.php"))
         echo "<td class='wireframe' align=\"center\">YES</td>\n";
      else echo "<td class='wireframe' align=\"center\">&nbsp;</td>\n";
      echo "</tr>\n";
   }
?>
</table>
<br><br>

<input type='submit' name='action' value="Add New User">&nbsp;
<input type='submit' name='action' value="Modify User">&nbsp;
<input type='submit' name='action' value="Delete User">&nbsp;
<input type='submit' name='action' value="Import accounts from IWS Security file">
<br><br>
<input type='submit' name='action' value="Advanced User Rights">&nbsp;
<input type='submit' name='action' value="Define User Menu">&nbsp;
<input type='submit' name='action' value="Define User Action Buttons">&nbsp;
<input type='submit' name='action' value="Set Default Filters">
   <? tws_print_synchro_token();   // synchro_token ?>
</form>
</div>

<? // ****** Groups Control Tab ******// ?>
<div id='groups'>

   <h3>Group Administration</h3><br>

   <form method='post' action='tws_group_administration_action.php'>
   <table class='wireframe sortable' cellspacing='0' cellpadding='3'>
   <thead><tr class='header'>
   <th> </th>
   <th> Group Name </th>
   <th> Description </th>
   <th> Group Rights <br> Customized </th>
   <th> Group Menu <br> Customized </th>
   <th> Group Actions <br> Customized </th>
   </tr></thead>
<?
   foreach ($groupslist as $groupname ) {
      echo "<tr class='standard'>\n";
      echo "<td class='wireframe'>";
      echo ($groupname=="admin") ? "&nbsp;" : "<input type='radio' name='selection' value='".htmlspecialchars($groupname)."'>";
      echo "</td>\n";
      echo ($groupname=="admin") ? "<td class='wireframe'><b>$groupname</b></td>\n" : "<td class='wireframe'>".htmlspecialchars($groupname)."</td>\n";

      // description
      if(!empty($twsgroupslist) && in_array($groupname, $twsgroupslist))
         echo "<td>Imported from IWS Security</td>\n";
      else echo "<td> </td>\n";

      if (isset($group_rights[$groupname]))
         echo "<td align='center'>YES</td>\n";
      else echo "<td> </td>\n";

      if (is_file($webadmin_user_home_dir."/groups/".$groupname.$user_setting_dir."/menu.php"))
         echo "<td align=\"center\">YES</td>\n";
      else echo "<td> </td>\n";

      if (is_file($webadmin_user_home_dir."/groups/".$groupname.$user_setting_dir."/actions.php"))
         echo "<td align='center'>YES</td>\n";
      else echo "<td> </td>\n";
      echo "</tr>\n";
   }
?>
</table>
<br><br>

<input type='submit' name='action' value="Add New Group">&nbsp;
<input type='submit' name='action' value="Delete Group"><br><br>
<input type='submit' name='action' value="Advanced Group Rights">&nbsp;
<input type='submit' name='action' value="Define Group Menu">&nbsp;
<input type='submit' name='action' value="Define Group Action Buttons">&nbsp;
<input type='submit' name='action' value="Set Default Filters">
   <? tws_print_synchro_token();   // synchro_token ?>
</form>
</div>

<? // ****** Default Settings ****** // ?>
<div id='defaults'>
<h3>Default Settings</h3>
<br>
<a href="tws_advanced_user_rights.php?default_user_rights=yes">Set Default Advanced Rights</a>
&nbsp;&nbsp;
<a href="tws_menu_configuration.php">Set Default Menu</a>
&nbsp;&nbsp;
<a href="tws_define_action_buttons.php">Set Default Action Buttons</a>
&nbsp;&nbsp;
<a href="tws_define_default_filters.php">Set Default Filters</a>

</div>

</div>

<script>
$(function() {
   $('#tabs').tabs();
   $('#tabs').css('background-color','inherit');
   $('#tabs').css('border','none 0px');
});
</script>

</body>
</html>
