<?php
//   HORIZONT Software GmbH, Munich
//

   require_once("tws_functions.php");
   tws_import_request_variables("P","rqst_");

   $action=$rqst_action;
   @$severity=$rqst_severity;

   switch ($action) {
     case "Add":
       include("tws_add_severity_level.php");
       break;
     case "Modify":
       include("tws_modify_severity_level.php");
       break;
     case "Delete":
       include("tws_delete_severity_level.php");
       break;
   }
?>