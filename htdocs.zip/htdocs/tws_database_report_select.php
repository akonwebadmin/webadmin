<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_import_request_variables("GP","rqst_");
   $objecttype=tws_gpc_get($rqst_objecttype, 'tws_name');
   include("tws_database_report_design.php");
?>