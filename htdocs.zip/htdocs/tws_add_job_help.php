<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');
?>
<html>
<head>
<?php require_once 'tws_functions.php'; tws_doctype('t'); ?><title>Add Job Definition Help</title>
<?php tws_stylesheet(); ?>
</head>

<body class="help">
<?php tws_set_window_title(); include 'tws_help_topbar.php'; ?>
<h1 class="help">Add/modify job definition</h1>

<p>To create a new job, fill in the form fields as
described below. When the specification of all requested parameters is
done, click the Add (or Update) button to create the new job (or
save changes in existing one) to the IWS database.
Click Save Druft bitton to save job defenition as draft.
</p>
<br>

<p>First specify <b>Task Type</b>. Possible values are:
<ul>
   <li>Windows</li>
   <li>Unix</li>
   <li>Other</li>
</ul>
</p>
<? if ($tws_config['cpuinfo']['version']>='8.6') : ?>
<p>IWS 8.6 has additional extended job types:
<ul>
   <li>Executable</li>
   <li>Shadow Distributed</li>
   <li>Shadow z/OS</li>
   <li>File Transfer</li>
   <li>Web Services</li>
   <li>J2EE</li>
   <li>Java</li>
   <li>XA Job</li>
   <li>IBM i</li>
</ul>
</p>
<p>Every this job types has it's own parameters</p>
<? endif; ?>
<p><b>Workstation:</b> The name of the workstation or workstation class on which the job runs</p>
<p><b>Job Name:</b> The name of the job definition</p>
<p><b>Description:</b> Job description</p>
<p><b>Job Type: </b>Possible values are:
<ul>
   <li>Command - When the job is a command, "Script/Command" field is the name of the command the job runs with any options and arguments.</li>
   <li>Script - When the job is a script, "Script/Command" field is the file name with any options and arguments.</li>
   <li>Interactive - For Windows jobs only. Select this check box to run the job interactively on the Windows desktop</li>
</ul>
</p>
<p><b>Script/Command:</b> Command or Script name the job runs with any options and arguments.</p>
<p>For Windows script, include the file extensions. Do not specify files on mapped drives.</p>
<p>You can add a variable to this field by clicking Add Parameter button.</p>
<p><b>Logon:</b> The name of the operating system user who launches the job.
Specify a user that can log on to the workstation where the job runs.</p>
<p>You can add a variable to this field by clicking Add Parameter</p>
<p>For Windows jobs, the user must also be defined in the database.</p>

<p><b>Return Code Mapping:</b> Define which return codes qualify the job as having completed successfully.
Enter a logical expression that defines the success condition. Use the following syntax: (RC <i>operator operand</i>) where:
<ul>
   <li>RC - The instruction keyword</li>
   <li>Operator - The comparison operator. Allowed operators are comparison operators (=, != or <>, >, >=, <, <=) that can be combined with logical operators (AND, OR, NOT).</li>
   <li>Operand - Any integer</li>
</ul>
For example:<br>
(RC<=3) to accept a job as successful when the job ends with a return code less than or equal to 3.<br>
NOT ((RC=0) AND (RC=1)) to accept a job successful when the job ends with a return code different from 0 and 1.<br>
(RC=2) OR (RC=4) to accept a job successful when the job ends with a return code equal to 2 or equal to 4.<br>
(RC&lt;7) AND (RC!= 5) to accept a job successful when the job ends with a return code less than 7 and not equal to 5.
</p>

<p><b>Recovery Options:</b> Specify the recovery options to be followed if the job abends.</p>
<p><b>Action</b> specify the action to be taken when the job abends:
<ul>
   <li>Stop - If the job ends in error and there is a follows dependency, processing does not continue with the next job. </li>
   <li>Continue - If the job ends in error and there is a follows dependency, processing continues with the next job.</li>
   <li>Rerun - If the job ends in error, rerun the job</li>
</ul>
</p>

<p><b>Recovery Job: </b>The name of a recovery job to run if the current job ends in error.
Recovery jobs are run only once for each instance of the current job ended in error.</p>
<p><b>Recovery Prompt: </b>The text of a recovery prompt to be displayed. The recovery prompt is an ad hoc prompt that is always displayed.
If the job ends in error, the prompt status changes to Asked. If the job ends successfully, the status remains Not Asked.</p>

</body>
</html>