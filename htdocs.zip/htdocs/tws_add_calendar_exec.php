<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add Calendar</title>
<?php
tws_stylesheet();
tws_show_backup();
?>
</head>
<body>
<?php tws_set_window_title(); ?>

<?php
function extr_date($datestamp) {
   if (preg_match("/([0-9]{4})([0-9]{2})([0-9]{2})/",$datestamp,$r)){
      $date = $r[1]."-".$r[2]."-".$r[3];
   } else {
       $date = "XXXX-XX-XX";
   }
   return $date;
}

   tws_check_synchro_token();  // synchro_token
   tws_import_request_variables("P","rqst_");


   if ($rqst_action=="Cancel") {
      tws_composer_unlock("cal=$calendar_namex") or tws_dyer("Unable to unlock calendar $calendar_namex");
      echo "<script type='text/javascript'>
         if(window.name == 'tws_popup')  window.close();
         else window.location.replace(\"tws_calendarsx.php\");
      </script>\n";
      exit;
   }
   elseif($rqst_action=="Return to Modification"){
      include("tws_add_calendar.php");
      exit;
   }

   if (isset($rqst_copy)) $copy=$rqst_copy;
      else $copy="no";
   if (isset($rqst_modify)) $modify=$rqst_modify;
      else $modify="no";

   if ($modify == "yes" && !tws_permit_action('database_calendars','Modify')) tws_access_denied ();
   elseif (!tws_permit_action('database_calendars','Add')) tws_access_denied ();

   $calendar_name=strtoupper(tws_gpc_get($rqst_calendar_name, 'tws_name'));
   $calendar_description=tws_gpc_get($rqst_calendar_description);
   $calendar_folder= '';
   if ($tws_config['cpuinfo']['version']>='9.5002'){
       $calendar_folder=strtoupper(tws_gpc_get($rqst_calendar_folder));
   }

   if (isset($rqst_confirm)) $confirm=$rqst_confirm;
      else $confirm="no";
   if (isset($rqst_backup)) $backup=$rqst_backup;
      else $backup="no";
   $original_data=tws_gpc_get($rqst_original_data);
/*
   if (isset($rqst_datex)) {
      if (is_array($rqst_datex)) {
         foreach ($rqst_datex as $index => $value)
            $date[$index]=$value;
      }
   }*/
   if (isset($rqst_calendar_dates)){
      $calendar_dates = $rqst_calendar_dates;
      $rqst_calendar_dates = explode(',', $rqst_calendar_dates);
      foreach($rqst_calendar_dates as $val){
         $tmp = trim(str_replace('-', '', $val));
         $date[$tmp] = 'yes';
      }
   }
   if (!isset($date) || !is_array($date)) tws_dyer("No dates selected");

   ksort($date);

// Check for existing calendar
   $match=FALSE;
   if ($confirm != "yes") {
       if (($db_cal = tws_get_calendars($calendar_folder.$calendar_name)) === FALSE) {
         tws_dyer("Unable to list calendars");
      }
      if ($db_cal['calendar_num'] > 1) {
         tws_dyer("Database query error");
      }
      if (($db_cal['calendar_num'] == 1) && ($calendar_name == $db_cal['calendar_name'][0])) {
         $orig_calendar_description = $db_cal['calendar_description'][0];
         $temp=explode(',',$db_cal['calendar_dates'][0]);
         $orig_date=Array();
         foreach($temp as $day) {
            $orig_date[$day]="yes";
         }
         $match = TRUE;
      }
   }

   if ($match == TRUE) {
      if ($modify == "yes") {
         echo "<h1>Confirmation</h1>\n";
      } else {
         echo "<h1>Replace Calendar Confirmation</h1>\n";
      }
      echo "<br><br>\n";
      echo "<h3>Confirm:</h3>\n";
      if ($modify != "yes") {
         echo "&nbsp;&nbsp;<b>The Calendar Name entered already exists</b>\n";
         echo "<br><br>\n";
      }
      echo "<style type=\"text/css\">
      table.cmp td { white-space:normal; }
      </style>
      ";
      $orig_cal = Array('calendar' => $calendar_name, 'description' => $orig_calendar_description , 'removed' => "", 'same' => "", 'new' => "" );
      $new_cal  = Array('calendar' => $calendar_name, 'description' => $calendar_description, 'removed' => "", 'same' => "", 'new' => "" );
      $label_map= Array('calendar' => "Name", 'description' => "Description", 'removed' => "Removed Dates", 'same' => "Same Dates", 'new' => "Added Dates" );
      if ($tws_config['cpuinfo']['version']>='9.5002'){
          $label_map['folder'] = "Calendar folder";
          $orig_cal['folder']= $calendar_folder;
          $new_cal['folder']= $calendar_folder;
      }
      $old_dates = $same_dates = $new_dates = Array();

// split into 3 groups (new, same, old)
      foreach ($date as $key => $value) {
         if (@$orig_date[$key] == "yes") $same_dates[$key] = "yes";
            else $new_dates[$key] = "yes";
      }
      foreach ($orig_date as $key => $value ) {
         if (@$date[$key] != "yes") $old_dates[$key] = "yes";
      }
// prepare output string arrays
      foreach ($old_dates as $key => $value) {
         $orig_cal['removed'] .= tws_iso_to_userdate(extr_date($key), null, true)." ";
      }
      foreach ($same_dates as $key => $value) {
         $temp = tws_iso_to_userdate(extr_date($key), null, true)." ";
         $orig_cal['same'] .= $temp;
         $new_cal['same'] .= $temp;
      }
      foreach ($new_dates as $key => $value) {
         $new_cal['new'] .= tws_iso_to_userdate(extr_date($key), null, true)." ";
      }
// show comparison table
      tws_show_cmp_table("Original Calendar", "New Calendar", $orig_cal, $new_cal, $label_map);

// confirmation form
      echo "<form method=post name=\"confirm\" action=\"tws_add_calendar_exec.php\">\n";
      echo "<input type=\"hidden\" name=\"confirm\" value=\"yes\">\n";
      echo "<input type=\"hidden\" name=\"calendar_name\" value=\"".htmlspecialchars($calendar_name)."\">\n";
      echo "<input type=\"hidden\" name=\"calendar_description\" value=\"".htmlspecialchars($calendar_description)."\">\n";
      if ($tws_config['cpuinfo']['version']>='9.5002'){
          echo "<input type=\"hidden\" name=\"calendar_folder\" value=\"".htmlspecialchars($calendar_folder)."\">\n";
      }

      if ($original_data=='') {
         //missing original data - this happens if user is adding job that already exists.
         if (($original_data=tws_composer_create_from("cal=$calendar_name"))===FALSE) {
            tws_err("Unable to get original data required to create backup.");
         }
      }
      echo "<input type=\"hidden\" name=\"original_data\" value=\"".htmlspecialchars($original_data)."\">\n";
      echo "<input type=\"hidden\" name='calendar_dates' value='$calendar_dates'>\n";
      if (tws_rights(SAVEBACKUPS) && $original_data!=''){
         echo "<input type='hidden' name='backup' value='yes'>";
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type='checkbox' name='backup' value='yes' checked disabled>&nbsp;Save Backup Copy of Original Calendar</label>\n";
      }
      else
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type='checkbox' name='backup' value='yes' ".($original_data!='' ? 'checked' : 'disabled').">&nbsp;Save Backup Copy of Original Calendar</label>\n";
      echo "<br><br><br>\n";
      if ($modify == "yes") {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Update\" name=\"action\">\n";
         echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
         echo "<input type=\"hidden\" name=\"calendar_namex\" value=\"".htmlspecialchars($calendar_name)."\">\n";
      } else {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Replace\" name=\"action\">\n";
      }
      echo '&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Return to Modification">'."\n";
      echo '&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Cancel">'."\n";
      tws_print_synchro_token();   // synchro_token
      echo "</form>\n";

   } else {
// Create Backup Copy if option checked
      if ($backup == "yes") {
          if (($bckfilename = tws_write_backup($original_data, "calendar", $calendar_folder.$calendar_name)) === FALSE) {
            tws_err("Unable to write backup");
         }
      }

// unlock the object
      tws_composer_unlock("cal=$calendar_folder$calendar_name");

      $cmd = tws_calendar_to_composer($_POST, true);

// Create random temporary filename
      $tmpfilename="$maestro_dir/webadmin/tmp/calendar.".tws_rndstr().".tmp";
      $fp=fopen($tmpfilename,'w') or tws_dyer("Unable to create temporary file '$tmpfilename'");

      $num_bytes=fwrite($fp,$cmd);
      if ($num_bytes < 0) {
         fclose($fp);
         tws_dyer("Unable to write temporary file");
      }
      fclose($fp);
      tws_chmod($tmpfilename,0644);

      if ($confirm == "yes") {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "replace $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      } else {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "add $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      }

      $stdout3='';
      $ec_popen=tws_popen($command3, $ec3, $stdout3, $stdout3, "N");

      //remove the tmp file now
      unlink($tmpfilename);

      //testing for the AWSBIA288I Total objects updated: 0.
      //Note: This has been added on 2016-07 to fix the problem of composer updating
      //correctly objects but returning incorrect return codes (not 0 or 4)
      $not_updated=!preg_match('/AWSBIA288[^\n]+(\d+)/', $stdout3, $_r) || $_r[1]==0;

      if ($ec_popen===FALSE || ($ec3!=0 && $ec3!=4 && $not_updated)) {
         if ($modify == "yes") {
            echo "<h1>Modify Calendar Status</h1>\n";
         } else {
            echo "<h1>Add Calendar Status</h1>\n";
         }
         tws_err("Calendar add modify operation failed", array('twscmd'=>$command3->compile('log'), 'stdout'=>$stdout3, "EC_POPEN"=>$ec_popen, "EC_UPDATED"=>$ec3, "NOT_UPDATED"=>tws_yesno($not_updated,'YES','NO')));
         echo "<form action='tws_add_calendar_exec.php' method='post' onsubmit=\"if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Workstation',null)) { cancel_button_pressed=false; return false;}\">\n";
         echo tws_create_hidden_inputs($_POST);
         tws_print_synchro_token();
         echo "<input type='submit' name='action' value='Cancel' onClick='cancel_button_pressed=true;'/>\n";
         echo "<input type='submit' name='action' value='Return to Modification'/>\n";
         echo "</form>";
      } elseif (preg_match("/warnings?\s[1-9]/i",$stdout3)) {
         if ($modify == "yes") {
            $headertext="Modify Calendar";
         } else {
            $headertext="Add Calendar";
         }
         tws_err("The Calendar has been saved with the following warnings:", array('stdout'=>$stdout3));

         $shortwarnfilename="warn.".tws_rndstr().".txt";
         $warnfilename="$webadmin_tmp_dir/$shortwarnfilename";
         $warnfp=fopen("$warnfilename","w") or tws_dyer("Unable to create warning text file", array('stdout'=>$stdout3));
         $num_bytes=fwrite($warnfp,"$stdout3");
         if ($num_bytes < 0) {
            fclose($warnfp);
            unlink($warnfilename);
            tws_dyer("Unable to write warning text file", array('stdout'=>$stdout3));
         }
         fclose($warnfp);
         tws_dyer();
      } else {
         if ($backup == "yes") {
            if ($modify == "yes") {
               echo "<h1>Modify Calendar Status</h1>\n";
            } else {
               echo "<h1>Add Calendar Status</h1>\n";
            }
            echo "<p class=\"message\">\n";
            echo "The calendar has been successfuly saved.&nbsp;";
            $bckfilename = preg_replace("/\\\\/", '/', $bckfilename);
            $file = explode('/',$bckfilename);
            $file = end($file);
            if(tws_profile('auth_user_group')=='admin')
               echo "<a href=\"javascript:showBackup('$file')\">Display Backup File</a>\n";
            echo "</p>\n";
            echo "<input type='button' value='OK' onClick=\"closeme('tws_calendarsx.php')\" />\n";

         } else {
            echo "<script type='text/javascript'>
               if(window.name == 'tws_popup')  window.close();
               else window.location.replace(\"tws_calendarsx.php\");
            </script>\n";
         }
      }
   }
?>
</body>
</html>
