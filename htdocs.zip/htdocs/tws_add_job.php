<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');

   // Cancel button test
   $tmp_test = (isset($_POST['action']) && (($_POST['action'] == 'Cancel') || strpos($_POST['action'], 'Return to Job')!== false)) ? true : false;
   if(isset($_POST['action_button']) && $_POST['action_button'] == 'Cancel') $tmp_test = true; // from tws_save_job_draft.php
   if ($tmp_test == true) {
      $arr = tws_form_to_arr('job', $_POST);
   }


   !isset($job_type) && $job_type = '';
   !isset($interactive) && $interactive = '';
   !isset($recovery_workstation) && $recovery_workstation = '';
   !isset($recovery_job) && $recovery_job = '';
   !isset($recovery_prompt) && $recovery_prompt = '';
   !isset($copy) && $copy = '';
   !isset($modify) && $modify = '';

   !isset($newjob) && isset($_GET['newjob']) && $newjob = $_GET['newjob'];

//    ACTIONS:
   if ($display == 'yes') {
      $title = 'Display Job Definition';
      $action = 'display';
   }
   else if ($copy == 'yes') {
      $title = 'Copy Job';
      $action = 'copy';
   }
   else if ($modify == 'yes') {
      $title = 'Modify Job';
      $action = 'modify';
   }
   else {
      $title = 'Add Job';
      $action = 'add';
   }
// -------------------------------
?>
<html>
<head>
<title><?php echo $title; ?></title>

<? tws_stylesheet();
   tws_set_window_title();
?>

<script type="text/javascript">
   function ConfirmCancel(objectname, url) {
   $('form').unbind('submit');
      var conftext = confirm("Exit " + objectname + " Definition (Changes will be lost) ?");
      if (conftext) {
         if (url==null) return true;
         closeme(url);
      } else {
         return false;
      }
   }
   // Call it on change Job Type
   function hide_all() {
      $('table.add_job').css('display','none');
      $('table.add_job input').attr('disabled', 'disabled');
      $('table.add_job select').attr('disabled', 'disabled');
      $('table.add_job textarea').attr('disabled', 'disabled');
      $('tr#stdin').css('display', '');
      $('input#workstation_list').removeAttr('disabled');
      hide_sec_interactive();
      show_recovery();
   }

   function show_sec_85() {
      document.getElementById('sec_85').style.display='';
      $('table#sec_85 input:text').removeAttr('disabled');
      <?php if ($display!='yes') : ?>
      $('table#sec_85 input').removeAttr('disabled');
      $('table#sec_85 select').removeAttr('disabled');
      <? endif; ?>
      hide_sec_interactive();
      show_codemap();
   }
   function hide_sec_interactive(display) {
      document.getElementById('interactive').disabled=true;
      var x=document.getElementById('sec_interactive');
      if (display) {
         x.style.display='';
         x.style.color='#808080';
      } else {
         //x.style.display='none';
      }
   }
   function show_sec_interactive() {
      var x=document.getElementById('sec_interactive');
      x.style.display='';
      x.style.color=sec_interactive_color;
      <?php if ($display!='yes') : ?>
      document.getElementById('interactive').disabled=false;
      <? endif; ?>
   }

   function show_codemap() {
      document.getElementById('codemap').style.display='';
      $('table#codemap input').removeAttr('disabled');
   }

   function show_sec_sap() {
      document.getElementById('sec_sap').style.display='';
      $('table#sec_sap input:text').removeAttr('disabled');
      <?php if ($display!='yes') : ?>
      $('table#sec_sap input').removeAttr('disabled');
      $('table#sec_sap select').removeAttr('disabled');
      <? endif; ?>
      show_codemap();
   }

   function hide_recovery() {
      document.getElementById('recovery').style.display='none';
   }
   function show_recovery() {
      document.getElementById('recovery').style.display='';
      $('table#recovery input').removeAttr('disabled');
      <?php if ($display!='yes') : ?>
      $('table#recovery select').removeAttr('disabled');
      <? endif; ?>
   }
   function show_affinity(){
      document.getElementById('affinity').style.display='';
      $('table#affinity input').removeAttr('disabled');
   }
   function show_environment(){
      document.getElementById('environment').style.display='';
      $('table#environment input').removeAttr('disabled');
   }
   function show_credentials(){
      document.getElementById('credentials').style.display='';
      $('table#credentials input').removeAttr('disabled');
   }
   function show_arguments(){
      $('td.arguments input.argument').remove();   // remove all added arguments
      document.getElementById('arguments').style.display='';
      $('table#arguments input').removeAttr('disabled');
   }
   function show_variables(){
      $('tr.variables').remove();   // remove all added variables
      document.getElementById('variables').style.display='';
      $('table#variables input').removeAttr('disabled');
   }

   function show_executable() {
      document.getElementById('executable').style.display='';
      $('table#executable input:text').removeAttr('disabled');
      <?php if ($display!='yes') : ?>
      $('table#executable input').removeAttr('disabled');
      $('table#executable select').removeAttr('disabled');
      <? endif; ?>
      show_affinity();
      show_environment();
      show_credentials();
      show_arguments();
      show_variables();
      show_codemap();
   }
   function show_dshadow() {
      document.getElementById('dshadow').style.display='';
      document.getElementById('matching').style.display='';
      $('table#dshadow input:text').removeAttr('disabled');
      $('table#matching input:text').removeAttr('disabled');
      <?php if ($display!='yes') : ?>
      $('table#dshadow input').removeAttr('disabled');
      $('table#dshadow select').removeAttr('disabled');
      $('table#matching input').removeAttr('disabled');
      $('table#matching select').removeAttr('disabled');
      <? endif; ?>
   }

   function show_zshadow() {
      document.getElementById('zshadow').style.display='';
      $('table#zshadow input').removeAttr('disabled');
   }
   function show_filetransfer() {
      document.getElementById('filetransfer').style.display='';
      $('table#filetransfer input').removeAttr('disabled');
      <?php if ($display!='yes') : ?>
      $('table#filetransfer select').removeAttr('disabled');
      <? endif; ?>
      document.getElementById('ftp_credentials').style.display='';
      $('table#ftp_credentials input').removeAttr('disabled');
      show_affinity();
      show_codemap();
      change_ft_mode();
   }
   function show_database() {
      document.getElementById('database').style.display='';
      $('table#database input:text').removeAttr('disabled');
      <?php if ($display!='yes') : ?>
      $('table#database input').removeAttr('disabled');
      $('table#database select').removeAttr('disabled');
      $('table#database textarea').removeAttr('disabled');
      <? endif; ?>
      show_credentials();
      show_affinity();
      show_codemap();
   }

   function show_ws() {
      document.getElementById('ws').style.display='';
      $('table#ws input').removeAttr('disabled');
      show_affinity();
      show_credentials();
      show_arguments();
      show_codemap();
   }
   function show_j2ee() {
      document.getElementById('j2ee').style.display='';
      $('table#j2ee input').removeAttr('disabled');
      $('table#j2ee textarea').removeAttr('disabled');
      <?php if ($display!='yes') : ?>
      $('table#j2ee select').removeAttr('disabled');
      <? endif; ?>
      show_affinity();
      show_credentials();
      show_codemap();
   }
   function show_java() {
      document.getElementById('java').style.display='';
      $('table#java input').removeAttr('disabled');
      show_affinity();
      show_variables();
      show_codemap();
   }
   function show_xa() {
      document.getElementById('xa').style.display='';
      $('table#xa input').removeAttr('disabled');
      show_affinity();
      show_variables();
      show_environment();
      $('input[name="stdin"]').attr('disabled', 'disabled');
      $('tr#stdin').css('display', 'none');
      show_credentials();
      show_codemap();
   }
   function show_ibm() {
      document.getElementById('ibm').style.display='';
      $('table#ibm input').removeAttr('disabled');
      show_affinity();
      show_codemap();
   }

// SAP section functions
   function r3type_change() {
      var obj = document.getElementById('r3job_type');
      var tasktype = obj.options[obj.selectedIndex].value;
      switch (tasktype) {
         case "std":
            sap_showall();
            hide_obj('r3job_chlog');
            break;
         case "bwip":
            $('table#sec_sap tr').css('display', '');
            $('table#sec_sap input').removeAttr('disabled');
            $('table#sec_sap select[name!="r3job_type"]').removeAttr('disabled');
            hide_obj('r3job_id');
            hide_obj('r3job_user');
            hide_obj('r3job_spool');
            hide_obj('r3job_log');
            hide_obj('r3job_class');
            hide_obj('r3job_chlog');
            hide_obj('r3job_diswa');
            hide_obj('r3job_immed');
            break;
         case "bwpc":
            $('table#sec_sap tr').css('display', '');
            $('table#sec_sap input').removeAttr('disabled');
            $('table#sec_sap select[name!="r3job_type"]').removeAttr('disabled');
            hide_obj('r3job_id');
            hide_obj('r3job_user');
            hide_obj('r3job_spool');
            hide_obj('r3job_log');
            hide_obj('r3job_class');
            hide_obj('r3job_diswa');
            hide_obj('r3job_immed');
            break;
      }
   }
   function sap_showall() {
      $('table#sec_sap tr').css('display', '');
      $('table#sec_sap input:text').removeAttr('disabled');
      <?php if ($display!='yes') : ?>
      $('table#sec_sap input').removeAttr('disabled');
      $('table#sec_sap select[name!="r3job_type"]').removeAttr('disabled');
      <?php endif; ?>
   }
   function hide_obj(tr_id) {
      $('input[name="'+tr_id+'"]').removeAttr('checked');
      $('input[name="'+tr_id+'"]').attr('disabled', 'disabled');
      $('select[name="'+tr_id+'"]').val('');
      $('select[name="'+tr_id+'"]').attr('disabled', 'disabled');
      $('tr#'+tr_id).css('display', 'none');
   }


   // J2EE change
   function j2ee_operation_change() {
      var obj = document.getElementById('j2ee_operation');
      var tasktype = obj.options[obj.selectedIndex].value;
      switch (tasktype) {
         case "send":
            $('tr#j2ee_message').css('display', '');
            $('table#j2ee textarea').removeAttr('disabled');

            $('tr#j2ee_timeout').css('display', 'none');
            $('input[name="j2ee_timeout"]').attr('disabled', 'disabled');
            break;
         case "receive":
            $('tr#j2ee_message').css('display', 'none');
            $('table#j2ee textarea').attr('disabled', 'disabled');

            $('tr#j2ee_timeout').css('display', '');
            $('input[name="j2ee_timeout"]').removeAttr('disabled');
            break;
      }
   }

   // Database change
   function db_dbms_change() {
      var obj = document.getElementById('db_dbms');
      var tasktype = obj.options[obj.selectedIndex].value;
      switch (tasktype) {
         case "db2":
         case "oracle":
         case "mssql":
            $('table#database input').removeAttr('disabled');
            $('tr#db_server').css('display', '');
            $('tr#db_port').css('display', '');
            $('tr#db_name').css('display', '');

            $('tr#jdbc_driver').css('display', 'none');
            $('input[name="db_jdbc_driver"]').attr('disabled', 'disabled');
            $('tr#jdbc_string').css('display', 'none');
            $('input[name="db_jdbc_string"]').attr('disabled', 'disabled');
            break;
         case "JDBC":
            $('table#database input').removeAttr('disabled');

            $('tr#db_server').css('display', 'none');
            $('input[name="db_server"]').attr('disabled', 'disabled');
            $('tr#db_port').css('display', 'none');
            $('input[name="db_port"]').attr('disabled', 'disabled');
            $('tr#db_name').css('display', 'none');
            $('input[name="db_name"]').attr('disabled', 'disabled');

            $('tr#jdbc_driver').css('display', '');
            $('tr#jdbc_string').css('display', '');
            break;
      }
   }
   // Filetransfer Mode - CodePage
   function change_ft_mode() {
      var obj = document.getElementById('ft_mode');
      var mode = obj.options[obj.selectedIndex].value;
      if(mode == 'ascii') {
         $('tr#ft_codepage').css('display','');
         $('tr#ft_codepage input').removeAttr('disabled');
      }
      else {
         $('tr#ft_codepage').css('display','none');
         $('tr#ft_codepage input').attr('disabled', 'disabled');
      }
   }
   // Matching
   function showMatch() {
      var obj = document.getElementById('matching_sel');
      var selection = obj.value;
      if(selection=='RELATIVE') {
         $('div#relative').css('display','block');
         $('div#relative input').removeAttr('disabled');
         $('div#relative select').removeAttr('disabled');
         $('div#absolute').css('display','none');
         $('div#absolute input').attr('disabled', 'disabled');
         $('div#absolute select').attr('disabled', 'disabled');
      }
      else if (selection=='ABSOLUTE') {
         $('div#relative').css('display','none');
         $('div#relative input').attr('disabled', 'disabled');
         $('div#relative select').attr('disabled', 'disabled');
         $('div#absolute').css('display','block');
         $('div#absolute input').removeAttr('disabled');
         $('div#absolute select').removeAttr('disabled');
      }
      else {
         $('div#relative').css('display','none');
         $('div#absolute').css('display','none');
         $('div#relative input').attr('disabled', 'disabled');
         $('div#relative select').attr('disabled', 'disabled');
         $('div#absolute input').attr('disabled', 'disabled');
         $('div#absolute select').attr('disabled', 'disabled');
      }
   }

   function insertArgument () {
      var count = $('td.arguments input').size();
      i=count + 1;
      $('td.arguments').append('<input type="text" class="argument" name="arguments['+i+']"/>');
   }
   function insertVariables () {
      var count = $('tr.variables').size();
      i=count + 1;
      $('table.variables').append('<tr class="variables"><td><input type="text" class="variables tws_alfanum" name="var_name['+i+']"/></td><td><input type="text" class="variables" name="var_val['+i+']"/></td></tr>');
   }

   function tws_cmp_vals (val1, val2) {
      if(val1 != val2)
         alert("Password values not correspond, please reenter passwords once again");
   }

// Call Workstation picker
   function select_workstations() {
      var obj = document.getElementById('sel_task_type');
      var tasktype = obj.options[obj.selectedIndex].value;
      if(tasktype == "UNIX" || tasktype == "WINDOWS"  || tasktype == "OTHER") {
         tws_picker_open('workstation_picker.php', 'fieldname=workstation&fieldvalue=' + document.contents.workstation.value);
      }
      else if (tasktype=="zShadowJob"){
         tws_picker_open('workstation_picker.php', 'os=Z&type=E&fieldname=workstation&fieldvalue=' + document.contents.workstation.value);
      }
      else if (tasktype=="SAP"){
         tws_picker_open('workstation_picker.php', 'os=O&type=X&method=r3batch&fieldname=workstation&fieldvalue=' + document.contents.workstation.value);
      }
      else{
         tws_picker_open('workstation_picker.php', 'type[]=A&type[]=E&type[]=L&type[]=Y&fieldname=workstation&fieldvalue=' + document.contents.workstation.value);
      }
   }

   function type_change(obj) {
      var tasktype = obj.options[obj.selectedIndex].value;
      hide_all();

      switch (tasktype) {
         case "": default:
            hide_recovery();
            $('input#workstation_list').attr('disabled', 'disabled');
            break;
         case "UNIX":
            show_sec_85();
            break;
         case "WINDOWS":
            show_sec_85();
            show_sec_interactive();
            break;
         case "OTHER":
            show_sec_85();
            break;
         case "SAP":
            show_sec_sap();
            r3type_change()
            break;
         case "executable":
            show_executable();
            break;
         case "distributedShadowJob":
            show_dshadow();
            showMatch();
            break;
         case "zShadowJob":
            show_zshadow();
            break;
         case "filetransfer":
            show_filetransfer();
            break;
         case "database":
            show_database();
            db_dbms_change();
            break;
         case "ws":
            show_ws();
            break;
         case "j2ee":
            show_j2ee();
            j2ee_operation_change();
            break;
         case "java":
            show_java();
            break;
         case "xajob":
            show_xa();
            break;
         case "ibmi":
            show_ibm();
            break;
      }
   }
</script>
<script type="text/javascript" src="tws_insert_row.js"></script>
<style type="text/css">
   table.add_job, table.common {
      width:95%;
   }
   table.add_job, table.add_job td, table.common, table.common td {
      border-collapse:collapse;
      padding:3px;
      /*border-width:1px;
      border-style: solid;*/
   }
   td.star {
      width:15px;
   }
   body {
      margin-left:10px;
      padding-left:10px;
   }
</style>
</head>
<body>
   <div id="show">
<?
  $log_file_name=tws_log('', 'OPEN');

   tws_print_head($title, array('__log__' => $log_file_name, '__help__' => 'tws_add_job_help.php'));

   if (($tmp_test == false) && empty($draft) && ($copy=='yes' || $modify=='yes' || $display=='yes')) {
      $num_elements=count($selection);
      if ($num_elements == 0) {
         tws_dyer("No job selected");
      } elseif ($num_elements > 1) {
         tws_dyer("Multiple jobs selected - Only one job can be ".($copy=="yes" ? 'copied' : 'modified')." at a time");
      }
      if ($modify=="yes") {
         // lock object
         tws_composer_lock("jd=$selection[0]") or tws_dyer("Unable to lock job ".$selection[0]);
         // backup
         if (($original_data=tws_composer_create_from("jd=$selection[0]"))===FALSE) tws_dyer("Unable to create backup");
      }

      $arr = tws_dbobject_to_array('job', $selection[0]);
   }
?>

<form method="post" name="contents" action="tws_add_job_action.php" onsubmit="if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Job',null)) { cancel_button_pressed=false; return false;}">
<?
tws_arr_to_form('job', $action, $arr);

if ($display!='yes') {
      if (isset($newjob) && $newjob=='yes') {
         echo '<input type="hidden" name="newjob" value="yes" />'."\n";
      }
      if ($modify == "yes") {
         echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
         echo "<input type=\"hidden\" name=\"workstationx\" value=\"".htmlspecialchars($workstation)."\">\n";
         echo "<input type=\"hidden\" name=\"jobx\" value=\"".htmlspecialchars($job)."\">\n";
         echo "<input type=\"hidden\" name=\"original_data\" value=\"".htmlspecialchars($original_data)."\">\n";
         echo "&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Update\" onClick=\"return tws_validate_form()\"/>\n";
      } else {
         if ($copy == 'yes') {
            echo '<input type="hidden" name="copy" value="yes" />'."\n";
         }
         echo "&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Add\" onClick=\"return tws_validate_form()\"/>\n";
      }
      if (tws_zli_module_check ()) {
          echo "<input type=\"hidden\" name=\"netmodule_file\" value=\"".htmlspecialchars($netmodule_file)."\">\n";
          echo "<input type=\"hidden\" name=\"netmodule_addjob\" value=\"".htmlspecialchars($netmodule_addjob)."\">\n";
      }

      if (tws_zli_module_check () && ($netmodule_file != "" || $netmodule_addjob != ""))
         ;
      else {
?>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Save Draft">
<?
         if (!isset($newjob) || $newjob != 'yes') {
            if ($modify=="yes") {
                echo "&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Cancel\" onClick=\"cancel_button_pressed=true;\"/>\n";
            } else {
                echo "&nbsp;&nbsp;&nbsp;<input type=\"button\" value=\"Cancel\" onClick=\"ConfirmCancel('Job','tws_jobsx.php')\"/>\n";
            }
         }
      }
      tws_print_synchro_token();   // synchro_token
      echo "<input type=\"hidden\" name=\"draft_file\" value=\"",(isset($draft_file) ? $draft_file : ''),"\">\n";
      echo '&nbsp;&nbsp;&nbsp;<input type="button" value="Print" onClick="window.print()">';
   }
   else {
      echo '<input type="button" value="Print" onClick="tws_url_print();">';
      echo "&nbsp;&nbsp;&nbsp;<input type=\"button\" value=\"Close\" onClick=\"tws_url_close();\"/>\n";
   }
?>
</form>
<script type="text/javascript">
   sec_interactive_color=document.getElementById('sec_interactive').style.color;
   type_change(document.getElementById('sel_task_type'));
</script>
   </div>
</body>
</html>
