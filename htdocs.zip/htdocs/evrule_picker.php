<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_import_request_variables("P","rqst_");

   $formname=isset($rqst_formname) ? trim($rqst_formname) : 'contents';
   $fieldname=$rqst_fieldname;
   tws_check_elname($formname);
   tws_check_elname($fieldname);
   $fieldvalue=tws_gpc_get($rqst_fieldvalue);
   $display="yes";

   $allowmultiple=@$rqst_allowmultiple;
   $s=($allowmultiple === 'yes') ? 's' : '';

   if ((strpos($fieldname,"[") !== FALSE) && (strpos($fieldname,"]") !== FALSE)) {
      $jsfieldname="elements['" . $fieldname . "']";
   }
   else {
      $jsfieldname = $fieldname;
   }
?>
<script type="text/javascript">

function sendValue(formsel) {
 var selectionval = "";
 if (formsel) {

    for (var i = 0; i < formsel.options.length; i++)
       if (formsel.options[i].selected)
          selectionval = selectionval + formsel.options[i].value + ",";
    window.document.<?=$formname?>.<?=$jsfieldname?>.value = selectionval.substr(0, selectionval.length - 1);
 }
   $('[name="<?=$fieldname?>"]').keyup();
   $("#evrule_picker").dialog( "close" );
}

</script>

<div id="evrule_picker">

<h1>Select Event Rule<?=$s?></h1>
<br>
<form name="evrule_list">
<?php
   if ($fieldvalue=='') {
      $arg='@';
   } else {
      if ((strpos($fieldvalue,'*')===FALSE) && (strpos($fieldvalue,'@')===FALSE)) {
         $arg=$fieldvalue.'@';
      } elseif (strpos($fieldvalue,'*')!==FALSE) {
         $arg=strtr($fieldvalue,'*','@');
      } else {
         $arg=$fieldvalue;
      }
   }

   echo '<select id="sel" name="selection" class="picker" size="15" onDblClick="sendValue(this.form.selection);"',($allowmultiple === 'yes' ? ' multiple="multiple"' : ''),">\n";
   if (($evrules=tws_get_evrules($arg))!==FALSE) {
      foreach ($evrules['evrule_name'] as $i => $name) {
         $evrule_folder = $evrules['evrule_folder'][$i];
         echo '<option value="',$evrule_folder.$name,'">',$evrule_folder.$name,'</option>',"\n";
      }
   }
   echo '</select>',"\n";

   if ($evrules===FALSE || $evrules['evrule_num']===0) {
      echo '<script type="text/javascript">',"\n",'  deleteElem(\'sel\');',"\n",'</script>',"\n";
      if ($evrules===FALSE) {
         tws_warning('Unable to event rules definitions list');
      } else echo '<p class="warning">No qualified event rules definition entries matching \'',  htmlspecialchars ($arg),'\'.</p>',"\n";
      echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\"></center>\n";
   } else {
      echo "<br><br>\n";
      echo "<center><input type=\"button\" value=\"OK\" onClick=\"sendValue(this.form.selection);\"></center>\n";
   }
?>
</form>
</div>

<script type="text/javascript">

$(function() {
   tws_picker_constructor("evrule_picker");
});

</script>
