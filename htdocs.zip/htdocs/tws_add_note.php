<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");

   tws_import_request_variables("P","rqst_");
   $name = (isset($rqst_name)) ? tws_gpc_get($rqst_name, 'tws_mask') : "";
   $type = (isset($rqst_type)) ? tws_gpc_get($rqst_type) : "";
   $cpu = (isset($rqst_cpu)) ? tws_gpc_get($rqst_cpu, 'tws_mask') : "";
   $return_url = (isset($rqst_url)) ? tws_gpc_get($rqst_url) : "";
   $user = (isset($rqst_user)) ? tws_gpc_get($rqst_user) : $_SERVER['PHP_AUTH_USER'];          // back from tws_add_note_exec
   $title = (isset($rqst_title)) ? tws_gpc_get($rqst_title) : "";                 // back from tws_add_note_exec
   $text = (isset($rqst_text)) ? tws_gpc_get($rqst_text) : "";                    // back from tws_add_note_exec
   if($type == "Comment" || $type == "Contact Information" || $type == "Recovery Procedures")
      $type = "Job";
?>
<html>
<head>
   <title>Add <?php echo $type; ?> Note</title>
   <?php tws_stylesheet(); ?>
<style type="text/css">
   td.star {
      width:15px;
      vertical-align:top;
   }
</style>
</head>

<body>
<?php
   tws_set_window_title();

   $filter=($cpu && $type!='Workstation') ? array('Workstation'=>$cpu, $type=>$name) : array($type=>$name);
   tws_print_head('Add '.$type.' Note', array('__help__'=>'tws_notes_help.php?type='.$type, '__filter__'=>$filter) );

   if (!tws_rights(NOTES)) {
      tws_access_denied();
   }

   $have_cpu=($type=='Jobstream' || $type=='Job' || $type=='Resource' || $type=='User');
?>

<form method="post" name="contents" action="tws_add_note_exec.php">
<table border=0 cellspacing=0>
   <tr>
      <td class=standard valign="top">Note Type:</td>
      <td>&nbsp;</td>
   <?php if (($type != "Job") && ($type != "Comment") && ($type != "Contact Information") && ($type != "Recovery Procedures")) { ?>
      <td class=standard><?php echo htmlspecialchars($type); ?></td>
   <?php } else { ?>
      <td class=standard>
         <select name="type">
            <option value="Comment" <? if (($type == "Job") || ($type == "Comment")) echo " selected"?>>Comment</option>
            <option value="Contact Information" <? if ($type == "Contact Information") echo " selected"?>>Contact Information</option>
            <option value="Recovery Procedures" <? if ($type == "Recovery Procedures") echo " selected"?>>Recovery Procedures</option>
         </select>
   <?php } ?>
   </tr>
   <tr><td colspan="3">&nbsp;</td></tr>
   <?php if($have_cpu) { ?>
   <tr>
      <td class=standard valign="top">Workstation:</td>
      <td class="star"> * </td>
      <td class=standard valign="top">
            <input type="text" name="cpu" required="required" class="tws_mask" size=16 maxlength=16 value="<?=$cpu?>"/>&nbsp;&nbsp;
            <input type="button" name="workstation_list" value="List" onClick="tws_picker_open('workstation_picker.php', 'fieldname=cpu&fieldvalue=' + document.contents.cpu.value);"/>
      </td>
   </tr>
   <tr><td colspan="3">&nbsp;</td></tr>
   <?php } ?>
   <tr>
      <td class=standard valign="top"><?=$type?>:</td>
      <td class="star"> * </td>
      <td><input type="text" name="name" required="required" class="tws_mask" size=40 maxlength=40 value="<?=$name?>"/>&nbsp;&nbsp;
         <?php $objid=strtolower(str_replace(' ','_',$type));
         if($type=="Event Rule") $objid = "evrule";
         echo "<input type=\"button\" value=\"List\" name=\"${objid}_list\" onClick=\"tws_picker_open('${objid}_picker.php', '";
               if ($type=="Calendar") echo "includestock=no&";
               if ($type=="Parameter") echo "table=no&";
         echo "fieldname=name&fieldvalue=' + document.contents.name.value"; if ($have_cpu) echo " + '&cpux=' + document.contents.cpu.value"; echo ");\" />\n";?>
      </td>
   </tr>
   <tr><td colspan="3">&nbsp;</td></tr>
   <tr>
      <td class=standard valign="top">Creator:</td>
      <td> </td>
      <td class=standard><?php echo htmlspecialchars($user); ?></td>
   </tr>
   <tr><td colspan="3">&nbsp;</td></tr>
   <tr>
      <td class=standard valign="top">Title:</td>
      <td class="star"> * </td>
      <td><input type="text" name="title" required="required" size=32 maxlength=32<?php if ($title) { ?> value="<?php echo htmlspecialchars($title); ?>" <?php } ?>/></td>
   </tr>
   <tr><td colspan="3">&nbsp;</td></tr>
   <tr>
      <td class=standard valign="top">Note:</td>
      <td class="star"> * </td>
      <td class=standard valign="top"><textarea name="text" cols="80" rows="15" wrap="soft"><?php if ($text) echo htmlspecialchars($text); ?></textarea></td>
   </tr>
</table>

<br/><br/>

<?php if (($type != "Job") && ($type != "Comment") && ($type != "Contact Information") && ($type != "Recovery Procedures")) { ?>
<input type="hidden" name="type" value="<?=htmlspecialchars($type)?>" />
<?php } ?>
<input type="hidden" name="user" value="<?=htmlspecialchars($user)?>" />
<input type="hidden" name="url" value="<?=$return_url?>" />
<input type="submit" name="action" value="Submit" onClick="return tws_validate_form()">
<input type="button" value="Cancel" name="Back" onclick="window.location.replace('<?=$return_url?>')"/>
</form>
</body>
</html>
