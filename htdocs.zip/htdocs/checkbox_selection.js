//
//   HORIZONT Software GmbH, Munich
//

var shiftIsPressed = false;
var firstCheckbox = undefined;
var firstCheckboxValue = undefined;
var secondCheckbox = undefined;

document.onkeydown = checkShift
document.onkeyup = uncheckShift

function checkShift(e) {
   var keycode;
   if (window.event)
      keycode = window.event.keyCode;
   else if (e)
      keycode = e.which;

   if (keycode == 16) {                               // 16 is SHIFT (left and right)
      shiftIsPressed = true;
   }
}


function uncheckShift(e) {
   if (shiftIsPressed) {
      shiftIsPressed = false;
      firstCheckbox = undefined;
      secondCheckbox = undefined;
      firstCheckboxValue = undefined;
   }
}

function selectCheckboxes(element) {
   if (shiftIsPressed == false) {
      firstCheckbox = element;
      firstCheckboxValue = firstCheckbox.checked;
   }
   else if ((firstCheckbox != undefined) && (secondCheckbox == undefined) && (element.form == firstCheckbox.form) && (element != firstCheckbox)) {
      secondCheckbox = element;
      form = element.form;
      selection = form.elements[element.name];
      var changeValue = false;
      for (i = 0; i < selection.length; i++) {
         if ((selection[i] == firstCheckbox) || (selection[i] == secondCheckbox)) {
            if (changeValue)
               changeValue = false;
            else
               changeValue = true;
         }
         if (changeValue || (selection[i] == firstCheckbox) || (selection[i] == secondCheckbox))
            selection[i].checked = firstCheckboxValue;
      }
   }
}
function selectCheckboxById (id) {
   if ( $('input#'+id).is(':checked') ){
      $('input#'+id).prop('checked', false);
      $('input#'+id).removeProp('checked');
   }
   else
      $('input#'+id).prop('checked', true);
}