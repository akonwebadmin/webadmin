<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html><head>
<title>Add Domain</title>
<?php
tws_stylesheet();
tws_show_backup();
?>
</head>
<body>
<?php tws_set_window_title(); ?>

<?php
   tws_check_synchro_token();    // synchro_token
   tws_import_request_variables("P","rqst_");

   $modify=@$rqst_modify;
   $confirm=@$rqst_confirm;
   $backup=@$rqst_backup;
   $original_data=tws_gpc_get($rqst_original_data);
   if ($modify == "yes") {
     if (!tws_permit_action('database_domains','Modify')) { tws_access_denied ();}
      $domain=strtoupper($rqst_domain_namex);
   } else {
     if (!tws_permit_action('database_domains','Add')) { tws_access_denied ();}
      $domain=strtoupper($rqst_domain_name);
   }
   tws_check_arg($domain, 'tws_name');
   $description=str_replace("\\'","'",tws_gpc_get($rqst_description));
   $parent=tws_gpc_get($rqst_parent, 'tws_name');

   $action=$rqst_action;
   if ($action=="Cancel") {
      // Unlock the object
      tws_composer_unlock("dom=$domain") or tws_dyer("Unable to unlock domain '$domain'");
      echo "<script type='text/javascript'>
         if(window.name == 'tws_popup')  window.close();
         else window.location.replace('tws_domainsx.php')
      </script>\n";
      exit;
   }
   elseif($action=="Return to Modification"){
      include("tws_add_domain.php");
      exit;
   }

// Perform error checking
   $field_error=0;
   $field_error_text="";

   if ($domain == "") {
      $field_error_text .= "Domain Name: '$domain' Error: domain name not set.\n";
      $field_error++;
   }
   if ($field_error != 0) {
      if ($modify == "yes") {
         echo "<h1>Modify Domain Status</h1>\n";
      } else {
         echo "<h1>Add Domain Status</h1>\n";
      }
      tws_err("Incorrect values entered. Domain add/modify operation cannot continue", array('attr'=>$field_error_text));
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"Javascript:history.back()\">Return to Domain Definition</a>\n";
      die("</body>\n</html>\n");
   }

// Check for existing domain
   $match=FALSE;
   if ($confirm != "yes") {
      if (($db_domain = tws_get_domains($domain)) === FALSE) {
         tws_dyer("Unable to list domains", '', "tws_domainsx.php");
      }
      if ($db_domain['domain_num'] > 1) {
         tws_dyer("Database query error", '', "tws_domainsx.php");
      }
      if (($db_domain['domain_num'] == 1) && ($domain == $db_domain['domain_name'][0])) {
         $orig_description = $db_domain['domain_description'][0];
         $orig_parent = $db_domain['domain_parent'][0];
         $match = TRUE;
      }
   }

   if ($match == TRUE) {
      if ($modify == "yes") {
         echo "<h1>Confirmation</h1>\n";
      } else {
         echo "<h1>Replace Domain Confirmation</h1>\n";
      }
      echo "<br><br>\n";
      echo "<h3>Confirm:</h3>\n";
      if ($modify != "yes") {
         echo "&nbsp;&nbsp;<b>The Domain Name entered already exists</b>\n";
         echo "<br><br>\n";
      }
      echo "&nbsp;&nbsp;&nbsp;<b><u>Original Domain:</u></b>\n";
      echo "<br><br>\n";

      $orig_domain_data = Array ( 'domain_name' => $domain , 'description' => $orig_description , 'parent' => $orig_parent );
      $new_domain       = Array ( 'domain_name' => $domain , 'description' => $description, 'parent' => $parent );
      $label_map        = Array ( 'domain_name' => 'Name' , 'description' => 'Description' , 'parent' => 'Parent' );

      tws_show_cmp_table("Original Domain", "New Domain", $orig_domain_data, $new_domain, $label_map);

// confirmation form
      echo "<form method=post name=\"confirm\" action=\"tws_add_domain_exec.php\">\n";
      echo "<input type=\"hidden\" name=\"confirm\" value=\"yes\">\n";
      if ($original_data=='') {
         //missing original data - this happens if user is adding job that already exists.
         if (($original_data=tws_composer_create_from("dom=$domain"))===FALSE) {
            tws_err("Unable to get original data required to create backup.");
         }
      }
      echo "<input type=\"hidden\" name=\"original_data\" value=\"".htmlspecialchars($original_data)."\">\n";
      foreach ($new_domain as $key=>$val) {
         echo "<input type=\"hidden\" name=\"".htmlspecialchars($key)."\" value=\"".htmlspecialchars($val)."\">\n";
      }
      if (tws_rights(SAVEBACKUPS) && $original_data!=''){
         echo "<input type='hidden' name='backup' value='yes'>";
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type='checkbox' name='backup' value='yes' checked disabled>&nbsp;Save Backup Copy of Original Domain</label>\n";
      }
      else
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type=\"checkbox\" name=\"backup\" value=\"yes\" ".($original_data!='' ? 'checked' : 'disabled').">&nbsp;Save Backup Copy of Original Domain</label>\n";
      echo "<br><br><br>\n";
      if ($modify == "yes") {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Update\" name=\"action\">\n";
         echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
         echo "<input type=\"hidden\" name=\"domain_namex\" value=\"".htmlspecialchars($domain)."\">\n";
      } else {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Replace\" name=\"action\">\n";
      }
      echo '&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Return to Modification">'."\n";
      echo '&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Cancel">'."\n";
      tws_print_synchro_token();   // synchro_token
      echo "</form>\n";

   } else {
// Create Backup Copy if option checked
      if ($backup == "yes") {
         if (($bckfilename = tws_write_backup($original_data, "domain", $domain)) === FALSE) {
            tws_dyer("Unable to write backup", '', "tws_domainsx.php");
         }
      }

// unlock the object
      tws_composer_unlock("dom=$domain");

// Create random temporary filename
      $tmpfilename="$maestro_dir/webadmin/tmp/domain.".tws_rndstr().".tmp";
      $fp=fopen($tmpfilename,'w') or tws_dyer("Unable to create temporary file '$tmpfilename'", '', "tws_domainsx.php");

      $cmd=Array();
      $cmd[]="DOMAIN $domain DESCRIPTION \"".addcslashes($description,'"')."\"\n";
      $cmd[]=($parent!='') ? " PARENT $parent\n" : " ISMASTER\n";
      $cmd[]="END\n";
      foreach ($cmd as $cmdline) {
         $num_bytes=fwrite($fp,$cmdline);
         if ($num_bytes < 0) {
            fclose($fp);
            tws_dyer("Unable to write temporary file", '', "tws_domainsx.php");
         }
      }
      fclose($fp);
      tws_chmod($tmpfilename,0644);

      if ($confirm == "yes") {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "replace $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      } else {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "add $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      }

      $stdout3='';
      $ec_popen=tws_popen($command3, $ec3, $stdout3, $stdout3, "N");
     
      //remove the tmp file now
      unlink($tmpfilename);
 
      //testing for the AWSBIA288I Total objects updated: 0.
      //Note: This has been added on 2016-07 to fix the problem of composer updating 
      //correctly objects but returning incorrect return codes (not 0 or 4)
      $not_updated=!preg_match('/AWSBIA288[^\n]+(\d+)/', $stdout3, $_r) || $_r[1]==0;

      if ($ec_popen===FALSE || ($ec3!=0 && $ec3!=4 && $not_updated)) {
         if ($modify == "yes") {
            echo "<h1>Modify Domain Status</h1>\n";
         } else {
            echo "<h1>Add Domain Status</h1>\n";
         }
         tws_err("Domain add/modify operation failed", array('twscmd'=>$command3->compile('log'), 'stdout'=>$stdout3, "EC_POPEN"=>$ec_popen, "EC_UPDATED"=>$ec3, "NOT_UPDATED"=>tws_yesno($not_updated,'YES','NO')));
         echo "<form action='tws_add_domain_exec.php' method='post' onsubmit=\"if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Workstation',null)) { cancel_button_pressed=false; return false;}\">\n";
         echo tws_create_hidden_inputs($_POST);
         tws_print_synchro_token();
         echo "<input type='submit' name='action' value='Cancel' onClick='cancel_button_pressed=true;'/>\n";
         echo "<input type='submit' name='action' value='Return to Modification'/>\n";
         echo "</form>";
      } elseif (preg_match("/warnings?\s[1-9]/i",$stdout3)) {
         if ($modify == "yes") {
            $headertext="Modify Domain";
         } else {
            $headertext="Add Domain";
         }
         tws_err("The Domain has been saved with the following warnings:", array('stdout'=>$stdout3));

         $shortwarnfilename="warn.".tws_rndstr().".txt";
         $warnfilename="$webadmin_tmp_dir/$shortwarnfilename";
         $warnfp=fopen("$warnfilename","w") or tws_dyer("Unable to create warning text file", "Warning output :\n$stdout3", "tws_domainsx.php");
         $num_bytes=fwrite($warnfp,"$stdout3");
         if ($num_bytes < 0) {
            fclose($warnfp);
            unlink($warnfilename);
            tws_dyer("Unable to write warning text file", "Warning output :\n$stdout3", "tws_domainsx.php");
         }
         fclose($warnfp);
         tws_dyer();
      } else {
         if ($backup == "yes") {
            if ($modify == "yes") {
               echo "<h1>Modify Domain Status</h1>\n";
            } else {
               echo "<h1>Add Domain Status</h1>\n";
            }
            echo "<p class=\"message\">\n";
            echo "The domain has been successfuly saved.&nbsp;";
            $bckfilename = preg_replace("/\\\\/", '/', $bckfilename);
            $file = explode('/',$bckfilename);
            $file = end($file);
            if(tws_profile('auth_user_group')=='admin')
               echo "<a href=\"javascript:showBackup('$file')\">Display Backup File</a>\n";
            echo "</p>\n";
               echo "<input type='button' value='OK' onClick=\"closeme('tws_domainsx.php')\" />\n";
         } else {
            echo "<script type='text/javascript'>
               closeme('tws_domainsx.php');
            </script>\n";
         }
      }
   }
?>
</body>
</html>
