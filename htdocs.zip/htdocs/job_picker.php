<?php
//   HORIZONT Software GmbH, Munich
//
    $__tlogmode='APPEND';
    require_once 'tws_functions.php';

   if (defined('IWD_PROCMAN')) {
      $iwd_class='iwd_dbjd';
      $search_elems=array();
      $search=$iwd_class::get_search_elems($search_elems, 'ref');
   }

   tws_import_request_variables("P","rqst_");

   $formname=isset($rqst_formname) ? trim($rqst_formname) : 'contents';
   tws_check_elname($formname);
   $cpux=strtoupper($rqst_cpux);
   $fieldname=$rqst_fieldname;
   $fieldid=@$rqst_fieldid;
   if(!isset($fieldid))
      tws_check_elname($fieldname);
   @$fieldvalue=$rqst_fieldvalue;
   $allowmultiple=@$rqst_allowmultiple;
   $display="yes";
   $action = strtoupper(tws_gpc_get(@$rqst_action));
   if($action != 'SUBMIT')
      $action = 'LIST';

   if ((strpos($fieldname,"[") !== FALSE) && (strpos($fieldname,"]") !== FALSE)) {
      $jsfieldname="elements['" . $fieldname . "']";
   }
   else {
      $jsfieldname = $fieldname;
   }
?>

<div id="job_picker">

<script type="text/javascript">

function updateValue(val) {
   <?php
      if (isset($fieldid)) {
         echo '$(window.document).find(\'input[id="'.addcslashes($fieldid,'\'').'"]\').last().attr(\'value\', val);',"\n";
      } else {
         echo 'window.document.'.$formname.'.'.$jsfieldname.'.value = val;',"\n";
      }
   ?>
   $('[name="<?=$fieldname?>"]').keyup();
}

function sendValue(formsel) {
   var selectionval = "";
   if (formsel) {
      for (var i = 0; i < formsel.options.length; i++)
      if (formsel.options[i].selected)
         selectionval = selectionval + formsel.options[i].value + ",";
      updateValue(selectionval.substr(0, selectionval.length - 1));
   }
   $( "#job_picker" ).dialog( "close" );
}
   <?php
      if (defined('IWD_PROCMAN')) {
         if (trim($fieldvalue)=='') {
            $fieldvalue=$search_elems[$iwd_class][0];
            echo "updateValue('".$fieldvalue."');\n";
         }
      }
   ?>

</script>

<h1>Select Job</h1>
<br>
<form name="job_list">
<?php
   if ($cpux == "") {
      echo "<center><p class=warning>No workstation name selected</p>\n";
      echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\"></center>\n";
   } else {
      $cpux=strtoupper(trim($cpux));
      $job_num=0;

      if ($fieldvalue=='') {
         $arg='@';
      } else {
         if ((strpos($fieldvalue,'*')===FALSE) && (strpos($fieldvalue,'@')===FALSE)) {
            $arg=$fieldvalue.'@';
         } elseif (strpos($fieldvalue,'*')!==FALSE) {
            $arg=strtr($fieldvalue,'*','@');
         } else {
            $arg=$fieldvalue;
         }
      }

      echo "<select id=\"sel\" name=\"selection\" class=\"picker\" size=14 onDblClick=\"sendValue(this.form.selection);\"";
      if ($allowmultiple == "yes") {
         echo " multiple";
      }
      echo ">\n";

      function job_picker_callback(&$jb) {
         global $cpux;
         $value = '';
         if(!empty($jb['job_folder']))
            $value = $jb['job_folder'];
         $value .= $jb['job_name'];
         echo '<option value="'.$value.'">',($cpux==$jb['job_workstation'] ? '' : $jb['job_workstation'].'#').$value.'</option>',"\n";
      }

      $select_options = '';
      if (defined('IWD_PROCMAN')) { //IWD/ProcMan
         $arg=strtr($arg,"@","*");
         $cpux=strtr($cpux,"@","*");
         if (($objs=$iwd_class::get_listing($cpux.'#'.$arg, 'ref'))!==FALSE) {
            $result['job_num']=count($objs);
            foreach($objs as $obj) {
               $select_options .= '<option value="'.$obj['rname'].'" '.(($obj['rname']==$fieldvalue) ? 'selected' : '').'>'.$obj['name'].' ('.$obj['version'].')</option>'."\n";
            }
            echo $select_options;
         } else {
            echo '</select>';
            hwi_log_flush();
            $result=FALSE;
         }
      }
      else { //IWS/WebAdmin
         $result=tws_get_jobs($cpux, $arg, '', 0, 1, 'job_picker_callback');  //,$action
      }
      echo "</select>\n";

      if ($result===FALSE || $result['job_num']==0) {
         echo '<script type="text/javascript">',"\n",'  deleteElem(\'sel\');',"\n",'</script>',"\n";
         if ($result===FALSE) echo '<center><p class="warning">Unable to get job definitions list</p>';
         else echo '<center><p class="warning">No qualified job definition entries matching ',htmlspecialchars($cpux.'#'.$arg),'.</p>',"\n";
         echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\"></center>\n";
      } else {
         echo "<br><br>\n";
         echo "<center><input type=\"button\" value=\"OK\" onClick=\"sendValue(this.form.selection);\"></center>\n";
      }
   }
?>
</form>
</div>

<script type="text/javascript">

$(function() {
   tws_picker_constructor("job_picker");
});

</script>
