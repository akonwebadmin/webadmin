<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<?php
   $report_handle="tws_".strtolower($objecttype)."_report";
   tws_stylesheet();
?>
<title><?=$objecttype?> Report Design</title>

<script type="text/javascript">
   function set_titlebox() {
      if($('#titletext').val() != '' )
         $('#title').attr('checked','checked');
      else
         $('#title').removeAttr('checked');
   }

   function check_content(){
      if( $('input[name^="selection["]').is(':checked') == false )
         $('input[name^="selection["]').attr('checked','checked');
   }
</script>
</head>
<body>
<?php tws_set_window_title(); ?>

<h1><?=htmlspecialchars($objecttype)?> Report Design</h1>

<form method=post name="contents" action="tws_view_database_report.php">
<input type="hidden" name="report_handle" value="<?=htmlspecialchars($report_handle)?>">
<input type="hidden" name="default_title" value="<?=htmlspecialchars($objecttype)?> Report">
<table class=wireframe cellspacing=0 cellpadding=4>
<tr class=header>
<th class=wireframe>Select</th>
<th class=wireframe>Column</th>
<th class=wireframe>Criteria</th>
<th class=wireframe>Sort</th>
<th class=wireframe>Sort Priority</th>
</tr>

<?php
   $cols=$report_handle(null);

   foreach ($cols as $col=>$alias) {
      echo "<tr>\n";
      echo "   <td class=\"wireframe\" align=\"center\"><input type=\"checkbox\" name=\"selection[$col]\" checked></td>\n";
      echo "   <td class=\"wireframe\">".htmlspecialchars($alias)."</td>\n";
      echo "   <td class=\"wireframe\"><input type=\"text\" name=\"criteria[$col]\" size=\"20\" maxlength=\"80\"></td>\n";    //  class='tws_mask'
      echo "   <td class=\"wireframe\"><select name=\"order[$col]\">\n";
      echo "         <option value=\"\"></option>\n";
      echo "         <option value=\"ASC\">Ascending</option>\n";
      echo "         <option value=\"DESC\">Descending</option>\n";
      echo "      </select></td>\n";
      echo "   <td class=\"wireframe\"><select name=\"priority[$col]\">\n";
      for ($i=0; $i<=count($cols); $i++) {
         echo "        <option value=\"$i\">".($i==0 ? '' : $i)."</option>\n";
      }
      echo "     </select></td>\n";
      echo "</tr>\n\n";
   }
?>
</table>
<br>
&nbsp;&nbsp;&nbsp;<a href="Javascript:CheckAll(document.contents);">Check All</a>&nbsp;&nbsp;-&nbsp;&nbsp;<a href="Javascript:ClearAll(document.contents);">Clear All</a>
<br><br><br>
<table border=0>
<!--tr>
<td class=standard valign="top" width=120>&nbsp;&nbsp;Records&nbsp;per&nbsp;page:</td>
<td class=standard><select name=records>
  <option selected>ALL
  <option>10
  <option>20
  <option>30
  <option>40
  <option>50
  <option>100
  </option></select>
</td>
</tr>
<tr><td>&nbsp;</td></tr-->
<tr>
<td class=standard>
&nbsp;&nbsp;<b><label><input type="checkbox" name="title" id="title" value="yes">
Set Title:</label></b>
</td>
<td><input type="text" name="titletext" id="titletext" size=40 maxlength=100 onkeyup="set_titlebox();"></td>
</tr>
<?php
/*TODO: Implement CSV send
<tr><td>&nbsp;</td></tr>
<tr>
<td class=standard colspan=2>
&nbsp;&nbsp;<input type="checkbox" name="send" value="yes">
<b><i>Send as CSV file</i></b>
</td>
</tr>
*/?>
<tr><td>&nbsp;</td></tr>
<tr>
<td class=standard colspan=2>
&nbsp;&nbsp;<b><label><input type="checkbox" name="opennew" value="yes" onClick="ChngTarg(this.checked)">
Open Report in New Window</label></b>
</td>
</tr>
</table>
<br><br>
<input type="submit" value="Generate Report" name="action" onclick="check_content(); return tws_validate_form();">
</form>
</body>
</html>
