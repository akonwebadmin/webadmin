<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Cancel Jobstream</title>
<? tws_stylesheet(); ?>
<script type="text/javascript">
   function show_pri(){
      if( $('#safe_mode').is(':checked') )
         $('#restore_pri').attr('disabled', false);
      else $('#restore_pri').attr('disabled', true);
   }
</script>
</head>
<body>
<?php tws_set_window_title(); ?>

<h1>Cancel Jobstream</h1>
<br><br>
<h3>Selected Objects:</h3>

<?php
   if (!tws_permit_action('plan_jobstreams','Cancel')) {
      tws_access_denied ();
   }
   $num_elements=count($selection);
   if ($num_elements == 0) {
      echo "<p class=warning>&nbsp;&nbsp;&nbsp;&nbsp;No objects selected</p>\n";
   } else {
      TWS_DISP_PLANJST_SEL($selection);

      echo "<br>\n";

      echo "<form method=post action=\"tws_cancel_schedule_exec.php\">\n";
      if ($num_elements >= 1) {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type='checkbox' name='safe_mode' id='safe_mode' value='yes' checked='checked' onclick='show_pri();'>&nbsp;Safe Mode</label>\n";
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type='checkbox' name='restore_pri' id='restore_pri' value='yes' checked='checked' >&nbsp;Restore priority to default</label>\n";
         echo "<br><br>\n";
      }
      for ($idx=0; $idx<$num_elements; ++$idx) {
         echo "<input type='hidden' name='selection[]' value='".htmlspecialchars($selection[$idx])."'>\n";
      }
      echo "<input type='hidden' name='arg' value='".htmlspecialchars($arg)."'>\n";
      echo "&nbsp;&nbsp;<input type='submit' value='Cancel Jobstream'>&nbsp;&nbsp;\n";
      echo '<INPUT TYPE="button" VALUE="Cancel" onClick="closeme(\''.tws_profile('last_opener').'\');">';
      tws_print_synchro_token();  // synchro token
      echo "</form>\n";
   }
?>
</body>
</html>
