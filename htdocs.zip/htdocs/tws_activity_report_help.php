<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');
?>
<html>
<head>
   <title>IWS Activity Report Help</title>
   <?php tws_stylesheet(); ?>
</head>
<body class=help>
<?php
   tws_set_window_title();
   include 'tws_help_topbar.php';
?>
<h1 class=help>IWS Activity Report Help</h1>
<p>The IWS Activity Report displays a graph showing the number of jobs that executed over a selected time period.
<h2 class=help>Appearance</h2>
<p><strong>Scale</strong> : Select the time scale for the graph:
<ul>
  <li><strong>Day</strong></li>
  <li><strong>Week</strong></li>
  <li><strong>Month</strong></li>
  <li><strong>Year</strong></li>
</ul>
<p><strong>Style</strong> : Select the visual style of the graph:
<ul>
  <li><strong>Bar Graph</strong> : single bar for each period showing total number of jobs</li>
  <li><strong>Multiple Bar Graph (with Status)</strong> : multiple bars for each period, one for each job status type</li>
  <li><strong>Accumulated Bar Graph</strong> : single bar for each period, with sections for each job status type</li>
  <li><strong>Line Graph</strong> : single line showing total number of jobs</li>
  <li><strong>Multiple Line Graph</strong> : multiple lines, one for each job status type</li>
  <li><strong>Accumulated Line Graph</strong> : filled line graph with sections for each job status type</li>
</ul>
<p><strong>Color</strong> : Select the color of the activity graph:
<ul>
  <li><strong>Black</strong></li>
  <li><strong>Red</strong></li>
  <li><strong>Orange</strong></li>
  <li><strong>Yellow</strong></li>
  <li><strong>Green</strong></li>
  <li><strong>Blue</strong></li>
  <li><strong>Purple</strong></li>
</ul>
<p><strong>Bar Graph Shadows</strong> : For bar graphs, select this option to display shadows behind the bars
<p><strong>Show Job Count Labels</strong> : Displays numerical job counts at each data point on the graph
<p><strong>Include Status Piechart</strong> : If selected, a status piechart is included in the report
<h2 class=help>Contents</h2>
<p>Select which jobs are included in the count:
<ul>
  <li><strong>Completed Jobs</strong> : Only completed jobs are included (Succ, Abend, Pend status)</li>
  <li><strong>Active and Completed Jobs</strong> : Active and completed jobs are included (Succ, Abend, Pend, Exec status)</li>
  <li><strong>All Jobs</strong> : All jobs are included (Succ, Abend, Pend, Exec, Hold, Ready)</li>
</ul>
<h2 class=help>Criteria</h2>
<p><strong>Workstation</strong> : Select one or more workstations, if desired. Only jobs from the selected workstation(s) will be counted. If left blank, all jobs on all workstations will be included. Click the <strong>List</strong> button to select workstations from a list - multiple workstations may be selected by holding the Ctrl key while selecting.
<h2 class=help>Options</h2>
<p><strong>Count Reruns</strong> : If selected, rerun job iterations will be counted.  If not selected, only the first iteration will be counted.
<p><strong>Count Each Iteration of Every Jobs</strong> : If selected, all iterations of jobs with the EVERY option will be counted.  If not selected, only the first iteration will be counted.
<p>Click the <strong>Generate Report</strong> button to generate the report.
</body>
</html>
