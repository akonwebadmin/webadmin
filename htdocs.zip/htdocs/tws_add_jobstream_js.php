<?php
//   HORIZONT Software GmbH, Munich
//
?>
<script type="text/javascript">

// From Calendar

// global variables for dateWindow and date_picker
var today = new Date();
var day   = today.getDate();
var month = today.getMonth();
var year  = y2k(today.getYear());
var element_name;
var month_obj;
var day_obj;
var year_obj;
var showselected = 'orange';
var showtoday = '#e0e0e0';


// From JOBS

if ((screen.width) && (screen.height)) {
  screenwidth=screen.width;
  screenheight=screen.height;
} else {
  screenwidth=800;
  screenheight=600;
}
var addjobwidth=560;
var addjobheight=480;
var newjobwidth=640;
var newjobheight=480;
var modjobwidth=640;
var modjobheight=480;
var disjobwidth=640;
var disjobheight=480;
if ((screenwidth >= 800) && (screenheight >= 600)) {
  addjobwidth=560;
  addjobheight=480;
  newjobwidth=800;
  newjobheight=600;
  modjobwidth=800;
  modjobheight=600;
  disjobwidth=800;
  disjobheight=600;
  if ((screenwidth >= 1024) && (screenheight >= 768)) {
    addjobwidth=560;
    addjobheight=480;
    newjobwidth=880;
    newjobheight=650;
    modjobwidth=1024;
    modjobheight=768;
    disjobwidth=800;
    disjobheight=600;
  }
}

// From General

function ConfirmCancel(objectname,url){
   $('form').unbind('submit');
   var conftext=confirm("Exit " + objectname + " Definition (Changes will be lost) ?");
   if (conftext) {
      if (url==null) return true;
         closeme(url);
   } else {
      return false;
   }
}

function setPrio(val){
   document.contents.priority.value=val;
}

function showMatch(selection) {
   if(selection=='RELATIVE') {
      $('div#relative').css('display','block');
      $('div#absolute').css('display','none');
   }
   else if (selection=='ABSOLUTE') {
      $('div#relative').css('display','none');
      $('div#absolute').css('display','block');
   }
   else {
      $('div#relative').css('display','none');
      $('div#absolute').css('display','none');
   }
}

// Dependensies Matches
function showFollowsJsMatch(selection, index) {
   if(selection=='RELATIVE') {
      $("div#followsJsMatchRelative"+index).css('display','block');
      $('div#followsJsMatchAbsolute'+index).css('display','none');
   }
   else if (selection=='ABSOLUTE') {
      $('div#followsJsMatchRelative'+index).css('display','none');
      $('div#followsJsMatchAbsolute'+index).css('display','block');
   }
   else {
      $('div#followsJsMatchRelative'+index).css('display','none');
      $('div#followsJsMatchAbsolute'+index).css('display','none');
   }
}

function showFollowsJobMatch(selection, index) {
   if(selection=='RELATIVE') {
      $("div#followsJobMatchRelative"+index).css('display','block');
      $('div#followsJobMatchAbsolute'+index).css('display','none');
   }
   else if (selection=='ABSOLUTE') {
      $('div#followsJobMatchRelative'+index).css('display','none');
      $('div#followsJobMatchAbsolute'+index).css('display','block');
   }
   else {
      $('div#followsJobMatchRelative'+index).css('display','none');
      $('div#followsJobMatchAbsolute'+index).css('display','none');
   }
}


// From Calendar

function set_byday_options(formsel,index){
  if ($(formsel,'option:selected :first').val()=='YEARLY') {
    $(formsel).siblings('span.rc_bydays_group:first').hide();
  }
  else {
    $(formsel).siblings('span.rc_bydays_group:first').show();
  }
  enable_freedays_rules();
}

function on_except_diffs(select, index){
// Differences between on/except:
// UNTIL, DEADLINE, VARTABLE - only for ON

// UNTIL items
   var u1=document.getElementsByName('rc_untilhour['+ (index) +']');
   var u2=document.getElementsByName('rc_untilminute['+ (index) +']');
   var u3=document.getElementsByName('rc_untilplusdays['+ (index) +']');
   var ua=document.getElementsByName('rc_onuntil['+ (index) +']');
// DEADLINE items
   var d1=document.getElementsByName('rc_deadlinehour['+ (index) +']');
   var d2=document.getElementsByName('rc_deadlineminute['+ (index) +']');
   var d3=document.getElementsByName('rc_deadlineplusdays['+ (index) +']');
// VARTABLE items
   var vt_input=document.getElementsByName('rc_parameter_table['+index+']');
   var vt_picker=document.getElementsByName('parameter_table_picker['+index+']');

   if (select.selectedIndex==1) {   //For radio buttons look would be: if (select.value=='EXCEPT') ...
      u1[0].disabled=1;
      u2[0].disabled=1;
      u3[0].disabled=1;
      ua[0].disabled=1;
      d1[0].disabled=1;
      d2[0].disabled=1;
      d3[0].disabled=1;
      $('tr.on'+index+' input').prop('disabled', true);
      if (vt_input) { //only for IWS 8.5
         vt_input[0].disabled=1;
         vt_picker[0].disabled=1;
      }
   }
   else {
      u1[0].disabled=0;
      u2[0].disabled=0;
      u3[0].disabled=0;
      ua[0].disabled=0;
      d1[0].disabled=0;
      d2[0].disabled=0;
      d3[0].disabled=0;
      if (vt_input) { //only for IWS 8.5
         vt_input[0].disabled=0;
         vt_picker[0].disabled=0;
      }
      $('tr.on'+index+' input').prop('disabled', false);
   }
}

function rc_at_time_type(check,index){
    $('[id="rc_times['+index+']"] tr:first td:first').html(check.checked ? 'At:' : 'Schedtime:');
}

function rcg_at_time_type(check){
    $('[id="rcg_times"] tr:first td:first').html(check.checked ? 'At:' : 'Schedtime:');
}


function spec_fields(rc_type_select, index)
{
   var r_spec=document.getElementById('r_spec['+index+']');
   var s_spec=document.getElementById('s_spec['+index+']');
   var c_spec=document.getElementById('c_spec['+index+']');
   var rcg_spec = document.getElementById('rcg_spec['+index+']');
   if (rc_type_select.selectedIndex==0){  // Run Cycle
      r_spec.style.display='';
      s_spec.style.display='none';
      c_spec.style.display='none';
      rcg_spec.style.display='none';
   } else if (rc_type_select.selectedIndex==1){ // Calendar
      r_spec.style.display='none';
      s_spec.style.display='none';
      c_spec.style.display='';
      rcg_spec.style.display='none';
   }
   else if (rc_type_select.selectedIndex==2){ // Single Dates
      r_spec.style.display='none';
      s_spec.style.display='';
      c_spec.style.display='none';
      rcg_spec.style.display='none';
   }
   else{    // RC Group
      r_spec.style.display='none';
      s_spec.style.display='none';
      c_spec.style.display='none';
      rcg_spec.style.display='';
   }
}


function addcalendarrow(tableID)
{
 var table=document.getElementById(tableID);
 var index=table.rows.length;
 var newrow=table.insertRow(index);

 var calendar=newrow.insertCell(0);
 calendar.innerHTML='<input type="button" name="delete" value=" - " onClick="deletecalendarrow(\'calendar\',\''+ (index + 1) + '\');">&nbsp;(' + (index + 1) + ')&nbsp;';
 calendar.className='standard';
 calendar.align='right';
 calendar.width=140;

 calendardata1=newrow.insertCell(1);
 html='<select name="calendar_on_except['+ (index + 1) + ']"><option value="ON">On<option value="EXCEPT">Except</select> ';
 html+='<input type="text" name="calendar['+ (index + 1) + ']"  class="tws_name" size=16 maxlength=16> ';
 html+='<input type="button" name="calendar_list" value="List" onClick="tws_picker_open(\'calendar_picker.php\', \'includestock=no&amp;fieldname=calendar['+(index+1)+']&amp;fieldvalue=\' + document.contents.elements[\'calendar['+(index+1)+']\'].value);" />';
 html+=' &nbsp;&nbsp;&nbsp;&nbsp;<b>Offset:</b> <select name="calendar_offset_dir[' + (index + 1) + ']">';
 html+='<option value="+">+</option><option value="-">-</option></select> ';
 html+='&nbsp;<input type="text" name="calendar_offset[' + (index + 1) + ']" class="tws_num" size=5 maxlength=5>&nbsp; ';
 html+='<select name="calendar_offset_unit[' + (index + 1) + ']"> <option value="DAYS">Days</option>';
 html+='<option value="WEEKDAYS">Weekdays</option><option value="WORKDAYS">Workdays</option></select>';
 calendardata1.innerHTML=html;
 calendardata1.className='standard';
 calendardata1.noWrap='nowrap';
}

function deletecalendarrow(tableID,rowID)
{
 table=document.getElementById(tableID);
 var index=table.rows.length;
 if (index > 0) {
   if (index < 2) {
     for (i=1; i<100; i++) {
       if (document.contents.elements['calendar[' + i + ']']) {
         document.contents.elements['calendar[' + i + ']'].value='';
         document.contents.elements['calendar_on_except[' + i + ']'].options[0].selected='true';
         document.contents.elements['calendar_offset_dir[' + i + ']'].options[0].selected='true';
         document.contents.elements['calendar_offset[' + i + ']'].value='';
         document.contents.elements['calendar_offset_unit[' + i + ']'].options[0].selected='true';
       }
     }
   } else {
     var rownum = rowID - 1;
     if ((rownum >= 0) && (rownum < 1000)) {
       table.deleteRow(rownum);
     }
     for (i=rownum; i<(index - 1); i++) {
       row=table.rows[i];
       row.cells[0].innerHTML='<input type="button" name="delete" value=" - " onClick="deletecalendarrow(\'calendar\',\''+ (i + 1) + '\');">&nbsp;(' + (i + 1) + ')&nbsp;';
     }
   }
 }
}

function adddaterow(rcID)
{
 var tableID='date' + rcID;
 var table=document.getElementById(tableID);
 var index=table.rows.length;
 var newrow=table.insertRow(index);

 var date=newrow.insertCell(0);
 date.innerHTML='<input type="button" name="delete" value=" - " onClick="deletedaterow(\''+ rcID +'\',\''+ (index + 1) + '\');">&nbsp;(' + (index + 1) + ')&nbsp;';
 date.className='standard';
 date.align='left';

 datedata1=newrow.insertCell(1);
 html='';

<?
   $format_help=tws_user_date_format('');
?>
   html+='<input type="text" id="date_day['+rcID+']['+(index)+']" maxlength="40" size="25" name="date_day['+rcID+']['+(index)+']" class="tws_date" />';
   html+='<a name="date_day['+rcID+']['+(index)+']" class="picker" href="javascript:NewCssCal(\'date_day['+rcID+']['+(index)+']\', \'<?=$format_help?>\', \'dropdown\',false,\'24\',true,false,false);">';
   html+='<img name="date_day['+rcID+']['+(index)+']" id="date_day_img['+rcID+']['+(index)+']" src="images/cal.gif" width="16" height="16" alt="Pick a date"  title="Date & Time picker [<?=$format_help?>]"/></a>';

 datedata1.innerHTML=html;

 datedata1.className='standard';
 datedata1.noWrap='nowrap';
}

function deletedaterow(rcID,rowID)
{
 var tableID='date' + rcID;
 var table=document.getElementById(tableID);
 var index=table.rows.length;
 if (index > 0) {
   if (index < 2) {
     for (i=1; i<100; i++) {
       if (document.contents.elements['date[' + i + ']']) {
         document.contents.elements['date[' + i + ']'].value='';
         document.contents.elements['date_on_except[' + i + ']'].options[0].selected='true';
       }
     }
   } else {
     var rownum = rowID - 1;
     if ((rownum >= 0) && (rownum < 1000)) {
       table.deleteRow(rownum);
     }
     for (i=rownum; i<(index - 1); i++) {
       row=table.rows[i];
       row.cells[0].innerHTML='<input type="button" name="delete" value=" - " onClick="deletedaterow(\''+ rcID +'\',\''+ (i + 1) + '\');">&nbsp;(' + (i + 1) + ')&nbsp;';
     }
   }
 }
}

function check_rc_names(tableID) {
   var table=document.getElementById(tableID);
   var row_num=table.rows.length;
   var elem;
   var wrong=new Array();
   var i=0;
   while (row_num>0) {
      elem=document.getElementsByName('rc_name['+i+']');
      if (elem.length>0) {
         if (!elem[0].value.match(/^ *[a-zA-Z_-]{1}[a-zA-Z0-9-_]* *$/)) wrong.push(i+1);
         row_num--;
      }
      i++;
   }
   if (wrong.length==0) return true;
   else if (wrong.length==1) {
      alert ('Missing or incorrect rule name in run date rule ' + wrong[0] + '.');
   } else {
      alert ('Missing or incorrect rule names in run date rules ' + wrong.toString() + '.');
   }
   return false;
}

function addruncyclerow(tableID){
 var table=document.getElementById(tableID);
 var index=table.rows.length;
 var newrow=table.insertRow(index);
 newrow.id='rdr'+index;
 newrow.className=(index % 2) ? 'standard even' : 'standard odd';

 var rc=newrow.insertCell(0);
 rc.innerHTML='<input type="button" name="delete" value=" - " onClick="deleteruncyclerow(\''+ tableID +'\',\''+ index + '\');">&nbsp;(' + (index+1) + ')&nbsp;';
 rc.className='standard';
 rc.align='right';
 rc.vAlign='top';
 rc.width='100';

 rcdata1=newrow.insertCell(1);
 html='<table border=0 cellspacing=0 style="border:0px none; border-collapse:collapse; background-color:transparent">';
 html+='<tr><td class=standard>Type:</td><td class=standard>\n';
   html+='<select name="rc_on_except['+ index +']" onChange="on_except_diffs(this,'+ index +')"><option value="ON">On</option><option value="EXCEPT">Except</option></select>\n';
   html+='<select name="rc_type['+index+']" onChange="spec_fields(this,'+ index +')"><option value="R">Run Cycle</option><option value="C">Calendar</option><option value="S">Single Date(s)</option>';
   <? if( $tws_config['cpuinfo']['version']>='9.1' && empty($add_runcycle)){ // Jobstream ?>
      html+='<option value="G">Run Cycle Group</option>';
   <? } ?>
   html+='</select></td></tr>\n';
 html+='<tr><td class=standard>Rule name *:</td><td class=standard><input type="text" name="rc_name['+ index +']" class="tws_name" size=16 maxlength=40" value="Rule'+(index+1)+'"></td></tr>\n';
 html+='<tr><td class=standard>Description:</td><td class=standard><input type="text" name="rc_description['+ index +']" class="tws_alfanum" size=70 maxlength=120></td></tr>\n';
 <? if( $tws_config['cpuinfo']['version']>='9.1' && !empty($add_runcycle)){ // RCG ?>
      if(index == 0) subset = 'SUBSET_1';
      else subset = $('input[name="rc_subset['+(index-1)+']"]').val();
      html+='<tr><td>Subset:</td><td><input type="text" name="rc_subset['+index+']" class="tws_name" size=16 maxlength=40 value="'+subset+'">&nbsp;&nbsp;';
      html+='<select name="rc_and['+index+']"><option value="-" selected>OR</option>';
      html+='<option value="A">AND</option></select></td></tr>';
  <? } ?>
 <? if ($tws_config['cpuinfo']['version']>=8.5) : ?>
 html+='<tr><td class=standard>Parameter Table:</td><td class=standard><input type="text" name="rc_parameter_table['+index+']" class="tws_name" size=20 maxlength="<?=$tws_config['VARTABLE_MAXLENGTH']?>">&nbsp;';
 html+='<input type="button" name="parameter_table_picker['+index+']" onClick="tws_picker_open(\'parameter_table_picker.php\', \'fieldname=rc_parameter_table['+index+']&amp;fieldvalue=\' + document.contents.elements[\'rc_parameter_table['+index+']\'].value);" value="List"></td></tr>\n';
 <? endif; ?>
<? if ($tws_config['cpuinfo']['version']>=9.1 && empty($add_runcycle)){  // Jobstream ?>
   html+='<tr id="rcg_spec['+index+']" style="display:none"> <td>Run Cycle Group:</td>';
   html+='<td class="standard"> <input type="text" name="rcg['+index+']" class="tws_name">';
   html+='<input type="button" class ="list" name="runcycle_list" value="List" onClick="tws_picker_open(\'runcycle_picker.php\', \'fieldname=rcg['+index+']&amp;fieldvalue=\'+document.contents.elements[\'rcg['+index+']\'].value);">\n';
   html+='<input type="button" class ="list" name="runcycle_view" value="View" onClick="display_rcg(\'rcg['+index+']\');"> ';
   html+='&nbsp;&nbsp;Offset:&nbsp;<input type="text" name="rcg_offsetvalue['+ index +']" class="tws_num" size="4" maxlength="4" value="">\n';
   html+='<select name="rcg_offsettype['+ index +']"><? foreach (array_unique($tws_types['CAL_OFFSET_TYPE']) as $val) echo "<option value=\"$val\">$val</option>"; ?></select></td></tr>\n';
<? } ?>
 html+='<!-- Run Cycle -->\n';
 html+='<tr id="r_spec['+ index +']"><td class=standard class=standard>Frequency *:</td><td class=standard><select name="rc_freq['+ index +']" onChange="set_byday_options(this,'+ index +');">';
   html+='<option value="" selected></option>';
   html+='<option value="DAILY">Daily</option><option value="WEEKLY">Weekly</option><option value="MONTHLY">Monthly (m)</option>';
   html+='<option value="MONTHLY2">Monthly (w)</option>\n';
   html+='<option value="YEARLY">Yearly</option></select>&nbsp;Interval:&nbsp;<input type="text" name="rc_interval['+ index +']" class="tws_num" size=3>';
   html+='<span class="rc_bydays_group">&nbsp;Days:&nbsp;<input type="text" name="rc_bydays['+index+']" class="tws_alfanum_class" size=15>';
   html+='&nbsp;<input type="button" name="rc_bydays_pick" value="List" onClick="tws_picker_open(\'byday_picker.php\', \'fieldname=rc_bydays['+index+']&amp;fieldvalue=\' + document.contents.elements[\'rc_bydays['+index+']\'].value + \'&amp;freq=\' + document.contents.elements[\'rc_freq['+index+']\'].value);" /></span></td></tr>\n';

 html+='<!-- Calendar -->\n';
 html+='<tr id="c_spec['+ index +']" style="display:none"><td class=standard>Calendar&nbsp;name:</td><td class=standard>\n';
   html+='<input type="text" name="calendar['+ index +']" class="tws_name" size=16 maxlength=16 value="">';
   html+='<input type="button" name="calendar_list" value="List" onClick="tws_picker_open(\'calendar_picker.php\', \'includestock=no&amp;fieldname=calendar['+index+']&amp;fieldvalue=\' + document.contents.elements[\'calendar['+index+']\'].value);" />\n';
   html+='&nbsp;&nbsp;Offset:&nbsp;<input type="text" name="offsetvalue['+ index +']" class="tws_num" size="4" maxlength="4" value="">\n';
   html+='<select name="offsettype['+ index +']"><? foreach (array_unique($tws_types['CAL_OFFSET_TYPE']) as $val){ if(empty($val)) continue; echo "<option value=\"$val\">$val</option>"; }?></select></td></tr>\n';

 html+='<!-- Single Dates -->\n';
 html+='<tr id="s_spec['+ index +']" style="display:none"><td class="standard" valign="top">Single&nbsp;Date(s):</td>';
 html+='<td class="standard" align="left"><input type="button" name="add" value=" + " onClick="adddaterow(\''+index+'\');"><br>\n';
 html+='<table id="date'+ index +'" border=0 cellpadding=0 cellspacing=0 style="background:transparent">\n';
 html+='<tr><td class="standard" align="left"><input type="button" name="delete" value=" - " onClick="deletedaterow(\''+ index +'\',\'1\');">&nbsp;(1)&nbsp;</td>';
 html+='<td class="standard" nowrap>\n';
   html+='<input type="text" id="date_day['+index+'][0]" maxlength="40" size="25" name="date_day['+index+'][0]" class="tws_date" />';
   html+='<a name="date_day['+index+'][0]" class="picker" href="javascript:NewCssCal(\'date_day['+index+'][0]\', \'<?=$format_help?>\', \'dropdown\',false,\'24\',true,false,false);">';
   html+='<img name="date_day['+index+'][0]" id="date_day_img['+index+'][0]" src="images/cal.gif" width="16" height="16" alt="Pick a date"  title="Date & Time picker [<?=$format_help?>]"/></a>';
  html+='</td></tr></table>\n';
  html+='</td></tr>\n';

 html+='<tr><td class=standard class=standard>Freedays rule:</td><td class=standard><label><input type="radio" name="rc_freedaysrule['+ index +']" value="" checked>&nbsp;Ignore</label>&nbsp;&nbsp;&nbsp;';
 html+='<label><input type="radio" name="rc_freedaysrule['+ index +']" value="fdignore">&nbsp;Don\'t run</label>&nbsp;&nbsp;&nbsp;';
   html+='<label><input type="radio" name="rc_freedaysrule['+ index +']" value="fdprev">&nbsp;Run previous day</label>&nbsp;&nbsp;&nbsp;';
   html+='<label><input type="radio" name="rc_freedaysrule['+ index +']" value="fdnext">&nbsp;Run next day</label>&nbsp;&nbsp;&nbsp;</td></tr>';
<?
  $df = tws_profile("date_format");
  $vf = date($df);
?>
 html+='<tr><td class=standard>Valid from:</td><td class=standard>';
   html+='<input type="text" id="rc_validfrom['+index+']" value = "<?=$vf?>" maxlength="40" size="25" name="rc_validfrom['+index+']" class="tws_date"/>';
   html+='<a name="rc_validfrom['+index+']" class="picker" href="javascript:NewCssCal(\'rc_validfrom['+index+']\', \'<?=$format_help?>\', \'dropdown\',false,\'24\',true,false,false);">';
   html+='<img name="rc_validfrom['+index+']" id="rc_validfrom_img['+index+']" src="images/cal.gif" width="16" height="16" alt="Pick a date"  title="Date & Time picker [<?=$format_help?>]"/></a>&nbsp;&nbsp;';
 html+=' Valid to: ';
   html+='<input type="text" id="rc_validto['+index+']" maxlength="40" size="25" name="rc_validto['+index+']" class="tws_date"/>';
   html+='<a name="rc_validto['+index+']" class="picker" href="javascript:NewCssCal(\'rc_validto['+index+']\', \'<?=$format_help?>\', \'dropdown\',false,\'24\',true,false,false);">';
   html+='<img name="rc_validto['+index+']" id="rc_validto_img['+index+']" src="images/cal.gif" width="16" height="16" alt="Pick a date" title="Date & Time picker [<?=$format_help?>]"/></a>';
 html+='</td></tr>\n';
 html+='</table>\n';

 html+='<table id=rc_times['+ index +'] style="border:0px none; border-collapse:collapse; margin-bottom:20px; background-color:#e9e9e9">\n';
 html+='<tr><td class=standard style="width:10em;">At:</td><td class=standard><input type="text" name="rc_athour['+ index +']" class="tws_hour" size=2 maxlength=2>&nbsp;:&nbsp;';

   html+='<input type="text" name="rc_atminute['+ index +']" class="tws_minute" size=2 maxlength=2>&nbsp;+&nbsp;';
   html+='<input type="text" name="rc_atplusdays['+ index +']" class="tws_num" size=2 maxlength=2>&nbsp;days <label style="margin-left:20px"><input type="checkbox" name="rc_time_dep['+ index +']" value="YES" checked onClick="rc_at_time_type(this,'+ index +');">&nbsp;Use as time dependency</label></td></tr>\n';
<? if ($tws_config['cpuinfo']['version']>=9.3){ ?>
   html+="<tr class='on"+index+"'><td class='standard'>Every:</td> \
      <td class='standard'><input type='text' name='rc_everyhour["+index+"]' class='tws_hour' size=2 maxlength=2>&nbsp;: \
      <input type='text' name='rc_everyminute["+index+"]' class='tws_minute every_req"+index+"' size=2 maxlength=2>&nbsp;&nbsp; \
      End Time: <input type='text' name='rc_everyendhour["+index+"]' class='tws_hour every_req"+index+"' size=2 maxlength=2>&nbsp;: \
               <input type='text' name='rc_everyendminute["+index+"]' class='tws_minute every_req"+index+"' size=2 maxlength=2>&nbsp;+ \
               <input type='text' name='rc_everyendplusdays["+index+"]' class='tws_num' size=2 maxlength=2>&nbsp;days \
      </td></tr>";
<? } ?>
 html+='<tr><td class=standard>Until:</td><td class=standard><input type="text" name="rc_untilhour['+ index +']" class="tws_hour" size=2 maxlength=2>&nbsp;:&nbsp;';
   html+='<input type="text" name="rc_untilminute['+ index +']" class="tws_minute" size=2 maxlength=2>&nbsp;+&nbsp;';
   html+='<input type="text" name="rc_untilplusdays['+ index +']" class="tws_num" size=2 maxlength=2>&nbsp;days <span style="margin:20px">Until action:</span><select name="rc_onuntil['+ index +']">';
   html+='<option value="suppr">Suppress</option>\n';
   html+='<option value="CONT">Continue</option>\n';
   html+='<option value="CANC">Cancel</option>\n';
   html+='</select>\n';
<? if ($tws_config['cpuinfo']['version']>9.4){ ?>
   html+='<label style="margin-left:20px"><input type="checkbox" name="rc_jsuntil['+index+']" value="Y" checked>&nbsp;Apply to each job</label>';
<? } ?>
   html+='</td></tr>\n';
 html+='<tr><td class=standard>Deadline:</td><td class=standard><input type="text" name="rc_deadlinehour['+ index +']" class="tws_hour" size=2 maxlength=2>&nbsp;:&nbsp;';
   html+='<input type="text" name="rc_deadlineminute['+ index +']" class="tws_minute" size=2 maxlength=2>&nbsp;+&nbsp;';
   html+='<input type="text" name="rc_deadlineplusdays['+ index +']" class="tws_num" size=2 maxlength=2>days</td></tr>\n';
 html+='</table>\n';

 rcdata1.innerHTML=html;
 rcdata1.className='standard';
 rcdata1.noWrap='nowrap';
}

function deleteruncyclerow(tableID,rowID)
{
 table=document.getElementById(tableID);
 var index=table.rows.length;
//set keep_one to true if one rule row should always stay present...
 var keep_one=false;

 if (index > 0) {
   if (keep_one && index < 2) {

     //TODO: last rule: delete all rule values and put it into the default status
     for (i=1; i<100; i++) {
       if (document.contents.elements['runcycle[' + i + ']']) {
         document.contents.elements['runcycle[' + i + ']'].value='';
         document.contents.elements['date_on_except[' + i + ']'].options[0].selected='true';
       }
     }
   } else {
     var rownum = parseInt(rowID);
     if ((rownum >= 0) && (rownum < 1000)) {
       table.deleteRow(rownum);
     }
     for (i=rownum; i<(index - 1); i++) {
       row=table.rows[i];
       row.cells[0].innerHTML='<input type="button" name="delete" value=" - " onClick="deleteruncyclerow(\'rdrs\','+ i + ');">&nbsp;(' + (i+1) + ')&nbsp;';
     }
   }
 }
}

function y2k(number)
{
 return (number < 1000) ? number + 1900 : number;
}


function padout(number) {
 return (number < 10) ? '0' + number : number;
}

// From Dependenciess

function addfollowsjobstreamrow(tableID) {
 table=document.getElementById(tableID);
 rowcount=table.rows.length;
 index=rowcount/4;
 newrow=table.insertRow(rowcount);

 workstation=newrow.insertCell(0);
 workstation.innerHTML='(' + (index + 1) + ') - Workstation:&nbsp;<input type="text" name="followsjobstreamcpu[' + (index + 1) + ']" class="tws_name" style="width:20em;" >';
 workstation.innerHTML+='&nbsp;<input type="button" name="workstation_list" onClick="tws_picker_open(\'workstation_picker.php\', \'includeclasses=yes&amp;fieldname=followsjobstreamcpu['+(index+1)+']&amp;fieldvalue=\' + document.contents.elements[\'followsjobstreamcpu['+(index+1)+']\'].value);" value="List">';
 workstation.className='standard';

 jobstream=newrow.insertCell(1);
 jobstream.innerHTML='Jobstream:&nbsp;<input type="text" name="followsjobstreamname[' + (index + 1) + ']" class="tws_name" style="width:20em;">';
 jobstream.innerHTML+='&nbsp;<input type="button" name="jobstream_list" onClick="tws_picker_open(\'jobstream_picker.php\', \'fieldname=followsjobstreamname['+(index+1)+']&amp;fieldvalue=\' + document.contents.elements[\'followsjobstreamname['+(index+1)+']\'].value + \'&amp;cpux=\' + document.contents.elements[\'followsjobstreamcpu['+(index+1)+']\'].value);" value="List">';
 jobstream.className='standard';

 str = '';
<? if($tws_config['cpuinfo']['version']>='9.3'){  ?>
   str = '<label><input type="checkbox" name="js_js_abend['+(index+1)+']" value="Y">On ABEND</label>&nbsp;';
   str +='<label><input type="checkbox" name="js_js_success['+(index+1)+']" value="Y">On SUCCESS</label>&nbsp;';
   str +='<label><input type="checkbox" name="js_js_suppress['+(index+1)+']" value="Y">On SUPPRESS</label>';
<? } ?>
 $('#'+tableID+' tr:last').after('<tr><td colspan=2 style="padding-left:20px;">'+str+'</td></tr>');

 newrow2 = table.insertRow(rowcount+2);
 depres = newrow2.insertCell(0);
 depres.className='standard';
html='&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dependency resolution: &nbsp;&nbsp;';
html+='        <select name="followsjobstreammatching['+(index+1)+']" onchange="showFollowsJsMatch(this.value, '+(index+1)+');">';
html+='            <option value="DEFAULT" selected>Default</option>';
html+='            <option value="SAMEDAY">Same day</option>';
html+='            <option value="PREVIOUS">Previous day</option>';
html+='            <option value="RELATIVE">Relative</option>';
html+='            <option value="ABSOLUTE">Absolute</option>';
html+='         </select>';

depres.innerHTML=html;

depres2 = newrow2.insertCell(1);
depres2.className='standard';

html='      <div id="followsJsMatchRelative'+(index+1)+'" style="display:none">';
html+='         from <select name="followsjobstreammatchingrelativefromdir['+(index+1)+']">';
html+='            <option value="+" selected>+</option>';
html+='            <option value="-">-</option>';
html+='         </select>';
html+='         <input type="text" name="followsjobstreammatchingrelativefromhour['+(index+1)+']" class="tws_hour" size=2 maxlength=2 />&nbsp;:';
html+='         <input type="text" name="followsjobstreammatchingrelativefromminute['+(index+1)+']" class="tws_minute" size=2 maxlength=2 />&nbsp;';
html+='         to <select name="followsjobstreammatchingrelativetodir['+(index+1)+']">';
html+='            <option value="+" selected>+</option>';
html+='            <option value="-">-</option>';
html+='         </select>';
html+='         <input type="text" name="followsjobstreammatchingrelativetohour['+(index+1)+']" class="tws_hour" size=2 maxlength=2 />&nbsp;:';
html+='         <input type="text" name="followsjobstreammatchingrelativetominute['+(index+1)+']" class="tws_minute" size=2 maxlength=2 />';
html+='      </div>';

html+='      <div id="followsJsMatchAbsolute'+(index+1)+'" style="display:none">';
html+='         from <input type="text" name="followsjobstreammatchingabsolutefromhour['+(index+1)+']" class="tws_hour" size=2 maxlength=2 />&nbsp;:';
html+='         <input type="text" name="followsjobstreammatchingabsolutefromminute['+(index+1)+']" class="tws_minute" size=2 maxlength=2 />';
html+='         <select name="followsjobstreammatchingabsolutefromdir['+(index+1)+']">';
html+='            <option value="+" selected>+</option>';
html+='            <option value="-">-</option>';
html+='         </select>';
html+='         <input type="text" name="followsjobstreammatchingabsolutefromdays['+(index+1)+']" class="tws_num" size=2 maxlength=5 />days&nbsp;&nbsp;';

html+='         to <input type="text" name="followsjobstreammatchingabsolutetohour['+(index+1)+']" class="tws_hour" size=2 maxlength=2 />&nbsp;:';
html+='         <input type="text" name="followsjobstreammatchingabsolutetominute['+(index+1)+']" class="tws_minute" size=2 maxlength=2 />';
html+='         <select name="followsjobstreammatchingabsolutetodir['+(index+1)+']">';
html+='            <option value="+" selected>+</option>';
html+='            <option value="-">-</option>';
html+='         </select>';
html+='         <input type="text" name="followsjobstreammatchingabsolutetodays['+(index+1)+']" class="tws_num" size=2 maxlength=5 />days';
html+='      </div>';

 depres2.innerHTML=html;

   html = '<tr><td></td></tr>';  // join row
   $('#'+tableID+' tr:last').after(html);
}

function addfollowsjobrow(tableID) {
 table=document.getElementById(tableID);
 rowcount=table.rows.length;
 index=rowcount/5;
// newrow=table.insertRow(rowcount);
// newcell=newrow.insertCell(0);

str = '<tr><td>('+(index+1)+') - Workstation:</td><td>Jobstream:</td><td>Job:</td></tr>\n';
str += '<tr><td><input type="text" name="followsjobcpu['+index+']" id="followsjobcpu'+index+'" class="tws_name" style="width:20em;">\n';
str += '<input type="button" name="workstation_list" value="List" onClick="tws_picker_open(\'workstation_picker.php\', \'includeclasses=yes&amp;fieldname=followsjobcpu['+index+']&amp;fieldvalue=\' + document.contents.elements[\'followsjobcpu['+index+']\'].value);"></td>\n';
str += '<td><input type="text" name="followsjobjobstream['+index+']" id="followsjobjobstream'+index+'" class="tws_name" style="width:20em;">\n';
str += '<input type="button" name="jobstream_list" value="List" onClick="tws_picker_open(\'jobstream_picker.php\', \'fieldname=followsjobjobstream['+index+']&amp;fieldvalue=\'+document.contents.elements[\'followsjobjobstream['+index+']\'].value + \'&amp;cpux=\' + document.contents.elements[\'followsjobcpu['+index+']\'].value);"></td>\n';
str += '<td><input type="text" name="followsjobname['+index+']" id="followsjobname'+index+'" style="width:15em;" maxlength=40 class="tws_name">\n';
str += '<input type="button" name="job_list" onClick="tws_picker_open(\'job_instance_picker.php\', \'jobfieldname=followsjobname['+index+']&amp;jsfieldname=followsjobjobstream['+index+']&amp;wksfieldname=followsjobcpu['+index+']&amp;fieldvalue=\' + document.contents.elements[\'followsjobname['+index+']\'].value + \'&amp;cpux=\' + document.contents.elements[\'followsjobcpu['+index+']\'].value + \'&amp;schedulex=\' + document.contents.elements[\'followsjobjobstream['+index+']\'].value);" value="List"></td>\n';
str += '</tr>\n';
//newcell.innerHTML = str;

 $('#'+tableID).append(str);

 str = '';
<? if($tws_config['cpuinfo']['version']>='9.3'){  ?>
   str = '<div id="js_job_execute'+index+'"><label><input type="checkbox" name="js_job_execute['+index+']" value="Y" onclick="js_job_oncondition('+index+')">On EXECUTE</label></div>';
   str += '<div id="js_job_state'+index+'"><label><input type="checkbox" name="js_job_abend['+index+']" value="Y" onclick="js_job_oncondition('+index+')">On ABEND</label>&nbsp;';
   str +='<label><input type="checkbox" name="js_job_fail['+index+']" value="Y" onclick="js_job_oncondition('+index+')">On FAIL</label>&nbsp;';
   str +='<label><input type="checkbox" name="js_job_success['+index+']" value="Y" onclick="js_job_oncondition('+index+')">On SUCCESS</label>&nbsp;';
   str +='<label><input type="checkbox" name="js_job_suppress['+index+']" value="Y" onclick="js_job_oncondition('+index+')">On SUPPRESS</label></div>';
   str +='<div id=js_job_condition'+index+'></div>';
<? } ?>
 $('#'+tableID+' tr:last').after('<tr><td colspan=3 style="padding-left:20px;">'+str+'</td></tr>');
<? if($tws_config['cpuinfo']['version']>='9.3'){  ?>
// bind onchange
   $('input#followsjobcpu'+index).on('keyup', {index: index}, tws_js_job_change);
   $('input#followsjobjobstream'+index).on('keyup', {index: index}, tws_js_job_change);
   $('input#followsjobname'+index).on('keyup', {index: index}, tws_js_job_change);
<? } ?>
// newrow2 = table.insertRow(rowcount+2);
// depres = newrow2.insertCell(0);
// depres.className='standard';

   html='<tr><td style="padding-left:20px;" colspan="3">\n';
   html+= '<div style="float:left; padding-right:20px;">Dependency resolution:';
   html+= '<select name="followsjobmatching['+index+']" onchange="showFollowsJobMatch(this.value, '+index+');">';
   html+= '    <option value="DEFAULT" selected>Default</option>';
   html+= '    <option value="SAMEDAY">Same day</option>';
   html+= '    <option value="PREVIOUS">Previous day</option>';
   html+= '    <option value="RELATIVE">Relative</option>';
   html+= '    <option value="ABSOLUTE">Absolute</option>';
   html+= '</select></div>';

   html+= '<div id="followsJobMatchRelative'+index+'" style="float:left;display:none;">';
   html+= '   from <select name="followsjobmatchingrelativefromdir['+index+']">';
   html+= '      <option value="+" selected>+</option>';
   html+= '      <option value="-">-</option>';
   html+= '   </select>';
   html+= '   <input type="text" name="followsjobmatchingrelativefromhour['+index+']" class="tws_hour" size=2 maxlength=2/>&nbsp;:';
   html+= '   <input type="text" name="followsjobmatchingrelativefromminute['+index+']" class="tws_minute" size=2 maxlength=2/>&nbsp;';
   html+= '   to <select name="followsjobmatchingrelativetodir['+index+']">';
   html+= '      <option value="+" selected>+</option>';
   html+= '      <option value="-">-</option>';
   html+= '   </select>';
   html+= '   <input type="text" name="followsjobmatchingrelativetohour['+index+']" class="tws_hour" size=2 maxlength=2 />&nbsp;:';
   html+= '   <input type="text" name="followsjobmatchingrelativetominute['+index+']"  class="tws_minute"size=2 maxlength=2 />';
   html+= '</div>';

   html+= '<div id="followsJobMatchAbsolute'+index+'" style="float:left;display:none;">';
   html+= '   from <input type="text" name="followsjobmatchingabsolutefromhour['+index+']" class="tws_hour" size=2 maxlength=2/>&nbsp;:';
   html+= '   <input type="text" name="followsjobmatchingabsolutefromminute['+index+']"  class="tws_minute"size=2 maxlength=2 />';
   html+= '   <select name="followsjobmatchingabsolutefromdir['+index+']">';
   html+= '      <option value="+" selected>+</option>';
   html+= '      <option value="-">-</option>';
   html+= '   </select>';
   html+= '   <input type="text" name="followsjobmatchingabsolutefromdays['+index+']" class="tws_num" size=2 maxlength=5/>days&nbsp;&nbsp;';

   html+= '   to <input type="text" name="followsjobmatchingabsolutetohour['+index+']" class="tws_hour" size=2 maxlength=2/>&nbsp;:';
   html+= '   <input type="text" name="followsjobmatchingabsolutetominute['+index+']" class="tws_minute" size=2 maxlength=2 />';
   html+= '   <select name="followsjobmatchingabsolutetodir['+index+']">';
   html+= '      <option value="+" selected>+</option>';
   html+= '      <option value="-">-</option>';
   html+= '   </select>';
   html+= '   <input type="text" name="followsjobmatchingabsolutetodays['+index+']" class="tws_num" size=2 maxlength=5 />days';
   html+= '</div></td></tr>';

   $('#'+tableID+' tr:last').after(html);
   html = '<tr><td></td></tr>';  // join row
   $('#'+tableID+' tr:last').after(html);
}

function tws_js_job_change(event){
   var index = event.data.index;

   // clear conditions
   $('div#js_job_condition'+index).html('');

   var ws = $('input#followsjobcpu'+index).val();
   var js = $('input#followsjobjobstream'+index).val();
   var job = $('input#followsjobname'+index).val();
   var validfrom = '';

   if($.trim(ws)=='' || $.trim(js)=='' || $.trim(job)=='')
      return "";
   $.ajax({
      type: 'GET',
      url: 'tws_job_codemap.php',
      dataType: 'json',
      cache: false,
      data: {'ws':ws, 'js':js, 'job':job, 'validfrom':validfrom},
      success: function(codemap) {
         for(i=0; i<$(codemap).size(); i++){
            val = codemap[i];
            $('div#js_job_condition'+index).append('<input type="hidden" name="js_job_codemaps['+index+']['+i+']" value="'+val+'">');
            $('div#js_job_condition'+index).append('<label><input type="checkbox" name="js_job_condition['+index+']['+i+']" value="'+val+'" id="'+val+index+'" onclick="js_job_oncondition('+index+')">'+val+'</label>');
         }
         js_job_oncondition(index);
      },
      error: function(response, error) {
         alert( "Error: (" + error + ")");
      }
   });

}

function js_job_oncondition(i){
      $('div#js_job_state'+i+' input').prop('disabled', false);
      $('div#js_job_execute'+i+' input').prop('disabled', false);
      $('div#js_job_condition'+i+' input').prop('disabled', false);

   if($('div#js_job_condition'+i+' input').is(':checked') ){
      $('div#js_job_state'+i+' input').prop('disabled', true);
      $('div#js_job_execute'+i+' input').prop('disabled', true);
   }

   if($('div#js_job_execute'+i+' input').is(':checked') ){
      $('div#js_job_state'+i+' input').prop('disabled', true);
      $('div#js_job_condition'+i+' input').prop('disabled', true);
   }

   if($('div#js_job_state'+i+' input').is(':checked') ){
      $('div#js_job_execute'+i+' input').prop('disabled', true);
      $('div#js_job_condition'+i+' input').prop('disabled', true);
   }
}

function addfollowsnetrow(tableID) {
 table=document.getElementById(tableID);
 index=table.rows.length;
 newrow=table.insertRow(index);

 networkagent=newrow.insertCell(0);
 networkagent.innerHTML='(' + (index + 1) + ') - Network Agent:&nbsp;<input type="text" name="followsnetworkagent[' + (index + 1) + ']" class="tws_name" style="width:15em;" maxlength="16">\n';
 networkagent.innerHTML+='<input type="button" name="workstation_list" onClick="tws_picker_open(\'workstation_picker.php\', \'includexagents=only&amp;fieldname=followsnetworkagent[' + (index + 1) + ']&amp;fieldvalue=\' + document.contents.elements[\'followsnetworkagent[' + (index + 1) + ']\'].value);" value="List">\n';
 networkagent.className='standard';

 dependency=newrow.insertCell(1);
 dependency.innerHTML='Dependency:&nbsp;<input type="text" name="followsnetworkdep[' + (index + 1) + ']" size=50 maxlength=74>\n';
 dependency.className='standard';
}

function addpromptrow(tableID) {
 table=document.getElementById(tableID);
 index=table.rows.length;
 newrow=table.insertRow(index);

 promptrow=newrow.insertCell(0);
 promptrow.innerHTML='(' + (index + 1) + ') - Prompt:&nbsp;<input type="text" name="promptname[' + (index + 1) + ']" class="tws_name" style="width:20em;" >\n';
 promptrow.innerHTML+='<input type="button" name="prompt_list" onClick="tws_picker_open(\'prompt_picker.php\', \'fieldname=promptname[' + (index + 1) + ']&amp;fieldvalue=\' + document.contents.elements[\'promptname[' + (index + 1) + ']\'].value);" value="List">\n';
 promptrow.className='standard';
}

function addlocalpromptrow(tableID) {
 table=document.getElementById(tableID);
 index=table.rows.length;
 newrow=table.insertRow(index);

 localpromptrow=newrow.insertCell(0);
 localpromptrow.innerHTML='(' + (index + 1) + ') - Prompt Text:&nbsp;<input type="text" name="prompttext[' + (index + 1) + ']" size=80 maxlength=200>\n';
 localpromptrow.className='standard';
}

function addopensrow(tableID) {
 table=document.getElementById(tableID);
 index=table.rows.length;
 newrow=table.insertRow(index);

 workstation=newrow.insertCell(0);
 workstation.innerHTML='(' + (index + 1) + ') - Workstation:&nbsp;<input type="text" name="openscpu[' + (index + 1) + ']" class="tws_name" style="width:20em;">\n';
 workstation.innerHTML+='<input type="button" name="workstation_list" onClick="tws_picker_open(\'workstation_picker.php\', \'fieldname=openscpu[' + (index + 1) + ']&amp;fieldvalue=\' + document.contents.elements[\'openscpu[' + (index + 1) + ']\'].value);" value="List">\n';
 workstation.className='standard';

 filename=newrow.insertCell(1);
 filename.innerHTML='Filename:&nbsp;<input type="text" name="opensfile[' + (index + 1) + ']" size=32 maxlength=148>\n';
 filename.className='standard';

 qualifier=newrow.insertCell(2);
 qualifier.innerHTML='Qualifier:&nbsp;<input type="text" name="opensqual[' + (index + 1) + ']" size=16 maxlength=128>\n';
 qualifier.className='standard';
}

function addresourcerow(tableID) {
 table=document.getElementById(tableID);
 index=table.rows.length;
 newrow=table.insertRow(index);

 workstation=newrow.insertCell(0);
 workstation.innerHTML='(' + (index + 1) + ') - Workstation:&nbsp;<input type="text" name="needscpu[' + (index + 1) + ']" class="tws_name" style="width:20em;" >\n';
 workstation.innerHTML+='<input type="button" name="workstation_list" onClick="tws_picker_open(\'workstation_picker.php\', \'fieldname=needscpu[' + (index + 1) + ']&amp;fieldvalue=\' + document.contents.elements[\'needscpu[' + (index + 1) + ']\'].value);" value="List">\n';
 workstation.className='standard';

 needsresource=newrow.insertCell(1);
 needsresource.innerHTML='Resource:&nbsp;<input type="text" name="resource[' + (index + 1) + ']" class="tws_name" style="width:15em;" >\n';
 needsresource.innerHTML+='<input type="button" name="resource_list" onClick="tws_picker_open(\'resource_picker.php\', \'fieldname=resource[' + (index + 1) + ']&amp;fieldvalue=\' + document.contents.elements[\'resource[' + (index + 1) + ']\'].value + \'&amp;cpux=\' + document.contents.elements[\'needscpu[' + (index + 1) + ']\'].value);" value="List">\n';
 needsresource.className='standard';

 needsunits=newrow.insertCell(2);
 needsunits.innerHTML='Units:&nbsp;<input type="text" name="units[' + (index + 1) + ']" class="tws_num" size=4 maxlength=4>\n';
 needsunits.className='standard';
}

// From JOBS

function movecolup(control)
{
 var sel=document.contents[control].selectedIndex;
 if (sel > 0 && document.contents[control].options[sel].value > "") {
   var temptext=document.contents[control].options[sel].text;
   var tempvalue=document.contents[control].options[sel].value;
   document.contents[control].options[sel].text=document.contents[control].options[sel-1].text;
   document.contents[control].options[sel].value=document.contents[control].options[sel-1].value;
   document.contents[control].options[sel-1].text=temptext;
   document.contents[control].options[sel-1].value=tempvalue;
   document.contents[control].selectedIndex--;
 }
}
function movecoldown(control)
{
 var sel=document.contents[control].selectedIndex;
 if (sel != -1 && sel < document.contents[control].length-1 && document.contents[control].options[sel].value > "") {
   var temptext=document.contents[control].options[sel].text;
   var tempvalue=document.contents[control].options[sel].value;
   document.contents[control].options[sel].text=document.contents[control].options[sel+1].text;
   document.contents[control].options[sel].value=document.contents[control].options[sel+1].value;
   document.contents[control].options[sel+1].text=temptext;
   document.contents[control].options[sel+1].value=tempvalue;
   document.contents[control].selectedIndex++;
 }
}
function selectJob(selectcontrol,textcontrol) {
 var sel=document.contents[selectcontrol].selectedIndex;
 if (sel != -1) {
   var temptext=document.contents[selectcontrol].options[sel].text;
   if (temptext > "") {
     document.contents[textcontrol].value=temptext;
    $('input[name="setdep"]').prop('disabled', false);
    $('input[name="jobinfo"]').prop('disabled', false);
    if(typeof display == 'undefined' || display == false)
      $('input[name="deletejob"]').prop('disabled', false);
   }
   // show job properties
   // showJobProperties(document.contents[selectcontrol].options[sel].value);
 }
}

function showJobProperties(jobname) {
   var prop = '';
   if($('input[name="jobathour['+jobname+']"]').size()>0) {
      prop += 'At ' + $('input[name="jobathour['+jobname+']"]').val() + ':' + $('input[name="jobatminute['+jobname+']"]').val();
      if ($('input[name="jobatplusdays['+jobname+']"]').size()>0)
         prop += ' + ' + $('input[name="jobatplusdays['+jobname+']"]').val() + ' days';
      prop += '<br>\n';
   }
   if($('input[name="jobuntilhour['+jobname+']"]').size()>0) {
      prop += 'Until ' + $('input[name="jobuntilhour['+jobname+']"]').val() + ':' + $('input[name="jobuntilminute['+jobname+']"]').val();
      if ($('input[name="jobuntilplusdays['+jobname+']"]').size()>0)
         prop += ' + ' + $('input[name="jobuntilplusdays['+jobname+']"]').val() + ' days';
      prop += '<br>\n';
   }
   if($('input[name="jobdeadlinehour['+jobname+']"]').size()>0) {
      prop += 'Deadline ' + $('input[name="jobdeadlinehour['+jobname+']"]').val() + ':' + $('input[name="jobdeadlineminute['+jobname+']"]').val();
      if ($('input[name="jobdeadlineplusdays['+jobname+']"]').size()>0)
         prop += ' + ' + $('input[name="jobdeadlineplusdays['+jobname+']"]').val() + ' days';
      prop += '<br>\n';
   }
   if($('input[name="jobeveryhour['+jobname+']"]').size()>0) {
      prop += 'Every ' + $('input[name="jobeveryhour['+jobname+']"]').val() + ':' + $('input[name="jobeveryminute['+jobname+']"]').val();
      prop += '<br>\n';
   }
   if($('input[name="jobpriority['+jobname+']"]').size()>0) {
      prop += 'Priority ' + $('input[name="jobpriority['+jobname+']"]').val();
      prop += '<br>\n';
   }
   if($('input[name="jobconfirmed['+jobname+']"]').size()>0 && $('input[name="jobconfirmed['+jobname+']"]').val() != 'NO' ) {
      prop += 'Confirmed<br>\n';
   }
   if($('input[name="jobkeyjob['+jobname+']"]').size()>0 && $('input[name="jobkeyjob['+jobname+']"]').val() != 'NO' ) {
      prop += 'Monitored<br>\n';
   }
   if($('input[name="jobcritical['+jobname+']"]').size()>0 && $('input[name="jobcritical['+jobname+']"]').val() != 'NO' ) {
      prop += 'Critical<br>\n';
   }

   $('td#jobproperties').html(prop);
}

function addJob(newtext,newvalue) {
 var fulljobname;
 var splitpos;
 var workstation;
 var jobname;
 var pos;

 var newsplitpos=newvalue.indexOf("#");
 if (newsplitpos == -1) {
   var newworkstation="";
   var newjobname=newvalue;
   pos = newjobname.lastIndexOf('/');     // if folders exists
   if(pos != -1)
      newjobname = newjobname.substr(pos+1);
 }
 else {
   var newworkstation=newvalue.substring(0,newsplitpos - 1);
   var newjobname=newvalue.substring(newsplitpos + 1);
   pos = newjobname.lastIndexOf('/');     // if folders exists
   if(pos != -1)
      newjobname = newjobname.substr(pos+1);
 }

 control=document.contents['jobs'];
 var destpos=control.length;
 for (i=0; i<destpos; i++) {
   fulljobname=control.options[i].value;
   splitpos=fulljobname.indexOf("#");
   if (splitpos == -1) {
     workstation="";
     jobname=fulljobname;
      pos = jobname.lastIndexOf('/');     // if folders exists
      if(pos != -1)
         jobname = jobname.substr(pos+1);
   }
   else {
     workstation=fulljobname.substring(0,splitpos - 1);
     jobname=fulljobname.substring(splitpos + 1);
      pos = jobname.lastIndexOf('/');     // if folders exists
      if(pos != -1)
         jobname = jobname.substr(pos+1);
   }

   if (jobname == newjobname) {
     alert("Job " + jobname + " already exists in this jobstream");
     return false;
   }
 }
 control.options[destpos]=new Option(newtext,newvalue);
}

function removeJob(control) {
   control=document.contents[control];
   for (i=0; i<control.length; i++) {
      if(control.options[i].selected){
         control.remove(i);
         i--;
      }
   }
   document.contents.showjob.value='';
/*
 var sel=document.contents[control].selectedIndex;
 if (sel != -1 && document.contents[control].options[sel].value > "") {
   document.contents[control].options[sel]=null;
   document.contents.showjob.value='';
 }*/
}
function modifyJob(control, action){
   var sel=document.contents[control].selectedIndex;
   if (sel == -1)
     alert("No Job Selected");
   else {
      if(action == 'display') arg = '&display=yes'
      else arg = '';
         var selval=document.contents[control].options[sel].value;
      window.open('tws_job_properties1.php?jobname='+escape(selval)+arg,'job_properties','width=' + modjobwidth + ',height=' + modjobheight + ',toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=yes');
   }
}
function displayJobDef(control)
{
 var sel=document.contents[control].selectedIndex;
 if (sel == -1) {
   alert("No Job Selected");
 } else {
   var selval=document.contents[control].options[sel].value;
   //window.open('tws_display_job.php?arg=' + escape(selval),'job_info','width=' + disjobwidth + ',height=' + disjobheight + ',toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=yes');
   tws_url_open('tws_display_job.php?arg='+escape(selval)+'&display=yes', '', disjobwidth);
 }
}
function insertJobInfo(tableID,varname,varvalue)
{
 table=document.getElementById(tableID);
 var index=table.rows.length;
 newrow=table.insertRow(index);

 newcell=newrow.insertCell(0);
 newcell.innerHTML='<input type="hidden" name="' + varname + '" value="' + varvalue + '">';
}

function setjobnames(tableID)
{
 var jobname;
 var index;

 var numjobs=document.contents['jobs'].length;
  if (numjobs > 0) {
   table=document.getElementById(tableID);
   for (i=0; i<numjobs; i++) {
     jobname=document.contents['jobs'].options[i].value;
     index=table.rows.length;
     newrow=table.insertRow(index);
     newcell=newrow.insertCell(0);
     newcell.innerHTML='<input type="hidden" name="jobname[' + i + ']" value="' + jobname + '">';
   }
 }
}

function insertRCG (){

   if($('tr.rcg').last().css('display')=='none'){
      $('tr.rcg').last().css('display','block');
      return;
   }
   var myclone = $('tr.rcg').last().clone(true);
   // find last field number
   var fname = $(myclone).find('input:text').attr('name');
   var re = /\[(\d+)\]/g;
   var m = re.exec(fname);
   var i = parseInt(m[1]);
   var ii = i+1;
   var f = '[' + i + ']';
   var r = '[' + ii + ']';
   var oldhtml = myclone.html();
   var newhtml = oldhtml.split(f).join(r);
   myclone.html(newhtml);

   $(myclone).find('input:text').val('');    // remove values from text fields

   myclone.insertAfter($('tr.rcg').last());
}

function setjobalias(jobname, alias) {
   // change (add) alias in job list
   var sel=document.contents['jobs'].selectedIndex;
   var newval=document.contents['jobs'].options[sel].text;
   var oldval = newval;
   if (newval.search(/ as /i) == -1){
      if(trim(alias) != '')
         newval = newval + ' as ' + alias;
   }
   else {   // replace alias
      newval = newval.substr(0, newval.indexOf(' '));
      if(trim(alias) != '')
         newval = newval + ' as ' + alias;
   }
   document.contents['jobs'].options[sel].text = newval;
   document.contents['jobs'].options[sel].value = newval;

   var fname;
   $('table#storage input[name*="['+oldval+']"]').each(function (i) {
      fname = this.name;
      fname = fname.replace(oldval, newval);
      $(this).attr('name', fname);
      });

   selectJob('jobs','showjob');
}

function escapeHtml(unsafe) {
  return unsafe.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}

function rc_preview(send) {

   var arg = '';
  $(':text[name^="rc_"]').each(function() {
      if($(this).val() != '')
         arg += $(this).attr("name") +'='+ encodeURIComponent($(this).val()) + '&';
  });
  $('select[name^="rc_"]').each(function() {
      if($(this).val() != '')
         arg += $(this).attr("name") +'='+ $(this).val() + '&';
  });
  $(':text[name^="calendar"]').each(function() {
      if($(this).val() != '')
         arg += $(this).attr("name") +'='+ $(this).val() + '&';
  });
  $(':text[name^="freedays_"]').each(function() {
      if($(this).val() != '')
         arg += $(this).attr("name") +'='+ $(this).val() + '&';
  });
  $('input:checked[name^="rc_"]').each(function() {
      if($(this).val() != '')
         arg += $(this).attr("name") +'='+ $(this).val() + '&';
  });
  $('input:checked[name^="freedays_"]').each(function() {
      if($(this).val() != '')
         arg += $(this).attr("name") +'='+ $(this).val() + '&';
  });
  $('input:selected[name^="rc_"]').each(function() {
      if($(this).val() != '')
         arg += $(this).attr("name") +'='+ $(this).val() + '&';
  });
  $('input:selected[name^="freedays_"]').each(function() {
      if($(this).val() != '')
         arg += $(this).attr("name") +'='+ $(this).val() + '&';
  });
   if($('input#validfrom').val() != '')   // JS validfrom
      arg += 'validfrom=' + $('input#validfrom').val() + '&';
   if($('input#validto').val() != '')
      arg += 'validto=' + $('input#validto').val() + '&';
   // JS At plus days
   if($('input#atplusdays').val() != '' && $('input#athour').val() != '' && $('input#atminute').val() != '')
      arg += 'delay=' + $('input#atplusdays').val() + '&';

// RCG
  $(':text[name^="rcg"]').each(function() {
      if($(this).val() != '')
         arg += $(this).attr("name") +'='+ $(this).val() + '&';
  });
  $('select[name^="rcg_"]').each(function() {
      if($(this).val() != '')
         arg += $(this).attr("name") +'='+ $(this).val() + '&';
  });

// for calendar rc
  $(':text[name^="offsetvalue"]').each(function() {
      if($(this).val() != '')
         arg += $(this).attr("name") +'='+ $(this).val() + '&';
  });
  $('select[name^="offsettype"]').each(function() {
      if($(this).val() != '')
         arg += $(this).attr("name") +'='+ $(this).val() + '&';
  });
// for Single Dates
  $(':text[name^="date_day"]').each(function() {
      if($(this).val() != '')
         arg += $(this).attr("name") +'='+ $(this).val() + '&';
  });

   $.ajax({
      type: 'POST',
      url: 'ajax_server.php',
      data: {'object':'rc_preview', 'arg':arg <?=defined('IWD_PROCMAN') ? ', __hwi_syntok:window.hwi_syntok' : ''?>},
      success: function(elemid) {
         if(send)
            location.replace('rc_preview.php?send=yes&elemid='+elemid);
         else if(typeof(tws_dialog_type) == 'undefined' || tws_dialog_type=='modal'){
            tws_dialog_type='modal';
            tws_url_open('rc_preview.php?elemid='+elemid, 'rc_preview', 950);
         }
         else
            window.open('rc_preview.php?elemid='+elemid, '', 'height=320, width=950, left=60, top=50, toolbar=no, menubar=no, location=no, scrollbars=no, resizable=no');
      },
      error: function(jqXHR, Status, errorThrown ) {
          alert('ajax ' +Status+ ': ' +errorThrown+'. url: '+ url);
         },
      dataType: 'html'
      });
}

function enable_freedays(on) {
  if(on) {
    $('input[name="freedays_sat"]').prop('disabled', false);
    $('input[name="freedays_sun"]').prop('disabled', false);
    $('input[name^="freedays_calendar"]').prop('disabled', false);

    }
  else {
    $('input[name="freedays_sat"]').prop("disabled", "disabled");
    $('input[name="freedays_sun"]').prop("disabled", "disabled");
    $('input[name^="freedays_calendar"]').prop('disabled', "disabled");
   <? $tmp = tws_get_calendars('HOLIDAYS');
      if($tmp['calendar_num']==1):  ?>
      $('input[name="freedays_calendar"]').val('HOLIDAYS');
   <? endif; ?>
  }
}

function enable_rcg_calendar(on) {
  if(on) {
    $('input[name="rcg_sat_free"]').prop('disabled', false);
    $('input[name="rcg_sun_free"]').prop('disabled', false);
    $('input[name="rcg_calendar"]').prop('disabled', false);

    }
  else {
      $('input[name="rcg_sat_free"]').prop("checked", true);
      $('input[name="rcg_sun_free"]').prop("checked", true);
    $('input[name="rcg_sat_free"]').prop("disabled", "disabled");
    $('input[name="rcg_sun_free"]').prop("disabled", "disabled");
    $('input[name="rcg_calendar"]').prop('disabled', "disabled");
   <? $tmp = tws_get_calendars('HOLIDAYS');
      if($tmp['calendar_num']==1):  ?>
      $('input[name="rcg_calendar"]').val('HOLIDAYS');
   <? endif; ?>
  }
}

function enable_freedays_rules() {
/*
   if( $('input[name="freedays_option"][value="specify"]').is(':checked') ) {
      $('input[name^="rc_freedaysrule"]').prop('disabled', false);
      return;
   }
   $('input[name^="rc_freedaysrule"]').prop('disabled', "disabled");
   $('select[name^="rc_freq"]').each(function(){
      var re = /\[(\d+)\]/g;
      var m = re.exec($(this).prop('name'));
      var i = parseInt(m[1]);
      i = parseInt(i);
      //alert($('select[name="rc_freq['+i+']"]').val());
      //alert($('input[name="rc_bydays['+i+']"]').val());
      if($('select[name="rc_freq['+i+']"]').val() == 'DAILY' && $('input[name="rc_bydays['+i+']"]').val()=='')
        $('input[name="rc_freedaysrule['+i+']"]').prop('disabled', false);
      if($('select[name="rc_freq['+i+']"]').val() == 'MONTHLY')
        $('input[name="rc_freedaysrule['+i+']"]').prop('disabled', false);
      if($('select[name="rc_freq['+i+']"]').val() == 'YEARLY')
        $('input[name="rc_freedaysrule['+i+']"]').prop('disabled', false);
  });
*/
}
</script>
