<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Cancel Job</title>
<?php tws_stylesheet(); ?>
</head>
<body>
<?php tws_set_window_title(); ?>

<h1>Cancel Job Status</h1>

<?php
   if (!tws_permit_action('plan_jobs','Cancel')) {
      tws_access_denied ();
   }
   tws_import_request_variables("P","rqst_");

   $selection=tws_gpc_get($rqst_selection, "tws_name;tws_name;tws_datetime;tws_sched_id;tws_name;tws_name;tws_num");
   $safe_mode=tws_gpc_get($rqst_safe_mode, "tws_name");
   $arg=@tws_gpc_get($rqst_arg, "tws_filter");
   $afteraction=@tws_gpc_get($rqst_afteraction, "tws_name");
      tws_check_synchro_token();

   if ($safe_mode == "yes") {
      echo "<h3>Safe Mode:</h3>\n";

      $status=0;
      $priority=0;
      $num_elements=count($selection);
      for ($idx=0; $idx<$num_elements; ++$idx) {
         $jb=tws_get_job_data($selection[$idx]);

         echo "Setting priority to <em>$priority</em> for <em>$jb[cpu]#$jb[schedule]($jb[schedtime]).$jb[job]</em> ... ";
         tws_flush_output();

         $command=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/conman", $tws_config['conman_args'], "-gui", "ap $jb[cpu]#$jb[schedid].$jb[job];schedid;$priority", hwi_cmd::operator('2>&1',FALSE));
         $stdout=array();
         if (tws_popen($command, $ec, $stdout, $stdout, "N")===FALSE || tws_process_conman_gui($stdout)!=0) {
            $status=1;
            echo "<span class=\"err\">ERROR</span><br/>\n";
            tws_dyer("Alternate job priority to 0 failed", array('stdout'=>$stdout));
         } else {
            echo "<span class=\"ok\">OK</span><br/>\n";
         }
      }
      if ($status!=0) {
         //TODO: script should probably exit now
         //if ($arg != "") {
         //   echo "<a href=\"tws_sj.php?arg=" . urlencode($arg) . "\">Return to Jobs Display</a>\n";
         //} else {
         //   echo "<a href=\"tws_sj.php\">Return to Jobs Display</a>\n";
         //}
      }
      echo "<br>\n";
   }

   $status=0;
   $num_elements=count($selection);
   for ($idx=0; $idx<$num_elements; ++$idx) {
      $jb=tws_get_job_data($selection[$idx]);

      set_time_limit($tws_config['excmd_limit']);

      echo "Cancelling <em>$jb[cpu]#$jb[schedule]($jb[schedtime]).$jb[job]</em> ... ";
      tws_flush_output();

      $command=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/conman", $tws_config['conman_args'], "-gui", "cj $jb[cpu]#$jb[schedid].$jb[job];schedid", hwi_cmd::operator('2>&1',FALSE));
      $stdout=array();
      if (tws_popen($command, $ec, $stdout, $stdout, "N")===FALSE || tws_process_conman_gui($stdout)!=0) {
         $status=1;
         echo "<span class=\"err\">ERROR</span><br/>\n";
         tws_err("Cancel job failed", array('stdout'=>$stdout));
      } else {
         echo "<span class=\"ok\">OK</span><br/>\n";
      }
   }

   // restore priority can't be set for Cancelled job

   if(tws_profile('action_refresh')=='yes'){
      if ($status==0) {
         echo "<script type='text/javascript'>\n";
            echo "window.location.replace('".tws_profile('opener')."');\n";
         echo "</script>\n";
      }
      else
         echo "<br><br><a href='".tws_profile('opener')."'>Return to Jobs Display</a>\n";
   }
   else{
      if ($status==0 && tws_profile('action_popup_close'))
         echo "<script>window.close();</script>";
      else
         echo '<br><input type="button" value="Close Window" onClick="window.close();">';
   }
?>
</body>
</html>
