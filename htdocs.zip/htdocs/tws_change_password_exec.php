<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Set IWS/WebAdmin Password</title>
<?php tws_stylesheet(); ?>
</head>
<body>
<?php tws_set_window_title(); ?>
<h1>IWS/WebAdmin Password Change Results</h1>

<?php
   tws_check_synchro_token();

   tws_import_request_variables("P","rqst_");

   $password=tws_gpc_get($rqst_password);
   $confirm_password=tws_gpc_get($rqst_confirm_password);

   if ($password!=$confirm_password) {
      echo "<p class=warning>Error: Password fields do not match</p>\n";
   } else {
      $authusers="$base_inst_dir/httpd/conf/authusers";
      $authgroups="$base_inst_dir/httpd/conf/authgroups";
      $bakauthusers=$authusers . ".bak";

      copy($authusers,$bakauthusers);

      if(!empty($tws_config['hwf_root']))
         $hwf_root = $tws_config['hwf_root'];
      else $hwf_root = $base_inst_dir;

      if ($host_os == "win32") {
         $command=new hwi_cmd("$hwf_root/httpd/bin/htpasswd", "-b", $authusers, $_SERVER['PHP_AUTH_USER'], $password, hwi_cmd::operator('2>&1',FALSE));
      } else {
         $command=new hwi_cmd("$hwf_root/httpd/bin/htpasswd", "-b", $authusers, $_SERVER['PHP_AUTH_USER'], $password, hwi_cmd::operator('2>&1',FALSE));
      }

      if (tws_popen($command,$ec,$stdout,$stdout)===FALSE || $ec!=0) {
         copy($bakauthusers,$authusers);
         tws_err("Unable to change password. Original password restored.", array('stdout'=>$stdout));
         echo "<br><br>\n";
         echo "<a href=\"tws_options.php\">Return to IWS/WebAdmin Options</a>\n";
      } else {
         echo "<br>\n";
         echo "<p class=warning>Password for <b>$_SERVER[PHP_AUTH_USER]</b> has been changed\n";
         echo "<br><br>\n";
         echo "<a href=\"tws_options.php\">Return to IWS/WebAdmin Options</a>\n";
      }
   }
?>
</body>
</html>
