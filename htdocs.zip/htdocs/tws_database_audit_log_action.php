<?php
//   HORIZONT Software GmbH, Munich
//

   require_once("tws_functions.php");
   tws_import_request_variables("P","rqst_");

   $action=$rqst_action;
   $object='database_audit';
   $filter = $rqst_arg;

   switch ($action) {
     case "Filter":
       include("tws_database_audit_log_filter.php");
       break;
     case "Save Filter":
       header("Location: tws_save_filter.php?object=$object&arg=".urlencode($filter));
       exit;
     case "Send as CSV":
       header("Location:tws_send_database_audit_log.php?arg=".urlencode($filter));
       break;
   }
?>