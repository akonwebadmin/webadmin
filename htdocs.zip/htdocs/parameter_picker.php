<?php
//   HORIZONT Software GmbH, Munich
//
   $__tlogmode='APPEND';
   require_once 'tws_functions.php';

   if (defined('IWD_PROCMAN')) {
      $iwd_class='iwd_dbvb';
      $search_elems=array();
      $search=$iwd_class::get_search_elems($search_elems, 'ref');
   }

   tws_import_request_variables("P","rqst_");

   $parameter_tablex=@$rqst_parameter_tablex;
   $fieldname=@$rqst_fieldname;
   tws_check_elname($fieldname);
   $fieldvalue=@$rqst_fieldvalue;
   $allowmultiple=@$rqst_allowmultiple;
   $caret=@$rqst_caret;
   $append=@$rqst_append;
   $insert=@$rqst_insert;
   $have_table = @$rqst_table;
   $display="yes";

   if (!isset($fieldname)) {
      $fieldname="parameter";
   }

   if ((strpos($fieldname,"[") !== FALSE) && (strpos($fieldname,"]") !== FALSE)) {
      $jsfieldname="elements['" . $fieldname . "']";
   }
   else {
      $jsfieldname = $fieldname;
   }

   ?>

<script type="text/javascript">

function sendValue(formsel) {
 var selectionval = "";
 if(formsel) {
 for (var i = 0; i < formsel.options.length; i++) {
    if (formsel.options[i].selected) {
       selectionval = selectionval + formsel.options[i].value + ",";
<?php
   if ($caret == "yes") {
?>
       selectionval="^" + selectionval.substr(0, selectionval.length - 1) + "^,";
<?php
   }
?>
    }
 }
 selectionval=selectionval.substr(0, selectionval.length - 1);
<?php
   if ($insert == "yes") {
      echo " if (window.document.selection) {\n";
      echo "    window.document.contents.$jsfieldname.focus();\n";
      echo "    sel = window.document.selection.createRange();\n";
      echo "    sel.text = selectionval;\n";
      echo " } else if (window.document.contents.$jsfieldname.selectionStart || window.document.contents.$jsfieldname.selectionStart == '0') {\n";
      echo "    var startpos = window.document.contents.$jsfieldname.selectionStart;\n";
      echo "    var endpos = window.document.contents.$jsfieldname.selectionEnd;\n";
      echo "    window.document.contents.$jsfieldname.value = window.document.contents.$jsfieldname.value.substring(0, startpos) + selectionval + window.document.contents.$jsfieldname.value.substring(endpos, window.document.contents.$jsfieldname.value.length);\n";
      echo "    window.document.contents.$jsfieldname.selectionStart = startpos + selectionval.length;\n";
      echo "    window.document.contents.$jsfieldname.selectionEnd = startpos + selectionval.length;\n";
      echo " } else {\n";
      echo "    window.document.contents.$jsfieldname.value += selectionval;\n";
      echo " }\n";
   } elseif ($append == "yes") {
      echo " window.document.contents.$jsfieldname.value += selectionval;\n";
   } else {
      echo " window.document.contents.$jsfieldname.value = selectionval;\n";
   }
?>
   }
   $('[name="<?=$fieldname?>"]').keyup();
   $("#parameter_picker").dialog( "close" );
}

</script>

<div id="parameter_picker">

<h1>Select Parameter</h1>
<form name="parameter_list" action="">
<?php
 // if we have no field for parameter table - call picker with "table=no"
   $together = 0;
   $dyer=0;
   if ($tws_config['cpuinfo']['version']>='8.5' && $parameter_tablex=='') {
      if($have_table=='no') {
         $together = 1;
         if (strpos($fieldvalue, ".") === FALSE) {
            $parameter_tablex="@";
         }
         else {
            $parameter_tablex = substr($fieldvalue, 0, strpos($fieldvalue, "."));
            $fieldvalue = substr($fieldvalue, strpos($fieldvalue, ".")+1);
         }
      }
      else {
         $dyer=1;
      }
   }

   if ($dyer) {
      echo "<center><p class=warning>No parameter table name selected</p>\n";
      echo '<input type="button" value="Cancel" onClick="sendValue(null)"></center>',"\n";
   }
   else {
     if ($fieldvalue=="") {
      $arg="@";
   } else {
      if ((strpos($fieldvalue,"*") === FALSE) && (strpos($fieldvalue,"@") === FALSE)) {
         $arg=$fieldvalue . "@";
      } elseif (strpos($fieldvalue,"*") !== FALSE) {
         $arg=strtr($fieldvalue,"*","@");
      } else {
         $arg=$fieldvalue;
      }
   }
   $tws_config['cpuinfo']['version']>=8.5 && $arg=$parameter_tablex.'.'.$arg;

   $select_options = '';
   if (defined('IWD_PROCMAN')) { //IWD/ProcMan
      $arg=strtr($arg,"@","*");
      if (($objs=$iwd_class::get_listing($arg, 'ref'))!==FALSE) {
         $parameters=array('parameter_num'=>count($objs), 'parameter_table'=>array(), 'parameter_name'=>array(), 'version'=>array());
         $i=0;
         foreach($objs as $obj) {
            list($parameters['parameter_table'][$i],$parameters['parameter_name'][$i])=explode('.', $obj['name']);
            $parameters['version'][$i]=$obj['version'];
            $i++;
         }
      } else {
         hwi_log_flush();
         $parameters=FALSE;
      }
   }
   else { //IWS/WebAdmin
      $parameters = tws_get_parameters($arg);
   }

   if ($parameters=== FALSE) {
      echo "<center><p class=warning>Unable to list parameters</p>\n";
      echo '<input type="button" value="Cancel" onClick="sendValue(null)"></center>',"\n";
   }
   elseif ($parameters['parameter_num']==0) {
      echo "<p class=warning>No parameter entries matching '". htmlspecialchars($arg)."' criteria found.</p>\n";
   }
   else {
      echo '<select class="picker" name="selection" size=15 onDblClick="sendValue(this.form.selection);"',($allowmultiple=='yes' ? ' multiple' : ''),'>',"\n";
      foreach ($parameters['parameter_name'] as $parkey=>$name) { //jozsef
         $version=defined('IWD_PROCMAN') ? ' ('.$parameters['version'][$parkey].')' : '';
		 $parname = $name;
		 if ($tws_config['cpuinfo']['version']>='9.5002') {
				$partable = $parameters['parameter_table_folder'][$parkey].$parameters['parameter_table'][$parkey];
		 } else {
			 $partable = $parameters['parameter_table_folder'][$parkey];
		 }
         if (@$partable!='') {   // improve: don't include table name into parameter field
            if($together) {
               $parname = $partable.'.'.$parname;
               echo '<option value="'.$parname.'">'.$parname.$version.'</option>'."\n";
            } else {
               echo '<option value="'.$parname.'">'.$partable.'.'.$parname.$version.'</option>'."\n";
            }
         }
         else {
            echo '<option value="'.$parname.'">'.$parname.$version.'</option>'."\n";
         }
      }
      echo '</select>',"\n";
      echo '<center><input type="button" value="OK" onClick="sendValue(this.form.selection);"></center>',"\n";
    }
   }
?>
</form>
</div>

<script type="text/javascript">

$(function() {
   tws_picker_constructor("parameter_picker");
});

</script>
