<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";

   $log_file_name=tws_log('', 'OPEN');
   tws_log('-- START ('.basename(__FILE__).'['.__LINE__.'])');
   $execution_time = tws_getmicrotime();

   tws_doctype("t");
?>
<html>
<head>
   <title>Add Schedule Dependency Result</title>
   <?php tws_stylesheet(); ?>
</head>
<body>
<?php
   tws_set_window_title();
   if (!tws_permit_action('plan_jobstreams','Add Dep')) {
      tws_access_denied ();
   }

   tws_import_request_variables("P","rqst_");

   $error_title = 'Incomplete or incorrect submit data';
   $error = '';
   $status = true;

   $selection=tws_gpc_get($rqst_selection, "tws_name;tws_name;tws_datetime;tws_sched_id");
   $arg=tws_gpc_get($rqst_arg, "tws_filter");
   $afteraction=tws_gpc_get($rqst_afteraction, "tws_name");
   $athour=tws_gpc_get($rqst_athour, "tws_num");
   $atminute=tws_gpc_get($rqst_atminute, "tws_num");
   $atplusdays=tws_gpc_get($rqst_atplusdays, "tws_num");
   $untilhour=tws_gpc_get($rqst_untilhour, "tws_num");
   $untilminute=tws_gpc_get($rqst_untilminute, "tws_num");
   $untilplusdays=tws_gpc_get($rqst_untilplusdays, "tws_num");
   $onuntil = $rqst_onuntil ? ';onuntil '.tws_gpc_get($rqst_onuntil, "tws_name") : '';
   $deadlinehour = tws_gpc_get($rqst_deadlinehour, "tws_num");
   $deadlineminute = tws_gpc_get($rqst_deadlineminute, "tws_num");
   $deadlineplusdays = tws_gpc_get($rqst_deadlineplusdays, "tws_num");
   $privalue=tws_gpc_get($rqst_privalue, "tws_priority");
   $limitvalue=tws_gpc_get($rqst_limitvalue, "tws_num");
   $carryforward=tws_gpc_get($rqst_carryforward, "tws_name");

   $followsjobstreamcpu = is_array($rqst_followsjobstreamcpu) ? tws_gpc_get($rqst_followsjobstreamcpu, "tws_name") : array();
   $followsjobstreamname = is_array($rqst_followsjobstreamname) ? tws_gpc_get($rqst_followsjobstreamname) : array();
   $followsjobcpu = is_array($rqst_followsjobcpu) ? tws_gpc_get($rqst_followsjobcpu, "tws_name") : array();
   $followsjobjobstream = is_array($rqst_followsjobjobstream) ? tws_gpc_get($rqst_followsjobjobstream) : array();
   $followsjobname = is_array($rqst_followsjobname) ? tws_gpc_get($rqst_followsjobname, "tws_name") : array();
   $promptname = is_array($rqst_promptname) ? tws_gpc_get($rqst_promptname, "tws_name") : array();
   $prompttext = is_array($rqst_prompttext) ? tws_gpc_get($rqst_prompttext) : array();
   $openscpu = is_array($rqst_openscpu) ? tws_gpc_get($rqst_openscpu, "tws_name") : array();
   $opensfile = is_array($rqst_opensfile) ? tws_gpc_get($rqst_opensfile, "tws_file") : array();
   $needscpu = is_array($rqst_needscpu) ? tws_gpc_get($rqst_needscpu, "tws_name") : array();
   $resource = is_array($rqst_resource) ? tws_gpc_get($rqst_resource, "tws_name") : array();
   $units = is_array($rqst_units) ? tws_gpc_get($rqst_units, "tws_num") : array();

   tws_check_synchro_token();

   if (tws_yesno(tws_get_tz_status(),TRUE,FALSE)) {
      $time_zone = ($rqst_time_zone!='' && $rqst_time_zone!='NULL') ? ' timezone '.$rqst_time_zone : '';
   } else {
      $time_zone = '';
   }

   $deps="";

   if (($athour != "") && ($atminute != "")) {
      $deps .= ";at=$athour$atminute$time_zone";
      if ($atplusdays != "") {
         $deps .= "+$atplusdays days";
   }
   } elseif (($athour != "") || ($atminute != "")) {
      $error .= "Invalid AT Time specified!\n";
      $status = false;
   }

   if (($untilhour != "") && ($untilminute != "")) {
      $deps .= ";until=$untilhour$untilminute$time_zone";
      if ($untilplusdays != "") {
         $deps .= "+$untilplusdays days";
      }
      $deps .= $onuntil;
   } elseif (($untilhour != "") || ($untilminute != "")) {
      $error .= "Invalid UNTIL Time specified!\n";
      $status = false;
   }

   if (($deadlinehour != "") && ($deadlineminute != "")) {
      $deps .= ";deadline=$deadlinehour$deadlineminute$time_zone";
      if ($deadlineplusdays != "") {
         $deps .= "+$deadlineplusdays days";
      }
   } elseif (($deadlinehour != "") || ($deadlineminute != "")) {
      $error .= "Invalid DEADLINE Time specified!\n";
      $status = false;
   }

   if ($privalue != "") {
      $deps .= ";pri=$privalue";
   }

   if ($limitvalue != "") {
      $deps .= ";limit=$limitvalue";
   }

   if ($carryforward == "yes") {
      $deps .= ";carryforward";
   }

   // ********    Stream to Stream Deps    ******** //
   $first = true;
   foreach ($followsjobstreamname as $key => $value) {
      if ($value != "") {
         $tmp_arr = explode(';', $value);
         $follows_jobstream_name = $tmp_arr[0];
//         $follows_jobstream_id = $tmp_arr[1];
         $deps .= $first ? ';follows=' : ',follows=';
         if (!empty($followsjobstreamcpu[$key]))
            $deps .= $followsjobstreamcpu[$key].'#';
         $deps .= $follows_jobstream_name;
         $first = false;
      }
   }

   // ********    Stream to Job Deps    ******** //
   $first = true;
   foreach ($followsjobname as $key => $value) {
      if (($value != '') && ($followsjobjobstream[$key] != '')) {
         // list($follows_job_jobstream_name,$follows_job_jobstream_id)=explode(';',$followsjobjobstream[$key]);
         $tmp = explode(';',$followsjobjobstream[$key]);
         $follows_job_jobstream_name = $tmp[0];
         $deps .= $first ? ';follows=' : ',follows=';
         // $follows_job_jobstream_id = $tmp[1];
         if (!empty($followsjobcpu[$key]))
            $deps .= $followsjobcpu[$key].'#';
         $deps .= $follows_job_jobstream_name;
         $deps .= ".$value";
         $first = false;
      }
   }

   $first = true;
   foreach ($promptname as $value) {
      if ($value != '') {
        $deps .= $first ? ";prompt=$value" : ",$value";
        $first = false;
      }
   }
   foreach ($prompttext as $value) {
      if ($value != '') {
        $deps .= $first ? ";prompt='".$value."'" : ",'".$value."'";
        $first = false;
      }
   }

   $first = true;
   foreach ($opensfile as $key => $value) {
      if ($value != '') {
         if ($openscpu[$key] != '') {
            $deps .= $first ? ";opens=$openscpu[$key]#$value" : ",$openscpu[$key]#$value";
         } else {
            $deps .= $first ? ";opens=$value" : ",$value";
         }
         $first = false;
      }
   }

   $first = true;
   foreach ($resource as $key => $value) {
      if ($value != '') {
         if ($needscpu[$key] != '') {
            $deps .= $first ? ";needs=$units[$key] $needscpu[$key]#$value" : ",$units[$key] $needscpu[$key]#$value";
         } else {
            $deps .= $first ? ";needs=$units[$key] $value" : ",$units[$key] $value";
         }
         $first = false;
      }
   }

   if ($deps == '') {
      $error .= "No dependencies specified.\n";
      $status = false;
   }

   if ($status) {
      tws_log('-- OUTPUT:');
      foreach($selection as $val){
         $js=tws_get_jobstream_data($val);
         // echo "Adding selected dependencies to <em>$js[cpu]#$js[schedule]($js[schedtime])</em> ... ";

         $command=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/conman", $tws_config['conman_args'], "-gui", "ads $js[cpu]#$js[schedid];schedid$deps", hwi_cmd::operator('2>&1',FALSE));

         $stdout=array();
         if (tws_popen($command, $ec, $stdout, $stdout, "N")===FALSE || ($opstatus=tws_process_conman_gui($stdout))!=0) {
            $error_title = "The add schedule dependency operation failed. Command: $maestro_dir/bin/conman -gui ads $js[cpu]#$js[schedid];schedid$deps";
            $error = array('stdout'=>$stdout);
            $status = false;
         }
         tws_log(implode('', $stdout));
         tws_log("-- CONMAN EXIT CODE = $ec, OPERATION STATUS = $opstatus");
      }
   }
   else $error = array('attr'=>$error);

   tws_log('-- FINISH ('.basename(__FILE__).'['.__LINE__.'])', 'CLOSE');        //close log file
   $execution_time = tws_getmicrotime() - $execution_time;

   if ($status) {
      $url = tws_profile('last_opener');
         echo '<script type="text/javascript">'."\n";
         echo "closeme('$url');\n";
         echo '</script>'."\n";
   }
   else {
      tws_print_head('Add Schedule Dependency Result', array('__time__' => $execution_time, '__log__' => $log_file_name));
      tws_err($error_title, $error);
      echo '<form action="tws_add_schedule_dependency.php" method="post">'."\n";
      echo tws_create_hidden_inputs($_POST);
      echo '<input type="submit" name="action" value="Return to Add Schedule Dependency">'."\n";
      echo '</form>'."\n";
   }
?>
</body>
</html>
