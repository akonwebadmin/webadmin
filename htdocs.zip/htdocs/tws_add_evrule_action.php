<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_import_request_variables('P', 'rqst_');

   @$action=$rqst_action;
   @$evrule_name=isset($rqst_evrules['evrule_name'][0]) ? tws_gpc_get($rqst_evrules['evrule_name'][0], 'tws_name') : tws_gpc_get($rqst_evrule_namex, 'tws_name');
   @$evrule_namex=tws_gpc_get($rqst_evrule_namex, 'tws_name');

   switch ($action) {
      case 'Add':
      case 'Update':
      case 'Replace':
      case 'OK':
         include('tws_add_evrule_exec.php');
         break;
      case 'Cancel':
         // Unlock the object
         $evruleid=trim($evrule_namex)!='' ? "er=$evrule_namex" : "er=$evrule_name";
         tws_composer_unlock($evruleid) or tws_dyer("Unable to unlock event rule $evruleid");
         echo '<script type="text/javascript">
            if(window.name == "tws_popup")  window.close();
            else window.location.replace("tws_evrulesx.php");
         </script>'."\n";
         break;
      case "Return to Event Rule Modification":
         include("tws_add_evrule.php");
         break;
   }
?>