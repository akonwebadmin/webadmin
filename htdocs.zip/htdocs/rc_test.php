<?php
//   HORIZONT Software GmbH, Munich
//
// We have some test jobstreams with runcyckles under known errors from tickets
// So, we have to get dates from this JS (RC)
//
   require_once "tws_functions.php";      // bin
   require_once 'tws_sec.php';
   require_once 'db_statements.php';      // missed in bin/tws_functions
   require_once 'tws_composer.php';
   
// Get stream name from parameter   
   $sapi_name = php_sapi_name();
if ($sapi_name == 'cli'){   
   $options = getopt('j:');
   $js = $options['j'];
}
else $js = 'CZ14#RC_TEST0';

// get js params 
   list($ws, $js) = explode("#", $js);
   list($js, $valid) = explode(":", $js);
   if(empty($valid)) $valid = '';
   
// Get RC Parameters    
   $run_data = tws_get_jobstream_runcycle_data($ws, $js, $valid);
   // TODO: if(empty)
   $arg = '';
   foreach($run_data['rc'] as $var=>$rc_val){
      if(is_array($rc_val)){
         foreach($rc_val as $i=>$val){
            if(is_array($val)){  // single dates
               foreach($val as $j=>$date)
                  $arg .= $var."[".$i."][".$j."]=$date&";
            }
            elseif(!empty($val)){ 
               $arg .= $var."[".$i."]=$val&";
            }
         }
         
      }
   }
// Get JS Parameters    
   $generic_data = tws_get_jobstream_generic_data($ws, $js, $valid);
   // TODO: if(false)

   if($generic_data["validfrom"] != "") 
      $arg .= "validfrom=".$generic_data["validfrom"]."&";
   if($generic_data["atplusdays"] != "") 
      $arg .= "delay=".$generic_data["atplusdays"];
   
   if($generic_data['freedays_option']=="specify"){
      $arg .= "freedays_option=specify&freedays_calendar=".$generic_data['freedays_calendar']."&";
      $arg .= "freedays_sat=".$generic_data["freedays_sat"]."&";
      $arg .= "freedays_sun=".$generic_data["freedays_sun"]."&";
   }
   else{       // default calendar
      $arg .= "freedays_option=default&";
      if(!empty($generic_data['freedays_calendar']))
         $arg .= "freedays_calendar=".$generic_data['freedays_calendar']."&";
      else{
         $tmp = tws_get_calendars('HOLIDAYS');
         if($tmp['calendar_num']==1)
            $arg .= "freedays_calendar=HOLIDAYS&";
         }
      $arg .= "freedays_sun=YES&freedays_sat=YES&";
   }
   $foryear = date("Y");
   $arg .= "foryear=$foryear&";
   $arg .= "test=YES";

// no auth    
   $__session = false;
   tws_profile('auth_user_group', 'admin');
   
// put $arg into session
   $elemid = tws_rndstr('ELEMID');
   $rc_preview = tws_profile('rc_preview');
   $rc_preview[$elemid] = $arg;
   tws_profile('rc_preview', $rc_preview);
   
   // call rc_peview.php with $elemid
   include "$base_inst_dir/httpd/htdocs/rc_preview.php";
   //echo $test_result;
   //delete session['elemid']
   $rc_preview = tws_profile('rc_preview');
   unset($rc_preview[$elemid]);
   tws_profile('rc_preview', $rc_preview);
?>
