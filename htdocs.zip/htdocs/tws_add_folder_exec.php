<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add Folder</title>
<?
tws_stylesheet();
// tws_show_backup(); ??
?>
</head>
<body>
<? tws_set_window_title();
   tws_check_synchro_token();  // synchro_token
   tws_import_request_variables("P","rqst_");

   if (!tws_permit_action('database_folders','Add')) { tws_access_denied ();}

   $folder_name=tws_gpc_get($rqst_folder_name, 'tws_name');
   $folder_name=strtoupper($folder_name);
   $folder_path=tws_gpc_get($rqst_folder_path);
   $folder = $folder_path.$folder_name;
   $action=$rqst_action;

   if ($action=="Cancel") {
      echo "<script type='text/javascript'>\n";
         echo "  closeme('tws_foldersx.php');\n";
      echo "</script>\n";
      exit;
   }
   elseif($action=="Return to Modification"){
      include("tws_add_folder.php");
      exit;
   }
   elseif($action=='Rename')
     // unlock the object
     tws_composer_unlock("folder=$folder");

// Create random temporary filename
      $tmpfilename="$maestro_dir/webadmin/tmp/folder.".tws_rndstr().".tmp";
      $fp=fopen($tmpfilename,'w') or tws_dyer("Unable to create temporary file");
      $cmd=Array();
      $cmd[]="folder $folder\n";
      foreach ($cmd as $cmdline) {
         $num_bytes=fwrite($fp, $cmdline);
         if ($num_bytes < 0) {
            fclose($fp);
            tws_dyer("Unable to write temporary file");
         }
      }
      fclose($fp);
      tws_chmod($tmpfilename, 0644);

      $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "add $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      $stdout3='';
      $ec_popen=tws_popen($command3, $ec3, $stdout3, $stdout3, "N");


      //testing for the AWSBIA288I Total objects updated: 0.
      //Note: This has been added on 2016-07 to fix the problem of composer updating
      //correctly objects but returning incorrect return codes (not 0 or 4)
      $not_updated=!preg_match('/AWSBIA288[^\n]+(\d+)/', $stdout3, $_r) || $_r[1]==0;

      if ($ec_popen===FALSE || ($ec3!=0 && $ec3!=4 && $not_updated)) {
         echo "<h1>Add Folder Status</h1>\n";
         tws_err("Folder add operation failed", array('twscmd'=>$command3->compile('log'), 'stdout'=>$stdout3, "EC_POPEN"=>$ec_popen, "EC_UPDATED"=>$ec3, "NOT_UPDATED"=>tws_yesno($not_updated,'YES','NO')));
         echo "<form action='tws_add_folder_exec.php' method='post' onsubmit=\"if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Workstation',null)) { cancel_button_pressed=false; return false;}\">\n";
         echo tws_create_hidden_inputs($_POST);
         tws_print_synchro_token();
         echo "<input type='submit' name='action' value='Cancel' onClick='cancel_button_pressed=true;'/>\n";
         echo "<input type='submit' name='action' value='Return to Modification'/>\n";
         echo "</form>";
      } else {
         if (preg_match("/warnings?\s[1-9]/i",$stdout3)) {
            $headertext="Add Folder";
            tws_err("The Folder has been saved with the following warnings:", array('stdout'=>$stdout3));
             $shortwarnfilename="warn.".tws_rndstr().".txt";
             $warnfilename="$webadmin_tmp_dir/$shortwarnfilename";
             $warnfp=fopen("$warnfilename","w") or tws_dyer("Unable to create warning text file", "Warning output :\n$stdout3");
             $num_bytes=fwrite($warnfp,"$stdout3");
             if ($num_bytes < 0) {
                 fclose($warnfp);
                 unlink($warnfilename);
                 tws_dyer("Unable to write warning text file", "Warning output :\n$stdout3");
            }
            fclose($warnfp);
            tws_dyer();
         }
         if (tws_zli_module_check () && isset ($netmodule_file)) {
             require_once ("zli_lib.php");
             zli_netmod_file_editfolder($folder_name, $folder_path, $netmodule_file);
             $message = urlencode ("The folder has been saved successfuly.");
             echo "<script type='text/javascript'>\n";
             echo "window.location.replace(\"zli_close_window.php?message=$message\");\n";
             echo "</script>\n";
         }
         else {   // All OK
               //remove the tmp file now
               unlink($tmpfilename);

               echo "<script type='text/javascript'>\n";
               echo "closeme('tws_foldersx.php');\n";
               echo "</script>\n";
         }
      }
?>
</body>
</html>
