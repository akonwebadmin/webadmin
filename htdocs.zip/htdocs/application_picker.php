<?php
//   HORIZONT Software GmbH, Munich
//
   $__tlogmode='APPEND';
   require_once 'tws_functions.php';

   tws_import_request_variables("P","rqst_");

   $fieldname=$rqst_fieldname;
   tws_check_elname($fieldname);
   $fieldvalue=@$rqst_fieldvalue;
   $display="yes";

   if ((strpos($fieldname,"[") !== FALSE) && (strpos($fieldname,"]") !== FALSE)) {
      $jsfieldname="elements['" . $fieldname . "']";
   }
   else $jsfieldname = $fieldname;
?>

<script type="text/javascript">

function sendValue(formsel) {
 var selectionval = "";
 if (formsel) {
   for (var i = 0; i < formsel.options.length; i++)
      if (formsel.options[i].selected)
         selectionval = selectionval + formsel.options[i].value + ",";
   window.document.contents.<?=$jsfieldname ?>.value = selectionval.substr(0, selectionval.length - 1);
 }
 $('[name="<?=$fieldname?>"]').keyup();
 $( "#application_picker" ).dialog( "close" );
}

</script>

<div id="application_picker">

<h1>Select Application</h1>
<br>
<?php
   if ($fieldvalue == "") {
      $arg="@";
   } else {
      if ((strpos($fieldvalue,"*") === FALSE) && (strpos($fieldvalue,"@") === FALSE)) {
         $arg=$fieldvalue . "@";
      } elseif (strpos($fieldvalue,"*") !== FALSE) {
         $arg=strtr($fieldvalue,"*","@");
      } else {
         $arg=$fieldvalue;
      }
   }

   $select_options = '';
   if (($apps = tws_get_applications($arg)) === FALSE) {
      tws_warning('Unable to list applications');
   } else if (isset($apps['app_name'])) {
      foreach ($apps['app_name'] as $name) {
         $select_options .= '<option value="'.$name.'">'.$name.'</option>'."\n";
      }
   }
?>
<form name="application_list" action="">
<select name="selection" size=14 class="picker" onDblClick="sendValue(this.form.selection);">
<?php
   echo $select_options;
?>
</select>
<br><center>
<input type="button" value="OK" onClick="sendValue(this.form.selection);">
</center><br>
</form>
</div>

<script type="text/javascript">

$(function() {
   tws_picker_constructor("application_picker");
});

</script>