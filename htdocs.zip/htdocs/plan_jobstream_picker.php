<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";

   if (defined('IWD_PROCMAN')) {
      $iwd_class='iwd_cpjs';
      $search_elems=array();
      $search=$iwd_class::get_search_elems($search_elems, 'ref');
   }

   tws_import_request_variables("P","rqst_");

   $cpux=strtoupper(trim($rqst_cpux));
   $wksfieldname = $rqst_wksfieldname;
   $fieldname=$rqst_fieldname;
   tws_check_elname($fieldname);
   $fieldvalue=trim($rqst_fieldvalue);
   $allowmultiple=@$rqst_allowmultiple;
   $display="yes";

   if (!isset($fieldname)) {
      $fieldname="jobstream";
   }

   $show_full_name = false;
   if ( preg_match('/[*@]/', $cpux) )
      $show_full_name = true;

?>
<script type="text/javascript">
function updateValue(val) {
   <?/* if(!empty($wksfieldname)): ?>
      if (val.indexOf('#')>0)
         $('[name="<?=$wksfieldname?>"]').val(val.substr(0, val.indexOf('#')));
   <? endif; */?>
   if (val.indexOf('#')>0)
      $('[name="<?=$fieldname?>"]').val(val.substr(val.indexOf('#')+1, val.length - val.indexOf('#')-1));
   else $('[name="<?=$fieldname?>"]').val(val);
   <? if(!empty($wksfieldname)): ?>
   $('[name="<?=$wksfieldname?>"]').keyup();
   <? endif; ?>
   $('[name="<?=$fieldname?>"]').keyup();
}

function sendValue(formsel) {
   var selval = "";
   if (formsel) {
      for (var i = 0; i < formsel.options.length; i++)
         if (formsel.options[i].selected)
            selval = selval + formsel.options[i].value + ",";
      if (selval!="") updateValue(selval.substr(0,selval.length-1));
   }
   $( "#plan_jobstream_picker" ).dialog( "close" );
}

   <?php
      if (defined('IWD_PROCMAN')) {
         if (trim($fieldvalue)=='') {
            $fieldvalue=$search_elems[$iwd_class][0];
            echo "updateValue('".$fieldvalue."');\n";
         }
      }
    ?>
</script>

<div id="plan_jobstream_picker">
<h1>Select Jobstream</h1>
<br>

<form name="jobstream_list">

<?php
   if ($cpux=='') {
      echo "<center><p class=warning>No workstation name selected</p>\n";
      echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\"></center>\n";
   }
   else {
      if ($fieldvalue == "") {
         $arg="@";
         if($tws_config['cpuinfo']['version']>='9.5')
            $arg = '/@/@';
      }
      else {
         /*    TODO: ?????
         list($sched_name,$sched_id)=explode(';',$fieldvalue);
            $tmp = explode(';',$fieldvalue);
            $sched_name = $tmp[0];
          */
         if ((strpos($fieldvalue,"*") === FALSE) && (strpos($fieldvalue,"@") === FALSE))
            $arg=$fieldvalue . "@";
         elseif (strpos($fieldvalue,"*") !== FALSE)
            $arg=strtr($fieldvalue,"*","@");
         else
            $arg=$fieldvalue;
      }
   }

      echo "<select id='sel' name='selection' class='picker' size=14 onDblClick='sendValue(this.form.selection);'";
      if ($allowmultiple == "yes") {
         echo " multiple";
      }
      echo ">\n";

      function plan_jobstream_picker_callback(&$sss,$ia,$ib) {
         global $show_full_name;
         if(!empty($sss['folder'][$ia]))
            $sss['schedule'][$ia] = $sss['folder'][$ia].$sss['schedule'][$ia];
//       echo '<option value="'.$sss['cpu'][$ia].'#'.$sss['schedule'][$ia].';'.$sss['schedid'][$ia].'">'.($show_full_name?$sss['cpu'][$ia].'#':'').$sss['schedule'][$ia],'  [(',$sss['schedtime'][$ia],') (',$sss['schedid'][$ia],')]</option>'."\n";
         echo '<option value="'.$sss['cpu'][$ia].'#'.$sss['schedule'][$ia].' ('.$sss['schedtime'][$ia].');'.$sss['schedid'][$ia].'">'.($show_full_name?$sss['cpu'][$ia].'#':'').$sss['schedule'][$ia],' [(',$sss['schedtime'][$ia],') (',$sss['schedid'][$ia],')]</option>'."\n";
      }

      if (defined('IWD_PROCMAN')) { //IWD/ProcMan
         $arg=strtr($arg,"@","*");
         $cpux=strtr($cpux,"@","*");

         if (($objs=$iwd_class::get_listing($cpux.'#'.$arg, 'ref'))!==FALSE) {
            foreach($objs as $obj) {
               echo '<option value="'.$obj['rname'].'" '.(($obj['rname']==$fieldvalue) ? 'selected' : '').'>'.$obj['name'].'</option>'."\n";
            }
            $result['nrows']=count($objs);
            echo "</select>\n";
         } else {
            echo '</select>';
            hwi_log_flush();
            $result=FALSE;
         }
      }
      else { //IWS/WebAdmin
         $result=tws_get_plan_jobstream_list($cpux.'#'.$arg, 0, 0, 1, 'plan_jobstream_picker_callback');
         echo "</select>\n";
      }
      if ($result===FALSE || $result['nrows']==0) {
         echo '<center>';
         echo '<script type="text/javascript">',"\n",'  deleteElem(\'sel\');',"\n",'</script>',"\n";
         if ($result===FALSE)
            echo '<p class="warning">Unable to get plan jobstream list</p>',"\n";
         else
            echo '<p class="warning">No qualified entries matching ',htmlspecialchars($cpux),'#',($fieldvalue=='' ? '@' : htmlspecialchars($fieldvalue)),'</p>',"\n";
         echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\"></center>\n";
      }
      else
         echo "<br><center><input type=\"button\" value=\"OK\" onClick=\"sendValue(this.form.selection);\"><br></center>\n";
?>
</form>
</div>

<script type="text/javascript">
$(function() {
   tws_picker_constructor("plan_jobstream_picker");

   // sort jobstream list
   var lb = document.getElementById('sel');
   if(!lb) return; // if no streams
   var arr = [];

   for(i=0; i<lb.length; i++)
      arr[i] = [lb.options[i].text, lb.options[i].value];

   arr.sort();

   for(i=0; i<lb.length; i++)  {
     lb.options[i].text = arr[i][0];
     lb.options[i].value = arr[i][1];
   }

});
</script>
