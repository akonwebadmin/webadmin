<?php
//   HORIZONT Software GmbH, Munich
//

require_once 'tws_functions.php';

tws_audit_loginout('LOGOUT');

?>
