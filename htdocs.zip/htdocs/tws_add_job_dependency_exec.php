<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";

   $log_file_name=tws_log('', 'OPEN');
   tws_log('-- START ('.basename(__FILE__).'['.__LINE__.'])');
   $execution_time = tws_getmicrotime();

   tws_doctype("t");
?>
<html>
<head>
   <title>Add Job Dependency Result</title>
   <?php tws_stylesheet(); ?>
</head>
<body>
<?php
   tws_set_window_title();

   if (!tws_permit_action('plan_jobs','Add Dep')) {
      tws_access_denied ();
   }

   tws_import_request_variables("P","rqst_");

   $error_title = 'Incomplete or incorrect submit data';
   $error = '';
   $status = true;

   $selection=tws_gpc_get($rqst_selection, "tws_name;tws_name;tws_datetime;tws_sched_id;tws_name;tws_name;tws_num");
   $arg=tws_gpc_get($rqst_arg, "tws_filter");
   $afteraction=tws_gpc_get($rqst_afteraction, "tws_name");
   $athour=tws_gpc_get($rqst_athour, "tws_num");
   $atminute=tws_gpc_get($rqst_atminute, "tws_num");
   $atplusdays=tws_gpc_get($rqst_atplusdays, "tws_num");
   $untilhour=tws_gpc_get($rqst_untilhour, "tws_num");
   $untilminute=tws_gpc_get($rqst_untilminute, "tws_num");
   $untilplusdays=tws_gpc_get($rqst_untilplusdays, "tws_num");
   $onuntil = $rqst_onuntil ? ';onuntil '.tws_gpc_get($rqst_onuntil, "tws_name") : '';
   $deadlinehour = tws_gpc_get($rqst_deadlinehour, "tws_num");
   $deadlineminute = tws_gpc_get($rqst_deadlineminute, "tws_num");
   $deadlineplusdays = tws_gpc_get($rqst_deadlineplusdays, "tws_num");
   $everyhour=tws_gpc_get($rqst_everyhour, "tws_num");
   $everyminute=tws_gpc_get($rqst_everyminute, "tws_num");
   $privalue=tws_gpc_get($rqst_privalue, "tws_priority");
   $confirmed=tws_gpc_get($rqst_confirmed, "tws_name");

   $followsjobstreamcpu = is_array($rqst_followsjobstreamcpu) ? tws_gpc_get($rqst_followsjobstreamcpu, "tws_name") : array();
   // TODO: validator for 'tws_name;tws_sched_id' in tws_gpc_get
   $followsjobstreamname = is_array($rqst_followsjobstreamname) ? tws_gpc_get($rqst_followsjobstreamname) : array();
   $followsjobcpu = is_array($rqst_followsjobcpu) ? tws_gpc_get($rqst_followsjobcpu, "tws_name") : array();
   $followsjobjobstream = is_array($rqst_followsjobjobstream) ? tws_gpc_get($rqst_followsjobjobstream) : array();
   $followsjobname = is_array($rqst_followsjobname) ? tws_gpc_get($rqst_followsjobname, "tws_name") : array();
   $promptname = is_array($rqst_promptname) ? tws_gpc_get($rqst_promptname, "tws_name") : array();
   $prompttext = is_array($rqst_prompttext) ? tws_gpc_get($rqst_prompttext) : array();
   $openscpu = is_array($rqst_openscpu) ? tws_gpc_get($rqst_openscpu, "tws_name") : array();
   $opensfile = is_array($rqst_opensfile) ? tws_gpc_get($rqst_opensfile, "tws_file") : array();
   $needscpu = is_array($rqst_needscpu) ? tws_gpc_get($rqst_needscpu, "tws_name") : array();
   $resource = is_array($rqst_resource) ? tws_gpc_get($rqst_resource, "tws_name") : array();
   $units = is_array($rqst_units) ? tws_gpc_get($rqst_units, "tws_num") : array();

   tws_check_synchro_token();


   if (tws_yesno(tws_get_tz_status(),TRUE,FALSE)) {
      $time_zone = ($rqst_time_zone!='' && $rqst_time_zone!='NULL') ? ' timezone '.$rqst_time_zone : '';
   } else {
      $time_zone = '';
   }
   $deps="";

   if (($athour != "") && ($atminute != "")) {
      $deps .= ";at=$athour$atminute$time_zone";
      if ($atplusdays != "") {
         $deps .= "+$atplusdays days";
      }
   } elseif (($athour != "") || ($atminute != "")) {
      $error .= "Invalid AT Time specified!\n";
      $status = false;
   }

   if (($untilhour != "") && ($untilminute != "")) {
      $deps .= ";until=$untilhour$untilminute$time_zone";
      if ($untilplusdays != "") {
         $deps .= "+$untilplusdays days";
      }
      $deps .= $onuntil;
   } elseif (($untilhour != "") || ($untilminute != "")) {
      $error .= "Invalid UNTIL Time specified!\n";
      $status = false;
   }

   if (($deadlinehour != "") && ($deadlineminute != "")) {
      $deps .= ";deadline=$deadlinehour$deadlineminute$time_zone";
      if ($deadlineplusdays != "") {
         $deps .= "+$deadlineplusdays days";
      }
   } elseif (($deadlinehour != "") || ($deadlineminute != "")) {
      $error .= "Invalid DEADLINE Time specified!\n";
      $status = false;
   }

   if ($privalue != "") {
      $deps .= ";pri=$privalue";
   }

   if ($everyminute != "") {
      $deps .= ";every=$everyhour$everyminute";
   } elseif (($everyhour != "") || ($everyminute != "")) {
      $error .= "Invalid EVERY Time specified!\n";
      $status = false;
   }

   if ($privalue != "") {
      $deps .= ";pri=$privalue";
   }

   if ($confirmed == "yes") {
      $deps .= ";confirmed";
   }

   // ********    Job to Stream Deps    ******** //
   $first = true;
   foreach ($followsjobstreamname as $key => $value) {
      if ($value != "") {
         //@list($follows_jobstream_name, $follows_jobstream_id) = explode(';', $value);
         $tmp_arr = explode(';', $value);
         $follows_jobstream_name = $tmp_arr[0];
         // $follows_jobstream_id = $tmp_arr[1];
         $deps .= $first ? ';follows=' : ',follows=';
         if ($followsjobstreamcpu[$key] != "")
            $deps .= $followsjobstreamcpu[$key].'#';
         $deps .= $follows_jobstream_name;
         $first = false;
      }
   }

   // ********    Job to Job Deps    ******** //
   $first = true;
   foreach ($followsjobname as $key => $value) {
      if (($value != '') && ($followsjobjobstream[$key] != '')) {
         //@list($follows_job_jobstream_name,$follows_job_jobstream_id)=explode(';',$followsjobjobstream[$key]);
         $tmp_arr = explode(';', $followsjobjobstream[$key]);
         $follows_job_jobstream_name = $tmp_arr[0];
         // $follows_job_jobstream_id = $tmp_arr[1];
         $deps .= $first ? ';follows=' : ',follows=';
         if (!empty($followsjobcpu[$key]))
            $deps .= $followsjobcpu[$key].'#';
         $deps .= $follows_job_jobstream_name.".$value";
         $first = false;
      }
   }

   $first = true;
   foreach ($promptname as $value) {
      if ($value != '') {
        $deps .= $first ? ";prompt=$value" : ",$value";
        $first = false;
      }
   }
   foreach ($prompttext as $value) {
      if ($value != '') {
        $deps .= $first ? ";prompt='".$value."'" : ",'".$value."'";
        $first = false;
      }
   }

   $first = true;
   foreach ($opensfile as $key => $value) {
      if ($value != '') {
         if ($openscpu[$key] != '') {
            $deps .= $first ? ";opens=$openscpu[$key]#$value" : ",$openscpu[$key]#$value";
         } else {
            $deps .= $first ? ";opens=$value" : ",$value";
         }
         $first = false;
      }
   }

   $first = true;
   foreach ($resource as $key => $value) {
      if ($value != '') {
         if ($needscpu[$key] != '') {
            $deps .= $first ? ";needs=$units[$key] $needscpu[$key]#$value" : ",$units[$key] $needscpu[$key]#$value";
         } else {
            $deps .= $first ? ";needs=$units[$key] $value" : ",$units[$key] $value";
         }
         $first = false;
      }
   }

   if ($deps == '') {
      $error .= "No dependencies specified.\n";
      $status = false;
   }

   if ($status) {
      foreach($selection as $val){
         $jb=tws_get_job_data($val);
         // echo "Adding selected dependencies to <em>$jb[cpu]#$jb[schedule]($jb[schedtime]).$jb[job]</em> ... ";

         $command=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/conman", $tws_config['conman_args'], "-gui", "adj $jb[cpu]#$jb[schedid].$jb[job];schedid$deps", hwi_cmd::operator('2>&1',FALSE));
         $stdout=array();
         if (tws_popen($command, $ec, $stdout, $stdout, "N")===FALSE || ($opstatus=tws_process_conman_gui($stdout))!=0) {
            $error_title = 'The add job dependency operation failed';
            $error = array('stdout'=>$stdout);
            $status = false;
         }
         tws_log($stdout);
         tws_log("-- CONMAN EXIT CODE = $ec, OPERATION STATUS = $opstatus");
      }
   }
   else $error = array('attr'=>$error);

   tws_log('-- FINISH ('.basename(__FILE__).'['.__LINE__.'])', 'CLOSE');        //close log file
   $execution_time = tws_getmicrotime() - $execution_time;

   if ($status) {
      $enable_trace = (tws_profile('enable_trace') == 'yes') ? true : false;
      $url = "tws_sjx.php?arg=".urlencode($arg);
      if ($enable_trace) {
         tws_print_head('Add Job Dependency Result', array('__time__' => $execution_time, '__log__' => $log_file_name));
         echo '<div class="message">'."\n";
         echo '<p>The submit operation finished successfully. Click OK button to continue.</p><br/>'."\n";
            echo '<input type="button" value="OK" title="Continue" onclick="closeme(\''.$url.'\');" />'."\n";
         echo '</div>'."\n";
      }
      else {
            echo '<script type="text/javascript">'."\n";
            echo 'closeme("'.$url.'");'."\n";
            echo '</script>'."\n";
      }
   }
   else {
      tws_print_head('Add Job Dependency Result', array('__time__' => $execution_time, '__log__' => $log_file_name));
      tws_err($error_title, $error);
      echo '<form action="tws_add_job_dependency.php" method="post">'."\n";
      echo tws_create_hidden_inputs($_POST);
      echo '<input type="submit" name="action" value="Return to Add Job Dependency" />'."\n";
      echo '</form>'."\n";
   }
?>
</body>
</html>
