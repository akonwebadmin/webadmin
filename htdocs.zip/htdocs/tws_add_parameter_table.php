<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");

   if (isset($_POST['srcaction']))
      $h1 = "$_POST[srcaction] Parameter Table";
   else {
      if ($copy == "yes") $h1 = "Copy Parameter Table";
      elseif ($modify == "yes") $h1 = "Modify Parameter Table";
      else $h1 = "Add Parameter Table";
   }
?>
<html>
<head>
<title><?=$h1 ?></title>
<? tws_stylesheet(); ?>
<script type="text/javascript">
   function ConfirmCancel(objectname,url) {
   $('form').unbind('submit');
      var conftext=confirm('Exit ' + objectname + ' Definition (Changes will be lost) ?');
      if (conftext) {
         if (url==null) return true;
            closeme(url);
      } else {
         return false;
      }
   }
</script>
</head>
<body>
<?php
   tws_set_window_title();
   if (isset($_POST['srcaction'])) {
	  $db_parameter_table['parameter_table_folder'][0]=tws_gpc_get($_POST['parameter_table_folder']);
      $db_parameter_table['parameter_table_name'][0]=$_POST['srcaction']=='Modify' ? $_POST['parameter_table_namex'] : $_POST['parameter_table_name'];
      $db_parameter_table['parameter_table_description'][0]=tws_gpc_get($_POST['parameter_table_description']);
      $db_parameter_table['parameter_table_default'][0]=tws_yesno($_POST['parameter_table_default'], TRUE, FALSE);
      $parameter_name=array();
      $parameter_value=array();
      if (is_array($_POST['parameter_name'])) {
         foreach ($_POST['parameter_name'] as $key=>$pname) {
            $db_parameter_table['parameter_name'][$key]=$pname;
            $db_parameter_table['parameter_value'][$key]=tws_gpc_get($_POST['parameter_value'][$key]);
         }
      }
      ${strtolower($_POST['srcaction'])}='yes';
      $action=$_POST['srcaction'];
   }
   else {
      if (($copy == "yes") || ($modify == "yes")) {

         $num_elements=count($selection);
         if ($num_elements == 0) {
            tws_dyer("No parameter table selected");
         } elseif ($num_elements > 1) {
            tws_dyer("Multiple parameter tables selected. Only one parameter table can be copied at a time");
         }
         
         $db_parameter_table = tws_dbobject_to_array('parameter_table', $selection[0]);
/*         
         if (($db_parameter_table=tws_get_parameter_tables($selection[0]))===FALSE){
            tws_dyer("Unable to list parameter tables");
         }
         if ($db_parameter_table['parameter_table_num']!=1) {
            tws_dyer("Database query failed");
         }

         if (($db_parameter_table_parameters=tws_get_parameters($db_parameter_table['parameter_table_name'][0].'.@'))===FALSE) {
            tws_dyer("Unable to get list of parameters");
         }
         foreach($db_parameter_table_parameters['parameter_name'] as $i=>$pname){
            $db_parameter_table['parameter_name'][$i] = $pname;
            $db_parameter_table['parameter_value'][$i] = $db_parameter_table_parameters['parameter_value'][$i];
         }
*/
         if ($modify=="yes") {
//lock object
            tws_composer_lock("vartable=$selection[0]") or tws_dyer("Unable to lock parameter table '$selection[0]'");
//backup
            if (($original_data=tws_composer_create_from("vartable=$selection[0]"))===FALSE) 
               tws_dyer("Unable to create backup");
         }
      }
   }
   tws_print_head($h1);
   
   if($modify == "yes") $p_action = 'modify';
   elseif($copy == "yes") $p_action = 'copy';
   else $p_action = 'add';
?>
   
<br><br>
<form method=post name="contents" action="tws_add_parameter_table_exec.php" onsubmit="if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Parameter Table',null)) { cancel_button_pressed=false; return false;}">

<? tws_arr_to_form('parameter_table', $p_action, $db_parameter_table); ?>

<br><br>
<?php
   $pt_namex=is_array($db_parameter_table['parameter_table_name']) ? $db_parameter_table['parameter_table_name'][0] : $db_parameter_table['parameter_table_name'];
   echo "<input type=\"hidden\" name=\"srcaction\" value=\"$action\">\n";
   if ($modify == "yes") {
      echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
      echo "<input type=\"hidden\" name=\"parameter_table_namex\" value=\"".$pt_namex."\">\n";
      echo "<input type=\"hidden\" name=\"original_data\" value=\"".htmlspecialchars($original_data)."\">\n";
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Update\" onClick=\"return tws_validate_form()\"/>\n";
   } else {
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Add\" onClick=\"return tws_validate_form()\"/>\n";
   }
   if ($modify=="yes") {
      echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Cancel\" onClick=\"cancel_button_pressed=true;\"/>\n";
   } else {
      echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"button\" value=\"Cancel\" onClick=\"ConfirmCancel('Parameter Table','tws_parameter_tablesx.php')\"/>\n";
   }
   tws_print_synchro_token();  // synchro token
?>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" value="Print" onClick="window.print()">
</form>
</body>
</html>
