<?php
//   HORIZONT Software GmbH, Munich
//

   require_once("tws_functions.php");
   tws_import_request_variables("P","rqst_");

   $action=$rqst_action;
   $calendar_name=tws_gpc_get($rqst_calendar_name,'tws_name');

   switch ($action) {
     case "Save Calendar":
       include("tws_add_calendar_exec.php");
       break;
     case "Cancel":
       tws_composer_unlock("cal=$calendar_name") or tws_dyer("Unable to unlock calendar $calendar_name");
       echo "<script type='text/javascript'>
         if(window.name == 'tws_popup')  window.close();
         else window.location.replace('tws_calendarsx.php')
       </script>\n";
       break;
   }
?>