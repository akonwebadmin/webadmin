<?php
//   HORIZONT Software GmbH, Munich
//

   require_once("tws_functions.php");
   tws_import_request_variables("P","rqst_");

   $action=$rqst_action;
   $selection=tws_gpc_get($rqst_selection, 'tws_name');
   tws_check_selection($action, $selection);
   $arg = tws_gpc_get($_POST['arg'], "tws_filter");

   $calendar_class=$domain=FALSE;

   switch ($action) {
      case "Display":
      case "Definition":
         if (tws_permit_action('database_calendars','Display')) { include("tws_text_display_calendar.php"); }
         break;
      case "Add":
         $copy="no";
         $modify="no";
         if (tws_permit_action('database_calendars','Add')) { include("tws_add_calendar.php"); }
         break;
      case "Copy":
       $copy="yes";
       $modify="no";
       if (tws_permit_action('database_calendars','Copy')) { include("tws_add_calendar.php"); }
       break;
     case "Modify":
       $copy="no";
       $modify="yes";
       if (tws_permit_action('database_calendars','Modify')) { include("tws_add_calendar.php"); }
       break;
     case "Rename":
       if (tws_permit_action('database_calendars','Rename')) { include("tws_rename_calendar.php"); }
       break;
     case "Text Edit":
       if (tws_permit_action('database_calendars','Text Edit')) { include("tws_text_edit_calendar.php"); }
       break;
     case "Delete":
       if (tws_permit_action('database_calendars','Delete')) { include("tws_delete_calendar.php"); }
       break;
     case "Unlock":
       $object="Calendar";
       $srcref="tws_calendarsx.php";
       if (tws_permit_action('database_calendars','Unlock')) { include("tws_unlock.php"); }
       break;
     case "Dependent Objects":
       if (!tws_permit_action('database_calendars','Dependent Objects')) { break; }
       $num_elements=count($selection);
       $disable_query_display = TRUE;
       if ($num_elements == 0) {
          echo "<html>\n<head>\n<title>Calendar Dependent Objects</title>\n";
          tws_stylesheet();
          die("</head>\n<body>\n".tws_set_window_title(null, null, false)."\n<h1>Calendar Dependent Objects</h1>\n<br><br>\n
            <p class=warning>&nbsp;&nbsp;&nbsp;&nbsp;No objects selected</p>\n</body>\n</html>\n");
       } elseif ($num_elements > 1) {

          $rqst_cal_query1 = " ( ";
          $rqst_cal_query2 = " ( ";
          for ($idx=0; $idx<$num_elements; ++$idx) {
             $rqst_cal_query1 .= " (CAL_NAME='$selection[$idx]') OR";
             $rqst_cal_query2 .= " (RCY_ICALENDAR like '$selection[$idx]') OR";
          }
          $rqst_cal_query1 .= " (1=2)) ";
          $rqst_cal_query2 .= " (1=2)) ";

          $rqst_include=array("jobstreams","drafts");
          include("tws_view_calendars_xref_report.php");
          break;
       } else {
          $rqst_calendar=$selection[0];
          $rqst_include=array("jobstreams","drafts");
          include("tws_view_calendars_xref_report.php");
          break;
       }
      case "Notes":
         $type="Calendar";
         if (tws_permit_action('database_calendars','Notes')) { include("tws_notes.php"); }
         break;
    case "Filter":
       include("tws_dbcalendar_filter.php");
       break;
     case "Save Filter":
       $location = "tws_save_filter.php?object=dbcalendar";
       if(!empty($arg)) $location .="&arg=".urlencode($arg);
       header("Location: $location");
       exit;
     case 'Layout':
       $section = 'Database Calendars';
       if (tws_permit_action('common_actions','Layout')) { include 'tws_layout.php'; }
       break;
     default:
         include("tws_calendarsx.php");
   }
?>