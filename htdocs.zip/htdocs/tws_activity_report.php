<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_profile('opener', basename(trim($_SERVER['REQUEST_URI'], '/')));
   tws_doctype("t");
?>
<html>
<head>
   <title>IWS Activity Report</title>
   <?php tws_stylesheet(); ?>

<script type="text/javascript">
   function set_titlebox() {
      if($('#titletext').val() != '' )
         $('#title').attr('checked','checked');
      else
         $('#title').removeAttr('checked');
   }

   function scalechange(val){

      if(val=='day'){
         if($('input[name="contents"][value="all"]').is(':checked')){
            $('input[name="contents"][value="active"]').prop('checked', 'checked');
            $('input[name="contents"][value="all"]').prop('checked', false);
         }
         $('input[name="contents"][value="all"]').prop('disabled', 'disabled');
      }
      else $('input[name="contents"][value="all"]').removeAttr('disabled');
   }
</script>
</head>
<body>
<?php
if(tws_get_menu('TWS_Activity')==0) tws_access_denied();

   tws_set_window_title();
   tws_print_head('IWS Activity Report', 'tws_activity_report_help.php');
?>
<form method=post name="contents" action="tws_view_activity_report.php">
<table border=0 cellspacing=5>
<tr>
<td class=standard><h3>Criteria</h3></td><td></td>
</tr>
<tr><td class=standard>&nbsp;&nbsp;<b>Workstation:</b></td>
<td class=standard><input type="text" name="workstation" class='tws_mask' style="width:20em;" maxlength=320>
&nbsp;&nbsp;<input type="button" name="workstation_list" onClick="tws_picker_open('workstation_picker.php', 'fieldname=workstation&amp;fieldvalue=' + document.contents.workstation.value + '&amp;allowmultiple=yes');" value="List">
</td></tr>

<tr>
<td class=standard><h3>Appearance</h3></td><td></td>
</tr>
<tr><td class=standard>&nbsp;&nbsp;<b>Scale:</b></td>
<td>
<select name=scale onchange="scalechange(this.value);">
  <option value="day">Day</option>
  <option value="week">Week</option>
  <option value="month" selected>Month</option>
  <option value="year">Year</option>
</select>
</td>
</tr>
<tr><td class=standard>&nbsp;&nbsp;<b>Style:</b></td>
<td>
<select name=style>
  <option value="bar" selected>Bar Graph</option>
  <option value="multibar">Multiple Bar Graph (with Status)</option>
  <option value="accbar">Accumulated Bar Graph (with Status)</option>
  <option value="line">Line Graph</option>
  <option value="multiline">Multiple Line Graph (with Status)</option>
  <option value="accline">Accumulated Line Graph (with Status)</option>
</select>
</td>
</tr>
<tr><td class=standard>&nbsp;&nbsp;<b>Color:</b></td>
<td>
<select name=color>
  <option style="background-color: black; color: white" value="black" selected>Black</option>
  <option style="background-color: red" value="red">Red</option>
  <option style="background-color: orange" value="orange">Orange</option>
  <option style="background-color: yellow" value="yellow">Yellow</option>
  <option style="background-color: green; color: white" value="green">Green</option>
  <option style="background-color: blue; color: white" value="blue">Blue</option>
  <option style="background-color: purple; color: white" value="purple">Purple</option>
</select>
</td>
</tr>
<tr><td></td><td class=standard><label><input type="checkbox" name="shadows" value="yes">&nbsp;Bar Graph Shadows</label></td></tr>
<tr><td></td><td class=standard><label><input type="checkbox" name="labels" value="yes">&nbsp;Show Job Count Labels</label></td></tr>
<tr><td class=standard colspan=2>&nbsp;&nbsp;<label><input type="checkbox" name="include_piechart" value="yes" checked>&nbsp;Include Status Piechart</label></td></tr>

<tr>
<td class=standard><h3>Contents</h3></td><td></td>
</tr>
<tr><td class=standard colspan=2>&nbsp;&nbsp;<label><input type="radio" name="contents" value="completed" checked>&nbsp;Completed Jobs</label></td></tr>
<tr><td class=standard colspan=2>&nbsp;&nbsp;<label><input type="radio" name="contents" value="active">&nbsp;Active and Completed Jobs</label></td></tr>
<tr><td class=standard colspan=2>&nbsp;&nbsp;<label><input type="radio" name="contents" value="all">&nbsp;All Jobs</label></td></tr>

<tr>
<td class=standard><h3>Options</h3></td><td></td>
</tr>
<tr><td class=standard colspan=2>&nbsp;&nbsp;<label><input type="checkbox" name="reruns" value="yes">&nbsp;Count Reruns</label></td></tr>
<tr><td class=standard colspan=2>&nbsp;&nbsp;<label><input type="checkbox" name="everys" value="yes">&nbsp;Count Each Iteration of Every Jobs</label></td></tr>

<tr>
<td class=standard>&nbsp;&nbsp;<label><input type="checkbox" name="title" id="title" value="yes">
Set Title:</label></td>
<td class=standard><input type="text" name="titletext" id="titletext" size=40 maxlength=100 onkeyup="set_titlebox();"></td>
</tr>

<tr>
<td class=standard colspan=2>
&nbsp;&nbsp;<label><input type="checkbox" name="opennew" value="yes" onClick="ChngTarg(this.checked)">
Open Report in New Window</label>
</td>
</tr>
</table>

<br><br>
<input type="submit" value="Generate Report" name="action">

</form>
</body>
</html>
