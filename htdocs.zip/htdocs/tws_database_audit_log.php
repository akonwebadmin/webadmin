<?php
//   HORIZONT Software GmbH, Munich
//
   require_once 'tws_functions.php';
   require_once 'tws_filters_lib.php';

   tws_get_filter_from_get($filter, $filter_name);

   tws_profile('opener', basename($_SERVER['REQUEST_URI']));
   tws_doctype('t');
?>
<html>
<head>
<title>IWS Database Audit Log</title>
<? tws_stylesheet();
   tws_save_filter_in_storage();
?>
<script type="text/javascript">

   function doSubmit(actionButton) {
      var action = actionButton.innerHTML;
      var form = document.content;
      form.action.value = action;

      if(action != 'Send as CSV'){
         var param = 'height=600, width=800, left=60, top=50, toolbar=no, menubar=no, location=no, scrollbars=yes, resizable=yes';
         window.open('', 'tws_popup', param);
         form.target = 'tws_popup';
      }
      else form.target = '_self';
      form.submit();
   }
</script>

</head>
<body>
<? if (tws_profile('button_location') != 'bottom')
      echo "<div style='top:0; height:35px;'> </div>\n";
   if(tws_get_menu('Database_Audit_Log')==0) tws_access_denied();

   tws_set_window_title($filter);
   $execution_time = tws_getmicrotime();

   if (!tws_rights(VIEWAUDITLOGS)) {
      echo '<h1>IWS Database Audit Log</h1>'."\n";
      die("<b>IWS/WebAdmin: Permission Denied</b>\n</body>\n</html>\n");
   }
// not used
   tws_import_request_variables("P","rqst_");
   if ((isset($rqst_date_format)) && ($rqst_date_format != "Default")) {
      $date_format=$rqst_date_format;
   } elseif ((isset($rqst_def_date_format)) && ($rqst_date_format != "Default")) {
      $date_format=$rqst_def_date_format;
   }
//
   if (isset($timeout)) {
      set_time_limit($timeout);
   }
   if (isset($filter)) {
      $filterchunks=0;
      $tok=strtok($filter,"+");
      $filterchunks++;
      $filterchunk[$filterchunks]=$tok;
      while ($tok=strtok("+")) {
         $filterchunks++;
         $filterchunk[$filterchunks]=$tok;
      }
      for ($i=1; $i<=$filterchunks; $i++) {
         if (substr($filterchunk[$i],0,17) == "auditlog_columns=") {
            $junk=strtok($filterchunk[$i],"=");
            $auditlog_columns=explode(",",strtok("\n"));
         } elseif (substr($filterchunk[$i],0,10) == "log_types=") {
            $junk=strtok($filterchunk[$i],"=");
            $log_types=explode(",",strtok("\n"));
         } elseif (substr($filterchunk[$i],0,5) == "today") {
            $today=TRUE;
            $singledate=date("Ymd");
         } elseif (substr($filterchunk[$i],0,8) == "alldates") {
            $alldates=TRUE;
         } elseif (substr($filterchunk[$i],0,12) == "single_date=") {
            $junk=strtok($filterchunk[$i],"=");
            $singledate=strtok("\n");
         } elseif (substr($filterchunk[$i],0,8) == "lowdate=") {
            $junk=strtok($filterchunk[$i],"=");
            $lowdate=strtok("\n");
            $lowdate_timestamp=mktime(0,0,0,substr($lowdate,4,2),substr($lowdate,6,2),substr($lowdate,0,4));
         } elseif (substr($filterchunk[$i],0,9) == "highdate=") {
            $junk=strtok($filterchunk[$i],"=");
            $highdate=strtok("\n");
            $highdate_timestamp=mktime(0,0,0,substr($highdate,4,2),substr($highdate,6,2),substr($highdate,0,4)) + 86400;
         } elseif (substr($filterchunk[$i],0,8) == "user_id=") {
            $junk=strtok($filterchunk[$i],"=");
            $user_id_filter=strtok("\n");
         } elseif (substr($filterchunk[$i],0,15) == "framework_user=") {
            $junk=strtok($filterchunk[$i],"=");
            $framework_user_filter=strtok("\n");
         } elseif (substr($filterchunk[$i],0,13) == "object_types=") {
            $junk=strtok($filterchunk[$i],"=");
            $object_types=explode(",",strtok("\n"));
         } elseif (substr($filterchunk[$i],0,12) == "object_name=") {
            $junk=strtok($filterchunk[$i],"=");
            $object_name_filter=strtok("\n");
         } elseif (substr($filterchunk[$i],0,13) == "action_types=") {
            $junk=strtok($filterchunk[$i],"=");
            $action_types=explode(",",strtok("\n"));
         } elseif (substr($filterchunk[$i],0,12) == "workstation=") {
            $junk=strtok($filterchunk[$i],"=");
            $workstation_filter=strtok("\n");
         } elseif (substr($filterchunk[$i],0,12) == "action_data=") {
            $junk=strtok($filterchunk[$i],"=");
            $action_data_filter=strtok("\n");
         }
      }
   } else {
      $filter="today";
      $singledate=date("Ymd");
   }

// Set up column names
   $column_name["log_type"]="Log Type";
   $column_name["timestamp"]="Timestamp";
   $column_name["user_id"]="User ID";
   $column_name["framework_user"]="Framework User";
   $column_name["object_type"]="Object Type";
   $column_name["object_name"]="Object Name";
   $column_name["action_type"]="Action Type";
   $column_name["workstation"]="Workstation";
   $column_name["action_data"]="Action Data";

   if (isset($auditlog_columns) && count($auditlog_columns) > 0) {
      $num_cols=count($auditlog_columns);
   } else {
      $auditlog_columns=array("log_type","timestamp","user_id","framework_user","object_type","object_name","action_type","workstation","action_data");
      $num_cols=9;
   }

   tws_print_head('IWS Database Audit Log', array('__help__' => 'tws_database_audit_help.php', '__filter__' => $filter, '__filter_name__' => $filter_name, '__time__' => (tws_getmicrotime() - $execution_time)));

   if (tws_yesno($tws_config['optmanopts']['endbaudit'],TRUE,FALSE)) {
      $audit_dir = "$maestro_dir/audit/database";
      if($tws_config['cpuinfo']['version']>='9.5' && !empty($tws_config['twsenv']['UNISONWORK']))
         $audit_dir = $tws_config['twsenv']['UNISONWORK']."/audit/database";
      $dir = opendir($audit_dir);

      if($dir == false)
         tws_dyer("Can't open file $audit_dir" );
      $log_count=0;
      while (($file=readdir($dir))!==FALSE) {
         if ($file == "." || $file == "..")
            continue;
         if (isset($singledate) && $singledate != "$file")
            continue;
         if (isset($lowdate) && $file < $lowdate)
            continue;
         if (isset($highdate) && $file > $highdate)
            continue;

         $file="$audit_dir/$file";
         $stdout = tws_get_filecontent($file);
         if (empty($stdout))
            continue;
         foreach ($stdout as $buffer) {
            if ($buffer == "") {
               continue;
            }
            $log_type=trim(strtok($buffer,"|"));
            if (isset($log_types)) {
               if (!in_array($log_type,$log_types)) {
                  continue;
               }
            }

            $temp=strtok("|");
            $temp=strtok("|");
            $date=trim(strtok("|"));
            $time=trim(strtok("|"));
            $year=substr($date,0,4);
            $month=substr($date,4,2);
            $day=substr($date,6,2);

            if (isset($singledate)) {
               if ($singledate != "$year$month$day") {
                  continue;
               }
            } elseif ((isset($lowdate)) || (isset($highdate))) {
               $timestamp=mktime(0,0,0,$month,$day,$year);
               if (isset($lowdate)) {
                  if ($timestamp < $lowdate_timestamp) {
                     continue;
                  }
               }
               if (isset($highdate)) {
                  if ($timestamp >= $highdate_timestamp) {
                     continue;
                  }
               }
            }

            $hour=substr($time,0,2);
            $minute=substr($time,2,2);
            $second=substr($time,4,2);

            $timestamp=tws_iso_to_userdate("$year-$month-$day $hour:$minute:$second");
            $object_type=trim(strtok("|"));
            if (isset($object_types)) {
               if (!in_array($object_type,$object_types)) {
                  continue;
               }
            }

            $action_type=trim(strtok("|"));
            if (isset($action_types)) {
               if (!in_array($action_type,$action_types)) {
                  continue;
               }
            }

            $workstation=trim(strtok("|"));
            if (isset($workstation_filter)) {
               if (!tws_jokercmp($workstation,$workstation_filter)) {
                  continue;
               }
            }

            $user_id=trim(strtok("|"));
            if (isset($user_id_filter)) {
               if (!tws_jokercmp($user_id,$user_id_filter)) {
                  continue;
               }
            }

            $framework_user=trim(strtok("|"));
            if (isset($framework_user_filter)) {
               if (!tws_jokercmp($framework_user,$framework_user_filter)) {
                  continue;
               }
            }

            $object_name=trim(strtok("|"));
            list($tmp, $object_name) = explode('=', $object_name);
            if($object_name=='') $object_name = $tmp;
            if (isset($object_name_filter)) {
               if (!tws_jokercmp($object_name,$object_name_filter, false, 'tws')) {
                  continue;
               }
            }

            $action_data=trim(strtok("|"));
            if (isset($action_data_filter)) {
               if (!tws_jokercmp($action_data,$action_data_filter)) {
                  continue;
               }
            }

            if ($log_count==0) {
               echo "<br><table class='wireframe dtable' id='sortable' cellspacing='0' cellpadding='4' width='100%'>\n";
               echo "<thead><tr class=header>\n";
               for ($i=0; $i<$num_cols; $i++) {
                  $temp=$auditlog_columns[$i];
                  echo "<th class=wireframe>$column_name[$temp]</th>\n";
               }
               echo "</tr></thead>\n";
            }

            echo "<tr class=standard>\n";
            if (in_array("log_type",$auditlog_columns)){
               if ($log_type == "") {
                  $log_type=" ";
               }
               echo "  <td class=wireframe>$log_type</td>\n";
            }
            if (in_array("timestamp",$auditlog_columns)){
               if ($timestamp == "") {
                  $timestamp=" ";
               }
               echo "  <td class=wireframe>$timestamp</td>\n";
            }
            if (in_array("user_id",$auditlog_columns)){
               if ($user_id == "") {
                  $user_id=" ";
               }
               echo "  <td class=wireframe>$user_id</td>\n";
            }
            if (in_array("framework_user",$auditlog_columns)){
               if ($framework_user == "") {
                  $framework_user=" ";
               }
               echo "  <td class=wireframe>$framework_user</td>\n";
            }
            if (in_array("object_type",$auditlog_columns)){
               if ($object_type == "") {
                  $object_type=" ";
               }
               echo "  <td class=wireframe>$object_type</td>\n";
            }
            if (in_array("object_name",$auditlog_columns)){
               if ($object_name == "") {
                  $object_name=" ";
               }
               echo "  <td class=wireframe>$object_name</td>\n";
            }
            if (in_array("action_type",$auditlog_columns)){
               if ($action_type == "") {
                  $action_type=" ";
               }
               echo "  <td class=wireframe>$action_type</td>\n";
            }
            if (in_array("workstation",$auditlog_columns)){
               if ($workstation == "") {
                  $workstation=" ";
               }
               echo "  <td class=wireframe>$workstation</td>\n";
            }
            if (in_array("action_data",$auditlog_columns)){
               if ($action_data == "") {
                  $action_data=" ";
               }
               echo "  <td class=wireframe>$action_data</td>\n";
            }
            $log_count++;
         }
      }
      closedir($dir);

      if ($log_count>0) {
         echo "</table>\n";
      } else {
         echo "<br>\n";
         echo "<p class=warning>No database audit log entries</p>\n";
      }
   } else {
      tws_err("Database audit logs are not enabled.");
   }
?>
<form method="post" name="content" action="tws_database_audit_log_action.php">
<div class='buttons'>
<ul class="menu">
   <li><a href="#" onclick="return false;">Filter</a>
      <ul>
         <li><a href="tws_database_audit_log_filter.php?arg=<?=urlencode($filter)?>">Set Filter</a></li>
         <? if (isset($filter) && $filter!='') {
            echo '<li><a href="#" onclick="doSubmit(this)">Save Filter</a></li>';
            //echo '<li><a href="#" onclick="window.location.href=\'tws_database_audit_log_filter_action.php?action=Clear Filter\'">Clear Filter</a></li>';
         } ?>
      </ul>
   </li>
   <li><a href='#' onclick='return false;'>Display</a>
      <ul>
         <li><a href='#' onclick='doSubmit(this); return false;'>Send as CSV</a></li>
      </ul>
   </li>

   <li><a href='#' onclick='return false;'>Settings</a>
   <ul>
   <li><a href='#' onclick='window.print(); return false;'>Print</a></li>
   </ul>
   </li>
   <li><a href='#' onclick='location.reload(false)'>Refresh</a></li>
</ul>
</div>
<input type='hidden' name='action' value=''>
<input type='hidden' name='arg' value='<?=$filter?>'>
</form>
</body>
</html>
