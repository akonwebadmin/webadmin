<?php
//   HORIZONT Software GmbH, Munich
//

   require_once("tws_functions.php");
   tws_import_request_variables("GP","rqst_");

   $action=tws_gpc_get($rqst_action);
   $object='database_audit';

   if ($action=='Reset Filter'){
      header("Location: tws_database_audit_log_filter.php?arg=");
      exit;
   }
   $auditlog_columns=tws_gpc_get($rqst_auditlog_columns);
   $log_types=tws_gpc_get($rqst_log_types);

   $date = tws_gpc_get($rqst_date);
   $null = null;
   if($date == 'today')
      $today='yes';
   if($date == 'single_date'){
      $regs= tws_userdate_to_regs($rqst_single_date, $null, true);
      $single_date = $regs['Y'].$regs['m'].$regs['d'];
   }
   elseif($date == 'date_range'){
      $regs= tws_userdate_to_regs($rqst_lowdate, $null, true);
      $lowdate = $regs['Y'].$regs['m'].$regs['d'];
      $regs= tws_userdate_to_regs($rqst_highdate, $null, true);
      $highdate = $regs['Y'].$regs['m'].$regs['d'];
   }
   $user_id=tws_gpc_get($rqst_user_id);
   $framework_user=tws_gpc_get($rqst_framework_user);
   $object_types=tws_gpc_get($rqst_object_types);
   $object_name=tws_gpc_get($rqst_object_name, 'tws_mask');
   $action_types=tws_gpc_get($rqst_action_types);
   $workstation=tws_gpc_get($rqst_workstation, 'tws_mask');
   $action_data=tws_gpc_get($rqst_action_data);

   $edit_file=tws_gpc_get($rqst_edit_file, 'tws_file');

   switch ($action) {
      case "Set Filter":
         include("tws_set_database_audit_log_filter.php");
         break;
      case "Clear Filter":
         include("tws_clear_filter.php");
         break;
      case "Load Filter":
         include("tws_load_filter.php");
         break;
      case "Save Filter":
         $redirect = false;                           // flag for set function, not redirect at end - continue
         include('tws_set_database_audit_log_filter.php');
         header("Location: tws_save_filter.php?object=$object&arg=".urlencode($filter)."&edit_file=".urlencode($edit_file));
         exit;
   }
?>