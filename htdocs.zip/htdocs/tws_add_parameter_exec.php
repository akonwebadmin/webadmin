<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add Parameter</title>
<?php
tws_stylesheet();
tws_show_backup();
?>
</head>
<body>
<?php tws_set_window_title(); ?>

<?php
   tws_check_synchro_token();    // synchro_token
   tws_import_request_variables("P","rqst_");

   $action=$rqst_action;
   $parameter_name=tws_gpc_get($rqst_parameter_name, 'tws_name');
   $parameter_table=tws_gpc_get($rqst_parameter_table, 'tws_name');
   $parameter_name=strtoupper(trim($parameter_name));
   $parameter_table=strtoupper(trim($parameter_table));
   $parameter_value=tws_gpc_get($rqst_parameter_value);
   $parameter_value = str_replace("\\\\", "\\", $parameter_value);

   $full_parm_name=($parameter_table!='' ? $parameter_table.'.' : '').$parameter_name;

   if ($action=="Cancel") {
// Unlock the object
      tws_composer_unlock("parm=$full_parm_name") or tws_dyer("Unable to unlock parameter '$parameter_name'");
      echo "<script type='text/javascript'>\n";
         echo "  closeme('tws_parametersx.php');\n";
      echo "</script>\n";
      exit;
   }
   elseif($action=="Return to Modification"){
      include("tws_add_parameter.php");
      exit;
   }

   if (isset($rqst_modify)) {
      if (!tws_permit_action('database_parameters','Modify')) tws_access_denied ();
      $modify=$rqst_modify;
   } else {
      if (!tws_permit_action('database_parameters','Add')) tws_access_denied ();
      $modify="no";
   }
   if (isset($rqst_confirm))
      $confirm=$rqst_confirm;
   else
      $confirm="no";

   if (isset($rqst_backup))
      $backup=$rqst_backup;
   else
      $backup="no";

   $original_data=tws_gpc_get($rqst_original_data);

// Check for existing parameter
   $match=FALSE;
   if ($confirm != "yes") {
      if (($db_parameter = tws_get_parameters($full_parm_name)) === FALSE) {
         tws_dyer("Unable to list parameters");
      }
      if ($db_parameter['parameter_num'] > 1) {
         tws_dyer("Database query error");
      }
      $orig_ptable = $db_parameter['parameter_table'][0];
      if ($tws_config['cpuinfo']['version']>='9.5002')
          $orig_ptable = $db_parameter['parameter_table_folder'][0].$orig_ptable;
      if (($db_parameter['parameter_num'] == 1) && ($parameter_name == $db_parameter['parameter_name'][0]) && ($parameter_table == $orig_ptable)) {
         $orig_parm_value = $db_parameter['parameter_value'][0];
         $match = TRUE;
      }
   }
   if ($match == TRUE) {
      if ($modify == "yes") {
         echo "<h1>Confirmation</h1>\n";
      } else {
         echo "<h1>Replace Parameter Confirmation</h1>\n";
      }
      echo "<br><br>\n";
      echo "<h3>Confirm:</h3>\n";
      if ($modify != "yes") {
         echo "&nbsp;&nbsp;<b>The Parameter Name entered already exists</b>\n";
         echo "<br><br>\n";
      }
      $orig_parm_data = Array ( 'parameter_name' => $full_parm_name, 'parameter_value' => $orig_parm_value );
      $new_parm       = Array ( 'parameter_name' => $full_parm_name, 'parameter_value' => $parameter_value );
      $label_map      = Array ( 'parameter_name' => 'Name' , 'parameter_value' => 'Value' );

      tws_show_cmp_table("Original Parameter", "New Parameter", $orig_parm_data, $new_parm, $label_map);

// confirmation form
      echo "<form method=post name=\"confirm\" action=\"tws_add_parameter_exec.php\">\n";
      echo "<input type=\"hidden\" name=\"confirm\" value=\"yes\">\n";
      if ($original_data=='') {
         //missing original data - this happens if user is adding parameter that already exists.
         if (($original_data=tws_composer_create_from("parm=$full_parm_name"))===FALSE) {
            tws_err("Unable to get original data required to create backup.");
         }
      }
      echo "<input type=\"hidden\" name=\"original_data\" value=\"".htmlspecialchars($original_data)."\">\n";
      echo "<input type=\"hidden\" name=\"parameter_table\" value=\"".htmlspecialchars($parameter_table)."\">\n";
      echo "<input type=\"hidden\" name=\"parameter_name\" value=\"".htmlspecialchars($parameter_name)."\">\n";
      echo "<input type=\"hidden\" name=\"parameter_value\" value=\"".htmlspecialchars($parameter_value)."\">\n";

      if (tws_rights(SAVEBACKUPS) && $original_data!=''){
         echo "<input type='hidden' name='backup' value='yes'>";
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type='checkbox' name='backup' value='yes' checked disabled>&nbsp;Save Backup Copy of Original Parameter</label>\n";
      }
      else
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type=\"checkbox\" name=\"backup\" value=\"yes\" ".($original_data!='' ? 'checked' : 'disabled').">&nbsp;Save Backup Copy of Original Parameter</label>\n";
      echo "<br><br><br>\n";
      if ($modify == "yes") {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Update\" name=\"action\">\n";
         echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
         echo "<input type=\"hidden\" name=\"parameter_tablex\" value=\"".htmlspecialchars($parameter_table)."\">\n";
         echo "<input type=\"hidden\" name=\"parameter_namex\" value=\"".htmlspecialchars($parameter_name)."\">\n";
      } else {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Replace\" name=\"action\">\n";
      }
      echo '&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Return to Modification">'."\n";
      echo '&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Cancel">'."\n";
      tws_print_synchro_token();   // synchro_token
      echo "</form>\n";
   } else {
// Create Backup Copy if option checked
      if ($backup == "yes") {
         if (($bckfilename = tws_write_backup($original_data, "parameter", $full_parm_name)) === FALSE) {
            tws_dyer("Unable to write backup");
         }
      }
// unlock the object
      tws_composer_unlock("parm=$full_parm_name");

// modify/add new parameter
      $tmpfilename="$maestro_dir/webadmin/tmp/parameter.".tws_rndstr().".tmp";
      $fp=fopen($tmpfilename,'w') or tws_dyer("Unable to create temporary file '$tmpfilename'");

      $cmd = tws_arr_to_composer('parameter', $_POST);

         $num_bytes=fwrite($fp,$cmd);
         if ($num_bytes < 0) {
            fclose($fp);
            tws_dyer("Unable to write temporary file '$tmpfilename'");
         }
      fclose($fp);
      tws_chmod($tmpfilename,0644);

      if ($confirm == "yes") {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "replace $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      } else {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "add $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      }

      $stdout3='';
      $ec_popen=tws_popen($command3, $ec3, $stdout3, $stdout3, "N");

      //testing for the AWSBIA288I Total objects updated: 0.
      //Note: This has been added on 2016-07 to fix the problem of composer updating
      //correctly objects but returning incorrect return codes (not 0 or 4)
      $not_updated=!preg_match('/AWSBIA288[^\n]+(\d+)/', $stdout3, $_r) || $_r[1]==0;

      if ($ec_popen===FALSE || ($ec3!=0 && $ec3!=4 && $not_updated)) {
         if ($modify == "yes") {
            echo "<h1>Modify Parameter Status</h1>\n";
         } else {
            echo "<h1>Add Parameter Status</h1>\n";
         }
         tws_err("Parameter add/modify operation failed", array('twscmd'=>$command3->compile('log'), 'stdout'=>$stdout3, "EC_POPEN"=>$ec_popen, "EC_UPDATED"=>$ec3, "NOT_UPDATED"=>tws_yesno($not_updated,'YES','NO')));
         echo "<form action='tws_add_parameter_exec.php' method='post' onsubmit=\"if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Workstation',null)) { cancel_button_pressed=false; return false;}\">\n";
         echo tws_create_hidden_inputs($_POST);
         tws_print_synchro_token();
         echo "<input type='submit' name='action' value='Cancel' onClick='cancel_button_pressed=true;'/>\n";
         echo "<input type='submit' name='action' value='Return to Modification'/>\n";
         echo "</form>";
      } elseif (preg_match("/warnings?\s[1-9]/i",$stdout3)) {
         if ($modify == "yes") {
            $headertext="Modify Parameter";
         } else {
            $headertext="Add Parameter";
         }
         tws_err("The Parameter has been saved with the following warnings:", array('stdout'=>$stdout3));

         $shortwarnfilename="warn.".tws_rndstr().".txt";
         $warnfilename="$webadmin_tmp_dir/$shortwarnfilename";
         $warnfp=fopen("$warnfilename","w") or tws_dyer("Unable to create warning text file", "Warning output :\n$stdout3");
         $num_bytes=fwrite($warnfp,"$stdout3");
         if ($num_bytes < 0) {
            fclose($warnfp);
            unlink($warnfilename);
            tws_dyer("Unable to write warning text file", "Warning output :\n$stdout3");
         }
         fclose($warnfp);
         tws_dyer();
      } else {
         if ($backup == "yes") {
            if ($modify == "yes") {
               echo "<h1>Modify Parameter Status</h1>\n";
            } else {
               echo "<h1>Add Parameter Status</h1>\n";
            }
            echo "<p class=\"message\">\n";
            echo "The parameter has been successfuly saved.&nbsp;";
            //remove the tmp file now
            unlink($tmpfilename);
            $bckfilename = preg_replace("/\\\\/", '/', $bckfilename);
            $file = explode('/',$bckfilename);
            $file = end($file);
            if(tws_profile('auth_user_group')=='admin')
               echo "<a href=\"javascript:showBackup('$file')\">Display Backup File</a>\n";
            echo "</p>\n";
               echo "<input type='button' value='OK' onClick=\"closeme('tws_parametersx.php')\">\n";
         } else {
            echo "<script type='text/javascript'>\n";
               echo "closeme('tws_parametersx.php');\n";
            echo "</script>\n";
         }
      }
   }
?>
</body>
</html>
