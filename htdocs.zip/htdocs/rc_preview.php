<?php
//   HORIZONT Software GmbH, Munich
//
require_once "tws_functions.php";

   if (defined('IWD_PROCMAN')) {
      $eold=error_reporting(E_ERROR | E_WARNING);
      $de_old=ini_get('display_errors');
      ini_set('display_errors', 0);
   }

// dows
$dows = array(0=>'Su', 1=>'Mo', 2=>'Tu', 3=>'We', 4=>'Th', 5=>'Fr', 6=>'Sa');

// find period
// $calendar_from - show calendar from the begining of current month or from JS valid_from if later
// $calendar_to - if exist JS valid_to or 12 month from the current month

$today_jd = my_cal_to_jd(date("m"), date("d"), date("Y")); // today

$tmp = my_cal_from_jd($today_jd);
$curyear = $tmp['year'];
$curmonth = $tmp['month'];

// Get arguments:
// 17470: Runcycle preview not processing all parameters:
//  
// GET length is limited, so now we put all arguments in session, 
// GET parameter has only pointer to this arguments: ($_GET['elemid'])
// arguments are stored in SESSION['rc_preview'][$elemid];
if(isset($elemid) || isset($_GET['elemid'])){
   if(!empty($_GET['elemid']))
      $elemid = tws_gpc_get($_GET['elemid'], 'tws_num');
   $rc_post = tws_profile("rc_preview");
   if(!empty($rc_post[$elemid])){
      $tt = explode('&', $rc_post[$elemid]);
      foreach($tt as $arg){
         list($key, $val) = explode('=', $arg);
         $val = urldecode($val);
         if(preg_match('/(\w*)\[(\d*)\]\[(\d*)\]/', $key, $r)){    // two dimentional array
            $args[$r[1]][$r[2]][$r[3]] = $val;   
         }
         elseif(preg_match('/(\w*)\[(\d*)\]/', $key, $r))         // one dimentional array
            $args[$r[1]][$r[2]] = $val;   
         else $args[$key] = $val;                                 // string
      }
      // unset($rc_post[$elemid]);        // don't delete args from session to use in prev/next year
      // tws_profile("rc_preview", $rc_post);
      if(!empty($_GET['foryear']))
         $args['foryear'] = tws_gpc_get($_GET['foryear'], 'tws_num');
   }
   else $args = $_GET;
}
else $args = $_GET;

// Process arguments from - to: 
if(!empty($args['foryear']) && $args['foryear'] != $tmp['year']){
   $min_jd = my_cal_to_jd(1, 1, $args['foryear']);
   $max_jd = my_cal_to_jd(12, 31, $args['foryear']);
   $next_year = $args['foryear']+1;
   $prev_year = $args['foryear']-1;
   //unset($args['foryear']);
}
else{
   $min_jd = my_cal_to_jd(1, 1, $tmp['year']);
   if(isset($_GET['send']))   // export two years
      $max_jd = my_cal_to_jd(1, 1, $tmp['year']+2);
   else
      $max_jd = my_cal_to_jd($tmp['month'], 1, $tmp['year']+1);
   $year_end = my_cal_to_jd(1, 1, $tmp['year']+1);
   $month_begin = my_cal_to_jd($tmp['month'], 1, $tmp['year']);
   $next_year = $tmp['year']+1;
   $prev_year = $tmp['year']-1;
}

// prepare args for next/prev year links
$year_link = ''; 

foreach($args as $var=>$val){    // not need, see below $elemid
   if(is_array($val)){
      foreach($val as $i=>$str){
         if(is_array($str)){     // two-dimentional arrays (single dates only) 
                                 // neither recursion, no QUERY_STRING can't be used
            foreach($str as $j=>$str2)
               $year_link .= $var.'['.$i.']['.$j.']='. urlencode($str2)."&";
         }
         else 
            $year_link .= $var.'['.$i.']='. urlencode($str)."&";
      }
   }
   elseif($var!='foryear')
      $year_link .= "$var=".urlencode($val)."&";
}
if(isset($elemid)) // rewrite $year_link if POST request 
   $year_link = "elemid=$elemid&";

if(defined('IWD_PROCMAN') || tws_profile('dialog_type')=='modal'){
   $prev_year_click = "tws_url_close('rc_preview'); tws_url_open('rc_preview.php?".$year_link."foryear=$prev_year', 'rc_preview', 900);";
   $next_year_click = "tws_url_close('rc_preview'); tws_url_open('rc_preview.php?".$year_link."foryear=$next_year', 'rc_preview', 900);";
}
else{
   $prev_year_click = "window.location.replace('rc_preview.php?".$year_link."foryear=$prev_year')";
   $next_year_click = "window.location.replace('rc_preview.php?".$year_link."foryear=$next_year')";
}

if(!empty($args['validfrom'])) { // jobstream validfrom
   if(!preg_match('/(\d{4})-(\d{2})-\d{2}/', $args['validfrom']))
      $js_validfrom = tws_userdate_to_iso($args['validfrom']);
   else $js_validfrom = $args['validfrom'];  // ISO goes from test mode
   $js_validfrom = date_parse($js_validfrom);
   $js_validfrom = my_cal_to_jd($js_validfrom['month'], $js_validfrom['day'], $js_validfrom['year']);
}
else $js_validfrom=null;

if(!empty($args['validto']) ) {      // jobstream validto
   $js_validto = date_parse($args['validto']);
   $js_validto = my_cal_to_jd($js_validto['month'], $js_validto['day'], $js_validto['year']);
}
else $js_validto=null;

// take one more month from previous and next years 
// 
$min_show = $min_jd;
$min_jd -= 30;
$max_show = $max_jd;
$max_jd += 30;

// build calendar for this year
$rc_year = array();
for ($i = $min_jd; $i< $max_jd; $i++) {
   $rc_year[$i] = my_cal_from_jd($i);
}
// get free days
   $freedays_option = $args['freedays_option'];
   $freedays_sat = $args['freedays_sat'];
   $freedays_sun = $args['freedays_sun'];
   $sun_free=false; $sat_free=false;   
   if(empty($freedays_option) || $freedays_option =='default') {
      $sun_free=true; $sat_free=true;
   }
   else {
      if(isset($freedays_sun)) $sun_free=true;
      if(isset($freedays_sat)) $sat_free=true;
   }
//  get freedays calendar
if($freedays_option=='specify'){
   if( !empty($args['freedays_calendar']))
      $freedays_calendar = $args['freedays_calendar'];
}
else{
   $tmp = tws_get_calendars('HOLIDAYS');
   if($tmp['calendar_num']==1)
      $freedays_calendar = 'HOLIDAYS';
   else $freedays_calendar = '';    // have no 'HOLIDAYS' calendar
}
// mark freedays in $rc_year[$jd]['free'] = true
   mark_freedays($freedays_calendar);

   // all this groups must be calculated separately
   $rcg_dates = array();   // runcycle groups
   $rcgroups_dates  = array();   //we are inside runcycle groups
   $at_dates = array();    // at_time groups in normal runcycles
   $rc_dates = array();   // normal runcycles

   $startofday=$tws_config['optmanopts']['startofday'];
   if(empty($startofday)){
      $startofday='0000';
      tws_error("Unable to get 'start of day' value from optman. Using the default value '$startofday'.");
   }
   
/**************  process runcycles **************/   
   
// first process RCG
   foreach($args['rc_on_except'] as $i => $rc_on_except){
      $rcg_at = false;
      if($args['rc_type'][$i] != 'G') continue;  // RCG
      $dates = tws_get_rcg_dates($args['rcg'][$i]);    // parametr is rcg_name
      // apply rcg parameters to $dates (Offset with offsettype, Freedays rule, Valid from/to)
      $rcg_params = tws_select_param($args, $i);
      $dates = set_rcg_offsets($dates, $rcg_params);

      // ticket 17751: JS with RCG are forecasted one day earlier if startofday = 0000
      // UPD: on TWS 9.4 it's ok
      if($tws_config['cpuinfo']['version']<'9.4'){
         if($startofday == '0000' && $rcg_at == false) 
            foreach($dates as $i=>$date)
               $dates[$i]--;
      }
      // union all into $rcg_dates
      $rcg_dates = array_merge($rcg_dates, $dates);
   }
   
// process $rcgroups_date groups i.e. we are inside RCG
if(isset($args['rc_subset'])){
   $rcgroup_dates = get_rcgroup_dates($args);
   $rcgroup_group = true;     // to exclude them from other RC
}
else{   
// check at_time groups:
   $at_groups = get_at_groups();
   $at_list = array();     // to exclude them from other RC
   foreach($at_groups as $list){
      $at_list = array_merge($at_list, $list);
      $dates = get_at_dates($list);
      $at_dates = array_merge($at_dates, $dates);
   }

// process all other normal RC   
   foreach($args['rc_on_except'] as $i => $rc_on_except){   // ON
      if($args['rc_type'][$i] == 'G' || in_array($i, $at_list)) continue;
      $arg = tws_select_param($args, $i);
      if($rc_on_except == 'ON'){
         $dates = preview_rule($arg);
         $rc_dates = array_merge($rc_dates, $dates);
      }
   }
   foreach($args['rc_on_except'] as $i => $rc_on_except){   // EXCEPT
      if($args['rc_type'][$i] == 'G' || in_array($i, $at_list)) continue;
      $arg = tws_select_param($args, $i);
      if($rc_on_except == 'EXCEPT'){
         $dates = preview_rule($arg);
         $rc_dates = array_diff($rc_dates, $dates);
      }
   }
   
// put $rcg_dates into year calendar
   foreach($rcg_dates as $jd)
      $rc_year[$jd]['inc'] = 'rc_inc';
// put $at_dates into year calendar
   foreach($at_dates as $jd)
      $rc_year[$jd]['inc'] = 'rc_inc';
// put $rc_dates into year calendar
   foreach($rc_dates as $jd)
      $rc_year[$jd]['inc'] = 'rc_inc';
}   
// if we are inside RCG
// put $rcgroup_dates into year calendar
   foreach($rcgroup_dates as $jd)
      $rc_year[$jd]['inc'] = 'rc_inc';


//    set Offset with offsettype, Freedays rule, Valid from/to for RCG dates
function set_rcg_offsets($dates, $rcg_params){
   global $rc_year;
   // offset (+/- days )
   if(!empty($rcg_params['rcg_offsetvalue'])){
      if($rcg_params['rcg_offsettype'] == 'DAYS'){
         foreach($dates as $i=>$date)
            $dates[$i] += $rcg_params['rcg_offsetvalue'];
      }              
      else{
         // cut and set sign
         $rcg_offsetvalue = $rcg_params['rcg_offsetvalue'];
         if($rcg_offsetvalue[0] == '-'){
            $sign = -1;
            $rcg_offsetvalue = substr($rcg_offsetvalue, 1);
         } 
         if($rcg_offsetvalue[0] == '+'){
            $sign = 1;
            $rcg_offsetvalue = substr($rcg_offsetvalue, 1);
         } 
         else $sign = 1;
         // offset by WEEKDAYS
         if($rcg_params['rcg_offsettype'] == 'WEEKDAYS'){
         // set offset
            foreach($dates as $i=>$date){
               $actual_date = $date;      // new calculated date
               $j=0;    // shift
               while(1){
                  $actual_date += $sign;
                  if($rc_year[$actual_date]['dow'] != 0 && $rc_year[$actual_date]['dow'] != 6){
                     $j++;
                     $dates[$i] = $actual_date;
                  }
                  if($j >= $rcg_offsetvalue) break;
               }
            }
         }
         elseif($rcg_params['rcg_offsettype'] == 'WORKDAYS'){
            foreach($dates as $i=>$date){
               $actual_date = $date;      // new calculated date
               $j=0;    // shift
               while(1){
                  $actual_date += $sign;
                  if(($rc_year[$actual_date]['dow'] == 0 && $rcg_params['freedays_sun']=='Y') || ($rc_year[$actual_date]['dow'] == 6 && $rcg_params['freedays_sat']=='Y'))
                     continue;
                  else{   
                     $j++;
                     $dates[$i] = $actual_date;
                  }
                  if($j >= $rcg_offsetvalue) break;
               }
            }
         }
      }
   }
   // Freedays rule
   foreach($dates as $i=>$date){
      if(empty($rc_year[$date]['free'])) continue; 
      // for free days only: 
      if($rcg_params['rc_freedaysrule'] == 'fdignore')   // Don't run
         unset($dates[$i]);
      elseif($rcg_params['rc_freedaysrule'] == 'fdprev'){
         $j=0;
         while(!empty($rc_year[$date-$j]['free'])){
            $j++;
            $dates[$i]--;
         }
      }
      elseif($rcg_params['rc_freedaysrule'] == 'fdnext'){
         $j=0;
         while(!empty($rc_year[$date+$j]['free'])){
            $j++;
            $dates[$i]++;
         }
      }
   }
   return $dates;
}

//     return rcg dates under rcg name
function tws_get_rcg_dates($rcg_name){
   global $rcg_at;

   $rcg_dates = array();
   $rc_list = tws_get_rcg_runcycle_data($rcg_name);   // rc in rcg
   if(empty($rc_list)) return $rcg_dates;
   
   $rc_list = $rc_list['rc'];    // it have such a structure for composer 

   // Divide on subsets   
   foreach($rc_list['rc_subset'] as $i=>$subset){
      // get all $i-th data from $rc_list and put it in appropriate subset
      $rcg_subsets[$subset][] = divide_subsets($rc_list, $i);   
   }   
   
   //foreach($rcg_subsets as $subset_name => $subset_values)
   //   $subset_dates[$subset_name] = get_rc_list_dates($subset_values);
   
   $res = array();   
   
   foreach($rcg_subsets as $name=>$arr){
      $acc = array();
      $and_arr = array();  // 
      $first_and = true;   // 
      foreach($arr as $i=>$args){
         if($args['rc_on_except'] == 'ON' ){
            if($args['rc_athour'] != '' && $args['rc_atminute']!='')
               $rcg_at = true;
            $subset_dates = preview_rule($args);
            if($args['rc_and'] == 'A'){   // logical and rule (only ON rules can have)
               if($first_and){   // first and rule
                  $first_and = false;
                  $and_arr = $subset_dates;
               }
               else $and_arr = array_intersect($and_arr, $subset_dates);
            }
            else 
               $acc = array_merge($acc, $subset_dates);
         }
      }
      $acc = array_merge($acc, $and_arr);    // add dates from 'and' array
      foreach($arr as $i=>$args){
         if($args['rc_on_except'] == 'EXCEPT' ){
            $subset_dates = preview_rule($args);
            $acc = array_diff($acc, $subset_dates);
         }
      }
      $res[$name] = $acc;     // own dates for each subset
   }
   foreach($res as $name=>$dates)   // union all subsets
      $rcg_dates = array_merge($rcg_dates, $dates);
   
   return $rcg_dates;
}

// get all $i-th data from $rc_list
function divide_subsets($rc_list, $i){
   $res = array();
   foreach($rc_list as $param => $val)
      $res[$param] = $val[$i];
   return $res;
}

// check if runcycles are grouped by at_time
function get_at_groups(){
   global $args;
   $at_groups = array();
   if(empty($args['rc_athour']))
      return $at_groups;
   
   foreach($args['rc_athour'] as $i => $rc_athour){
      if(!empty($rc_athour) && !empty($args['rc_atminute'][$i])){
         $at_groups[$rc_athour.$args['rc_atminute'][$i]][] = $i;
      }
   }
   // if there are some groups?
   foreach($at_groups as $at=>$i){
      if(count($at_groups[$at]) < 2)
         unset($at_groups[$at]);
   }
   // remove grouped rc from normal rc 
   foreach($at_groups as $at=>$i){
      unset($args['rc_on_except'][$i]);
   }
   return $at_groups;
}

function get_at_dates($list){
   global $args;
   $at_dates = array();
   
   foreach($list as $i){   // ON
      $arg = tws_select_param($args, $i);
      if($arg['rc_on_except'] == 'ON'){
         $dates = preview_rule($arg);
         $at_dates = array_merge($at_dates, $dates);
      }
   }
   foreach($list as $i){   // EXCEPT
      $arg = tws_select_param($args, $i);
      if($arg['rc_on_except'] == 'EXCEPT'){
         $dates = preview_rule($arg);
         foreach($dates as $date){
            $found = array_search($date, $at_dates);
            if($found)
               unset($at_dates[$found]);
         }
      }
   }
   return $at_dates;
}

// ===================================================================== //

// SEND AS CSV
if(isset($_GET['send'])){
   header ("Content-disposition: attachment; filename=rc_prev.txt");
   header ("Content-type: application/octet-stream");
   header ("Pragma: no-cache");
   header ("Expires: 0");

   foreach($rc_year as $jd=>$val) {
      if($jd>$max_show || $jd<$min_show) continue;
      if( (!empty($js_validfrom) && $jd < $js_validfrom) || (!empty($js_validto) && $jd >= $js_validto) )         
            continue;
      if($val['inc'])
         echo($val['year'].'-'.$val['month'].'-'.$val['day']."\n");
   }
   exit;
}
// TEST MODE
// The same as previous, but write it in file tmp/rc_prev.txt
// var_dump($args['test']);
//$args['test'] = 'YES';
if(isset($args['test'])){
   $fp = @fopen("$webadmin_tmp_dir/rc_tests.txt", "w");
   if($fp == false){
      echo "Can't open file $webadmin_tmp_dir/rc_tests.txt for write"; 
   }
   //else echo "file $webadmin_tmp_dir/rc_tests.txt is opened for write";
   $test_result = '';
   foreach($rc_year as $jd=>$val) {
      if($jd>=$max_show || $jd<$min_show) continue;
      if( (!empty($js_validfrom) && $jd < $js_validfrom) || (!empty($js_validto) && $jd >= $js_validto) )
            continue;
      if(!empty($val['inc']) && $val['year'] == $curyear){
         //fwrite($fp, $val['year'].sprintf('%02d', $val['month']).sprintf('%02d', $val['day'])."\n");
         fwrite($fp, $val['year'].'-'.sprintf('%02d', $val['month']).'-'.sprintf('%02d', $val['day'])."\n");
      }
   }
   fclose($fp);
   exit;
}
//    Main page: draw calendar with run (and free) days from $rc_year[$jd] array 

tws_doctype("t");
?>
<html>
<head>
   <?php tws_stylesheet(); ?>
   <style>
      .hide{
         display: none;
      }
   </style>
</head>
<body>
<div id="rc_preview">
   <table border=0 style="width:200px; margin: 0 auto; border-collapse:collapse;"><tr valign="middle">
      <td align="right" ><img id="moveleft" src="images/MoveLeft.gif" style="cursor:pointer" onclick="<?=$prev_year_click?>"/>&nbsp;&nbsp;</td>
      <td align="center">
      <? if(!empty($args['foryear'])) echo "<b>".htmlspecialchars($args['foryear'])."</b>";
         else echo "<b>$curyear</b>";
      ?>
      </td>
      <td align="left">&nbsp;&nbsp;<img id="moveright" src="images/MoveRight.gif" style="cursor:pointer" onclick="<?=$next_year_click?>"/></td>
      </tr></table>
   <table>
   <tr style="border-bottom:2px solid black">
<?php
 // Draw calendar table  
 // days of week
 $firstdow = tws_profile('firstdow');
 if(!isset($firstdow) || $firstdow=='') $firstdow = 0;

 echo "<td></td><td></td>";
 for($i=0, $j=$firstdow; $i<37; $i++, $j++){
   if($j>6) $j=0;
   if (($j==0 && $sun_free) || ($j==6 && $sat_free))
      echo "<td class='red' style='border-bottom:1px solid black'>$dows[$j]</td>";
   else
      echo "<td style='border-bottom:1px solid black'>$dows[$j]</td>";
 }
  $month=0; $year=0;
 
foreach($rc_year as $jd=>$val) {
   if($jd>$max_show || $jd<$min_show) continue;
   if(!empty($month_begin) && $jd < $month_begin) $class = 'year_begin';
   elseif(!empty($year_end) && $jd < $year_end) $class = 'month_begin';
   elseif(!empty($year_end) && $jd >= $year_end) $class = 'next_year hide';
   else $class = '';
   // month
   if($val['month'] != $month) {
      $month = $val['month'] ;
      if ($val['year'] != $year) {
         $year = $val['year'];
         echo "</tr>\n<tr class='$class'><td>".$year.'</td><td>'.$val['abbrevmonth'].'</td>';
      }
      elseif($year== $curyear && $month == $curmonth)
         echo "</tr>\n<tr class='$class'><td><span class='curmonth'>".$year.'</span></td><td>'.$val['abbrevmonth'].'</td>';
      else
         echo "</tr>\n<tr class='$class'><td></td><td>".$val['abbrevmonth'].'</td>';

      // start from monday
      if ($firstdow==1) {
         for($i=$val['dow']; $i>1 || $i==0; $i--) {
            if($i==0) $i=7;
            echo "<td> </td>";
         }
      }  // start from sunday
      else {
         for($i=$val['dow']; $i>0; $i--) {
            echo "<td> </td>";
         }
      }
   }
   // day
   if(($val['dow']==0 && $sun_free) || ($val['dow']==6 && $sat_free) || !empty($val['free'])) $free_day = 'red';
   else $free_day = '';
   //             TITLE
   $title='';
   $style='';
   if(!empty($val['rc'])){
      $on=''; $ex='';
      foreach($val['rc'] as $rc_num){
         if($args['rc_on_except'][$rc_num] == 'ON'){
            $on .= "On ".$args['rc_name'][$rc_num];
            if( !empty($val['fd']) && in_array($rc_num, $val['fd']) && $args['rc_freedaysrule'][$rc_num] == 'fdprev')
               $on .= ' Run previous day';
            elseif( !empty($val['fd']) && in_array($rc_num, $val['fd']) && $args['rc_freedaysrule'][$rc_num] == 'fdnext')
               $on .= ' Run next day';

            if($args['rc_type'][$rc_num]=='C' && !empty($args['offsetvalue'][$rc_num]) )  // Calendar offset
               $on .= " ".$args['offsetvalue'][$rc_num]." days offset";
            if(!empty($args['rc_time_dep'][$rc_num]) && !empty($args['rc_atplusdays'][$rc_num]))
               $on .= " +".$args['rc_atplusdays'][$rc_num]." days delay";
            $on .= "\n";
         }
         elseif($args['rc_on_except'][$rc_num] == 'EXCEPT'){
            $ex .= "Except ".$args['rc_name'][$rc_num];
            if($args['rc_type'][$rc_num]=='C' && !empty($args['offsetvalue'][$rc_num]) )  // Calendar offset
               $ex .= " ".$args['offsetvalue'][$rc_num]." days offset";
            if(!empty($args['rc_time_dep'][$rc_num]) && !empty($args['rc_atplusdays'][$rc_num]))
               $ex .= " +".$args['rc_atplusdays'][$rc_num]." days delay";
            $ex .= "\n";
         }
      }
      if(!empty($on))
         $title .= $on;
      if(!empty($ex)){
         $title .= $ex;
         //$style .= 'text-decoration:line-through;';
      }
   }
   if(!empty($title)) $style .= 'cursor:pointer;';
   if( (!empty($js_validfrom) && $jd < $js_validfrom) || (!empty($js_validto) && $jd >= $js_validto) )   // don't display days where jobstream is not valid
      echo "<td> </td>";
   else
      echo '<td class="'.$free_day.' '.@$val['inc'].'" title="'.trim($title).'" style="'.$style.'">'.$val['day'].'</td>';
}
   echo "</tr>\n";
?>
</table>
   <? if(empty($args['foryear'])){?>
   <div style="float:left">
      <img id="movedown" src="images/MoveDown.gif" style="cursor:pointer" onclick="MoveDown()"/>
   </div>
   <? } ?>
</div>
<script type="text/javascript">
$(document).ready(function () {
   $('span.curmonth').hide();
});

function MoveDown(){
   if($('img#movedown').attr('src') == 'images/MoveDown.gif'){
      $('tr.year_begin').hide();
      $('tr.next_year').css('display', '');
      $('tr.next_year').removeClass('hide'); // all things with 'hide' class are made because of auto-height in modal dialogs
      $('img#movedown').attr('src', 'images/MoveUp.gif');
      $('span.curmonth').css('display', '');
   }
   else{
      $('tr.year_begin').css('display', '');
      $('tr.next_year').hide();
      $('img#movedown').attr('src', 'images/MoveDown.gif');
      $('span.curmonth').hide();
   }
}
</script>
</body>
</html>
<?
   if (defined('IWD_PROCMAN')) {
      error_reporting($eold);
      ini_set('display_errors', $de_old);
   }

         /***  That's all :)   ***/


// Mark run days
   
function preview_rule($args) {
   global $rc_year;
   global $rc_freedaysrule, $delay, $sun_free, $sat_free, $js_validto, $min_jd, $max_jd;
   $res_dates = array();   // resulted array with dates;
   
   foreach ($args as $key => $val) {
      if(!is_array($val))
         $$key = trim($val);
      else $$key = $val;
   }
   if($rc_type == 'G') return;      // RCG are procwessed in 'tws_get_rcg_dates' f-ce
   
   if ($rc_interval == '' || $rc_interval < 2)
      $rc_interval=1;
   else $rc_interval = 0+$rc_interval;

   if($rc_validfrom!='') {    // runcycle validfrom
      if(!preg_match('/(\d{4})-(\d{2})-\d{2}/', $rc_validfrom))  // test mode    
         $tmp_validfrom = tws_userdate_to_iso($rc_validfrom);
      else $tmp_validfrom = $rc_validfrom;
      $tmp_validfrom = date_parse($tmp_validfrom);
      $jd_validfrom = my_cal_to_jd($tmp_validfrom['month'], $tmp_validfrom['day'], $tmp_validfrom['year']);
      unset($tmp_validfrom);
   }
   elseif($rc_interval>1)
      $jd_validfrom = my_cal_to_jd(1, 4, 1998); // in fact from 4.1.1970 under IWS logic, but we can get it from 1998 (1970+28 - full calendar cycle)
   elseif(!empty($args['foryear'])){
      $jd_validfrom = my_cal_to_jd(1, 1, $args['foryear']);
      $jd_validfrom -= 30;    // month before (17585: Runcycle preview: run days from previous/next year)
   }
   else{    // current year
      $jd_validfrom = my_cal_to_jd(1, 1, date('Y'));
      $jd_validfrom -= 30;    // month before (17585: Runcycle preview: run days from previous/next year)
   }

   if($rc_validto!='') {    // runcycle validto
      if(!preg_match('/(\d{4})-(\d{2})-\d{2}/', $rc_validto))  // test mode
         $tmp_validto = tws_userdate_to_iso($rc_validto);
      else $tmp_validto = $rc_validto;
      $tmp_validto = date_parse($tmp_validto);
      $jd_validto = my_cal_to_jd($tmp_validto['month'], $tmp_validto['day'], $tmp_validto['year']);
      unset($tmp_validto);
   }
   else $jd_validto = $max_jd+1;

   if($js_validto!='' && $jd_validto > $js_validto) 
      $jd_validto = $js_validto; // jobstream validto

   // (global) $delay = JS at time day (+/-)
   // $rc_atplusdays = RC at time day (+/-)
   if(empty($delay)) $delay = 0;
   if(!empty($rc_athour) && !empty($rc_atminute) && !empty($rc_atplusdays) && $rc_atplusdays>0)
      $delay += $rc_atplusdays;

   //if($rc_interval>1)
   $from_jd = $jd_validfrom;
   //else $from_jd = $min_jd;
   $res_days = array();    // calculated days for runcycle (in jd format)
   switch($rc_type) {
      case 'R':   // Run Cycle
         switch($rc_freq) {
            case 'DAILY':
               $interval=$rc_interval;

               for ($jd=$from_jd; $jd<$max_jd; $jd++) {
                  if($jd < $jd_validfrom &&  $rc_interval==1) continue;
                  if($jd >= $jd_validto) break;
                  if($jd<$min_jd)
                     $val = my_cal_from_jd($jd);
                  else
                     $val = $rc_year[$jd];
                  // Work days
                  if( $rc_bydays == 'BYWORKDAY' ) {
                     if($args['freedays_option'] == 'default'){
                        if($val['dow'] != 0 &&  $val['dow'] != 6 && !$val['free']) {
                           if($interval==$rc_interval) {
                              $interval=0;
                              if($jd>=$min_jd){
                                 $res_days[] = $jd+$delay;
                                 //$rc_year[$jd+$delay]['inc'] = $rc_inc;
                                 //$rc_year[$jd+$delay]['rc'][] = $i;
                              }
                           }
                           $interval++;
                        }
                     }
                     elseif( !$val['free'] && ($val['dow']!=0 || !$sun_free) && ($val['dow']!=6 || !$sat_free) ) {
                        if($interval==$rc_interval) {
                           $interval=0;
                           if($jd>=$min_jd){ 
                              $day = free_days_rule($jd);
                              if($day != false)
                                 $res_days[] = $day;
                           }
                        }
                        $interval++;
                     }
                  }
                  // Free days
                  elseif($rc_bydays == 'BYFREEDAY'){
                     if($args['freedays_option'] == 'default'){
                        if ( $val['dow']==0  || $val['dow']==6 || @$val['free'] ){
                           if($interval==$rc_interval) {
                              $interval=0;
                              if($jd>=$min_jd){ 
                                 $day = free_days_rule($jd);
                                 if($day != false)
                                    $res_days[] = $day;
                              }
                           }
                           $interval++;
                        }
                     }
                     elseif( ($val['dow']==0 && $sun_free) || ($val['dow']==6 && $sat_free) || $val['free'] ){
                        if($interval==$rc_interval) {
                           $interval=0;
                           if($jd>=$min_jd){ 
                              $day = free_days_rule($jd);
                              if($day != false)
                                 $res_days[] = $day;
                           }
                        }
                        $interval++;
                     }
                  }
                  // Every day
                  elseif($rc_bydays == '') {
                     if($interval==$rc_interval) {
                        $interval=0;
                        if($jd>=$min_jd){ 
                           $day = free_days_rule($jd);
                           if($day != false)
                              $res_days[] = $day;
                        }
                     }
                     $interval++;
                  }
               }
               break;
            case 'WEEKLY':
               $interval=array();
               $firsttime=true;
               for ($jd=$from_jd; $jd<$max_jd; $jd++) {
                  if($jd >= $jd_validto) break;
                  if($jd<$min_jd)
                     $val = my_cal_from_jd($jd);
                  else
                     $val = $rc_year[$jd];
                  if($firsttime){
                     $firsttime=false;
                     for($k=0; $k<$val['dow']; $k++)
                        $interval[$k]=1;
                     for($k=$val['dow']; $k<7; $k++)
                        $interval[$k]=$rc_interval;
                  }

                  if(preg_match('/SU/',$rc_bydays) && $val['dow'] == 0 || preg_match('/MO/',$rc_bydays) && $val['dow'] == 1 || preg_match('/TU/',$rc_bydays) && $val['dow'] == 2 || preg_match('/WE/',$rc_bydays) && $val['dow'] == 3 || preg_match('/TH/',$rc_bydays) && $val['dow'] == 4 || preg_match('/FR/',$rc_bydays) && $val['dow'] == 5 || preg_match('/SA/',$rc_bydays) && $val['dow'] == 6) {
                     if($interval[$val['dow']]==$rc_interval) {
                        $interval[$val['dow']]=0;
                        if($jd>=$min_jd){ 
                           $day = free_days_rule($jd);
                           if($day != false)
                              $res_days[] = $day;
                        }
                     }
                     $interval[$val['dow']]++;
                  }
               }
               break;
            case 'MONTHLY':
               $interval=array();
               $sdays = explode(',', $rc_bydays);
               foreach($sdays as $sday)
                  $interval[$sday]=0;
               $tmp = my_cal_from_jd($from_jd);
               $month=$tmp['month'];

               for ($jd=$from_jd; $jd<$max_jd; $jd++) {
                  if($jd >= $jd_validto) break;
                  if($jd<$min_jd)
                     $val = my_cal_from_jd($jd);
                  else
                     $val = $rc_year[$jd];

                  if($month!=$val['month']){
                     $month=$val['month'];
                     foreach($sdays as $sday){
                        $interval[$sday]++;
                        if($interval[$sday] == $rc_interval)
                           $interval[$sday]=0;
                     }
                  }

                  if( in_array($val['day'], $sdays) ) {
                     if($interval[$val['day']]==$rc_interval || $interval[$val['day']]==0 ) {
                        if($jd>=$min_jd){
                           $day = free_days_rule($jd);
                           if($day != false)
                              $res_days[] = $day;
                        }
                     }
                  }
               }
               // for reverse dates
               $have_rev=false;
               foreach($sdays as $sel) {
                  if($sel<0) {
                     $have_rev=true;
                     break;
                  }
               }
               if($have_rev){
                  $tmp = my_cal_from_jd($from_jd);
                  $month=$tmp['month'];
                  $interval=array();
                  for($j=$from_jd; $j<=$max_jd; $j++){
                     if($j >= $jd_validto) break;
                     if($j<$min_jd)
                        $val = my_cal_from_jd($j);
                     else
                        $val = $rc_year[$j];

                     if($val['month']!=$month){  // new month
                        $month = $val['month'];
                        foreach($sdays as $cday) {
                           if($cday<0) {
                              if($interval[$cday]==$rc_interval || !isset($interval[$cday])) {
                                 $interval[$cday]=0;
                                 if($j+$cday >= $min_jd){ 
                                    $day = free_days_rule($j+$cday);
                                    if($day!=false)
                                       $res_days[] = $day;
                                 }
                              }
                              $interval[$cday]++;
                           }
                        }
                     }
                  }
               }
               break;
            case 'MONTHLY2':
               $wdays=array();   // make new array by dow
               $month=0;
               for ($jd=$from_jd; $jd<$max_jd; $jd++) {
                  if($jd >= $jd_validto) break;
                  if($jd<$min_jd)
                     $val = my_cal_from_jd($jd);
                  else
                     $val = $rc_year[$jd];

                  if($val['month'] != $month){
                     $counts = array();
                     $month=$val['month'];
                  }
                  $counts[$val['dow']]++;
                  $wdays[$val['dow']][$counts[$val['dow']]][] = $jd;
                  if($counts[$val['dow']] == 4){   // add it in 5th week if last
                     $tmpday = my_cal_from_jd($jd+7);
                     if($val['month'] != $tmpday['month'] && ($jd+7) <= $jd_validto){
                        $wdays[$val['dow']][5][] = $jd;
                     }
                  }
               }
               $tdays = array('SU'=>0,'MO'=>1,'TU'=>2,'WE'=>3,'TH'=>4,'FR'=>5,'SA'=>6);
               $rc_bydays = preg_replace('/-1/','5',$rc_bydays);
               preg_match_all('/(\d)([A-Z]+)/',$rc_bydays, $matches);
               foreach($matches[1] as $key=>$j){
                  $interval=array();
                  $seldow = $tdays[$matches[2][$key]];
                  foreach($wdays[ $seldow ][$j] as $val){
                     if($interval[$seldow]==$rc_interval || !isset($interval[$seldow])) {
                        $interval[$seldow]=0;
                        if($val>=$min_jd){ 
                           $day = free_days_rule($val);
                           if($day!=false)
                              $res_days[] = $day;
                        }
                     }
                     $interval[$seldow]++;
                  }
               }
               break;
            case 'YEARLY':
               $interval=$rc_interval;
               for ($jd=$jd_validfrom; $jd<$max_jd; ) {
                  if($jd >= $jd_validto) break;
                  if($interval==$rc_interval) {
                     $interval=0;
                     if($jd>=$min_jd){
                        $day = free_days_rule($jd);
                        if($day!=false)
                           $res_days[] = $day;
                        break;
                     }
                  }
                  $interval++;
                  $tmp = my_cal_from_jd($jd);
                  if($tmp['month']<3) $cdays = 337 + my_cal_days_in_month(2, $tmp['year']);
                  else $cdays = 337 + my_cal_days_in_month(2, $tmp['year']+1);
                  $jd+=$cdays;
               }
               break;
         }
         break;

      case 'C':      // CALENDAR
         if (($db_cal = tws_get_calendars($calendar)) === FALSE) {
              echo "Error: Unable to get calendar";
         }
         if ($db_cal['calendar_num'] != 1) {
            echo "Error: Database query error";
         }
         $calendar_dates=explode(',',$db_cal['calendar_dates'][0]);

        // mark all calendar days
         foreach ($calendar_dates as $date) {
            $jd = my_cal_to_jd(substr($date,4,2), substr($date,6), substr($date,0,4));
            if($jd < $from_jd || $jd > $jd_validto) continue;
            if(empty($offsetvalue)){
               $day = free_days_rule($jd);
               if($day!=false)
                  $res_days[] = $day;
            }
            else {
               $offsetvalue = 0+$offsetvalue;
               if($offsettype == 'DAYS') {         // All days
                  if($jd+$offsetvalue+$delay >= $min_jd && $jd+$offsetvalue+$delay < $jd_validto) {
                     if(($rc_freedaysrule == 'fdnext' || $rc_freedaysrule == 'fdprev') && !empty($rc_year[$jd+$offsetvalue+$delay]['free'])){
                        $i=0;
                        while(!empty($rc_year[$jd+$offsetvalue+$delay+$i]['free'])){
                           if($rc_freedaysrule == 'fdnext') $i++;
                           else $i--;
                        }
                        $res_days[] = $jd+$offsetvalue+$delay+$i;
                        //$rc_year[$jd+$offsetvalue+$delay+$i]['inc'] = $rc_inc;
                        //$rc_year[$jd+$offsetvalue+$delay+$i]['rc'][] = $i;
                     }
                     else{
                        $res_days[] = $jd+$offsetvalue+$delay;
                        //$rc_year[$jd+$offsetvalue+$delay]['inc'] = $rc_inc;
                        //$rc_year[$jd+$offsetvalue+$delay]['rc'][] = $i;
                     }
                  }
               }
               elseif($offsettype == 'WEEKDAYS') { // always only MO-FR
                  $shift=0;
                  if($offsetvalue>0){
                     // find weekends beetween dates
                     for ($tmp=$jd+1; $tmp<=$jd+$offsetvalue+$shift; $tmp++){
                        if(isset($rc_year[$tmp]['dow']) && ($rc_year[$tmp]['dow']==0 || $rc_year[$tmp]['dow']==6))
                           $shift++;
                     }
                  }
                  else {   // $offsetvalue<0
                     for ($tmp=$jd-1; $tmp>=$jd+$offsetvalue+$shift; $tmp--){
                        if(isset($rc_year[$tmp]['dow']) && ($rc_year[$tmp]['dow']==0 || $rc_year[$tmp]['dow']==6))
                           $shift--;
                     }
                  }
                  if($jd+$offsetvalue+$shift+$delay >= $min_jd && $jd+$offsetvalue+$shift+$delay < $jd_validto) {
                     $res_days[] = $jd+$offsetvalue+$shift+$delay;
                     //$rc_year[$jd+$offsetvalue+$shift+$delay]['inc'] = $rc_inc;
                     //$rc_year[$jd+$offsetvalue+$shift+$delay]['rc'][] = $i;
                  }
               }
               elseif($offsettype == 'WORKDAYS') {    // Workdays only
                  $shift=0;
                  if($offsetvalue>0){
                     for ($tmp=$jd+1; $tmp<=$jd+$offsetvalue+$shift; $tmp++){
                        if(isset($rc_year[$tmp]['dow']) && ( ($rc_year[$tmp]['dow']==0 && $sun_free) || ($rc_year[$tmp]['dow']==6 && $sat_free)) || !empty($rc_year[$tmp]['free']))
                           $shift++;
                     }
                  }
                  else {   // $offsetvalue<0
                     for ($tmp=$jd-1; $tmp>=$jd+$offsetvalue+$shift; $tmp--){
                        if(isset($rc_year[$tmp]['dow']) && (($rc_year[$tmp]['dow']==0 && $sun_free) || ($rc_year[$tmp]['dow']==6 && $sat_free)) || !empty($rc_year[$tmp]['free']))
                           $shift--;
                     }
                  }
                  if($jd+$offsetvalue+$shift+$delay >= $min_jd && $jd+$offsetvalue+$shift+$delay < $jd_validto) {
                     $res_days[] = $jd+$offsetvalue+$shift+$delay;
                     //$rc_year[$jd+$offsetvalue+$shift+$delay]['inc'] = $rc_inc;
                     //$rc_year[$jd+$offsetvalue+$shift+$delay]['rc'][] = $i;
                  }
               }
               else  { tws_error("offset type is missing"); break;}
            }
         }
         break;

      case 'S':   // SINGLE DATES
         foreach($date_day as $date){
            if(!preg_match('/(\d{4})-(\d{2})-\d{2}/', $date))  // test mode
               $date = tws_userdate_to_iso($date,null, true);
            $jd = my_cal_to_jd(substr($date,5,2), substr($date,8,2), substr($date,0,4));
            if($jd < $from_jd || $jd > $jd_validto) continue;
            $day = free_days_rule($jd);
            if($day!=false)
               $res_days[] = $day;
         }
         break;
   }
   return $res_days;
}
//    Set run day according free days rule
//
function free_days_rule($jd) {
   global $rc_year, $rc_freedaysrule, $delay, $sun_free, $sat_free;

   if( $rc_freedaysrule=='' || empty($rc_year[$jd+$delay]['free'])) {
      return($jd+$delay);
      //$rc_year[$jd+$delay]['inc'] = $rc_inc;
      //$rc_year[$jd+$delay]['rc'][] = $i;
   }
   elseif($rc_freedaysrule=='fdnext') {
      $j=0;
      while(!empty($rc_year[$jd+$delay+$j]['free']))
         $j++;
      return($jd+$j+$delay);
      //$rc_year[$jd+$j+$delay]['inc'] = $rc_inc;
      //$rc_year[$jd+$j+$delay]['rc'][] = $i;
      //$rc_year[$jd+$j+$delay]['fd'][] = $i;
   }
   elseif($rc_freedaysrule=='fdprev'){
      $j=0;
      while(!empty($rc_year[$jd+$delay-$j]['free']))
         $j++;
      return($jd-$j+$delay);
      //$rc_year[$jd-$j+$delay]['inc'] = $rc_inc;
      //$rc_year[$jd-$j+$delay]['rc'][] = $i;
      //$rc_year[$jd-$j+$delay]['fd'][] = $i;
   }
   elseif($rc_freedaysrule=='fdignore') { // don't run
      if( empty($rc_year[$jd]['free'])) {
         return($jd+$delay);
         //$rc_year[$jd+$delay]['inc'] = $rc_inc;
         //$rc_year[$jd+$delay]['rc'][] = $i;
      }
   }
   return(false);
}

// mark freedays from calendar as "free"
// mark sun & sat if options is on
function mark_freedays ($cal_name) {
   global $rc_year, $sun_free, $sat_free;
   
   // mark sun & sat if options is on
   foreach($rc_year as $jd=>$arr){
      if($rc_year[$jd]['dow']==0 && $sun_free)
         $rc_year[$jd]['free'] = true;
      elseif($rc_year[$jd]['dow']==6 && $sat_free)
         $rc_year[$jd]['free'] = true;
   }
   if(empty($cal_name))
       return;    // have no HOLIDAYS calendar
   
   if (($db_cal = tws_get_calendars($cal_name)) === FALSE) {
      echo "Error: Unable to get calendar";
   }
   if ($db_cal['calendar_num'] != 1) {
      echo "Error: Database query error";
   }
   $calendar = $db_cal['calendar_name'][0];
   $calendar_dates=explode(',',$db_cal['calendar_dates'][0]);

// color all freedays
   foreach ($calendar_dates as $date) {
      $jd = my_cal_to_jd(substr($date,4,2), substr($date,6), substr($date,0,4));
      $rc_year[$jd]['free'] = true;
   }
}

// Own Calendar Functions instead of standard php Calendar Functions
// (To get them to work, you have to compile PHP with --enable-calendar )

// Date to Julian day
function my_cal_to_jd ($month, $day, $year){
  $a =  intval((14-$month)/12);
  $y = $year+4800-$a;
  $m = $month+12*$a-3;

  $jdn = $day + intval((153*$m+2)/5) + 365*$y + intval($y/4) - intval($y/100) + intval($y/400) - 32045;
  return $jdn;
}

// Julian day to date
function my_cal_from_jd ($jdn){
   $cal = array();
   $cal['dow'] = $jdn%7+1;
   if($cal['dow']==7) $cal['dow']=0;

   $a = $jdn + 32044;
   $b = intval((4*$a+3)/146097);
   $c = $a - intval(146097*$b/4);
   $d = intval((4*$c+3)/1461);
   $e = $c - intval(1461*$d/4);
   $m = intval((5*$e+2)/153);

   $cal['day'] = $e-intval((153*$m+2)/5) +1;
   $cal['month'] = $m+3-12*intval($m/10);
   $cal['year'] = 100*$b + $d - 4800 + intval($m/10);

   $abbrevmonth = array(1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May', 6=>'Jun', 7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct', 11=>'Nov', 12=>'Dec');
   $cal['abbrevmonth'] = $abbrevmonth[$cal['month']];
   return $cal;
}

// days_in_month
function my_cal_days_in_month($month, $year) {
   return date('t', mktime(0, 0, 0, $month, 1, $year));
}

/* functions to work with sructures as:
 $struct = [
[workstation][0][1] etc
[jobstream][0][1] etc
[job][0][1] etc
]
   and so on
*/

// return $i-th data from $struct ()
function tws_select_param(&$struct, $index){
   $res = array();
   foreach($struct as $struct_name=>$val_arr)
      if(is_array($val_arr))
         $res[$struct_name] = $val_arr[$index];
      else $res[$struct_name] = $val_arr;
   return $res;
}

// add $i-th parameter to $struct ()
function tws_add_param(&$struct, $index, $add_arr){
   foreach($struct as $struct_name=>$val_arr){
      $struct[] = $val_arr[$index];
   }
   
}

// delete all $i-th parameter from $struct
function tws_delete_param(&$struct, $index){
   foreach($struct as $struct_name=>$val_arr)
      unset($struct[$struct_name][$index]);
   return $struct;
}
/*
// resort all $struct parameters
function tws_resort_param(&$struct){
   $res = array();
   foreach($struct as $struct_name=>$val_arr){
      foreach($val_arr as $i=>$val){
         if($i == $index)
            $res[$struct_name] = $val;
      }
   }
   return $res;
}
*/

// instead of standard php merge_arrays function, because:
//    Values in the input array with numeric keys will be renumbered with 
//    incrementing keys starting from zero in the result array. 
// this function make it as with string keys:
//    If the input arrays have the same string keys, 
//    then the later value for that key will overwrite the previous one.
function tws_array_merge($arr1, $arr2){
   foreach($arr2 as $i=>$val)
      $arr1[$i] = $arr2[$i];
   return $arr1;
}

// remove indexes of $arr2 from $arr1
function tws_array_exclude($arr1, $arr2){
   foreach($arr2 as $i=>$val)
      unset($arr1[$i]);
   return $arr1;
}


function get_rcgroup_dates($args){
 
   $rcg_dates = array();
   
   foreach($args['rc_subset'] as $i=>$subset){
      $rcg_subsets[$subset][] = divide_subsets($args, $i);   
   }
   $rcg_dates = tws_get_subset_dates($rcg_subsets);
   return $rcg_dates;
}

function tws_get_subset_dates($rcg_subsets){
   
   $res = array();   
   $rcg_dates = array();
   
   foreach($rcg_subsets as $name=>$arr){
      $acc = array();
      $and_arr = array();  // 
      $first_and = true;   // 
      foreach($arr as $i=>$args){
         if($args['rc_on_except'] == 'ON' ){
            $subset_dates = preview_rule($args);
            if($args['rc_and'] == 'A'){   // logical and rule (only ON rules can have)
               if($first_and){   // first and rule
                  $first_and = false;
                  $and_arr = $subset_dates;
               }
               else $and_arr = array_intersect($and_arr, $subset_dates);  // logical AND for arrays
            }
            else 
               $acc = array_merge($acc, $subset_dates);
         }
      }
      $acc = array_merge($acc, $and_arr);    // add dates from 'and' array
      foreach($arr as $i=>$args){
         if($args['rc_on_except'] == 'EXCEPT' ){
            $subset_dates = preview_rule($args);
            $acc = array_diff($acc, $subset_dates);
         }
      }
      $res[$name] = $acc;     // own dates for each subset
   }
   foreach($res as $name=>$dates)   // union all subsets
      $rcg_dates = array_merge($rcg_dates, $dates);
   return $rcg_dates;
}

?>