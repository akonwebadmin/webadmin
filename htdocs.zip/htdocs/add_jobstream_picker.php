<?php
//   HORIZONT Software GmbH, Munich
//
//    used in Add/Modify Workload Application dialog
//    IWS 9.1

   require_once 'tws_functions.php';

   tws_import_request_variables("P","rqst_");

   $workstation=tws_gpc_get($rqst_workstation, 'tws_mask');
   $jobstream=tws_gpc_get($rqst_jobstream, 'tws_mask');
   $action=$rqst_action;
   $display="yes";

   if (trim($workstation)=='') $workstation="@";
   if (trim($jobstream)=='') $jobstream="@";
?>

<script type="text/javascript">

function sendValue(formsel) {
   if (formsel) {
      for (var i=0; i < formsel.options.length; i++) {
         if (formsel.options[i].selected) {
            temptext=formsel.options[i].text;
            tempvalue=formsel.options[i].value;
            rc=window.addJobstream(temptext,tempvalue);
            if (rc == false) {
               window.focus();
               return;
            }
         }
      }
   }
   $( "#add_jobstream_picker" ).dialog( "close" );
}

function setValue() {
    var param = 'action=set&workstation='+ document.filter_list.workstation.value +'&jobstream='+ document.filter_list.jobstream.value;
   $('#add_jobstream_picker').dialog('close');
   tws_picker_open('add_jobstream_picker.php', param);
}

</script>

<style type="text/css">
input, select, textarea, button {
   font-family: Verdana,Arial,sans-serif;
   font-size:13px;
}

</style>

<div id="add_jobstream_picker">

<h1>Select JobStream</h1>
<br>

<form name="filter_list">
<table border=0 cellspacing=0 align=center name="seltable">
<tr><td class=standard colspan=2><b>Filter:</b></td></tr>
<tr>
   <td class=standard>&nbsp;&nbsp;Workstation:&nbsp;</td>
   <td class=standard>
      <input type="text" name="workstation" class='tws_mask' size="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" maxlength="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" value="<?=htmlspecialchars($workstation)?>">
   </td>
</tr>
<tr>
   <td class=standard>&nbsp;&nbsp;JobStream:&nbsp;</td>
   <td class=standard>
      <input type="text" name="jobstream" class='tws_mask' size="<?=$tws_config['JOBSTREAM_MAXLENGTH']?>" maxlength="<?=$tws_config['JOBSTREAM_MAXLENGTH']?>" value="<?=htmlspecialchars($jobstream)?>">
   </td>
</tr>
<tr>
   <td class=standard colspan=2 align=center>&nbsp;&nbsp;
      <input type="button" name="action" value=" Set " onClick="setValue();"/>
   </td>
</tr>
</table>
</form>
<br>

<?php
   if ((isset($action) && strtolower(trim($action))=='set') || $jobstream!='@' || $workstation!='@') {
      // valid only
      $dformat = tws_profile("date_format");
      if(!$dformat) 
         $dformat = 'm/d/Y';
      $filter = tws_where_valid_in(tws_userdate_to_iso(date($dformat), $dformat, true));
      
      echo '<form name="jobstream_list">',"\n";

      if (($jobstreams=tws_get_jobstreams($workstation, $jobstream, '', $filter))===FALSE) {
         echo "<center><p class=warning>Unable to get jobstreams.</p>\n";
         echo "<input type=\"button\" value=\"OK\" onClick=\"sendValue(null);\"></center>\n";
      }

      if ($jobstreams['jobstream_num'] == 0) {
         echo "<center><p class=warning>No jobstreams matching the filtering criteria had been found.</p>\n";
         echo "<input type='button' value='OK' onClick='sendValue(null);'></center>\n";
      } else {
         echo "<select name='selection' size=15 onDblClick='sendValue(this.form.selection);' multiple>\n";

         for ($i=0; $i<$jobstreams['jobstream_num']; $i++) {
            echo "<option value='".$jobstreams['jobstream_workstation'][$i]."#".$jobstreams['jobstream_name'][$i]."'";
            if($jobstreams['jobstream_num']==1) echo " selected";
            echo">".$jobstreams['jobstream_workstation'][$i]."#".$jobstreams['jobstream_name'][$i]."</option>\n";
         }
         echo "</select>\n";
         echo "<br><br>\n";
         echo "<center><input type='button' value='OK' onClick='sendValue(this.form.selection);'></center>\n";
      }
      echo "</form>\n";
   } 
?>
</div>

<script type="text/javascript">

$(function() {
   tws_picker_constructor("add_jobstream_picker", "seltable");
});

</script>