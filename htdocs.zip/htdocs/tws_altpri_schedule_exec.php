<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Set Jobstream Priority</title>
<?php tws_stylesheet(); ?>
</head>
<body>
<?php tws_set_window_title(); ?>

<h1>Set Jobstream Priority Status</h1>

<?php
   if (!tws_permit_action('plan_jobstreams','Priority')) {
      tws_access_denied ();
   }
   tws_import_request_variables("P","rqst_");

   $selection=tws_gpc_get($rqst_selection, "tws_name;tws_name;tws_datetime;tws_sched_id");
   $priority=tws_gpc_get($rqst_priority, "tws_priority");
   $arg=@tws_gpc_get($rqst_arg, "tws_filter");
   $afteraction=@tws_gpc_get($rqst_afteraction, "tws_name");
      tws_check_synchro_token();

   $status=0;
   $num_elements=count($selection);

   for ($idx=0; $idx<$num_elements; ++$idx) {
      $js=tws_get_jobstream_data($selection[$idx]);

      set_time_limit($tws_config['excmd_limit']);

      echo "Setting priority $priority for <em>$js[cpu]#$js[schedule]($js[schedtime])</em> ... ";

      $command=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/conman", $tws_config['conman_args'], "-gui", "ap $js[cpu]#$js[schedid];schedid;$priority", hwi_cmd::operator('2>&1',FALSE));
      $stdout=array();
      if (tws_popen($command, $ec, $stdout, $stdout, "N")===FALSE || tws_process_conman_gui($stdout)!=0) {
         $status=1;
         echo "<span class=\"err\">ERROR</span><br/>\n";
         tws_dyer("Alternate jobstream priority failed", array('stdout'=>$stdout));
      } else {
         echo "<span class=\"ok\">OK</span><br/>\n";
      }
   }
if(tws_profile('action_refresh')=='yes'){
   if ($status==0) {
      echo "<script type='text/javascript'>\n";
         echo "window.location.replace('".tws_profile('last_opener')."');\n";
      echo "</script>\n";
   } else
      echo "<br><br><a href='".tws_profile('last_opener')."'>Return to Jobstreams Display</a>\n";
}
else{
   if ($status==0 && tws_profile('action_popup_close'))
      echo "<script>window.close();</script>";
   else
      echo '<br><input type="button" value="Close Window" onClick="window.close();">';
}
?>
</body>
</html>
