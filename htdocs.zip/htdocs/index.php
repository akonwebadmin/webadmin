<?php
//   HORIZONT Software GmbH, Munich
//

   //this is only for Apache authentication since 3.2
   //OS authentication uses special tws_logout.php script
   if (@$_GET['logout']==1) {
      $oldauth=str_replace("\\\\","\\",@$_GET['oldauth']);
      // user@domain
      if(strpos($_SERVER['PHP_AUTH_USER'], '@') ){
         list($user, $domain) = explode('@', $_SERVER['PHP_AUTH_USER']);
         $_SERVER['PHP_AUTH_USER'] = $domain."\\".$user;
      }
      if( strpos($_SERVER['PHP_AUTH_USER'], '\\')!==false){
         list($domain, $user) = explode('\\', $_SERVER['PHP_AUTH_USER']);
         if( ($pos=strpos($domain, '.'))!==false )
            $domain = substr($domain,0,$pos);
         $_SERVER['PHP_AUTH_USER'] = $domain.'\\'.$user;
      }

      if ($oldauth==$_SERVER['PHP_AUTH_USER']) {
         //ERR18438: The realm name must be identical to the value of AuthName in auth.conf!!!
         //See the ERR18438 for more details
         header('WWW-Authenticate: Basic realm="IWS/WebAdmin"');
         header('HTTP/1.0 401 Unauthorized');
         session_start();
         $_SESSION = array();
         if (isset($_COOKIE[session_name()]))
            setcookie(session_name(), '', time()-42000, '/');
         session_destroy();
      }
      echo "<html><head><meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\">\n";
      echo "   <script type='text/javascript'>\n";
      echo "      location.replace('/');";
      echo "   </script>\n";
      echo "</head></html>\n";
      exit;
   }

   require_once 'tws_functions.php';
   header("X-Frame-Options: DENY");
   tws_doctype('f');
?>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title>IWS/WebAdmin <?=tws_profile('webadmin_version')?></title>
<meta name="author" content="HORIZONT IT; www.horizont-it.com">
<meta name="copyright" content="HORIZONT IT; www.horizont-it.com">
<style> html {display:none } </style>
<script type="text/javascript" src="jquery/js/jquery-1.11.0.min.js"></script>
<script type="text/javascript">

   function logout(){
      // ajax "tws_audit_logout.php"
      $.ajax({
      type: 'GET',
      url: 'tws_audit_logout.php',
      complete: function(result) {
         try { 
            //only IE knows this:
            ie = document.execCommand("ClearAuthenticationCache"); 
         } catch(e) { 
            ie = false;
         } 
         if(ie){
            window.location.href='/';
            return false;
         }
         else{
            location.replace('<?=(tws_get_authtype()=='os' ? "/tws_logout.php" : "/index.php?logout=1&oldauth=".urlencode($_SERVER['PHP_AUTH_USER']));?>');    
         }
      },
      error: function(jqXHR, Status, errorThrown ) {
          console.log(jqXHR);
      },
      dataType: 'html'
      });
   }
   
   var menuStatus = 'expanded';
   <? if(tws_profile('autohide')){ ?>
      var menuPin = 'of';
   <?} else{?>
      var menuPin = 'on';
   <? } ?>
function init() {
   <? if(isset($_GET['redirect']) && isset($_SESSION['bookmarks_menu_collapsed']) && $_SESSION['bookmarks_menu_collapsed']=='yes'){ ?>
      menuStatus = 'expanded';
      menuPin = 'of';
      window.frames['navbar'].document.getElementById('pin').src="images/icons/pin_off.gif";
      menu();
   <? } ?>

   if (self == top)  document.documentElement.style.display = "block";
   else top.location = self.location;
   return;
}
      /*
       * Function can expand or collapse frame with menu.
       */
   function menu() {
      if(menuPin == 'on' && menuStatus == 'expanded')
         return;

      var image = window.frames['topbar'].document.getElementById('bar_menu');
      var frameset = document.getElementById('frameset');
      var navopen = window.frames['navbar'].document.getElementById('nav_open');
      var navmain = window.frames['navbar'].document.getElementById('nav_main');
      if(!image) return;   // sometimes topbar is not loaded yet
      if(!navopen) return; // sometimes navbar is not loaded yet


      if (menuStatus == 'expanded') {
         frameset.cols  = '25, *';
         image.src = 'images/icons/bar_menu_expand.gif';
         menuStatus = 'collapsed';
         navopen.style.display = 'block';
         navmain.style.display = 'none';
      }
      else {
         frameset.cols  = '190, *';
            image.src = 'images/icons/bar_menu_collapse.gif';
         menuStatus = 'expanded';
         navopen.style.display = 'none';
         navmain.style.display = 'block';
      }
   }

</script>
</head>
<noscript>
   <style> html {display:block;} </style>
   <h2>This version of IWS/WebAdmin requires JavaScript enabled to work correctly.</h2>
</noscript>
<frameset rows="17, *" frameborder="0" border="0" framespacing="0" onload="init()">
   <frame id="topbar" name="topbar" src="tws_topbar.php" scrolling="no" noresize />
   <frameset id="frameset" cols="190,*" frameborder="0" border="0" framespacing="0">
      <frame id="navbar" name="navbar" src="tws_navbar.php" />
      <frame id="view_window" name="view_window" src="<?php echo isset($_GET['redirect']) ? base64_decode($_GET['redirect']) : 'tws_home.php'; ?>" />
   </frameset>
</frameset>
<noframes>
   <p>Sorry, this document can only be viewed in a frames capable browser</p>
</noframes>
</html>
