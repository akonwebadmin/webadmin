<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Set Job Priority</title>
<?php tws_stylesheet(); ?>
</head>
<body>
<?php tws_set_window_title(); ?>

<h1>Set Job Priority</h1>
<br><br>
<h3>Selected Objects:</h3>

<?php
   if (!tws_permit_action('plan_jobs','Priority')) {
      tws_access_denied ();
   }
   $num_elements=count($selection);
   if ($num_elements == 0) {
      echo "<p class=warning>&nbsp;&nbsp;&nbsp;&nbsp;No objects selected</p>\n";
   } else {
      if (!empty($_POST['js_selection']))
         TWS_DISP_PLANJST_SEL($_POST['js_selection']);
      TWS_DISP_PLANJOB_SEL($selection);

      echo "<br>\n";
      if(!isset($altpri)) $altpri = '';
      else $altpri = htmlspecialchars($altpri);

      echo "<form method=post action='tws_altpri_job_exec.php'>\n";
      for ($idx=0; $idx<$num_elements; ++$idx) {
         echo "<input type=\"hidden\" name=\"selection[]\" value=\"".htmlspecialchars($selection[$idx])."\">\n";
      }
      if (!empty($_POST['js_selection'])){
         for ($idx=0; $idx<count($_POST['js_selection']); ++$idx)
            echo '<input type="hidden" name="js_selection[]" value="'.htmlspecialchars($_POST['js_selection'][$idx]).'">'."\n";
      }
      echo "<input type=\"hidden\" name=\"arg\" value=\"".htmlspecialchars($arg)."\">\n";
      echo "Set Job Priority:&nbsp;
         <input type='text' name='priority' value='$altpri' class='tws_priority' required='required' size='4' maxlength='4'><br><br>
         &nbsp;&nbsp;<input type='submit' value='Submit' onClick='return tws_validate_form()'>&nbsp;&nbsp;\n";
         echo '<INPUT TYPE="button" VALUE="Cancel" onClick="closeme(\'tws_sjx.php\');">';
      tws_print_synchro_token();     // synchro token
      echo "</form>\n";
   }
?>
</body>
</html>
