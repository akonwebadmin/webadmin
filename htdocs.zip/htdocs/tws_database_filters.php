<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>IWS Database Filters</title>
<?php tws_stylesheet(); ?>
<script type="text/javascript">
function submit_page2(filtertype) {
   open("tws_db" + filtertype + "_filter.php","_self");
}
</script>
</head>
<body>
<?php
if(tws_get_menu('Database_Filters')==0) tws_access_denied();

tws_set_window_title();
tws_print_head('IWS Database Filters');
 ?>
<form name="filterselect" action="">
<table border=0 cellspacing=0>
<tr>
<td class=standard width=150>
<b>Filter Type:</b>
</td>
<td>
<select name="filtertype" onchange="submit_page2(document.filterselect.filtertype.options[document.filterselect.filtertype.selectedIndex].value)">
<option value="-- Select One --">-- Select One --</option>
<option value="workstation">Workstation</option>
<option value="workstation_class">Workstation Class</option>
<option value="domain">Domain</option>
<option value="jobstream">Jobstream</option>
<option value="calendar">Calendar</option>
<option value="job">Job</option>
<option value="resource">Resource</option>
<option value="prompt">Prompt</option>
<option value="parameter">Parameter</option>
<option value="user">User</option>
<?php
   if ($tws_config['cpuinfo']['version']>='8.4') echo '<option value="evrule">Event Rules</option>',"\n";
?>
</select>
</td>
</tr>
</table>
</form>

<div id='tabs'>
   <ul>
      <li><a href='#domains'        onclick="window.localStorage.dbtab='0'">Domains</a></li>
      <li><a href='#workstations'   onclick="window.localStorage.dbtab='1'">Workstations</a></li>
      <li><a href='#workstation_classes' onclick="window.localStorage.dbtab='2'">Workstation Classes</a></li>
      <li><a href='#jobstreams'  onclick="window.localStorage.dbtab='3'">Jobstreams</a></li>
      <li><a href='#jobs'        onclick="window.localStorage.dbtab='4'">Jobs</a></li>
      <li><a href='#calendars'   onclick="window.localStorage.dbtab='5'">Calendars</a></li>
      <li><a href='#resources'   onclick="window.localStorage.dbtab='6'">Resources</a></li>
      <li><a href='#prompts'     onclick="window.localStorage.dbtab='7'">Prompts</a></li>
      <li><a href='#parameters'  onclick="window.localStorage.dbtab='8'">Parameters</a></li>
      <li><a href='#users'       onclick="window.localStorage.dbtab='9'">Users</a></li>
      <li><a href='#evrules'     onclick="window.localStorage.dbtab='10'">Event Rules</a></li>
   <? if ($tws_config['cpuinfo']['version']>='8.5')
         echo "<li><a href='#parameter_tables' onclick=\"window.localStorage.dbtab='11'\">Parameter Tables</a></li>";
      if ($tws_config['cpuinfo']['version']>='9.1')
         echo "<li><a href='#applications' onclick=\"window.localStorage.dbtab='12'\">Applications</a></li>";
      if ($tws_config['cpuinfo']['version']>='9.1')
         echo "<li><a href='#runcycles'   onclick=\"window.localStorage.dbtab='13'\">Run Cycles</a></li>"; ?>
   </ul>

<div id='domains'>
<? $object='dbdomain';
   include "tws_load_filter.php";
?>
</div>
<div id='workstations'>
<? $object='dbworkstation';
   include "tws_load_filter.php";
?>
</div>
<div id='workstation_classes'>
<? $object='dbworkstationclass';
   include "tws_load_filter.php";
?>
</div>

<div id='jobstreams'>
<? $object='dbjobstream';
   include "tws_load_filter.php";
?>
</div>
<div id='jobs'>
<? $object='dbjob';
   include "tws_load_filter.php";
?>
</div>
<div id='calendars'>
<? $object='dbcalendar';
   include "tws_load_filter.php";
?>
</div>
<div id='resources'>
<? $object='dbresource';
   include "tws_load_filter.php";
?>
</div>
<div id='prompts'>
<? $object='dbprompt';
   include "tws_load_filter.php";
?>
</div>

<div id='parameters'>
<? $object='dbparameter';
   include "tws_load_filter.php";
?>
</div>
<div id='users'>
<? $object='dbuser';
   include "tws_load_filter.php";
?>
</div>
<div id='evrules'>
<? $object='dbevrule';
   include "tws_load_filter.php";
?>
</div>
<?
if ($tws_config['cpuinfo']['version']>='8.5') {
   echo"<div id='parameter_tables'>";
   $object='dbparameter_table';
   include "tws_load_filter.php";
   echo "</div>\n";
}
if ($tws_config['cpuinfo']['version']>='9.1'){
   echo "<div id='applications'>\n";
   $object='dbapplication';
   include "tws_load_filter.php";
   echo "</div>\n";
}
if ($tws_config['cpuinfo']['version']>='9.1'){
   echo "<div id='runcycles'>\n";
   $object='dbruncycle';
   include "tws_load_filter.php";
   echo "</div>\n";
}
?>

</div>

<script>
$(function() {
   var cur = window.localStorage.dbtab;
   if(typeof(cur) != 'undefined')
      $( "#tabs" ).tabs({ active: cur});
   else $('#tabs').tabs();
   $('#tabs').css('background-color','inherit');
   $('#tabs').css('border','none 0px');
});
</script>

</body>
</html>
