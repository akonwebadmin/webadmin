<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";

tws_doctype("t");
?>
<html><head>
<title>Add Jobstream</title>
<?php
tws_stylesheet();
tws_show_backup();
 ?>
</head>
<body>
<? tws_set_window_title();

   $copy=tws_gpc_get($_POST['copy'], 'tws_name');
   $modify=tws_gpc_get($_POST['modify'], 'tws_name');

   $confirm=tws_gpc_get($_POST['confirm'], 'tws_name');
   $backup=tws_gpc_get($_POST['backup'], 'tws_name');

   tws_check_synchro_token();  // synchro_token

   if (tws_zli_module_check ()) {
       $netmodule_file = "";
       $netmodule_show_prompt = "";
       $netmodule_show_internet = "";
       $netmodule_show_file = "";
       $netmodule_show_resource = "";
       if (!empty($_POST['netmodule_file']))
           $netmodule_file=tws_gpc_get($_POST['netmodule_file'], 'tws_file');
       if (isset ($_POST['netmodule_show_prompt']))
           $netmodule_show_prompt=tws_gpc_get($_POST['netmodule_show_prompt'], 'tws_num');
       if (isset ($_POST['netmodule_show_internet']))
           $netmodule_show_internet=tws_gpc_get($_POST['netmodule_show_internet'], 'tws_num');
       if (isset ($_POST['netmodule_show_file']))
           $netmodule_show_file=tws_gpc_get($_POST['netmodule_show_file'], 'tws_num');
       if (isset ($_POST['netmodule_show_resource']))
           $netmodule_show_resource=tws_gpc_get($_POST['netmodule_show_resource'], 'tws_num');
   }

// read post params to vars
   foreach($_POST as $key => $value) {
      $$key=tws_gpc_get($value);
   }

   if (!is_array($jobname)) $jobname=array();

   tws_check_arg($workstation, 'tws_name');
   tws_check_arg($jobstream, 'tws_name');
   if ($validfrom && tws_check_arg($validfrom, 'tws_datetime')) {
      $validfrom = tws_userdate_to_iso($validfrom, null, true);
      $tws_validfrom="valid from ".tws_date_from_iso($validfrom);
   } else {
      $validfrom=null;
      $tws_validfrom='';
   }
   if(!empty($jobstream_folder))
      $jobstream = $jobstream_folder.$jobstream;
   $tws_jobstream_name="$workstation#$jobstream $tws_validfrom";

// Check for existing jobstream
   $match=FALSE;
   if ($confirm != "yes") {
      $db_streams=tws_get_jobstreams($workstation,$jobstream,$validfrom);
      if ($db_streams['jobstream_num']!=0){
         $match=TRUE;
         if ($db_streams['jobstream_num']==1){
            foreach($db_streams as $key =>$value){
               $orig_stream[$key] = $value[0];
            }
         } else {
            foreach($db_streams['jobstream_valid_from'] as $key => $vf) {
               if ($vf == "") $index=$key;
            }
            foreach($db_streams as $key =>$value){
               $orig_stream[$key] = $value[$index];
            }
         }

      }
   }
   if ($match == TRUE) {
      if ($modify == "yes") {
         echo "<h1>Confirmation</h1>\n";
      } else {
         echo "<h1>Replace Jobstream Confirmation</h1>\n";
      }
      echo "<br><br>\n";
      echo "<h3>Confirm:</h3>\n";
      if ($modify != "yes") {
         echo "&nbsp;&nbsp;<b>The Jobstream Name entered already exists</b>\n";
         echo "<br><br>\n";
      }
      echo "&nbsp;&nbsp;&nbsp;<b><u>Original Jobstream:</u></b>\n";
      echo "<br><br>\n";
      echo "<table border=0 cellspacing=0>\n";
      echo "<tr>\n";
      echo "<td class=standard width=120><b>&nbsp;&nbsp;&nbsp;&nbsp;Workstation:</b></td>\n";
      echo "<td class=standard>".htmlspecialchars($orig_stream['jobstream_workstation'])."</td>\n";
      echo "</tr>\n";
      echo "<tr>\n";
      echo "<td class=standard width=120><b>&nbsp;&nbsp;&nbsp;&nbsp;Jobstream:</b></td>\n";
      echo "<td class=standard>".htmlspecialchars($orig_stream['jobstream_name'])."</td>\n";
      echo "</tr>\n";
      echo "<tr>\n";
      echo "<td class=standard width=120><b>&nbsp;&nbsp;&nbsp;&nbsp;Valid from:</b></td>\n";
      echo "<td class=standard>".htmlspecialchars($orig_stream['jobstream_valid_from'])."</td>\n";
      echo "</tr>\n";
      echo "<tr>\n";
      echo "<td class=standard width=120><b>&nbsp;&nbsp;&nbsp;&nbsp;Creator:</b></td>\n";
      echo "<td class=standard>".htmlspecialchars($orig_stream['jobstream_creator'])."</td>\n";
      echo "</tr>\n";
      echo "<tr>\n";
      echo "<td class=standard width=120><b>&nbsp;&nbsp;&nbsp;&nbsp;Last Updated:</b></td>\n";
      echo "<td class=standard>".htmlspecialchars($orig_stream['jobstream_last_updated'])."</td>\n";
      echo "</tr>\n";
      echo "</table>\n";
      echo "<br><br>\n";
      echo "&nbsp;&nbsp;&nbsp;<b><u>New Jobstream:</u></b>\n";
      echo "<br><br>\n";
      echo "<table border=0 cellspacing=0>\n";
      echo "<tr>\n";
      echo "<td class=standard width=120><b>&nbsp;&nbsp;&nbsp;&nbsp;Workstation:</b></td>\n";
      echo "<td class=standard>".htmlspecialchars($workstation)."</td>\n";
      echo "</tr>\n";
      echo "<tr>\n";
      echo "<td class=standard width=120><b>&nbsp;&nbsp;&nbsp;&nbsp;Jobstream:</b></td>\n";
      echo "<td class=standard>".htmlspecialchars($jobstream)."</td>\n";
      echo "</tr>\n";
      echo "<tr>\n";
      echo "<td class=standard width=120><b>&nbsp;&nbsp;&nbsp;&nbsp;Valid from:</b></td>\n";
      echo "<td class=standard>".htmlspecialchars($validfrom)."</td>\n";
      echo "</tr>\n";
      echo "</table>\n";
      echo "<br>\n";
      echo "<form method=post name=\"confirm\" action=\"tws_add_jobstream4_action.php\">\n";
      echo "<input type=\"hidden\" name=\"confirm\" value=\"yes\">\n";
      if ($modify == "yes") {
         echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
      } else {
         echo "<input type=\"hidden\" name=\"modify\" value=\"no\">\n";
      }
      if ($copy == "yes") {
         echo "<input type=\"hidden\" name=\"copy\" value=\"yes\">\n";
      } else {
         echo "<input type=\"hidden\" name=\"copy\" value=\"no\">\n";
      }

      if ($original_data=='') {
         //missing original data - this happens if user is adding job that already exists.
         if (($original_data=tws_composer_create_from("js=$tws_jobstream_name"))===FALSE) {
            tws_err("Unable to get original data required to create backup.");
         }
      }

// write vars to hidden
      echo "<input type=\"hidden\" name=\"original_data\" value=\"".htmlspecialchars($original_data)."\">\n";
      echo tws_create_hidden_inputs($_POST);

      if (tws_zli_module_check ()) {
          echo "<input type=\"hidden\" name=\"netmodule_file\" value=\"".htmlspecialchars($netmodule_file)."\">\n";
          echo "<input type=\"hidden\" name=\"netmodule_show_prompt\" value=\"".htmlspecialchars($netmodule_show_prompt)."\">\n";
          echo "<input type=\"hidden\" name=\"netmodule_show_internet\" value=\"".htmlspecialchars($netmodule_show_internet)."\">\n";
          echo "<input type=\"hidden\" name=\"netmodule_show_file\" value=\"".htmlspecialchars($netmodule_show_file)."\">\n";
          echo "<input type=\"hidden\" name=\"netmodule_show_resource\" value=\"".htmlspecialchars($netmodule_show_resource)."\">\n";
      }

      if (tws_rights(SAVEBACKUPS) && $original_data!=''){
         echo "<input type='hidden' name='backup' value='yes'>";
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type='checkbox' name='backup' value='yes' checked disabled>&nbsp;Save Backup Copy of Original Jobstream</label>\n";
      }
      else
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type=\"checkbox\" name=\"backup\" value=\"yes\" ".($original_data!='' ? 'checked' : 'disabled').">&nbsp;Save Backup Copy of Original Jobstream</label>\n";
      echo "<br><br><br>\n";
      if ($modify == "yes") {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Update\" />\n";
      } else {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Replace\" />\n";
      }
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"action\" value=\"Return to Jobstream Modification\" />\n";
      tws_print_synchro_token();   // synchro_token
      echo "</form>\n";
   }
   else {
      // Create Backup Copy if option checked
      if ($backup == "yes") {
         if (($bckfilename = tws_write_backup($original_data, "jobstream", "$workstation#$jobstream")) === FALSE) {
            tws_err("Unable to write backup");
         }
      }

// Build jobstream definition
      $tmpfilename="$maestro_dir/webadmin/tmp/jobstream.".tws_rndstr().".tmp";
      $fp=fopen("$tmpfilename","w") or tws_dyer("Unable to create temporary file '$tmpfilename'");

$cmd = tws_arr_to_composer('jobstream', $_POST);

// write the composer command to the temporary file
      if (fwrite($fp, $cmd)===FALSE) {
         fclose($fp);
         tws_dyer("Unable to write temporary file", $tmpfilename);
      }
      fclose($fp);
      tws_chmod($tmpfilename,0644);

      if ($confirm == "yes") {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'],  "replace $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      } else {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "add $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      }

      if(tws_yesno($tws_config['unlock_before'])=='YES')
         tws_composer_unlock("js=$tws_jobstream_name");  // unlock the object

      $stdout3='';
      $ec_popen=tws_popen($command3, $ec3, $stdout3, $stdout3, "N");

      //testing for the AWSBIA288I Total objects updated: 0.
      //Note: This has been added on 2016-07 to fix the problem of composer updating
      //correctly objects but returning incorrect return codes (not 0 or 4)
      $not_updated=!preg_match('/AWSBIA288[^\n]+(\d+)/', $stdout3, $_r) || $_r[1]==0;

      if ($ec_popen===FALSE || ($ec3!=0 && $ec3!=4 && $not_updated)) {
         if ($modify == "yes") {
            echo "<h1>Modify Jobstream</h1>\n";
         } else {
            echo "<h1>Add Jobstream</h1>\n";
         }
         tws_err("Jobstream add/modify operation failed", array('twscmd'=>$command3->compile('log'), 'stdout'=>$stdout3, "EC_POPEN"=>$ec_popen, "EC_UPDATED"=>$ec3, "NOT_UPDATED"=>tws_yesno($not_updated,'YES','NO')));
         echo "Jobstream Definition: ". nl2br(file_get_contents($tmpfilename));    // DEBUG only!

            echo "<form action=\"tws_add_jobstream4_action.php\" method=\"post\">\n";
            echo tws_create_hidden_inputs($_POST);
            tws_print_synchro_token();
            echo "<input type=\"submit\" name=\"action\" value=\"Cancel\"/>\n";
            echo "<input type=\"submit\" name=\"action\" value=\"Return to Jobstream Modification\"/>\n";
            echo "</form>";
      }
      else {
         // unlock the object
         if(tws_yesno($tws_config['unlock_before'])=='NO') tws_composer_unlock("js=$tws_jobstream_name");
         if ($ec3==4 || preg_match("/warnings?\s[1-9]/i",$stdout3)) {
            if ($modify == "yes") {
               $headertext="Modify Jobstream Status";
            } else {
               $headertext="Add Jobstream Status";
            }
           tws_err("The jobstream has been saved with the following warnings:", array('stdout'=>$stdout3));

           $shortwarnfilename="warn.".tws_rndstr().".txt";
           $warnfilename="$webadmin_tmp_dir/$shortwarnfilename";
           $warnfp=fopen("$warnfilename","w") or tws_dyer("Unable to create warning text file", "Warning output :\n$stdout3");
           $num_bytes=fwrite($warnfp,"$stdout3");
           if ($num_bytes < 0) {
               fclose($warnfp);
               unlink($warnfilename);
               tws_dyer("Unable to write warning text file", "Warning output :\n$stdout3");
           }
           fclose($warnfp);
           tws_dyer();
         }
         if (tws_zli_module_check () && $netmodule_file != "") {
            require_once ("zli_lib.php");
            $validfrom = substr (tws_make_url_valid_from ($validfrom), 1);
            zli_netmod_file_addstream($workstation, $jobstream, $validfrom, $netmodule_file,
                                      $netmodule_show_prompt,
                                      $netmodule_show_internet,
                                      $netmodule_show_file,
                                      $netmodule_show_resource, $modify);

            $message = urlencode ("The stream has been saved successfuly.");
            echo "<script type='text/javascript'>\n";
            echo "window.location.replace(\"zli_close_window.php?message=$message\");\n";
            echo "</script>\n";
         }
         else {
            if ($backup == "yes") {
               if ($modify == "yes") {
                  echo "<h1>Modify Jobstream Status</h1>\n";
               } else {
                  echo "<h1>Add Jobstream Status</h1>\n";
               }
               echo "<p class=\"message\">\n";
               echo "The jobstream has been successfuly saved.&nbsp;";
               $bckfilename = preg_replace("/\\\\/", '/', $bckfilename);
               $file = explode('/',$bckfilename);
               $file = end($file);
               if(tws_profile('auth_user_group')=='admin')
                  echo "<a href=\"javascript:showBackup('$file')\">Display Backup File</a>\n";
               echo "</p>\n";
                  echo "<input type=\"button\" value=\"OK\" onClick=\"closeme('tws_jobstreamsx.php')\">\n";
            }
            else {
               echo "<script type='text/javascript'>\n";
                  echo "closeme('tws_jobstreamsx.php');\n";
              echo "</script>\n";
            }
         }
         // remove the tmp file
         unlink($tmpfilename);
      }
   }
?>
</body>
</html>
