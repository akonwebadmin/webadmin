<?php
    $__tlogmode='APPEND';
   require_once 'tws_functions.php';

$object = $_POST['object'];

if($object == 'rc_preview'){
   $arg = tws_gpc_get($_POST['arg']);

   $rc_preview = tws_profile('rc_preview');
   if(is_null($rc_preview)) $rc_preview = array();
   $elemid = tws_rndstr('ELEMID');
   $rc_preview[$elemid] = $arg;
   tws_profile('rc_preview', $rc_preview);
   echo $elemid;
   exit;
}

$xfilter = tws_gpc_get($_POST['xfilter']);

$layout_column = array();
$limit = tws_group_limit();

echo '{"data":[';

switch($object){

   case('dbjob'):
      tws_set_layout('database_jobs');
      if(in_array('Notes',$layout_column))
         $notes=tws_get_notes_exist('@', '@', "(note_type_id=1 OR note_type_id=2 OR note_type_id=3)");

      $result=tws_get_jobs('@', '@', $xfilter, $limit, 1, 'tws_jobsx_ajax');

      if($result == false){
         $adata = array();
         $adata = array_fill(0, count($layout_column)+1, '');
         echo ','. json_encode($adata);
         tws_flush_output();
      }
      break;

   case('dbjobstream'):
      tws_set_layout('database_jobstreams');
      if(in_array('Notes', $layout_column))
         $notes=tws_get_notes_exist('@', '@', "note_type_id=7");
      $result = tws_get_jobstreams('@', '@', '', $xfilter, $limit, 1, 'tws_jobstreamsx_ajax');

      if($result == false){
         $adata = array_fill(0, count($layout_column)+1, '');
         echo ','. json_encode($adata);
         tws_flush_output();
      }
      break;

   case('plan_job'):
      tws_set_layout('plan_job');
      if(in_array('Notes',$layout_column))
         $notes=tws_get_notes_exist('@', '@', "(note_type_id=1 OR note_type_id=2 OR note_type_id=3)" );
      $symphony = tws_profile('symphony');
      $result=tws_get_plan_job_list($xfilter, $symphony, $limit, 1, 'tws_sjx_ajax');
      break;

   case('plan_jobstream'):
      tws_set_layout('plan_jobstream');
      if(in_array('Notes',$layout_column))
         $notes=tws_get_notes_exist('@', '@', "note_type_id=7" );
      $symphony = tws_profile('symphony');
      $result=tws_get_plan_jobstream_list($xfilter, $symphony, $limit, 1, 'tws_ssx_ajax');
      break;
}

echo ']}';


/**
 * display jobs
 * @param unknown $jb
 */
function tws_jobsx_ajax(&$jb){
   global $layout_column, $notes, $composer_db, $tws_config;

   static $first = true;
   if ($first) $first = false;
   else echo ",";

   $adata = array();
   $checkbox_val = $jb['job_workstation'].'#';


   if($tws_config['cpuinfo']['version']>='9.5002'){
      if(empty($jb['job_workstation_folder']))
         $jb['job_workstation_folder'] = '/';
      $checkbox_val = $jb['job_workstation_folder'].$checkbox_val;

   }
   if($tws_config['cpuinfo']['version']>='9.5')
      $checkbox_val .= $jb['job_folder'];

   $checkbox_val .= $jb['job_name'];
   $jobref = $checkbox_val;

   $adata[] = '<input name="selection[]" type="checkbox" value="'.$checkbox_val.'" onclick="selectCheckboxes(this);">';

   for ($c = 0; $c < count($layout_column); $c++) {
      switch ($layout_column[$c]) {
         case 'Workstation Folder':
            $adata[] = $jb['job_workstation_folder'];
            break;
         case 'Workstation':
            $adata[] = $jb['job_workstation'];
            break;
         case 'Job Folder':
            $adata[] = $jb['job_folder'];
            break;
         case 'Job':
            $adata[] = "<a href=\"javascript:displayJob('".$jobref."')\">".$jb['job_name'].'</a>';
            break;
         case 'Task Type':
            $adata[] = $jb['job_task_type'];
            break;
         case 'Logon':
            $adata[] = htmlspecialchars($jb['job_login']);
            break;
         case 'Description':
            $adata[] = htmlspecialchars($jb['job_description']);
            break;
         case 'Last Run':
            $adata[] = (trim($jb['job_last_run'])=='' ? '<span style="display:none">datetime</span>' : tws_iso_to_userdate($jb['job_last_run'], null, FALSE, $composer_db['tz']));
            break;
         case 'Creator':
            $adata[] = $jb['job_creator'];
            break;
         case 'Last Update':
            $adata[] = tws_iso_to_userdate($jb['job_last_updated'], null, FALSE, $composer_db['tz']);
            break;
         case 'Lock':
            $adata[] = $jb['job_lock_by'].' '.tws_iso_to_userdate($jb['job_lock_on'], null, FALSE, $composer_db['tz']);
            break;
         case 'Notes':
            if(!empty($jb['job_folder']))
               $jb['job_name'] = $jb['job_folder'].$jb['job_name'];
            $jbname = $jb['job_workstation'].'#'.$jb['job_name'];
            if(isset($notes[$jbname]))
                $adata[] = "<a href='javascript:displayNote(\"".$jb['job_workstation']."\", \"".$jobref."\");'><img src='images/icons/note.gif' border=0></a>";
            else $adata[] = '';
            break;
      }
   }
   echo json_encode($adata);
   tws_flush_output();
}

function tws_jobstreamsx_ajax(&$js){
   global $layout_column, $notes, $composer_db, $tws_config;

   static $first = true;
   if ($first) $first = false;
   else echo ",";

   $jsname_valid = $js['jobstream_name'].tws_make_url_valid_from($js['jobstream_valid_from']);

   $adata = array();

   $checkbox_val = $js['jobstream_workstation'].'#';
   if($tws_config['cpuinfo']['version']>='9.5')
      $checkbox_val .= $js['jobstream_folder'];
   if($tws_config['cpuinfo']['version']>='9.5002'){
       if(empty($js['workstation_folder']))
           $js['workstation_folder'] = '/';
      $checkbox_val = $js['workstation_folder'].$checkbox_val;
   }
   $checkbox_val .= $jsname_valid;
   $href = $checkbox_val;

// checkbox
   $adata[] = '<input type="checkbox" name="selection[]" value="'.$checkbox_val.'" onclick="selectCheckboxes(this);">';

   for ($c=0; $c<count($layout_column); $c++) {
      switch ($layout_column[$c]) {
         case 'Workstation Folder':
            $adata[] = $js['workstation_folder'];
            break;
         case 'Workstation':
            $adata[] = $js['jobstream_workstation'];
            break;
         case 'Jobstream Folder':
            $adata[] = $js['jobstream_folder'];
            break;
         case 'Jobstream':
             $adata[] = '<a href="javascript:displayJobstream(\''.$href.'\');">'.$js['jobstream_name'].'</a>';
            break;
         case 'Valid From':
            $adata[] = tws_iso_to_userdate($js['jobstream_valid_from'], NULL, TRUE);
            break;
         case 'Valid To':
            $adata[] = tws_iso_to_userdate($js['jobstream_valid_to'], NULL, TRUE);
            break;
         case 'Draft':
            $adata[] = ($js['jobstream_draft']=='YES' ? 'YES' : ' ');
            break;
         case 'Creator':
            $adata[] = $js['jobstream_creator'];
            break;
         case 'Last Update':
            $adata[] = tws_iso_to_userdate($js['jobstream_last_updated'], null, FALSE, $composer_db['tz']);
            break;
         case 'Lock':
            $adata[] = $js['jobstream_lock_by'].' '.tws_iso_to_userdate($js['jobstream_lock_on'], null, FALSE, $composer_db['tz']);
            break;
         case 'Description':
            $adata[] = htmlspecialchars($js['jobstream_description']);
            break;
         case 'Notes':
            if(!empty($js['jobstream_folder']))
               $js['jobstream_name'] = $js['jobstream_folder'].$js['jobstream_name'];
            $jsname = $js['jobstream_workstation'].'#'.$js['jobstream_name'];
            if(isset($notes[$jsname]))
               $adata[] = "<a href='javascript:displayNote(\"".$js['jobstream_workstation']."\", \"".$js['jobstream_name']."\");'><img src='images/icons/note.gif' border=0></a>";
            else $adata[] = '';
            break;
      }
   }
   echo json_encode($adata);
   tws_flush_output();
}

function tws_sjx_ajax(&$sjs, $ia, $ib){
   global $layout_column, $joblog, $page_size, $notes, $grayclass, $ie6;
   global $tws_config;
   static $first = true;

   for ($i=$ia; $i<=$ib; $i++) {
      $adata = array();
      if (isset($sjs['x'][$i])) continue; //job is marked as "removed" - i.e. is to be skipped

      if ($first) $first = false;
      else echo ",";

      $adata['schedid'] = $sjs['schedid'][$sjs['sched_idx'][$i]]; // not displayed, used for <tr> class

      if ($sjs['entry_type'][$i]=='job') {
         $jobid_full=$sjs['cpu'][$sjs['sched_idx'][$i]].';'.$sjs['schedule'][$sjs['sched_idx'][$i]].';'.$sjs['schedtime'][$sjs['sched_idx'][$i]].';'.$sjs['schedid'][$sjs['sched_idx'][$i]].';'.$sjs['jobcpu'][$i].';'.$sjs['job'][$i].';'.@$sjs['jobnum'][$i];
         $adata['js_selection'] = '<input type="checkbox" style="display:none">';
         $adata['selection'] = '<input type="checkbox" name="selection[]" value="'.$jobid_full.'" onclick="selectCheckboxes(this);">';
      }
      else {   // Stream
         //$folder = '';  // to avoid Warnings
//         if($tws_config['cpuinfo']['version']>='9.5'){
//            if(!empty($sjs['folder'][$sjs['sched_idx'][$i]]))
               $folder = $sjs['folder'][$sjs['sched_idx'][$i]];

//            $original_schedname = tws_get_original_schedname($sjs['schedid'][$i]);
//            $sjs['schedule'][$sjs['sched_idx'][$i]] = $original_schedname['jobstream_folder'].$sjs['schedule'][$sjs['sched_idx'][$i]];
//         }

         $ws_folder = $sjs['workstation_folder'][$sjs['sched_idx'][$i]];

         $adata['js_selection'] = '<input type="checkbox" name="js_selection[]" onclick="selectCheckboxes(this);" value="'.$sjs['cpu'][$sjs['sched_idx'][$i]].';'.$sjs['schedule'][$sjs['sched_idx'][$i]].';'.$sjs['schedtime'][$sjs['sched_idx'][$i]].';'.$sjs['schedid'][$sjs['sched_idx'][$i]].'">';
         $adata['selection'] = '<a class="collapsJS" id="a_'.$sjs['schedid'][$sjs['sched_idx'][$i]].'" href="javascript:collaps(\''.$sjs['schedid'][$sjs['sched_idx'][$i]].'\')" style="text-decoration:none; font-weight:bold;"><b> &#8212; </b></a>';
      }

      for ($c=0; $c < count($layout_column); $c++) {

        switch ($layout_column[$c]) {

          case 'Workstation Folder':
            switch ($sjs['entry_type'][$i]){
               case 'job' :
                  $adata['Workstation Folder']  = '';
                  break;
               case 'schedule' :
                  $adata['Workstation Folder']  = $ws_folder;
                  break;
            }

          case 'Workstation':
            switch ($sjs['entry_type'][$i]){
               case 'job' :
                  $adata['Workstation'] = '<div class="ws" style="display:none;"><a href="tws_ssx.php?tmp='.$sjs['cpu'][$sjs['sched_idx'][$i]].'%23@" >'.$sjs['cpu'][$sjs['sched_idx'][$i]].'</a></div><div style="display:none;">'.$sjs['schedid'][$sjs['sched_idx'][$i]].'&nbsp;</div>';
                  if (trim($sjs['jobrun'][$i])!='')
                     $adata['Workstation'] .= $sjs['jobrun'][$i]; //jobrun contains stuff like "every run", "recovery" etc...
                  break;

               case 'schedule' :
                  $adata['Workstation'] = '<a href="tws_scx.php?tmp=@!'.$ws_folder.$sjs['cpu'][$sjs['sched_idx'][$i]].'">'.$sjs['cpu'][$sjs['sched_idx'][$i]].'</a><div style="display:none;">'.$sjs['schedid'][$sjs['sched_idx'][$i]].'</div>';
                  break;
               default:
                  $adata['Workstation'] = '';
            } //entry_type switch
            break;

          case 'Jobstream Folder':
            switch ($sjs['entry_type'][$i]) {
               case 'schedule':
                  //$adata['Jobstream Folder'] = $original_schedname['jobstream_folder'];
                  $adata['Jobstream Folder'] = $folder;
                  break;
               case 'job':
                  // job Folder is empty
                  $adata['Jobstream Folder'] = '';
            } //entry_type switch
            break;

          case 'Jobstream':
            switch ($sjs['entry_type'][$i]) {
               case 'schedule' :
                  if(!empty($sjs['folder'][$sjs['sched_idx'][$i]]))
                     $jsfolder = $sjs['folder'][$sjs['sched_idx'][$i]];
                  else $jsfolder = '';
                  $adata['Jobstream'] = '<div><a href="tws_ssx.php?tmp='.$sjs['cpu'][$sjs['sched_idx'][$i]].'%23'.$jsfolder.$sjs['schedule'][$sjs['sched_idx'][$i]].'">'.$sjs['schedule'][$sjs['sched_idx'][$i]].'</a></div>';
                  $adata['Jobstream'] .= '<div class="schedid" style="display:none;"><a href="tws_sjx.php?tmp='.$sjs['cpu'][$sjs['sched_idx'][$i]].'%23'.$sjs['schedid'][$sjs['sched_idx'][$i]].';schedid">'.$sjs['schedid'][$sjs['sched_idx'][$i]].'</a></div>';
                  break;
               default:
                 $adata['Jobstream'] = '<div class="js" style="display:none;"><a href="tws_sjx.php?tmp='.$sjs['cpu'][$sjs['sched_idx'][$i]].'%23'.$sjs['schedid'][$sjs['sched_idx'][$i]].';schedid">'.$sjs['schedule'][$sjs['sched_idx'][$i]].'</a></div><div style="display:none;">'.$sjs['schedid'][$sjs['sched_idx'][$i]].'&nbsp;</div>';
            }
            break;
          case 'Sched Time':
               $disp_time = tws_conman_to_userdate($sjs['schedtime'][$sjs['sched_idx'][$i]], TRUE);
            switch ($sjs['entry_type'][$i]) {
               case 'schedule':
                  $adata['Sched Time'] = $disp_time.'<div style="display:none;">'.$sjs['schedid'][$sjs['sched_idx'][$i]].'</div>';
                  break;
               default:
                  $adata['Sched Time'] = '<div class="st" style="display:none;">'.$disp_time.'</div><div style="display:none;">'.$sjs['schedid'][$sjs['sched_idx'][$i]].'&nbsp;</div>';
            } //entry_type switch
            break;
          case 'Job':
            switch ($sjs['entry_type'][$i]) {
               case 'job' :
                  if ($joblog!='multiple' && $sjs['jobnum'][$i]!='') {
                     //in SINGLE mode, use the job number rather than job name to identify the required job log
                     $jobname=$sjs['cpu'][$sjs['sched_idx'][$i]].'#'.$sjs['jobnum'][$i];
                  } else {
                     $jobname=$sjs['cpu'][$sjs['sched_idx'][$i]].'#'.$sjs['schedid'][$sjs['sched_idx'][$i]].'.'.$sjs['job'][$i].';schedid';
                  }
                  $jobname.=';'.$sjs['start_time'][$i]; //start time is important to identify the correct symphony date why maual searching of the job log (more in tws_stdlist.php)
                  $jobname.=';'.$sjs['job'][$i];        // To avoid multiple jobs output with the same job number
                  $disp_time = tws_conman_to_userdate($sjs['schedtime'][$sjs['sched_idx'][$i]], TRUE);
                  $job_title = $sjs['cpu'][$sjs['sched_idx'][$i]].'#'.$sjs['schedule'][$sjs['sched_idx'][$i]].' '.$disp_time;
                  $adata['Job'] = '<a href="javascript:OpenStdlist(\''.$jobname.'\');" title="'.$job_title.'">'.($sjs['cpu'][$sjs['sched_idx'][$i]]!=$sjs['jobcpu'][$i] ? '('.$sjs['jobcpu'][$i].'#)' : '').$sjs['job'][$i].'</a>';
                  break;
               case 'schedule' :
                  $adata['Job'] = '';
                  break;
               default:
                  $adata['Job'] = '';
            } //entry_type switch
            break;

          case 'State':
            if ($sjs['state'][$i]=='SUCC')
               $adata['State'] = '<span class=good>'.$sjs['state'][$i].'</span>';
            elseif ($sjs['state'][$i]=='ABEND' || $sjs['state'][$i]=='FAIL' || $sjs['state'][$i]=='ERROR' || $sjs['state'][$i]=='STUCK')
               $adata['State'] = '<span class=error>'.$sjs['state'][$i].'</span>';
            elseif ($sjs['state'][$i]=='EXTRN' || $sjs['state'][$i]=='EXEC')
               $adata['State'] = '<span class=warning>'.$sjs['state'][$i].'</span>';
            elseif ($sjs['state'][$i]=='')
               $adata['State'] = '';
            else
               $adata['State'] = $sjs['state'][$i];
            break;

          case 'Priority':
            if ($sjs['priority'][$i]=='') {
               $adata['Pri'] = '';
            } else {
               if($sjs['priority'][$i]=='0')
                  $adata['Pri'] = '<span class=warning>'.$sjs['priority'][$i].'</span>';
               else
                  $adata['Pri'] = $sjs['priority'][$i];
            }
            break;
          case 'Start':
            if (($st=$sjs['start_time'][$i])=='') {
               $adata['Start'] = '';
            } else {
               if (preg_match('/^\((.+)\)$/', $st, $_r)) {
                  $est=TRUE;
                  $st=$_r[1];
               } else $est=FALSE;
               $adata['Start'] = ($est ? '(' : '').tws_conman_to_userdate($st, TRUE).($est ? ')' : '');
               }
            break;
          case 'Elapse':
               $adata['Elapse'] = $sjs['elapse_time'][$i];
            break;
          case 'Exit Code': case 'Return Code':
               $adata['RC'] = $sjs['exit_code'][$i];
            break;
          case 'Dependencies':
            $adata['Dependencies'] = '';
            if ($sjs['entry_type'][$i] == 'schedule') {
               $tmp = trim(substr($sjs['schedrun'][$sjs['sched_idx'][$i]],0,8));
               if($tmp=="*LIM  0*")
                  $adata['Dependencies'] .= '<span class=warning><i>'.$tmp.'</i></span>,';
               elseif(substr($tmp,0,4)=='*LIM')
                  $adata['Dependencies'] .= "<i>$tmp</i> ,";
            }
            foreach ($sjs['dep'][$i] as $j=>$dep_string) {
               $sep=($j < count($sjs['dep'][$i])) ? ',&nbsp;' : '';
               $dep_src=$dep_string;
               $dep_string=htmlspecialchars($dep_src);

               if (strpos($dep_string,'$PROMPT:')) {     // PROMPT
                  $depx=strtok($dep_string,'$');
                  $temp=strtok(':');
                  $dep_state=strtok('$');
                  $dep_link=substr(strtok($depx,'('),1);
                  $adata['Dependencies'] .= '<b>? </b>';
                  if ($dep_state=='NO') {
                     $adata['Dependencies'] .= '<span class=error>';
                  } elseif ($dep_state=='YES') {
                     $adata['Dependencies'] .= '<span class=good>';
                  } elseif ($dep_state=='ASKED') {
                     $adata['Dependencies'] .= '<span class=warning>';
                  } else {
                     $adata['Dependencies'] .= '<span>';
                  }
                  $adata['Dependencies'] .= '<a href="tws_spx.php?tmp='.$dep_link.'">'.$depx.' ('.$dep_state.')</a></span>';
               }
               elseif (strpos($dep_string,'$FOLLOWS:')) {    //    FOLLOWS
                  $depx=strtok($dep_string,'$');
                  $temp=strtok(':');
                  $dep_state=strtok('$');
                  // if have "[(time),(id)].job" - extract id and job
                  if(preg_match('/\[\(.*\),\((.*)\)\]\.(.*)$/', $depx, $matches)) {
                     if ( ($pos = strpos($depx, '#'))!==false)
                        $dep_cpu = substr($depx, 0, $pos)."#";
                     else $dep_cpu = '';
                     $dest = 'tws_sjx.php';
                     if(strpos($matches[2], ' [P]') !== false || strpos($matches[2], ' [O]') !== false)     // Planned for future / overtimed
                        $dep_link = '';
                     else{
                        list($matches[2], $cond) = explode(' IF ', $matches[2]); // cond dep from TWS 9.3
                        $dep_link = $dep_cpu.$matches[1].".".$matches[2].";schedid";
                     }
                  }
                  elseif (strpos($depx, '::')===false) { // if(not internetwork dependence)
                     // internal job dependence
                     $dest = 'tws_sjx.php';
                     $dep_link = $sjs['cpu'][$sjs['sched_idx'][$i]].'#'.$sjs['schedid'][$sjs['sched_idx'][$i]].".$depx;schedid";
                  }
                  else $dep_link = '';    // internetwork dependence

                  $adata['Dependencies'] .= '<b>&#8212;> </b>';
                  if ($dep_state=='ABEND' || $dep_state=='FAIL' || $dep_state=='ERROR' || $dep_state=='STUCK')
                     $adata['Dependencies'] .= '<span class=error>';
                  elseif ($dep_state=='EXTRN')
                     $adata['Dependencies'] .= '<span class=warning>';
                  elseif ($dep_state=='SUCC')
                     $adata['Dependencies'] .= '<span class=good>';
                  else $adata['Dependencies'] .= '<span>';

                  if(!empty($dep_link))
                     $adata['Dependencies'] .= '<a href="'.$dest.'?tmp='.urlencode($dep_link).'">'.$depx.'</a> ('.$dep_state.')'.'</span>';
                  else $adata['Dependencies'] .= $depx.'('.$dep_state.')</span>';
               }
               elseif (strpos($dep_string,'$OPENS:')) {   // OPENS
                  $depx=strtok($dep_string,'$');
                  $temp=strtok(':');
                  $dep_state=strtok('$');
                  $dep_link=str_replace('#','%23',$depx);
                  $adata['Dependencies'] .= '<b>&#664; </b>';
                  if ($dep_state=='NO') {
                     $adata['Dependencies'] .= '<span class=error>';
                  } elseif ($dep_state=='YES') {
                     $adata['Dependencies'] .= '<span class=good>';
                  } else {
                     $adata['Dependencies'] .= '<span>';
                  }
                  $adata['Dependencies'] .= '<a href="tws_sfx.php?tmp='.$dep_link.'">'.$depx.' ('.$dep_state.')</a></span>';
               }
               elseif (strpos($dep_string,'$NEEDS:')) {   // NEEDS
                  $depx=strtok($dep_string,'$');
                  $temp=strtok(':');
                  $dep_state=strtok('$');
                  $dep_link = substr(trim($depx), 1, -1);      // remove '-' from begin and end
                              // old and wrong variant because res name may contain '-' symbol:
                  //$dep_link_array=explode('-',$depx);
                  //$dep_link=$dep_link_array[1];
                  if (strstr($dep_link,' '))
                     $dep_link=trim(strstr($dep_link,' '));
                  $dep_link = str_replace('#', '%23', $dep_link);
                  $adata['Dependencies'] .= '<b>! </b>';
                  if ($dep_state=='AVAIL') {
                     $adata['Dependencies'] .= '<span class=good>';
                  } else {
                     $adata['Dependencies'] .= '<span class=warning>';
                  }
                  $adata['Dependencies'] .= '<a href="tws_srx.php?tmp='.$dep_link.'">'.$depx.' ('.$dep_state.')</a></span>';
               }
               elseif (strpos($dep_string,'$UNTIL:')) {   //    UNTIL
                  $depx=strtok($dep_string,'$');
                  $temp=strtok(':');
                  $dep_state=strtok('$');
                  if ($dep_state=='EXPIRED')
                     $adata['Dependencies'] .= '<span class=error>'.$depx.'('.$dep_state.')</span>';
                  else
                     $adata['Dependencies'] .= '<span>'.$depx.'('.$dep_state.')</span>';
               }
               elseif ((substr($dep_string,0,1)=='[') && (strpos($dep_string,',')!==FALSE)){
                  $adata['Dependencies'] .= '<span><i>'.str_replace(' ','',$dep_string).'</i></span>';
               }
               elseif (preg_match('!<\d{2}[:/]\d{2}!', $dep_src)) {
                  $adata['Dependencies'] .= '<span>'.$dep_string.'&nbsp;(DEADLINE)</span>';
               }
               elseif($dep_string == '[Cancelled]')
                  $adata['Dependencies'] .= "<span class=warning><i>$dep_string</i></span>";
               else {
                  $adata['Dependencies'] .= '<span><i>'.$dep_string.'</i></span>';
               }
               $adata['Dependencies'] .= $sep;
            }
            break;

         case 'Notes':
            $jbname = $sjs['jobcpu'][$i].'#'.$sjs['job'][$i];
            if($sjs['entry_type'][$i] == 'job' && isset($notes[$jbname]))
               $adata['Notes'] =  "<a href='javascript:displayNote(\"".$sjs['jobcpu'][$i]."\", \"".$sjs['job'][$i]."\");'><img src='images/icons/note.gif' border=0 alt='Notes exist'></a>";
            else
               $adata['Notes'] = '';
            break;
         }
      }
      echo json_encode($adata);
      tws_flush_output();     //
      $adata = null;
   }
}

function tws_ssx_ajax(&$sss, $ia, $ib){
   global $layout_column, $notes, $composer_db, $tws_config;
   static $first = true;
   $adata = array();

   for ($i=$ia; $i<=$ib; $i++) {
      if ($first) $first = false;
      else echo ",";
      $folder = '';
      if(!empty($sss['folder'][$i]))
         $folder = $sss['folder'][$i];

      $ws_folder = $sss['workstation_folder'][$i];

      $ssid_full=$ws_folder.$sss['cpu'][$i].';'.$folder.$sss['schedule'][$i].';'.$sss['schedtime'][$i].';'.$sss['schedid'][$i];
      $adata[] = '<input type="checkbox" name="selection[]" value="'.$ssid_full.'" onclick="selectCheckboxes(this);">';

      for ($c=0; $c<count($layout_column); $c++) {

      switch ($layout_column[$c]) {

       case "Workstation Folder":
          $adata[] = $ws_folder;
          break;

          case 'Workstation':
            $adata[] = '<a href="tws_scx.php?tmp=@!'.$ws_folder.$sss['cpu'][$i].'">'.$sss['cpu'][$i].'</a>';
            break;

          case 'Jobstream':
            $adata[] = '<a href="tws_sjx.php?tmp='.$ws_folder.$sss['cpu'][$i].'%23'.$sss['schedid'][$i].';schedid">'.$sss['schedule'][$i].'</a>';
            break;

         case 'Jobstream Folder':
            if(!empty($sss['folder'][$i]))
               $adata[] = $sss['folder'][$i];
            break;

          case 'Sched Time':
            if (($scht=$sss['schedtime'][$i])=='') {
               $adata[] = '';
            } else {
               $adata[] = tws_conman_to_userdate($scht, TRUE);
            }
            break;
          case 'State':
            if ($sss['state'][$i]=='SUCC') {
               $adata[] = '<span class=good>'.$sss['state'][$i].'</span>';
            } elseif ($sss['state'][$i]=='ABEND' || $sss['state'][$i]=='ERROR' || $sss['state'][$i]=='STUCK') {
               $adata[] = '<span class=error>'.$sss['state'][$i].'</span>';
            } elseif ($sss['state'][$i]=='EXTRN' || $sss['state'][$i]=='EXEC') {
               $adata[] = '<span class=warning>'.$sss['state'][$i].'</span>';
            } elseif ($sss['state'][$i]=='') {
               $adata[] = '';
            } else {
               $adata[] = $sss['state'][$i];
            }
            break;
          case 'Priority':
            if ($sss['priority'][$i]=='') {
               $adata[] = '';
            } else {
               if($sss['priority'][$i]=='0')
                  $adata[] = '<span class=warning>'.$sss['priority'][$i].'</span>';
               else
                  $adata[] = $sss['priority'][$i];
            }
            break;
          case 'Start':
            if (($st=$sss['start_time'][$i])=='') {
               $adata[] = '';
            } else {
               if (preg_match('/^\((.+)\)$/', $st, $_r)) {
                  $est=TRUE;
                  $st=$_r[1];
               } else $est=FALSE;
               $adata[] = ($est ? '(' : '').tws_conman_to_userdate($st, TRUE).($est ? ')' : '');
            }
            break;
          case 'Elapse':
            if ($sss['elapse_time'][$i]=='') {
               $adata[] = '';
            } else {
               $adata[] = $sss['elapse_time'][$i];
            }
            break;
          case 'Num Jobs':
            if ($sss['num_jobs'][$i]=='') {
               $adata[] = '';
            } else {
               if(!is_numeric($sss['num_jobs'][$i]))
                  $adata[] = "<span class='warning'>".$sss['num_jobs'][$i]."</span>";
               else $adata[] = $sss['num_jobs'][$i];
            }
            break;
          case 'OK Jobs':
            if ($sss['ok_jobs'][$i]=='') {
               $adata[] = '';
            } else {
               if(!is_numeric($sss['ok_jobs'][$i]))
                  $adata[] = "<span class='warning'>".$sss['ok_jobs'][$i]."</span>";
               else $adata[] = $sss['ok_jobs'][$i];
            }
            break;
          case 'Limit':
            if ($sss['limit'][$i]=='') {
               $adata[] = '';
            } else {
               if($sss['limit'][$i]==0)
                  $adata[] = '<span class=warning>'.$sss['limit'][$i].'</span>';
               else
                  $adata[] = $sss['limit'][$i];
            }
            break;
          case 'Sched ID':
               $adata[] = $sss['schedid'][$i];
            break;
          case 'Dependencies':
            $res = '';
            foreach ($sss['dep'][$i] as $j=>$dep_string) {
               $sep=($j<count($sss['dep'][$i])) ? ',&nbsp;' : '';
               $dep_src=$dep_string;
               $dep_string=htmlspecialchars($dep_src);

               if (strstr($dep_string,'$PROMPT:')) {     // PROMPT
                  $depx=strtok($dep_string,'$');
                  $temp=strtok(':');
                  $dep_state=strtok('$');
                  $dep_link=substr(strtok($depx,'('),1);
                  $res .= '<b>? </b>';
                  if ($dep_state=='NO')   $res .= '<span class=error>';
                  elseif ($dep_state=='YES') $res .= '<span class=good>';
                  elseif ($dep_state == "ASKED") $res .= '<span class=warning>';
                  else $res .='<span>';
                  $res .= "<a href='tws_spx.php?tmp=$dep_link'>$depx ($dep_state)</a></span>";

               }
               elseif (strstr($dep_string,'$FOLLOWS:')) {    //    FOLLOWS
                  $depx=strtok($dep_string,'$');
                  $temp=strtok(':');
                  $dep_state=strtok('$');
                  // if have "[(time),(id)].job" - extract id and job
                  if(preg_match('/\[\(.*\),\((.*)\)\]\.(.*)$/', $depx, $matches)) {
                     if ( ($pos = strpos($depx, '#'))!==false)
                        $dep_cpu = substr($depx, 0, $pos)."#";
                     else $dep_cpu = '';
                     $dest = 'tws_sjx.php';
                     if(strpos($matches[2], ' [P]') !== false || strpos($matches[2], ' [O]') !== false)     // Planned for future / overtimed
                        $dep_link = '';
                     else{
                        list($matches[2], $cond) = explode(' IF ', $matches[2]); // cond dep from TWS 9.3
                        $dep_link = $dep_cpu.$matches[1].".".$matches[2].";schedid";
                     }
                  }
                  else $dep_link = '';

                  $res .= '<b>&#8212;> </b>';
                  if ($dep_state=='ABEND' || $dep_state=='FAIL' || $dep_state=='ERROR' || $dep_state=='STUCK')
                     $res .= '<span class="error">';
                  elseif ($dep_state=='EXTRN')
                     $res .= '<span class="warning">';
                  elseif ($dep_state=='SUCC')
                     $res .= '<span class="good">';
                  else
                     $res .= '<span>';

                  if(!empty($dep_link))
                     $res .='<a href="'.$dest.'?tmp='.urlencode($dep_link).'">'.$depx.'</a> ('.$dep_state.')</span>';
                  else
                     $res .= $depx.'('.$dep_state.')</span>';

               } elseif (strstr($dep_string,'$OPENS:')) {    //    OPENS
                  $depx=strtok($dep_string,'$');
                  $temp=strtok(':');
                  $dep_state=strtok('$');
                  $dep_link=str_replace('#','%23',$depx);
                  $res .= '<b>&#664; </b>';
                  if ($dep_state=='NO') {
                     $res .='<span class=error><a href="tws_sfx.php?tmp='.$dep_link.'">'.$depx.'('.$dep_state.')</a></span>';
                  } elseif ($dep_state=='YES') {
                     $res .= '<span class=good><a href="tws_sfx.php?tmp='.$dep_link.'">'.$depx.'('.$dep_state.')</a></span>';
                  } else {
                     $res .='<span><a href="tws_sfx.php?tmp='.$dep_link.'">'.$depx.'('.$dep_state.')</a></span>';
                  }
               } elseif (strstr($dep_string,'$NEEDS:')) {    //    NEEDS
                  $depx=strtok($dep_string,'$');
                  $temp=strtok(':');
                  $dep_state=strtok('$');
                  $dep_link = substr(trim($depx), 1, -1);      // remove '-' from begin and end
                              // old and wrong variant because res name may contain '-' symbol:
                  //$dep_link_array=explode('-',$depx);
                  //$dep_link=$dep_link_array[1];
                  if (strstr($dep_link,' '))
                     $dep_link=trim(strstr($dep_link,' '));
                  $dep_link = str_replace('#', '%23', $dep_link);
                  $res .= '<b>! </b>';
                  if ($dep_state=='AVAIL')
                     $res .= '<span class=good>';
                  else
                     $res .= '<span class=warning>';
                  $res .= '<a href="tws_srx.php?tmp='.$dep_link.'">'.$depx.'('.$dep_state.')</a></span>';

               } elseif (strstr($dep_string,'$UNTIL:')) {
                  $depx=strtok($dep_string,'$');
                  $temp=strtok(':');
                  $dep_state=strtok('$');
                  if ($dep_state=='EXPIRED') {
                     $res .= '<span class=error>'.$depx.'('.$dep_state.')</span>';
                  } else {
                     $res .= '<span>'.$depx.'('.$dep_state.')</span>';
                  }
               } elseif ((substr($dep_string,0,1)=='[') && (strpos($dep_string,',')!==FALSE)) {
                  $res .= '<span><i>'.str_replace(' ','',$dep_string).'</i></span>';
               } elseif (preg_match('!<\d{2}[:/]\d{2}!', $dep_src)) {
                  $res .= '<span>'.$dep_string.'&nbsp;(DEADLINE)</span>';
               }
               elseif($dep_string == '[Cancelled]')
                  $res .= "<span class=warning><i>$dep_string</i></span>";
               else {
                  $res .= '<span><i>'.$dep_string.'</i></span>';
               }
               $res .= $sep;
            }
            $adata[] = $res;
            break;
         case 'Notes':
            if(!empty($sss['folder'][$i]))
               $sss['schedule'][$i] = $sss['folder'][$i].$sss['schedule'][$i];
            tws_log("schedule name: ".$sss['schedule'][$i]);
            $jsname = $sss['cpu'][$i].'#'.$sss['schedule'][$i];
            if(isset($notes[$jsname]))
               $adata[] = "<a href='javascript:displayNote(\"".$sss['cpu'][$i]."\", \"".$sss['schedule'][$i]."\");'><img src='images/icons/note.gif' border=0></a>";
            else
               $adata[] = "";
            break;
         }
      }
      echo json_encode($adata);
      tws_flush_output();
   }
}

?>
