<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");

   // Cancel button test
   $tmp_test = (isset($_POST['action']) && (($_POST['action'] == 'Cancel') || ($_POST['action'] == 'Return to Modification'))) ? true : false;
   if ($tmp_test == true) {
      foreach ($_POST as $key => $val){
         $$key = tws_gpc_get($val);
      }
      $members = explode(':', $setmembers);
   }

   if ($copy == "yes") $h1 = "Copy Workstation Class";
   elseif ($modify=="yes") $h1 = "Modify Workstation Class";
   else $h1 = "Add Workstation Class";
?>
<html>
<head>
<title><?=$h1 ?></title>
<?php tws_stylesheet(); ?>
<script type="text/javascript">
function swapcol(srccontrol,destcontrol)
{
 sel=document.contents[srccontrol].selectedIndex;
 if (sel != -1 && document.contents[srccontrol].options[sel].value > "") {
   temptext=document.contents[srccontrol].options[sel].text;
   tempvalue=document.contents[srccontrol].options[sel].value;
   if (temptext != '@') {
     destpos=document.contents[destcontrol].length;
     if (destpos == 1) {
       if (document.contents[destcontrol].options[0].value == "-NULL-") {
         document.contents[destcontrol].options[0]=null;
         destpos=0;
       }
     }
     document.contents[destcontrol].options[destpos]=new Option(temptext,tempvalue);
   }
   document.contents[srccontrol].remove(document.contents[srccontrol].selectedIndex);
   document.contents[srccontrol].selectedIndex=-1;
 }
}
function addAll()
{
 destcontrol='include';
 destpos=document.contents[destcontrol].length;
 document.contents[destcontrol].options[destpos]=new Option('@','@');
}
function setMembers()
{
 numinclude=document.contents['include'].length;
 newmembers="";
 if (numinclude > 0) {
   for (i=0; i<numinclude; i++) {
     newmembers += document.contents['include'].options[i].value + ":";
   }
   if (newmembers.substring((newmembers.length - 1),newmembers.length) == ":") {
     newmembers="" + newmembers.substring(0,(newmembers.length - 1));
   }
 } else {
   newmembers="";
 }
 document.contents['setmembers'].value=newmembers;
}
function ConfirmCancel(objectname,url){
   tws_waiting(0);
 var conftext=confirm("Exit " + objectname + " Definition (Changes will be lost) ?");
 if (conftext) {
   if (url==null) return true;
      closeme(url);
 } else {
   return false;
 }
}
</script>
</head>
<body>
<? tws_set_window_title();
   $log_file_name=tws_log('', 'OPEN');
   tws_log('-- START ('.basename(__FILE__).'['.__LINE__.'])');

   tws_print_head($h1,array('__log__' => $log_file_name));

// If mode is copy or modify, parse existing workstation class definition
   if ($tmp_test == false && ($copy == "yes" || $modify == "yes")) {

      $num_elements=count($selection);
      if ($num_elements == 0)
         tws_dyer("No workstation class selected");
      elseif ($num_elements > 1)
         tws_dyer("Multiple workstation classes selected. Only one workstation class can be ".($copy=="yes" ? 'copied' : 'modified')." at a time.");

      $workstation_class=$selection[0];
      $full_name = $selection[0];

      tws_log("-- ".basename(__FILE__). " full_name = $full_name");

      if (($db_class = tws_get_workstation_classes($full_name)) == FALSE)
         tws_dyer("Unable to list workstation classes");
      if ($db_class['workstation_class_num'] != 1)
         tws_error("Unable to get workstation class $full_name");

      tws_log("-- ".basename(__FILE__). " db_class = ".var_export($db_class, true));
      tws_adjust4html($db_class);
      $workstation_class_name = $db_class['workstation_class_name'][0];
      $description = $db_class['workstation_class_description'][0];
      $ignore = $db_class['workstation_class_ignore'][0];
      if(!empty($db_class['workstation_class_folder'][0]))
         $workstation_class_folder = $db_class['workstation_class_folder'][0];

      if (($member_list = tws_get_class_members($full_name)) == FALSE) {
         tws_dyer("Unable to list workstation class members");
      }
      tws_log("member_list: ".var_export($member_list, true));
      $members_num = $member_list['member_num'];
      $members=Array();
      if (is_array($member_list['workstation_name'])) {
         foreach ($member_list['workstation_name'] as $i => $member){
            if(!empty($member_list['workstation_folder'][$i]))
               $member = $member_list['workstation_folder'][$i].$member;
            $members[]=$member;
         }
      }
// Generate array of all available workstations
   if (($workstations = tws_get_workstations("@")) === FALSE )
      tws_dyer('Unable to list workstations');

   $workstation_num = $workstations['workstation_num'];
   foreach ($workstations['workstation_name'] as $i => $name) {
       $full_name = '';
      if(!empty($workstations['workstation_folder'][$i]))
          $full_name = $workstations['workstation_folder'][$i];
      $workstation_name[] = $full_name.$name;
   }

// Build list of available workstations
      $avail_num=0;
      for ($i=0; $i<$workstation_num; $i++) {
         if (!in_array($workstation_name[$i],$members)) {
            $avail[$avail_num]=$workstation_name[$i];
            $avail_num++;
         }
      }

      if ($modify=="yes") {
// lock object
         tws_composer_lock("wscl=$workstation_class") or tws_dyer("Unable to lock workstation class '$workstation_class'");
// backup
         if (($original_data=tws_composer_create_from("wscl=$workstation_class"))===FALSE) tws_dyer("Unable to create backup");
      }

   }
   else {
      $avail=$workstation_name;
      $avail_num=$workstation_num;
   }
?>

<br><br>
<form method=post name="contents" action="tws_add_workstation_class_exec.php" onSubmit="if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Workstation Class',null)) { cancel_button_pressed=false; return false;} setMembers(); return true">
<input type="hidden" name="original_data" value="<?=htmlspecialchars($original_data)?>"/>
<input type="hidden" name="setmembers" value="">
<table border=0 cellspacing=0>
<tr>
<td class=standard colspan=2>
<h3>Properties</h3>
</td>
</tr>
<? if ($tws_config['cpuinfo']['version']>='9.5002'){ ?>
    <tr>
    <td class=standard>
    &nbsp;&nbsp;<b>Workstation Class Folder:</b>
    </td>
    <td class=standard>
    <input type="text" name="workstation_class_folder" class="tws_name" required="required" size="60" maxlength="200" value="<?=$workstation_class_folder?>" <?if ($modify == "yes") echo " disabled"; ?> />
      <? if ($modify != "yes"){ ?>
         &nbsp;&nbsp;&nbsp;&nbsp;<input type="button" name="workstation_class_folder_picker" onClick="tws_picker_open('folder_picker.php', 'fieldname=workstation_class_folder&amp;fieldvalue=' + document.contents.workstation_class_folder.value);" value="List">
      <? } ?>
    </td>
    </tr>
<? } ?>
<tr>
<td class=standard>
&nbsp;&nbsp;<b>Workstation Class:</b>
</td>
<td class=standard>
<input type="text" name="workstation_class_name" class="tws_name" required="required" size="60" maxlength="200" <? if (isset($workstation_class_name)) echo " value='".htmlspecialchars($workstation_class_name)."'"; if ($modify == "yes") echo " disabled"; ?> />
</td>
</tr>
<tr>
<td class=standard>
&nbsp;&nbsp;<b>Description:</b>
</td>
<td class=standard>
<input type="text" name="description" size=45 maxlength=120 <?php if (isset($description)) echo " value=\"$description\""; ?>>
</td>
</tr>
<tr>
<td class=standard>
&nbsp;&nbsp;<b>Ignore:</b>
</td>
<td class=standard>
<input type="checkbox" name="ignore" value="Y" <?php if (tws_yesno($ignore)=="YES" ) echo "checked"; ?>>
</td>
</tr>

   <?
   if ($copy == "yes") {
      echo "<script type='text/javascript'>\n";
      echo "<!--\n";
      echo "document.contents.workstation_class_name.focus();\n";
      echo "document.contents.workstation_class_name.select();\n";
      echo "// -->\n";
      echo "</script>\n";
   }
?>
<tr><td>&nbsp;</td></tr>
<tr>
<td class=standard colspan=2>
<h3>Workstation List</h3>
</td>
</tr>
<tr>
<td class=standard colspan=2>
  <table border=0 cellspacing=0>
  <tr>
  <td class=standard align="center">
  <h3>Members</h3>
  </td>
  <td width=50 rowspan=6>&nbsp;</td>
  <td class=standard align="center">
  <h3>Available Workstations</h3>
  </td>
  </tr>
  <tr>
  <td class=standard>
  <select name="include" size=10 style="width: 16em;" onDblClick="swapcol('include','exclude')">
<?php
   if (is_array($members)) {
      if (count($members) > 0) {
         foreach ($members as $i=>$val) {
            echo "<option value=\"$members[$i]\">$members[$i]</option>\n";
         }
      }
   }
?>
  </select>
  </td>
  <td class=standard>
  <select name="exclude" size=10 style="width: 16em;" onDblClick="swapcol('exclude','include')">
<?php
   if (is_array($avail)) {
      if (count($avail) > 0) {
         for ($i=0; $i<$avail_num; $i++) {
            echo "<option value=\"$avail[$i]\">$avail[$i]</option>\n";
         }
      }
   }
?>
  </select>
  </td>
  </tr>
  <tr><td colspan=4>&nbsp;</td></tr>
  <tr>
  <td align="center"><input type="button" name="remove" value="Remove  ->" onClick="swapcol('include','exclude')"></td>
  <td align="center"><input type="button" name="add" value="<-  Add" onClick="swapcol('exclude','include')"></td>
  </tr>
  <tr><td colspan=4>&nbsp;</td></tr>
  <tr>
  <td>&nbsp;</td>
  <td align="center"><input type="button" name="addall" value="<-  Add All" onClick="addAll()"></td>
  </tr>
  </table>
</td>
</tr>
</table>
<br><br>
<?
   if ($modify == "yes") {
      echo "<input type='hidden' name='modify' value='yes'>\n";
      echo "<input type='hidden' name='workstation_class_name' value='".htmlspecialchars($workstation_class)."'>\n";
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' name='action' value='Update' onClick='return tws_validate_form()'/>\n";
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' name='action' value='Cancel' onClick='cancel_button_pressed=true;'/>\n";

   }
   else {
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' name='action' value='Add' onClick='return tws_validate_form()'/>\n";
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' value='Cancel' onClick='ConfirmCancel('Workstation Class','tws_workstation_classesx.php')'/>\n";
   }
?>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" value="Print" onClick="window.print()">
<? tws_print_synchro_token();
   tws_log('-- FINISH ('.basename(__FILE__).'['.__LINE__.'])', 'CLOSE');
?>
</form>
</body>
</html>
