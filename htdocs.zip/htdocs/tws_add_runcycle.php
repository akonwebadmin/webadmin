<?php
//   HORIZONT Software GmbH, Munich
//
   require_once 'tws_functions.php';
   tws_doctype('t');

   // Cancel button test
   $tmp_test = (isset($_POST['action']) && ($_POST['action'] == 'Cancel' || $_POST['action'] == 'Return to Modification')) ? true : false;
   if ($tmp_test == true) {
      foreach ($_POST as $key => $val)
         $$key = tws_gpc_get($val);
   }

   if ($copy == "yes")   $h1="Copy Run Cycle Group";
   elseif($modify == "yes") $h1 = "Modify Run Cycle Group";
   elseif ($display == "yes") $h1 = "Display Run Cycle Group";
   else $h1 = "Add Run Cycle Group";

   $log_file_name=tws_log('', 'OPEN');
   tws_log('-- START ('.basename(__FILE__).'['.__LINE__.'])');
?>
<html>
<head>
<title><?=$h1?></title>

<? tws_stylesheet();
   $add_runcycle = true;
   include("tws_add_jobstream_js.php");
?>

<script type="text/javascript">
   function ConfirmCancel(objectname, url) {
   $('form').unbind('submit');
      var conftext = confirm("Exit " + objectname + " Definition (Changes will be lost) ?");
      if (conftext) {
         if (url==null) return true;
         window.location.replace(url);
      }
      else
         return false;
   }
</script>
</head>
<body>
   <div id="showrc">
<? tws_set_window_title();
   tws_print_head($h1, array('__log__' => $log_file_name));

   if ($tmp_test == false && ($copy == "yes" || $modify == "yes" || $display=='yes')) {

      if (($db_rcg=tws_get_runcycles($selection[0]))===FALSE)
         tws_dyer("Unable to get run cycle group data");
      if ($db_rcg['runcycle_num'] == 0)
         tws_dyer("Unable to get run cycle group '$selection[0]'");

      $rcg_description     = $db_rcg['rcg_description'][0];
      $rcg_time_dependent  = $db_rcg['rcg_time_dependent'][0];
      $rcg_start_offset    = $db_rcg['rcg_start_offset'][0];
      $rcg_deadline_offset = $db_rcg['rcg_deadline_offset'][0];
      $rcg_until_offset    = $db_rcg['rcg_latest_start_offset'][0];
      $rcg_onuntil         = $db_rcg['rcg_latest_start_action'][0];
      $rcg_sat_free        = $db_rcg['rcg_saturday_free'][0];
      $rcg_sun_free        = $db_rcg['rcg_sunday_free'][0];
      $rcg_repeat_interval = $db_rcg['rcg_repeat_interval'][0];
      $rcg_repeat_end_time = $db_rcg['rcg_repeat_end_time'][0];
      $rcg_vat_name        = $db_rcg['vat_name'][0];
      $rcg_calendar        = $db_rcg['rcg_calendar'][0];

      tws_get_at_time($rcg_start_offset, $rcg_athour, $rcg_atminute, $temp, $rcg_atplusdays);
      tws_get_at_time($rcg_deadline_offset, $rcg_deadlinehour, $rcg_deadlineminute, $temp, $rcg_deadlineplusdays);
      tws_get_at_time($rcg_until_offset, $rcg_untilhour, $rcg_untilminute, $temp, $rcg_untilplusdays);

      unset($db_rcg);

      // Get RCG RunCycles
      if (($db_runcycle=tws_get_rcg_runcycle_data($selection[0]))===FALSE)
         tws_dyer("Unable to get run cycle group data");

      foreach ($db_runcycle['rc'] as $key => $val) {
         $$key = tws_gpc_get($val);
         //echo "$key => $val<br>";
      }
      unset($db_runcycle);

      if ($modify=="yes") {
         tws_composer_lock("rc=$selection[0]") or tws_dyer("Unable to lock run cycle '$selection[0]'");
         if (($original_data=tws_composer_create_from("rc=$selection[0]"))===FALSE) tws_dyer("Unable to get run cycle data");
      }
      $runcycle = $selection[0];
   }
?>
<br>
<form method='post' name="contents" action="tws_add_runcycle_exec.php" onsubmit="if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Run Cycle',null)) { cancel_button_pressed=false; return false;}">

   <? /*  For runcycle preview  */ ?>
   <input type='hidden' id='validfrom' name='validfrom' value=''>
   <input type='hidden' id='validto' name='validto' value=''>
<table border=0 cellspacing=0><tr><td>
<?
if ($modify == "yes" || $display == 'yes') {
   echo "</td><td> <h1>".htmlspecialchars($runcycle). "</h1>\n";
   echo "<input type='hidden' name='runcyclex' value='".htmlspecialchars($runcycle)."'></td></tr>";
}
else{
    if ($tws_config['cpuinfo']['version']>='9.5002'){
        $tmp = tws_divide_folder($runcycle);
        $runcycle = $tmp[1];
        $runc_folder = $tmp[0];
        echo "<b>Runcycle Group Folder:</b> </td><td> <input type='text' name='rcg_folder' required='required' value='".htmlspecialchars($runc_folder)."'>\n";
        echo "<input type=\"button\" name=\"folder_list\" onClick=\"tws_picker_open('folder_picker.php', 'fieldname=rcg_folder&fieldvalue=' + document.contents.rcg_folder.value);\" value=\"List\" > </td>";
        echo "</tr><tr><td>";
    }
   echo "<b>Name:</b> </td><td> <input type='text' name='runcycle' required='required' value='".htmlspecialchars($runcycle)."'></td></tr>\n";
}
echo "<tr><td><b>Description:</b> </td><td> <input type='text' name='rcg_description' value='".htmlspecialchars($rcg_description),"' size='70' maxlength='120'>\n";
?>
</td></tr>
      <tr>
         <td class="standard">Parameter Table:</td>
         <td class="standard">
            <input type="text" name="rcg_vat_name" class="tws_name" size=20 maxlength="<?=$tws_config['VARTABLE_MAXLENGTH']?>" value="<?=htmlspecialchars($rcg_vat_name)?>">&nbsp;
            <input type="button" name="rcg_vat_name_list" value="List" onClick="tws_picker_open('parameter_table_picker.php', 'fieldname=rcg_vat_name&amp;fieldvalue=' + document.contents.rcg_vat_name.value);">
         </td>
      </tr>
      <tr>
         <table id="rcg_times" border=0 cellspacing=0 style="border:0px none; border-collapse:collapse; margin-bottom:20px;">
         <tr>
            <td class="standard" style="width:10em;"><?=($rcg_time_dependent=="YES" ? "At:" : "Schedtime:")?></td>
            <td class="standard">
            <input type="text" name="rcg_athour" class="tws_hour" size=2 maxlength=2 value="<? if (isset($rcg_athour)) echo htmlspecialchars($rcg_athour);?>">&nbsp;:
            <input type="text" name="rcg_atminute" class="tws_minute" size=2 maxlength=2 value="<? if (isset($rcg_atminute)) echo htmlspecialchars($rcg_atminute);?>">&nbsp;+&nbsp;
            <input type="text" name="rcg_atplusdays" class="tws_num" size=2 maxlength=2 value="<? if (isset($rcg_atplusdays)) echo htmlspecialchars($rcg_atplusdays);?>">&nbsp;days
            <label style="margin-left:20px"><input type="checkbox" name="rcg_time_dependent" value="Y" <? if ($rcg_time_dependent=="Y") echo "checked";?> onClick="rcg_at_time_type(this);">&nbsp;Use as time dependency</label>
            </td>
         </tr>
         </td>
      </tr>
         <tr>
            <td class="standard">Until:</td>
            <td class="standard">
               <input type="text" name="rcg_untilhour" class="tws_hour" size=2 maxlength=2 value="<? if (isset($rcg_untilhour)) echo htmlspecialchars($rcg_untilhour); ?>">&nbsp;:
               <input type="text" name="rcg_untilminute" class="tws_minute" size=2 maxlength=2 value="<? if (isset($rcg_untilminute)) echo htmlspecialchars($rcg_untilminute);?>">&nbsp;+&nbsp;
               <input type="text" name="rcg_untilplusdays" class="tws_num" size=2 maxlength=2 value="<? if (isset($rcg_untilplusdays)) echo htmlspecialchars($rcg_untilplusdays);?>">&nbsp;days
               <span style="margin:20px">Until action:</span><select name="rcg_onuntil">
                  <option value="S" <? if (strtoupper($rcg_onuntil) == "S") echo " selected";?>>Suppress</option>
                  <option value="C" <? if (strtoupper($rcg_onuntil) == "C") echo " selected";?>>Continue</option>
                  <option value="X" <? if (strtoupper($rcg_onuntil) == "X") echo " selected";?>>Cancel</option>
               </select>
            </td>
         </tr>
         <tr>
            <td class="standard">Deadline:</td>
            <td class="standard">
               <input type="text" name="rcg_deadlinehour" class="tws_hour" size=2 maxlength=2 value="<? if (isset($rcg_deadlinehour)) echo htmlspecialchars($rcg_deadlinehour);?>">&nbsp;:
               <input type="text" name="rcg_deadlineminute" class="tws_minute" size=2 maxlength=2 value="<? if (isset($rcg_deadlineminute)) echo htmlspecialchars($rcg_deadlineminute);?>">&nbsp;+&nbsp;
               <input type="text" name="rcg_deadlineplusdays" class="tws_num" size=2 maxlength=2 value="<? if (isset($rcg_deadlineplusdays)) echo htmlspecialchars($rcg_deadlineplusdays);?>">&nbsp;days
            </td>
         </tr>
      </table>
      </td>
  </tr>
</table>
<br><br>
<?
include "tws_add_runcycle_inc.php";

// RCG Free days Calerndar
?>
<table border=0 cellspacing=0 class="transparent">
<tr><td colspan="2"><h3> Free Days:</h3></td></tr>
<tr>
   <td> <b>Calendar:</b></td>
<td>
<?
   if( empty($rcg_calendar) )
      $rcg_freedays_option = 'default';
   else
      $rcg_freedays_option = 'specify';
?>
<table border=0 cellspacing=0 class="transparent">
<tr>
   <td><label><input type="radio" name="rcg_freedays_option" value="default"<? if( $rcg_freedays_option == "default") echo " checked"; ?> onclick="enable_rcg_calendar(false);" >Use Default</label></td>
</tr>
<tr>
   <td><label><input type="radio" name="rcg_freedays_option" value="specify" <? if ($rcg_freedays_option == "specify") echo " checked"; ?>  onclick="enable_rcg_calendar(true);">Specify Calendar:</label></td>
<td>
   <input type="text" name="rcg_calendar" class="tws_name" size=16 maxlength=16 <? if (!empty($rcg_calendar)) echo " value='".htmlspecialchars($rcg_calendar)."'";?>>
   <input type="button" name="freedays_calendar_list" value="List" onClick="tws_picker_open('calendar_picker.php', 'includestock=no&amp;fieldname=rcg_calendar&amp;fieldvalue=' + document.contents.rcg_calendar.value );">
</td>
</tr>
<tr><td> </td></tr>
<tr>
<td>Consider as Free Days:&nbsp;&nbsp;</td>
<td>
   <label><input type="checkbox" name="rcg_sat_free" value="Y" <?php if ($rcg_freedays_option == "default" || $rcg_sat_free == "Y") echo " checked"; ?>>Saturday</label>&nbsp;&nbsp;
   <label><input type="checkbox" name="rcg_sun_free" value="Y" <?php if ($rcg_freedays_option == "default" || $rcg_sun_free == "Y") echo " checked"; ?>>Sunday</label>
</td>
</tr>
</table>
</td>
</tr>
</table>
<br><br>
<?
   if ($display!='yes') {
      if ($modify == "yes") {
         echo "<input type='hidden' name='modify' value='yes'>\n";
         echo "<input type='hidden' name='original_data' value='".htmlspecialchars($original_data)."'>\n";
         echo "&nbsp;&nbsp;<input type='submit' name='action' value='Update' onClick='return tws_validate_form();'>\n";
      }
      else {
         if ($copy == 'yes')
            echo "<input type='hidden' name='copy' value='yes'>\n";
         echo "&nbsp;&nbsp;<input type='submit' name='action' value='Add' onClick='return tws_validate_form()'/>\n";
      }
      if ($modify=="yes")
         echo "&nbsp;&nbsp;&nbsp;<input type='submit' name='action' value='Cancel' onClick='cancel_button_pressed=true;'>\n";
      else
         echo "&nbsp;&nbsp;&nbsp;<input type='button' value='Cancel' onClick=\"ConfirmCancel('Run cycle','tws_runcyclesx.php')\">\n";

      tws_print_synchro_token();
   }
   else {
      //echo "<input type='button' value='Print' onClick='tws_url_print();'>&nbsp;&nbsp;&nbsp;\n";
      if (!empty($popup))
         echo "<input type='button' value='Close' onClick='window.close();'>\n";
      else
         echo "<input type='button' value='Close' onClick='tws_url_close(\"showrc\");'>\n";
   }
?>
</form>
<script>
   $(function() {
      if( $('input[name="freedays_option"][value="default"]').is(':checked') )
         enable_freedays(false);
      else
         enable_freedays(true);
      <? /*if($display=='yes'): ?>
         $('input:text').attr('readonly', 'readonly');
         $('select').attr('disabled', 'disabled');
      <? endif; */?>
   });
</script>
   </div>
</body>
</html>