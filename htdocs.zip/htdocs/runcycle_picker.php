<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';

   tws_import_request_variables("P","rqst_");

   $fieldname=$rqst_fieldname;
   tws_check_elname($fieldname);
   $fieldvalue=@$rqst_fieldvalue;
   $allowmultiple=@$rqst_allowmultiple;
   $display="yes";

   if ((strpos($fieldname,"[") !== FALSE) && (strpos($fieldname,"]") !== FALSE)) {
      $jsfieldname="elements['" . $fieldname . "']";
   }
   else $jsfieldname = $fieldname;
?>

<script type="text/javascript">

function sendValue(formsel) {
 var selectionval = "";
 if (formsel) {
   for (var i = 0; i < formsel.options.length; i++)
      if (formsel.options[i].selected)
         selectionval = selectionval + formsel.options[i].value + ",";
   window.document.contents.<?=$jsfieldname ?>.value = selectionval.substr(0, selectionval.length - 1);
 }
 $('[name="<?=$fieldname?>"]').keyup();
 $( "#runcycle_picker" ).dialog( "close" );
}

</script>

<div id="runcycle_picker">

<h1>Select Run Cycle Group</h1>
<br>
<?php
   if ($fieldvalue == "") {
      $arg="@";
   } else {
      if ((strpos($fieldvalue,"*") === FALSE) && (strpos($fieldvalue,"@") === FALSE)) {
         $arg=$fieldvalue . "@";
      } elseif (strpos($fieldvalue,"*") !== FALSE) {
         $arg=strtr($fieldvalue,"*","@");
      } else {
         $arg=$fieldvalue;
      }
   }

   $select_options = '';
   if (($runcycles = tws_get_runcycles($arg)) === FALSE) {
      tws_warning('Unable to list run cycles'); // print error message
   } else if (isset($runcycles['runcycle_name'])) {
      foreach ($runcycles['runcycle_name'] as $runkey => $name) { //jozsef
			$runname = $name;
			if ($tws_config['cpuinfo']['version']>='9.5002') {
				$runname = $runcycles['rcg_folder'][$runkey].$runname;
			}
            $select_options .= '<option value="'.$runname.'">'.$runname.'</option>'."\n";
         }
   }
?>
<form name="runcycle_list" action="">
<select name="selection" size=14 class="picker" onDblClick="sendValue(this.form.selection);"<?php if ($allowmultiple == "yes") echo " multiple"; ?>>
<?php
   echo $select_options;
?>
</select>
<br><center>
<input type="button" value="OK" onClick="sendValue(this.form.selection);">
</center><br>
</form>
</div>

<script type="text/javascript">

$(function() {
   tws_picker_constructor("runcycle_picker");
});

</script>
