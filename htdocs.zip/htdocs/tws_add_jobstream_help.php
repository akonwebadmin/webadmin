<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');
?>
<html>
<head>
<?php require_once 'tws_functions.php'; tws_doctype('t'); ?><title>Add Event Rule Definition Help</title>
<?php tws_stylesheet(); ?>
</head>

<body class="help">
<?php tws_set_window_title(); include 'tws_help_topbar.php'; ?>
<h1 class="help">Add/modify jobstream definition</h1>
<p>The dialog consists of 4 sheets:</p>
<ul>
<li><a href="#general">General Options</a>:
Specify general information about the jobstream.</li>
<li><a href="#runcycle">On/Except/Freedays</a>:</li>
<li><a href="#dependencies">Dependencies</a>:</li>
<li>Job Instances:</li>
</ul>
<p>To create a new jobstream, fill in the form fields on the 4
sheets as
described below. The sheets can be repeatedly switched by clicking
their title. When the specification of all requested parameters is
done, click the Save Jobstream button to create the new jobstream (or
save changes in existing one) to the IWS database.
</p>
<br>
<!-- General Options -->
<h2 class="help"><a name="general"></a>General Options</h2>
Use this section to specify general information about the jobstream:

<p><b>Name:</b> The name of the jobstream. </p>

<p><b>Workstation:</b> The name of the workstation or workstation class on which the jobstream is launched.
If you specify a workstation class, it must match the workstation class of any jobs, and resource,
or file dependencies used in the jobstream.</p>

<p><b>Valid from:</b> The starting date from which the jobstream is included in a production plan if selected by a run cycle. </p>

<p><b>Description:</b>The description of the jobstream.</p>

<p><b>Time restrictions: </b></p>

<p><b>At:</b> Earliest start time. Indicates the time before which the jobstream must not start.
If empty, jobstream start time defined by the plan. <br>
Delay for days: Specify an offset in days from the start time.
The offset is calculated from the day the jobstream is selected for inclusion in the production plan.</p>

<p><b>Until:</b> Latest start. The latest time when the jobstream must start. <br>
Delay for days: An offset in days from the Latest start.
The offset is calculated from the day the jobstream is selected for inclusion in the production plan. </p>

<p><b>Until Action:</b> The action to be taken on a jobstream whose Latest start has expired, but that has not yet started.
Supported values are as follows:
<ul>
<li>Suppress: The jobstream and any dependent jobstreams do not run. This is the default behavior. </li>
<li>Continue: The jobstream runs when all necessary conditions are met and a notification message is written to the log if the Latest start time elapses. </li>
<li>Cancel: A jobstream is canceled when the Latest start specified expires.
Any jobstream that was dependent on the completion of a jobstream that was canceled, runs because the dependency no longer exists.</li>
</ul>
</p>

<p><b>Deadline:</b> The time within which a jobstream must complete.
Jobstreams that have not yet started or that are still running when the deadline time is reached, are considered late in the plan.
The Deadline does not prevent jobstreams from starting. <br>
Delay for days: An offset in days from the deadline time.
The offset is calculated from the day the jobstream is selected for inclusion in the production plan.</p>

<p><b>Time zone:</b> The time zone used to calculate the jobstream time restrictions.
The default value is None, which represents the time zone of the workstation on which the jobstream is defined.</p>

<p><b>Matching:</b> Define the criteria for dependency resolution.
Dependency resolution criteria define how the jobstream or job referenced by an external follows dependency is matched to a specific jobstream or
job instance in the plan. The criteria you specify here apply when you add a dependency to the jobstream without specifying the related
<b>Dependency Resolution </b>criteria in the dependency properties.
Because the plan allows the inclusion of multiple instances of the same job or jobstream,
you can identify the instance that resolves the external follows dependency according to the following resolution criteria:
<ul>
<li><b>Same scheduled day:</b> The jobstream or job instance that resolves the dependency is the closest one in time
scheduled to start on the day when the instance that includes the dependency is scheduled to run. </li>
<li><b>Previous scheduled day:</b> The jobstream or job instance that resolves the dependency is the closest preceding
the instance that includes the dependency. </li>
<li><b>Within a relative interval:</b> The jobstream or job instance that resolves the dependency is the closest one
in a time interval of your choice, which is defined relatively to the scheduled start time of the dependent instance.
Specify if the interval starts before or after the jobstream start time. </li>
<li><b>Within an absolute interval:</b> The jobstream or job instance that resolves the dependency is the closest one
in a time interval of your choice. The time interval is not related to the scheduled start time of the dependent instance.
Specify if the interval starts before or after the jobstream start time.</li>
</ul>
</p>

<p><b>Priority:</b> The priority assigned to the jobstream.
The priority level determines which job starts first, if dependencies are solved. Type the value or choose one of the following priorities:
<ul>
<li>Hold - The job is assigned a priority of 0. Jobstream with this priority prevents the jobstream and all of its jobs from running.</li>
<li>High - The job is assigned a priority of 100. Jobs with this priority are launched as soon as their dependencies are satisfied.
This value overrides the job limit set for the workstation where the job runs.
It does not override the job limit value set for the jobstream nor the job fence value set for the workstation. </li>
<li>Go - The job is assigned a priority of 101. Jobs with this priority are launched as soon as their dependencies are satisfied.
This value overrides the job limit values set for the workstation.
It does not override the job limit value set for the jobstream nor the job fence value set for the workstation. </li>
<li>Specify value - The priority to be assigned to the jobstream. </li>
</ul>
</p>

<p><b>Limit:</b> The maximum number of jobs in the jobstream that can be launched concurrently.
If you specify a job limit of 0, no jobs are launched in the jobstream.
</p>

<p><b>Variable table:</b> The name of a variable table associated to the jobstream.</p>

<p><b>Monitored:</b> The jobstream is enabled for monitoring by monitoring applications,
such as Tivoli Enterprise Portal or Tivoli Enterprise Console.</p>

<p><b>Carry forward:</b> Select this checkbox to carry the jobstream forward to the next production plan if it is not
completed before the end of the current production plan. Jobstreams that are carried forward retain the Carry forward option and are
carried forward again. You can control the number of days a jobstream is carried forward by specifying the relevant values in the Latest
start, where you can also specify the actions to be taken if the jobstream is not completed before the end of the current production plan
</p>

<p><b>Draft:</b> The jobstream is saved in draft status and is not included in the plan.</p>
<br>

<!-- On/Except/Freedays -->
<h2 class="help"><a name="runcycle"></a>On/Except/Freedays</h2>
<p>This panel describes the properties of jobstream run cycle.</p>

<p><b>Run cycle type:</b>
<ul>
   <li><b>On</b> - The run cycle is defined to include the set of days you specify.</li>
   <li><b>Except</b> - The run cycle is defined to exclude the set of days you specify.</li>
</ul>
<ul>
   <li><b>Run cycle</b></li>
   <li><b>Calendar</b> - When a Calendar run cycle selected, the Rule data contains dates from selected Calendar.
The offset can be applied for this dates. This value, be it positive or negative,
is applied to all days, working days or weekdays (po-pa), depending on the selection.</li>
   <li><b>Single dates</b> - Set dates for the run cycle </li>
</ul>
</p>

<p><b>Rule Name:</b> A name for the run cycle.</p>

<p><b>Description:</b> A description for the run cycle.</p>

<p><b>Parameter Table:</b> The name of a variable table associated to the run cycle.</p>

<p>If "Run Cycle" type is selected, frequency must be defined<br>
<b>Frequency:</b>
<ul>
<li><b>Daily</b>
- Specify on which types of days the run cycle is effective. Possible values are:<br>
<ul>
   <li>Everyday</li>
   <li>Workdays</li>
   <li>Freedays</li>
</ul>
The Interval of the run cycle in days, such as every 3 days
</li>
<li><b>Weekly</b><br>
- Specify the day of the week when jobstream runs.<br>
- Specify the Interval of the run cycle in weeks, such as every 3 weeks
</li>
<li><b>Monthly by month day</b><br>
- Specify the numeric day of the month when the run cycle runs: 1st day, 2nd day, and so on.
Or last day, 2nd last day, and so on.<br>
- Specify the Interval of the run cycle in months, such as every 3 months.
</li>
<li><b>Monthly by week day</b><br>
- Specify the day of the month when the run cycle runssuch as: every 1st Sunday, 2nd Sunday or last Sunday, and so on.<br>
- Specify the Interval of the run cycle in months, such as every 3 months.
</li>
<li><b>Yearly</b><br>
- Specify the <b>Valid from</b> field.<br>
- Specify the Interval of the run cycle in years, such as every 2 years.
</li>
</ul>
</p>

<p><b>Freedays rule:</b> Possible values are:
<ul>
   <li>Ignore - If the scheduled date falls on a non-working day, run the jobstream regardless.</li>
   <li>Don't run - Do not select when non-working day. If the scheduled date falls on a non-working day, do not run the jobstream.</li>
   <li>Run previous day - Select nearest workday before non-working day.
   If the scheduled date falls on a non-working day, run the jobstream on the preceding working day.</li>
   <li>Run next day - Select nearest workday after non-working day.
   If the scheduled date falls on a non-working day, run the jobstream on the following working day.</li>
</ul>
</p>

<p><b>Valid from:</b> The date at which the run cycle begins. </p>

<p><b>Valid to:</b> The date at which the run cycle ends.</p>

<p><b>Time dependent:</b> Use this section to specify time restrictions for the run cycle.</p>
<p><b>At:</b> Earliest start time. Indicates the time before which the jobstream must not start.
If empty, jobstream start time defined by the plan. <br>
Delay for days: Specify an offset in days from the start time.
The offset is calculated from the day the jobstream is selected for inclusion in the production plan.</p>
<p><b>Until:</b> Latest start. The latest time when the jobstream must start. <br>
Delay for days: An offset in days from the Latest start.
The offset is calculated from the day the jobstream is selected for inclusion in the production plan. </p>
<p><b>Until Action:</b> The action to be taken on a jobstream whose Latest start has expired, but that has not yet started.
Supported values are as follows:
<ul>
   <li>Suppress: The jobstream and any dependent jobstreams do not run. This is the default behavior. </li>
   <li>Continue: The jobstream runs when all necessary conditions are met and a notification message is written to the log if the Latest start time elapses. </li>
   <li>Cancel: A jobstream is canceled when the Latest start specified expires.
   Any jobstream that was dependent on the completion of a jobstream that was canceled, runs because the dependency no longer exists.</li>
</ul>
</p>

<p><b>Deadline:</b> The time within which a jobstream must complete.
Jobstreams that have not yet started or that are still running when the deadline time is reached, are considered late in the plan.
The Deadline does not prevent jobstreams from starting. <br>
Delay for days: An offset in days from the deadline time.
The offset is calculated from the day the jobstream is selected for inclusion in the production plan.</p>

<p><b>Freedays Calendar</b> Used to specify which days have to be considered as non-working days.<br>
The behavior of the jobstream on the non-working days is defined in the non-working day rule.
<ul>
<li><b>Use default</b> - used default freedays calendar. If a calendar named <b>HOLIDAYS</b> has been defined in the database,
it is used as the default freedays calendar. Otherwise a default calendar with all Sundays and Saturdays as non-working days is used.</li>
<li> <b>Specify calendar</b> - Specify Calendar name for freedays other than the default calendar.<br>
- Consider Saturday as FreeDay - Deselect to indicate that Saturday is a working day. By default, Saturday is a freeday.<br>
- Consider Sunday as FreeDay - Deselect to indicate that Sunday is a working day. By default, Sunday is a freeday.
</li>
</ul>
</p>

<p>The rules defined can be present graphically with <b>Preview</b> button.</p>
<br>

<!-- Dependencies -->
<h2 class="help"><a name="dependencies"></a>Dependencies</h2>

<p>This panel describes the properties of jobstream dependencies.</p>

<h3 class="help">Jobstream Dependencies</h3>

<p>Describes a dependency from another jobstream.</p>

<p><b>Workstation:</b> The name of the workstation where the external jobstream is defined to run.</p>

<p><b>Jobstream:</b> The name of the external jobstream.</p>

<p><b>Dependency resolution:</b> Specify the settings for resolving follows dependencies.</p>
<ul>
<li><b>By default</b>, the settings of the jobstream will be used.</li>
<li><b>Same scheduled day</b> - The dependencies used for resolution are those on the same scheduled date as the current jobstream. </li>
<li><b>Previous scheduled day</b> - The dependencies used for resolution are the closest that preceded the jobstream. </li>
<li><b>Within a relative interval</b> - The jobstream that resolves the dependency is the closest one in a time interval of your choice,
which is defined relatively to the scheduled start time of the dependent instance.
Specify if the interval starts before or after the jobstream start time.</li>
<li><b>Within an absolute interval</b> - The jobstream that resolves the dependency is the closest one in a time interval of your choice.
The time interval is not related to the scheduled start time of the dependent instance.
Specify if the interval starts before or after the jobstream start time.</li>
</ul>

<h3 class="help">Job Dependencies</h3>

<p>Describes a dependency from a job in another jobstream.</p>
<p><b>Workstation:</b> The name of the workstation where the external jobstream is defined to run.</p>
<p><b>Jobstream:</b> The name of the jobstream that contains the job on which the jobstream depends.</p>
<p><b>Job:</b> The name of the job on which the jobstream depends.</p>
<p><b>Dependency resolution:</b> Specify the settings for resolving follows dependencies.</p>
<ul>
<li><b>By default</b>, the settings of the jobstream will be used.</li>
<li><b>Same scheduled day</b> - The dependencies used for resolution are those on the same scheduled date as the current jobstream. </li>
<li><b>Previous scheduled day</b> - The dependencies used for resolution are the closest that preceded the jobstream. </li>
<li><b>Within a relative interval</b> - The jobstream that resolves the dependency is the closest one in a time interval of your choice,
which is defined relatively to the scheduled start time of the dependent instance.
Specify if the interval starts before or after the jobstream start time.</li>
<li><b>Within an absolute interval</b> - The jobstream that resolves the dependency is the closest one in a time interval of your choice.
The time interval is not related to the scheduled start time of the dependent instance.
Specify if the interval starts before or after the jobstream start time.</li>
</ul>

<h3 class="help">Internetwork Dependencies</h3>

<p>Internetwork dependencies allow jobstream to use jobs and jobstreams in a remote network as predecessors.</p>
<p><b>Network agent:</b> The name of the workstation that acts as the network agent.
Internetwork dependencies require that a network agent is configured to communicate with the external scheduler network.</p>

<p><b>Dependency:</b> The predecessor job or jobstream in the remote network in the form workstation#jobstream.job.</p>

<h3 class="help">Global Prompt Dependencies</h3>

<p>Describes the properties of a dependency from a predefined prompt.</p>
<p><b>Prompt:</b> The name of the prompt.</p>

<h3 class="help">Ad-Hoc Prompt Dependencies</h3>

<p>describes the properties of an ad-hoc prompt dependency.</p>

<p><b>Text:</b> The text of a prompt. The default behavior of a prompt is to display a message and wait for a reply.</p>
<p>Based on the character preceding the text, the prompt can behave differently:</p>
<ul>
<li>If the text begins with a colon (:), the prompt is displayed, but no reply is required to continue processing.</li>
<li>If the text begins with an exclamation mark (!), the prompt is displayed, but it is not recorded in the log file.</li>
</ul>

<h3 class="help">File Dependencies</h3>

<p>Describes the properties of a file dependency.</p>
<p><b>Workstation:</b> The name of the workstation or workstation class on which the file is located.</p>

<p><b>File:</b> The path and name of the file.</p>

<p><b>Qualifier:</b> The test conditions for the file dependency.</p>
<p> - On <b>UNIX</b>, the valid qualifiers are the same as UNIX test command conditions.
For more information, refer to your UNIX system documentation.</p>
<p> - On <b>Windows</b>, the following qualifiers are supported:</p>
<ul>
<li>-d %p True if the file exists and is a directory.</li>
<li>-e %p True if the file exists.</li>
<li>-f %p True if the file exists and is a regular file.</li>
<li>-r %p True if the file exists and is readable.</li>
<li>-s %p True if the file exists and its size is greater than zero.</li>
<li>-w %p True if the file exists and is available for editing.</li>
</ul>

<p>On both UNIX and Windows , the expression %p inserts the file name.</p>
<p>If no qualifier is specified, the default is -f %p</p>

<h3 class="help">Resource Dependencies</h3>

<p>Describes the properties of a resource dependency.</p>
<p><b>Workstation:</b> The name of the workstation or workstation class on which the resource is defined.</p>
<p><b>Resource:</b> The name of the resource.</p>
<p><b>Quantity:</b> The number of required resource units.</p>
<br>
</body></html>