<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');
?>
<html>
<head>
   <title>Critical Jobs Report Help</title>
   <?php tws_stylesheet(); ?>
</head>
<body class=help>
<?php
   tws_set_window_title();
   include 'tws_help_topbar.php';
?>
<h1 class=help>Critical Jobs Report Help</h1>
<p>The Critical Jobs Report allows first to create custom lists of critical jobs and then generate reports on selected symphony files. Critical jobs that don't finish in time are highlighted in the report.

<h2 class=help>Criteria</h2>
<p><strong>Select Plan</strong> : Select the symphony file for processing</p>
<ul>
  <li><strong>Current Plan</strong></li>
  <li><strong>Yesterday</strong></li>
  <li><strong>Schedule date</strong> : Select the date of interrest</li>
</ul>
<h2 class=help>Contents</h2>
<p><strong>Critical Job List</strong> : Select one of the predefined lists of critical jobs</p>
<h2 class=help>Options</h2>
<ul>
  <li><strong>Display ALL critical jobs, even if not present in plan</strong></li>
  <li><strong>Only show jobs that passed deadline</strong></li>
  <li><strong>Only show last iteration of repeated / rerun jobs</strong></li>
  <li><strong>Open Report in New Window</strong></li>
</ul>
</body>
</html>
