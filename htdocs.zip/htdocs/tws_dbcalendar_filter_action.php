<?php
//   HORIZONT Software GmbH, Munich
//

   require_once("tws_functions.php");
   tws_import_request_variables("GP","rqst_");

   $action=tws_gpc_get($rqst_action);
   $object='dbcalendar';

   if ($action=='Reset Filter'){
      header("Location: tws_".$object."_filter.php?arg=");
      exit;
   }
   $calendar=tws_gpc_get($rqst_calendar, 'tws_name');
   $filter_type=tws_gpc_get($rqst_filter_type, 'tws_name');
   $expert_filter=tws_gpc_get($rqst_expert_filter, 'tws_filter');

   $edit_file=tws_gpc_get($rqst_edit_file, 'tws_file');

   switch ($action) {
      case "Set Filter":
      case "Send as CSV":
         include("tws_set_dbcalendar_filter.php");
         break;
      case "Clear Filter":
         $arg = urlencode("@");
         include("tws_clear_filter.php");
         break;
      case "Load Filter":
         include("tws_load_filter.php");
         break;
      case "Save Filter":
         $redirect = false;                           // flag for set function, not redirect at end - continue
         include('tws_set_dbcalendar_filter.php');
         header("Location: tws_save_filter.php?object=$object&arg=".urlencode($filter)."&edit_file=".urlencode($edit_file));
         exit;
   }
?>