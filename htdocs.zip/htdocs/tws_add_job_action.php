<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   $myPost = array();
   foreach($_POST as $key=>$val) {
      $$key = tws_gpc_get($val);
      $myPost[$key] = tws_gpc_get($val);
      //echo "$key = '".htmlspecialchars($myPost[$key])."'<br>";
   }
   // Prepare arguments
   if(isset($arguments)) {
      foreach($arguments as $i=>$argument){
         if(trim($argument) == '')
            unset ($arguments[$i]);
      }
      if(count($arguments) == 0){
         unset($arguments);
         unset($myPost['arguments']);
      }
      else {
         $arguments = array_values($arguments);
         $myPost['arguments'] = $arguments;
      }
   }
   // Prepare variables
   if(isset($var_name)) {
      $variables = array();
      foreach($var_name as $i=>$name){
         if(trim($name) == '' || trim($var_val[$i]) == '' ) {
            unset ($var_name[$i]);
            unset ($myPost['var_name['.$i.']']);
         }
         else {
            $variables[$var_name[$i]] = $var_val[$i];
         }
      }
      if(count($variables) != 0)
         $myPost['variables'] = $variables;
      unset($var_name);
      unset($var_val);
   }

   if (tws_zli_module_check ()) {
      if(!isset($netmodule_file))  $netmodule_file = '';
      if(!isset($netmodule_addjob)) $netmodule_addjob = '';
   }

   $workstation=strtoupper($workstation);
   $workstationx=strtoupper($workstationx);
   $job=strtoupper($job);
   $jobx=strtoupper($jobx);
   $recovery_workstation=strtoupper($recovery_workstation);
   $recovery_job=strtoupper($recovery_job);


   switch ($action) {
      case 'Add':
      case 'Update':
      case 'Replace':
         include 'tws_add_job_exec.php';
         break;
      case 'Save Draft':
         $name = $job; // job name for Save Draft
         $namex = $jobx;
         $draft_file = tws_gpc_get($rqst_draft_file, 'tws_file');
         include 'tws_save_job_draft.php';
         break;
      case 'Cancel':
         // Unlock the object
         if(empty($rqst_job_folder))
            $job_folder = '';
         $jobid=(trim($workstationx)!='' && trim($jobx)!='') ? "jd=$workstationx#$job_folder$jobx" : "jd=$workstation#$job_folder$job";
         tws_composer_unlock($jobid) or tws_dyer("Unable to unlock job '$jobid'");
         echo "<script type='text/javascript' src='tws_js_functions.js'></script>
            <script type='text/javascript'>
            closeme('tws_jobsx.php');
            </script>";
         break;
      case "Return to Job Modification":
         include("tws_add_job.php");
   }
?>