<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add User</title>
<?php tws_stylesheet(); ?>
</head>
<body>
<?php tws_set_window_title(); ?>

<?php
   tws_import_request_variables("P","rqst_");
   tws_check_synchro_token();

   if (isset($rqst_modify)) {
      if (!tws_permit_action('database_users','Modify')) { tws_access_denied ();}
      $modify=$rqst_modify;
   } else {
      if (!tws_permit_action('database_users','Add')) { tws_access_denied ();}
      $modify="no";
   }
   if ($modify == "yes") {
      $workstation=tws_gpc_get($rqst_workstationx, 'tws_name');
      $domain=tws_gpc_get($rqst_domainx, 'tws_name');
      $username=tws_gpc_get($rqst_usernamex, 'tws_alfanum');
   } else {
      $workstation=tws_gpc_get($rqst_workstation, 'tws_name');
      $domain=tws_gpc_get($rqst_domain, 'tws_name');
      $username=tws_gpc_get($rqst_username, 'tws_alfanum');
   }
   $workstation=strtoupper($workstation);

   if ($workstation != "") {
      $workstationp = $workstation . "#";
   } else {
      $workstationp = $workstation;
   }
   if ($domain != "") {
      $fullusername=$domain . "\\" . $username;
   } else {
      $fullusername=$username;
   }

   $action=$rqst_action;
   if ($action=="Cancel") {
// Unlock the object
      tws_composer_unlock("user=$workstationp$fullusername") or tws_dyer("Unable to unlock user '$workstationp.$fullusername'");
      echo "<script type='text/javascript'>\n";
         echo "closeme('tws_usersx.php');\n";
      echo "</script>\n";
      exit;
   }

   $password=tws_gpc_get($rqst_password);
   $confirm_password=tws_gpc_get($rqst_confirm_password);
   $confirm=@$rqst_confirm;

   if ($password != $confirm_password) {
      if ($modify == "yes") {
         echo "<h1>Modify User Status</h1>\n";
      } else {
         echo "<h1>Add User Status</h1>\n";
      }
      tws_err("Passwords do not match");
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"Javascript:history.back()\">Return to User Definition</a>\n";
      die("</body>\n</html>\n");
   }


// Check for existing user
   $match = FALSE;
   if ($confirm != "yes") {
      if ($workstation == "") {
         $wks_query = "WKC_NAME IS NULL";
      } else {
         $wks_query = "WKC_NAME = '$workstation'";
      }
      $db_user = tws_get_users($fullusername,$wks_query);
      if (($db_user === FALSE) || $db_user['user_num'] > 1) {
         tws_dyer("Unable to list users", "", "tws_usersx.php");
      }
      if ($db_user['user_num'] == 1)
         $match=TRUE;
   }

   if ($match == TRUE) {
   // confirm replacing existing user
      if ($modify == "yes") {
         echo "<h1>Confirmation</h1>\n";
      } else {
         echo "<h1>Replace User Confirmation</h1>\n";
      }
      echo "<br><br>\n";
      echo "<h3>Confirm:</h3>\n";
      if ($modify != "yes") {
         echo "&nbsp;&nbsp;<b>The User Name entered already exists</b>\n";
         echo "<br><br>\n";
      }
      // the values are the same, this just for password change confirmation
      $orig_user = Array('workstation' => $workstation, 'domain' => $domain, 'username' => $username, 'password' => "*************");
      $new_user = Array('workstation' => $workstation, 'domain' => $domain, 'username' => $username, 'password' => "************");
      $label_map = Array('workstation' => 'Workstation', 'domain' => 'NT Domain', 'username' => 'User Name', 'password' => 'Password' );

      // show the comparison table
      tws_show_cmp_table("Original User", "New User", $orig_user, $new_user, $label_map);
      // confirmation form
      echo "<form method=post name=\"confirm\" action=\"tws_add_user_exec.php\">\n";
      echo "<input type=\"hidden\" name=\"confirm\" value=\"yes\">\n";
      foreach( $new_user as $key=>$val ){
         if ($key != "password") {
            echo "<input type=\"hidden\" name=\"$key\" value=\"".htmlspecialchars($val)."\">\n";
         } else {
            echo "<input type=\"hidden\" name=\"password\" value=\"$password\">\n";
            echo "<input type=\"hidden\" name=\"confirm_password\" value=\"$password\">\n";
         }
      }
      echo "<br><br><br>\n";
      if ($modify == "yes") {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Update\" name=\"action\">\n";
      } else {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Replace\" name=\"action\">\n";
      }
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"button\" value=\"Cancel\" onClick=\"history.back()\">\n";
      tws_print_synchro_token();
      echo "</form>\n";

   } else {
// unlock the object
      tws_composer_unlock("user=$workstationp$fullusername");

   // modify / add new user
      $tmpfilename="$maestro_dir/webadmin/tmp/user.".tws_rndstr().".tmp";
      $fp=fopen($tmpfilename,'w') or tws_dyer("Unable to create temporary file");

      $cmd=Array();
      $cmd[]="USERNAME $workstationp$fullusername\n";
      $cmd[]="PASSWORD \"$password\"\n";
      $cmd[]="END\n";
      foreach ($cmd as $cmdline) {
         $num_bytes=fwrite($fp,$cmdline);
         if ($num_bytes < 0) {
            fclose($fp);
            tws_dyer("Unable to write temporary file");
         }
      }
      fclose($fp);
      tws_chmod($tmpfilename,0644);

      if ($confirm == "yes") {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "replace $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      } else {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "add $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      }

      $stdout3='';
      $ec_popen=tws_popen($command3, $ec3, $stdout3, $stdout3, "N");
     
      //remove the tmp file now
      unlink($tmpfilename);
 
      //testing for the AWSBIA288I Total objects updated: 0.
      //Note: This has been added on 2016-07 to fix the problem of composer updating 
      //correctly objects but returning incorrect return codes (not 0 or 4)
      $not_updated=!preg_match('/AWSBIA288[^\n]+(\d+)/', $stdout3, $_r) || $_r[1]==0;

      if ($ec_popen===FALSE || ($ec3!=0 && $ec3!=4 && $not_updated)) {
         if ($modify == "yes") {
            echo "<h1>Modify User Status</h1>\n";
         } else {
            echo "<h1>Add User Status</h1>\n";
         }
         tws_err("User add/modify operation failed", array('twscmd'=>$command3->compile('log'), 'stdout'=>$stdout3, "EC_POPEN"=>$ec_popen, "EC_UPDATED"=>$ec3, "NOT_UPDATED"=>tws_yesno($not_updated,'YES','NO')));
         echo "<input type='button' value='OK' onClick='closeme(\"tws_usersx.php\")'>\n";
         /*
         if ($confirm == "yes") {
            echo "<a href=\"tws_usersx.php\">Return to User List</a>&nbsp;&nbsp;&nbsp;&nbsp;-
               &nbsp;&nbsp;&nbsp;&nbsp;<a href=\"Javascript:history.go(-2)\">Return to User Definition</a>\n";
         } else {
            echo "<a href=\"tws_usersx.php\">Return to User List</a>&nbsp;&nbsp;&nbsp;&nbsp;-
               &nbsp;&nbsp;&nbsp;&nbsp;<a href=\"Javascript:history.back()\">Return to User Definition</a>\n";
         }*/
      } elseif (preg_match("/warnings?\s[1-9]/i",$stdout3)) {
         if ($modify == "yes") {
            $headertext="Modify User";
         } else {
            $headertext="Add User";
         }
         tws_err("The User has been saved with the following warnings:", array('stdout'=>$stdout3));

         $shortwarnfilename="warn.".tws_rndstr().".txt";
         $warnfilename="$webadmin_tmp_dir/$shortwarnfilename";
         $warnfp=fopen("$warnfilename","w") or tws_dyer("Unable to create warning text file", "Warning output :\n$stdout3");
         $num_bytes=fwrite($warnfp,"$stdout3");
         if ($num_bytes < 0) {
            fclose($warnfp);
            unlink($warnfilename);
            tws_dyer("Unable to create warning text file", "Warning output :\n$stdout3");
         }
         fclose($warnfp);
         tws_dyer();
      } else {
         echo "<script type='text/javascript'>\n";
            echo "closeme('tws_usersx.php');\n";
         echo "</script>\n";
      }
   }
?>
</body>
</html>
