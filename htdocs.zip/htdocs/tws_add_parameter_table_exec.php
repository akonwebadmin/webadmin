<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add Parameter Table</title>
<?php
tws_stylesheet();
tws_show_backup();
?>
</head>
<body>
<?php tws_set_window_title(); ?>

<?php
   tws_check_synchro_token();    // synchro_token
   tws_import_request_variables("P","rqst_");

   if (isset($rqst_modify)) {
      $modify=$rqst_modify;
      if (!tws_permit_action('database_parameter_tables','Modify')) { tws_access_denied ();}
   } else {
      $modify="no";
      if (!tws_permit_action('database_parameter_tables','Add')) { tws_access_denied ();}
   }
   if (isset($rqst_confirm)) {
      $confirm=$rqst_confirm;
   } else {
      $confirm="no";
   }
   if (isset($rqst_backup)) {
      $backup=$rqst_backup;
   } else {
      $backup="no";
   }
   $original_data=tws_gpc_get($rqst_original_data);   
   
   if ($modify == "yes") {
      $parameter_table_name=tws_gpc_get($rqst_parameter_table_namex, 'tws_name');
   } else {
      $parameter_table_name=tws_gpc_get($rqst_parameter_table_name, 'tws_name');
   }
   $parameter_table_name=strtoupper(trim($parameter_table_name));
   $parameter_table_folder='';
   if(!empty($rqst_parameter_table_folder)){
      $parameter_table_folder = tws_gpc_get($rqst_parameter_table_folder, 'tws_name');
      $parameter_table_name=$parameter_table_folder.$parameter_table_name;
   }
   
   if ($_POST['action']=="Cancel") {
// Unlock the object
      tws_composer_unlock("vartable=$parameter_table_name") or tws_dyer("Unable to unlock parameter table '$parameter_table_name'");
      echo "<script type='text/javascript'>\n";
         echo "  closeme('tws_parameter_tablesx.php');\n";
      echo "</script>\n";
      exit;
   }

// Fetch posted data
   $parameter_table_description=tws_gpc_get(trim($rqst_parameter_table_description));
   $parameter_table_default=$rqst_parameter_table_default;
   $parameter_name=tws_gpc_get($rqst_parameter_name, 'tws_name'); //array (indexed from 0)!!!
   $parameter_value=tws_gpc_get($rqst_parameter_value); //array (indexed from 0)!!!
   if (is_array($parameter_name)) {
      foreach ($parameter_name as $key=>$val) {
         $parameter_name[$key]=strtoupper(trim($val));
         // $parameter_value[$key]=tws_gpc_get(trim($parameter_value[$key]));
      }
   }

// Check for existing parameter
   $match=FALSE;
   if ($confirm != "yes") {
      if (($db_parameter_table=tws_get_parameter_tables($parameter_table_name)) === FALSE) {
         tws_dyer("Unable to list parameter_tables");
      }
      if ($db_parameter_table['parameter_num'] > 1) {
         tws_dyer("Database query error");
      }
	  if(!empty($db_parameter_table['parameter_table_folder'][0])) {
         $db_parameter_table['parameter_table_name'][0] = $db_parameter_table['parameter_table_folder'][0].$db_parameter_table['parameter_table_name'][0];
      }
      if (($db_parameter_table_parameters=tws_get_parameters($parameter_table_name.'.@'))===FALSE) {
         tws_dyer("Unable to get list of parameters");
      }
      if (($db_parameter_table['parameter_table_num']==1) && ($parameter_table_name==$db_parameter_table['parameter_table_name'][0])) {
         $match = TRUE;
      }
   }
   if ($match == TRUE) {
      if ($modify == "yes") {
         echo "<h1>Confirmation</h1>\n";
      } else {
         echo "<h1>Replace Parameter Table Confirmation</h1>\n";
      }
      echo "<br><br>\n";
      echo "<h3>Confirm:</h3>\n";
      if ($modify != "yes") {
         echo "&nbsp;&nbsp;<b>The Parameter Table Name entered already exists</b>\n";
         echo "<br><br>\n";
      }
//cols labels
      $label_map = Array ('parameter_table_name' => 'Name' , 'parameter_table_description' => 'Description', 'parameter_table_default' => 'Default');
//orig data
      $orig_parameter_table_data = Array (
         //'parameter_table_name' => $db_parameter_table['parameter_table_name'][0],
         'parameter_table_name' => $parameter_table_name,
         'parameter_table_description' => $db_parameter_table['parameter_table_description'][0],
         'parameter_table_default' => tws_yesno($db_parameter_table['parameter_table_default'][0],'Yes','No')
      );
//new data
      $new_parameter_table_data = Array (
         'parameter_table_name' => $parameter_table_name,
         'parameter_table_description' => $parameter_table_description,
         'parameter_table_default' => tws_yesno($parameter_table_default,'Yes','No'),
      );
	  
      if (is_array($db_parameter_table_parameters['parameter_name'])) {
         foreach ($db_parameter_table_parameters['parameter_name'] as $key=>$pname) {
            $pname=strtoupper($pname);
            $orig_parameter_table_data['^'.$pname.'^']=$db_parameter_table_parameters['parameter_value'][$key];
            $label_map['^'.$pname.'^']='Parameter '.$pname;
            if (!isset($parameter_name[$pname])) $new_parameter_table_data['^'.$pname.'^']=FALSE;
         }
      }
      if (is_array($parameter_name)) {
         foreach ($parameter_name as $key=>$pname) {
            if (trim($pname)==='') continue;
            $new_parameter_table_data['^'.$pname.'^']=$parameter_value[$key];
            $label_map['^'.$pname.'^']='Parameter '.$pname;
            if (!isset($orig_parameter_table_data['^'.$pname.'^'])) $orig_parameter_table_data['^'.$pname.'^']=FALSE;
         }
      }

//show comparison
      tws_show_cmp_table("Original Parameter Table Properties", "New Parameter Table Properties", $orig_parameter_table_data, $new_parameter_table_data, $label_map);

      if ($original_data=='') {
//missing original data - this happens if user is adding parameter that already exists.
         if (($original_data=tws_composer_create_from("vartable=$parameter_table_name"))===FALSE) {
            tws_err("Unable to get original data required to create backup.");
         }
      }

// confirmation form
      echo "<form method=post name=\"confirm\" action=\"tws_add_parameter_table_exec.php\">\n";
      echo "<input type=\"hidden\" name=\"confirm\" value=\"yes\">\n";
      echo "<input type=\"hidden\" name=\"original_data\" value=\"".htmlspecialchars($original_data)."\">\n";
      echo tws_create_hidden_inputs($_POST);
      echo "<table><tr><td colspan=2>";
      if (tws_rights(SAVEBACKUPS) && $original_data!=''){
         echo "<input type='hidden' name='backup' value='yes'>";
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type='checkbox' name='backup' value='yes' checked disabled>&nbsp;Save Backup Copy of Original Parameter Table</label>\n";
      }
      else
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type=\"checkbox\" name=\"backup\" value=\"yes\" ".($original_data!='' ? 'checked' : 'disabled').">&nbsp;Save Backup Copy of Original Parameter Table</label>\n";
      echo "<br><br><br></td><tr><td>\n";
      if ($modify == "yes") {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Update\" name=\"action\">\n";
      } else {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Replace\" name=\"action\">\n";
      }
      tws_print_synchro_token();   // synchro_token
      echo "</form></td><td>\n";
      echo '<form action="tws_add_parameter_table.php" method="post">'."\n";
      echo tws_create_hidden_inputs($_POST);
      echo '<input type="submit" name="action" value="Return to Parameter Table Definition"/>'."\n";
      echo '</form></td></tr></table>'."\n";
   } else {
// Create Backup Copy if option checked
      if ($backup == "yes") {
         if (($bckfilename = tws_write_backup($original_data, "parameter_table", $parameter_table_folder.$parameter_table_name)) === FALSE) {
            tws_dyer("Unable to write backup");
         }
      }

// unlock the object
      tws_composer_unlock("vartable=$parameter_table_name");

// modify/add new parameter table
      $tmpfilename="$maestro_dir/webadmin/tmp/parameter_table.".tws_rndstr().".tmp";
      $fp=fopen($tmpfilename,'w') or tws_dyer("Unable to create temporary file '$tmpfilename'");

      $cmd=Array();
      $cmd[]="VARTABLE $parameter_table_name\n";
      if ($parameter_table_description!='') $cmd[]="   DESCRIPTION \"".addcslashes($parameter_table_description,'"')."\"\n";
      if ($parameter_table_default=='yes') $cmd[]="   ISDEFAULT\n";
      $cmd[]="   MEMBERS\n";
      if (is_array($parameter_name)) {
         foreach ($parameter_name as $key=>$pname) {
            if (trim($pname)==='') continue;
            $cmd[]="   ".strtoupper(trim($pname))." \"".addcslashes($parameter_value[$key],'"')."\"\n";
         }
      }
      $cmd[]="END\n";

      foreach ($cmd as $cmdline) {
         $num_bytes=fwrite($fp,$cmdline);
         if ($num_bytes < 0) {
            fclose($fp);
            tws_dyer("Unable to write temporary file '$tmpfilename'");
         }
      }
      fclose($fp);
      tws_chmod($tmpfilename,0644);

      if ($confirm == "yes") {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "replace $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      } else {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "add $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      }

      $stdout3='';
      $ec_popen=tws_popen($command3, $ec3, $stdout3, $stdout3, "N");
     
      //remove the tmp file now
      unlink($tmpfilename);
 
      //testing for the AWSBIA288I Total objects updated: 0.
      //Note: This has been added on 2016-07 to fix the problem of composer updating 
      //correctly objects but returning incorrect return codes (not 0 or 4)
      $not_updated=!preg_match('/AWSBIA288[^\n]+(\d+)/', $stdout3, $_r) || $_r[1]==0;


      if (preg_match("/\nAWS\S+W/", $stdout3)) {
         if ($modify == "yes") {
            $headertext="Modify Parameter Table";
         } else {
            $headertext="Add Parameter Table";
         }
         tws_err("The Parameter Table has been saved with the following warnings:", array('stdout'=>$stdout3, "NOT_UPDATED"=>tws_yesno($not_updated,'YES','NO')));
         $shortwarnfilename="warn.".tws_rndstr().".txt";
         $warnfilename="$webadmin_tmp_dir/$shortwarnfilename";
         $warnfp=fopen("$warnfilename","w") or tws_dyer("Unable to create warning text file", "Warning output :\n$stdout3");
         $num_bytes=fwrite($warnfp,"$stdout3");
         if ($num_bytes < 0) {
            fclose($warnfp);
            unlink($warnfilename);
            tws_dyer("Unable to write warning text file", "Warning output :\n$stdout3");
         }
         fclose($warnfp);
         tws_dyer();
      } elseif ($ec_popen===FALSE || ($ec3!=0 && $ec3!=4 && $not_updated)) {
         if ($modify == "yes") {
            echo "<h1>Modify Parameter Table Status</h1>\n";
         } else {
            echo "<h1>Add Parameter Table Status</h1>\n";
         }
         tws_err("Parameter table add/modify operation failed", array('twscmd'=>$command3->compile('log'), 'stdout'=>$stdout3, "EC_POPEN"=>$ec_popen, "EC_UPDATED"=>$ec3));
         echo "<form action=\"tws_add_parameter_table.php\" method=\"post\">\n";
         echo tws_create_hidden_inputs($_POST);
         echo "<input type=\"submit\" name=\"action\" value=\"Return to Parameter Table Definition\"/>\n";
         echo "</form>";
      } else {
         if ($backup == "yes") {
            if ($modify == "yes") {
               echo "<h1>Modify Parameter Table Status</h1>\n";
            } else {
               echo "<h1>Add Parameter Table Status</h1>\n";
            }
            echo "<p class=\"message\">\n";
            echo "The parameter table has been successfuly saved.&nbsp;";
            $bckfilename = preg_replace("/\\\\/", '/', $bckfilename);
            $file = explode('/',$bckfilename);
            $file = end($file);
            if(tws_profile('auth_user_group')=='admin')
               echo "<a href=\"javascript:showBackup('$file')\">Display Backup File</a>\n";
            echo "</p>\n";
               echo "<input type='button' value='OK' onClick=\"closeme('tws_parameter_tablesx.php')\" />\n";
         } else {
            echo "<script type='text/javascript'>\n";
               echo "closeme('tws_parameter_tablesx.php');\n";
            echo "</script>\n";
         }
      }
   }
?>
</body>
</html>
