<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Change Resource Units</title>
<?php tws_stylesheet(); ?>
</head>
<body>
<?php tws_set_window_title(); ?>
<h1>Change Resource Units</h1>
<br><br>
<h3>Selected Objects:</h3>

<?php
	if ($tws_config['cpuinfo']['version']>='9.5002') {
		foreach($selection as $key => &$value){
			$split = explode("#", $value); //split workstation and resource name
			$value = $split[0].';'.$split[1];
		}
		unset($value);
	}
   if (!tws_permit_action('plan_resources','Change Units')) {
      tws_access_denied ();
   }
   $num_elements=count($selection);
   if ($num_elements == 0) {
      echo "<p class=warning>&nbsp;&nbsp;&nbsp;&nbsp;No objects selected</p>\n";
   } else {
      TWS_DISP_PLANRES_SEL($selection);

      echo "<br>\n";

      echo "<form method='post' action='tws_change_resource_units_exec.php'>\n";
      for ($idx=0; $idx<$num_elements; ++$idx) {
         echo "<input type=\"hidden\" name=\"selection[]\" value=\"".htmlspecialchars($selection[$idx])."\">\n";
      }
      echo "<input type=\"hidden\" name=\"arg\" value=\"".htmlspecialchars($arg)."\">\n";
      echo "Set the Number of Units (quantity):&nbsp;<input type=\"text\" name=\"quantity\" class='tws_num' required='required' size=\"4\" maxlength=\"4\"><br><br>";
      echo "&nbsp;&nbsp;<input type='submit' value='Submit' onClick='return tws_validate_form()'>&nbsp;&nbsp;\n";
         echo '<INPUT TYPE="button" VALUE="Cancel" onClick="closeme(\'tws_srx.php\');"/>';
      tws_print_synchro_token();
      echo "</form>\n";
   }
?>
</body>
</html>
