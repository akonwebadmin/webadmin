<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
   tws_profile('opener', basename($_SERVER['REQUEST_URI']));
?>
<html>
<head>
<title>Calendars Cross Reference Report Design</title>
<?php tws_stylesheet(); ?>
<script type="text/javascript" src="tws_js_xref_functions.js"></script>
</head>
<body>
<?php tws_set_window_title();
tws_print_head("Calendar Cross Reference Report Design");
?>
<br>

<form method=post name="contents" action="tws_view_calendars_xref_report.php">
<table border=0 cellspacing=0>
<tr>
<td class=standard width=140>
<h3>Criteria</h3>
</td>
</tr>
<tr>
<td class=standard width=140>
&nbsp;&nbsp;<b>Calendar:</b>
</td>
<td class=standard>
<input type="text" name="calendar" class="tws_mask" size=16 maxlength=16>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" name="calendar_list" onClick="tws_picker_open('calendar_picker.php', 'fieldname=calendar&amp;fieldvalue=' + document.contents.calendar.value);" value="List">
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class=standard width=140>
<h3>Contents</h3>
</td>
</tr>
<tr>
<td class=standard colspan=2>
&nbsp;&nbsp;<input type="checkbox" name="include[]" value="jobstreams" checked="checked" disabled> Jobstreams
<input type="hidden" name="include[]" value="jobstreams">
</td>
</tr>
<tr>
<td class=standard colspan=2>
&nbsp;&nbsp;<label><input type="checkbox" name="include[]" value="drafts" checked> Include Drafts</label>
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class=standard colspan=2>
&nbsp;&nbsp;&nbsp;<a href="Javascript:XCheckAll();">Check All</a>&nbsp;&nbsp;-&nbsp;&nbsp;<a href="Javascript:XClearAll();">Clear All</a>
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class=standard width=140>
<h3>Options</h3>
</td>
</tr>
<tr>
<td class=standard>
&nbsp;&nbsp;<b><label><input type="checkbox" name="title" value="yes">
Set Title:</label></b>
</td>
<td><input type="text" name="titletext" size=40 maxlength=100 onkeyup="set_titlebox();"></td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr><td class=standard colspan=2>
&nbsp;&nbsp;<b><label><input type="checkbox" name="show_stats" id="show_stats" value="yes" checked='checked'/>
Show Query Statistics</label></b>
</td></tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class=standard colspan=2>
&nbsp;&nbsp;<b><label><input type="checkbox" name="opennew" value="yes" onClick="XChngTarg(this.checked)">
Open Report in New Window<label></b>
</td>
</tr>
</table>
<br><br>
<input type='hidden' name='home' value='tws_calendars_xref_report.php'/>
<input type="submit" value="Generate Report" name="action" onclick="return tws_validate_form();">

</form>
</body>
</html>
