<?php
//   HORIZONT Software GmbH, Munich
//
   require_once 'tws_functions.php';

   if (defined('IWD_PROCMAN')) {
      $iwd_class='iwd_dbprom';
      $search_elems=array();
      $search=$iwd_class::get_search_elems($search_elems, 'ref');
   }

   tws_import_request_variables("P","rqst_");

   $fieldname=$rqst_fieldname;
   tws_check_elname($fieldname);
   $fieldvalue=@$rqst_fieldvalue;
   $allowmultiple=@$rqst_allowmultiple;
// includeclasses = "yes" or "only", default: do not include classes
   $includeclasses=@$rqst_includeclasses;
// includexagents = "no" or "only", default: include xagents
   $includexagents=@$rqst_includexagents;
   $display="yes";

   if ((strpos($fieldname,"[") !== FALSE) && (strpos($fieldname,"]") !== FALSE)) {
      $jsfieldname="elements['" . $fieldname . "']";
   }
   else $jsfieldname = $fieldname;
?>

<script type="text/javascript">
function updateValue(val) {
   window.document.contents.<?=$jsfieldname ?>.value = val;
   $('[name="<?=$fieldname?>"]').keyup();
}

function sendValue(formsel) {
   var selectionval = "";
   if (formsel) {
      for (var i = 0; i < formsel.options.length; i++)
         if (formsel.options[i].selected)
            selectionval = selectionval + formsel.options[i].value + ",";
      updateValue(selectionval.substr(0, selectionval.length - 1));
   }
   $( "#prompt_picker" ).dialog( "close" );
}

   <?php
      if (defined('IWD_PROCMAN')) {
         if (trim($fieldvalue)=='') {
            $fieldvalue=$search_elems[$iwd_class][0];
            echo "updateValue('".$fieldvalue."');\n";
         }
      }
   ?>
</script>

<div id="prompt_picker">

<h1>Select Prompt</h1>
<br>
<?php
   if ($fieldvalue == "")
      $arg="@";
   else {
      if ((strpos($fieldvalue,"*") === FALSE) && (strpos($fieldvalue,"@") === FALSE))
         $arg=$fieldvalue . "@";
      elseif (strpos($fieldvalue,"*") !== FALSE)
         $arg=strtr($fieldvalue,"*","@");
      else
         $arg=$fieldvalue;
   }
   $select_options = '';
   if (defined('IWD_PROCMAN')) { //IWD/ProcMan
      $arg=strtr($arg,"@","*");
      if (($objs=$iwd_class::get_listing($arg, 'ref'))!==FALSE) {
         foreach($objs as $obj) {
            $select_options .= '<option value="'.$obj['rname'].'" '.(($obj['rname']==$fieldvalue) ? 'selected' : '').'>'.$obj['name'].' ('.$obj['version'].')</option>'."\n";
         }
      } else hwi_log_flush();
   }
   else { //IWS/WebAdmin
      if (($prompts = tws_get_prompts($arg)) === FALSE)
         tws_warning('Unable to list prompts'); // print error message
      elseif (isset($prompts['prompt_name'])) {
         foreach ($prompts['prompt_name'] as $prokey => $name) { //jozsef
				$proname = $name;
				if ($tws_config['cpuinfo']['version']>='9.5002') {
					$proname = $prompts['prompt_folder'][$prokey].$proname;
				}
				
				$select_options .= '<option value="'.$proname.'">'.$proname.'</option>'."\n";
			}
		}
   }
?>
<form name="prompt_list" action="">
<select name="selection" size=14 class="picker" onDblClick="sendValue(this.form.selection);"<?php if ($allowmultiple == "yes") echo " multiple"; ?>>
<?php
   echo $select_options;
?>
</select>
<br><center>
<input type="button" value="OK" onClick="sendValue(this.form.selection);">
</center><br>
</form>
</div>

<script type="text/javascript">

$(function() {
   tws_picker_constructor("prompt_picker");
});

</script>
