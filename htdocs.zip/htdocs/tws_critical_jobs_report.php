<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   require_once "tws_filters_lib.php";
   tws_profile('opener', basename($_SERVER['REQUEST_URI']));
   tws_doctype("t");
?>
<html>
<head>
<title>Critical Jobs Report</title>
<?php tws_stylesheet(); ?>
<script type="text/javascript">
   function set_titlebox() {
      if($('#titletext').val() != '' )
         $('#title').attr('checked','checked');
      else
         $('#title').removeAttr('checked');
   }
</script>
</head>
<body>
<?php
if(tws_get_menu('Critical_Jobs')==0) tws_access_denied();

   tws_set_window_title();
   $log_file_name=tws_log('', 'OPEN');
   tws_print_head('Critical Jobs Report', array('__log__' => $log_file_name, '__help__' => 'tws_critical_jobs_report_help.php', '__time__' => (tws_getmicrotime() - $execution_time)));

   $execution_time = tws_getmicrotime();

// Get current date
   $command=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), "$tws_config[maestro_dir]/bin/datecalc", "scheddate pic yyyy-mm-dd");
   $stdout=''; $stderr=''; $ec=0;
   if (tws_popen($command,$ec,$stdout,$stderr)===FALSE || $ec!=0) {
      tws_dyer("Unable to get current schedule date", array('stdout'=>$stdout));
   }

   $current_schedule_date=trim($stdout);
   $res = strtotime($current_schedule_date);
   if($res==false){  // windows can return error (may be because of USERNAME setting)
      $stdout = explode("\n", $stdout);
      foreach($stdout as $str) {
         $res = strtotime($str);
         if($res != false)
            $current_schedule_date = $str;
      }
   }

// conect to database
   db_connect($webadmin_db, DB_PERSISTENT) or tws_dyer("Could not connect to database");
   $schema=$webadmin_db['schema'];

// list of processed schdlogs
   $query="SELECT sched_date FROM $schema.jobhist_schedlogs GROUP BY sched_date ORDER BY sched_date DESC";
   db_query($webadmin_db, $query) or tws_dyer("Unable to list jobhist_schedlogs table");
   $sched_date=array();
   while ($row=db_fetch_row($webadmin_db)) {
      $sched_date[]=tws_iso_to_userdate($row['SCHED_DATE'],'Y-m-d',TRUE);
   }
//  IMPORTANT !! Otherwise it can't show next SELECTs in not persistance mode   db_close($webadmin_db);	

// list of critical job lists
/*
   $query="SELECT listnum,listdesc FROM $schema.critical_jobs_lists ORDER BY listnum";
   db_query($webadmin_db,$query) or tws_dyer("Unable to list critical jobs lists");
   $listnum=array();
   $listdesc=array();
   while ($row=db_fetch_row($webadmin_db)) {
      $listnum[]=$row['LISTNUM'];
      $listdesc[]=$row['LISTDESC'];
   }

*/
   // list of user's job lists (+ forall). Not empty only
   $my_listnum = tws_get_critical_lists(true);
   tws_log("-- tws_critical_jobs_report.php -- my_listnum: ".var_export($my_listnum, true));

   foreach($my_listnum as $num=>$val){
      $listnum[]=$num;
      $listdesc[]=$val['desc'];
   }
?>

<form method=post name="contents" action="tws_critical_jobs_report_action.php">
<table border=0 cellspacing=0>
<tr>
<td class=standard width=150>
<h3>Criteria</h3>
</td>
</tr>
<tr>
<td class=standard width=150>&nbsp;&nbsp;<b>Select Plan:</b></td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class=standard width=150>
&nbsp;&nbsp;<label><input type="radio" name="run" value="current">&nbsp;Current Plan</label>
</td>
</tr>
<tr>
<td class=standard width=150>
&nbsp;&nbsp;<label><input type="radio" name="run" value="yesterday" checked>&nbsp;Yesterday</label>
</td>
</tr>
<tr>
<td class=standard width=150>
&nbsp;&nbsp;<label><input type="radio" name="run" value="schedlog">&nbsp;Schedule Date:</label>
</td>
<td class=standard>
<select name="schedule_date">
<?php
   if (count($sched_date)<1) {
      echo "<option value=\"NONE\">--- None Available ---\n";
   } else {
      for ($i=0; $i<count($sched_date); $i++) {
         echo "<option value=\"$sched_date[$i]\">".tws_iso_to_userdate($sched_date[$i],null,TRUE)."\n";
      }
   }
?>
</select>
</td>
</tr>
<tr><td>
<?php echo "<input type=\"hidden\" name=\"yesterday_schedule_date\" value=\"$sched_date[0]\">\n"; ?>
<?php echo "<input type=\"hidden\" name=\"current_schedule_date\" value=\"$current_schedule_date\">\n"; ?>
</td></tr>
<tr>
<td class=standard width=150>
<h3>Contents</h3>
</td>
</tr>
<tr>
<td class=standard width=150>
&nbsp;&nbsp;<b>Critical Job List:</b>
</td>
<td class=standard>
   <select name="critical_job_list">
<?php
   if (count($listnum)<1) {
      echo "<option value=\"NONE\">--- None Available ---\n";
   } else {
      for ($i=0; $i<count($listnum); $i++) {
         echo "<option value=\"$listnum[$i]\">".htmlspecialchars("$listdesc[$i]")."\n";
      }
   }
?>
</select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="tws_critical_jobs_lists.php">Manage Critical Job Lists</a>
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class=standard width=150>
<h3>Options</h3>
</td>
</tr>
<tr><td class=standard colspan=2>&nbsp;&nbsp;<label><input type="checkbox" name="show_all" value="yes">&nbsp;Display ALL critical jobs, even if not present in plan</label></td></tr>
<tr><td class=standard colspan=2>&nbsp;&nbsp;<label><input type="checkbox" name="late_only" value="yes">&nbsp;Only show jobs that passed deadline</label></td></tr>
<tr><td class=standard colspan=2>&nbsp;&nbsp;<label><input type="checkbox" name="last_only" value="yes" checked>&nbsp;Only show last iteration of repeated / rerun jobs</label></td></tr>
<tr><td class=standard colspan=2>&nbsp;&nbsp;<label><input type="checkbox" name="show_description" value="yes">&nbsp;Show jobs description</label></td></tr>
<tr><td class=standard>&nbsp;&nbsp;<label><input type="checkbox" name="title" id="title" value="yes">
Set Title:</label></td>
<td class=standard><input type="text" name="titletext" id="titletext" size=40 maxlength=100 onkeyup="set_titlebox();"></td>
</tr>
<tr><td class=standard colspan=2>&nbsp;&nbsp;<label><input type="checkbox" name="csv" value="yes">&nbsp;Send as CSV file</label></td></tr>
<tr><td class=standard colspan=2>&nbsp;&nbsp;<label><input type="checkbox" name="opennew" value="yes" onClick="ChngTarg(this.checked)">&nbsp;Open Report in New Window</label></td></tr>
</table>
<br><br>
<input type="submit" value="Generate Report" name="action">

</form>
</body>
</html>
