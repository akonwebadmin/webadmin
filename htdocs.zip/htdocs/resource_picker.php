<?php
//   HORIZONT Software GmbH, Munich
//
   require_once 'tws_functions.php';

   if (defined('IWD_PROCMAN')) {
      $iwd_class='iwd_dbres';
      $search_elems=array();
      $search=iwd_dbres::get_search_elems($search_elems, 'ref');
   }

   tws_import_request_variables("P","rqst_");

   $cpux=strtoupper($rqst_cpux);
   $fieldname=$rqst_fieldname;
   if (($wksfieldname=$rqst_wksfieldname)=='') {
      $wksfieldname=str_replace('resource', 'needscpu', $fieldname);
   }
   tws_check_elname($fieldname);
   tws_check_elname($wksfieldname);

   $fieldvalue=tws_gpc_get($rqst_fieldvalue, 'tws_mask');

   $allowmultiple=tws_gpc_get(@$rqst_allowmultiple, 'tws_name');
// includeclasses = "yes" or "only", default: do not include classes
   $includeclasses=tws_gpc_get(@$rqst_includeclasses, 'tws_name');
// includexagents = "no" or "only", default: include xagents
   $includexagents=tws_gpc_get(@$rqst_includexagents, 'tws_name');
   $display="yes";
?>
<script type="text/javascript">
function updateValue(txt) {
      $('input:text[name="<?=$fieldname?>"]').val(txt);
      $('input:text[name="<?=$fieldname?>"]').keyup();
}

function sendValue(formsel) {
   var selval = "";
   if (formsel) {
      for (var i = 0; i < formsel.options.length; i++){
         if (formsel.options[i].selected)
            selval = formsel.options[i].text;
      }
      updateValue(selval);
   }
   $( "#resource_picker" ).dialog( "close" );
}

   <?php
      if (defined('IWD_PROCMAN')) {
         if (trim($fieldvalue)=='') {
            $fieldvalue=$search_elems[$iwd_class][0];
            echo "updateValue(null, '".$fieldvalue."');\n";
         }
      }
   ?>
</script>

<div id="resource_picker">

<h1>Select Resource</h1>
<br>
<?php
   if ($cpux == '') {
      $cpufilter = '1=1';
   }
   elseif ($tws_config['cpuinfo']['version']>='9.5002') {
	  $tmp = tws_divide_folder($cpux);
	  $cpux_name = $tmp[1];
      $cpux_folder = $tmp[0];
	  $cpufilter = 'WKC_NAME '.tws_sqllike(db_string($composer_db,$cpux_name)).' AND WKS_FOL.FOL_PATH '.tws_sqllike(db_string($composer_db,$cpux_folder));
   } else {
	   $cpufilter = 'WKC_NAME '.tws_sqllike(db_string($composer_db,$cpux_name));
   }
   if ($fieldvalue == "") {
      $arg="@";
   } else {
      if ((strpos($fieldvalue,"*") === FALSE) && (strpos($fieldvalue,"@") === FALSE)) {
         $arg=$fieldvalue . "@";
      } elseif (strpos($fieldvalue,"*") !== FALSE) {
         $arg=strtr($fieldvalue,"*","@");
      } else {
         $arg=$fieldvalue;
      }
   }
   
   $select_options = '';
   if (defined('IWD_PROCMAN')) { //IWD/ProcMan
      $arg=strtr($arg,"@","*");
      $cpux=strtr($cpux,"@","*");
      if (($objs=iwd_dbres::get_listing($cpux.'#'.$arg, 'ref'))!==FALSE) {
         foreach($objs as $obj) {
            $select_options .= '<option value="'.$obj['name'].'" '.(($obj['rname']==$fieldvalue) ? 'selected' : '').'>'.$obj['name'].' ('.$obj['version'].')</option>'."\n";
         }
      } else hwi_log_flush();
   } 
   else { //IWS/WebAdmin
      if (($resources = tws_get_resources($arg, $cpufilter)) === FALSE) {
         tws_warning('Unable to list resources'); // print error message
      } else if (isset($resources['resource_name'])) {
         foreach ($resources['resource_name'] as $reskey => $name) {
			$resname = $name;
			if ($tws_config['cpuinfo']['version']>='9.5002') {
				$resname = $resources['resource_folder'][$reskey].$resname;
				$wks_fold= $resources['workstation_folder'][$reskey];
			}
            $select_options .= '<option value="'.$resname.'">'.$resname.'</option>'."\n";
         }
      }
   }
?>

<form name="resource_list" action="">

<select name="selection" class="picker" size=14 onDblClick="sendValue(this.form.selection);"<?php if ($allowmultiple == "yes") echo " multiple"; ?>>
<?php
   echo $select_options;
?>
</select>
<br><center>
<input type="button" value="OK" onClick="sendValue(this.form.selection);">
</center><br>
</form>
</div>

<script type="text/javascript">

$(function() {
   tws_picker_constructor("resource_picker");
});

</script>
