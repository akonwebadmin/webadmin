<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_import_request_variables("P","");
   tws_doctype("t");
?>
<html>
<head>
<title>Add Critical Job</title>
<?php tws_stylesheet(); ?>
</head>
<body>
<?php tws_set_window_title();
tws_print_head("Add Critical Job");
?>
<table border=0 cellspacing=0 cellpadding=2><tr><td class=powered>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Critical Job List:&nbsp;<?php echo $list_number; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr></table>
<br><br>

<form method=post name="contents" action="tws_add_critical_job_exec.php">
<table border=0 cellspacing=0>
<tr>
<td class=standard width=120>
&nbsp;&nbsp;<b>Workstation:</b>
</td>
<td class=standard>
<input type="text" name="workstation" class="tws_mask" required="required" style="width:20em;" value=<?=$workstation?>>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" name="workstation_list" onClick="tws_picker_open('workstation_picker.php', 'fieldname=workstation&amp;fieldvalue=' + document.contents.workstation.value);" value="List">
</td>
</tr>
<tr>
<td class=standard width=120>
&nbsp;&nbsp;<b>Jobstream:</b>
</td>
<td class=standard>
<input type="text" name="jobstream" class="tws_mask" required="required" style="width:20em;" value=<?=$jobstream?>>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" name="jobstream_list" onClick="tws_picker_open('jobstream_picker.php', 'fieldname=jobstream&amp;fieldvalue=' + document.contents.jobstream.value + '&amp;cpux=' + document.contents.workstation.value);" value="List">
</td>
</tr>
<tr>
<td class=standard width=120>
&nbsp;&nbsp;<b>Job:</b>
</td>
<td class=standard>
<input type="text" name="job" class="tws_mask" required="required" style="width:15em;" maxlength=40 value=<?=$job?>>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" name="job_list" onClick="tws_picker_open('job_instance_picker.php', 'jobfieldname=job&amp;jsfieldname=jobstream&amp;wksfieldname=workstation&amp;fieldvalue=' + document.contents.job.value + '&amp;cpux=' + document.contents.workstation.value + '&amp;schedulex=' + document.contents.jobstream.value);" value="List">
</td>
</tr>
<tr>
<td class=standard width=120>
&nbsp;&nbsp;<b>Deadline:</b>
</td>
<td class=standard>
<input type="text" name="deadline_hour" class="tws_hour" required="required" size=2 maxlength=2 value=<?=$deadline_hour?>>:<input type="text" name="deadline_minute" class="tws_minute" required="required" size=2 maxlength=2 value=<?=$deadline_minute?>>
</td>
</tr>
</table>

<br><br>

<input type="hidden" name="list_number" value="<?php echo "$list_number"; ?>">

&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Add" onclick="return tws_validate_form();">&nbsp;&nbsp;
<input type="button" name="action" value="Cancel" onclick="window.location.replace('tws_critical_jobs_lists.php?list_number=<?=$list_number?>');">
</form>
</body>
</html>
