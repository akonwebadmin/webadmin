<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Cancel Jobstream</title>
<?php tws_stylesheet(); ?>
</head>
<body>
<? tws_set_window_title();?>
<br>
<h1>Cancel Jobstream Status</h1>
<? if (!tws_permit_action('plan_jobstreams','Cancel')) tws_access_denied ();

   tws_import_request_variables("P","rqst_");

   $selection=tws_gpc_get($rqst_selection, "tws_name;tws_name;tws_datetime;tws_sched_id");
   $safe_mode=@tws_gpc_get($rqst_safe_mode, "tws_name");
   $restore_pri=@tws_gpc_get($rqst_restore_pri, "tws_name");
   $arg=@tws_gpc_get($rqst_arg, "tws_filter");
   $afteraction=@tws_gpc_get($rqst_afteraction, "tws_name");
      tws_check_synchro_token();

   if ($safe_mode == "yes") {
      echo "<h3>Safe Mode:</h3>\n";

      $status=0;
      $num_elements=count($selection);
      for ($idx=0; $idx<$num_elements; ++$idx) {
         $js=tws_get_jobstream_data($selection[$idx]);

         set_time_limit($tws_config['excmd_limit']);

         echo "Setting priority to <em>0</em> and pausing for <em>$js[cpu]#$js[schedule]($js[schedtime])</em> ... ";
         tws_flush_output();

         $command=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/conman", $tws_config['conman_args'], "-gui", "ap $js[cpu]#$js[schedid];schedid;0", hwi_cmd::operator('2>&1',FALSE));
         $stdout=array();
         if (tws_popen($command, $ec, $stdout, $stdout, "N")===FALSE || tws_process_conman_gui($stdout)!=0) {
            $status=1;
            echo "<span class=\"err\">ERROR</span><br/>\n";
            tws_err("Alterenate jobstream priority failed", array('stdout'=>$stdout));
         }
         else 
            echo "<span class=\"ok\">OK</span><br/>\n";
         
      }
      if ($status!=0) {
         //TODO: script should probably exit now
         //echo "<a href=\"tws_ss.php\">Return to Jobstreams Display</a>\n";
      }
      echo "<br>\n";
   }

   $status=0;
   $num_elements=count($selection);
   for ($idx=0; $idx<$num_elements; ++$idx) {
      $js=tws_get_jobstream_data($selection[$idx]);

      set_time_limit($tws_config['excmd_limit']);

      echo "Cancelling <em>$js[cpu]#$js[schedule]($js[schedtime])</em> ... ";
      tws_flush_output();

      $command=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/conman", $tws_config['conman_args'], "-gui", "cs $js[cpu]#$js[schedid];schedid", hwi_cmd::operator('2>&1',FALSE));
      $stdout=array();
      if (tws_popen($command, $ec, $stdout, $stdout, "N")===FALSE || tws_process_conman_gui($stdout)!=0) {
         $status=1;
         echo "<span class=\"err\">ERROR</span><br/>\n";
         tws_err("Cancel jobstream failed", array('stdout'=>$stdout));
      } else {
         echo "<span class=\"ok\">OK</span><br/>\n";
      }
   }
   // restore priority to PRI (is important from IWS 8.6)
   if(!empty($restore_pri) ){
      echo "<br>\n";
      for ($idx=0; $idx<$num_elements; ++$idx) {
         $js=tws_get_jobstream_data($selection[$idx]);

         set_time_limit($tws_config['excmd_limit']);

         echo "Setting priority to <em>PRI</em> for <em>$js[cpu]#$js[schedule]($js[schedtime])</em> ... ";
         tws_flush_output();

         $command=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/conman", $tws_config['conman_args'], "-gui", "ap $js[cpu]#$js[schedid];schedid;PRI", hwi_cmd::operator('2>&1',FALSE));
         $stdout=array();
         if (tws_popen($command, $ec, $stdout, $stdout, "N")===FALSE || tws_process_conman_gui($stdout)!=0) {
            $status=1;
            echo "<span class=\"err\">ERROR</span><br/>\n";
            tws_err("Altrenate jobstream priority failed", array('stdout'=>$stdout));
         } else {
            echo "<span class=\"ok\">OK</span><br/>\n";
         }
      }

   }

if(tws_profile('action_refresh')=='yes'){
   if ($status==0) {
      echo "<script type='text/javascript'>\n";
         echo "window.location.replace('".tws_profile('opener')."');\n";
      echo "</script>\n";
   } else
      echo "<br><br><a href='".tws_profile('opener')."'>Return to Jobstreams Display</a>\n";
}
else{
   if ($status==0 && tws_profile('action_popup_close'))
      echo "<script>window.close();</script>";
   else
      echo '<br><input type="button" value="Close Window" onClick="window.close();">';
}
?>
</body>
</html>
