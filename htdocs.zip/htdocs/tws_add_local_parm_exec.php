<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add Local Parameter</title>
<?php tws_stylesheet(); ?>
</head>
<body>
<?php tws_set_window_title(); ?>

<?php
   tws_check_synchro_token();    // synchro_token
   tws_import_request_variables("P","rqst_");

   if (isset($rqst_modify)) {
      if (!tws_permit_action('database_local_parameters','Modify')) { tws_access_denied ();}
      $modify=$rqst_modify;
   } else {
      if (!tws_permit_action('database_local_parameters','Add')) { tws_access_denied ();}
      $modify="no";
   }
   if ($modify == "yes") {
      $parm_name=tws_gpc_get($rqst_parm_namex, 'tws_name');
   } else {
      $parm_name=tws_gpc_get($rqst_parm_name, 'tws_name');
   }
   $parm_name=strtoupper($parm_name);
   $parm_value=tws_gpc_get($rqst_parm_value);
   $confirm=@$rqst_confirm;

   if ($rqst_action=="Cancel") {
      echo "<script type='text/javascript'>\n";
         echo "  closeme('tws_local_parmsx.php');\n";
      echo "</script>\n";
      exit;
   }
   elseif($rqst_action=="Return to Modification"){
      include("tws_add_local_parm.php");
      exit;
   }
// Check for existing parm
   $match = FALSE;
   if ($confirm != "yes") {
      if (($parms=tws_get_localparms($parm_name))===FALSE){
         $parms = array();
         // tws_dyer("Unable to list local parameters");    unable to create first parameter
      }
      elseif (($key=array_search($parm_name,$parms['parm_name']))!==FALSE){
         $match = TRUE;
         $orig_parm_value= $parms['parm_value'][$key];
      }
   }

   if ($match == TRUE) {
   // confirm replacing existing parm
      if ($modify == "yes") {
         echo "<h1>Confirmation</h1>\n";
      } else {
         echo "<h1>Replace Local Parameter Confirmation</h1>\n";
      }
      echo "<br><br>\n";
      echo "<h3>Confirm:</h3>\n";
      if ($modify != "yes") {
         echo "&nbsp;&nbsp;<b>The Local Parameter Name entered already exists</b>\n";
         echo "<br><br>\n";
      }
      // the values are the same, this just for password change confirmation
      $orig_parm = Array('parm_name' => $parm_name, 'parm_value' => $orig_parm_value);
      $new_parm = Array('parm_name' => $parm_name, 'parm_value' => $parm_value);
      $label_map = Array('parm_name' => 'Parametr', 'parm_value' => 'Value');

      // show the comparison table
      tws_show_cmp_table("Original Parametr", "New Parametr", $orig_parm, $new_parm, $label_map);
      // confirmation form
      echo "<form method=post name=\"confirm\" action=\"tws_add_local_parm_exec.php\">\n";
      echo "<input type=\"hidden\" name=\"confirm\" value=\"yes\">\n";
      foreach( $new_parm as $key=>$val ){
         echo '<input type="hidden" name="'.htmlspecialchars($key).'" value="'.htmlspecialchars($val).'">'."\n";
      }
      echo "<br><br><br>\n";
      if ($modify == "yes") {
         echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
         echo "<input type=\"hidden\" name=\"parm_namex\" value=\"".htmlspecialchars($parm_name)."\">\n";
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Update\" name=\"action\">\n";
      } else {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Replace\" name=\"action\">\n";
      }
      echo '&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Return to Modification">'."\n";
      echo '&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Cancel">'."\n";
      tws_print_synchro_token();   // synchro_token
      echo "</form>\n";

   } else {
      // modify / add new parm

      $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/parms", "-c", $parm_name, $parm_value, hwi_cmd::operator('2>&1',FALSE));
      $stdout3='';
      if (tws_popen($command3, $ec3, $stdout3, $stdout)===FALSE) {
         tws_dyer("Local parameter add/modify operation failed");
      }

      if( $ec3!='0' && $ec3!=4 ){
         if ($modify == "yes") {
            echo "<h1>Modify Local Parameter Status</h1>\n";
         } else {
            echo "<h1>Add Local Parameter Status</h1>\n";
         }
         tws_err("Local parameter add/modify operation failed", array('stdout'=>$stdout3));
         echo "<form action='tws_add_local_parm_exec.php' method='post' onsubmit=\"if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Workstation',null)) { cancel_button_pressed=false; return false;}\">\n";
         echo tws_create_hidden_inputs($_POST);
         tws_print_synchro_token();
         echo "<input type='submit' name='action' value='Cancel' onClick='cancel_button_pressed=true;'/>\n";
         echo "<input type='submit' name='action' value='Return to Modification'/>\n";
         echo "</form>";
      } else {
         echo "<script type='text/javascript'>\n";
            echo "closeme('tws_local_parmsx.php');\n";
         echo "</script>\n";
      }
   }
?>
</body>
</html>
