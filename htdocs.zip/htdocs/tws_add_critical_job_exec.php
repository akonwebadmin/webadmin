<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add Critical Job</title>
<?php tws_stylesheet(); ?>
</head>
<body>
<?php tws_set_window_title();

   tws_import_request_variables("P","rqst_");

   $list_number=tws_gpc_get($rqst_list_number, 'tws_num');
   $deadline_hour=tws_gpc_get($rqst_deadline_hour, 'tws_num');
   $deadline_minute=tws_gpc_get($rqst_deadline_minute, 'tws_num');

// Confirmation form
if(empty($rqst_confirmed)){
   $workstation=strtoupper(tws_gpc_get($rqst_workstation, 'tws_mask'));
   $jobstream=strtoupper(tws_gpc_get($rqst_jobstream, 'tws_mask'));
   $job=strtoupper(tws_gpc_get($rqst_job, 'tws_mask'));

// Do some error checking
   if ($workstation == "")
      tws_dyer("No workstation name specified");
   if ($jobstream == "")
      tws_dyer("No jobstream name specified");
   if ($job == "")
      tws_dyer("No job name specified");
   if (($deadline_hour == "") || ($deadline_minute == ""))
      tws_dyer("Invalid deadline time specified");
   if ((!is_numeric($deadline_hour)) || (!is_numeric($deadline_minute)) ||
       $deadline_hour<0 || $deadline_minute<0 || $deadline_hour>23 || $deadline_minute>59)
      tws_dyer("Invalid deadline time specified", "", "back");

   if (!db_connect($composer_db,DB_PERSISTENT) )
      tws_warning("Cannot connect to database");
   $schema = $composer_db['schema'];

// IWS 9.5 folders
      // avoid usage of list f-ce
      $tmp = tws_explode_folder($jobstream);
      $folder = $tmp[0];
      $jobstream = $tmp[1];

$query="SELECT DISTINCT
            WKC.WKC_NAME WKC,
            AJS.AJS_NAME AJS,
            AJB.AJB_NAME AJB";
         if($tws_config['cpuinfo']['version']>='9.5' )
            $query .= ",
               FOL_PATH" ;     // 9.5 folders
   $query .="
         FROM (((( $schema.JOB_JOBS JOB
           JOIN $schema.AJB_ABSTRACT_JOBS AJB   ON AJB.AJB_ID = JOB.AJB_ID)
           JOIN $schema.JST_JOB_STREAMS JST  ON JST.JST_ID = JOB.JST_ID)
           JOIN $schema.AJS_ABSTRACT_JOB_STREAMS AJS  ON AJS.AJS_ID = JST.AJS_ID)
           JOIN $schema.WKC_WORKSTATION_CLASSES WKC   ON WKC.WKC_ID = AJS.WKC_ID)";
         $query .= ($tws_config['cpuinfo']['version']>='9.5' ? "
            LEFT JOIN $schema.FOL_FOLDERS FOL ON AJS.FOL_ID = FOL.FOL_ID " : '');  // 9.5 folders
      $query .= "
         WHERE WKC.WKC_NAME ".tws_sqllike(db_string($composer_db,$workstation))." AND
               AJS.AJS_NAME ".tws_sqllike(db_string($composer_db,$jobstream))."
            AND AJB.AJB_NAME ".tws_sqllike(db_string($composer_db,$job));
         if($tws_config['cpuinfo']['version']>='9.5')
            $query .= "
               AND FOL_PATH ".tws_sqllike(db_string($composer_db, $folder));
      $query .= "
         ORDER BY WKC, AJS, AJB";

   if (!db_query($composer_db,$query) )
      tws_warning("Database query error");

?>
<div style="position:relative;">
<h2>Select jobs to set critical deadline at <?=$deadline_hour?>:<?=$deadline_minute?></h2>
<br>
<form action="tws_add_critical_job_exec.php" method="POST" name='content'>
<? tws_print_check_clear_all('document.content');
while ($row = db_fetch_row($composer_db)){
   if(!empty($row['FOL_PATH']))
      $row['AJS'] = $row['FOL_PATH'].$row['AJS'];
   echo "<label><input type='checkbox' name='selection[]' value='".$row['WKC']."#".$row['AJS'].".".$row['AJB']."' checked>";
   echo $row['WKC']."#".$row['AJS'].".".$row['AJB']."</label><br>";
}
   echo tws_create_hidden_inputs($_POST);?>
   <input type="hidden" name='confirmed' value='yes'>

   <input type="submit" name='action' value=" Ok " style="position:absolute; bottom:0; left:20px;" >
</form>

<form action="tws_add_critical_job.php" method="post" style="display:inline-block;">
      <?=tws_create_hidden_inputs($_POST);?>
      <input type="submit" name='action' value="Cancel" style="position: absolute; bottom:0; left:100px;" >
</form>
<br><br><br>
</div>
<?
exit;
}
?>

<h1>Add Critical Job</h1>
<br>
<?
// Form deadline string
   $deadline_hour=str_pad($deadline_hour,2,'0',STR_PAD_LEFT);
   $deadline_minute=str_pad($deadline_minute,2,'0',STR_PAD_LEFT);
   $deadline="1970-01-01 $deadline_hour:$deadline_minute:00";

// conect to database
   db_connect($webadmin_db, DB_PERSISTENT) or tws_dyer("Could not connect to database", "", "tws_critical_jobs_lists.php");
   $schema=$webadmin_db['schema'];

   if(empty($rqst_selection)) tws_dyer("No jobs selected");

foreach($rqst_selection as $i=>$selection){
   // avoid 'list' f-ce
   $tmp = explode('#', $selection);
   $workstation = $tmp[0];
   $selection = $tmp[1];
   $tmp = explode('.', $selection);
   $jobstream = $tmp[0];
   $job = $tmp[1];
   if(empty($workstation) || empty($jobstream) || empty($job)){
      tws_warning("Bad job name: ". $rqst_selection[$i]);
      continue;
   }

   is_numeric($list_number) or tws_dyer("Bad list number format");
   $query="DELETE FROM $schema.critical_jobs
      WHERE listnum=$list_number
      AND workstation='".db_string($webadmin_db, $workstation)."'
      AND jobstream='".db_string($webadmin_db, $jobstream)."'
      AND job='".db_string($webadmin_db, $job)."'";
   db_query($webadmin_db, $query) or tws_dyer("Database query failed");

// Insert deadline
   $query="INSERT INTO $schema.critical_jobs (listnum,workstation,jobstream,job,deadline)
   VALUES ($list_number,'".db_string($webadmin_db,$workstation)."','".db_string($webadmin_db,$jobstream)."','".db_string($webadmin_db,$job)."','".db_string($webadmin_db,$deadline)."')";
   db_query($webadmin_db,$query) or tws_dyer("Insert into table 'critical_jobs' failed - unable to complete request.", "", "tws_critical_jobs_lists.php");
}
   if (isset($webadmin_db['allow_persistent']) && tws_yesno($webadmin_db['allow_persistent'])=='NO')
      db_commit($webadmin_db) or tws_dyer("Insert into table 'critical_jobs' failed - unable to COMMIT request.");

// close db connection
   db_close($webadmin_db);

   echo "<script type='text/javascript'>\n";
   echo "window.location.replace(\"tws_critical_jobs_lists.php?list_number=".urlencode($list_number)."\");\n";
   echo "</script>\n";
?>
</body>
</html>
