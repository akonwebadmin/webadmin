<?php
//   HORIZONT Software GmbH, Munich
//

require_once 'tws_functions.php';

error_reporting(E_ALL ^ E_STRICT);
ini_set('display_errors', 'on');
set_time_limit(30);

if (isset($_POST['action']) && $_POST['action'] == 'Save Report') {
   header('Content-Type: text/html');
   header('Content-disposition: attachment; filename="IWSWebAdmin4_engine_check.htm"');
   $result = unserialize(base64_decode($_POST['result']));
   foreach ($result as $val) {
      echo $val."\n\n\n";
   }
   exit();
}
$result = array();
$line = "\n--------------------------------------------------\n";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
   <meta http-equiv="content-type" content="text/html; charset=utf-8" />
   <title>IWS/WebAdmin4 System Info</title>
   <?php tws_stylesheet(); ?>
</head>
<body>
<h1 style="text-align: center; margin-bottom: 60px">IWS/WebAdmin4 System Info</h1>
<?php
if (!tws_profile('is_admin')) {
   tws_profile('opener', 'index.php');
   tws_dyer("Unprivilleged access to the IWS/WebAdmin System Informations");
}
echo "<hr/>";
// TWA Version
   twa_info();

function _phpinfo($buffer) {
   global $result;
   $result[1].=$buffer;
}

//init:
$session_cpy=$_SESSION;
$tws_config_cpy=$tws_config;
$tws_config['twa_dir']=preg_replace(';/TWS;','',$tws_config['maestro_dir']);
$_SERVER['PHP_AUTH_PW']='******';
$session_hide=array('auth_user_pw', 'tws_authority_pw', 'tws_cache', 'sudo_auth');
$backup=array();
$result=array();
$result[1]='';

ob_start('_phpinfo');
phpinfo();
ob_end_flush();

//ERR17363, ERR17364:
secure_data($result[1],'x');

$result[1]=preg_replace('/<\/body><\/html>/', '', $result[1]);
echo '<div>'.$result[1].'</div>';

//webadmin subsystems
if (function_exists('apache_get_version')) {
   $wserver_version=apache_get_version();
} else {
  $wserver_version='Apache';
}
$result[2]="<h2><a name=\"tws_webadmin_subsystems\">Other IWS/WebAdmin Subsystems</a></h2>\n";
$result[2].="<table border=\"0\" cellpadding=\"3\" width=\"600\">\n";
$result[2].="<tr><td class=\"e\">Web Server</td><td class=\"v\">".$wserver_version."</td></tr>\n";
$result[2].="</table>\n";

$result[3]="<h2><a name=\"php_extensions_dl\">PHP Extensions dynamic load</a></h2>\n";
$result[3].="<table border=\"0\" cellpadding=\"3\" width=\"600\">\n";
$libs = array();
$dir = opendir(ini_get('extension_dir'));
while (($lib=readdir($dir))!==FALSE) {
   if (preg_match('/'.PHP_SHLIB_SUFFIX.'/',$lib)) $libs[] = $lib;
}
sort($libs);
foreach ($libs as $lib) {
   //if ($host_os!='win32' && !extension_loaded(preg_replace('/\.'.PHP_SHLIB_SUFFIX.'|php_/','',$lib))) @dl($lib);
   $result[3].="<tr><td class=\"e\">$lib</td><td class=\"v\">".(extension_loaded(preg_replace('/\.'.PHP_SHLIB_SUFFIX.'|php_/','',$lib)) ? 'Success' : 'Not Loaded')."</td></tr>\n";
}
$result[3].="</table>\n";

//include db_config.php once more - reason: we need the encrypted passwords
include 'db_config.php';

//ERR17363,17364:
array_walk_recursive($tws_config_cpy, 'secure_data');
array_walk_recursive($session_cpy, 'secure_data');
foreach ($session_hide as $key) {
   if (isset($session_cpy[$key])) {
      $session_cpy[$key]='******';
   }
}
$result[4]="<h2><a name=\"dump\">User profile</a></h2>\n";
$result[4].="<table border=\"0\" cellpadding=\"3\" width=\"600\">\n";
$result[4].="  <tr><td class=\"e\">\$tws_config</td><td class=\"v\" style=\"text-align:left\"><pre>".htmlspecialchars(print_r($tws_config_cpy, true))."</pre></td></tr>\n";
$result[4].="  <tr><td class=\"e\">\$_SESSION</td><td class=\"v\" style=\"text-align:left\"><pre>".htmlspecialchars(print_r($session_cpy, true))."</pre></td></tr>\n";
$result[4].="  <tr><td class=\"e\">\$composer_db</td><td class=\"v\" style=\"text-align:left\"><pre>".htmlspecialchars(print_r($composer_db, true))."</pre></td></tr>\n";
$result[4].="  <tr><td class=\"e\">\$webadmin_db</td><td class=\"v\" style=\"text-align:left\"><pre>".htmlspecialchars(print_r($webadmin_db, true))."</pre></td></tr>\n";
$result[4].="</table>\n";


echo '<center>'.$result[2].'</center>';
echo '<center>'.$result[3].'</center>';
echo '<center>'.$result[4].'</center>';
$result[5]="</body></html>";

flush();
?>
<form action="" method="post" name="reportForm" style="position: absolute; top: 60px; left: 0; width: 100%; text-align: center">
   <input type="hidden" name="result" value="<?php echo base64_encode(serialize($result)); ?>" />
   <input type="hidden" name="action" value="Save Report" />
   <input type="submit" name="action" value="Save Report" />
</form>
<script type="text/javascript">
   window.document.reportForm.submit();
</script>
</body>
</html>
<?php

function secure_data(&$item, $key) {
   global $tws_config;
   $item=preg_replace(';'.addcslashes($tws_config['base_inst_dir'],'\\').';', '$WEBADMIN_DIR', $item);
   $item=preg_replace(';'.addcslashes($tws_config['maestro_dir'],'\\').';', '$TWS_DIR', $item);
   $item=preg_replace(';'.addcslashes($tws_config['twa_dir'],'\\').';', '$TWA_DIR', $item);
   $item=preg_replace(';/.*IBM/;', '$IBM_DIR/', $item);
   $item=preg_replace(';/.*ibm/;', '$ibm_DIR/', $item);
   $item=preg_replace(';'.$_SERVER['SERVER_ADDR'].';', '$SERVER_ADDR', $item);
   $item=preg_replace(';'.$_SERVER['SERVER_PORT'].';', '$SERVER_PORT', $item);
}

function twa_info(){
   $curdir = getcwd();

   // read Version
   ?><table border=0><tr><td class='e'><?
   $file = $curdir."/../../version/version.info";
   if( ($content = file($file))!==false )
      $str = trim(implode('', $content));
   else echo "can't read TWA Version from $file";
   $file = $curdir."/../../version/fixpack.info";
   if( ($content = file($file))!==false )
      $str .= " ".trim(implode('', $content));
   echo "TWA Version: </td><td class='v'>$str";
   ?></td>
   </tr><tr><td class='e'><?
   $file = $curdir."/zli_net_module/zli_component.info";
   if( ($content = file($file))!==false ){
      $str = trim(implode('', $content));
      $str = str_replace(',', '.', $str);
      echo "NetPlan ActiveX Version: </td><td class='v'>$str";
   }
   ?></td></tr>
   </tr><tr><td class='e'><?
   $file = $curdir."/twazy/version.info";
   if( ($content = file($file))!==false ){
      $str = trim(implode('', $content));
      echo "NetPlan JS/SVG Version: </td><td class='v'>$str";
   }
   ?></td></tr>

   <?

   // Scan for patches installed

   $dirlist[] = $curdir;
   $dirlist[] = $curdir."/admin";
   $dirlist[] = $curdir."/../../inc";
   $dirlist[] = $curdir."/../../bin";

   foreach($dirlist as $dir) {
      if ($dh = opendir($dir)) {
         while (($file = readdir($dh)) !== false) {
            $file = "$dir/$file";
            $info = pathinfo($file);
            if(empty($info['extension'])) continue;
            $ext = $info['extension'];
            if($ext == "php"){
               if( ($content = file($file))===false ) { echo "can't read $file"; continue; }
               // look for patch info (first 20 rows)
               $cnt = count($content);
               if($cnt>20) $cnt=20;
               for($i=0; $i<$cnt; $i++){
                  $patch_name_pattern = 'twa3\.[.0-9]*-patch\d*';
                  if(preg_match("/\/\/\s*patch.*:\s*($patch_name_pattern)/i", $content[$i])){
                     preg_match_all("/$patch_name_pattern/", $content[$i], $matches);
                     foreach($matches[0] as $match) $patchlist[$match] = '';
                  }
               }
            }
         }
         closedir($dh);
      }
   }
   ?><tr><td valign="top" class='e'>Patches installed:</td><td class='v'><?
   if (!empty($patchlist)){
      foreach($patchlist as $patch=>$v)
         echo "$patch<br>";
   }
   ?>
   </td></tr></table>
   <?
}
?>
