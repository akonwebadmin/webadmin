<?php
//   HORIZONT Software GmbH, Munich
//
   require_once "tws_functions.php";
   tws_doctype("t");

   // Cancel button test
   if (isset($_POST['action']) && $_POST['action'] == 'Return to Modification'){
      $values = tws_form_to_arr('calendar', $_POST);
      foreach ($_POST as $key => $val){
         $$key = tws_gpc_get($val);
      }
   }
   if ($copy == "yes") {
      $h1 = "Copy Calendar";
      if (!tws_permit_action('database_calendars','Copy')) { tws_access_denied ();}
   } 
   elseif($modify == "yes") {
      $h1 = "Modify Calendar";
      if (!tws_permit_action('database_calendars','Modify')) { tws_access_denied ();}
   } 
   elseif($display == "yes") 
      $h1 = "Display Calendar";
   else {
      $h1 = "Add Calendar";
      if (!tws_permit_action('database_calendars','Add')) { tws_access_denied ();}
   }

   if (($copy == "yes" || $modify == "yes" || $display=='yes') && !isset($calendar_name)) {
      $num_elements=count($selection);
      if ($num_elements == 0) 
         tws_dyer("No calendar selected");
      elseif ($num_elements > 1) 
         tws_dyer("Multiple calendars selected");

      // Get Calendar data
      if (($db_cal = tws_calendar_to_arr($selection[0])) === FALSE) 
         tws_dyer("Unable to get calendar $selection[0]");
      if ($db_cal['calendar_num'] != 1) 
         tws_dyer("Multiple calendars get from DB");
   }
   if ($modify=="yes" && !$original_data) {
      tws_composer_lock("cal=$selection[0]") or tws_dyer("Unable to lock calendar '$selection[0]'");
      if (($original_data=tws_composer_create_from("cal=$selection[0]"))===FALSE) tws_dyer("Unable to get original data");
   }
   if($modify=="yes") $action = 'modify';
   elseif($copy == "yes") $action = 'copy';
   elseif($display == "yes") $action = 'display';
   else $action = 'add';
?>
<html>
<head>
<title><?=$h1 ?></title>
<? tws_stylesheet(); ?>

<script type="text/javascript">
function ConfirmCancel(objectname,url){
   $('form').unbind('submit');
   var conftext=confirm("Exit " + objectname + " Definition (Changes will be lost) ?");
   if (conftext) {
      if (url==null) return true;
      closeme(url);
   }
   else 
      return false;
   
}

</script>

</head>
<body>
<? tws_set_window_title();
   tws_print_head($h1);
?>
<br><br>
<form method=post name="contents" action="tws_add_calendar_action.php" onsubmit="if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Calendar',null)) { cancel_button_pressed=false; return false;}">

<? tws_show_calendar_form($db_cal, $action); ?> 

<br><br>&nbsp;&nbsp;&nbsp;&nbsp;
<? if ($display!='yes'){
   echo '<input type="submit" name="action" value="Save Calendar" onClick="return tws_validate_form()">';

   if ($modify=="yes") 
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' name='action' value='Cancel' onClick='cancel_button_pressed=true;'>\n";
   else 
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' value='Cancel' onClick=\"ConfirmCancel('Calendar','tws_calendarsx.php')\">\n";
   
}
else echo "&nbsp;&nbsp;&nbsp;<input type='button' value='Close window' onClick='window.close();'>\n";

?>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" value="Print" onClick="window.print()">
<?
   if ($modify == "yes") 
      echo "<input type='hidden' name='modify' value='yes'>\n";
   elseif ($copy == "yes") 
      echo "<input type='hidden' name='copy' value='yes'>\n";
   
   tws_print_synchro_token();   // synchro_token

?>
<input type="hidden" name="original_data" value="<?=htmlspecialchars($original_data)?>">
</form>
</body>
</html>
