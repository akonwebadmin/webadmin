<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_import_request_variables("P","rqst_");

   $modify=$rqst_modify;
   if ($modify == "yes") {
      if ( !tws_permit_action('database_workstations','Modify') ) {tws_access_denied ();}
      $workstation_name=strtoupper($rqst_workstation_namex);
   }
   else {
      if ( !tws_permit_action('database_workstations','Add') ) {tws_access_denied ();}
      $workstation_name=strtoupper($rqst_workstation_name);
   }
   $workstation_name = tws_gpc_get($workstation_name, 'tws_name');

  
   $action=$rqst_action;
   if($action=="Return to Workstation Modification"){
      include("tws_add_workstation.php");
      exit;
   }
   
    if(!empty($rqst_workstation_folder)){
      $workstation_folder = tws_gpc_get($rqst_workstation_folder);
      $workstation_name = $workstation_folder.$workstation_name;
   } else {
	  $workstation_folder = '';
   }
   
   if ($tws_config['cpuinfo']['version']>='9.5002') {
      list($ws_folder, $ws_name) = tws_divide_folder($workstation_name);
   } else {
	   $ws_folder = '';
	   $ws_name = $workstation_name;
   }

   tws_doctype("t");
?>
<html>
<head>
<title>Add Workstation</title>
<?
tws_stylesheet();
tws_show_backup();

   if ($action=="Cancel") {
      // Unlock the object
      tws_composer_unlock("ws=$workstation_name") or tws_dyer("Unable to unlock workstation ".$workstation_name);
      tws_doctype("t");
      echo "<script type='text/javascript'>\n";
         echo "closeme('tws_workstationsx.php');\n";
      echo "</script>\n";
      exit;
   }

?>
<script type="text/javascript">
   function ConfirmCancel(objectname, url) {
   tws_waiting(0);
      var conftext = confirm("Exit " + objectname + " Definition (Changes will be lost) ?");
      if (conftext) {
         if (url==null) return true;
         window.location.replace(url);
      } else {
         return false;
      }
   }
</script>
</head>
<body>
<? tws_set_window_title();

   tws_check_synchro_token();

   $node=tws_gpc_get($rqst_node);
   $tcpaddr=tws_gpc_get($rqst_tcpaddr, 'tws_num');
   $secureaddr=tws_gpc_get($rqst_secureaddr, 'tws_num');

   if (($rqst_os_typex != "") && ($rqst_os_typex != "NULL")) {
      $os_type=$rqst_os_typex;
   } else {
      $os_type=$rqst_os_type;
   }
   $os_type = tws_gpc_get($os_type, 'tws_name');

   if (isset($rqst_workstation_typex) && ($rqst_workstation_typex != "")) {
      $workstation_type=$rqst_workstation_typex;
   } else {
      $workstation_type=$rqst_workstation_type;
   }
   $workstation_type = tws_gpc_get($workstation_type, 'tws_name');

   $description=tws_gpc_get($rqst_description);
   $domain=strtoupper(tws_gpc_get($rqst_domain, 'tws_name'));
   $parameter_table=strtoupper(tws_gpc_get($rqst_parameter_table, 'tws_name'));
   $time_zone=tws_gpc_get($rqst_time_zone);
   $autolink=tws_gpc_get($rqst_autolink, 'tws_name');
   $fullstatus=tws_gpc_get($rqst_fullstatus, 'tws_name');

   //$resolvedeps=$rqst_resolvedeps;
   $behindfirewall=tws_gpc_get($rqst_behindfirewall, 'tws_name');
   $securitylevel=tws_gpc_get($rqst_securitylevel, 'tws_name');
   $protocol=tws_gpc_get($rqst_protocol, 'tws_name');
   $ignore=tws_gpc_get($rqst_ignore, 'tws_name');
   $server=tws_gpc_get($rqst_server, 'tws_alfanum');
   $method=tws_gpc_get($rqst_method, 'tws_name');
   $host=strtoupper(tws_gpc_get($rqst_host));
   $confirm=tws_gpc_get($rqst_confirm, 'tws_name');
   $backup=tws_gpc_get($rqst_backup, 'tws_name');
   $original_data=tws_gpc_get($rqst_original_data);
   if(isset($rqst_license_type))
      $license_type = $rqst_license_type;

// Make some corrections:
   switch ($workstation_type) {
      case 'M' : case 'MANAGER' :
         $fullstatus='YES';
         break;
      case 'S' : case 'S-AGENT' :
         $fullstatus='NO';
         break;
      case 'X' : case 'X-AGENT' :
         $fullstatus='';
         if($tws_config['cpuinfo']['version']<'8.6') $domain='';
         break;
      case 'L' : case 'POOL' :
         $members = tws_gpc_get($rqst_members, 'tws_name');
         break;
      case 'Y' : case 'D-POOL' :
         $availableOS = tws_gpc_get($rqst_availableOS, 'tws_name');   //array
         $CPUUtilization = tws_gpc_get($rqst_CPUUtilization, 'tws_num'); // number
         $resources = $rqst_resources; // resources[i][name], resources[i][quantity], resources[i][reserve]
         if(empty($resources)) $resources = array();
         foreach($resources as $i=>$res) {
            if (isset($resources[$i]['name']) && $resources[$i]['reserve']) {
               $reservedResources[$i]['name'] = $resources[$i]['name'];
               $reservedResources[$i]['quantity'] = @$resources[$i]['quantity'];
               $reservedResources[$i]['subType'] = @$resources[$i]['type'];
            }
            elseif (isset($resources[$i]['name']) ) {
               $relatedResources[$i]['DisplayName'] = $resources[$i]['name'];
               $relatedResources[$i]['SubType'] = @$resources[$i]['type'];
               $relatedResources[$i]['Quantity'] = @$resources[$i]['quantity'];
            }
         }
         $workstations = tws_gpc_get($rqst_workstations, 'tws_name');    // array
         $optimization = tws_gpc_get($rqst_optimization, 'tws_name');    // string
         $requirements = tws_gpc_get($rqst_requirements);   // <XML> from confirmation
         break;
   }

// Perform error checking
   $field_error=0;
   $field_error_text="";

   if ($workstation_name == "") {
      $field_error_text .= "Workstation: '$workstation_name' Error: Workstation name not set\n";
      $field_error++;
   }
   if ($tcpaddr != "") {
      if (!is_numeric($tcpaddr)) {
         $field_error_text .= "TCP Address: '$tcpaddr' Error: TCP Address is non-numeric\n";
         $field_error++;
      } elseif (($tcpaddr < 0) || ($tcpaddr > 65535)) {
         $field_error_text .= "TCP Address: '$tcpaddr' Error: TCP Address is not within the valid range 1-65535\n";
         $field_error++;
      }
   }
   if ($secureaddr != "") {
      if (!is_numeric($secureaddr)) {
         $field_error_text .= "TCP Address: '$secureaddr' Error: TCP Address is non-numeric\n";
         $field_error++;
      } elseif (($secureaddr < 1) || ($secureaddr > 65535)) {
         $field_error_text .= "TCP Address: '$secureaddr' Error: TCP Address is not within the valid range 1-65535\n";
         $field_error++;
      }
   }

   if ($workstation_type == "X" || $workstation_type == "A" || $workstation_type == "E" || $workstation_type == "L" || $workstation_type == "Y") {
      if ($host == "") {
         $field_error_text .= "Host: '$host' Error: Host not set\n";
         $field_error++;
      }
   }
   if ($workstation_type == "X") {
      if ($method == "") {
         $field_error_text .= "Method: '$method' Error: Method not set for workstation type X-AGENT\n";
         $field_error++;
      }
   }
   if ($field_error != 0) {
      if ($modify == "yes") {
         echo "<h1>Modify Workstation Status</h1>\n";
      } else {
         echo "<h1>Add Workstation Status</h1>\n";
      }
      tws_err("Incorrect values entered", array('attr'=>$field_error_text));  //TODO
      echo "<form method=post name=\"confirm\" action=\"tws_add_workstation_exec.php\" onsubmit=\"if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Workstation',null)) { cancel_button_pressed=false; return false;}\">\n";
         echo tws_create_hidden_inputs($_POST);
         echo "<input type=\"hidden\" name=\"workstation_folder\" value=\"$workstation_folder\">\n";
         echo "<input type=\"hidden\" name=\"workstation\" value=\"$workstation_name\">\n";
         if ($modify == "yes") {
            echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
            echo "<input type=\"hidden\" name=\"workstation_namex\" value=\"".htmlspecialchars($workstation_name)."\">\n";
         }
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Return to Workstation Modification\" name=\"action\">\n";
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Cancel\" name=\"action\" onClick=\"cancel_button_pressed=true;\">\n";
         echo "</form>\n";
         die();
   }

// CONFIRMATION REQUIRE
// Form the workstation data and check for existing workstation
   if($confirm!="yes") {
      // create the new workstation structure
      $new_workstation=Array('workstation_folder'=>$ws_folder, 'workstation_name'=>$ws_name, 'description'=>$description, 'os_type'=>$os_type, 'node'=>$node, 'tcpaddr'=>$tcpaddr, 'secureaddr'=>$secureaddr, 'domain'=>$domain, 'workstation_type'=>$workstation_type, 'time_zone'=>$time_zone, 'ignore'=>$ignore, 'host'=>$host, 'method'=>$method, 'autolink'=>$autolink, 'fullstatus'=>$fullstatus, 'behindfirewall'=>$behindfirewall, 'securitylevel'=>$securitylevel, 'server'=>$server);
      $tws_config['cpuinfo']['version']>='8.5' && $new_workstation['parameter_table']=$parameter_table;

      if($workstation_type == 'L') {
         $new_workstation['members']=$members;
      }
      if($workstation_type == 'Y') {
         $new_workstation['requirements']['candidateOperatingSystems'] = $availableOS;
         $new_workstation['requirements']['CPUUtilization'] = $CPUUtilization;
         $new_workstation['requirements']['relatedResources'] = $relatedResources;
         $new_workstation['requirements']['reservedResources'] = $reservedResources;
         $new_workstation['requirements']['candidatedWorkstations'] = $workstations;
         $new_workstation['requirements']['optimization'] = $optimization;
      }
      // form the new-workstation data for composer
      $new_workstation=tws_form_workstation_data($new_workstation);

      // original workstation data to the composer form
      $orig_workstation_data=tws_get_workstation_data($workstation_name);
      if (count($orig_workstation_data)) {
         if ($modify == "yes") {
            echo "<h1>Confirmation</h1>\n";
         } else {
            echo "<h1>Replace Workstation Confirmation</h1>\n";
         }
         echo "<br><br>\n";
         echo "<h3>Confirm:</h3>\n";
         if ($modify != "yes") {
            echo "&nbsp;&nbsp;<b>The Workstation Name entered already exists</b>\n";
            echo "<br><br>\n";
         }
         echo "<br>\n";

         $orig_workstation_data=tws_form_workstation_data($orig_workstation_data);

         $label_map = Array('ws_name'=>'Workstation', 'node'=>'Node', 'tcpaddr'=>'TCP Address', 'os_type'=>'Operating System', 'description'=>'Description', 'secureaddr'=>'Secure TCP Port', 'domain'=>'Domain', 'workstation_type'=>'Workstation Type', 'time_zone'=>'Time Zone', 'ignore'=>'Ignore', 'host'=>'Host', 'method'=>'Method', 'autolink'=>'Auto Link', 'fullstatus'=>'Full Status', 'behindfirewall'=>'Behind Firewall', 'securitylevel'=>'SSL Communication', 'server'=>'Server', 'parameter_table'=>'Parameter Table', 'protocol'=>'Protocol');
         if($workstation_type == 'Y') {
            $label_map['candidateOperatingSystems'] = 'Operating Systems';
            $label_map['reservedResources'] = 'Reserved Resources';
            $label_map['CPUUtilization'] = 'CPU Utilization (%)';
            $label_map['candidatedWorkstations'] = 'Workstations';
            $label_map['relatedResources'] = 'Related Resources';
            $label_map['optimization'] = 'Optimization';
         }
         elseif($workstation_type == 'L')
            $label_map['members'] = 'Members';

         // show the comparison table
         tws_show_cmp_table("Original Workstation", "New Workstation", $orig_workstation_data, $new_workstation, $label_map);

         // confirmation form
         echo "<form method=post name=\"confirm\" action=\"tws_add_workstation_exec.php\" onsubmit=\"if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Workstation',null)) { cancel_button_pressed=false; return false;}\">\n";
         if ($original_data=='') {
         //missing original data - this happens if user is adding job that already exists.
            if (($original_data=tws_composer_create_from("ws=$workstation_name"))===FALSE) {
               tws_err("Unable to get original data required to create backup.");
            }
         }
         //    prepare hidden inputs
         echo tws_create_hidden_inputs($_POST);
         echo "<input type=\"hidden\" name=\"workstation\" value=\"$workstation_name\">\n";
         //echo "<input type=\"hidden\" name=\"original_data\" value=\"".htmlspecialchars($original_data)."\">\n";
         echo "<input type=\"hidden\" name=\"confirm\" value=\"yes\">\n";

         if (tws_rights(SAVEBACKUPS) && $original_data!=''){
            echo "<input type='hidden' name='backup' value='yes'>";
            echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type='checkbox' name='backup' value='yes' checked disabled>&nbsp;Save Backup Copy of Original Workstation</label>\n";
         }
         else
            echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type=\"checkbox\" name=\"backup\" value=\"yes\" ".($original_data!='' ? 'checked' : 'disabled').">&nbsp;Save Backup Copy of Original Workstation</label>\n";
         echo "<br><br><br>\n";
         if ($modify == "yes") {
            echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Update\" name=\"action\">\n";
            echo "<input type=\"hidden\" name=\"modify\" value=\"yes\">\n";
            echo "<input type=\"hidden\" name=\"workstation_namex\" value=\"".htmlspecialchars($workstation_name)."\">\n";
         } else {
            echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Replace\" name=\"action\">\n";
         }
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Return to Workstation Modification\" name=\"action\">\n";
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Cancel\" name=\"action\" onClick=\"cancel_button_pressed=true;\">\n";
         tws_print_synchro_token();   // synchro_token
         echo "</form>\n";
      }
      else {
         // No need for confirmation - no conflict detected - ready to call composer
         $confirm="none";
         foreach( $new_workstation as $key=>$val )
            $$key=$val;
      }
   }

// READY TO CALL COMPOSER
   if ($confirm=="yes" || $confirm=="none") {
// Create Backup Copy if option checked
      if ($backup == "yes") {
         if (($bckfilename = tws_write_backup($original_data, "workstation", $workstation_name)) === FALSE) {
            tws_error("Unable to write backup");
         }
      }

      if($workstation_type == 'Y' || $workstation_type =='D-POOL') {
         $requirements['availableOS'] = $availableOS;
         $requirements['CPUUtilization'] = $CPUUtilization;
         $requirements['resources'] = $resources;
         $requirements['workstations'] = $workstations;
         $requirements['optimization'] = $optimization;
         $str_requirements = tws_req_get_xml ($requirements);
      }
      elseif($workstation_type == 'L' || $workstation_type == 'POOL') {
         if(isset($members) && count($members))
            $str_members = implode(' ', $members);
      }

// Unlock the object
      tws_composer_unlock("ws=$workstation_name");

// Assembly the composer command
      $cmd=Array();
      $cmd[]="CPUNAME $workstation_folder"."$workstation_name\n";
      $cmd[]="DESCRIPTION \"".addcslashes($description,'"')."\"\n";
      if(isset($license_type) && $license_type == 'S')
         $cmd[]="LICENSETYPE perServer\n";
      elseif(isset($license_type) && $license_type == 'J')
         $cmd[]="LICENSETYPE perJob\n";
      $cmd[]="OS ". tws_typeval('WKS_OPERATING_SYSTEM',$os_type). "\n";
      if(!empty($node)) $cmd[]="NODE $node\n";
      if(!empty($tcpaddr)) $cmd[]="TCPADDR $tcpaddr\n";
      if(!empty($secureaddr)) $cmd[]="SECUREADDR $secureaddr\n";
      if(isset($time_zone) && $time_zone!='NULL' && $time_zone!='') $cmd[]="TIMEZONE $time_zone\n";
      if(!empty($domain)) $cmd[]="DOMAIN $domain\n";
      if(!empty($parameter_table)) $cmd[]="VARTABLE $parameter_table\n";
      $cmd[]="FOR MAESTRO\n";
      if(!empty($host)) $cmd[]="   HOST $host\n";
      if(!empty($method)) $cmd[]="   ACCESS $method\n";
      $cmd[]="   TYPE ". tws_typeval('WKS_AGENT_TYPE',$workstation_type). "\n";
      if(!empty($autolink)) $cmd[]="   AUTOLINK ". tws_yesno($autolink, "ON", "OFF") ."\n";
      if(!empty($fullstatus)) $cmd[]="   FULLSTATUS ".tws_yesno($fullstatus,'ON','OFF')."\n";
      if(isset($securitylevel) && $securitylevel!='NULL' && $securitylevel!='') $cmd[]="   SECURITYLEVEL ".tws_typeval('WKS_SECURITY_LEVEL',$securitylevel)."\n";
      if(!empty($behindfirewall)) $cmd[]="   BEHINDFIREWALL ". tws_yesno($behindfirewall, "ON", "OFF"). "\n";
      if(isset($server) && $server!='NULL' && $server!='') $cmd[]="   SERVER $server\n";
      if(isset($ignore) && $ignore!='NO' ) $cmd[]="   IGNORE\n";
      if(!empty($members)) $cmd[]="   MEMBERS $str_members\n";
      if(!empty($requirements)) $cmd[]="   REQUIREMENTS $str_requirements\n";
      $cmd[]="END\n";

// write the composer command to the temporary file
      $tmpfilename="$webadmin_tmp_dir/workstation.".tws_rndstr().".tmp";
      $fp3=fopen($tmpfilename,'w') or tws_dyer("Unable to create temporary file '$tmpfilename'");
      foreach( $cmd as $cmdline ){
         if (fwrite( $fp3, $cmdline )===FALSE) {
            fclose($fp3);
            tws_dyer("Unable to write temporary file '$tmpfilename'");
         }
      }
      fclose($fp3);
      tws_chmod($tmpfilename,0644);
// perform the command
      if ($confirm == "yes") {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "replace $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      } else {
         $command3=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "add $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      }

      $stdout3='';
      $ec_popen=tws_popen($command3, $ec3, $stdout3, $stdout3, "N");

      //remove the tmp file now
      unlink($tmpfilename);

      //testing for the AWSBIA288I Total objects updated: 0.
      //Note: This has been added on 2016-07 to fix the problem of composer updating
      //correctly objects but returning incorrect return codes (not 0 or 4)
      $not_updated=!preg_match('/AWSBIA288[^\n]+(\d+)/', $stdout3, $_r) || $_r[1]==0;

      if ($ec_popen===FALSE || ($ec3!=0 && $ec3!=4 && $not_updated)) {
         if ($modify == "yes") {
            echo "<h1>Modify Workstation Status</h1>\n";
         } else {
            echo "<h1>Add Workstation Status</h1>\n";
         }
         tws_err("Workstation add/modify operation failed", array('twscmd'=>$command3->compile('log'), 'stdout'=>$stdout3, "EC_POPEN"=>$ec_popen, "EC_UPDATED"=>$ec3, "NOT_UPDATED"=>tws_yesno($not_updated,'YES','NO')));

         echo "<form action=\"tws_add_workstation_exec.php\" method=\"post\" onsubmit=\"if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Workstation',null)) { cancel_button_pressed=false; return false;}\">\n";
         echo tws_create_hidden_inputs($_POST, '', null);
         tws_print_synchro_token();
         echo "<input type=\"hidden\" name=\"workstation\" value=\"$workstation_name\">\n";
         echo "<input type=\"submit\" name=\"action\" value=\"Cancel\" onClick=\"cancel_button_pressed=true;\"/>\n";
         echo "<input type=\"submit\" name=\"action\" value=\"Return to Workstation Modification\"/>\n";
         echo "</form>";
      }
      elseif (preg_match("/warnings?\s[1-9]/i",$stdout3)) {
         if ($modify == "yes") {
            $headertext="Modify Workstation";
         } else {
            $headertext="Add Workstation";
         }
         tws_err("The workstation has been saved with the following warnings:", array('stdout'=>$stdout3));

         $shortwarnfilename="warn.".tws_rndstr().".txt";
         $warnfilename="$webadmin_tmp_dir/$shortwarnfilename";
         $warnfp=fopen("$warnfilename","w") or tws_dyer("Unable to create warning text file", "Warning output :\n$stdout3");
         $num_bytes=fwrite($warnfp,"$stdout3");
         if ($num_bytes < 0) {
            fclose($warnfp);
            unlink($warnfilename);
            tws_dyer("Unable to write warning text file", "Warning output :\n$stdout3");
         }
         fclose($warnfp);
         tws_dyer();
      }
      else {
         if ($backup == "yes") {
            if ($modify == "yes") {
               echo "<h1>Modify Workstation Status</h1>\n";
            } else {
               echo "<h1>Add Workstation Status</h1>\n";
            }
            echo "<p class=\"message\">\n";
            echo "The workstation has been successfuly saved.&nbsp;";
            $bckfilename = preg_replace("/\\\\/", '/', $bckfilename);
            $file = explode('/',$bckfilename);
            $file = end($file);
            if(tws_profile('auth_user_group')=='admin')
               echo "<a href=\"javascript:showBackup('$file')\">Display Backup File</a>\n";
            echo "</p>\n";
               echo "<input type='button' value='OK' onClick=\"closeme('tws_workstationsx.php')\">\n";
         } else {
            echo "<script type='text/javascript'>\n";
               echo "closeme('tws_workstationsx.php');\n";
            echo "</script>\n";
         }
      }
   }
?>
</body>
</html>
<?php
// php format -> composer format filtering function
function tws_form_workstation_data($wd) {
   $wd['workstation_type']=tws_typeval('WKS_AGENT_TYPE',$wd['workstation_type']);
   $wd['os_type']=tws_typeval('WKS_OPERATING_SYSTEM',$wd['os_type']);
   $wd['time_zone']=(trim($wd['time_zone'])=='' || $wd['time_zone']=='NULL') ? '' : $wd['time_zone'];
   //$wd['ignore']=tws_yesno($wd['ignore']);
   $wd['ignore']= tws_yesno($wd['ignore'], "YES", "NO");
   $wd['securitylevel']= $wd['securitylevel']=='NULL' ? "" : tws_typeval('WKS_SECURITY_LEVEL',$wd['securitylevel']);
   $wd['server']=(trim($wd['server'])=='' || $wd['server']=='NULL') ? "" : $wd['server'];
   $wd['host']=trim($wd['host']);
   $wd['secureaddr']=$wd['secureaddr'] ? $wd['secureaddr'] : '';
   $wd['autolink']= tws_yesno($wd['autolink'], "ON", "OFF");
   $wd['fullstatus']= tws_yesno($wd['fullstatus'], "ON", "OFF");
   $wd['behindfirewall']= tws_yesno($wd['behindfirewall'], "ON", "OFF");
   if($wd['workstation_type']=='AGENT' || $wd['workstation_type']=='REM-ENG' || $wd['workstation_type']=='POOL' || $wd['workstation_type']=='D-POOL'){
      $wd['autolink']= '';
      $wd['fullstatus']= '';
      $wd['behindfirewall']= '';
      $wd['securitylevel']= '';
   }

   if(isset($wd['requirements'])){
      if(is_array($wd['requirements'])) {
         foreach($wd['requirements'] as $key=>$requirement)
            $wd[$key] =$requirement;
      }
      else {   // dizassemble XML string
         $jsdl_data = tws_get_jsdl_requirements ($wd['requirements']);
         foreach($jsdl_data as $key=>$val)
            $wd[$key] = $val;
      }
      unset($wd['requirements']);
   }
   return $wd;
}

// make JSDL XML from fields
function tws_req_get_xml($requirements) {
   $xml = '<?xml version="1.0" encoding="UTF-8"?>
   <jsdl:resourceRequirements xmlns:jsdl="http://www.ibm.com/xmlns/prod/scheduling/1.0/jsdl">
   <jsdl:resources>'."\n";
   foreach ($requirements as $key=>$requirement) {
      // candidate Operating Systems
      if($key == 'availableOS' && is_array($requirement)) {
         $xml .= '<jsdl:candidateOperatingSystems>'."\n";
         foreach ($requirement as $os) {
            $xml .= '   <jsdl:operatingSystem type="'.$os.'"/>'."\n";
         }
         $xml .= '</jsdl:candidateOperatingSystems>'."\n";
      }
      // CPU Utilization
      elseif ($key == 'CPUUtilization') {
         $xml .= '<jsdl:properties>
         <jsdl:requirement propertyName="CPUUtilization">
           <jsdl:range>
             <jsdl:minimum>0</jsdl:minimum>
             <jsdl:maximum>'.$requirement.'</jsdl:maximum>
           </jsdl:range>
         </jsdl:requirement>
       </jsdl:properties>'."\n";
      }
      // Logical resources
      elseif ($key == 'resources' && is_array($requirement)) {
         $lr=0;
         foreach ($requirement as $resource){
            // Reserved resource
            if(isset($resource['name']) && isset($resource['reserve'])){
               if(isset($resource['quantity']) )
                  $xml .= '<jsdl:logicalResource name="'.$resource['name'].'" quantity="'.$resource['quantity'].'" subType="'.$resource['type'].'"/>'."\n";
               else
                  $xml .= '<jsdl:logicalResource name="'.$resource['name'].'" subType="'.$resource['type'].'"/>'."\n";
            }
            // Related resource
            elseif (isset($resource['name'])) {
               $lr++;
               $xml .= '<jsdl:relationship target="lr_'.$lr.'" type="AssociatesWith"/>'."\n";
            }
         }
      } // CandidatedWorkstations
      elseif($key == 'workstations' && is_array($requirement)){
         $xml .= '<jsdl:orderedCandidatedWorkstations>'."\n";
         foreach ($requirement as $ws){
            $xml .= '   <jsdl:workstation>'.$ws.'</jsdl:workstation>'."\n";
         }
         $xml .= '</jsdl:orderedCandidatedWorkstations>'."\n";
      }
   }
   $xml .= '</jsdl:resources>'."\n";

   foreach ($requirements as $key=>$requirement) {
      // Related resources
      if($key == 'resources' && is_array($requirement)) {
         $lr=0;
         foreach ($requirement as $resource){
            if (isset($resource['name'])&& !isset($resource['reserve'])) {
               $lr++;
               $xml .= '<jsdl:relatedResources id="lr_'.$lr.'" type="LogicalResource">
            <jsdl:properties>
              <jsdl:requirement propertyName="DisplayName">
                <jsdl:exact>'.$resource['name'].'</jsdl:exact>
              </jsdl:requirement>
              <jsdl:requirement propertyName="SubType">
                <jsdl:exact>'.$resource['type'].'</jsdl:exact>
              </jsdl:requirement>'."\n";
              if (isset($resource['quantity']))
               $xml .= '<jsdl:requirement propertyName="Quantity">
                <jsdl:range>
                  <jsdl:minimum>'.$resource['quantity'].'</jsdl:minimum>
                </jsdl:range>
              </jsdl:requirement>'."\n";
              $xml .= '</jsdl:properties>
          </jsdl:relatedResources>'."\n";
            }
         }
      }  // optimization
      elseif ($key == 'optimization') {
         switch ($requirement) {
            case "CPUUtilization" :
               $xml .= '<jsdl:optimization name="JPT_JSDLOptimizationPolicyType">
               <jsdl:objective propertyObjective="minimize" resourcePropertyName="CPUUtilization" resourceType="ComputerSystem"/>
               </jsdl:optimization>'."\n";
               break;
            case "HighestQuantity" :
               $xml .= '<jsdl:optimization name="JPT_BestResource">
               <jsdl:objective propertyObjective="maximize" resourcePropertyName="Quantity" resourceType="LogicalResource"/>
               </jsdl:optimization>'."\n";
               break;
            case "LowestQuantity" :
               $xml .= '<jsdl:optimization name="JPT_BestResource">
               <jsdl:objective propertyObjective="minimize" resourcePropertyName="Quantity" resourceType="LogicalResource"/>
               </jsdl:optimization>'."\n";
               break;
            case "HighestUtilization" :
               $xml .= '<jsdl:optimization name="JPT_BestResource">
               <jsdl:objective propertyObjective="maximizeUtilization" resourcePropertyName="Quantity" resourceType="LogicalResource"/>
               </jsdl:optimization>'."\n";
               break;
            case "LowestUtilization" :
               $xml .= '<jsdl:optimization name="JPT_BestResource">
               <jsdl:objective propertyObjective="minimizeUtilization" resourcePropertyName="Quantity" resourceType="LogicalResource"/>
               </jsdl:optimization>'."\n";
               break;
         }
      }
   }
   $xml .= '</jsdl:resourceRequirements>';
   return $xml;
}

?>
