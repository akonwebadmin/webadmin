<?php
//   HORIZONT Software GmbH, Munich
//
   $__tlogmode='APPEND';
   require_once 'tws_functions.php';

   if (defined('IWD_PROCMAN')) {
      $iwd_class='iwd_dbcal';
      $search_elems=array();
      $search=$iwd_class::get_search_elems($search_elems, 'ref');
   }

   tws_import_request_variables("P","rqst_");

   $fieldname=$rqst_fieldname;
   tws_check_elname($fieldname);
   $fieldvalue=tws_gpc_get($rqst_fieldvalue);   // don't use  'tws_mask' here!
   $allowmultiple=@$rqst_allowmultiple;
   $includeclasses=@$rqst_includeclasses;
   $includestock=@$rqst_includestock;
   $display="yes";

   if (!isset($fieldname)) {
      $fieldname="calendar";
   }
   if ((strpos($fieldname,"[") !== FALSE) && (strpos($fieldname,"]") !== FALSE)) {
      $jsfieldname="elements['" . $fieldname . "']";
   }
   else {
      $jsfieldname = $fieldname;
   }
?>
<script type="text/javascript">

function updateValue(val) {
   window.document.contents.<?=$jsfieldname ?>.value = val;
   $('[name="<?=$fieldname?>"]').keyup();
}

function sendValue(formsel) {
   var selectionval = "";
   for (var i = 0; i < formsel.options.length; i++)
      if (formsel.options[i].selected)
         selectionval = selectionval + formsel.options[i].value + ",";

   updateValue(selectionval.substr(0, selectionval.length - 1));
   $("#calendar_picker").dialog("close");
}
   <?php
      if (defined('IWD_PROCMAN')) {
         if (trim($fieldvalue)=='') {
            $fieldvalue=$search_elems[$iwd_class][0];
            echo "updateValue('".$fieldvalue."');\n";
         }
      }
   ?>
</script>

<div id="calendar_picker">

<h1>Select Calendar</h1>
<br>
<?php
   if ($fieldvalue == "") {
      $arg="@";
   } else {
      if ((strpos($fieldvalue,"*") === FALSE) && (strpos($fieldvalue,"@") === FALSE)) {
         $arg=$fieldvalue . "@";
      } elseif (strpos($fieldvalue,"*") !== FALSE) {
         $arg=strtr($fieldvalue,"*","@");
      } else {
         $arg=$fieldvalue;
      }
   }
   $select_options = '';
   if (defined('IWD_PROCMAN')) { //IWD/ProcMan
      $arg=strtr($arg,"@","*");
      if (($objs=$iwd_class::get_listing($arg, 'ref'))!==FALSE) {
         foreach($objs as $obj) {
            $select_options .= '<option value="'.$obj['rname'].'" '.(($obj['rname']==$fieldvalue) ? 'selected' : '').'>'.$obj['name'].' ('.$obj['version'].')</option>'."\n";
         }
      } else hwi_log_flush();
   }
   else { //IWS/WebAdmin
      if (($calendars = tws_get_calendars($arg)) === FALSE) {
         tws_warning('Unable to list calendars'); // print error message
      } else if (isset($calendars['calendar_name'])) {
         foreach($calendars['calendar_name'] as $i => $name) {
            $calendar_folder = $calendars['calendar_folder'][$i];
            $select_options .= '<option value="'.$calendar_folder.$name.'">'.$calendar_folder.$name.'</option>'."\n";
         }
      }
   }
?>
<form name="calendar_list" action="">

<select name="selection" size=14  class="picker" onDblClick="sendValue(this.form.selection);"<?php if ($allowmultiple == "yes") echo " multiple"; ?>>
<?php
   echo $select_options;
   if ($includestock != 'no') { ?>
<option value="*DAILY*">DAILY</option>
<option value="*WEEKLY*">WEEKLY</option>
<option value="*MONTLY*">MONTLY</option>
<option value="*YEARLY*">YEARLY</option>
<option value="*WORKDAY*">WORKDAY</option>
<option value="*FREEDAY*">FREEDAY</option>
   <?php } ?>
</select>
<br><br>
<center>
<input type="button" value="OK" onClick="sendValue(this.form.selection);">
</center>
</form>
</div>

<script type="text/javascript">

$(function() {
   tws_picker_constructor("calendar_picker");
});

</script>
