<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Add Run Cycle Group</title>
<?php
tws_stylesheet();
tws_show_backup();
?>
</head>
<body>
<?php tws_set_window_title(); ?>

<?php
   tws_check_synchro_token();  // synchro_token
   foreach ($_POST as $key => $val)
      $$key = tws_gpc_get($val);

   if (!empty($modify) && $modify == 'yes')
         if (!tws_permit_action('database_runcycles','Modify')) tws_access_denied ();
   else
         if (!tws_permit_action('database_runcycles','Add')) tws_access_denied ();

   if ($modify == "yes")
      $runcycle=$runcyclex;
   $runcycle=strtoupper($runcycle);
   if ($tws_config['cpuinfo']['version']>='9.5002'){
       $runcycle = $rcg_folder.$runcycle;
   }


   if ($action=="Cancel") {
      // Unlock the object
      tws_composer_unlock("rc=$runcycle") or tws_dyer("Unable to unlock runcycle '$runcycle'", "", "tws_runcyclesx.php");
      echo "<script type='text/javascript'>\n";
      echo "  window.location.replace(\"tws_runcyclesx.php\");\n";
      echo "</script>\n";
      exit;
   }
   elseif($action=="Return to Modification"){
      include("tws_add_runcycle.php");
      exit;
   }

// Check for existing runcycle
   $match=FALSE;
   if ($confirm != "yes") {
      if (($db_runcycle = tws_get_runcycles($runcycle)) === FALSE)
         tws_dyer("Unable to get runcycle group", "", "tws_runcyclesx.php");

      if ($db_runcycle['runcycle_num'] > 1)
         tws_dyer("Database query failed", "", "tws_runcyclesx.php");

      $exrcname = $db_runcycle['runcycle_name'][0];
      if ($tws_config['cpuinfo']['version']>='9.5002') $exrcname = $db_runcycle['rcg_folder'][0].$db_runcycle['runcycle_name'][0];
      if (($db_runcycle['runcycle_num'] == 1) && ($runcycle ==  $exrcname))
         $match = TRUE;

   }
      $cmd=Array();
      $cmd[]="RUNCYCLEGROUP $runcycle\n";
      if(!empty($rcg_description))
         $cmd[]=" DESCRIPTION \"$rcg_description\"\n";
      if(!empty($rcg_vat_name))
         $cmd[]=" VARTABLE ".$rcg_vat_name;
      if(!empty($rcg_calendar)){
         $tmp=" FREEDAYS ".$rcg_calendar;
         if(empty($rcg_sat_free)) $tmp .= " -SA ";
         if(empty($rcg_sun_free)) $tmp .= " -SU ";
         $cmd[] = $tmp;
      }



      // tws_get_rc_def_from_form() - function made from tws_add_jobstream_exec
      // gather RC definition from form fields
      $tmp = tws_get_rc_def_from_form();
      foreach($tmp as $val)
         $cmd[] = $val;

      $tmp = '';
      if(!empty($rcg_athour) && !empty($rcg_atminute)){
         if(!empty($rcg_time_dependent))
            $tmp = 'AT ';
         else $tmp = 'SCHEDTIME ';
         $tmp .= $rcg_athour.$rcg_atminute;
         if(!empty($rcg_atplusdays))
            $tmp .= " +$rcg_atplusdays DAYS";
      }
      if(!empty($rcg_untilhour) && !empty($rcg_untilminute)){
         $tmp .= " UNTIL $rcg_untilhour$rcg_untilminute";
         if(!empty($rcg_untilplusdays))
            $tmp .= " +$rcg_untilplusdays DAYS ";
         if($rcg_onuntil == 'C')
            $tmp .=  " ONUNTIL CONT ";
         elseif($rcg_onuntil == 'X')
            $tmp .=  " ONUNTIL CANC ";
      }
      if(!empty($rcg_deadlinehour) && !empty($rcg_deadlineminute)){
         $tmp .= " DEADLINE $rcg_deadlinehour$rcg_deadlineminute";
         if(!empty($rcg_deadlineplusdays))
            $tmp .= " +$rcg_deadlineplusdays DAYS";
      }
      if(!empty($tmp))
         $cmd[] = $tmp;

      $cmd[] = " END";

//       Confirmation Form
   if ($match == TRUE) {
      if ($modify == "yes")
         echo "<h1>Confirmation</h1>\n";
      else
         echo "<h1>Replace Run Cycle Group Confirmation</h1>\n";
      echo "<br><br>\n";
      echo "<h3>Confirm:</h3>\n";
      if ($modify != "yes")
         echo "&nbsp;&nbsp;<b>The Run Cycle Group entered already exists</b><br><br>\n";

      echo "<form method='post' name='confirm' action='tws_add_runcycle_exec.php'>\n";
      foreach ($cmd as $cmdline)
         echo htmlspecialchars($cmdline)."<br>";

      echo "<input type='hidden' name='confirm' value='yes'>\n";
      if (empty($original_data)) {
         //missing original data - this happens if user is adding job that already exists.
         if (($original_data=tws_composer_create_from("rv=$runcycle"))===FALSE)
            tws_err("Unable to get original data required to create backup.");
      }
      echo tws_create_hidden_inputs($_POST);
      echo "<input type='hidden' name='original_data' value='".htmlspecialchars($original_data)."'>\n";

      if (tws_zli_module_check () && isset ($netmodule_file))
          echo "<input type=\"hidden\" name=\"netmodule_file\" value=\"".htmlspecialchars($netmodule_file)."\">\n";

      echo "<br>\n";
      if (tws_rights(SAVEBACKUPS) && $original_data!=''){
         echo "<input type='hidden' name='backup' value='yes'>&nbsp;&nbsp;&nbsp;";
         echo "<label><input type='checkbox' name='backup' value='yes' checked disabled>&nbsp;Save Backup Copy</label>\n";
      }
      else
         echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label><input type='checkbox' name='backup' value='yes' ".($original_data!='' ? 'checked' : 'disabled').">&nbsp;Save Backup Copy</label>\n";
      echo "<br><br>\n";

      if ($modify == "yes") {
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' value='Update' name='action'>\n";
         echo "<input type='hidden' name='modify' value='yes'>\n";
         echo "<input type='hidden' name='runcyclex' value='".htmlspecialchars($runcycle)."'>\n";
      }
      else
         echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' value='Replace' name='action'>\n";

      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' name='action' value='Return to Modification'>\n";
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' name='action' value='Cancel'>\n";
      tws_print_synchro_token();   // synchro_token
      echo "</form>\n";
   }
   //       Confirmed
   else {
      if ($backup == "yes") {
         if (($bckfilename = tws_write_backup($original_data, "runcycle", $runcycle)) === FALSE)
            tws_dyer("Unable to write backup");
      }

      // unlock the object
      tws_composer_unlock("RC=$runcycle");

// Create random temporary filename
      $tmpfilename="$maestro_dir/webadmin/tmp/runcycle.".tws_rndstr().".tmp";
      $fp=fopen($tmpfilename,'w') or tws_dyer("Unable to create temporary file");
/*
      $cmd=Array();
      $cmd[]="RUNCYCLEGROUP $runcycle\n";
      // tws_get_rc_def_from_form() - function made from tws_add_jobstream_exec
      // gather RC definition from form fields
      $tmp = tws_get_rc_def_from_form();
      foreach($tmp as $val)
         $cmd[] = $val;
      unset($tmp);

      $cmd[] = 'END';
*/
      foreach ($cmd as $cmdline) {
         if (fwrite($fp,$cmdline."\n") < 0) {
            fclose($fp);
            tws_dyer("Unable to write temporary file '$tmpfilename'");
         }
      }
      fclose($fp);
      tws_chmod($tmpfilename,0644);

      if ($confirm == "yes") {
         $command=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "replace $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      } else {
         $command=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "add $tmpfilename", hwi_cmd::operator('2>&1',FALSE));
      }

      $stdout='';
      $ec_popen=tws_popen($command, $ec, $stdout, $stdout, "N");

      //testing for the AWSBIA288I Total objects updated: 0.
      //Note: This has been added on 2016-07 to fix the problem of composer updating
      //correctly objects but returning incorrect return codes (not 0 or 4)
      $not_updated=!preg_match('/AWSBIA288[^\n]+(\d+)/', $stdout, $_r) || $_r[1]==0;

      if ($ec_popen===FALSE || ($ec!=0 && $ec!=4 && $not_updated)) {
         if ($modify == "yes")
            echo "<h1>Modify Run Cycle Group Status</h1>\n";
         else
            echo "<h1>Add Run Cycle Group Status</h1>\n";

         tws_err("Run Cycle Group add/modify operation failed", array('twscmd'=>$command->compile('log'), 'stdout'=>$stdout, "EC_POPEN"=>$ec_popen, "EC_UPDATED"=>$ec, "NOT_UPDATED"=>tws_yesno($not_updated,'YES','NO')));
         echo "<form action='tws_add_runcycle_exec.php' method='post' onsubmit=\"if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Run Cycle',null)) { cancel_button_pressed=false; return false;}\">\n";
         echo tws_create_hidden_inputs($_POST);
         tws_print_synchro_token();
         echo "<input type='submit' name='action' value='Cancel' onClick='cancel_button_pressed=true;'/>\n";
         echo "<input type='submit' name='action' value='Return to Modification'/>\n";
         echo "</form>";
      }
      else {
         unlink($tmpfilename);
         if (preg_match("/warnings?\s[1-9]/i",$stdout)) {
             if ($modify == "yes")
                 $headertext="Modify Run Cycle";
             else
                 $headertext="Add Run Cycle";

            tws_err("The Run Cycle Group has been saved with the following warnings:", array('stdout'=>$stdout));
             $shortwarnfilename="warn.".tws_rndstr().".txt";
             $warnfilename="$webadmin_tmp_dir/$shortwarnfilename";
             $warnfp=fopen("$warnfilename","w") or tws_dyer("Unable to create warning text file", "Warning output :\n$stdout");
             if (fwrite($warnfp,"$stdout") < 0) {
                 fclose($warnfp);
                 unlink($warnfilename);
                 tws_dyer("Unable to write warning text file", "Warning output :\n$stdout");
            }
            fclose($warnfp);
            tws_dyer();
         }
         if ($backup == "yes") {
            if ($modify == "yes")
               echo "<h1>Modify Run Cycle Group Status</h1>\n";
            else
               echo "<h1>Add Run Cycle Group Status</h1>\n";

            echo "<p class='message'>\n";
            echo "Run Cycle Group has been successfuly saved.&nbsp;";
            $bckfilename = preg_replace("/\\\\/", '/', $bckfilename);
            $file = explode('/',$bckfilename);
            $file = end($file);
            if(tws_profile('auth_user_group')=='admin')
               echo "<a href=\"javascript:showBackup('$file')\">Display Backup File</a>\n";
            echo "</p>\n";
            echo "<input type='button' value='OK' onClick=\"closeme('tws_runcyclesx.php')\">\n";
         }
         else {
            echo "<script type='text/javascript'>\n";
            echo "   closeme('tws_runcyclesx.php');\n";
            echo "</script>\n";
         }
      }
   }
?>
</body>
</html>
