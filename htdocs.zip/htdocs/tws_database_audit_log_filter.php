<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   require_once 'tws_filters_lib.php';
   tws_doctype("t");

   $date_format=tws_profile('date_format');
?>
<html>
<head>
<title>Database Audit Log Filter</title>
<? tws_stylesheet();
   tws_get_filter_from_storage('tws_database_audit_log');
   $database_auditfilter=$_GET['arg'];
?>
<script type="text/javascript">

function CheckAll_auditlog_columns() {
 auditlog_columns = document.contents.elements['auditlog_columns[]'];
 for (i=0; i<auditlog_columns.length; i++) {
  auditlog_columns[i].checked=true;
 }
}
function ClearAll_auditlog_columns() {
 auditlog_columns = document.contents.elements['auditlog_columns[]'];
 for (i=0; i<auditlog_columns.length; i++) {
  auditlog_columns[i].checked=false;
 }
}
function CheckAll_logtypes() {
 log_types = document.contents.elements['log_types[]'];
 for (i=0; i<log_types.length; i++) {
  log_types[i].checked=true;
 }
}
function ClearAll_logtypes() {
 log_types = document.contents.elements['log_types[]'];
 for (i=0; i<log_types.length; i++) {
  log_types[i].checked=false;
 }
}
function CheckAll_objecttypes() {
 object_types = document.contents.elements['object_types[]'];
 for (i=0; i<object_types.length; i++) {
  object_types[i].checked=true;
 }
}
function ClearAll_objecttypes() {
 object_types = document.contents.elements['object_types[]'];
 for (i=0; i<object_types.length; i++) {
  object_types[i].checked=false;
 }
}

function y2k(number) { return (number < 1000) ? number + 1900 : number; }

var today = new Date();
var day   = today.getDate();
var month = today.getMonth();
var year  = y2k(today.getYear());
var element_name;
var month_obj;
var day_obj;
var year_obj;
var showselected = 'orange';
var showtoday = '#e0e0e0';

function padout(number) { return (number < 10) ? '0' + number : number; }

function restart() {
 month_obj.value = padout(month - 0 + 1);
 day_obj.value = padout(day);
 year_obj.value = year;
 $(day_obj).keyup();
 $(month_obj).keyup();
 $(year_obj).keyup();
 datewindow.close();
}

function dateWindow(element) {
 element_name = element;
 eval('month_obj = document.contents.' + element_name + '_month');
 eval('day_obj = document.contents.' + element_name + '_day');
 eval('year_obj = document.contents.' + element_name + '_year');
 datewindow=open('date_picker.html','date_picker','width=350,height=270,toolbar=no,menubar=no,location=no,scrollbars=no,resizable=no');
 datewindow.location.href = 'date_picker.html';
 if (datewindow.opener == null) datewindow.opener = self;
}
</script>
</head>
<body>
<?php tws_set_window_title();
   tws_print_head('Database Audit Log Filter');
?>
<br>
<div id='tabs'>
   <ul>
      <li><a href='#filter'>Set Filter</a></li>
      <li><a href='#load'>Load Filter</a></li>
   </ul>

<div id="filter">

<?php
   if (isset($database_auditfilter)) {
      $filterchunks=0;
      $tok=strtok($database_auditfilter,"+");
      $filterchunks++;
      $filterchunk[$filterchunks]=$tok;
      while ($tok=strtok("+")) {
         $filterchunks++;
         $filterchunk[$filterchunks]=$tok;
      }

      $null = null;
      for ($i=1; $i<=$filterchunks; $i++) {
         if (substr($filterchunk[$i],0,17) == "auditlog_columns=") {
            $junk=strtok($filterchunk[$i],"=");
            $auditlog_columns=explode(",",strtok("\n"));
         } elseif (substr($filterchunk[$i],0,10) == "log_types=") {
            $junk=strtok($filterchunk[$i],"=");
            $log_types=explode(",",strtok("\n"));
         } elseif (substr($filterchunk[$i],0,5) == "today") {
            $today=TRUE;
         } elseif (substr($filterchunk[$i],0,8) == "alldates") {
            $alldates=TRUE;
         } elseif (substr($filterchunk[$i],0,12) == "single_date=") {
            $junk=strtok($filterchunk[$i],"=");
            $single_date=strtok("\n");
            $single_date = tws_iso_to_userdate(substr($single_date,0,4).'-'.substr($single_date,4,2).'-'.substr($single_date,6,2), $null, true);
         } elseif (substr($filterchunk[$i],0,8) == "lowdate=") {
            $junk=strtok($filterchunk[$i],"=");
            $lowdate=strtok("\n");
            $lowdate = tws_iso_to_userdate(substr($lowdate,0,4).'-'.substr($lowdate,4,2).'-'.substr($lowdate,6,2), $null, true);
         } elseif (substr($filterchunk[$i],0,9) == "highdate=") {
            $junk=strtok($filterchunk[$i],"=");
            $highdate=strtok("\n");
            $highdate = tws_iso_to_userdate(substr($highdate,0,4).'-'.substr($highdate,4,2).'-'.substr($highdate,6,2), $null, true);
         } elseif (substr($filterchunk[$i],0,8) == "user_id=") {
            $junk=strtok($filterchunk[$i],"=");
            $user_id=strtok("\n");
         } elseif (substr($filterchunk[$i],0,15) == "framework_user=") {
            $junk=strtok($filterchunk[$i],"=");
            $framework_user=strtok("\n");
         } elseif (substr($filterchunk[$i],0,13) == "object_types=") {
            $junk=strtok($filterchunk[$i],"=");
            $object_types=explode(",",strtok("\n"));
         } elseif (substr($filterchunk[$i],0,12) == "object_name=") {
            $junk=strtok($filterchunk[$i],"=");
            $object_name=strtok("\n");
         } elseif (substr($filterchunk[$i],0,13) == "action_types=") {
            $junk=strtok($filterchunk[$i],"=");
            $action_types=explode(",",strtok("\n"));
         } elseif (substr($filterchunk[$i],0,12) == "workstation=") {
            $junk=strtok($filterchunk[$i],"=");
            $workstation=strtok("\n");
         } elseif (substr($filterchunk[$i],0,12) == "action_data=") {
            $junk=strtok($filterchunk[$i],"=");
            $action_data=strtok("\n");
         }
      }
   } else {
      $today=TRUE;
   }
?>

<form method=post name="contents" action="tws_database_audit_log_filter_action.php">
<table border='0' cellspacing='5'>

<tr>
<td class=standard ><h3>Criteria</h3></td><td></td>
</tr>

<tr>
<td class='standard'>&nbsp;&nbsp;<b>Date:</b></td>
<td class=standard>
<table border=0 cellspacing=0><tr><td>
   <select name='date' onchange='date_change(this);'>
      <option value='today' <?=($today ? 'selected':'')?>>Today</option>
      <option value='single_date' <?=($single_date ? 'selected':'')?>>Date</option>
      <option value='date_range' <?=($lowdate||$highdate ? 'selected':'')?>>Range</option>
   </select>
   </td><td>
   <div id='single_date_div' style='display: <?=($single_date ? 'block':'none')?>;'>
      &nbsp;<?=tws_datetime_picker('single_date',$single_date,'','',"'dropdown',false,'24',true,false,false");?>
   </div>
   <div id='date_range' style='display: <?=($lowdate||$highdate ? 'block':'none')?>;'>
   &nbsp;From: <?=tws_datetime_picker('lowdate',$lowdate,'','',"'dropdown',false,'24',true,false,false");?>
   &nbsp;To: <?=tws_datetime_picker('highdate',$highdate,'','',"'dropdown',false,'24',true,false,false");?>
   </div>
</td></tr>
</table>
<script type="text/javascript">
   function date_change(my){
      if(my.value=='today'){
         $('div#single_date_div').hide();
         $('div#date_range').hide();
      }
      else if(my.value=='single_date'){
         $('div#single_date_div').show();
         $('div#date_range').hide();
      }
      else if(my.value=='date_range'){
         $('div#single_date_div').hide();
         $('div#date_range').show();
      }
   }
</script>
</td>
</tr>

<tr>
<td class=standard>&nbsp;&nbsp;<b>Workstation:</b></td>
<td class=standard>
<input type="text" name="workstation" class="tws_mask" <?php if (isset($workstation)) echo "value=\"".htmlspecialchars($workstation)."\""; ?> size=16 maxlength=16>
&nbsp;&nbsp;<input type="button" name="workstation_list" onClick="tws_picker_open('workstation_picker.php', 'fieldname=workstation&amp;fieldvalue=' + document.contents.workstation.value);" value="List">
</td>
</tr>

<tr>
<td class=standard >&nbsp;&nbsp;<b>User:</b></td>
<td class=standard>
<input type="text" name="user_id" <?php if (isset($user_id)) echo "value=\"".htmlspecialchars($user_id)."\""; ?> size=16 maxlength=40>
</td>
</tr>

<tr>
<td class=standard >&nbsp;&nbsp;<b>Framework User:</b></td>
<td class=standard>
<input type="text" name="framework_user" <?php if (isset($framework_user)) echo "value=\"".htmlspecialchars($framework_user)."\""; ?> size=16 maxlength=40>
</td>
</tr>

<tr>
<td class=standard >&nbsp;&nbsp;<b>Object Name:</b></td>
<td class=standard>
<input type="text" name="object_name" class="tws_mask" <?php if (isset($object_name)) echo "value=\"".htmlspecialchars($object_name)."\""; ?> size=40 maxlength=80>
</td>
</tr>

<tr>
<td class=standard >&nbsp;&nbsp;<b>Action Data:</b></td>
<td class=standard>
<input type="text" name="action_data" <?php if (isset($action_data)) echo "value=\"".htmlspecialchars($action_data)."\""; ?> size=40 maxlength=80>
</td>
</tr>

<tr>
<td class='standard' >&nbsp;&nbsp;<b>Log Types:</b>
<div class='log_types_div'><br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="Javascript:CheckAll_logtypes();">Check All</a><br>&nbsp;&nbsp;&nbsp;&nbsp;<a href="Javascript:ClearAll_logtypes();">Clear All</a>
</div>
</td>
<td class=standard>
<label><input type="checkbox" id="log_types_all" <?=(empty($log_types) ? 'checked' : '')?> value="ALL"> <b>All</b></label>
<div class='log_types_div'>
<table border=0 cellspacing=0>
<tr>
<td class=standard nowrap><label><input type="checkbox" name="log_types[]" <? if (isset($log_types) && in_array("HEADER",$log_types)) echo "checked"; ?> value="HEADER">HEADER</label></td>
<td class=standard nowrap><label><input type="checkbox" name="log_types[]" <? if (isset($log_types) && in_array("CONMAN",$log_types)) echo "checked"; ?> value="CONMAN">CONMAN</label></td>
<td class=standard nowrap><label><input type="checkbox" name="log_types[]" <? if (isset($log_types) && in_array("FILEAID",$log_types)) echo "checked"; ?> value="FILEAID">FILEAID</label></td>
<td class=standard nowrap><label><input type="checkbox" name="log_types[]" <? if (isset($log_types) && in_array("PLAN",$log_types)) echo "checked"; ?> value="PLAN">PLAN</label></td>
</tr>
<tr>
<td class=standard nowrap><label><input type="checkbox" name="log_types[]" <? if (isset($log_types) && in_array("STAGEMAN",$log_types)) echo "checked"; ?> value="STAGEMAN">STAGEMAN</label></td>
<td class=standard nowrap><label><input type="checkbox" name="log_types[]" <? if (isset($log_types) && in_array("RELEASE",$log_types)) echo "checked"; ?> value="RELEASE">RELEASE</label></td>
<td class=standard nowrap><label><input type="checkbox" name="log_types[]" <? if (isset($log_types) && in_array("DATABASE",$log_types)) echo "checked"; ?> value="DATABASE">DATABASE</label></td>
<td class=standard nowrap><label><input type="checkbox" name="log_types[]" <? if (isset($log_types) && in_array("PARMS",$log_types)) echo "checked"; ?> value="PARMS">PARMS</label></td>
</tr>
<tr>
<td class=standard nowrap><label><input type="checkbox" name="log_types[]" <? if (isset($log_types) && in_array("MAKESEC",$log_types)) echo "checked"; ?> value="MAKESEC">MAKESEC</label></td>
<td class=standard nowrap><label><input type="checkbox" name="log_types[]" <? if (isset($log_types) && in_array("DBEXPAND",$log_types)) echo "checked"; ?> value="DBEXPAND">DBEXPAND</label></td>
</tr>
</table>
<br></div>
<script type="text/javascript">

   if($('input#log_types_all').is(':checked')){
      $('div.log_types_div').hide();
      $('input[name="log_types[]"]').attr('disabled', 'disabled');
   }
   $('input#log_types_all').on('click', function(){
      if($('input#log_types_all').is(':checked')){
         $('div.log_types_div').hide();
         $('input[name="log_types[]"]').attr('disabled', 'disabled');
      }
      else{
         $('input[name="log_types[]"]').attr('disabled', false);
         $('div.log_types_div').show();
      }
   });

</script>
</td>
</tr>

<tr>
<td class=standard >&nbsp;&nbsp;<b>Object Types:</b>
<div class='object_types_div'><br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="Javascript:CheckAll_objecttypes();">Check All</a><br>&nbsp;&nbsp;&nbsp;&nbsp;<a href="Javascript:ClearAll_objecttypes();">Clear All</a>
</div>
</td>
<td class=standard >
<label><input type="checkbox" id="object_types_all" <?=(empty($object_types) ? 'checked' : '')?> value="ALL"> <b>All</b></label>
<div class='object_types_div'>
<table border=0 cellspacing=0>
<tr>
<td class=standard nowrap><label><input type="checkbox" name="object_types[]" <? if (isset($object_types) && in_array("DATABASE",$object_types)) echo "checked"; ?> value="DATABASE">DATABASE</label></td>
<td class=standard nowrap><label><input type="checkbox" name="object_types[]" <? if (isset($object_types) && in_array("DBWKSTN",$object_types)) echo "checked"; ?> value="DBWKSTN">WORKSTATION</label></td>
<td class=standard nowrap><label><input type="checkbox" name="object_types[]" <? if (isset($object_types) && in_array("DBWKCLS",$object_types)) echo "checked"; ?> value="DBWKCLS">WORKSTATION CLASS</label></td>
<td class=standard nowrap><label><input type="checkbox" name="object_types[]" <? if (isset($object_types) && in_array("DBDOMAIN",$object_types)) echo "checked"; ?> value="DBDOMAIN">DOMAIN</label></td>
</tr>
<tr>
<td class=standard nowrap><label><input type="checkbox" name="object_types[]" <? if (isset($object_types) && in_array("DBUSER",$object_types)) echo "checked"; ?> value="DBUSER">USER</label></td>
<td class=standard nowrap><label><input type="checkbox" name="object_types[]" <? if (isset($object_types) && in_array("DBJBSTRM",$object_types)) echo "checked"; ?> value="DBJBSTRM">JOBSTREAM</label></td>
<td class=standard nowrap><label><input type="checkbox" name="object_types[]" <? if (isset($object_types) && in_array("DBJOB",$object_types)) echo "checked"; ?> value="DBJOB">JOB</label></td>
<td class=standard nowrap><label><input type="checkbox" name="object_types[]" <? if (isset($object_types) && in_array("DBCAL",$object_types)) echo "checked"; ?> value="DBCAL">CALENDAR</label></td>
</tr>
<tr>
<td class=standard nowrap><label><input type="checkbox" name="object_types[]" <? if (isset($object_types) && in_array("DBPROMPT",$object_types)) echo "checked"; ?> value="DBPROMPT">PROMPT</label></td>
<td class=standard nowrap><label><input type="checkbox" name="object_types[]" <? if (isset($object_types) && in_array("DBPARM",$object_types)) echo "checked"; ?> value="DBPARM">PARAMETER</label></td>
<td class=standard nowrap><label><input type="checkbox" name="object_types[]" <? if (isset($object_types) && in_array("DBRES",$object_types)) echo "checked"; ?> value="DBRES">RESOURCE</label></td>
<td class=standard nowrap><label><input type="checkbox" name="object_types[]" <? if (isset($object_types) && in_array("DBSEC",$object_types)) echo "checked"; ?> value="DBSEC">SECURITY</label></td>
</tr>
</table>
<br></div>
<script type="text/javascript">

   if($('input#object_types_all').is(':checked')){
      $('div.object_types_div').hide();
      $('input[name="object_types[]"]').attr('disabled', 'disabled');
   }
   $('input#object_types_all').on('click', function(){
      if($('input#object_types_all').is(':checked')){
         $('div.object_types_div').hide();
         $('input[name="object_types[]"]').attr('disabled', 'disabled');
      }
      else{
         $('input[name="object_types[]"]').attr('disabled', false);
         $('div.object_types_div').show();
      }
   });
</script>
</td>
</tr>

<tr>
<td class=standard >&nbsp;&nbsp;<b>Action Types:</b>
</td>
<td class=standard>
<label><input type="checkbox" id="action_types_all" <?=(empty($action_types) ? 'checked' : '')?> value="ALL"> <b>All</b></label>
<div class='action_types_div'>
<table border=0 cellspacing=0>
<tr>
<td class=standard nowrap><label><input type="checkbox" name="action_types[]" <?php if (isset($action_types)) { if (in_array("ADD",$action_types)) echo "checked"; } ?> value="ADD">ADD</label></td>
<td class=standard nowrap><label><input type="checkbox" name="action_types[]" <?php if (isset($action_types)) { if (in_array("DELETE",$action_types)) echo "checked"; } ?> value="DELETE">DELETE</label></td>
<td class=standard nowrap><label><input type="checkbox" name="action_types[]" <?php if (isset($action_types)) { if (in_array("MODIFY",$action_types)) echo "checked"; } ?> value="MODIFY">MODIFY</label></td>
<td class=standard nowrap><label><input type="checkbox" name="action_types[]" <?php if (isset($action_types)) { if (in_array("EXPAND",$action_types)) echo "checked"; } ?> value="EXPAND">EXPAND</label></td>
<td class=standard nowrap><label><input type="checkbox" name="action_types[]" <?php if (isset($action_types)) { if (in_array("INSTALL",$action_types)) echo "checked"; } ?> value="INSTALL">INSTALL</label></td>
</tr>
</table>
</div>
<script type="text/javascript">

   if($('input#action_types_all').is(':checked')){
      $('div.action_types_div').hide();
      $('input[name="action_types[]"]').attr('disabled', 'disabled');
   }
   $('input#action_types_all').on('click', function(){
      if($('input#action_types_all').is(':checked')){
         $('div.action_types_div').hide();
         $('input[name="action_types[]"]').attr('disabled', 'disabled');
      }
      else{
         $('input[name="action_types[]"]').attr('disabled', false);
         $('div.action_types_div').show();
      }
   });
</script>
</td>
</tr>

<tr>
<td class=standard><h3>Content</h3></td><td></td>
</tr>

<tr>
<td class=standard >&nbsp;&nbsp;<b>Columns:</b>
<div class='columns_div'><br>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="Javascript:CheckAll_auditlog_columns();">Check All</a><br>&nbsp;&nbsp;&nbsp;&nbsp;<a href="Javascript:ClearAll_auditlog_columns();">Clear All</a>
</div>
</td>
<td class=standard>
<label><input type="checkbox" id="columns_all" <?=(empty($auditlog_columns) ? 'checked' : '')?> value="ALL"> <b>All</b></label>
<div class='columns_div'>
<table border=0 cellspacing=0>
<tr>
<td class=standard nowrap><label><input type="checkbox" name="auditlog_columns[]" <? if (isset($auditlog_columns) && in_array("log_type",$auditlog_columns)) echo "checked"; ?> value="log_type">Log Type</label></td>
<td class=standard nowrap><label><input type="checkbox" name="auditlog_columns[]" <? if (isset($auditlog_columns) && in_array("timestamp",$auditlog_columns)) echo "checked"; ?> value="timestamp">Timestamp</label></td>
<td class=standard nowrap><label><input type="checkbox" name="auditlog_columns[]" <? if (isset($auditlog_columns) && in_array("user_id",$auditlog_columns)) echo "checked"; ?> value="user_id">User ID</label></td>
<td class=standard nowrap><label><input type="checkbox" name="auditlog_columns[]" <? if (isset($auditlog_columns) && in_array("framework_user",$auditlog_columns)) echo "checked"; ?> value="framework_user">Framework User</label></td>
</tr>
<tr>
<td class=standard nowrap><label><input type="checkbox" name="auditlog_columns[]" <? if (isset($auditlog_columns) && in_array("object_type",$auditlog_columns)) echo "checked"; ?> value="object_type">Object Type</label></td>
<td class=standard nowrap><label><input type="checkbox" name="auditlog_columns[]" <? if (isset($auditlog_columns) && in_array("object_name",$auditlog_columns)) echo "checked"; ?> value="object_name">Object Name</label></td>
<td class=standard nowrap><label><input type="checkbox" name="auditlog_columns[]" <? if (isset($auditlog_columns) && in_array("action_type",$auditlog_columns)) echo "checked"; ?> value="action_type">Action Type</label></td>
<td class=standard nowrap><label><input type="checkbox" name="auditlog_columns[]" <? if (isset($auditlog_columns) && in_array("workstation",$auditlog_columns)) echo "checked"; ?> value="workstation">Workstation</label></td>
</tr>
<tr>
<td class=standard nowrap><label><input type="checkbox" name="auditlog_columns[]" <?php if (isset($auditlog_columns)) { if (in_array("action_data",$auditlog_columns)) echo "checked"; } ?> value="action_data">Action Data</label></td>
</tr>
</table>
</div>
<script type="text/javascript">

   if($('input#columns_all').is(':checked')){
      $('div.columns_div').hide();
      $('input[name="auditlog_columns[]"]').attr('disabled', 'disabled');
   }
   $('input#columns_all').on('click', function(){
      if($('input#columns_all').is(':checked')){
         $('div.columns_div').hide();
         $('input[name="auditlog_columns[]"]').prop( "checked", false );
         $('input[name="auditlog_columns[]"]').attr('disabled', 'disabled');
      }
      else{
         $('input[name="auditlog_columns[]"]').attr('disabled', false);
         $('input[name="auditlog_columns[]"]').prop( "checked", true );
         $('div.columns_div').show();
      }
   });
</script>
</td>
</tr>

</table>
<br><br>

<input type="submit" value="Set Filter" name="action" onclick='return tws_validate_form();'>
&nbsp;&nbsp;&nbsp;<input type="submit" value="Clear Filter" name="action">
&nbsp;&nbsp;&nbsp;<input type="submit" value="Save Filter" name="action" onclick='return tws_validate_form();'>
&nbsp;&nbsp;&nbsp;<input type="submit" value="Reset Filter" name="action">
<?php if(@$_GET['edit_file']!='') echo "<input type=\"hidden\" name=\"edit_file\" value=\"".htmlspecialchars($_GET['edit_file'])."\">\n";?>
</form>
</div>
<div id="load">
<?
   $object='database_audit';
   include "tws_load_filter.php";
?>
</div>
</div>

<script>
$(function() {
   $('#tabs').tabs();
   $('#tabs').css('background-color','inherit');
   $('#tabs').css('border','none 0px');
   $('#tabs ul').css('font-size', '140%');
});
</script>

</body>
</html>