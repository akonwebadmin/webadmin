<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");

   $db_parameter = array();

   // Cancel button test
   $tmp_test = (isset($_POST['action']) && $_POST['action'] == 'Return to Modification') ? true : false;
   if ($tmp_test == true){
      $db_parameter = tws_form_to_arr('parameter', $_POST);
      if(!empty($_POST['copy']))
         $copy = "yes";
      elseif(!empty($_POST['modify']))
         $modify = "yes";
   }
   if ($copy == "yes") {
      $h1 = "Copy Parameter";
      $action = 'copy';
   }
   elseif($modify == "yes"){
      $h1 = "Modify Parameter";
      $action = 'modify';
   }
   elseif($display == "yes"){
      $h1 = "Display Parameter";
      $action = 'display';
   }
   else{
      $h1 = "Add Parameter";
      $action = 'add';
   }
?>
<html>
<head>
<title><?=$h1 ?></title>
<?php tws_stylesheet(); ?>
<script type="text/javascript">
function ConfirmCancel(objectname,url){
   $('form').unbind('submit');
   var conftext=confirm("Exit " + objectname + " Definition (Changes will be lost) ?");
   if (conftext) {
      if (url==null) return true;
      closeme(url);
   } else {
      return false;
   }
}
</script>
</head>
<body>
<? tws_set_window_title();

   if ($tmp_test == false && ($copy == "yes" || $modify == "yes")) {

      $num_elements=count($selection);
      if ($num_elements == 0)
         tws_dyer("No parameter selected");
      elseif ($num_elements > 1)
         tws_dyer("Multiple parameters selected. Only one parameter can be copied at a time");

      if ($modify=="yes") {
         //lock object
         tws_composer_lock("parm=$selection[0]") or tws_dyer("Unable to lock parameter '$selection[0]'");
         //backup
         if (($original_data=tws_composer_create_from("parm=$selection[0]"))===FALSE)
            tws_dyer("Unable to create backup");
      }
      $db_parameter = tws_dbobject_to_array('parameter', $selection[0]);
   }
   tws_print_head($h1);

?>

<br><br>
<form method=post name="contents" action="tws_add_parameter_exec.php" onsubmit="if (typeof(cancel_button_pressed)!='undefined' && cancel_button_pressed && !ConfirmCancel('Parameter',null)) { cancel_button_pressed=false; return false;}">

<?
tws_arr_to_form('parameter', $action, $db_parameter);
?>

<br><br>
<?
   if ($modify == "yes") {
      echo "<input type='hidden' name='modify' value='yes'>\n";
      echo "<input type='hidden' name='original_data' value='".htmlspecialchars($original_data)."'>\n";
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' name='action' value='Update' onClick='return tws_validate_form()'>\n";
   }
   else
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' name='action' value='Add' onClick='return tws_validate_form()'>\n";

   if ($modify=="yes")
      echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' name='action' value='Cancel' onClick='cancel_button_pressed=true;'>\n";
   else
      echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' value='Cancel' onClick=\"ConfirmCancel('Parameter','tws_parametersx.php')\">\n";

   tws_print_synchro_token();   // synchro token
?>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" value="Print" onClick="window.print()">
</form>
</body>
</html>
