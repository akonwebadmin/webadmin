<?php
/*
echo"SCHEDULE PC106#MASS0 
:<br>";
for($i=0; $i<5; $i++){
   echo"PC106#MASS_job$i ";
   if($i>0)
      echo"FOLLOWS MASS_job".($i-1)."<br>";
}
echo"END";
*/

for($i=0; $i<500; $i++){
   echo"SCHEDULE PC106#MASS$i<br>
      FOLLOWS PC106#MASS".($i-1).".@<br>
      FOLLOWS PC106#MASS".($i-1).".MASS_JOB".(($i-1)*5)."<br>
      :<br>";
      for($j=0; $j<5; $j++){
         echo"PC106#MASS_JOB".($i*5+$j)."<br>";
            echo"FOLLOWS PC106#MASS".($i-1).".@<br>";   
            echo"FOLLOWS PC106#MASS".($i-1).".MASS_JOB".(($i-1)*5)."<br>";
            echo"FOLLOWS PC106#MASS".($i-1).".MASS_JOB".(($i-1)*5+1)."<br>";
            echo"FOLLOWS PC106#MASS".($i-1).".MASS_JOB".(($i-1)*5+2)."<br>";
            echo"FOLLOWS PC106#MASS".($i-1).".MASS_JOB".(($i-1)*5+3)."<br>";
            echo"FOLLOWS PC106#MASS".($i-1).".MASS_JOB".(($i-1)*5+4)."<br>";
      /*  INTERNAL
         $follows = $i*5+$j-1;
         if($j>0)
            echo"FOLLOWS MASS_JOB$follows<br>";
      */
      }
echo"END<br><br>";
}
/*
SCHEDULE PC106#MASS$i 
:
END
"

SCHEDULE PC106#DEMO_TEST1 VALIDFROM 08/12/2008 
DESCRIPTION "Just a test schedule 1"
ON RUNCYCLE RULE1 "FREQ=DAILY;"
AT 1600 DEADLINE 1720 
CARRYFORWARD
:
PC106#SLEEP120
PC106#ALTPRI
 FOLLOWS ALTPASS


PC106#MASS_job'.$i.' 
 DOCOMMAND "set"
 STREAMLOGON tws94
  TASKTYPE UNIX
 RECOVERY STOP
<br>'."\n";
*/
?>