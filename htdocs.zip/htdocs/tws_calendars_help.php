<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');
?>
<html>
<head>
   <title>Calendar Definitions Help</title>
   <?php tws_stylesheet(); ?>
</head>
<body class=help>
<?php
   tws_set_window_title();
   include 'tws_help_topbar.php';
?>
<h1 class=help>Calendar Definitions Help</h1>
<p>The Calendar Definitions List displays a list of calendars in the IWS database.
<h2 class=help>Display Format</h2>
<p><strong>Calendar</strong> : Calendar name
<p><strong>Description</strong> : Text description of the calendar
<h2 class=help>Actions</h2>
<p>Use the buttons located at the bottom of the Calendar Definitions List to perform actions. Calendars may be selected by checking the check-boxes in the far left column of the calendars table. Multiple calendars can be selected.
<p><strong>Display</strong> : Display the text definition of the selected calendar(s)
<p><strong>Add</strong> : Add a new calendar
<p><strong>Copy</strong> : Copy the selected calendar
<p><strong>Modify</strong> : Modify the selected calendar
<p><strong>Text Edit</strong> : Modify the selected calendar(s) in text mode
<p><strong>Delete</strong> : Delete the selected calendar(s)
<p><strong>Unlock</strong> : Unlock the selected calendar(s)
<p><strong>Dependent Objects</strong> : Display a cross-reference report showing a list of IWS jobstreams that use the selected calendar(s)
<p><strong>Filter</strong> : Set and apply filter for Calendar Definitions List. Selections are ignored when using this action.
<p><strong>Save Filter</strong> : Save the current Calendar Definitions List filter setting. Available only when a filter is set. Selections are ignored when using this action.
<p><strong>Print</strong> : Print the current page. Selections are ignored when using this action.
</body>
</html>
