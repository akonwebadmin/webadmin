<?php
//   HORIZONT Software GmbH, Munich
//

   require_once "tws_functions.php";
   tws_doctype("t");
?>
<html>
<head>
<title>Change IWS/WebAdmin Password</title>
<?php tws_stylesheet(); ?>
</head>
<body>
<?php tws_set_window_title(); ?>
<h1>Change IWS/WebAdmin Password</h1>
<br><br>

<?php
   if (!tws_rights(CHANGEPASSWORD)) {
      tws_dyer("IWS/WebAdmin: Permission Denied");
   }

   if (file_exists("$base_inst_dir/etc/authconf.php")) {
      include("$base_inst_dir/etc/authconf.php");
      if ($authtype == "os") {
         echo "<p class=warning><font color=\"#800000\">The IWS/WebAdmin Authentication Method is set to <b>Operating System</b>.  When using this authentication method, IWS/WebAdmin uses operating system user IDs and passwords. Therefore, users must change their passwords using the normal operating system facilities instead of this page.</font></p>\n<br>\n";
      }
   }

   tws_nossl_warning();
?>
Changing password for user <b><?php echo htmlspecialchars(tws_profile('auth_user_name')); ?></b>
<br/><br/>
<form method="post" action="tws_change_password_exec.php">
<table border="0" cellspacing="0">
<tr>
   <td class="standard" width="150">&nbsp;&nbsp;New Password:</td>
   <td class="standard"><input type="password" name="password" size="20" maxlength="40" autocomplete="off" /></td>
</tr>
<tr>
   <td class="standard" width="150">&nbsp;&nbsp;Confirm Password:</td>
   <td class="standard"><input type="password" name="confirm_password" size="20" maxlength="40" autocomplete="off" /></td>
</tr>
</table>
<br/><br/>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Set Password" name="action">
<?php
   tws_print_synchro_token();
?>
</form>
</body>
</html>
