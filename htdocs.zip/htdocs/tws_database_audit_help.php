<?php
//   HORIZONT Software GmbH, Munich
//

   require_once 'tws_functions.php';
   tws_doctype('t');
?>
<html>
<head>
   <title>IWS Database Audit Log Help</title>
   <?php tws_stylesheet(); ?>
</head>
<body class=help>
<?php
   tws_set_window_title();
   include 'tws_help_topbar.php';
?>
<h1 class=help>IWS Database Audit Log Help</h1>
<p>The IWS/WebAdmin Database Audit Log viewer displays IWS Database audit log entries in a table format that allows customization and filtering. Auditing must be enabled in the IWS globalopts file in order for the IWS/WebAdmin audit log viewers to function.
<p>The Database Audit Log tracks changes made to IWS object definitions (composer / mozart).
<p>By default, the IWS/WebAdmin Database Audit Log displays entries for the current day.
<h2 class=help>Columns</h2>
<p><strong>Log Type</strong> : Record Type:
<ul>
  <li><strong>HEADER</strong></li>
  <li><strong>CONMAN</strong></li>
  <li><strong>FILEAID</strong></li>
  <li><strong>PLAN</strong></li>
  <li><strong>STAGEMAN</strong></li>
  <li><strong>RELEASE</strong></li>
  <li><strong>DATABASE</strong></li>
  <li><strong>PARMS</strong></li>
  <li><strong>MAKESEC</strong></li>
  <li><strong>DBEXPAND</strong></li>
</ul>
<p><strong>Timestamp</strong> : Date and time of the audit log entry.
<p><strong>User ID</strong> : User that performed the action (via command line, legacy GUI, or IWS/WebAdmin)
<p><strong>Framework User</strong> : Tivoli Framework Administrator that performed the action (via Job Scheduling Console)
<p><strong>Object Type</strong> : Object type that was changed:
<ul>
  <li><strong>DATABASE</strong> : Database definition</li>
  <li><strong>DBWKSTN</strong> : Database workstation definition</li>
  <li><strong>DBWKCLS</strong> : Database workstation class definition</li>
  <li><strong>DBDOMAIN</strong> : Database domain definition</li>
  <li><strong>DBUSER</strong> : Database user definition</li>
  <li><strong>DBJBSTRM</strong> : Database job stream definition</li>
  <li><strong>DBJOB</strong> : Database job definition</li>
  <li><strong>DBCAL</strong> : Database calendar definition</li>
  <li><strong>DBPROMPT</strong> : Database prompt definition</li>
  <li><strong>DBPARM</strong> : Database parameter definition</li>
  <li><strong>DBRES</strong> : Database resource definition</li>
  <li><strong>DBSEC</strong> : Database security</li>
</ul>
<p><strong>Object Name</strong> : Name of the object that was changed.
<p><strong>Action Type</strong> : Type of action that was performed:
<ul>
  <li><strong>ADD</strong> : An object was added to the database</li>
  <li><strong>DELETE</strong> : An object was deleted from the database</li>
  <li><strong>MODIFY</strong> : An object was modified</li>
  <li><strong>EXPAND</strong> : Database was expanded using dbexpand</li>
  <li><strong>INSTALL</strong> : Security file was installed using makesec</li>
</ul>
<p><strong>Workstation</strong> : Name of the workstation where the action was performed (usually the IWS master domain manager)
<p><strong>Action Data</strong> : Audit log record details
<h2 class=help>Actions</h2>
<p><strong>Filter</strong> : Choose columns and set the filter for the Database Audit Log. The date range to display is also set with the filter.
<p><strong>Send CSV File</strong> : Send the currently displayed audit log records as a CSV file that can be read by Microsoft Excel and other applications.
<p><strong>Print</strong> : Print the current page.
</body>
</html>
