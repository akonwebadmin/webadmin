<?php
//   HORIZONT Software GmbH, Munich
//

   $col[1]=2;
   $len[1]=17;
   $col[2]=19;
   $len[2]=17;
   $col[3]=37;
   $len[3]=16;

   $col[4]=37; //type in ;info
   $len[4]=16;
?>