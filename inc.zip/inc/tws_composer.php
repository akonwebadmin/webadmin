<?php
//   HORIZONT Software GmbH, Munich
//

///////////////////////////////////////////////////////////////////////////////
//
// List of workstations
//
// Arguments:
//    workstation = workstation name (@=wildcard for all)
//    sqlcond = sql filteri - conditions of the where clause
//
function tws_get_workstations($workstation='@', $sqlfilter='', $page_size = 0, $page = 1, $od_callback=null, $action='LIST') {
   global $tws_config, $composer_db;
   tws_log('-- tws_get_workstations (start at '.basename(__FILE__).'['.__LINE__.'])');
   tws_log("-- tws_get_workstations Params: workstation = $workstation, sqlfilter = $sqlfilter");

   if(trim($sqlfilter)=='') $sqlfilter="1=1";

   $workstations=array();
   $ws = array();
   $workstations['workstation_num']=0;
   $ws['workstation_num']=0;
   $oc=($od_callback!==null);

   if ($tws_config['cpuinfo']['version']>='9.5002'){
      list($wks_folder, $workstation) = tws_divide_folder($workstation);
      if(empty($wks_folder))
         $wks_folder = '/@/';
      tws_log("-- tws_get_workstations: wks_folder = $wks_folder, workstation = $workstation");
   }

//access rights checking
   if (($acc_sql=tws_sec_check('CPU', array('CPU'=>'WKS_NAME', 'TYPE'=>'WKS_AGENT_TYPE'), '', $action))===FALSE) return $workstations;

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if (!$dbh) {
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }

   $schema=$composer_db["schema"];
   $query ="
       SELECT
         WKC_ID,
         WKS_NAME,
         WKS_MODIFY_OWNER,
         WKS_MODIFY_TIME,
         WKS_AGENT_TYPE,
         DOM_NAME,
         WKS_LOCK_OWNER LO,
         WKS_LOCK_TIME  LT,
         WKS_DESCRIPTION,
         WKS_OPERATING_SYSTEM,
         WKS_INCLUDE_IN_PLAN,
         WKS.WKS_ACCESS_METHOD";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= ",
          WS_FOL.FOL_PATH WS_FOL_PATH";
      $query .= "
      FROM
         $schema.WKS_WORKSTATIONS WKS LEFT JOIN $schema.DOM_DOMAINS DOM ON WKS.DOM_ID=DOM.DOM_ID ";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
            LEFT JOIN $schema.FOL_FOLDERS WS_FOL ON WS_FOL.FOL_ID = WKS.FOL_ID";
      $query .= "
      WHERE
         WKS_NAME ".tws_sqllike(db_string($composer_db, $workstation)).
         "
         AND $sqlfilter
         $acc_sql";

// !!! TODO:
/*
      if ($tws_config['cpuinfo']['version']>='9.5002')
      $query .= "
         AND FOL.FOL_PATH ".tws_sqllike(db_string($composer_db, $wks_folder));
 */
      $query .= "
         ORDER BY WKS_NAME";

   tws_log('-- tws_get_workstations: DB query: '.$query);
   if (!($r=db_query($composer_db,$query))) {
      tws_log('-- tws_get_workstations: Error: Database query failed');
      tws_error('', "-- tws_get_workstations: Database query failed");
      return FALSE;
   }
   $tl=tws_log();
   if ($page_size > 0) {
      $page_down = ($page - 1) * $page_size;
      $page_up = $page * $page_size;
   }
   while ($row = db_fetch_row($composer_db)) {
     tws_log("-- tws_get_workstations: row ". var_export($row, true));
      $ws['workstation_num']++;
      if ($page_size > 0) {
         if ($page_down >= $ws['workstation_num']) {
            while (($page_down > $ws['workstation_num']) && db_fetch_row($composer_db, null)) {
               $ws['workstation_num']++;
            }
            continue;
         }
         if ($page_up < $ws['workstation_num']) {
            while (($page_up < $ws['workstation_num']) && db_fetch_row($composer_db, null)) {
               $ws['workstation_num']++;
            }
            break;
         }
      }
      $workstations['workstation_id'          ] = $row['WKC_ID'];
      $workstations['workstation_name'        ] = $row['WKS_NAME'];
      $workstations['workstation_creator'     ] = $row['WKS_MODIFY_OWNER'];
      $workstations['workstation_last_updated'] = $row['WKS_MODIFY_TIME'];
      $workstations['workstation_type'        ] = tws_typeval('WKS_AGENT_TYPE', $row['WKS_AGENT_TYPE']);
      $workstations['workstation_type_name'   ] = tws_typeval('WKS_AGENT_NAME', $row['WKS_AGENT_TYPE']);
      $workstations['workstation_domain'      ] = $row['DOM_NAME'];
      $workstations['workstation_lock_by'     ] = $row['LO'];
      $workstations['workstation_lock_on'     ] = $row['LT'];
      $workstations['workstation_description' ] = $row['WKS_DESCRIPTION'];
      $workstations['workstation_os'          ] = tws_typeval('WKS_OPERATING_SYSTEM', $row['WKS_OPERATING_SYSTEM']);
      $workstations['workstation_ignore'      ] = tws_yesno($row['WKS_INCLUDE_IN_PLAN'], '', 'YES');
      $workstations['workstation_method'      ] = @$row['WKS_ACCESS_METHOD'];
      if ($tws_config['cpuinfo']['version']>='9.5002'){
         $workstations['workstation_folder'] = $row['WS_FOL_PATH'];
             // $workstations['workstation_name'] = $row['FOL_PATH'].$workstations['workstation_name'];
      }

      if ($oc){
         $workstations['workstation_num']=$ws['workstation_num'];
         $od_callback($workstations);
      }
      else{
         foreach ($workstations as $key=>$val){
            if($key != 'workstation_num')
               $ws[$key][]=$val;
         }
      }
   }

   tws_log('-- get_db_workstations_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
   if (defined('IWD_PROCMAN')) return $ws; //procman::db_functions::db_fetch_row returns FALSE if there are no rows left
   return ($row===FALSE ? FALSE : $ws);
}


/// Get all workstation data.
/// The output structure should correspond to the add/copy/modify form
/// \param workstation Workstation name (accurate name)
function tws_get_workstation_data($workstation){
   global $tws_config, $composer_db;

   if ($workstation!='') {
      $dbh = db_connect($composer_db,DB_PERSISTENT);
      if( !$dbh ){
         tws_error('', 'Cannot connect to database');
         return FALSE;
   }
      $schema=$composer_db["schema"];

      // get the workstation data
      if ($tws_config['cpuinfo']['version']<'8.5') {
         $query="
            SELECT
               WKS.WKS_NAME,
               WKS.WKS_DESCRIPTION,
               WKS.WKS_OPERATING_SYSTEM,
               WKS.WKS_NODE_NAME,
               WKS.WKS_TCP_PORT,
               WKS.WKS_SSL_PORT,
               WKS.WKS_TIMEZONE_ID,
               DOM.DOM_NAME,
               WKS_HOST.WKS_NAME          HOST_NAME,
               WKS.WKS_MASTER_HOSTED,
               WKS.WKS_ACCESS_METHOD,
               WKS.WKS_AGENT_TYPE,
               WKS.WKS_INCLUDE_IN_PLAN,
               WKS.WKS_AUTOLINK,
               WKS.WKS_BEHIND_FIREWALL,
               WKS.WKS_SECURITY_LEVEL,
               WKS.WKS_FULL_STATUS,
               WKS.WKS_SERVER
            FROM
               (($schema.WKS_WORKSTATIONS WKS LEFT JOIN $schema.DOM_DOMAINS DOM ON WKS.DOM_ID=DOM.DOM_ID)
                 LEFT JOIN $schema.WKS_WORKSTATIONS WKS_HOST ON WKS.WKS_HOST_ID=WKS_HOST.WKC_ID)";
            if($tws_config['cpuinfo']['version']>='9.5002')
               $query .= "
                 LEFT JOIN $schema.FOL_FOLDERS HOST_FOL ON HOST_FOL.FOL_ID = HOST.FOL_ID = WKS_HOST.FOL_ID)";
            $query .= "
            WHERE
               WKS.WKS_NAME='".db_string($composer_db,$workstation)."'
         ";
      }
      else {
         list($wks_folder, $workstation) = tws_divide_folder($workstation);
         // if ($tws_config['cpuinfo']['version']>='9.5002')

         $query = "
            SELECT
               WKS.WKS_NAME,
               WKS.WKS_DESCRIPTION,
               WKS.WKS_OPERATING_SYSTEM,
               WKS.WKS_NODE_NAME,
               WKS.WKS_TCP_PORT,
               WKS.WKS_SSL_PORT,
               WKS.WKS_TIMEZONE_ID,
               DOM.DOM_NAME,
               WKS_HOST.WKS_NAME       HOST_NAME,
               WKS.WKS_MASTER_HOSTED,
               WKS.WKS_ACCESS_METHOD,
               WKS.WKS_AGENT_TYPE,
               WKS.WKS_INCLUDE_IN_PLAN,
               WKS.WKS_AUTOLINK,
               WKS.WKS_BEHIND_FIREWALL,
               WKS.WKS_SECURITY_LEVEL,
               WKS.WKS_FULL_STATUS,
               WKS.WKS_SERVER,
               VAT.VAT_NAME   VAT_NAME
               ".($tws_config['cpuinfo']['version']>=9.4 ? ',WKS.WKS_LICENSE_TYPE' : '');
               if ($tws_config['cpuinfo']['version']>='9.5002')
                  $query .= ",
               WS_FOL.FOL_PATH         WS_FOLDER,
               VAT_FOL.FOL_PATH        VAT_FOLDER,
               HOST_FOL.FOL_PATH       HOST_FOLDER";
            $query .= "
               FROM
               ((($schema.WKS_WORKSTATIONS WKS LEFT JOIN $schema.DOM_DOMAINS DOM ON WKS.DOM_ID=DOM.DOM_ID)
                  LEFT JOIN $schema.WKS_WORKSTATIONS WKS_HOST ON WKS.WKS_HOST_ID=WKS_HOST.WKC_ID)
                  LEFT JOIN $schema.VAT_VARIABLE_TABLES VAT ON WKS.VAT_ID=VAT.VAT_ID)";
            if ($tws_config['cpuinfo']['version']>='9.5002')
               $query .= "
                  LEFT JOIN $schema.FOL_FOLDERS WS_FOL ON WS_FOL.FOL_ID = WKS.FOL_ID
                  LEFT JOIN $schema.FOL_FOLDERS VAT_FOL ON VAT_FOL.FOL_ID = VAT.FOL_ID
                  LEFT JOIN $schema.FOL_FOLDERS HOST_FOL ON HOST_FOL.FOL_ID = WKS_HOST.FOL_ID";
            $query .= "
               WHERE
               WKS.WKS_NAME ='".db_string($composer_db, $workstation)."'";
            if ($tws_config['cpuinfo']['version']>='9.5002')
               $query .= "
               AND WS_FOL.FOL_PATH ".tws_sqllike(db_string($composer_db, $wks_folder));

      }
tws_log(" -- tws_get_workstation_data. query = $query");
      if (!($r=db_query($composer_db,$query))) {
         tws_error('', 'Database query failed');
         return FALSE;
      }
      $row = db_fetch_row( $composer_db );
   }
   $workstation_data=Array();
   if ($row || $workstation=='') {

      if(!empty($row['WS_FOLDER']))
         $workstation_data['workstation_folder'] = $row['WS_FOLDER'];
      else $workstation_data['workstation_folder'] = '';

      $workstation_data['workstation_name']=@$row['WKS_NAME'];
      $workstation_data['description']     =@$row['WKS_DESCRIPTION'];
      $workstation_data['os_type']         =@$row['WKS_OPERATING_SYSTEM'];
      $workstation_data['node']            =@$row['WKS_NODE_NAME'];
      $workstation_data['tcpaddr']         =@$row['WKS_TCP_PORT'];
      $workstation_data['secureaddr']      =@$row['WKS_SSL_PORT'];
      $workstation_data['domain']          =@$row['DOM_NAME'];
      $workstation_data['workstation_type']=@$row['WKS_AGENT_TYPE'];
      $workstation_data['time_zone']       =@$row['WKS_TIMEZONE_ID'];
      $workstation_data['ignore']          =tws_yesno(tws_neg(@$row['WKS_INCLUDE_IN_PLAN']));

      if(!empty($row['HOST_FOLDER']))
         $host_folder = $row['HOST_FOLDER'];
      else $host_folder = '';
      $workstation_data['host']            = $host_folder.$row['HOST_NAME'];

      if(tws_yesno(@$row['WKS_MASTER_HOSTED'])=='YES' && empty($workstation_data['host']))
         $workstation_data['host'] = '$MASTER';
      $workstation_data['method']          =@$row['WKS_ACCESS_METHOD'];
      $workstation_data['autolink']        =@$row['WKS_AUTOLINK'];
      $workstation_data['fullstatus']      =@$row['WKS_FULL_STATUS'];
      //$resolvedeps=$row['WKS_']; not in TWS8.3?
      $workstation_data['behindfirewall']  =@$row['WKS_BEHIND_FIREWALL'];
      $workstation_data['securitylevel']   =@$row['WKS_SECURITY_LEVEL'];
      $workstation_data['server']          =@$row['WKS_SERVER'];
      if ($tws_config['cpuinfo']['version']>='8.5')
         $workstation_data['parameter_table']     =@$row['VAT_NAME'];

      if ($tws_config['cpuinfo']['version']>='9.5002')
          $vartable_folder = $row['VAT_FOLDER'];
       else $vartable_folder = '';
       $workstation_data['parameter_table']  = $vartable_folder.$row['VAT_NAME'];

      if(isset($row['WKS_LICENSE_TYPE']))
         if($row['WKS_LICENSE_TYPE'] == 'S' || $row['WKS_LICENSE_TYPE'] == 'J')
            $workstation_data['license_type'] = $row['WKS_LICENSE_TYPE'];
         else $workstation_data['license_type'] = '';
   }
   // securitylevel == 'H' => Protocol='HTTP'; securitylevel == 'S' => Protocol='HTTPS'
   if($workstation_data['securitylevel'] == 'S' || $workstation_data['securitylevel']=='H')
      $workstation_data['securitylevel'] = '';
   if(isset($workstation_data['tcpaddr']) && $workstation_data['tcpaddr'] == 0)
      $workstation_data['tcpaddr'] = '';
   // for this types access_method contains agentID
   if($workstation_data['workstation_type'] == 'A' || $workstation_data['workstation_type'] == 'E' || $workstation_data['workstation_type'] == 'L' || $workstation_data['workstation_type'] == 'Y')
      $workstation_data['method'] = '';


   $sch_br=isset($composer_db['schema_broker']) ? $composer_db['schema_broker'] : ($composer_db['type']=='db2' ? 'DWB' : $composer_db['schema']);
   if($workstation_data['workstation_type'] == 'L') {    // PooL
      $workstation_data['members'] = "";
      $workstation_data['node']='';
      $workstation_data['tcpaddr']='';
      $members = array();
      $query = "
      SELECT WKS_NAME FROM $schema.WKS_WORKSTATIONS WHERE WKS_ACCESS_METHOD IN
      (  SELECT  CSR.CSR_NAME
         FROM    $sch_br.ARE_ABSTRACT_RESOURCES ARE,
                 $sch_br.REL_RESOURCE_DEPS REL,
                 $sch_br.CSR_COMPUTER_SYSTEM_RESOURCES CSR,
                 $schema.WKS_WORKSTATIONS WKS
         WHERE   CSR.ARE_ID = REL.ARE_TARGET_ID AND
                 REL.ARE_SOURCE_ID = ARE.ARE_ID AND
                 WKS.WKS_NAME = '".$workstation_data['workstation_name']."' AND
                 WKS.WKS_ACCESS_METHOD = ARE.ARE_NAME);
      ";
      if (!($r=db_query($composer_db,$query))) {
         tws_error('', 'Database query failed');
         return FALSE;
      }
      while( $row = db_fetch_row( $composer_db )) {
         $members[] = $row['WKS_NAME'];
      }
      $workstation_data['members'] = $members;
   }
   elseif($workstation_data['workstation_type'] == 'Y'){    // Dynamic Pool
      $workstation_data['requirements'] = "";
      $workstation_data['node']='';
      $workstation_data['tcpaddr']='';
      $query = "
         SELECT RER.RER_JSDL
         FROM  $sch_br.RER_RESOURCE_REQUIREMENTS RER,
               $schema.WKS_WORKSTATIONS WKS
         WHERE WKS.WKS_NAME = '$workstation_data[workstation_name]' AND
               WKS.WKS_ACCESS_METHOD = RER.RER_NAME;
      ";
      if (!($r=db_query($composer_db,$query))) {
         tws_error('', 'Database query failed');
         return FALSE;
      }
      if( $row = db_fetch_row( $composer_db ) ) {
         $workstation_data['requirements'] = $row['RER_JSDL'];
      }
   }
   return $workstation_data;
}
/**
 * get variable table with its folder for IWD 9.5.0.2
 * @param array $db
 * @param int $vartab_id - binary key to VAT_VARIABLE table
 * @return boolean|(array
 */
function tws_get_vartable_folder($db, $vartab_id) {
    global $composer_db;
    if(is_null($vartab_id)){
        return false;
    }
    tws_log(__FUNCTION__. " start");
    if( !$db)
        $db= db_connect($composer_db,DB_PERSISTENT);
    $schema=$composer_db["schema"];
    $sql = "SELECT
    VAT_ID,
    VAT_NAME,
    FOL.FOL_PATH
    FROM
    $schema.VAT_VARIABLE_TABLES
    LEFT JOIN $schema.FOL_FOLDERS FOL ON FOL.FOL_ID = $schema.VAT_VARIABLE_TABLES.FOL_ID
    WHERE
    VAT_ID = ? ";
    $stmt = new db_statement($db, $sql);
    if ($stmt->prepare() == FALSE) {
        unset($stmt);
        tws_error('', 'Database query prepare failed: ' . $query);
        return FALSE;
    }
    if ($stmt->execute(array($vartab_id)) !== false) {
        $stmt->fetch();
        $row = $stmt->row();
        tws_log(var_export($row, true));
        return $row;
    }
}



//**********************************
//    GET Requirements data from XML definition
//    for Dynamic Pools
//*********************************/
function tws_get_jsdl_requirements ($xmlstr) {
   $xml = new XMLReader();
      $xml->xml($xmlstr);
      $requirements = tws_xml2assoc($xml);
      $xml->close();
   $xmldata = array();
   if (is_array($requirements)) {
      $requirements = $requirements[0]['value'];
      foreach($requirements as $node){
         if (is_array($node['value'])) {
            // Resources
            if($node['tag'] == "jsdl:resources") {
               foreach($node['value'] as $value) {
                  // Candidate Operating Systems
                  if($value['tag'] == "jsdl:candidateOperatingSystems") {
                     $xmldata['candidateOperatingSystems'] = tws_get_req_candidateOperatingSystems($value['value']);
                  }
                  // CPU Utilization
                  elseif($value['tag'] == "jsdl:properties") {
                     if($value['value'][0]['tag'] == 'jsdl:requirement' &&  $value['value'][0]['attributes']['propertyName'] == 'CPUUtilization') {
                        $xmldata['CPUUtilization'] = tws_get_req_CPUUtilization ($value['value'][0]['value']);
                     }
                  }
                  // Candidated Workstations
                  elseif($value['tag'] == "jsdl:orderedCandidatedWorkstations") {
                     $xmldata['candidatedWorkstations'] = tws_get_req_candidatedWorkstations($value['value']);
                  }
                  // Reserved Resources
                  elseif($value['tag'] == "jsdl:logicalResource") {
                     $xmldata['reservedResources'][] = $value['attributes'];
                  }
               }
            }
            // Related Resources
            elseif($node['tag'] == "jsdl:relatedResources") {
               if($node['attributes']['type'] == 'LogicalResource' ){
                  $xmldata['relatedResources'][] = tws_get_req_relatedResources($node['value'][0]);
               }
            }
            // Optimization
            elseif($node['tag'] == "jsdl:optimization") {
               $xmldata['optimization'] = tws_get_req_optimization($node);
            }
         }
      }
   }
   return $xmldata;
}

function tws_get_req_candidateOperatingSystems($req) {
   $os = array();
   if(is_array($req)) {
      foreach ($req as $val) {
         if($val['tag']=='jsdl:operatingSystem') {
            $os[]=$val['attributes']['type'];
         }
      }
   }
   return $os;
}

function tws_get_req_CPUUtilization ($req) {
   $utilization=0;
   if(is_array($req)) {
      $req = $req[0];
      if($req['tag'] == 'jsdl:range' ) {
         $req = $req['value'];
         foreach($req as $range){
            if($range['tag'] == 'jsdl:maximum')
               $utilization = $range['value'];
         }
      }
   }
   return $utilization;
}

//  $req contains array of candidatedWorkstations ID
// return array of their names
function tws_get_req_candidatedWorkstations($req) {
   global $tws_config, $composer_db;
   $dbh = db_connect($composer_db, DB_PERSISTENT);
   if(!$dbh ){
      tws_err('Cannot connect to database');
      return FALSE;
   }
   $schema=$composer_db["schema"];
   $sch_br=isset($composer_db['schema_broker']) ? $composer_db['schema_broker'] : ($composer_db['type']=='db2' ? 'DWB' : $composer_db['schema']);
   $workstations = array();
   if(is_array($req)) {
      foreach($req as $ws){
         if($ws['tag'] == "jsdl:workstation"){
            $ws_id = $ws['value'];
            $query = "
            SELECT   WKS.WKS_NAME
            FROM  $schema.WKS_WORKSTATIONS WKS
            WHERE WKS.WKS_ACCESS_METHOD = '$ws_id'
            ";
            if (!($r=db_query($composer_db,$query))) {
               tws_error('', 'Database query failed');
               return FALSE;
            }
            $row = db_fetch_row( $composer_db );
            $workstations[] = $row['WKS_NAME'];
         }
      }
   }
   return $workstations;
}

function tws_get_req_optimization($req) {
   if($req['attributes']['name']=="JPT_JSDLOptimizationPolicyType" )
      return "CPUUtilization";
   elseif($req['attributes']['name']=="JPT_BestResource") {
      $req = $req['value'][0];
      if($req['attributes']['propertyObjective']=="maximizeUtilization")
         return"HighestUtilization";
      elseif($req['attributes']['propertyObjective']=="minimizeUtilization")
         return"LowestUtilization";
      elseif($req['attributes']['propertyObjective']=="maximize")
         return"HighestQuantity";
      elseif($req['attributes']['propertyObjective']=="minimize")
         return"LowestQuantity";
   }
   return "WorkloadBalance";
}

function tws_get_req_relatedResources($req) {
   $resources = array();
   if($req['tag'] == 'jsdl:properties' ) {
      $req = $req['value'];
      foreach($req as $requirement) {
         if($requirement['tag']== 'jsdl:requirement') {
            $propertyName = $requirement['attributes']['propertyName'];
            $property = $requirement['value'][0];
            if(is_array($property['value'])) {
               $resources[$propertyName] = $property['value'][0]['value'];
            }
            else {
               $resources[$propertyName] = $property['value'];
            }
         }
      }
   }
   return $resources;
}

// return available members for pool or candidatedWorkstations
function tws_get_available_members() {
   global $tws_config, $composer_db;
   $dbh = db_connect($composer_db, DB_PERSISTENT);
   if(!$dbh ){
      tws_err('Cannot connect to database');
      return FALSE;
   }

   $schema=$composer_db["schema"];
   $sch_br=isset($composer_db['schema_broker']) ? $composer_db['schema_broker'] : ($composer_db['type']=='db2' ? 'DWB' : $composer_db['schema']);
   $query = "
      SELECT   WKS.WKS_NAME
      FROM  $sch_br.CSR_COMPUTER_SYSTEM_RESOURCES CSR,
            $schema.WKS_WORKSTATIONS WKS
      WHERE CSR.CSR_NAME = WKS.WKS_ACCESS_METHOD";
   if (!($r=db_query($composer_db,$query))) {
      tws_err('Database query failed');
      return FALSE;
   }
   $members = array();
   while( $row = db_fetch_row( $composer_db )) {
      $members[] = $row['WKS_NAME'];
   }
   return $members;
}

// return available logical resources for Dynamic Pool
function tws_get_req_availableResources() {
   global $tws_config, $composer_db;
   $dbh = db_connect($composer_db, DB_PERSISTENT);
   if(!$dbh ){
      tws_err('Cannot connect to database');
      return FALSE;
   }
   $schema=$composer_db["schema"];
   $sch_br=isset($composer_db['schema_broker']) ? $composer_db['schema_broker'] : ($composer_db['type']=='db2' ? 'DWB' : $composer_db['schema']);
   // Select all logical resources
   $query = "
      SELECT   LGR.LGR_NAME, LGR.LGR_DISPLAY_NAME, LGR.LGR_TYPE
      FROM  $sch_br.LGR_LOGICAL_RESOURCES LGR
   ";
   if (!($r=db_query($composer_db,$query))) {
      tws_error('', 'Database query failed');
      return FALSE;
   }
   $resources = array();
   while( $row = db_fetch_row( $composer_db )) {
      $id = $row['LGR_NAME'];
      $resources[$id]['name'] = $row['LGR_DISPLAY_NAME_UP'];
      $resources[$id]['type'] = $row['LGR_TYPE'];
   }
   // Select Pools and rewrite names in $resources
   // Pools display names not correct in LGR_LOGICAL_RESOURCES but in WKS_WORKSTATIONS
   $query = "
      SELECT   WKS.WKS_ACCESS_METHOD, WKS.WKS_NAME, LGR.LGR_TYPE
      FROM  $sch_br.LGR_LOGICAL_RESOURCES LGR,
            $schema.WKS_WORKSTATIONS WKS
      WHERE WKS.WKS_ACCESS_METHOD = LGR.LGR_NAME;
   ";
   if (!($r=db_query($composer_db,$query))) {
      tws_error('', 'Database query failed');
      return FALSE;
   }
   $pools = array();
   while( $row = db_fetch_row( $composer_db )) {
      $id = $row['WKS_ACCESS_METHOD'];
      $resources[$id]['name'] = $row['WKS_NAME'];
      $resources[$id]['type'] = $row['LGR_TYPE'];
   }

   return $resources;
}

///
/// Workstation report handler (used at IWS Database Report page)
/// \param sel SELECT attributes
/// \param crit items used to build WHERE clause
/// \param ord items used to build ORDER BY clause
/// \param pri items used to sort ORDER BY items
/// \param query (output parameter) resultant sql query string
/// \param dbds (output parameter) database descriptor name
/// \param mode controls the output mode (FETCH_ALL=all results returned in an in array, INIT=initialize the data stream, then fetching data by calling without parameters)
/// \return resultant fetched rows of the created query or the column name map if sel===null
function tws_workstations_report($sel=array(), $crit=array(), $ord=array(), $pri=array(), &$query='', &$dbds='', $mode='FETCH_ALL') {
   global $tws_config, $composer_db, $tws_types;
   static $db_cache=NULL, $sel_cache=NULL;

   if (func_num_args()==0) { //fetching data after a previous calling with mode='INIT'
      if ($db_cache===NULL || $sel_cache===NULL) {
         tws_error('Data fetch error', 'Not initialized data stream');
         return FALSE;
      }
      $sel=$sel_cache;
      $db=$db_cache;
      $mode='ROW'; //just internal flag, anything besides 'FETCH_ALL' has the same effect
   } else {
      $dbds='composer_db';
      $colmap=array (
         'WKS.WKS_NAME'                => 'Workstation',
         'WKS.WKS_DESCRIPTION'         => 'Description',
         'WKS.WKS_OPERATING_SYSTEM'    => 'Operating System',
         'WKS.WKS_NODE_NAME'           => 'Node',
         'WKS.WKS_TCP_PORT'            => 'TCP Port',
         'WKS.WKS_SSL_PORT'            => 'SSL Port',
         'DOM_NAME'                    => 'Domain',
         'WKS.WKS_AGENT_TYPE'          => 'Node Type',
         'WKS.WKS_TIMEZONE_ID'         => 'Time Zone',
         'WKS.WKS_INCLUDE_IN_PLAN'     => 'Ignore Flag',
         'WKS_HOST.WKS_NAME HOST_NAME' => 'Host',
         'WKS.WKS_ACCESS_METHOD'       => 'Access method',
         'WKS.WKS_AUTOLINK'            => 'Autolink Flag',
         'WKS.WKS_FULL_STATUS'         => 'Full Status Flag',
         'WKS.WKS_BEHIND_FIREWALL'     => 'Behind Firewall',
         'WKS.WKS_SECURITY_LEVEL'      => 'Security Level',
         'WKS.WKS_SERVER'              => 'Server',
         'VERSION'                     => 'Version'
      );
      if ($sel===NULL) return $colmap;
      // "Version" is not db field!
      if (array_key_exists("VERSION",$sel)) {
         $version = 'on';
         unset($sel['VERSION']);
         unset($crit['VERSION']);
         unset($ord['VERSION']);
         unset($pri['VERSION']);
      }
      $schema=$composer_db['schema'];
      $from="(($schema.WKS_WORKSTATIONS WKS LEFT JOIN $schema.DOM_DOMAINS DOM ON WKS.DOM_ID=DOM.DOM_ID) LEFT JOIN $schema.WKS_WORKSTATIONS WKS_HOST ON WKS.WKS_HOST_ID=WKS_HOST.WKC_ID)";
      if (!empty($crit['WKS.WKS_INCLUDE_IN_PLAN'])) $crit['WKS.WKS_INCLUDE_IN_PLAN']=tws_neg(@tws_yesno($crit['WKS.WKS_INCLUDE_IN_PLAN'], 'Y', 'N'));
      $crit['WKS.WKS_NAME']=strtoupper($crit['WKS.WKS_NAME']);
      $crit['WKS.WKS_OPERATING_SYSTEM']=strtoupper($crit['WKS.WKS_OPERATING_SYSTEM']);
      $crit['DOM_NAME']=strtoupper($crit['DOM_NAME']);
      $crit['WKS.WKS_AGENT_TYPE']=strtoupper($crit['WKS.WKS_AGENT_TYPE']);
      $crit['WKS.WKS_TIMEZONE_ID']=strtoupper($crit['WKS.WKS_TIMEZONE_ID']);
      //TODO: some criteria values should be rewritten (e.g. YES->Y, etc.)
      if (!empty($crit['WKS.WKS_AUTOLINK']))  $crit['WKS.WKS_AUTOLINK']=@tws_yesno($crit['WKS.WKS_AUTOLINK'], 'Y', 'N');
      if (!empty($crit['WKS.WKS_FULL_STATUS'])) $crit['WKS.WKS_FULL_STATUS']=@tws_yesno($crit['WKS.WKS_FULL_STATUS'], 'Y', 'N');
      if (!empty($crit['WKS.WKS_SECURITY_LEVEL'])) $crit['WKS.WKS_SECURITY_LEVEL']=@tws_yesno($crit['WKS.WKS_SECURITY_LEVEL'], 'Y', 'N');
      if (!empty($crit['WKS.WKS_BEHIND_FIREWALL'])) $crit['WKS.WKS_BEHIND_FIREWALL']=@tws_yesno($crit['WKS.WKS_BEHIND_FIREWALL'], 'Y', 'N');
      // execute the report query
      if (($db=tws_report_query($$dbds,$from,$sel,$crit,$ord,$pri,$query))===FALSE) return FALSE; //database query failed
      if ($mode=='FETCH_ALL') {
         //initialize the output structure
         $rows=array();
      } else {
         //initialize the cache
         $sel_cache=$sel;
         $db_cache=$db;
         return $db;
      }
   }
   //fetch query rows
   while ($row=db_fetch_row($db)) {
      if (array_key_exists('WKS.WKS_INCLUDE_IN_PLAN',$sel)) $row['WKS_INCLUDE_IN_PLAN']=@tws_yesno(tws_neg($row['WKS_INCLUDE_IN_PLAN']));
      if (array_key_exists('WKS.WKS_AUTOLINK',$sel))  $row['WKS_AUTOLINK']=@tws_yesno($row['WKS_AUTOLINK']);
      if (array_key_exists('WKS.WKS_FULL_STATUS',$sel)) $row['WKS_FULL_STATUS']=@tws_yesno($row['WKS_FULL_STATUS']);
      if (array_key_exists('WKS.WKS_BEHIND_FIREWALL',$sel)) $row['WKS_BEHIND_FIREWALL']=@tws_yesno($row['WKS_BEHIND_FIREWALL']);
      if (array_key_exists('WKS.WKS_SECURITY_LEVEL',$sel)) $row['WKS_SECURITY_LEVEL']=@$tws_types['WKS_SECURITY_LEVEL'][$row['WKS_BEHIND_FIREWALL']];
      if (array_key_exists('WKS.WKS_AGENT_TYPE',$sel)) $row['WKS_AGENT_TYPE']=@$tws_types['WKS_AGENT_TYPE'][$row['WKS_AGENT_TYPE']];
      if (array_key_exists('WKS.WKS_OPERATING_SYSTEM',$sel)) $row['WKS_OPERATING_SYSTEM']=@$tws_types['WKS_OPERATING_SYSTEM'][$row['WKS_OPERATING_SYSTEM']];
      if (!empty($version)) $row['VERSION'] = tws_get_wks_version($row['WKS_NAME']);
      if ($mode=='FETCH_ALL') $rows[]=$row;
      else return $row;
   }
   if ($mode=='FETCH_ALL') return $rows;
   //reset the cache
   $db_cache=$sel_cache=NULL;
   return 0;
}

// private function for tws_workstations_report()
function tws_get_wks_version($wks_name){
   global $tws_config;

   $command=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), $tws_config['maestro_dir']."/bin/cpuinfo", $wks_name);
   $stdout=$stderr=array(); $ec=0;
      if (tws_popen($command, $ec, $stdout, $stderr, "N")===FALSE || $ec!=0)
      return "";

   foreach ($stdout as $buffer){
      $field=strtok($buffer,":");
      $value=trim(strtok("\n"));
      if( $field == "VERSION")
         return $value;
   }
}

// valid in
function tws_where_valid_in($isodate, $tas='') {
   $q = "((${tas}JST_VALID_FROM <= '${isodate}' OR ${tas}JST_VALID_FROM IS NULL) AND (${tas}JST_VALID_TO > '${isodate}' OR ${tas}JST_VALID_TO IS NULL))";
   return $q;
}


///////////////////////////////////////////////////////////////////////////////
//
// List of jobstreams
//
// Arguments:
//    workstation = workstation class  name (@=wildcard for all)
//    jobstream = jobstream name (@=wildcard for all)
//    sqlcond = sql filteri - conditions of the where clause
//
function tws_get_jobstreams($workstation='@', $jobstream='@', $validfrom='', $sqlfilter='', $page_size=0, $page=1, $od_callback=null, $action='LIST') {
   global $tws_config, $composer_db;
   tws_log('-- tws_get_jobstreams (start at '.basename(__FILE__).'['.__LINE__.'])');
   tws_log("-- tws_get_jobstreams  Parameters: $workstation, $jobstream, $validfrom, $sqlfilter, $page_size, $page, $od_callback, $action");
   tws_log('-- tws_get_jobstreams - memory usage: '.intval(memory_get_usage()/1024).' kB');
   tws_log('-- tws_get_jobstreams - peak memory usage: '.intval(memory_get_peak_usage()/1024).' kB');

   if ($validfrom===null) $validfromqry="JST_VALID_FROM IS NULL";
   elseif ($validfrom==='') $validfromqry = "1=1";
   else  $validfromqry = "JST_VALID_FROM = '".db_string($composer_db,$validfrom)."'";
   if (trim($sqlfilter)=='') $sqlfilter="1=1";

   $jobstreams=array();
   $jobstreams['jobstream_num']=0;

//access rights checking
   $secsel= array('CPU'=>'WKC_NAME','NAME'=>'AJS_NAME');

   if ($tws_config['cpuinfo']['version']>='9.5')
       $secsel['FOLDER'] = 'FOL.FOL_PATH';

   if (($acc_sql=tws_sec_check('SCHEDULE', $secsel, '', $action))===FALSE) return $jobstreams;

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if (!$dbh) {
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=$composer_db["schema"];

   if( $page_size > 0)     // if flextable has page_size - it means that it is limit from admin
      $paging = true;
   else $paging = false;
/*
    // FOLDERS
    if($tws_config['cpuinfo']['version']>='9.5'){
        // explode name from folder
        list($folder_mask, $jobstream) = tws_explode_folder($jobstream);
//        if(empty($folder_mask))
//            $folder_mask = '/@';
        tws_log("-- tws_get_jobstreams -- folder = '$folder_mask', jobstream = '$jobstream'");
    }

// WORKSTATION FOLDER
    if ($tws_config['cpuinfo']['version']>='9.5002'){
       // explode workstation folder and name
       list($ws_folder, $workstation) = tws_explode_folder($workstation);
//       if(empty($ws_folder))
//          $ws_folder = '@';
        tws_log("-- tws_get_jobstreams -- ws_folder = '$ws_folder', workstation = '$workstation'");
    }
*/

// Streams Count:
if( $paging ){
   $query ="
      SELECT count(*) CNT
      FROM
               $schema.JST_JOB_STREAMS JST
         JOIN  $schema.AJS_ABSTRACT_JOB_STREAMS AJS  ON JST.AJS_ID = AJS.AJS_ID
         JOIN  $schema.WKC_WORKSTATION_CLASSES WKC ON AJS.WKC_ID = WKC.WKC_ID";

         $query .= ($tws_config['cpuinfo']['version']>='9.5' ? "
            LEFT JOIN $schema.FOL_FOLDERS FOL ON AJS.FOL_ID = FOL.FOL_ID " : '');  // 9.5 folders

         $query .= ($tws_config['cpuinfo']['version']>='9.5002' ? "
            LEFT JOIN $schema.FOL_FOLDERS WS_FOL ON WKC.FOL_ID = WS_FOL.FOL_ID " : '');  // 9.5 folders

      $query .= "
      WHERE
         WKC_NAME ".tws_sqllike(db_string($composer_db, $workstation))." AND
         AJS_NAME ".tws_sqllike(db_string($composer_db, $jobstream))." AND";

         if($tws_config['cpuinfo']['version']>='9.5'  && !empty($folder_mask))
            $query .= "
               FOL.FOL_PATH ".tws_sqllike(db_string($composer_db, $folder_mask))." AND ";

         if($tws_config['cpuinfo']['version']>='9.5002' && !empty($ws_folder))
            $query .= "
            WS_FOL.FOL_PATH ".tws_sqllike(db_string($composer_db, $ws_folder))." AND ";

      $query .= "
        $validfromqry
        AND $sqlfilter
        $acc_sql";

   tws_log("-- tws_get_jobstreams -- DB Count Query: $query");

   if( !($r=db_query($composer_db,$query)) ){
      tws_log('Error: Database query failed');
      tws_error('', 'Database query failed');
      return FALSE;
   }
   $row = db_fetch_row($composer_db);
   $jobstreams['jobstream_num'] = $row['CNT'];
   tws_log("-- tws_get_jobstreams -- jobstream_num: ". var_export($jobstreams['jobstream_num'], true));
}

// Select Streams
   $query ="
      SELECT
         JST_ID,
         JST_VALID_FROM,
         JST_VALID_TO,
         WKC_NAME,
         JST_DRAFT,
         AJS_NAME,
         AJS_MODIFY_OWNER,
         AJS_MODIFY_TIME,
         AJS_LOCK_OWNER,
         AJS_LOCK_TIME,
         JST_START_OFFSET,
         JST_DESCRIPTION";
         if($paging && $composer_db['type']=='db2')  // TODO: ORACLE ???
            $query .=",
               ROW_NUMBER() OVER(ORDER BY WKC_NAME, AJS_NAME, JST_VALID_FROM) rnum";

         if($tws_config['cpuinfo']['version']>='9.5' )
            $query .= ",
               JS_FOL.FOL_PATH JS_FOLDER" ;     // 9.5 folders
         if($tws_config['cpuinfo']['version']>='9.5002' )
            $query .= ",
               WS_FOL.FOL_PATH WS_FOLDER" ;     // 9.5002 WS folders
   $query .="
      FROM
               $schema.JST_JOB_STREAMS JST
         JOIN  $schema.AJS_ABSTRACT_JOB_STREAMS AJS  ON JST.AJS_ID = AJS.AJS_ID
         JOIN  $schema.WKC_WORKSTATION_CLASSES WKC ON AJS.WKC_ID = WKC.WKC_ID";

         $query .= ($tws_config['cpuinfo']['version']>='9.5' ? "
            LEFT JOIN $schema.FOL_FOLDERS JS_FOL ON JS_FOL.FOL_ID = AJS.FOL_ID " : '');  // 9.5 folders

         $query .= ($tws_config['cpuinfo']['version']>='9.5002' ? "
            LEFT JOIN $schema.FOL_FOLDERS WS_FOL ON WS_FOL.FOL_ID  = WKC.FOL_ID" : '');  // 9.5.2 folders

      $query .= "
      WHERE
         WKC_NAME ".tws_sqllike(db_string($composer_db, $workstation))." AND
         AJS_NAME ".tws_sqllike(db_string($composer_db, $jobstream))." AND";

         if($tws_config['cpuinfo']['version']>='9.5'  && !empty($folder_mask))
            $query .= "
               FOL.FOL_PATH ".tws_sqllike(db_string($composer_db, $folder_mask))." AND ";

         if($tws_config['cpuinfo']['version']>='9.5002' && !empty($ws_folder))
            $query .= "
            WS_FOL.FOL_PATH ".tws_sqllike(db_string($composer_db, $ws_folder))." AND ";

      $query .= "
        $validfromqry
        AND $sqlfilter
        $acc_sql";
      if(!$paging || $composer_db['type']!='db2')
         $query .= " ORDER BY WKC_NAME, AJS_NAME, JST_VALID_FROM";

   tws_log("-- tws_get_jobstreams -- DB query for paging: $query");

   if($paging){
      if($composer_db['type']=='db2')
         $query = "SELECT * FROM ($query)
            WHERE rnum BETWEEN ".(($page-1)*$page_size +1)." AND ".($page*$page_size);
      else
         $query = "
         select *
         from (select a.*, rownum rnum
            from ($query)a
            where rownum <= ".($page*$page_size).") where rnum > ".(($page-1)*$page_size);
   }

   tws_log("-- tws_get_jobstreams -- DB query: $query");
   if (!($r=db_query($composer_db,$query))) {
      tws_log('Error: Database query failed');
      tws_error('', 'Database query failed');
      return FALSE;
   }

   $oc=$od_callback!==null;
   $tl=tws_log();
   while ($row = db_fetch_row($composer_db)) {
      tws_log(var_export($row, true));
      if(!$paging)
         $jobstreams['jobstream_num']++;

      $js['jobstream_id'          ] = $row['JST_ID'];
      $js['jobstream_workstation' ] = $row['WKC_NAME'];
      $js['jobstream_valid_from'  ] = $row['JST_VALID_FROM'];
      $js['jobstream_valid_to'    ] = $row['JST_VALID_TO'];
      $js['jobstream_name'        ] = $row['AJS_NAME'];
      $js['jobstream_creator'     ] = $row['AJS_MODIFY_OWNER'];
      $js['jobstream_last_updated'] = $row['AJS_MODIFY_TIME'];
      $js['jobstream_lock_by'     ] = $row['AJS_LOCK_OWNER'];
      $js['jobstream_lock_on'     ] = $row['AJS_LOCK_TIME'];
      $js['jobstream_draft'       ] = tws_yesno($row['JST_DRAFT']);
      $js['jobstream_start_offset'] = $row['JST_START_OFFSET'];
      $js['jobstream_description'] = $row['JST_DESCRIPTION'];
      if($tws_config['cpuinfo']['version']>='9.5'){
         if(empty($row['JS_FOLDER']))
            $row['JS_FOLDER'] = '/';
         $js['jobstream_folder'] = $row['JS_FOLDER'];
      }
      if($tws_config['cpuinfo']['version']>='9.5002'){
         if(empty($row['WS_FOLDER']))
            $row['WS_FOLDER'] = '/';
         $js['workstation_folder'] = $row['WS_FOLDER'];
      }
      if ($oc) {
         $js['offset']=$jobstreams['jobstream_num'];
         $od_callback($js);
      } else {
         foreach ($js as $key=>$val) {
            $jobstreams[$key][]=$val;
         }
      }
   }
   tws_log('-- tws_get_jobstreams (end up in '.basename(__FILE__).'['.__LINE__.'])');
   tws_log('-- tws_get_jobstreams - memory usage: '.intval(memory_get_usage()/1024).' kB');
   tws_log('-- tws_get_jobstreams - peak memory usage: '.intval(memory_get_peak_usage()/1024).' kB');
   if (defined('IWD_PROCMAN')) return $jobstreams; //procman::db_functions::db_fetch_row returns FALSE if there are no rows left
   return ($row===FALSE ? FALSE : $jobstreams);
}

////////////////////////////////////////////
//
// tws_get_at_time
// calculates hour, min, days from milisecond format returned by DB
//
function tws_get_at_time($total_milisecs,&$h,&$m,&$s,&$d,$mode='STD_AT') {
	// tws_log("-- tws_get_at_time parameters: $total_milisecs,&$h,&$m,&$s,&$d,$mode");
   if ($total_milisecs<0) {
      $h=$m=$s=$d='';
      return '';
   }
   else {
      list($d,$h,$m,$s)=explode(':', gmdate('z:H:i:s',floor($total_milisecs/1000)));
      $h=str_pad($h,2,'0',STR_PAD_LEFT);
      $m=str_pad($m,2,'0',STR_PAD_LEFT);
      $s=str_pad($s,2,'0',STR_PAD_LEFT);
      //return the AT standard format
      switch ($mode) {
         case 'DAY_OFFSET' :
            return "$h:$m:$s";
         case 'RELATIVE_OFFSET' :
            $h+=$d*24; //ERR16587-Relative dependencies resolution must support times up to 167:59
            $h=str_pad($h,3,'0',STR_PAD_LEFT);
         default : case 'STD_AT' :
            if (intval($d)>0) return  "$h:$m + $d DAYS";
            else return "$h:$m";
      }
   }
}

/// Get Jobstream generic data
/// General data + options (1st page of "add jobstream").
/// @param workstation exact workstation name (no wildcars)
/// @param jobstream exact jobstream name (no wildcars)
/// @param validfrom valid from in iso format

/// @warning No wildcards allowed, will return first record found!
/// @return vector of arrays, see bellow the key description
/// @code Array(
///   'workstation', 'jobstream', 'validfrom'
///   'description', 'comment'
///   'athour','atminute','atplusdays' ~ earliest time the jobstream can be launched
///   'untilhour','untilminute','untilplusdays' ~ latest time the jobstream can be launched
///   'onuntil' ~ specifies the action to take when until time has been reached
///   'deadlinehour','deadlineminute','deadlineplusdays' ~ time within which the jobstream should complete
///   'time_zone' ~ time zone for at,intil,deadline
///   'priority' ~ jobstream priority (100~HI, 101~GO)
///   'limit', 'carryforward', 'keysched'
///   'freedays_option', 'freedays_calendar', 'freedays_sat', 'freedays_sun' ~ specifies a freeday calendar for calculating workdays freedays for the job stream. It can also set Saturdays and Sundays as workdays.
///   'request' ~ on request choice (YES/NO)
///   'draft' ~ specifies that the plan generation process must ignore this jobstream
///   'matching' ~ matching criteria: PREVIOUS,SAMEDAY,RELATIVE,ABSOLUTE. In case of RELATIVE and ABSOLUTE, additional indexes are added. See the function definition for details.
/// )
function tws_get_jobstream_generic_data($workstation, $jobstream, $validfrom =''){
   global $tws_config, $composer_db;

   tws_log('-- tws_get_jobstream_generic_data (start at '.basename(__FILE__).'['.__LINE__.'])');
   tws_log("-- tws_get_jobstream_generic_data Parameters: workstation = $workstation, jobstream = $jobstream, validfrom = $validfrom");

   if( ($workstation == '') || ($jobstream == '') ) {
      tws_error("workstation='$workstation', jobstream='$jobstream'","Database query error - missing argument(s)");
      return FALSE;
   }
   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema = $composer_db['schema'];

   $workstation_name = $workstation;
// IWS 9.5002 - divide WS folder and WS name
   if ($tws_config['cpuinfo']['version'] >=9.5002){
      list($workstation_folder, $workstation_name) = tws_divide_folder($workstation);
      if(empty($workstation_folder))
         $workstation_folder = '/@';
   }
   $jobstream_name = $jobstream;
// IWS 9.5 - divide Stream folder and Stream name
   if ($tws_config['cpuinfo']['version'] >=9.5 ){
      list($jobstream_folder, $jobstream_name) = tws_divide_folder($jobstream);
      if(empty($jobstream_folder))
         $jobstream_folder = '/@';
   }

// VALIDFROM
   if ($validfrom == '') {
      $validfrom_expr = "JST_VALID_FROM IS NULL";
      $st_name = 'STREAM_GENERIC_DATA';
   }
   else {
      $validfrom_expr = "JST_VALID_FROM = ?";
      $st_name = 'STREAM_GENERIC_DATA_VALID';
   }

   if(!isset($composer_db[$st_name])){
      if ($tws_config['cpuinfo']['version']<'8.5') {
         $query = "
         SELECT
            WKC.WKC_NAME WORKSTATION,
            AJS.AJS_NAME JOBSTREAM,
            JST.JST_VALID_FROM VALID_FROM,
            JST.JST_VALID_TO VALID_TO,
            JST.JST_DESCRIPTION DESCRIPTION,
            JST.JST_COMMENT COMMENTAR,
            JST.JST_ON_REQUEST ON_REQUEST,
            CAL.CAL_NAME FREEDAYS_CALENDAR,
            JST.JST_SATURDAY_FREE FREEDAYS_SAT,
            JST.JST_SUNDAY_FREE FREEDAYS_SUN,
            JST.JST_START_OFFSET AT,
            JST.JST_TIME_DEPENDENT TIME_DEPENDENT,
            JST.JST_LATEST_START_OFFSET UNTIL,
            JST.JST_LATEST_START_ACTION ONUNTIL,
            JST.JST_DEADLINE_OFFSET DEADLINE,
            JST.JST_TIMEZONE_ID TIMEZONE,
            JST.JST_PRIORITY PRIORITY,
            JST.JST_LIMIT LIMIT,
            JST.JST_CARRY_FORWARD CARRYFORWARD,
            JST.JST_MONITORED MONITORED,
            JST.JST_DRAFT DRAFT,
            JST.JST_RULE MATCHING,
            JST.JST_RULE_START_OFFSET MATCHING_FROM,
            JST.JST_RULE_END_OFFSET MATCHING_TO
         FROM (($schema.JST_JOB_STREAMS JST
            JOIN $schema.AJS_ABSTRACT_JOB_STREAMS AJS ON AJS.AJS_ID = JST.AJS_ID)
            JOIN $schema.WKC_WORKSTATION_CLASSES WKC ON WKC.WKC_ID = AJS.WKC_ID)
            LEFT JOIN $schema.CAL_CALENDARS CAL ON CAL.CAL_ID = JST.CAL_ID
         WHERE
            WKC_NAME = ? AND
            AJS_NAME = ? AND
            $validfrom_expr";
      }
      else {
         $query = "
         SELECT";
         if ($tws_config['cpuinfo']['version'] >=9.5002)
             $query .= "
             WS_FOL.FOL_PATH WS_FOLDER,
             CAL_FOL .FOL_PATH CAL_FOLDER,";
         $query .= "
            WKC.WKC_NAME WORKSTATION,";
         if ($tws_config['cpuinfo']['version'] >=9.5)
             $query .= "
             JS_FOL.FOL_PATH JS_FOLDER,";
         $query .= "
            AJS.AJS_NAME JOBSTREAM,
            JST.JST_VALID_FROM VALID_FROM,
            JST.JST_VALID_TO VALID_TO,
            JST.JST_DESCRIPTION DESCRIPTION,
            JST.JST_COMMENT COMMENTAR,
            JST.JST_ON_REQUEST ON_REQUEST,
            CAL.CAL_NAME FREEDAYS_CALENDAR,
            JST.JST_SATURDAY_FREE FREEDAYS_SAT,
            JST.JST_SUNDAY_FREE FREEDAYS_SUN,
            JST.JST_START_OFFSET AT,
            JST.JST_TIME_DEPENDENT TIME_DEPENDENT,
            JST.JST_LATEST_START_OFFSET UNTIL,
            JST.JST_LATEST_START_ACTION ONUNTIL,
            JST.JST_DEADLINE_OFFSET DEADLINE,
            JST.JST_TIMEZONE_ID TIMEZONE,
            JST.JST_PRIORITY PRIORITY,
            JST.JST_LIMIT LIMIT,
            JST.JST_CARRY_FORWARD CARRYFORWARD,
            JST.JST_MONITORED MONITORED,
            JST.JST_DRAFT DRAFT,
            JST.JST_RULE MATCHING,
            JST.JST_RULE_START_OFFSET MATCHING_FROM,
            JST.JST_RULE_END_OFFSET MATCHING_TO,
            VAT.VAT_NAME VAT_NAME
            ".($tws_config['cpuinfo']['version']>='9.3' ? ', JST_RUNNING_RULE_ACTION RUNNING_RULE_ACTION' : '')."
            ".($tws_config['cpuinfo']['version'] > '9.4' ? ', JST_PROPAGATE_LATEST_START PROPAGATE_LATEST_START' : '')."
            ".($tws_config['cpuinfo']['version']>='9.5' ? ', JS_FOL.FOL_NAME FOL_NAME' : '');
            if($tws_config['cpuinfo']['version']>='9.5002')
               $query .= ",
               VAT_FOL.FOL_PATH           VAT_FOLDER,
               CAL_FOL.FOL_PATH           CAL_FOLDER";
         $query .= "
         FROM (((($schema.JST_JOB_STREAMS JST
            JOIN $schema.AJS_ABSTRACT_JOB_STREAMS AJS  ON AJS.AJS_ID = JST.AJS_ID)
            JOIN $schema.WKC_WORKSTATION_CLASSES WKC ON WKC.WKC_ID = AJS.WKC_ID)
            LEFT JOIN $schema.CAL_CALENDARS CAL ON CAL.CAL_ID = JST.CAL_ID)
            LEFT JOIN $schema.VAT_VARIABLE_TABLES VAT ON JST.VAT_ID = VAT.VAT_ID)";

            if($tws_config['cpuinfo']['version']>='9.5002')
               $query .= "
               LEFT JOIN $schema.FOL_FOLDERS WS_FOL ON WS_FOL.FOL_ID = WKC.FOL_ID
               LEFT JOIN $schema.FOL_FOLDERS VAT_FOL ON VAT_FOL.FOL_ID = VAT.FOL_ID
               LEFT JOIN $schema.FOL_FOLDERS CAL_FOL ON CAL_FOL.FOL_ID = CAL.FOL_ID";

            if($tws_config['cpuinfo']['version']>='9.5')
               $query .= "
               LEFT JOIN $schema.FOL_FOLDERS JS_FOL ON JS_FOL.FOL_ID = AJS.FOL_ID";

         $query .= "
            WHERE";
            if($tws_config['cpuinfo']['version']>='9.5002')
               $query .= "
               WS_FOL.FOL_PATH = ? AND";
            $query .= "
            WKC_NAME = ? AND";
            if($tws_config['cpuinfo']['version']>='9.5')
               $query .= "
               JS_FOL.FOL_PATH = ? AND";
            $query .= "
               AJS_NAME = ? AND
            $validfrom_expr";
      }

      $stmt=new db_statement($composer_db, $query);
      if ($stmt->prepare()==FALSE){
         unset($stmt);
         tws_error('', 'Database query prepare failed: '.$query);
         return FALSE;
      }
      $composer_db[$st_name] = $stmt;
   }
   else $stmt = $composer_db[$st_name];

   $values = array();
   if($tws_config['cpuinfo']['version']>='9.5002')
      $values[]  = $workstation_folder;
   $values[] = db_string($composer_db, $workstation_name);
   if($tws_config['cpuinfo']['version']>='9.5')
      $values[]  = $jobstream_folder;
   $values[] = db_string($composer_db, $jobstream_name);
   if (!empty($validfrom))
      $values[] =  db_string($composer_db,$validfrom);

   tws_log(' -- tws_get_jobstream_generic_data, DB query: '.$stmt->sql());
   tws_log('tws_get_jobstream_generic_data, Query values: '.var_export($values, true));

   if ($stmt->execute($values)==false){
      tws_error('', 'Database query failed: '.$query);
      return FALSE;
   }

   $temp='';
   $stream1=Array();

   if( $stmt->fetch() ){
      $row = $stmt->row();
// tws_log ("row = " .var_export($row, true));
      //at, until, deadline are returned in thousandth of seconds or -1 if not set
      if(!empty($workstation_folder))
         $stream1['workstation_folder']=$row['WS_FOLDER'];
      $stream1['workstation']=$row['WORKSTATION'];
      if(!empty($jobstream_folder))
         $stream1['jobstream_folder'] = $row['JS_FOLDER'];
      $stream1['jobstream']=$row['JOBSTREAM'];
      $stream1['validfrom']=tws_iso_to_userdate($row['VALID_FROM'], null, true);
      $stream1['validto']=tws_iso_to_userdate($row['VALID_TO'], null, true);
      $stream1['description']=$row['DESCRIPTION'];
      $stream1['comment']=trim($row['COMMENTAR'], "\r\n");
      tws_get_at_time($row['AT'],$stream1['athour'],$stream1['atminute'],$temp,$stream1['atplusdays']);
      $stream1['time_dependent']=$row['TIME_DEPENDENT'];
      tws_get_at_time($row['UNTIL'],$stream1['untilhour'],$stream1['untilminute'],$temp,$stream1['untilplusdays']);
      $stream1['onuntil']=tws_typeval('ONUNTIL',$row['ONUNTIL']);
      if($tws_config['cpuinfo']['version']>'9.4')
         $stream1['jsuntil']=$row['PROPAGATE_LATEST_START'];   // default is 'YES' - it mewans normal until, otherwise - jsuntil
      tws_get_at_time($row['DEADLINE'],$stream1['deadlinehour'],$stream1['deadlineminute'],$temp,$stream1['deadlineplusdays']);
      if($tws_config['cpuinfo']['version']>='9.3')
         $stream1['running_rule']=$row['RUNNING_RULE_ACTION'];
      $stream1['time_zone']=$row['TIMEZONE'];
      $stream1['priority']=$row['PRIORITY'];
      if ($stream1['priority']==100) $stream1['priority']='HI';
      if ($stream1['priority']==101) $stream1['priority']='GO';
      $stream1['limit']=$row['LIMIT']>=0 ? $row['LIMIT'] : '';
      $stream1['carryforward']=tws_yesno($row['CARRYFORWARD']);
      $stream1['keysched']=tws_yesno($row['MONITORED']);

      if($tws_config['cpuinfo']['version']>='9.5002'){
          $vat_folder = $row['VAT_FOLDER'];
          $cal_folder = $row['CAL_FOLDER'];
      }
      else{
         $vat_folder = '';
         $cal_folder = '';
      }
      $stream1['parameter_table']= $vat_folder.$row['VAT_NAME'];

      if ($row['FREEDAYS_CALENDAR']!= "")
         $stream1['freedays_option']="specify";
      else $stream1['freedays_option']="default";
      $stream1['freedays_calendar']=$cal_folder.$row['FREEDAYS_CALENDAR'];

      $stream1['freedays_sat']=tws_yesno($row['FREEDAYS_SAT']);
      $stream1['freedays_sun']=tws_yesno($row['FREEDAYS_SUN']);
      $stream1['request']=tws_yesno($row['ON_REQUEST']);
      $stream1['draft']=tws_yesno($row['DRAFT']);
      $stream1['matching']=tws_typeval('MATCHING',$row['MATCHING']);
      switch ($stream1['matching']) {
         case "RELATIVE":
            if ($row['MATCHING_FROM'] < 0) {
               tws_get_at_time(-1*$row['MATCHING_FROM'],$stream1['matchingrelativefromhour'],$stream1['matchingrelativefromminute'],$temp,$temp, 'RELATIVE_OFFSET');
               $stream1['matchingrelativefromdir'] = "-";
            } else {
               tws_get_at_time(($row['MATCHING_FROM']),$stream1['matchingrelativefromhour'],$stream1['matchingrelativefromminute'],$temp,$temp, 'RELATIVE_OFFSET');
               $stream1['matchingrelativefromdir'] = "+";
            }
            if ($row['MATCHING_TO'] < 0) {
               tws_get_at_time(-1*$row['MATCHING_TO'],$stream1['matchingrelativetohour'],$stream1['matchingrelativetominute'],$temp,$temp, 'RELATIVE_OFFSET');
               $stream1['matchingrelativetodir'] = "-";
            } else {
               tws_get_at_time($row['MATCHING_TO'],$stream1['matchingrelativetohour'],$stream1['matchingrelativetominute'],$temp,$temp, 'RELATIVE_OFFSET');
               $stream1['matchingrelativetodir'] = "+";
            }
            break;
         case "ABSOLUTE":
            $day= 1000 * 60 * 60 * 24;
            if ($row['MATCHING_FROM'] < 0) {
               $stream1['matchingabsolutefromdir'] = "-";
               $stream1['matchingabsolutefromdays']= strval(-1*(floor($row['MATCHING_FROM']/($day))));
               $rest = ($row['MATCHING_FROM']%($day)+($day));
               tws_get_at_time($rest,$stream1['matchingabsolutefromhour'],$stream1['matchingabsolutefromminute'],$temp,$temp);
            } else {
               tws_get_at_time($row['MATCHING_FROM'],
                  $stream1['matchingabsolutefromhour'],
                  $stream1['matchingabsolutefromminute'],
                  $temp,
                  $stream1['matchingabsolutefromdays']);
               $stream1['matchingabsolutefromdir'] = "+";
            }
            if ($row['MATCHING_TO'] < 0) {
               $stream1['matchingabsolutetodir'] = "-";
               $stream1['matchingabsolutetodays']= strval(-1*(floor($row['MATCHING_TO']/($day))));
               $rest = ($row['MATCHING_TO']%($day)+($day));
               tws_get_at_time($rest,$stream1['matchingabsolutetohour'],$stream1['matchingabsolutetominute'],$temp,$temp);
            } else {
               tws_get_at_time($row['MATCHING_TO'],
                     $stream1['matchingabsolutetohour'],
                     $stream1['matchingabsolutetominute'],
                     $temp,
                     $stream1['matchingabsolutetodays']);
               $stream1['matchingabsolutetodir'] = "+";
            }
      }
      //$stream1['']=$row[''];
   }
   else {
      tws_error(' -- tws_get_jobstream_generic_data Result is Empty');
      return FALSE;
   }
   tws_log(' -- tws_get_jobstream_generic_data Result: '.var_export($stream1, true));
   return $stream1;
}

// IWS 9.4 - startcond feature
function tws_get_stream_startcond($workstation, $jobstream, $validfrom =''){
   global $tws_config, $composer_db;

   tws_log('-- tws_get_stream_startcond (start at '.basename(__FILE__).'['.__LINE__.'])');
   tws_log("-- tws_get_stream_startcond Parameters: workstation = $workstation, jobstream = $jobstream");

   if ($workstation=='' || $jobstream=='') {
      tws_error("workstation='$workstation', jobstream='$jobstream'","Missing argument(s)");
      return false;
   }

   if($tws_config['cpuinfo']['version']>='9.5')
      list($jobstream_folder, $jobstream) = tws_explode_folder($jobstream);

   if($tws_config['cpuinfo']['version']>='9.5002')
      list($workstation_folder, $workstation) = tws_explode_folder($workstation);

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_error('', 'Cannot connect to database');
      return false;
   }
   $schema = $composer_db['schema'];
   if ($validfrom == '')
      $validfrom_expr = "JST_VALID_FROM IS NULL";
   else
      $validfrom_expr = "JST_VALID_FROM = '".db_string($composer_db, $validfrom)."'";

   $query ="
   SELECT
      JOD_TASK_STRING,
          JOD_WKC.WKC_NAME JOB_WORKSTATION,
          AJB.AJB_NAME JOBNAME,
          JOD.JOD_NAME DEF_JOBNAME,
          JOB_STARTCOND_TYPE,
          JOB_POLLING_CONDITION,
          JOB_POLLING_INTERVAL,
          JST_TRIGGER_ONCE";
         if($tws_config['cpuinfo']['version']>='9.5' )
            $query .= ",
               JOB_FOL.FOL_PATH,
               JODWS_FOL.FOL_PATH JOBWS_PATH " ;     // 9.5 folders
   $query .="
   FROM (((((($schema.JOB_JOBS JOB
      JOIN $schema.AJB_ABSTRACT_JOBS AJB ON   AJB.AJB_ID = JOB.AJB_ID)
      JOIN $schema.AJS_ABSTRACT_JOB_STREAMS AJS ON   AJB.AJS_ID = AJS.AJS_ID)
      JOIN $schema.WKC_WORKSTATION_CLASSES WKC ON   WKC.WKC_ID = AJS.WKC_ID)
      JOIN $schema.JOD_JOB_DEFINITIONS JOD ON   JOD.JOD_ID = JOB.JOD_ID)
      JOIN $schema.WKC_WORKSTATION_CLASSES JOD_WKC ON   JOD.WKC_ID = JOD_WKC.WKC_ID)
      JOIN $schema.JST_JOB_STREAMS JST ON   JST.JST_ID = JOB.JST_ID)";
      if ($tws_config['cpuinfo']['version']>='9.5')
         $query .= "
         LEFT JOIN $schema.FOL_FOLDERS JS_FOL ON JS_FOL.FOL_ID = AJS.FOL_ID
         LEFT JOIN $schema.FOL_FOLDERS JOB_FOL ON JOB_FOL.FOL_ID = JOD.FOL_ID";  // Job Folder
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
         LEFT JOIN $schema.FOL_FOLDERS WS_FOL ON WS_FOL.FOL_ID = WKC.FOL_ID
         LEFT JOIN $schema.FOL_FOLDERS JODWS_FOL ON JODWS_FOL.FOL_ID = JOD_WKC.FOL_ID   ";  // Job Folder
      $query .= "
   WHERE
      WKC.WKC_NAME = '".db_string($composer_db, $workstation)."' AND
      AJS.AJS_NAME  = '".db_string($composer_db, $jobstream)."' AND
      $validfrom_expr AND
      JOB.JOB_POSITION = -1";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
            AND WS_FOL.FOL_PATH = '$workstation_folder'";

   tws_log(" -- tws_get_stream_startcond DB query: $query");

   if( !($r=db_query($composer_db, $query)) ){
      tws_error('', 'Database query failed: '.$query);
      return false;
   }
   $res = array();
   if(($row = db_fetch_row($composer_db)) !== false){

      if(!empty($row['FOL_PATH']) )
         $res['startcond_select'] = $row['FOL_PATH'];
      $task_str = $row['JOD_TASK_STRING'];
      $arr = json_decode($task_str, true);
      $res['startcond_select'] = $row['JOB_STARTCOND_TYPE'];
      if($row['JOB_STARTCOND_TYPE'] == 'J'){    // job_condition
         if ($tws_config['cpuinfo']['version']>='9.5002')
             $res['jobcond_cpu']= $row['JOBWS_PATH'].$row['JOB_WORKSTATION'];
         else
             $res['jobcond_cpu']= $row['JOB_WORKSTATION'];
        if ($tws_config['cpuinfo']['version']>='9.5')
            $res['jobcond_job'] = $row['FOL_PATH'].trim($row['DEF_JOBNAME']);
         else
              $res['jobcond_job'] = trim($row['DEF_JOBNAME']);
         $res['jobcond_output'] = $row['JOB_POLLING_CONDITION'];
         $res['jobcond_interval'] = $row['JOB_POLLING_INTERVAL'];
         $res['jobcond_create_job'] = trim($row['JOBNAME']);
         $res['jobcond_once']  = $row['JST_TRIGGER_ONCE'];
      }
      else{    // file condition
         if($row['JOB_STARTCOND_TYPE'] != 'C' && $row['JOB_STARTCOND_TYPE'] != 'M')
            return $res;
         if ($tws_config['cpuinfo']['version']>='9.5002')
             $res['filecond_cpu'] = $row['JOBWS_PATH'].$row['JOB_WORKSTATION'];
         else
             $res['filecond_cpu'] = $row['JOB_WORKSTATION'];
         $res['filecond_interval'] = $row['JOB_POLLING_INTERVAL'];
         $res['filecond_create_job'] = trim($row['JOBNAME']);
         $res['filecond_once']  = $row['JST_TRIGGER_ONCE'];
         if(isset($arr['processingbatch']) && $arr['processingbatch'] == true)
            $res['filecond_group'] = 'Y';
         if(isset($arr['advancedparams']))
            $res['filecond_add'] = $arr['advancedparams'];
         if(isset($arr['filename']))
            $res['filecond_file'] = $arr['filename'];
         if(isset($arr['outputfile']))
            $res['filecond_output'] = $arr['outputfile'];
         if(isset($arr['userlogin']))
            $res['filecond_login'] = $arr['userlogin'];
      }
   }
   tws_log(" -- tws_get_stream_startcond Result: ". var_export($res, true));
   return $res;
}

///
/// Jobstreams report handler (used at IWS Database Report page)
/// \param sel SELECT attributes
/// \param crit items used to build WHERE clause
/// \param ord items used to build ORDER BY clause
/// \param pri items used to sort ORDER BY items
/// \param query (output parameter) resultant sql query string
/// \param dbds (output parameter) database descriptor name
/// \param mode controls the output mode (FETCH_ALL=all results returned in an in array, INIT=initialize the data stream, then fetching data by calling without parameters)
/// \return resultant fetched rows of the created query or the column name map if sel===null
function tws_jobstreams_report($sel=array(), $crit=array(), $ord=array(), $pri=array(), &$query='', &$dbds='', $mode='FETCH_ALL') {
   global $tws_config, $composer_db, $tws_types;
   static $db_cache=NULL, $sel_cache=NULL;

   if (func_num_args()==0) { //fetching data after a previous calling with mode='INIT'
      if ($db_cache===NULL || $sel_cache===NULL) {
         tws_error('Data fetch error', 'Not initialized data stream');
         return FALSE;
      }
      $sel=$sel_cache;
      $db=$db_cache;
      $mode='ROW'; //just internal flag, anything besides 'FETCH_ALL' has the same effect
   } else {
      $dbds='composer_db';
      $colmap = array();
      $colmap['WKC.WKC_NAME WORKSTATION']       = 'Workstation';
      if($tws_config['cpuinfo']['version']>='9.5')
         $colmap['FOL_PATH']                    = 'Jobstream Folder';
      $colmap['AJS.AJS_NAME JOBSTREAM']         = 'Jobstream';
      $colmap['JST.JST_VALID_FROM VALID_FROM']  = 'Valid From';
      $colmap['JST.JST_DESCRIPTION DESCRIPTION'] = 'Description';
      $colmap['JST.JST_START_OFFSET AT']        = 'At';
      $colmap['JST.JST_LATEST_START_OFFSET UNTIL'] = 'Until';
      $colmap['JST.JST_DEADLINE_OFFSET DEADLINE']  = 'Deadline';
      $colmap['JST.JST_CARRY_FORWARD CARRYFORWARD'] = 'Carryforward';
      $colmap['JST.JST_LIMIT LIMIT']               = 'Limit';
      $colmap['JST.JST_PRIORITY PRIORITY']         = 'Priority';
      $colmap['JST.JST_DRAFT DRAFT']               = 'Draft';
      $colmap['JST.JST_ON_REQUEST ON_REQUEST']     = 'On Request';

      if ($sel===null) return $colmap;
      $schema=$composer_db['schema'];
      $from="(($schema.JST_JOB_STREAMS JST
         JOIN $schema.AJS_ABSTRACT_JOB_STREAMS AJS ON AJS.AJS_ID=JST.AJS_ID)
         JOIN $schema.WKC_WORKSTATION_CLASSES WKC ON WKC.WKC_ID=AJS.WKC_ID)";
      if($tws_config['cpuinfo']['version']>='9.5')
         $from .=
         "LEFT JOIN $schema.FOL_FOLDERS FOL ON FOL.FOL_ID = AJS.FOL_ID";
      $crit['JST.JST_VALID_FROM VALID_FROM']=tws_iso_to_userdate($crit['JST.JST_VALID_FROM VALID_FROM'],null,true);
      $crit['WKC.WKC_NAME WORKSTATION']=strtoupper($crit['WKC.WKC_NAME WORKSTATION']);
      if($tws_config['cpuinfo']['version']>='9.5')
         $crit['WKC.WKC_NAME WORKSTATION']=strtoupper($crit['WKC.WKC_NAME WORKSTATION']);
      $crit['FOL_PATH']=strtoupper($crit['FOL_PATH']);
   //TODO: AT,UNTIL,DEADLINE must be converted from user format to miliseconds
      $crit['JST.JST_START_OFFSET AT']=tws_set_at_time($crit['JST.JST_START_OFFSET AT'], 'JST.JST_START_OFFSET');
      $crit['JST.JST_LATEST_START_OFFSET UNTIL']=tws_set_at_time($crit['JST.JST_LATEST_START_OFFSET UNTIL'], 'JST.JST_LATEST_START_OFFSET');
      $crit['JST.JST_DEADLINE_OFFSET DEADLINE']=tws_set_at_time($crit['JST.JST_DEADLINE_OFFSET DEADLINE'], 'JST.JST_DEADLINE_OFFSET');
   //TODO: Carryforward Draft On Request must be converted in 'Y'/'N' form
      if (!empty($crit['JST.JST_DRAFT DRAFT'])) $crit['JST.JST_DRAFT DRAFT']=tws_yesno($crit['JST.JST_DRAFT DRAFT'], 'Y', 'N');
      if (!empty($crit['JST.JST_CARRY_FORWARD CARRYFORWARD'])) $crit['JST.JST_CARRY_FORWARD CARRYFORWARD']=tws_yesno($crit['JST.JST_CARRY_FORWARD CARRYFORWARD'], 'Y', 'N');
      if (!empty($crit['JST.JST_ON_REQUEST ON_REQUEST'])) $crit['JST.JST_ON_REQUEST ON_REQUEST']=tws_yesno($crit['JST.JST_ON_REQUEST ON_REQUEST'], 'Y', 'N');
      // execute the report query
      if (($db=tws_report_query($$dbds,$from,$sel,$crit,$ord,$pri,$query))===FALSE) return FALSE; //database query failed
      if ($mode=='FETCH_ALL') {
         //initialize the output structure
         $rows=array();
      } else {
         //initialize the cache
         $sel_cache=$sel;
         $db_cache=$db;
         return $db;
      }
   }
   //fetch query rows
   $temp='';
   while ($row=db_fetch_row($db)) {
      if (array_key_exists('JST.JST_VALID_FROM VALID_FROM',$sel)) $row['VALID_FROM']=tws_iso_to_userdate($row['VALID_FROM'],null,true);
      if (array_key_exists('JST.JST_START_OFFSET AT',$sel)) $row['AT']=tws_get_at_time($row['AT'],$h,$m,$temp,$d);
      if (array_key_exists('JST.JST_LATEST_START_OFFSET UNTIL',$sel)) $row['UNTIL']=tws_get_at_time($row['UNTIL'],$h,$m,$temp,$d);
      if (array_key_exists('JST.JST_DEADLINE_OFFSET DEADLINE',$sel)) $row['DEADLINE']=tws_get_at_time($row['DEADLINE'],$h,$m,$temp,$d);
      if (array_key_exists('JST.JST_CARRY_FORWARD CARRYFORWARD',$sel)) $row['CARRYFORWARD']=tws_yesno($row['CARRYFORWARD']);
      if (array_key_exists('JST.JST_LIMIT LIMIT',$sel)) $row['LIMIT']=tws_yesno($row['LIMIT'],$row['LIMIT'],'',-1);
      if (array_key_exists('JST.JST_DRAFT DRAFT',$sel)) $row['DRAFT']=tws_yesno($row['DRAFT'], 'YES', ' ');
      if (array_key_exists('JST.JST_ON_REQUEST ON_REQUEST',$sel)) $row['ON_REQUEST']=tws_yesno($row['ON_REQUEST'], 'YES', ' ');
      if ($mode=='FETCH_ALL') $rows[]=$row;
      else return $row;
   }
   if ($mode=='FETCH_ALL') return $rows;
   //reset the cache
   $db_cache=$sel_cache=NULL;
   return 0;
}


// AT,UNTIL,DEADLINE must be converted from user format to miliseconds
// mask can contain:
//    * - not empty
//    ??[:]?? (*) [+][N]DAYS
//   e.g '06:?? + ? days'
//   all possible masks see below
// $fname - field name
function tws_set_at_time ($mask, $fname) {
   global $composer_db;

   if(empty($mask)) return '';
   $mask = trim(str_replace('@', '*', $mask));
   if($mask == '*') return '>0';

   $h=$m='*';
   $d=-1;      // undefined

   $cond = '';
   //  '(??):(??) + (?) days'    // 06:00 + * days
   if( preg_match('/^([\d*]+):([\d*]+)\s*\+\s*([\d*]+)\s*day/i', $mask, $matches) ){
      $h=$matches[1]; $m=$matches[2]; $d=$matches[3];
   } //  '(??)* + (?) days'      // 06* + 1 day
   elseif( preg_match('/^([\d*]+)\s*\*+\s*\+\s*([\d*]+)\s*day/i', $mask, $matches) ){
      $h=$matches[1]; $d=$matches[2];
   } //  '* + (?) days'          // * + 1 day
   elseif( preg_match('/^\*+\s*\+\s*([\d*]+)\s*day/i', $mask, $matches) ){
      $d=$matches[1];
   } //  '(?) days'              // * days
   elseif( preg_match('/^([\d*]+)\s*day/i', $mask, $matches) ){
      $d=$matches[1];
   } //  '(??):(??)'             // 06:33
   elseif( preg_match('/^([\d*]+):([\d*]+)/i', $mask, $matches) ){
      $h=$matches[1]; $m=$matches[2];
   } //  '(??)*'                 // 06*
   elseif( preg_match('/^([\d]+)\*/i', $mask, $matches) ){
      $h=$matches[1];
   }

   // if not a number - it will be *
   if( !is_numeric($d) ) $d='*';
   if( !is_numeric($h) ) $h='*';
   if( !is_numeric($m) ) $m='*';

   // DB2 don't understand own integer format, so must be INT(millisecs)
   // Oracle don't understand documented INT[EGER] function

      if($h=='*' && $m=='*'){   // days only
         if($d=='*')
            $cond = " >= ".strval(36e5*24);
         else
            $cond = " BETWEEN ".strval($d*36e5*24). ' AND '.strval(($d+1)*36e5*24 - 1000);
      }
      elseif($h!='*' && $m=='*'){   // hour [+days]
         if (is_numeric($d) ){
            if($d == -1){      // show all days
               if ($composer_db['type']=='db2')
                  $cond = ' > 0 AND MOD(INT('.$fname.'), 3600000*24) BETWEEN '. strval($h*36e5) . ' AND '. strval(($h+1)*36e5 - 1000);
               else
                  $cond = ' > 0 AND MOD('.$fname.', 3600000*24) BETWEEN '. strval($h*36e5) . ' AND '. strval(($h+1)*36e5 - 1000);
            }
            else              //
               $cond = ' BETWEEN '. strval($h*36e5 + $d*36e5*24) . ' AND '. strval(($h+1)*36e5 + $d*36e5*24 - 1000);
         }
         else {  // $days = *
            if ($composer_db['type']=='db2')
               $cond = ' > 3600000*24 AND MOD(INT('.$fname.'), 3600000*24) BETWEEN '. strval($h*36e5) . ' AND '. strval(($h+1)*36e5 - 1000);
            else
               $cond = ' > 3600000*24 AND MOD('.$fname.', 3600000*24) BETWEEN '. strval($h*36e5) . ' AND '. strval(($h+1)*36e5 - 1000);
         }
      }
      elseif($h!='*' && $m!='*'){   // hour:min [+days]
         if ( is_numeric($d)){
            if($d == -1){      // show all days
               if ($composer_db['type']=='db2')
                  $cond = ' > 0 AND MOD(INT('.$fname.'), 3600000*24) = '. strval($m*6e4 + $h*36e5 + $d*36e5*24);
               else
                  $cond = ' > 0 AND MOD('.$fname.', 3600000*24) = '. strval($m*6e4 + $h*36e5 + $d*36e5*24);
            }
            else
               $cond = ' = '. strval($m*6e4 + $h*36e5 + $d*36e5*24);
         }
         else{  // $days = *
            if ($composer_db['type']=='db2')
               $cond = ' > 3600000*24 AND MOD(INT('.$fname.'), 3600000*24) = '. strval($m*6e4 + $h*36e5 + $d*36e5*24);
            else
               $cond = ' > 3600000*24 AND MOD('.$fname.', 3600000*24) = '. strval($m*6e4 + $h*36e5 + $d*36e5*24);
         }
      }
      elseif($h=='*' && $m!='*'){   // *:min [+days]
         if ( is_numeric($d) ){
            if($d == -1){      // show all days
               if ($composer_db['type']=='db2')
                  $cond = ' > 0 AND MOD(INT('.$fname.'/60000),60) = '.$m;
               else
                  $cond = ' > 0 AND MOD('.$fname.'/60000, 60) = '.$m;
            }
            else{
               if ($composer_db['type']=='db2')
                  $cond = ' BETWEEN '. strval($d*36e5*24) . ' AND '. strval(($d+1)*36e5*24 - 1000) . ' AND MOD(INT('.$fname.'/60000), 60) = '.$m;
               else
                  $cond = ' BETWEEN '. strval($d*36e5*24) . ' AND '. strval(($d+1)*36e5*24 - 1000) . ' AND MOD('.$fname.'/60000, 60) = '.$m;
            }
         }
         else{  // $days = *
            if ($composer_db['type']=='db2')
               $cond = ' > 3600000*24 AND MOD(INT('.$fname.'/60000),60) = '.$m;
            else
               $cond = ' > 3600000*24 AND MOD('.$fname.'/60000, 60) = '.$m;
         }
      }
      else
         $cond = '';

   return($cond);
}

///////////////////////////////////////////////////////////////////////////////
//
// Get Jobstream runcycle data (ON +  EXCEPT + FREEDAYS)
//            (2nd page of "add jobstream")
// Arguments:
//    workstation = parameter name
//    jobstream   = jobstream name
//    validfrom   = valid from
//    sqlcond = sql filter - conditions of the where clause
//
function tws_get_jobstream_runcycle_data($workstation, $jobstream, $validfrom='', $rc_type='*', $rc_inclusive='*', $sqlcond='1=1'){
   global $tws_config, $composer_db;

   tws_log('-- tws_get_jobstream_runcycle_data (start at '.basename(__FILE__).'['.__LINE__.'])');
   tws_log("-- tws_get_jobstream_runcycle_data Parameters: workstation = $workstation, jobstream = $jobstream");

   if( ($workstation == '') || ($jobstream == '') ) {
      tws_error("workstation='$workstation', jobstream='$jobstream'","Database query error - missing argument(s)");
      return FALSE;
   }

   if($tws_config['cpuinfo']['version']>='9.5')
      list($jobstream_folder, $jobstream) = tws_explode_folder($jobstream);

   if($tws_config['cpuinfo']['version']>='9.5002')
      list($workstation_folder, $workstation) = tws_explode_folder($workstation);

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema = $composer_db['schema'];

   if ($validfrom == '') {
      $validfrom_expr = "JST_VALID_FROM IS NULL";
   } else {
      $validfrom_expr = "JST_VALID_FROM = '".db_string($composer_db,$validfrom)."'";
   }

   $query ="SELECT
            WKC.WKC_NAME         WORKSTATION,
            AJS.AJS_NAME         JOBSTREAM,
            JST.JST_VALID_FROM   VALID_FROM,
            RCY_TYPE             RC_TYPE,
            RCY_NAME             RC_NAME,
            RCY_DESCRIPTION      RC_DESCRIPTION,
            RCY_INCLUSIVE        RC_INCLUSIVE,
            RCY_VALID_FROM       RC_VALID_FROM,
            RCY_VALID_TO         RC_VALID_TO,
            RCY_TIME_DEPENDENT   RC_TIME_DEPENDENT,
            RCY_START_OFFSET     RC_AT,
            RCY_LATEST_START_OFFSET    RC_UNTIL,
            RCY_LATEST_START_ACTION    RC_ONUNTIL,
            RCY_DEADLINE_OFFSET        RC_DEADLINE,
            RCY_FREE_DAYS_RULE         RC_FREEDAYSRULE,
            RCY_ICALENDAR              RC_ICALENDAR,
            CAL.CAL_NAME               CALENDARNAME,
            RCY_OFFSET_TYPE            OFFSETTYPE,
            RCY_OFFSET_VALUE           OFFSETVALUE"
            .($tws_config['cpuinfo']['version']<='8.4' ? '' : ',
               VAT.VAT_NAME            RC_VAT_NAME')."
            ".($tws_config['cpuinfo']['version']>='9.1' ? ',
               RCG.RCG_NAME' : '')."
            ".($tws_config['cpuinfo']['version']>='9.3' ? ',
               RCY_REPEAT_INTERVAL     RC_EVERY,
               RCY_REPEAT_END_TIME     RC_EVERY_END_TIME' : '')."
            ".($tws_config['cpuinfo']['version']>'9.4' ? ',
               RCY_PROPAGATE_LATEST_START    RC_JSUNTIL' : '');
            if($tws_config['cpuinfo']['version'] >= '9.5002')
            $query .= ",
               CAL_FOL.FOL_PATH           CAL_FOLDER,
               VAT_FOL.FOL_PATH           VAT_FOLDER";
         $query .= "
         FROM (((((($schema.JST_JOB_STREAMS JST
             JOIN $schema.AJS_ABSTRACT_JOB_STREAMS AJS   ON AJS.AJS_ID = JST.AJS_ID)
             JOIN $schema.WKC_WORKSTATION_CLASSES WKC    ON WKC.WKC_ID = AJS.WKC_ID)
             JOIN $schema.RCY_RUN_CYCLES RCY             ON RCY.JST_ID = JST.JST_ID)
             LEFT JOIN $schema.CAL_CALENDARS CAL         ON CAL.CAL_ID = RCY.CAL_ID)
             ".($tws_config['cpuinfo']['version']<='8.4' ? '' : " LEFT JOIN $schema.VAT_VARIABLE_TABLES VAT ON RCY.VAT_ID = VAT.VAT_ID").")
             ".($tws_config['cpuinfo']['version']>='9.1' ? " LEFT JOIN $schema.RCG_RUN_CYCLE_GROUPS RCG ON RCY.RCG_ID = RCG.RCG_ID" : '').")";
         if($tws_config['cpuinfo']['version'] >= '9.5')
            $query .= "
               LEFT JOIN $schema.FOL_FOLDERS JS_FOL ON JS_FOL.FOL_ID = AJS.FOL_ID";
         if($tws_config['cpuinfo']['version'] >= '9.5002')
            $query .= "
               LEFT JOIN $schema.FOL_FOLDERS CAL_FOL  ON CAL_FOL.FOL_ID = CAL.FOL_ID
               LEFT JOIN $schema.FOL_FOLDERS WS_FOL   ON WS_FOL.FOL_ID = WKC.FOL_ID
               LEFT JOIN $schema.FOL_FOLDERS VAT_FOL  ON VAT_FOL.FOL_ID = VAT.FOL_ID
            ";
         $query .= "
         WHERE
            WKC_NAME = '".db_string($composer_db,$workstation)."' AND
            AJS_NAME = '".db_string($composer_db,$jobstream)."' AND
            $validfrom_expr AND
            RCY_TYPE ".tws_sqllike(db_string($composer_db,$rc_type))." AND
            RCY_INCLUSIVE ".tws_sqllike(db_string($composer_db,$rc_inclusive))." AND
            $sqlcond
            AND AJS.AJS_NAME = '$jobstream'";
         if($tws_config['cpuinfo']['version'] >= '9.5')
            $query .= "
               AND JS_FOL.FOL_PATH = '$jobstream_folder'";
         if($tws_config['cpuinfo']['version'] >= '9.5002')
            $query .= "
               AND WS_FOL.FOL_PATH = '$workstation_folder'";

   tws_log('tws_get_jobstream_runcycle_data DB query: '.$query);

   if( !($r=db_query($composer_db, $query)) ){
      tws_error('', 'Database query failed');
      return FALSE;
   }
   $stream2=Array(
      'rc'=>Array()
   );
   $i=0;
   $temp='';
   while ($row = db_fetch_row($composer_db)) {
      $stream2['rc']['rc_type'][$i]=$row['RC_TYPE'];
      $stream2['rc']['rc_on_except'][$i]=tws_yesno($row['RC_INCLUSIVE']);
      if ($stream2['rc']['rc_on_except'][$i] == "YES") {
         $stream2['rc']['rc_on_except'][$i] = "ON";
      } else {
         $stream2['rc']['rc_on_except'][$i] = "EXCEPT";
      }
      $stream2['rc']['rc_name'][$i]=$row['RC_NAME'];
      $stream2['rc']['rc_description'][$i]=$row['RC_DESCRIPTION'];

      $stream2['rc']['rc_freedaysrule'][$i]=tws_typeval('FREEDAYSRULE',$row['RC_FREEDAYSRULE']);
      if ( tws_yesno($row['RC_TIME_DEPENDENT']) == "YES")
         $stream2['rc']['rc_time_dep']["$i"]="YES";
      else {
         $stream2['rc']['rc_time_dep']["$i"]="NO";
      }
      $stream2['rc']['rc_validfrom'][$i]=tws_iso_to_userdate($row['RC_VALID_FROM'], null, true);
      $stream2['rc']['rc_validto'][$i]=tws_iso_to_userdate($row['RC_VALID_TO'], null, true);
      if($tws_config['cpuinfo']['version']>='9.5002')
          $vat_folder = $row['VAT_FOLDER'];
      else
         $vat_folder = '';
      $stream2['rc']['rc_parameter_table'][$i]=$vat_folder.$row['RC_VAT_NAME'];
/*
      if($tws_config['cpuinfo']['version']>='9.5002')
          $cal_folder = $row['CAL_FOLDER'];
      else
         $cal_folder = '';
*/
      tws_get_at_time($row['RC_AT'], $stream2['rc']['rc_athour'][$i], $stream2['rc']['rc_atminute'][$i], $temp, $stream2['rc']['rc_atplusdays'][$i]);
      tws_get_at_time($row['RC_UNTIL'], $stream2['rc']['rc_untilhour'][$i], $stream2['rc']['rc_untilminute'][$i], $temp, $stream2['rc']['rc_untilplusdays'][$i]);
      $stream2['rc']['rc_onuntil'][$i]=tws_typeval('ONUNTIL', $row['RC_ONUNTIL']);
      if($tws_config['cpuinfo']['version']>'9.4')
         $stream2['rc']['rc_jsuntil'][$i] = $row['RC_JSUNTIL'];      // 'YES' means normal UNTIL, otherwise - it's JSUNTILL
      tws_get_at_time($row['RC_DEADLINE'], $stream2['rc']['rc_deadlinehour'][$i], $stream2['rc']['rc_deadlineminute'][$i], $temp, $stream2['rc']['rc_deadlineplusdays'][$i]);
      if($tws_config['cpuinfo']['version']>='9.3'){   // EVERY
         tws_get_at_time($row['RC_EVERY'], $stream2['rc']['rc_everyhour'][$i], $stream2['rc']['rc_everyminute'][$i], $temp, $temp);
         tws_get_at_time($row['RC_EVERY_END_TIME'], $stream2['rc']['rc_everyendhour'][$i], $stream2['rc']['rc_everyendminute'][$i], $temp, $stream2['rc']['rc_everyendplusdays'][$i]);
      }
      switch ($row['RC_TYPE']) {
         case "R":
            // first ensure that the ICALENDAR field ends with semicolon:
            $row['RC_ICALENDAR']=preg_replace('/;+$/',';',rtrim($row['RC_ICALENDAR']).';');
            // parse ICalendar field now
            $parts=explode(';',$row['RC_ICALENDAR']);
            $stream2['rc']['rc_freq'][$i]=substr($parts[0],strpos($parts[0],'=')+1);
            if (trim(substr($parts[1],0,9))=='INTERVAL=') {
               $stream2['rc']['rc_interval'][$i]=substr($parts[1],9);
            } else {
               // no interval (==1) (last part=='')
               $stream2['rc']['rc_interval'][$i]=1;
               $parts[2]=$parts[1];
            }
            if (@($pos=strpos($parts[2],"="))!==FALSE) {
               $stream2['rc']['rc_bydays'][$i]=substr($parts[2],$pos+1);
            } else {
               @$stream2['rc']['rc_bydays'][$i]=$parts[2];
            }
            // if montly, set correct type of monthly
            if ($stream2['rc']['rc_freq'][$i]=='MONTHLY') {
               $days=explode(",",$stream2['rc']['rc_bydays'][$i]);
               foreach ($days as $day) {
                  if (!is_numeric($day)) $stream2['rc']['rc_freq'][$i] = "MONTHLY2";
               }
            }
            break;
         case "C":   // Calendar
            if($tws_config['cpuinfo']['version']>='9.5002')
               $cal_fol = $row['CAL_FOLDER'];
            else
               $cal_fol = '';
            $stream2['rc']['calendar'][$i] = $cal_fol.$row['CALENDARNAME'];
            $stream2['rc']['offsettype'][$i]=tws_typeval('CAL_OFFSET_TYPE',$row['OFFSETTYPE']);
            $stream2['rc']['offsetvalue'][$i]=$row['OFFSETVALUE'];
            break;
         case "S":  // Single Dates
            $dates=explode(",",$row['RC_ICALENDAR']);
            $s=0;
            foreach ($dates as $date) {
               //$stream2['date']['date_on_except'][$i]=tws_yesno($row['RC_INCLUSIVE']);
               if (preg_match("/^([0-9]{4})([0-9]{2})([0-9]{2})/",$date, $dat)) {
                  //$stream2['rc']['date_year'][$i][$s]=$dat[1];
                  //$stream2['rc']['date_month'][$i][$s]=$dat[2];
                  $stream2['rc']['date_day'][$i][$s]=$dat[1]."-".$dat[2]."-".$dat[3];
                  $stream2['rc']['date_day'][$i][$s] = tws_iso_to_userdate($stream2['rc']['date_day'][$i][$s], null, true);
               } else {
                  $stream2['rc']['date'][$i]="ERROR";
               }
               $s++;
            }
            break;
         case "G":   // Run Cycle Group
            $stream2['rc']['rcg'][$i]=$row['RCG_NAME'];
            $stream2['rc']['rcg_offsettype'][$i]=tws_typeval('CAL_OFFSET_TYPE', $row['OFFSETTYPE']);
            $stream2['rc']['rcg_offsetvalue'][$i]=$row['OFFSETVALUE'];
            break;
      }
      $i++;
   }
   $stream2['rc']['rc_num']=$i;
   tws_log('tws_get_jobstream_runcycle_data Result: '.var_export($stream2, true));
   return $stream2;
}

///////////////////////////////////////////////////////////////////////////////
//
// Get Jobstream dependencies on jobstrems
// Arguments:
//    workstation = parameter name
//    jobstream   = jobstream name
//    validfrom   = valid from
// !!! no wildcards allowed
//
function tws_get_jobstream_dep_jobstream($workstation, $jobstream, $validfrom=''){
   global $tws_config, $composer_db;

   tws_log('-- tws_get_jobstream_dep_jobstream (start at '.basename(__FILE__).'['.__LINE__.'])');

   if( ($workstation == '') || ($jobstream == '') ) {
      tws_error("workstation='$workstation', jobstream='$jobstream'","Database query error - missing argument(s)");
      return FALSE;
   }
   if ($tws_config['cpuinfo']['version']>='9.5')
      list($jobstream_folder, $jobstream) = tws_divide_folder($jobstream);
   if ($tws_config['cpuinfo']['version']>='9.5002')
      list($workstation_folder, $workstation) = tws_divide_folder($workstation);

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema = $composer_db['schema'];

    if ($validfrom == '') {
      $validfrom_expr = "DEP_JS.JST_VALID_FROM IS NULL";
      $st_name = 'STREAM_DEP_STREAM';
   } else {
      $validfrom_expr = "DEP_JS.JST_VALID_FROM = ?";
      $st_name = 'STREAM_DEP_STREAM_VALID';
   }

   $depstream=Array();
   //access rights checking
   $secsel = array('CPU'=>'WKC.WKC_NAME','NAME'=>'AJS.AJS_NAME');
   if ($tws_config['cpuinfo']['version']>='9.5')
       $secsel['FOLDER'] = 'FOL_PATH';
   if (($acc_sql=tws_sec_check('SCHEDULE', $secsel))===FALSE)
      return $depstream;

   if ($validfrom == '')
      $validfrom_expr = "DEP_JS.JST_VALID_FROM IS NULL";
   else $validfrom_expr = "DEP_JS.JST_VALID_FROM = ?";

   if(!isset($composer_db[$st_name])){
         $query = "
         SELECT
            DEP_WKC.WKC_NAME        WORKSTATION,
            DEP_AJS.AJS_NAME        JOBSTREAM,
            DEP_JS.JST_VALID_FROM   VALID_FROM,
            WKC.WKC_NAME            PRED_WORKSTATION,
            AJS.AJS_NAME            PRED_JOBSTREAM,
            FDP.FDP_RULE            MATCHING,
            FDP_RULE_START_OFFSET   MATCHING_FROM,
            FDP_RULE_END_OFFSET     MATCHING_TO";
         if ($tws_config['cpuinfo']['version']>='9.5'){
            $query .= ",
               JS_FOL.FOL_PATH      JS_FOLDER,
               DPJS_FOL.FOL_PATH    DPJS_FOLDER";
         }
         if ($tws_config['cpuinfo']['version']>='9.5002'){
            $query .= ",
               WS_FOL.FOL_PATH      WS_FOLDER,
               DPWS_FOL.FOL_PATH    DPWS_FOLDER
                ";
         }
         $query .= "
         FROM
            ((((($schema.AJS_ABSTRACT_JOB_STREAMS     AJS
            JOIN    $schema.WKC_WORKSTATION_CLASSES   WKC      ON AJS.WKC_ID = WKC.WKC_ID)
            JOIN    $schema.FDP_FOLLOWS_DEPS          FDP      ON AJS.AJS_ID = FDP.AJS_PRED_ID)
            JOIN    $schema.JST_JOB_STREAMS           DEP_JS   ON DEP_JS.JST_ID = FDP.JST_ID)
            JOIN    $schema.AJS_ABSTRACT_JOB_STREAMS  DEP_AJS  ON DEP_JS.AJS_ID = DEP_AJS.AJS_ID)
            JOIN    $schema.WKC_WORKSTATION_CLASSES   DEP_WKC  ON DEP_AJS.WKC_ID = DEP_WKC.WKC_ID)";
            if ($tws_config['cpuinfo']['version']>='9.5'){
               $query .= "
               LEFT JOIN $schema.FOL_FOLDERS    JS_FOL   ON JS_FOL.FOL_ID = DEP_AJS.FOL_ID
               LEFT JOIN $schema.FOL_FOLDERS    DPJS_FOL   ON AJS.FOL_ID = DPJS_FOL.FOL_ID ";
            }
            if ($tws_config['cpuinfo']['version']>='9.5002'){
               $query .= "
               LEFT JOIN $schema.FOL_FOLDERS    WS_FOL   ON WS_FOL.FOL_ID = DEP_WKC.FOL_ID
               LEFT JOIN $schema.FOL_FOLDERS    DPWS_FOL   ON WKC.FOL_ID = DPWS_FOL.FOL_ID

                ";
            }
         $query .= "
         WHERE
            FDP_TYPE = 'S' AND
            DEP_WKC.WKC_NAME = ? AND
            DEP_AJS.AJS_NAME = ? ";
         if ($tws_config['cpuinfo']['version']>='9.5')
            $query .= "
               AND JS_FOL.FOL_PATH = ?
               ";
         if ($tws_config['cpuinfo']['version']>='9.5002')
            $query .= "
               AND WS_FOL.FOL_PATH = ? ";
        $query .= $acc_sql;

      $stmt=new db_statement($composer_db, $query);
      if ($stmt->prepare()==FALSE){
         unset($stmt);
         tws_error('', 'Database query prepare failed: '.$query);
         return FALSE;
      }
      $composer_db[$st_name] = $stmt;
   }
   else $stmt = $composer_db[$st_name];

   $values = array(db_string($composer_db,$workstation), db_string($composer_db,$jobstream));
   if (!empty($validfrom))
      $values[] =  db_string($composer_db,$validfrom);
   if ($tws_config['cpuinfo']['version']>='9.5')
      $values[] = $jobstream_folder;
   if ($tws_config['cpuinfo']['version']>='9.5002')
      $values[] = $workstation_folder;

   tws_log("DB query: $query");
   tws_log('Query values: '.var_export($values, true));

   if ($stmt->execute($values)==false){
      tws_error('', 'Database query failed: '.$query);
      return FALSE;
   }

   $i=0;
   $temp='';
   while( $stmt->fetch() ){
      $row = $stmt->row();
      tws_log('Row: '.var_export($row, true));
      $pred_workstation = $row['PRED_WORKSTATION'];
      $pred_jobstream = $row['PRED_JOBSTREAM'];
      if ($tws_config['cpuinfo']['version']>='9.5')
          $pred_jobstream = $row['DPJS_FOLDER']. $pred_jobstream;
      if ($tws_config['cpuinfo']['version']>='9.5002')
          $pred_workstation = $row['DPWS_FOLDER'].$pred_workstation;

      $depstream['followsjobstreamcpu'][$i]=$pred_workstation;
      $depstream['followsjobstreamname'][$i]=$pred_jobstream;
      $depstream['followsjobstreammatching'][$i]=tws_typeval('MATCHING',$row['MATCHING']);


      // the same with indexes for Netplan
         $depstream['dep_cpu'][$i] = $depstream['followsjobstreamcpu'][$i];
         $depstream['dep_jobstream'][$i] = $depstream['followsjobstreamname'][$i];
         $depstream['match'][$i] = $depstream['followsjobstreammatching'][$i];
         $depstream['match_from'][$i] = $row['MATCHING_FROM'];
         $depstream['match_to'][$i] = $row['MATCHING_TO'];
      $i++;
   }
   tws_log('Query results: '.var_export($depstream, true));

// Conditional Stream <- Stream dependency
   if($tws_config['cpuinfo']['version']>='9.3'){
      if ($validfrom == '')
         $validfrom_expr = "DEP_JS.JST_VALID_FROM IS NULL";
      else $validfrom_expr = "DEP_JS.JST_VALID_FROM = '".db_string($composer_db,$validfrom)."'";
      // TODO: access rights checking
//     if (($acc_sql=tws_sec_check('SCHEDULE', array('CPU'=>'WKC.WKC_NAME','NAME'=>'JS.AJS_NAME')))===FALSE) return $depstream;

   $query = "
   SELECT
       WKC.WKC_NAME WKS_NAME,
       JS.AJS_NAME STREAM_NAME,

       DEP_WKC.WKC_NAME DEP_WKS_NAME,
       DEP_AJS.AJS_NAME DEP_STREAM_NAME,
       DEP_JS.JST_VALID_FROM DEP_STREAM_VALID_FROM,
       DEP_JS.JST_VALID_TO DEP_STREAM_VALID_TO,
       $schema.CDP_CONDITIONAL_DEPS.CDP_SUCCESS ON_SUCCESS,
       $schema.CDP_CONDITIONAL_DEPS.CDP_ABEND ON_ABEND,
       $schema.CDP_CONDITIONAL_DEPS.CDP_SUPPRESS ON_SUPPRESS,
       $schema.CDP_CONDITIONAL_DEPS.CDP_RULE MATCHING,
       $schema.CDP_CONDITIONAL_DEPS.CDP_RULE_START_OFFSET MATCHING_FROM,
       $schema.CDP_CONDITIONAL_DEPS.CDP_RULE_END_OFFSET MATCHING_TO,
       CJO.CJO_NAME JOIN_NAME,
       CJO.CJO_QUANTITY JOIN_QUANTITY,
       CJO.CJO_DESCRIPTION JOIN_DESCRIPTION";
       if ($tws_config['cpuinfo']['version']>='9.5'){
           $query .= ",
               JS_FOL.FOL_PATH      JS_FOLDER,
               DPJS_FOL.FOL_PATH    DPJS_FOLDER";
       }
       if ($tws_config['cpuinfo']['version']>='9.5002'){
           $query .= ",
               WS_FOL.FOL_PATH      WS_FOLDER,
               DPWS_FOL.FOL_PATH    DPWS_FOLDER
                ";
       }
        $query .= "   FROM (((((($schema.AJS_ABSTRACT_JOB_STREAMS JS
     JOIN $schema.WKC_WORKSTATION_CLASSES WKC ON JS.WKC_ID = WKC.WKC_ID)
     JOIN $schema.CDP_CONDITIONAL_DEPS ON JS.AJS_ID = $schema.CDP_CONDITIONAL_DEPS.AJS_PRED_ID)
     JOIN $schema.JST_JOB_STREAMS DEP_JS ON DEP_JS.JST_ID = $schema.CDP_CONDITIONAL_DEPS.JST_ID)
     JOIN $schema.AJS_ABSTRACT_JOB_STREAMS DEP_AJS ON DEP_JS.AJS_ID = DEP_AJS.AJS_ID)
     JOIN $schema.WKC_WORKSTATION_CLASSES DEP_WKC ON DEP_AJS.WKC_ID = DEP_WKC.WKC_ID)
     LEFT JOIN $schema.CJO_CONDITIONAL_JOIN CJO ON CJO.CJO_ID = $schema.CDP_CONDITIONAL_DEPS.CJO_ID)";
     if($tws_config['cpuinfo']['version']>='9.5')
          $query .="
          LEFT JOIN $schema.FOL_FOLDERS             JS_FOL   ON JS_FOL.FOL_ID = DEP_AJS.FOL_ID
          LEFT JOIN $schema.FOL_FOLDERS      DPJS_FOL   ON JS.FOL_ID = DPJS_FOL.FOL_ID ";
      if($tws_config['cpuinfo']['version']>='9.5002')
          $query .="
          LEFT JOIN $schema.FOL_FOLDERS             WS_FOL   ON WS_FOL.FOL_ID = DEP_WKC.FOL_ID
          LEFT JOIN $schema.FOL_FOLDERS             DPWS_FOL   ON WKC.FOL_ID = DPWS_FOL.FOL_ID ";
   $query .= "
   WHERE
      DEP_WKC.WKC_NAME = '".db_string($composer_db, $workstation)."' AND
      DEP_AJS.AJS_NAME = '".db_string($composer_db, $jobstream)."' AND
      CDP_TYPE = 'S'";
      if ($tws_config['cpuinfo']['version']>='9.5')
         $query .= "
            AND JS_FOL.FOL_PATH = '$jobstream_folder'";
      if ($tws_config['cpuinfo']['version'] >= '9.5002')
         $query .= "
            AND WS_FOL.FOL_PATH = '$workstation_folder'";

   tws_log('Condition stream_dep_stream DB query: '.$query);

      if (!(db_query($composer_db, $query))) {
         tws_error('', 'Database query failed');
         return $depstream;
      }
      while(($row = db_fetch_row( $composer_db)) != false){
         // indexes used in Netplan
          tws_log('query output row '.var_export($row, true));
          $pred_workstation = $row['WKS_NAME'];
          $pred_jobstream = $row['STREAM_NAME'];
          if ($tws_config['cpuinfo']['version']>='9.5')
              $pred_jobstream = $row['DPJS_FOLDER']. $pred_jobstream;
          if ($tws_config['cpuinfo']['version']>='9.5002')
              $pred_workstation = $row['DPWS_FOLDER'].$pred_workstation;
         $depstream['dep_cpu'][$i] = $pred_workstation;
         $depstream['dep_jobstream'][$i] = $pred_jobstream;

         $depstream['match'][$i] = tws_typeval('MATCHING', $row['MATCHING']);
         $depstream['match_from'][$i] = $row['MATCHING_FROM'];
         $depstream['match_to'][$i] = $row['MATCHING_TO'];

      // indexes used in forms
         $depstream['followsjobstreamcpu'][$i]=$depstream['dep_cpu'][$i];
         $depstream['followsjobstreamname'][$i]=$depstream['dep_jobstream'][$i];
         $depstream['followsjobstreammatching'][$i]=$depstream['match'][$i];

         $depstream['js_js_success'][$i] =   $row['ON_SUCCESS'];
         $depstream['js_js_abend'][$i] =     $row['ON_ABEND'];
         $depstream['js_js_suppress'][$i] =  $row['ON_SUPPRESS'];

         $depstream['js_js_join_name'][$i] =  $row['JOIN_NAME'];
         $depstream['js_js_join_quantity'][$i] =  $row['JOIN_QUANTITY'];
         $depstream['js_js_join_description'][$i] =  $row['JOIN_DESCRIPTION'];

         $i++;
      }
   tws_log('Condition stream_dep_stream query Result: '.var_export($depstream, true));
   }

   $depstream['followsjobstream_num']=$i;
   $depstream['count']=$i;

   if(empty($depstream['match'])) $depstream['match'] = array();
   foreach($depstream['match'] as $i => $match){
      switch ($depstream['followsjobstreammatching'][$i]) {
         case "RELATIVE":
            if ($depstream['match_from'][$i] < 0) {
               $depstream['match_from'][$i] *= -1;
               $depstream['followsjobstreammatchingrelativefromdir'][$i] = "-";
            } else { $depstream['followsjobstreammatchingrelativefromdir'][$i] = "+"; }
            tws_get_at_time(($depstream['match_from'][$i]),
                     $depstream['followsjobstreammatchingrelativefromhour'][$i],
                     $depstream['followsjobstreammatchingrelativefromminute'][$i],
                     $temp, $temp, 'RELATIVE_OFFSET');
            if ($depstream['match_to'][$i] < 0) {
               $depstream['match_to'][$i] *= -1;
               $depstream['followsjobstreammatchingrelativetodir'][$i] = "-";
            } else { $depstream['followsjobstreammatchingrelativetodir'][$i] = "+"; }
            tws_get_at_time($depstream['match_to'][$i],
                  $depstream['followsjobstreammatchingrelativetohour'][$i],
                  $depstream['followsjobstreammatchingrelativetominute'][$i],
                  $temp, $temp, 'RELATIVE_OFFSET');
            break;
         case "ABSOLUTE":
            $day = (1000 * 60 * 60 * 24);
            if ($depstream['match_from'][$i] < 0) {
               $depstream['followsjobstreammatchingabsolutefromdir'][$i] = "-";
               $depstream['followsjobstreammatchingabsolutefromdays'][$i]= strval(-1*(floor($depstream['match_from']/($day))));
               $rest = ($depstream['match_from'][$i]%($day)+($day));
               tws_get_at_time($rest,$depstream['followsjobstreammatchingabsolutefromhour'][$i],
                     $depstream['followsjobstreammatchingabsolutefromminute'][$i],
                     $temp, $temp);
            } else {
               tws_get_at_time($depstream['match_from'][$i],$depstream['followsjobstreammatchingabsolutefromhour'][$i],
                  $depstream['followsjobstreammatchingabsolutefromminute'][$i],$temp,
                  $depstream['followsjobstreammatchingabsolutefromdays'][$i]);
               $depstream['followsjobstreammatchingabsolutefromdir'][$i] = "+";
            }
            if ($depstream['match_to'][$i] < 0) {
               $depstream['followsjobstreammatchingabsolutetodir'][$i] = "-";
               $depstream['followsjobstreammatchingabsolutetodays'][$i]= strval(-1*(floor($depstream['match_to']/($day))));
               $rest = ($depstream['match_to'][$i]%($day)+($day));
               tws_get_at_time($rest,$depstream['followsjobstreammatchingabsolutetohour'][$i],
                     $depstream['followsjobstreammatchingabsolutetominute'][$i],
                     $temp,$temp);
            } else {
               tws_get_at_time($depstream['match_to'][$i],$depstream['followsjobstreammatchingabsolutetohour'][$i],
                     $depstream['followsjobstreammatchingabsolutetominute'][$i],$temp,
                     $depstream['followsjobstreammatchingabsolutetodays'][$i]);
               $depstream['followsjobstreammatchingabsolutetodir'][$i] = "+";
            }
         }
   }
   tws_log('Result: '.var_export($depstream, true));
   return $depstream;
}

///////////////////////////////////////////////////////////////////////////////
//
// Get Jobstream dependencies on job
// Arguments:
//    workstation = parameter name
//    jobstream   = jobstream name
//    validfrom   = valid from
//    sqlcond = sql filter - conditions of the where clause
//    sqlcond removed - it is not used, and can't be used with prepared statements
// !!! no wildcards allowed
//
function tws_get_jobstream_dep_job($workstation, $jobstream, $validfrom=''){
   global $tws_config, $composer_db;
   tws_log('-- tws_get_jobstream_dep_job (start at '.basename(__FILE__).'['.__LINE__.'])');

   if( ($workstation == '') || ($jobstream == '') ) {
      tws_error("workstation='$workstation', jobstream='$jobstream'","Database query error - missing argument(s)");
      return FALSE;
   }
   if ($tws_config['cpuinfo']['version']>='9.5')
      list($jobstream_folder, $jobstream) = tws_divide_folder($jobstream);
   if ($tws_config['cpuinfo']['version']>='9.5002')
      list($workstation_folder, $workstation) = tws_divide_folder($workstation);

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema = $composer_db['schema'];
   if ($validfrom == '') {
      $validfrom_expr = "DEP_JS.JST_VALID_FROM IS NULL";
      $st_name = 'STREAM_DEP_JOB';
   } else {
      $validfrom_expr = "DEP_JS.JST_VALID_FROM = ?";
      $st_name = 'STREAM_DEP_JOB_VALID';
   }
   $depjob=array();
   //access rights checking      ,'JOB'=>'JOB.AJB_NAME'
  $secsel= array('CPU'=>'WKC.WKC_NAME','NAME'=>'AJS.AJS_NAME' );
   if ($tws_config['cpuinfo']['version']>='9.5')
       $secsel['FOLDER'] = 'FOL_PATH';
   if (($acc_sql=tws_sec_check('SCHEDULE',$secsel))===FALSE) return $depjob;

   if(!isset($composer_db[$st_name])){
      $query = "
         SELECT
           DEP_WKC.WKC_NAME      WORKSTATION,
           DEP_AJS.AJS_NAME      JOBSTREAM,
           DEP_JS.JST_VALID_FROM VALID_FROM,

           WKC.WKC_NAME          PRED_WORKSTATION,
           AJS.AJS_NAME          PRED_JOBSTREAM,
           JOB.AJB_NAME          PRED_JOB,
           FDP.FDP_RULE          MATCHING,
           FDP.FDP_RULE_START_OFFSET   MATCHING_FROM,
           FDP.FDP_RULE_END_OFFSET     MATCHING_TO";
         if($tws_config['cpuinfo']['version']>='9.5' ){
            $query .= ",
               JS_FOL.FOL_PATH   JS_FOLDER,
                DPJS_FOL.FOL_PATH    DPJS_FOLDER " ;     // 9.5 folders
         }
         if($tws_config['cpuinfo']['version']>='9.5002' ){
            $query .= ",
               WS_FOL.FOL_PATH   WS_FOLDER,
               DPWS_FOL.FOL_PATH    DPWS_FOLDER " ;     // 9.5 folders
         }
      $query .="
         FROM    (((((($schema.AJB_ABSTRACT_JOBS      JOB
            JOIN    $schema.AJS_ABSTRACT_JOB_STREAMS  AJS      ON JOB.AJS_ID = AJS.AJS_ID)
            JOIN    $schema.WKC_WORKSTATION_CLASSES   WKC      ON AJS.WKC_ID = WKC.WKC_ID)
            JOIN    $schema.FDP_FOLLOWS_DEPS          FDP      ON JOB.AJB_ID = FDP.AJB_PRED_ID)
            JOIN    $schema.JST_JOB_STREAMS           DEP_JS   ON DEP_JS.JST_ID = FDP.JST_ID)
            JOIN    $schema.AJS_ABSTRACT_JOB_STREAMS  DEP_AJS  ON DEP_JS.AJS_ID = DEP_AJS.AJS_ID)
            JOIN    $schema.WKC_WORKSTATION_CLASSES   DEP_WKC  ON DEP_AJS.WKC_ID = DEP_WKC.WKC_ID)";
            if($tws_config['cpuinfo']['version']>='9.5')
               $query .="
               LEFT JOIN $schema.FOL_FOLDERS             JS_FOL   ON JS_FOL.FOL_ID = DEP_AJS.FOL_ID
               LEFT JOIN $schema.FOL_FOLDERS      DPJS_FOL   ON AJS.FOL_ID = DPJS_FOL.FOL_ID ";
            if($tws_config['cpuinfo']['version']>='9.5002')
               $query .="
               LEFT JOIN $schema.FOL_FOLDERS             WS_FOL   ON WS_FOL.FOL_ID = DEP_WKC.FOL_ID
               LEFT JOIN $schema.FOL_FOLDERS             DPWS_FOL   ON WKC.FOL_ID = DPWS_FOL.FOL_ID ";
      $query .= "
         WHERE   FDP_TYPE = 'J' AND
            DEP_WKC.WKC_NAME = ? AND
            DEP_AJS.AJS_NAME = ? AND
            $validfrom_expr
            $acc_sql";
      if ($tws_config['cpuinfo']['version']>='9.5')
         $query .= "
            AND JS_FOL.FOL_PATH = ?";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
            AND WS_FOL.FOL_PATH = ?";

      $stmt=new db_statement($composer_db, $query);
      if ($stmt->prepare()==FALSE){
         unset($stmt);
         tws_error('', 'Database query prepare failed: '.$query);
         return FALSE;
      }
      $composer_db[$st_name] = $stmt;
   }
   else $stmt = $composer_db[$st_name];

   $values = array(db_string($composer_db,$workstation), db_string($composer_db,$jobstream));
   if (!empty($validfrom))
      $values[] =  db_string($composer_db,$validfrom);
   if ($tws_config['cpuinfo']['version']>='9.5')
      $values[] = db_string($composer_db, $jobstream_folder);
   if ($tws_config['cpuinfo']['version']>='9.5002')
      $values[] = db_string($composer_db, $workstation_folder);

   tws_log('DB query: '.$stmt->sql());
   tws_log('Query values: '.var_export($values, true));

   if ($stmt->execute($values)==false){
      tws_error('', 'Database query failed: '.$query);
      return FALSE;
   }

   $i=0;
   $temp='';
   while( $stmt->fetch() ){
      $row = $stmt->row();
      tws_log('DB query result row '.var_export($row, true));
      $pred_workstation = $row['PRED_WORKSTATION'];
      $pred_jobstream = $row['PRED_JOBSTREAM'];
      if ($tws_config['cpuinfo']['version']>='9.5')
          $pred_jobstream = $row['DPJS_FOLDER']. $pred_jobstream;
      if ($tws_config['cpuinfo']['version']>='9.5002')
          $pred_workstation = $row['DPWS_FOLDER'].$pred_workstation;
      $depjob['followsjobcpu'][$i]=$pred_workstation;
      $depjob['followsjobjobstream'][$i]=$pred_jobstream;
      if(!empty($row['FOL_PATH']))
         $depjob['followsjobfolder'][$i] = $row['FOL_PATH'];
      $depjob['followsjobname'][$i]=$row['PRED_JOB'];
      $depjob['followsjobmatching'][$i]=tws_typeval('MATCHING',$row['MATCHING']);
      // the same for NetPlan
      $depjob['dep_cpu'][$i] = $depjob['followsjobcpu'][$i];
      $depjob['dep_jobstream'][$i] = $depjob['followsjobjobstream'][$i];
      $depjob['dep_job'][$i] = $depjob['followsjobname'][$i];
      $depjob['match'][$i] = $depjob['followsjobmatching'][$i];
      $depjob['match_from'][$i] = $row['MATCHING_FROM'];
      $depjob['match_to'][$i] = $row['MATCHING_TO'];

      $i++;
   }

// Conditional Jobstream -> Job dependency
if($tws_config['cpuinfo']['version']>='9.3'){

   if ($validfrom == '')
      $validfrom_expr = "DEP_JS.JST_VALID_FROM IS NULL";
   else
      $validfrom_expr = "DEP_JS.JST_VALID_FROM = '".db_string($composer_db, $validfrom)."'";

   // TODO: access rights checking
   // if (($acc_sql=tws_sec_check('JOB', array('CPU'=>'PRED_WKC.WKC_NAME','NAME'=>'PRED_AJS.AJS_NAME')))===FALSE) return $depstream;

      $query = "
      SELECT
          JOB.AJB_NAME PRED_JOB,
          WKC.WKC_NAME PRED_WKS,
          JS.AJS_NAME PRED_STREAM,

          DEP_WKC.WKC_NAME DEP_WKS,
          DEP_AJS.AJS_NAME DEP_STREAM,
          $schema.CDP_CONDITIONAL_DEPS.CDP_SUCCESS ON_SUCCESS,
          $schema.CDP_CONDITIONAL_DEPS.CDP_ABEND ON_ABEND,
          $schema.CDP_CONDITIONAL_DEPS.CDP_FAIL ON_FAIL,
          $schema.CDP_CONDITIONAL_DEPS.CDP_EXECUTE ON_EXECUTE,
          $schema.CDP_CONDITIONAL_DEPS.CDP_SUPPRESS ON_SUPPRESS,
         $schema.CDP_CONDITIONAL_DEPS.CDP_RULE MATCHING,
         $schema.CDP_CONDITIONAL_DEPS.CDP_RULE_START_OFFSET MATCHING_FROM,
         $schema.CDP_CONDITIONAL_DEPS.CDP_RULE_END_OFFSET MATCHING_TO,
         CJO.CJO_NAME JOIN_NAME,
         CJO.CJO_QUANTITY JOIN_QUANTITY,
         CJO.CJO_DESCRIPTION JOIN_DESCRIPTION";
         if($tws_config['cpuinfo']['version']>='9.5' ){
             $query .= ",
               JS_FOL.FOL_PATH   JS_FOLDER,
                DPJS_FOL.FOL_PATH    DPJS_FOLDER " ;// 9.5 folders
         }
         if($tws_config['cpuinfo']['version']>='9.5002' ){
             $query .= ",
               WS_FOL.FOL_PATH   WS_FOLDER,
               DPWS_FOL.FOL_PATH    DPWS_FOLDER " ;     // 9.5 folders
         }
      $query .="
      FROM   ((((((($schema.AJB_ABSTRACT_JOBS JOB
        JOIN $schema.AJS_ABSTRACT_JOB_STREAMS JS ON JOB.AJS_ID = JS.AJS_ID)
        JOIN $schema.WKC_WORKSTATION_CLASSES WKC ON JS.WKC_ID = WKC.WKC_ID)
        JOIN $schema.CDP_CONDITIONAL_DEPS ON JOB.AJB_ID = $schema.CDP_CONDITIONAL_DEPS.AJB_PRED_ID)
        JOIN $schema.JST_JOB_STREAMS DEP_JS ON DEP_JS.JST_ID = $schema.CDP_CONDITIONAL_DEPS.JST_ID)
        JOIN $schema.AJS_ABSTRACT_JOB_STREAMS DEP_AJS ON DEP_JS.AJS_ID = DEP_AJS.AJS_ID)
        JOIN $schema.WKC_WORKSTATION_CLASSES DEP_WKC ON DEP_AJS.WKC_ID = DEP_WKC.WKC_ID)
        LEFT JOIN $schema.CJO_CONDITIONAL_JOIN CJO ON CJO.CJO_ID = $schema.CDP_CONDITIONAL_DEPS.CJO_ID)";
      if($tws_config['cpuinfo']['version']>='9.5')
         $query .= "
            LEFT JOIN $schema.FOL_FOLDERS JS_FOL ON JS_FOL.FOL_ID = DEP_AJS.FOL_ID
            LEFT JOIN $schema.FOL_FOLDERS      DPJS_FOL   ON JS.FOL_ID = DPJS_FOL.FOL_ID   ";
      if($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
            LEFT JOIN $schema.FOL_FOLDERS WS_FOL ON WS_FOL.FOL_ID = DEP_WKC.FOL_ID
            LEFT JOIN $schema.FOL_FOLDERS DPWS_FOL   ON WKC.FOL_ID = DPWS_FOL.FOL_ID ";
      $query .= "
      WHERE  CDP_TYPE = 'J' AND
           DEP_WKC.WKC_NAME = '".db_string($composer_db, $workstation)."' AND
           DEP_AJS.AJS_NAME = '".db_string($composer_db, $jobstream)."'
         AND $validfrom_expr";
      if ($tws_config['cpuinfo']['version']>='9.5')
         $query .= "
            AND JS_FOL.FOL_PATH = '$jobstream_folder'";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
            AND WS_FOL.FOL_PATH = '$workstation_folder'";



      tws_log("Conditional stream_to_job DB query : $query");

      if (!($r=db_query($composer_db, $query))) {
         tws_error('', "Database query failed: $query");
         return $depjob;
      }
      while(($row = db_fetch_row( $composer_db)) != false){
          tws_log('DB query result row '.var_export($row, true));
          $pred_workstation = $row['PRED_WKS'];
          $pred_jobstream = $row['PRED_STREAM'];
          if ($tws_config['cpuinfo']['version']>='9.5')
              $pred_jobstream = $row['DPJS_FOLDER']. $pred_jobstream;
         if ($tws_config['cpuinfo']['version']>='9.5002')
              $pred_workstation = $row['DPWS_FOLDER'].$pred_workstation;
         $depjob['followsjobcpu'][$i]=$pred_workstation;
         $depjob['followsjobjobstream'][$i]=$pred_jobstream;
         if(!empty($row['FOL_PATH']))
            $depjob['followsjobfolder'][$i] = $row['FOL_PATH'];

         $depjob['followsjobname'][$i]=$row['PRED_JOB'];
         $depjob['followsjobmatching'][$i]=tws_typeval('MATCHING',$row['MATCHING']);
         $depjob['match_from'][$i] = $row['MATCHING_FROM'];
         $depjob['match_to'][$i] = $row['MATCHING_TO'];

         $depjob['js_job_success'][$i] =   $row['ON_SUCCESS'];
         $depjob['js_job_abend'][$i] =     $row['ON_ABEND'];
         $depjob['js_job_suppress'][$i] =  $row['ON_SUPPRESS'];
         $depjob['js_job_fail'][$i] =  $row['ON_FAIL'];
         $depjob['js_job_execute'][$i] =  $row['ON_EXECUTE'];

         $depjob['js_job_join_name'][$i] =  $row['JOIN_NAME'];
         $depjob['js_job_join_quantity'][$i] =  $row['JOIN_QUANTITY'];
         $depjob['js_job_join_description'][$i] =  $row['JOIN_DESCRIPTION'];

         // the same for NetPlan
         $depjob['dep_cpu'][$i] = $depjob['followsjobcpu'][$i];
         $depjob['dep_jobstream'][$i] = $depjob['followsjobjobstream'][$i];
         $depjob['dep_job'][$i] = $depjob['followsjobname'][$i];
         $depjob['match'][$i] = $depjob['followsjobmatching'][$i];

         // For custom (named) jobs conditions if so
         $depjob['cdp_id'][$i] =  $row['CDP_ID'];
         $i++;
      }
      // Raise custom (named) jobs conditions if so
      if(!empty($depjob['cdp_id'])){
         $in = '';
         foreach($depjob['cdp_id'] as $cdp_id){
            $hex_id = ($composer_db['type']=='db2' ? "x'$cdp_id'" : "HEXTORAW('$cdp_id')");
            $in .= strtolower("$hex_id,");
         }
         $in = substr($in, 0, -1);
         $raw_to_hex_fce = ($composer_db['type']=='db2' ? "HEX" : "RAWTOHEX");
         $query = "SELECT
            JOC.JOC_NAME,
            $raw_to_hex_fce(CDP.CDP_ID) CDP_ID
         FROM $schema.JOC_JOB_OUTPUT_CONDITIONS JOC
            JOIN $schema.CDR_CONDITIONAL_DEPS_REFS CDP ON CDP.JOC_ID = JOC.JOC_ID
         WHERE CDP.CDP_ID IN ($in)";

         if (!db_query($composer_db, $query)) {
            tws_error('', 'Database query failed');
            return $depjob;
         }

         while(($row = db_fetch_row( $composer_db)) != false){
            $tmp[$row['CDP_ID']][] = $row['JOC_NAME'];
         }

         foreach($depjob['cdp_id'] as $k=>$cdp_id){
            $l=0;
            if(empty($tmp[$cdp_id])) $tmp[$cdp_id] = array();  // no codemaps
            foreach($tmp[$cdp_id] as $condition){
               $depjob['js_job_condition'][$k][$l] = $condition;
               $l++;
            }
         }
      }
   // Raise dep_job return code mappings
      if(empty($depjob['dep_job'])) $depjob['dep_job'] = array(); // no job deps
      foreach($depjob['dep_job'] as $k=>$depjobname){
         // if(empty($depjob['cdp_id'])) continue;  need for all dep jobs
         if(empty($depjob['dep_cpu'][$k]) )
            $depcpu = $workstation;
         else $depcpu = $depjob['dep_cpu'][$k];
         $arr = tws_get_job_codemap($depcpu, $depjobname);
         if(!empty($arr['joc_name'])){
            foreach($arr['joc_name'] as $l=>$codemap){
               $depjob['js_job_codemaps'][$k][$l] = $codemap;
            }
         }
   }
}
   $depjob['followsjob_num']=$i;
   $depjob['count']=$i;

   if(empty($depjob['followsjobmatching'])) $depjob['followsjobmatching'] = array();
   foreach($depjob['followsjobmatching'] as $i=>$match){
      switch ($depjob['followsjobmatching'][$i]) {
         case "RELATIVE":
            if ($depjob['match_from'][$i] < 0) {
               $depjob['match_from'][$i] *= -1;
               $depjob['followsjobmatchingrelativefromdir'][$i] = "-";
            } else { $depjob['followsjobmatchingrelativefromdir'][$i] = "+"; }
            tws_get_at_time(($depjob['match_from'][$i]),
                     $depjob['followsjobmatchingrelativefromhour'][$i],
                     $depjob['followsjobmatchingrelativefromminute'][$i],
                     $temp,$temp, 'RELATIVE_OFFSET');
            if ($depjob['match_to'][$i] < 0) {
               $depjob['match_to'][$i] *= -1;
               $depjob['followsjobmatchingrelativetodir'][$i] = "-";
            } else { $depjob['followsjobmatchingrelativetodir'][$i] = "+"; }
            tws_get_at_time($depjob['match_to'][$i],
                  $depjob['followsjobmatchingrelativetohour'][$i],
                  $depjob['followsjobmatchingrelativetominute'][$i],
                  $temp, $temp, 'RELATIVE_OFFSET');
            break;
         case "ABSOLUTE":
            $day = (1000 * 60 * 60 * 24);
            if ($depjob['match_from'][$i] < 0) {
               $depjob['followsjobmatchingabsolutefromdir'][$i] = "-";
               $depjob['followsjobmatchingabsolutefromdays'][$i]= strval(-1*(floor($depjob['match_from'][$i]/($day))));
               $rest = ($depjob['match_from'][$i]%($day)+($day));
               tws_get_at_time($rest,$depjob['followsjobmatchingabsolutefromhour'][$i],
                     $depjob['followsjobmatchingabsolutefromminute'][$i],
                     $temp, $temp);
            } else {
               tws_get_at_time($depjob['match_from'][$i],$depjob['followsjobmatchingabsolutefromhour'][$i],
                  $depjob['followsjobmatchingabsolutefromminute'][$i],$temp,
                  $depjob['followsjobmatchingabsolutefromdays'][$i]);
               $depjob['followsjobmatchingabsolutefromdir'][$i] = "+";
            }
            if ($depjob['match_to'][$i] < 0) {
               $depjob['followsjobmatchingabsolutetodir'][$i] = "-";
               $depjob['followsjobmatchingabsolutetodays'][$i]= strval(-1*(floor($depjob['match_to'][$i]/($day))));
               $rest = ($depjob['match_to'][$i]%($day)+($day));
               tws_get_at_time($rest,$depjob['followsjobmatchingabsolutetohour'][$i],
                     $depjob['followsjobmatchingabsolutetominute'][$i],
                     $temp, $temp);
            } else {
               tws_get_at_time($depjob['match_to'][$i],$depjob['followsjobmatchingabsolutetohour'][$i],
                     $depjob['followsjobmatchingabsolutetominute'][$i],$temp,
                     $depjob['followsjobmatchingabsolutetodays'][$i]);
               $depjob['followsjobmatchingabsolutetodir'][$i] = "+";
            }
      }
   }
   tws_log('Result: '.var_export($depjob, true));
   return $depjob;
}

///////////////////////////////////////////////////////////////////////////////
//
// Get Jobstream internetwork dependencies
// Arguments:
//    workstation = parameter name
//    jobstream   = jobstream name
//    validfrom   = valid from
// !!! no wildcards allowed
//
function tws_get_jobstream_dep_net($workstation, $jobstream, $validfrom=''){
   global $tws_config, $composer_db;
   tws_log('-- tws_get_jobstream_dep_net (start at '.basename(__FILE__).'['.__LINE__.'])');

   if( ($workstation == '') || ($jobstream == '') ) {
      tws_error("workstation='$workstation', jobstream='$jobstream'","Database query error - missing argument(s)");
      return FALSE;
   }

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
    if ($tws_config['cpuinfo']['version'] >= '9.5')
        list($jobstream_folder, $jobstream) = tws_divide_folder($jobstream);
    if ($tws_config['cpuinfo']['version'] >= '9.5002')
        list($workstation_folder, $workstation) = tws_divide_folder($workstation);
   $schema = $composer_db['schema'];
   if ($validfrom == '') {
      $validfrom_expr = "JST.JST_VALID_FROM IS NULL";
      $st_name = 'STREAM_DEP_NET';
   } else {
      $validfrom_expr = "JST.JST_VALID_FROM = ?";
      $st_name = 'STREAM_DEP_NET_VALID';
   }

   if(!isset($composer_db[$st_name])){
      $query = "
         SELECT
            WKC.WKC_NAME WORKSTATION,
            AJS.AJS_NAME JOBSTREAM,
            JST.JST_VALID_FROM VALID_FROM,
            NDP_WKC.WKC_NAME AGENT,
            NDP_VALUE DEPENDENCY
         FROM (((($schema.NDP_NETWORK_DEPS NDP
             JOIN $schema.JST_JOB_STREAMS JST            ON NDP.JST_ID = JST.JST_ID)
             JOIN $schema.AJS_ABSTRACT_JOB_STREAMS AJS   ON AJS.AJS_ID = JST.AJS_ID)
             JOIN $schema.WKC_WORKSTATION_CLASSES WKC    ON WKC.WKC_ID = AJS.WKC_ID)
             JOIN $schema.WKC_WORKSTATION_CLASSES NDP_WKC ON NDP_WKC.WKC_ID = NDP.WKC_ID)";
      if ($tws_config['cpuinfo']['version'] >= '9.5')
          $query .= "
                LEFT JOIN $schema.FOL_FOLDERS JS_FOL ON JS_FOL.FOL_ID = AJS.FOL_ID";
     if ($tws_config['cpuinfo']['version'] >= '9.5002')
              $query .= "
              LEFT JOIN $schema.FOL_FOLDERS WS_FOL ON WS_FOL.FOL_ID = WKC.FOL_ID";

       $query .= "
         WHERE
            WKC.WKC_NAME = ? AND
            AJS.AJS_NAME = ? AND ";
       if ($tws_config['cpuinfo']['version']>='9.5')
           $query .= "
            JS_FOL.FOL_PATH = '$jobstream_folder' AND ";
           if ($tws_config['cpuinfo']['version']>='9.5002')
               $query .= "
                WS_FOL.FOL_PATH = '$workstation_folder' AND ";
       $query .= "
            $validfrom_expr";

      $stmt=new db_statement($composer_db, $query);
      if ($stmt->prepare()==FALSE){
         unset($stmt);
         tws_error('', 'Database query prepare failed: '.$query);
         return FALSE;
      }
      $composer_db[$st_name] = $stmt;
   }
   else $stmt = $composer_db[$st_name];

   $values = array(db_string($composer_db,$workstation), db_string($composer_db,$jobstream));
   if (!empty($validfrom))
      $values[] =  db_string($composer_db,$validfrom);

   tws_log('-- tws_get_jobstream_dep_net -- DB query: '.$stmt->sql());
   tws_log('-- tws_get_jobstream_dep_net -- Query values: '.var_export($values, true));

   if ($stmt->execute($values)==false){
      tws_error('', 'Database query failed: '.$query);
      return FALSE;
   }

   $depnet=Array();
   $i=0;
   while( $stmt->fetch() ){
      $row = $stmt->row();
      $depnet['followsnetworkagent'][$i]=$row['AGENT'];
      $depnet['followsnetworkdep'][$i]=$row['DEPENDENCY'];
      $i++;
   }
   $depnet['followsnetwork_num']=$i;
   tws_log('-- tws_get_jobstream_dep_net -- Result: '.var_export($depnet, true));
   return $depnet;
}

///////////////////////////////////////////////////////////////////////////////
//
// Get Job internetwork dependencies
// Arguments:
//    workstation = parameter name
//    jobstream   = jobstream name
//    validfrom   = valid from
// !!! no wildcards allowed
//
function tws_get_job_dep_net($workstation, $jobstream, $validfrom='', $job=''){
   global $tws_config, $composer_db;
   global $job_folder_expr, $job_folder_id;
   tws_log('-- tws_get_job_dep_net (start at '.basename(__FILE__).'['.__LINE__.'])');

   if ($job=='') $job='@';
   if ($workstation=='') $workstation='@';
   if ($jobstream=='') $jobstream='@';

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema = $composer_db['schema'];
   if ($validfrom == '') {
      $validfrom_expr = "JST.JST_VALID_FROM IS NULL";
      $st_name = 'JOB_DEP_NET';
   }
   else {
      $validfrom_expr = "JST.JST_VALID_FROM = ?";
      $st_name = 'JOB_DEP_NET_VALID';
   }

   ///  ********     IWS >= 9.5    ********///
   // Dep net is in tws_get_job_dep_res()
   if(!isset($composer_db[$st_name])){
      $query = "
         SELECT
            WKC.WKC_NAME WORKSTATION,
            AJS.AJS_NAME JOBSTREAM,
            JST.JST_VALID_FROM VALID_FROM,
            AJB.AJB_NAME ASJOB,
            JOB_WKC.WKC_NAME JOB_WORKSTATION,
            JOD.JOD_NAME JOB_NAME,
            NDP_WKC.WKC_NAME AGENT,
            NDP_VALUE DEPENDENCY";
         if($tws_config['cpuinfo']['version']>='9.5' )
            $query .= ",
               FOL_PATH" ;     // 9.5 folders
      $query .="
         FROM (((((((($schema.NDP_NETWORK_DEPS NDP
             JOIN $schema.JOB_JOBS JOB       ON NDP.JOB_ID = JOB.JOB_ID)
             JOIN $schema.AJB_ABSTRACT_JOBS AJB ON AJB.AJB_ID = JOB.AJB_ID)
             JOIN $schema.JST_JOB_STREAMS JST   ON JST.JST_ID = JOB.JST_ID)
             JOIN $schema.AJS_ABSTRACT_JOB_STREAMS AJS   ON AJS.AJS_ID = JST.AJS_ID)
             JOIN $schema.WKC_WORKSTATION_CLASSES WKC    ON WKC.WKC_ID = AJS.WKC_ID)
             JOIN $schema.JOD_JOB_DEFINITIONS JOD        ON JOD.JOD_ID = JOB.JOD_ID)
             JOIN $schema.WKC_WORKSTATION_CLASSES JOB_WKC   ON JOB_WKC.WKC_ID = JOD.WKC_ID)
             JOIN $schema.WKC_WORKSTATION_CLASSES NDP_WKC   ON NDP_WKC.WKC_ID = NDP.WKC_ID)";
         $query .= ($tws_config['cpuinfo']['version']>='9.5' ? "
            LEFT JOIN $schema.FOL_FOLDERS FOL ON AJS.FOL_ID = FOL.FOL_ID " : '');
      $query .= "
         WHERE
            WKC.WKC_NAME = ? AND
            AJS.AJS_NAME = ? AND
            AJB.AJB_NAME = ? AND
            $validfrom_expr
            $job_folder_expr";

      $stmt=new db_statement($composer_db, $query);
      if ($stmt->prepare()==FALSE){
         unset($stmt);
         tws_error('', 'Database query prepare failed: '.$query);
         return FALSE;
      }
      $composer_db[$st_name] = $stmt;
   }
   else $stmt = $composer_db[$st_name];

   $values = array(db_string($composer_db,$workstation), db_string($composer_db,$jobstream), db_string($composer_db,$job));
   if (!empty($validfrom))
      $values[] =  db_string($composer_db,$validfrom);

   tws_log('DB query: '.$stmt->sql());
   tws_log('Query values: '.var_export($values, true));

   if ($stmt->execute($values)==false){
      tws_error('', 'Database query failed: '.$query);
      return FALSE;
   }

   $depnet=Array();
   $i=0;
   while( $stmt->fetch() ){
      $row = $stmt->row();
      $job_folder = '';
      if(!empty($row['JOB_FOLDER']))
         $job_folder = $row['FOL_PATH'];
//         if(!empty($row['FOL_PATH']))
//            $row['JOB_NAME'] = $row['FOL_PATH']

      if ($row['JOB_NAME'] == $row['ASJOB']){
         $jobname=$row['JOB_WORKSTATION']."#".$row['JOB_NAME'];
      }
      else{
         $jobname=$row['JOB_WORKSTATION']."#".$row['JOB_NAME']." AS ".$row['ASJOB'];
      }
      $depnet['jobfollowsnetworkagent'][$jobname][]=$row['AGENT'];
      $depnet['jobfollowsnetworkdep'][$jobname][]=$row['DEPENDENCY'];
      $i++;
   }
   $depnet['jobfollowsnetwork_num']=$i;
   tws_log('Result: '.var_export($depnet, true));
   return $depnet;
}


///////////////////////////////////////////////////////////////////////////////
//
// Get Jobstream resource dependencies (resources, files, prompts, Ad-Hoc Prompts)

//  !!! no wildcards allowed

// IWS 9.5.2 Folders:
//  File Dependencies:        /WS_Folder/Workstation
//  Resource Dependencies:    /WS_Folder/Workstation, /RES_Folder/Resource
//  Prompt Dependencies:      /Prompt_Folder/Prompt

function tws_get_jobstream_dep_res($workstation, $jobstream, $validfrom=''){
   global $tws_config, $composer_db;

   tws_log('-- tws_get_jobstream_dep_res (start at '.basename(__FILE__).'['.__LINE__.'])');
   tws_log("-- tws_get_jobstream_dep_res Parameters: workstation = $workstation, jobstream = $jobstream");

   if( ($workstation == '') || ($jobstream == '') ) {
      tws_error("workstation='$workstation', jobstream='$jobstream'","Database query error - missing argument(s)");
      return FALSE;
   }

   if($tws_config['cpuinfo']['version']>='9.5')
      list($jobstream_folder, $jobstream) = tws_explode_folder($jobstream);
   if($tws_config['cpuinfo']['version']>='9.5002')
      list($workstation_folder, $workstation) = tws_explode_folder($workstation);

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema = $composer_db['schema'];
   if ($validfrom == '') {
      $validfrom_expr = "JST.JST_VALID_FROM IS NULL";
      $st_name = 'STREAM_DEP_RES';
   } else {
      $validfrom_expr = "JST.JST_VALID_FROM = ?";
         //'".db_string($composer_db,$validfrom)."'";
      $st_name = 'STREAM_DEP_RES_VALID';
   }

   if(!isset($composer_db[$st_name])){
      $query = "
         SELECT
            WKC.WKC_NAME               WORKSTATION,
            AJS.AJS_NAME               JOBSTREAM,
            JST.JST_VALID_FROM         VALID_FROM,
            RES_WKC.WKC_NAME           RES_WORKSTATION,
            RES.RES_NAME               RES_NAME,
            RES_CLASS                  RES_CLASS,
            RES_TYPE                   RES_TYPE,
            RES_DESCRIPTION            RES_DESCRIPTION,
            RES_TEXT                   RES_TEXT,
            RDP_QUANTITY               QUANTITY,
            RDP_QUALIFIERS             QUALIFIERS";

            if($tws_config['cpuinfo']['version']>='9.5002')
               $query .=",
               RES.RES_ID    RES_ID,
               WS_FOL.FOL_PATH         WS_FOLDER,
               RES_FOL.FOL_PATH        RES_FOLDER,
               WSRS_FOL.FOL_PATH       WSRS_FOLDER";
         $query .="
         FROM ((((($schema.RDP_RESOURCE_DEPS RDP
             JOIN $schema.JST_JOB_STREAMS JST   ON RDP.JST_ID = JST.JST_ID)
             JOIN $schema.AJS_ABSTRACT_JOB_STREAMS AJS   ON AJS.AJS_ID = JST.AJS_ID)
             JOIN $schema.WKC_WORKSTATION_CLASSES WKC ON WKC.WKC_ID = AJS.WKC_ID)
             JOIN $schema.RES_ABSTRACT_RESOURCES RES  ON RDP.RES_ID = RES.RES_ID)
             LEFT JOIN $schema.WKC_WORKSTATION_CLASSES RES_WKC ON RES_WKC.WKC_ID = RES.WKC_ID)";
            if($tws_config['cpuinfo']['version']>='9.5002')
               $query .="
               LEFT JOIN $schema.FOL_FOLDERS WS_FOL ON WS_FOL.FOL_ID = WKC.FOL_ID
               LEFT JOIN $schema.FOL_FOLDERS JS_FOL ON JS_FOL.FOL_ID = AJS.FOL_ID
               LEFT JOIN $schema.FOL_FOLDERS RES_FOL ON RES_FOL.FOL_ID = RES.FOL_ID
                LEFT JOIN $schema.FOL_FOLDERS WSRS_FOL ON WSRS_FOL.FOL_ID = RES_WKC.FOL_ID";
         $query .="
         WHERE
            WKC.WKC_NAME = ? AND
            AJS.AJS_NAME = ? AND
            $validfrom_expr";
         if($tws_config['cpuinfo']['version']>='9.5')
            $query .="
            AND JS_FOL.FOL_PATH = ?";
         if($tws_config['cpuinfo']['version']>='9.5002')
            $query .="
            AND WS_FOL.FOL_PATH = ?";

      $stmt=new db_statement($composer_db, $query);
      if ($stmt->prepare()==FALSE){
         unset($stmt);
         tws_error('', 'Database query prepare failed: '.$query);
         return FALSE;
      }
      $composer_db[$st_name] = $stmt;
   }
   else $stmt = $composer_db[$st_name];

//    VALUES:
   $values = array(db_string($composer_db,$workstation), db_string($composer_db,$jobstream));
   if (!empty($validfrom))
      $values[] =  db_string($composer_db,$validfrom);
   if($tws_config['cpuinfo']['version']>='9.5')
      $values[] =  db_string($composer_db, $jobstream_folder);
   if($tws_config['cpuinfo']['version']>='9.5002')
      $values[] =  db_string($composer_db, $workstation_folder);

   tws_log('-- tws_get_jobstream_dep_res DB Query: '.$stmt->sql());
   tws_log('-- tws_get_jobstream_dep_res Query values: '.var_export($values, true));

   if ($stmt->execute($values)==false){
      tws_error('', 'Database query failed: '.$query);
      return FALSE;
   }

   $depres=Array();
   $res=$prompt=$aprompt=$file=0;
   while( $stmt->fetch() ){
      $row = $stmt->row();
      tws_log("-- tws_get_jobstream_dep_res ROW: ".var_export($row, true));

      switch ($row['RES_CLASS']) {
      case "F":
          $res_workstation = $row['RES_WORKSTATION'];
          if($tws_config['cpuinfo']['version']>='9.5002')
              $res_workstation = $row['WSRS_FOLDER'] . $row['RES_WORKSTATION'];
         $depres['openscpu'][$file]=$res_workstation;
         $depres['opensfile'][$file]=$row['RES_NAME'];
         $depres['opensqual'][$file]=$row['QUALIFIERS'];
         $file++;
         break;
      case "R":
          $res_workstation = $row['RES_WORKSTATION'];
          $res_name = $row['RES_NAME'];
          if($tws_config['cpuinfo']['version']>='9.5002'){
              $res_workstation = $row['WSRS_FOLDER'] . $row['RES_WORKSTATION'];
              $res_name = $row['RES_FOLDER'] . $row['RES_NAME'];
         }
         $depres['needscpu'][$res]=$res_workstation;
         $depres['resource'][$res]=$res_name;
         $depres['units'][$res]=$row['QUANTITY'];
         $res++;
         break;
      case "P":
         if ($row['RES_TYPE']=="A"){
            $depres['prompttext'][$aprompt]=$row['RES_TEXT'];
            $aprompt++;
         } else {
             $p_name = $row['RES_NAME'];
             if($tws_config['cpuinfo']['version']>='9.5002')
                 $p_name = $row['RES_FOLDER'].$row['RES_NAME'];
             $depres['promptname'][$prompt]=$p_name;
            $prompt++;
         }
         break;
      } //switch
   }
   $depres['file_num']=$file;
   $depres['resource_num']=$res;
   $depres['aprompt_num']=$aprompt; //ADHOC prompts
   $depres['prompt_num']=$prompt;
   tws_log("-- tws_get_jobstream_dep_res Result: ".var_export($depres, true));
   return $depres;
}

///////////////////////////////////////////////////////////////////////////////
//
// Get Job resource dependencies (resources, files, prompts)
// Arguments:
//    workstation = parameter name
//    jobstream   = jobstream name
//    validfrom   = valid from
//
function tws_get_job_dep_res($workstation, $jobstream, $validfrom='', $job=''){
   global $tws_config, $composer_db;
   tws_log("-- tws_get_job_dep_res -- (start with parameters: $workstation#$jobstream.$job  at ".basename(__FILE__).'['.__LINE__.'])');
   if ($job=='') $job='@';
   if ($workstation=='') $workstation='@';
   if ($jobstream=='') $jobstream='@';
   $depres=Array();

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema = $composer_db['schema'];

if($tws_config['cpuinfo']['version']>='9.5'){
    list($jobstream_folder, $jobstream) = tws_divide_folder($jobstream);
    if($tws_config['cpuinfo']['version']>='9.5002')
        list($workstation_folder, $workstation) = tws_divide_folder($workstation);
//  PROMPTS
         $query = "SELECT
            'P'                              RES_CLASS,
            'P'                              RES_TYPE,

            DEP_JOB_STREAM_WKS_NAME          JOB_STREAM_WKS_NAME,
            DEP_JOB_STREAM_FOLDER_NAME       JOB_STREAM_FOLDER_NAME,
            DEP_JOB_STREAM_NAME              JOB_STREAM_NAME,
            DEP_JOB_STREAM_VALID_FROM        JOB_STREAM_VALID_FROM,

            DEP_JOB_WKS_NAME                 JOB_WORKSTATION,
            DEP_JOB_FOLDER_NAME              JOB_FOLDER_NAME,
            DEP_JOB_DEFINITION_NAME          JOB_NAME,
            DEP_JOB_NAME                     ASJOB,";
         if($tws_config['cpuinfo']['version']>='9.5002')
             $query .= "
                    DEP_JOB_WKS_FOLDER_NAME,
                    PROMPT_FOL_NAME,";
         $query .= "
            PROMPT_NAME                      RES_NAME
         FROM $schema.PROMPT_REFS_V
         WHERE
            DEP_JOB_STREAM_WKS_NAME LIKE ? ESCAPE '/' AND
            DEP_JOB_STREAM_NAME LIKE ? ESCAPE '/' AND
            DEP_jOB_NAME LIKE ? ESCAPE '/' AND
            DEP_JOB_STREAM_FOLDER_NAME = '".db_string($composer_db,$jobstream_folder)."'";
            if($tws_config['cpuinfo']['version']>='9.5002')
                $query .= "
                   AND  DEP_JOB_STREAM_WKS_FOLDER_NAME = '".db_string($composer_db,$workstation_folder)."'";
            if ($validfrom == '')
               $query .= "
                  AND DEP_JOB_STREAM_VALID_FROM IS NULL";
            else $query .= "
               AND DEP_JOB_STREAM_VALID_FROM = '".db_string($composer_db,$validfrom)."'";

      tws_log("-- tws_get_job_dep_res -- PROMPTS query: $query");
      $values = array(tws_preplike(db_string($composer_db,$workstation)), tws_preplike(db_string($composer_db,$jobstream)), tws_preplike(db_string($composer_db,$job)));
      tws_log("-- tws_get_job_dep_res -- PROMPTS values: ". var_export($values, true));

      // run query:
         $stmt=new db_statement($composer_db, $query);
         if ($stmt->prepare()==FALSE){
            unset($stmt);
            tws_error('', 'Database query prepare failed: '.$query);
            return FALSE;
         }
         if ($stmt->execute($values)==false){
            tws_error('', 'Database query failed: '.$query);
            return FALSE;
         }
      // Get PROMPTS results:
         $prompt = 0;
         while( $stmt->fetch() ){
            $row = $stmt->row();
            tws_log("-- Prompts Query row: ". var_export($row, true));
            $jobfolder = $row['JOB_FOLDER_NAME'];     // IWS 9.5 Folders
            $jobname = '';
            $resname = $row['RES_NAME'];
            if($tws_config['cpuinfo']['version']>='9.5002'){
                $jobname .= $row['DEP_JOB_WKS_FOLDER_NAME'];
                $resname = $row['PROMPT_FOL_NAME'].$resname;
            }
            if ($row['JOB_NAME'] == $row['ASJOB'])
                  $jobname.=$row['JOB_WORKSTATION']."#".$jobfolder.$row['JOB_NAME'];
            else  $jobname.=$row['JOB_WORKSTATION']."#".$jobfolder.$row['JOB_NAME']." AS ".$row['ASJOB'];

            $depres['jobpromptname'][$jobname][]=$resname;
            tws_log("-- Prompts Query results: depres['jobpromptname'][$jobname] = ". var_export($depres['jobpromptname'][$jobname],true));
            $prompt++;
            $depres['prompt_num']=$prompt;
         }
         // tws_log("-- tws_get_job_dep_res -- PROMPTS results: ". var_export($depres, true));

// Ad-Hoc Prompts:
         $query = "
            SELECT
               WKC.WKC_NAME WORKSTATION,
               AJS.AJS_NAME JOBSTREAM,
               AJS.FOL_ID,
               JST.JST_VALID_FROM VALID_FROM,
               AJB.AJB_NAME ASJOB,
               JOB_WKC.WKC_NAME JOB_WORKSTATION,
               JOD.JOD_NAME JOB_NAME,
               RES_WKC.WKC_NAME RES_WORKSTATION,
               RES.RES_NAME RES_NAME,
               RES_CLASS RES_CLASS,
               RES_TYPE RES_TYPE,
               RES_DESCRIPTION RES_DESCRIPTION,
               RES_TEXT PROMPT_TEXT,
                JSFOL.FOL_PATH JS_FOLDER_NAME,";
         if($tws_config['cpuinfo']['version']>='9.5002')
             $query .= "
                    JOBWKCFOL.FOL_PATH JOBWKC_FOLDER_NAME,";
         $query .= "
                JOBFOL.FOL_PATH JOB_FOLDER_NAME
               FROM (((((((((($schema.RDP_RESOURCE_DEPS RDP
                JOIN $schema.JOB_JOBS JOB    ON JOB.JOB_ID = RDP.JOB_ID)
                JOIN $schema.AJB_ABSTRACT_JOBS AJB ON AJB.AJB_ID = JOB.AJB_ID)
                JOIN $schema.JST_JOB_STREAMS JST   ON JST.JST_ID=JOB.JST_ID)
                JOIN $schema.AJS_ABSTRACT_JOB_STREAMS AJS   ON AJS.AJS_ID = JST.AJS_ID)
                JOIN $schema.WKC_WORKSTATION_CLASSES WKC ON WKC.WKC_ID = AJS.WKC_ID)
                JOIN $schema.JOD_JOB_DEFINITIONS JOD  ON JOD.JOD_ID = JOB.JOD_ID)
                JOIN $schema.WKC_WORKSTATION_CLASSES JOB_WKC   ON JOD.WKC_ID = JOB_WKC.WKC_ID)
                JOIN $schema.RES_ABSTRACT_RESOURCES RES  ON RDP.RES_ID = RES.RES_ID)
                LEFT JOIN $schema.WKC_WORKSTATION_CLASSES RES_WKC ON RES_WKC.WKC_ID = RES.WKC_ID))
                LEFT JOIN $schema.FOL_FOLDERS JSFOL ON JSFOL.FOL_ID = AJS.FOL_ID
                LEFT JOIN $schema.FOL_FOLDERS JOBFOL ON JOBFOL.FOL_ID = JOD.FOL_ID";
         if($tws_config['cpuinfo']['version']>='9.5002')
             $query .= "
                LEFT JOIN $schema.FOL_FOLDERS JOBWKCFOL ON JOBWKCFOL.FOL_ID =  JOB_WKC.FOL_ID
                LEFT JOIN $schema.FOL_FOLDERS JSWKCFOL ON JSWKCFOL.FOL_ID =  WKC.FOL_ID";
         $query .= "
            WHERE
               WKC.WKC_NAME LIKE ? ESCAPE '/' AND
               AJS.AJS_NAME LIKE ? ESCAPE '/' AND
               AJB.AJB_NAME LIKE ? ESCAPE '/' AND
               RES_CLASS = 'P' AND RES_TYPE = 'A' AND
               JSFOL.FOL_PATH = '".db_string($composer_db,$jobstream_folder)."'";
                if($tws_config['cpuinfo']['version']>='9.5002')
                    $query .= "
                   AND  JSWKCFOL.FOL_PATH = '".db_string($composer_db,$workstation_folder)."'";
               if (empty($validfrom))
                    $query .= "
                       AND JST.JST_VALID_FROM IS NULL";
               else
                  $query .= "
                     AND JST.JST_VALID_FROM = '" .db_string($composer_db,$validfrom)."'";

      tws_log("-- tws_get_job_dep_res -- Ad-Hoc Prompts Query: $query");
      $values = array(tws_preplike(db_string($composer_db,$workstation)), tws_preplike(db_string($composer_db,$jobstream)), tws_preplike(db_string($composer_db,$job)));
      tws_log('-- tws_get_job_dep_res -- Ad-Hoc Prompts Query values: '.var_export($values, true));

      $stmt=new db_statement($composer_db, $query);
      if ($stmt->prepare()==FALSE){
         unset($stmt);
         tws_error('', 'Database query prepare failed: '.$query);
         return FALSE;
      }

   if ($stmt->execute($values)==false){
      tws_error('', 'Database query failed: '.$query);
      return FALSE;
   }

   $aprompt = 0;
   while( $stmt->fetch() ){
          $row = $stmt->row();
          if(!empty($row['JOB_FOLDER_NAME']))
             $jobfolder = $row['JOB_FOLDER_NAME'];
          $jobname = '';
          if(!empty($row['JOBWKC_FOLDER_NAME']))
              $jobname .=$row['JOBWKC_FOLDER_NAME'];
          $jobname .= $row['JOB_WORKSTATION']."#".$jobfolder.$row['JOB_NAME'];
         if ($row['JOB_NAME'] != $row['ASJOB'])
            $jobname=" AS ".$row['ASJOB'];
         $depres['jobprompttext'][$jobname][]=$row['PROMPT_TEXT'];
      }
      tws_log('-- Ad-Hoc Prompts depres result: '.var_export($depres, true));

//    RESOURCES
         $query = "
            SELECT
               WORKSTATION_NAME              RES_WORKSTATION,
               RESOURCE_NAME                 RES_NAME,
               UNITS_AVAILABLE,
               UNITS_ALLOCATED               QUANTITY,
               DEP_JOB_STREAM_WKS_NAME,
               DEP_JOB_STREAM_FOLDER_NAME   ,
               DEP_JOB_STREAM_NAME           JOBSTREAM,
               DEP_JOB_STREAM_VALID_FROM     VALID_FROM,
               DEP_JOB_WKS_NAME              JOB_WORKSTATION,
               DEP_JOB_FOLDER_NAME           JOB_FOLDER_NAME,
               DEP_JOB_NAME                  ASJOB,";
            if($tws_config['cpuinfo']['version']>='9.5002')
             $query .= "
                    DEP_JOB_WKS_FOLDER_NAME ,
                    RESOURCE_FOL_NAME,
                    WORKSTATION_FOLDER_NAME,";
               $query .= "
                DEP_JOB_DEFINITION_NAME       JOB_NAME
            FROM
               $schema.RESOURCE_REFS_V
            WHERE
            DEP_JOB_STREAM_WKS_NAME LIKE ? ESCAPE '/' AND
            DEP_JOB_STREAM_NAME LIKE ? ESCAPE '/' AND
            DEP_JOB_NAME LIKE ? ESCAPE '/' AND
            DEP_JOB_STREAM_FOLDER_NAME = '".db_string($composer_db,$jobstream_folder)."'";
            if($tws_config['cpuinfo']['version']>='9.5002')
                $query .= "
                    AND DEP_JOB_STREAM_WKS_FOLDER_NAME = '".db_string($composer_db,$workstation_folder)."'";
            if ($validfrom == '')
               $query .= " AND  DEP_JOB_STREAM_VALID_FROM IS NULL";
            else $query .= " AND DEP_JOB_STREAM_VALID_FROM = '".db_string($composer_db,$validfrom)."'";

      tws_log("-- tws_get_job_dep_res -- RESOURCES query: $query");
      tws_log("-- tws_get_job_dep_res -- RESOURCES values: ". var_export($values, true));

         $stmt=new db_statement($composer_db, $query);
         if ($stmt->prepare()==FALSE){
            unset($stmt);
            tws_error('', 'Database query prepare failed: '.$query);
            return FALSE;
         }
         if ($stmt->execute($values)==false){
            tws_error('', 'Database query failed: '.$query);
            return FALSE;
         }

      // Get RESOURCES results:
         $depres['resource_num'] = 0;
         while( $stmt->fetch() ){
            $row = $stmt->row();
            $jobfolder = $row['JOB_FOLDER_NAME'];
            $jobname = '';
            $resfolder = '';
            $reswsfolder = '';
            if($tws_config['cpuinfo']['version']>='9.5002'){
                $jobname .=  $row['DEP_JOB_WKS_FOLDER_NAME'];
                $reswsfolder .= $row['WORKSTATION_FOLDER_NAME'];
                $resfolder .= $row['RESOURCE_FOL_NAME'];
            }
            $jobname.=$row['JOB_WORKSTATION']."#".$jobfolder.$row['JOB_NAME'];
            if ($row['JOB_NAME'] != $row['ASJOB'])
               $jobname .=" AS ".$row['ASJOB'];

            $depres['jobneedscpu'][$jobname][]=$reswsfolder.$row['RES_WORKSTATION'];
            $depres['jobresource'][$jobname][]=$resfolder.$row['RES_NAME'];
            $depres['jobunits'][$jobname][]=$row['QUANTITY'];
            $depres['resource_num']++;
         }

// FILES

    $query = "SELECT
         DEP_JOB_STREAM_WKS_NAME,
         DEP_JOB_STREAM_FOLDER_NAME,
         DEP_JOB_STREAM_NAME        ,
         DEP_JOB_STREAM_VALID_FROM,

         DEP_JOB_WKS_NAME        JOB_WORKSTATION,
         DEP_JOB_FOLDER_NAME     JOB_FOLDER_NAME,
         DEP_JOB_DEFINITION_NAME JOB_NAME,
         DEP_JOB_NAME            ASJOB,

         WORKSTATION_NAME        RES_WORKSTATION,
         FILE_NAME               RES_NAME,";
    if($tws_config['cpuinfo']['version']>='9.5002')
        $query .= "
                    DEP_JOB_WKS_FOLDER_NAME ,
                    WORKSTATION_FOLDER_NAME,";
    $query .= "
        RDP_QUALIFIERS          QUALIFIERS
      FROM $schema.FILE_REFS_V
         LEFT JOIN $schema.RDP_RESOURCE_DEPS ON $schema.RDP_RESOURCE_DEPS.RES_ID = $schema.FILE_REFS_V.FILE_IDENTIFIER
      WHERE
         DEP_JOB_STREAM_WKS_NAME LIKE ? ESCAPE '/' AND
         DEP_JOB_STREAM_NAME LIKE ? ESCAPE '/' AND
         DEP_JOB_NAME LIKE ? ESCAPE '/'  AND
        DEP_JOB_STREAM_FOLDER_NAME = '".db_string($composer_db,$jobstream_folder)."'";
        if($tws_config['cpuinfo']['version']>='9.5002')
            $query .= "
            AND DEP_JOB_STREAM_WKS_FOLDER_NAME = '".db_string($composer_db,$workstation_folder)."'";
         if ($validfrom == '')
            $query .= "
               AND DEP_JOB_STREAM_VALID_FROM IS NULL";
         else $query .= "
            AND DEP_JOB_STREAM_VALID_FROM = '".db_string($composer_db,$validfrom)."'";


      tws_log("-- tws_get_job_dep_res -- FILES query: $query");
      tws_log("-- tws_get_job_dep_res -- FILES values: " . var_export($values, true));

      // TODO Valid_ from & alias
         $stmt=new db_statement($composer_db, $query);
         if ($stmt->prepare()==FALSE){
            unset($stmt);
            tws_error('', 'Database query prepare failed: '.$query);
            return FALSE;
         }
         if ($stmt->execute($values)==false){
            tws_error('', 'Database query failed: '.$query);
            return FALSE;
         }
// Files results:
         $depres['file_num']=0;
         while( $stmt->fetch() ){
            $row = $stmt->row();

            $jobfolder = $row['JOB_FOLDER_NAME'];
            $jobname = '';
            $reswsfolder = '';
            if($tws_config['cpuinfo']['version']>='9.5002'){
                $jobname .=  $row['DEP_JOB_WKS_FOLDER_NAME'];
                $reswsfolder .= $row['WORKSTATION_FOLDER_NAME'];
            }
            $jobname.=$row['JOB_WORKSTATION']."#".$jobfolder.$row['JOB_NAME'];
            if ($row['JOB_NAME'] != $row['ASJOB'])
               $jobname .= " AS ".$row['ASJOB'];
            $depres['jobopenscpu'][$jobname][]=$reswsfolder.$row['RES_WORKSTATION'];
            $depres['jobopensfile'][$jobname][]=$row['RES_NAME'];
            $depres['jobopensqual'][$jobname][]=$row['QUALIFIERS'];
            $depres['file_num']++;
         }
tws_log("-- tws_get_job_dep_res -- FILES results: ". var_export($depres, true));

// INTERNETWORK
   // INTERNETWORK_DEPS_V

    $query = "SELECT
         INTERNETWORK_DEPENDENCY    DEPENDENCY,
         NETWORK_AGENT_NAME         AGENT,
         DEP_JOB_STREAM_WKS_NAME,
         DEP_JOB_STREAM_FOLDER_NAME,
         DEP_JOB_STREAM_NAME,
         DEP_JOB_STREAM_VALID_FROM,
         DEP_JOB_WKS_NAME           JOB_WORKSTATION,
         DEP_JOB_NAME               ASJOB,
         DEP_JOB_DEFINITION_NAME    JOB_NAME, ";
    if($tws_config['cpuinfo']['version']>='9.5002')
        $query .= "
                    DEP_JOB_WKS_FOLDER_NAME ,";
    $query .= "
         DEP_JOB_FOLDER_NAME        JOB_FOLDER_NAME
      FROM $schema.INTERNETWORK_DEPS_V
      WHERE
         DEP_JOB_STREAM_WKS_NAME LIKE ? ESCAPE '/' AND
         DEP_JOB_STREAM_NAME LIKE ? ESCAPE '/' AND
         DEP_JOB_NAME LIKE ? ESCAPE '/' AND
        DEP_JOB_STREAM_FOLDER_NAME = '".db_string($composer_db,$jobstream_folder)."'";
        if($tws_config['cpuinfo']['version']>='9.5002')
            $query .= "
            AND DEP_JOB_STREAM_WKS_FOLDER_NAME = '".db_string($composer_db,$workstation_folder)."'";
         if (empty($validfrom))
              $query .= " AND DEP_JOB_STREAM_VALID_FROM IS NULL";
         else
            $query .= " AND DEP_JOB_STREAM_VALID_FROM = '" .db_string($composer_db,$validfrom)."'";

      tws_log("-- tws_get_job_dep_res -- INTERNETWORK query: $query");
      tws_log("-- tws_get_job_dep_res -- INTERNETWORK values: " .var_export($values, true));

         // TODO Valid_ from & alias
         $stmt=new db_statement($composer_db, $query);
         if ($stmt->prepare()==FALSE){
            unset($stmt);
            tws_error('', 'Database query prepare failed: '.$query);
            return FALSE;
         }
         if ($stmt->execute($values)==false){
            tws_error('', 'Database query failed: '.$query);
            return FALSE;
         }
// INTERNETWORK results:
         $depres['jobfollowsnetwork_num']=0;
         while( $stmt->fetch() ){
            $row = $stmt->row();

            $jobfolder = $row['JOB_FOLDER_NAME'];
            $jobname = '';
            if($tws_config['cpuinfo']['version']>='9.5002'){
                $jobname .=  $row['DEP_JOB_WKS_FOLDER_NAME'];
            }
            $jobname.=$row['JOB_WORKSTATION']."#".$jobfolder.$row['JOB_NAME'];
            if ($row['JOB_NAME'] != $row['ASJOB'])
               $jobname .= " AS ".$row['ASJOB'];

            tws_log("-- tws_get_job_dep_res -- INTERNETWORK results: jobfolder: $jobfolder, jobname: $jobname, ASJOB: ". $row['ASJOB']);

            $depres['jobfollowsnetworkagent'][$jobname][]=$row['AGENT'];
            $depres['jobfollowsnetworkdep'][$jobname][]=$row['DEPENDENCY'];
            $depres['jobfollowsnetwork_num']++;
         }
      tws_log("-- tws_get_job_dep_res -- results: ". var_export($depres, true));

}
// IWS < 9.5
      else{

         if ($validfrom == '') {
            $validfrom_expr = "JST.JST_VALID_FROM IS NULL";
            $st_name = 'JOB_DEP_RES';
         }
         else {
            $validfrom_expr = "JST.JST_VALID_FROM = ?";
            //'".db_string($composer_db,$validfrom)."'";
            $st_name = 'JOB_DEP_RES_VALID';
         }

         if(!isset($composer_db[$st_name])){
         $query = "
            SELECT
               WKC.WKC_NAME WORKSTATION,
               AJS.AJS_NAME JOBSTREAM,
               JST.JST_VALID_FROM VALID_FROM,
               AJB.AJB_NAME ASJOB,
               JOB_WKC.WKC_NAME JOB_WORKSTATION,
               JOD.JOD_NAME JOB_NAME,
               RES_WKC.WKC_NAME RES_WORKSTATION,
               RES.RES_NAME RES_NAME,
               RES_CLASS RES_CLASS,
               RES_TYPE RES_TYPE,
               RES_DESCRIPTION RES_DESCRIPTION,
               RES_TEXT RES_TEXT,
               RDP_QUANTITY QUANTITY,
               RDP_QUALIFIERS QUALIFIERS
            FROM ((((((((($schema.RDP_RESOURCE_DEPS RDP
                JOIN $schema.JOB_JOBS JOB    ON JOB.JOB_ID = RDP.JOB_ID)
                JOIN $schema.AJB_ABSTRACT_JOBS AJB ON AJB.AJB_ID = JOB.AJB_ID)
                JOIN $schema.JST_JOB_STREAMS JST   ON JST.JST_ID=JOB.JST_ID)
                JOIN $schema.AJS_ABSTRACT_JOB_STREAMS AJS   ON AJS.AJS_ID = JST.AJS_ID)
                JOIN $schema.WKC_WORKSTATION_CLASSES WKC ON WKC.WKC_ID = AJS.WKC_ID)
                JOIN $schema.JOD_JOB_DEFINITIONS JOD  ON JOD.JOD_ID = JOB.JOD_ID)
                JOIN $schema.WKC_WORKSTATION_CLASSES JOB_WKC   ON JOD.WKC_ID = JOB_WKC.WKC_ID)
                JOIN $schema.RES_ABSTRACT_RESOURCES RES  ON RDP.RES_ID = RES.RES_ID)
                LEFT JOIN $schema.WKC_WORKSTATION_CLASSES RES_WKC ON RES_WKC.WKC_ID = RES.WKC_ID)
            WHERE
               WKC.WKC_NAME LIKE ? ESCAPE '/' AND
               AJS.AJS_NAME LIKE ? ESCAPE '/' AND
               AJB.AJB_NAME LIKE ? ESCAPE '/' AND
               $validfrom_expr
               $job_folder_expr";

      $stmt=new db_statement($composer_db, $query);
      if ($stmt->prepare()==FALSE){
         unset($stmt);
         tws_error('', 'Database query prepare failed: '.$query);
         return FALSE;
      }
      $composer_db[$st_name] = $stmt;
   }
   else $stmt = $composer_db[$st_name];

      tws_log("-- tws_get_job_dep_res -- DB query: $query");

   $values = array(tws_preplike(db_string($composer_db,$workstation)), tws_preplike(db_string($composer_db,$jobstream)), tws_preplike(db_string($composer_db,$job)));
   if (!empty($validfrom))
      $values[] =  db_string($composer_db,$validfrom);

   tws_log('-- tws_get_job_dep_res -- Query values: '.var_export($values, true));

   if ($stmt->execute($values)==false){
      tws_error('', 'Database query failed: '.$query);
      return FALSE;
   }

   $res=$prompt=$aprompt=$file=0;
   while( $stmt->fetch() ){
      $row = $stmt->row();
      $jobfolder = '';
      if(!empty($row['JOB_FOLDER_NAME']))
         $jobfolder = $row['JOB_FOLDER_NAME'];     // IWS 9.5 Folders

      if ($row['JOB_NAME'] == $row['ASJOB'])
         $jobname=$row['JOB_WORKSTATION']."#".$jobfolder.$row['JOB_NAME'];
      else
         $jobname=$row['JOB_WORKSTATION']."#".$jobfolder.$row['JOB_NAME']." AS ".$row['ASJOB'];

      switch ($row['RES_CLASS']) {
      case "F":
         $depres['jobopenscpu'][$jobname][]=$row['RES_WORKSTATION'];
         $depres['jobopensfile'][$jobname][]=$row['RES_NAME'];
         $depres['jobopensqual'][$jobname][]=$row['QUALIFIERS'];
         $file++;
         break;
      case "R":
         $depres['jobneedscpu'][$jobname][]=$row['RES_WORKSTATION'];
         $depres['jobresource'][$jobname][]=$row['RES_NAME'];
         $depres['jobunits'][$jobname][]=$row['QUANTITY'];
         $res++;
         break;
      case "P":
         if ($row['RES_TYPE']=="A"){
            $depres['jobprompttext'][$jobname][]=$row['RES_TEXT'];
            $aprompt++;
         }
         else{
            $depres['jobpromptname'][$jobname][]=$row['RES_NAME'];
            $prompt++;
         }
         break;
      } //switch
   }
   $depres['file_num']=$file;
   $depres['resource_num']=$res;
   $depres['aprompt_num']=$aprompt; //ADHOC prompts
   $depres['prompt_num']=$prompt;
   }
// End of IWS < 9.5
   tws_log('-- tws_get_job_dep_res -- Result: '.var_export($depres, true));
   return $depres;
}


///////////////////////////////////////////////////////////////////////////////
//
// Get Jobstream jobs
//    // Arguments:
//    workstation = parameter name
//    jobstream   = jobstream name
//    validfrom   = valid from
//
//  !!!SQL wildcards allowed
//

function tws_get_jobstream_jobs($workstation, $jobstream, $validfrom=''){
   global $tws_config, $composer_db;
   global $tws_jobstream_jobs;   // arr[short_job_name] => full_job_name
   tws_log('-- tws_get_jobstream_jobs (start at '.basename(__FILE__).'['.__LINE__.'])');
   tws_log("-- tws_get_jobstream_jobs Parameters: workstation = $workstation, jobstream = $jobstream");

   if($tws_config['cpuinfo']['version']>='9.5002'){
      tws_log("workstation = $workstation");
      list($workstation_folder, $workstation) = tws_divide_folder($workstation);
   }

   if($tws_config['cpuinfo']['version']>='9.5'){
      tws_log("jobstream = $jobstream");
      list($jobstream_folder, $jobstream) = tws_divide_folder($jobstream);
      }
   if ($workstation=='' || $jobstream=='') {
      tws_error("workstation='$workstation', jobstream='$jobstream'","Database query error - missing argument(s)");
      return FALSE;
   }

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }

   $schema = $composer_db['schema'];

   if ($validfrom == '') {
      $validfrom_expr = "JST_VALID_FROM IS NULL";
      $st_name = 'STREAM_JOBS';
   } else {
      $validfrom_expr = "JST_VALID_FROM = ?";
      $st_name = 'STREAM_JOBS_VALID';
   }
   if(!isset($composer_db[$st_name])){
/*
      $query = "
         SELECT";
           if ($tws_config['cpuinfo']['version']>='9.5002')
              $query .= "
              WKC_FOL.FOL_PATH    JS_WORKSTATION_FOLDER,";

            $query .= "
            JST_WKC.WKC_NAME         JS_WORKSTATION_NAME,";

           if ($tws_config['cpuinfo']['version']>='9.5')
               $query .= "
               JST_WKC_FOL.FOL_PATH     JOBSTREAM_FOLDER,";

           $query .= "
           AJS.AJS_NAME             JOBSTREAM_NAME,
           JST.JST_VALID_FROM       JOBSTREAM_VALID_FROM,";

           if ($tws_config['cpuinfo']['version']>='9.5002')
              $query .= "
               WKC_FOL.FOL_PATH  JOB_WORKSTATION_FOLDER,";

            $query .= "
            JOD_WKC.WKC_NAME         JOB_WORKSTATION,";

           if ($tws_config['cpuinfo']['version']>='9.5')
              $query .= "
              JOB_WKC_FOL.FOL_PATH    JOB_FOLDER,";

           $query .= "
           AJB.AJB_NAME             JOBNAME,
           JOD.JOD_NAME             DEF_JOBNAME,

           JOB_DESCRIPTION,
           JOB_COMMENT,
           JOB_START_OFFSET,
           JOB_TIME_DEPENDENT,
           JOB_LATEST_START_OFFSET,
           JOB_LATEST_START_ACTION,
           JOB_DEADLINE_OFFSET,
           JOB_REPEAT_INTERVAL,
           JOB_TIMEZONE_ID,";

           if($tws_config['cpuinfo']['version']>='9.0')
              $query .= "
              JOB_MAX_DURATION, JOB_MAX_DURATION_ACTION, JOB_MAX_DURATION_TYPE,
              JOB_MIN_DURATION, JOB_MIN_DURATION_ACTION, JOB_MIN_DURATION_TYPE,";

           $query .= "
           JOB_PRIORITY,
           JOB_REQUIRES_CONFIRMATION,
           JOB_MONITORED,
           JOB_POSITION,";
           if($tws_config['cpuinfo']['version']>='8.5')
               $query .= "
               JOB_CRITICAL,";
           if($tws_config['cpuinfo']['version']>='9.3')
               $query .= "
               JOB_NOP,";
           if ($tws_config['cpuinfo']['version']>'9.4')
              $query .= "JOB_DEADLINE_ACTION,";

           $query .= "
           JOB_TIME_DEPENDENT,
           JOB_COMMENT

         FROM     $schema.JOB_JOBS                    JOB
            JOIN  $schema.AJB_ABSTRACT_JOBS           AJB      ON    AJB.AJB_ID     =  JOB.AJB_ID
            JOIN  $schema.AJS_ABSTRACT_JOB_STREAMS    AJS      ON    AJB.AJS_ID     =  AJS.AJS_ID
            JOIN  $schema.WKC_WORKSTATION_CLASSES     JST_WKC  ON    JST_WKC.WKC_ID =  AJS.WKC_ID
            JOIN  $schema.JOD_JOB_DEFINITIONS         JOD      ON    JOD.JOD_ID     =  JOB.JOD_ID
            JOIN  $schema.WKC_WORKSTATION_CLASSES     JOD_WKC  ON    JOD_WKC.WKC_ID =  JOD.WKC_ID
            JOIN  $schema.JST_JOB_STREAMS             JST      ON    JST.JST_ID     =  JOB.JST_ID";

           if($tws_config['cpuinfo']['version']>='9.5')        //
              $query .=  "
              JOIN $schema.FOL_FOLDERS        JST_WKC_FOL      ON    JST_WKC_FOL.FOL_ID  =   AJS.FOL_ID
              JOIN $schema.FOL_FOLDERS        JOB_WKC_FOL      ON    JOB_WKC_FOL.FOL_ID    =  JOD.FOL_ID";

           if($tws_config['cpuinfo']['version']>='9.5002')     //
              $query .=  "
              JOIN  $schema.FOL_FOLDERS         WKC_FOL      ON   WKC_FOL.FOL_ID =  JST_WKC.FOL_ID";

         $query .= "
         WHERE";
         if($tws_config['cpuinfo']['version']>='9.5002')
            $query .= "
            WKC_FOL.FOL_PATH LIKE ? ESCAPE '/' AND";    // JOBSTREAM_WORKSTATION_FOLDER
         $query .= "
            JST_WKC.WKC_NAME     LIKE ? ESCAPE '/' ";       // JOBSTREAM_WORKSTATION_NAME
            //
         if($tws_config['cpuinfo']['version']>='9.5')
            $query .= "
            AND JST_WKC_FOL.FOL_PATH LIKE ? ESCAPE '/'";

         $query .= "
            AND AJS.AJS_NAME LIKE ? ESCAPE '/' ";

//         $query .= "
//         AND $validfrom_expr";

// TODO:
//         $query .= "
//            ORDER BY WORKSTATION, JOBSTREAM, VALID_FROM, JOB_POSITION";

   $values = array();

   if($tws_config['cpuinfo']['version']>='9.5002')
      $values[] = tws_preplike(db_string($composer_db, $workstation_folder));

   $values[] = tws_preplike(db_string($composer_db, $workstation));

   if($tws_config['cpuinfo']['version']>='9.5')
      $values[] = tws_preplike(db_string($composer_db, $jobstream_folder));

   $values[] = tws_preplike(db_string($composer_db, $jobstream));

/*     if (!empty($validfrom))
        $values[] =  db_string($composer_db, $validfrom);
*/

// Improved version:

   $query = "SELECT";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
            WKC_FOL.FOL_PATH    JS_WORKSTATION_FOLDER,";
         $query .= "
            JST_WKC.WKC_NAME         JS_WORKSTATION_NAME,";

         if ($tws_config['cpuinfo']['version']>='9.5')
            $query .= "
            JST_WKC_FOL.FOL_PATH     JOBSTREAM_FOLDER,";
         $query .= "
           AJS.AJS_NAME             JOBSTREAM_NAME,
           JST.JST_VALID_FROM       JOBSTREAM_VALID_FROM,";

      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
            JOB_WS_FOL.FOL_PATH  JOB_WORKSTATION_FOLDER,
            JOD_WKC.WKC_NAME         JOB_WORKSTATION,";

      if ($tws_config['cpuinfo']['version']>='9.5')
         $query .= "
         JOB_WKC_FOL.FOL_PATH    JOB_FOLDER,";
      $query .= "
           AJB.AJB_NAME             JOBNAME,
           JOD.JOD_NAME             DEF_JOBNAME,
           JOB_DESCRIPTION,
           JOB_COMMENT,
           JOB_START_OFFSET,
           JOB_TIME_DEPENDENT,
           JOB_LATEST_START_OFFSET,
           JOB_LATEST_START_ACTION,
           JOB_DEADLINE_OFFSET,
           JOB_REPEAT_INTERVAL,
           JOB_TIMEZONE_ID,";

     if($tws_config['cpuinfo']['version']>='9.0')
        $query .= "
        JOB_MAX_DURATION, JOB_MAX_DURATION_ACTION, JOB_MAX_DURATION_TYPE,
        JOB_MIN_DURATION, JOB_MIN_DURATION_ACTION, JOB_MIN_DURATION_TYPE,";

           $query .= "
           JOB_PRIORITY,
           JOB_REQUIRES_CONFIRMATION,
           JOB_MONITORED,
           JOB_POSITION,";
           if($tws_config['cpuinfo']['version']>='8.5')
               $query .= "
               JOB_CRITICAL,";
           if($tws_config['cpuinfo']['version']>='9.3')
               $query .= "
               JOB_NOP,";
           if ($tws_config['cpuinfo']['version']>'9.4')
              $query .= "JOB_DEADLINE_ACTION,";

           $query .= "
           JOB_TIME_DEPENDENT,
           JOB_COMMENT";

   $query .= "
   FROM
      $schema.JOB_JOBS                    JOB
      JOIN  $schema.AJB_ABSTRACT_JOBS           AJB      ON    AJB.AJB_ID     =  JOB.AJB_ID
      JOIN  $schema.AJS_ABSTRACT_JOB_STREAMS    AJS      ON    AJB.AJS_ID     =  AJS.AJS_ID
      JOIN  $schema.WKC_WORKSTATION_CLASSES     JST_WKC  ON    JST_WKC.WKC_ID =  AJS.WKC_ID
      JOIN  $schema.JOD_JOB_DEFINITIONS         JOD      ON    JOD.JOD_ID     =  JOB.JOD_ID
      JOIN  $schema.WKC_WORKSTATION_CLASSES     JOD_WKC  ON    JOD_WKC.WKC_ID =  JOD.WKC_ID
      JOIN  $schema.JST_JOB_STREAMS             JST      ON    JST.JST_ID     =  JOB.JST_ID";

      if($tws_config['cpuinfo']['version']>='9.5002')     // JS WORKSTATION Folder
         $query .=  "
         JOIN $schema.FOL_FOLDERS        WKC_FOL      ON        WKC_FOL.FOL_ID =  JST_WKC.FOL_ID";

      if($tws_config['cpuinfo']['version']>='9.5') // JS Folder && JOB Folder
        $query .= "
        JOIN $schema.FOL_FOLDERS        JST_WKC_FOL      ON    JST_WKC_FOL.FOL_ID  =   AJS.FOL_ID
        JOIN $schema.FOL_FOLDERS        JOB_WS_FOL      ON    JOB_WS_FOL.FOL_ID    =  JOD_WKC.FOL_ID";

      if($tws_config['cpuinfo']['version']>='9.5002')     // JOB WORKSTATION Folder
         $query .=  "
         JOIN $schema.FOL_FOLDERS        JOB_WKC_FOL      ON    JOB_WKC_FOL.FOL_ID    =  JOD.FOL_ID";

      $query .=  "
      WHERE";
         if($tws_config['cpuinfo']['version']>='9.5002')
            $query .= "
            WKC_FOL.FOL_PATH LIKE ? ESCAPE '/' AND";    // JOBSTREAM_WORKSTATION_FOLDER
         $query .= "
            JST_WKC.WKC_NAME     LIKE ? ESCAPE '/' ";       // JOBSTREAM_WORKSTATION_NAME
            //
         if($tws_config['cpuinfo']['version']>='9.5')
            $query .= "
            AND JST_WKC_FOL.FOL_PATH LIKE ? ESCAPE '/'";

         $query .= "
            AND AJS.AJS_NAME LIKE ? ESCAPE '/' ";

   $values = array();

   if($tws_config['cpuinfo']['version']>='9.5002')
      $values[] = tws_preplike(db_string($composer_db, $workstation_folder));

   $values[] = tws_preplike(db_string($composer_db, $workstation));

   if($tws_config['cpuinfo']['version']>='9.5')
      $values[] = tws_preplike(db_string($composer_db, $jobstream_folder));

   $values[] = tws_preplike(db_string($composer_db, $jobstream));

/*     if (!empty($validfrom))
        $values[] =  db_string($composer_db, $validfrom);
*/

   tws_log("tws_get_jobstream_jobs DB query: $query");
   tws_log('tws_get_jobstream_jobs Query values: '.var_export($values, true));

      $stmt=new db_statement($composer_db, $query);
      if ($stmt->prepare()==FALSE){
         unset($stmt);
         tws_error('', 'Database query prepare failed: '.$query);
         return FALSE;
      }
      $composer_db[$st_name] = $stmt;
   }
   else $stmt = $composer_db[$st_name];

   if ($stmt->execute($values)==false){
      tws_error('', 'Database query failed: '.$stmt->sql());
      return FALSE;
   }

   $jobs=Array();
   $i=0;

   while( $stmt->fetch() ){
      $row = $stmt->row();
      if($row['JOB_POSITION'] == -1)   // IWS 9.4 start condition job - don't show in job list
         continue;

      $job_folder = '';
      if(!empty($row['JOB_FOLDER']))
         $job_folder = $row['JOB_FOLDER'];

      $ws_folder = '';     // Stream WS Folder
      if(!empty($row['WS_FOLDER']))
         $ws_folder = $row['WS_FOLDER'];

      $job_ws_folder = '';
      if(!empty($row['JOB_WORKSTATION_FOLDER']))
         $job_ws_folder = $row['JOB_WORKSTATION_FOLDER'];

      tws_log('-- tws_get_jobstream_jobs row Results:'. var_export($row, true));

      if ($row['JOBNAME'] == $row['DEF_JOBNAME'] || trim($row['JOBNAME'])=='') {    // job without alias
         $jobs['jobname'][$i] = $job_ws_folder.$row['JOB_WORKSTATION']."#".$job_folder.$row['DEF_JOBNAME'];

//         $tws_jobstream_jobs[$row['JOB_WORKSTATION']."#".$row['DEF_JOBNAME']] = $jobs['jobname'][$i];  //
      }
      else {
         $jobs['jobname'][$i] = $job_ws_folder.$row['JOB_WORKSTATION']."#".$job_folder.$row['DEF_JOBNAME']." AS ".$row['JOBNAME'];
         $jobs['jobalias'][$jobs['jobname'][$i]] = $row['JOBNAME'];

//         $shortname = $row['JOB_WORKSTATION']."#".$row['DEF_JOBNAME']." AS ".$row['JOBNAME'];
//         $tws_jobstream_jobs[$shortname] = $jobs['jobname'][$i];  //
      }

      if ($row['JOB_COMMENT']!="") {
         $jobs['jobdescription'][$jobs['jobname'][$i]]=trim($row['JOB_COMMENT'], "\r\n");
      }
      if ($row['JOB_START_OFFSET']!=-1) {
         tws_get_at_time($row['JOB_START_OFFSET'],
               $jobs['jobathour'][$jobs['jobname'][$i]],
               $jobs['jobatminute'][$jobs['jobname'][$i]], $temp, $jobs['jobatplusdays'][$jobs['jobname'][$i]] );
      }
      $jobs['job_time_dependent'][$jobs['jobname'][$i]] = $row['JOB_TIME_DEPENDENT'];
      if ($row['JOB_LATEST_START_OFFSET']!=-1) {
         tws_get_at_time($row['JOB_LATEST_START_OFFSET'],
               $jobs['jobuntilhour'][$jobs['jobname'][$i]],
               $jobs['jobuntilminute'][$jobs['jobname'][$i]], $temp, $jobs['jobuntilplusdays'][$jobs['jobname'][$i]] );
      }
      if ($row['JOB_LATEST_START_ACTION'] != '-') {
         $jobs['jobonuntil'][$jobs['jobname'][$i]]=tws_typeval('ONUNTIL',$row['JOB_LATEST_START_ACTION']);
      }
      if ($row['JOB_DEADLINE_OFFSET']!=-1) {
         tws_get_at_time($row['JOB_DEADLINE_OFFSET'],
               $jobs['jobdeadlinehour'][$jobs['jobname'][$i]],
               $jobs['jobdeadlineminute'][$jobs['jobname'][$i]],
               $temp,
               $jobs['jobdeadlineplusdays'][$jobs['jobname'][$i]] );
         // IWS 9.4
         if(isset($row['JOB_DEADLINE_ACTION']) && $row['JOB_DEADLINE_ACTION'] != '-')
            $jobs['jobdeadlineaction'][$jobs['jobname'][$i]] = 'Y';
      }
      if ($row['JOB_REPEAT_INTERVAL']!=-1) {
         tws_get_at_time($row['JOB_REPEAT_INTERVAL'],
               $jobs['jobeveryhour'][$jobs['jobname'][$i]],$jobs['jobeveryminute'][$jobs['jobname'][$i]],$temp,$temp);
      }
      if($tws_config['cpuinfo']['version']>='9.0'){
      // JOB_MAX_DURATION, JOB_MAX_DURATION_ACTION, JOB_MAX_DURATION_TYPE, JOB_MIN_DURATION, JOB_MIN_DURATION_ACTION, JOB_MIN_DURATION_TYPE
         if($row['JOB_MAX_DURATION_TYPE'] != '-'){
            $jobs['maxdur_type'][$jobs['jobname'][$i]]=$row['JOB_MAX_DURATION_TYPE'];
            if($row['JOB_MAX_DURATION_TYPE'] == 'M')  // milisecunds
               tws_get_at_time($row['JOB_MAX_DURATION'], $jobs['maxdur_hour'][$jobs['jobname'][$i]], $jobs['maxdur_minute'][$jobs['jobname'][$i]], $temp,$temp);
            else $jobs['maxdur_percent'][$jobs['jobname'][$i]]=$row['JOB_MAX_DURATION'];
            $jobs['maxdur_action'][$jobs['jobname'][$i]]=$row['JOB_MAX_DURATION_ACTION'];
         }
         if($row['JOB_MIN_DURATION_TYPE'] != '-'){
            $jobs['mindur_type'][$jobs['jobname'][$i]]=$row['JOB_MIN_DURATION_TYPE'];
            if($row['JOB_MIN_DURATION_TYPE'] == 'M')  // milisecunds
               tws_get_at_time($row['JOB_MIN_DURATION'], $jobs['mindur_hour'][$jobs['jobname'][$i]], $jobs['mindur_minute'][$jobs['jobname'][$i]], $temp,$temp);
            else $jobs['mindur_percent'][$jobs['jobname'][$i]]=$row['JOB_MIN_DURATION'];
            $jobs['mindur_action'][$jobs['jobname'][$i]]=$row['JOB_MIN_DURATION_ACTION'];
         }
      }

      $jobs['jobtime_zone'][$jobs['jobname'][$i]]=$row['JOB_TIMEZONE_ID'];
      $jobs['jobpriority'][$jobs['jobname'][$i]]=($row['JOB_PRIORITY']==10 ? '' : $row['JOB_PRIORITY']);
      $jobs['jobconfirmed'][$jobs['jobname'][$i]]=tws_yesno($row['JOB_REQUIRES_CONFIRMATION']);
      $jobs['jobkeyjob'][$jobs['jobname'][$i]]=tws_yesno($row['JOB_MONITORED']);
      if ($tws_config['cpuinfo']['version']>='8.5')
         $jobs['jobcritical'][$jobs['jobname'][$i]]=tws_yesno($row['JOB_CRITICAL']);
      if ($tws_config['cpuinfo']['version']>='9.3')
         $jobs['jobnop'][$jobs['jobname'][$i]]=tws_yesno($row['JOB_NOP']);

      if ($tws_config['cpuinfo']['version']>='9.5')
         $jobs['job_folder'][$jobs['jobname'][$i]] = $row['JOB_FILDER'];

      if ($tws_config['cpuinfo']['version']>='9.5002')
         $jobs['ws_folder'][$jobs['jobname'][$i]] = $row['WS_FOLDER'];

      $jobs['def_jobname'][$jobs['jobname'][$i]] = $row['DEF_JOBNAME'];
      $jobs['job_workstation'][$jobs['jobname'][$i]] = $row['JOB_WORKSTATION'];

      $i++;
   }
   // if ($row!==0) return FALSE;
   $jobs['job_num']=$i;
   tws_log('-- tws_get_jobstream_jobs Result: '.var_export($jobs, true));
   return $jobs;
}



///////////////////////////////////////////////////////////////////////////////
//
// Get Job follows jobstreams
//    // Arguments:
//    workstation = parameter name
//    jobstream   = jobstream name
//    validfrom   = valid from
//    $job        = job name
//
//  return list of jobstreams which are predecessors of the job instance specified
//  SQL query return also the original name of job and its workstation
//  and also the matching criteria
//
function tws_get_job_dep_jobstream($workstation='', $jobstream='', $validfrom='', $job=''){
   global $tws_config, $composer_db;
// ???   global $tws_jobstream_jobs;   // arr[short_job_name] => full_job_name (with folder if exist)
   tws_log('-- tws_get_job_dep_jobstream (start at '.basename(__FILE__).'['.__LINE__.'])');
   tws_log("-- parameters: $workstation, $jobstream, $job");

   if ($job=='') $job='@';
   if ($workstation=='') $workstation='@';
   if ($jobstream=='') $jobstream='@';

   if ($tws_config['cpuinfo']['version']>='9.5')
      list($jobstream_folder, $jobstream) = tws_divide_folder($jobstream);
   if ($tws_config['cpuinfo']['version']>='9.5002')
      list($workstation_folder, $workstation) = tws_divide_folder($workstation);

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema = $composer_db['schema'];

   if ($validfrom == '') {
      $validfrom_expr = "JST.JST_VALID_FROM IS NULL";
      $st_name = 'JOB_DEP_STREAM';
   } else {
      $validfrom_expr = "JST.JST_VALID_FROM = ?";
      $st_name = 'JOB_DEP_STREAM_VALID';
   }
   $depstream=Array();
   //access rights checking
   $secsel= array('CPU'=>'PRED_WKC.WKC_NAME','NAME'=>'PRED_AJS.AJS_NAME');
   if ($tws_config['cpuinfo']['version']>='9.5')
       $secsel['FOLDER'] = 'FOL_PATH';
   if (($acc_sql=tws_sec_check('JOB', $secsel))===FALSE) return $depstream;

   if(!isset($composer_db[$st_name])){

// TODO: check $acc_sql:
   // ((PRED_WKC.WKC_NAME  LIKE '%' ESCAPE '/' AND FOL_PATH  LIKE '//' ESCAPE '/')
   // OR (PRED_WKC.WKC_NAME  LIKE '%' ESCAPE '/' AND PRED_AJS.AJS_NAME  LIKE '%' ESCAPE '/'))

         $query="
         SELECT
           WKC.WKC_NAME       WORKSTATION,
           AJS.AJS_NAME       STREAM,
           JST.JST_VALID_FROM VALIDFROM,
           AJB.AJB_NAME       ASJOB,
           JOB_WKC.WKC_NAME   JOB_WORKSTATION,
           JOD.JOD_NAME       JOB_NAME,

           PRED_WKC.WKC_NAME  PRED_WORKSTATION,
           PRED_AJS.AJS_NAME  PRED_STREAM,";
           if($tws_config['cpuinfo']['version']>='9.5')
              $query .= "
              PRED_JS_FOL.FOL_PATH   PRED_JS_FOLDER,
              JOB_WKC_FOL.FOL_PATH    JOB_FOLDER,  ";

           if($tws_config['cpuinfo']['version']>='9.5002')
               $query .= "
               WS_FOLDERS.FOL_PATH   WS_FOLDER,
               PRED_WS_FOLDER.FOL_PATH   PREWS_FOLDER,";
         $query .= "
           FDP.FDP_RULE MATCHING,
           FDP.FDP_RULE_START_OFFSET MATCHING_FROM,
           FDP.FDP_RULE_END_OFFSET MATCHING_TO
         FROM (((((((((
            $schema.FDP_FOLLOWS_DEPS FDP
            JOIN $schema.JOB_JOBS                  JOB   ON JOB.JOB_ID = FDP.JOB_ID)
            JOIN $schema.AJB_ABSTRACT_JOBS         AJB   ON AJB.AJB_ID = JOB.AJB_ID)
            JOIN $schema.JST_JOB_STREAMS           JST   ON JST.JST_ID = JOB.JST_ID)
            JOIN $schema.AJS_ABSTRACT_JOB_STREAMS  AJS   ON AJS.AJS_ID = JST.AJS_ID)
            JOIN $schema.WKC_WORKSTATION_CLASSES   WKC   ON WKC.WKC_ID = AJS.WKC_ID)
            JOIN $schema.JOD_JOB_DEFINITIONS       JOD   ON JOD.JOD_ID = JOB.JOD_ID)
            JOIN $schema.WKC_WORKSTATION_CLASSES   JOB_WKC     ON JOB_WKC.WKC_ID = JOD.WKC_ID)
            JOIN $schema.AJS_ABSTRACT_JOB_STREAMS  PRED_AJS    ON PRED_AJS.AJS_ID = FDP.AJS_PRED_ID)
            JOIN $schema.WKC_WORKSTATION_CLASSES   PRED_WKC    ON PRED_WKC.WKC_ID = PRED_AJS.WKC_ID)";
           if($tws_config['cpuinfo']['version']>='9.5')
              $query .= "
                 LEFT JOIN $schema.FOL_FOLDERS   JS_FOLDER  ON  JS_FOLDER.FOL_ID = AJS.FOL_ID
                LEFT JOIN $schema.FOL_FOLDERS        JOB_WKC_FOL      ON    JOB_WKC_FOL.FOL_ID    =  JOD.FOL_ID
                LEFT JOIN $schema.FOL_FOLDERS        PRED_JS_FOL      ON     PRED_JS_FOL .FOL_ID    =  PRED_AJS.FOL_ID";
           if($tws_config['cpuinfo']['version']>='9.5002')
              $query .= "
                 LEFT JOIN $schema.FOL_FOLDERS   WS_FOLDERS ON  WS_FOLDERS.FOL_ID = JOB_WKC.FOL_ID
                LEFT JOIN $schema.FOL_FOLDERS   PRED_WS_FOLDER ON  PRED_WS_FOLDER.FOL_ID = PRED_WKC.FOL_ID
                LEFT JOIN $schema.FOL_FOLDERS   WSJS_FOLDERS ON  WSJS_FOLDERS.FOL_ID = WKC.FOL_ID";
         $query .= "
           WHERE
            WKC.WKC_NAME LIKE ? ESCAPE '/' AND
            AJS.AJS_NAME LIKE ? ESCAPE '/' AND
            AJB.AJB_NAME LIKE ? ESCAPE '/' AND
            $validfrom_expr";
            if($tws_config['cpuinfo']['version']>='9.5')
               $query .= "
                  AND JS_FOLDER.FOL_PATH = ?";
            if($tws_config['cpuinfo']['version']>='9.5002')
               $query .= "
                  AND WSJS_FOLDERS.FOL_PATH = ?";
//            $acc_sql";

         $stmt=new db_statement($composer_db, $query);
         if ($stmt->prepare()==FALSE){
            unset($stmt);
            tws_error('', 'Database query prepare failed: '.$query);
            return FALSE;
         }
         $composer_db[$st_name] = $stmt;
      }
      else
         $stmt = $composer_db[$st_name];

      $values = array(tws_preplike(db_string($composer_db, $workstation)), tws_preplike(db_string($composer_db, $jobstream)), tws_preplike(db_string($composer_db, $job)));
      if (!empty($validfrom))
         $values[] =  db_string($composer_db, $validfrom);
      if($tws_config['cpuinfo']['version']>='9.5')
         $values[] =  db_string($composer_db, $jobstream_folder);
      if($tws_config['cpuinfo']['version']>='9.5002')
         $values[] =  db_string($composer_db, $workstation_folder);

      tws_log("-- tws_get_job_dep_jobstream DB query: $query");
      tws_log('Query values: '.var_export($values, true));

      if ($stmt->execute($values)==false){
         tws_error('', 'Database query failed: '.$stmt->sql());
         return FALSE;
      }
   $i=0;
   $count = 0;
   $temp='';

   while( $stmt->fetch() ){
      $row = $stmt->row();
      tws_log('-- tws_get_job_dep_jobstream row: '.var_export($row, true));
      if($tws_config['cpuinfo']['version']>='9.5002')
          $jobname=$row['WS_FOLDER'].$row['JOB_WORKSTATION']."#";
      else
          $jobname=$row['JOB_WORKSTATION']."#";
       if($tws_config['cpuinfo']['version']>='9.5')
           $jobname.=$row['JOB_FOLDER'].$row['JOB_NAME'];
       else
           $jobname.=$row['JOB_NAME'];

      // JOB ALIAS
      if ($row['JOB_NAME'] != $row['ASJOB'])
         $jobname.=" AS ".$row['ASJOB'];

      //
      $pred_workstation_folder = '';
      if($tws_config['cpuinfo']['version']>='9.5002')
         $pred_workstation_folder = $row['PREWS_FOLDER'];
      $depstream['jobfollowsjobstreamcpu'][$jobname][] = $pred_workstation_folder.$row['PRED_WORKSTATION'];

      $pred_jobstream_folder = '';
      if($tws_config['cpuinfo']['version']>='9.5')
         $pred_jobstream_folder = $row['PRED_JS_FOLDER'];
      $depstream['jobfollowsjobstreamname'][$jobname][] = $pred_jobstream_folder.$row['PRED_STREAM'];

      $depstream['jobfollowsjobstreammatching'][$jobname][] = tws_typeval('MATCHING',$row['MATCHING']);

if($tws_config['cpuinfo']['version']>='9.3'){
      $depstream['job_js_abend'][$jobname][] = $row['ON_ABEND'];
      $depstream['job_js_success'][$jobname][] = $row['ON_SUCCESS'];
      $depstream['job_js_suppress'][$jobname][] = $row['ON_SUPPRESS'];
      $depstream['job_js_join_name'][$jobname][] = $row['JOIN_NAME'];
      $depstream['job_js_join_quantity'][$jobname][] = $row['JOIN_QUANTITY'];
}

// the same with indexes for Netplan
      $depstream['dep_cpu'][$jobname][] = $pred_workstation_folder.$row['PRED_WORKSTATION'];
      $depstream['dep_jobstream'][$jobname][] = $pred_stream_folder.$row['PRED_STREAM'];
      $depstream['match'][$jobname][] = tws_typeval('MATCHING',$row['MATCHING']);
      $depstream['match_from'][$jobname][] = $row['MATCHING_FROM'];
      $depstream['match_to'][$jobname][] = $row['MATCHING_TO'];

         switch (tws_typeval('MATCHING',$row['MATCHING'])) {
            case "RELATIVE":
               if ($row['MATCHING_FROM'] < 0) {
                  $row['MATCHING_FROM'] *= -1;
                  $depstream['jobfollowsjobstreammatchingrelativefromdir'][$jobname][] = "-";
               } else { $depstream['jobfollowsjobstreammatchingrelativefromdir'][$jobname][] = "+"; }
               tws_get_at_time(($row['MATCHING_FROM']),
                        $depstream['jobfollowsjobstreammatchingrelativefromhour'][$jobname][],
                        $depstream['jobfollowsjobstreammatchingrelativefromminute'][$jobname][],
                        $temp, $temp, 'RELATIVE_OFFSET');
               if ($row['MATCHING_TO'] < 0) {
                  $row['MATCHING_TO'] *= -1;
                  $depstream['jobfollowsjobstreammatchingrelativetodir'][$jobname][] = "-";
               } else { $depstream['jobfollowsjobstreammatchingrelativetodir'][$jobname][] = "+"; }
               tws_get_at_time($row['MATCHING_TO'],
                     $depstream['jobfollowsjobstreammatchingrelativetohour'][$jobname][],
                     $depstream['jobfollowsjobstreammatchingrelativetominute'][$jobname][],
                     $temp, $temp, 'RELATIVE_OFFSET');
               break;
            case "ABSOLUTE":
               $day = (1000 * 60 * 60 * 24);
               if ($row['MATCHING_FROM'] < 0) {
                  $depstream['jobfollowsjobstreammatchingabsolutefromdir'][$jobname][] = "-";
                  $depstream['jobfollowsjobstreammatchingabsolutefromdays'][$jobname][]= strval(-1*(floor($row['MATCHING_FROM']/($day))));
                  $rest = ($row['MATCHING_FROM']%($day)+($day));
                  tws_get_at_time($rest,$depstream['jobfollowsjobstreammatchingabsolutefromhour'][$jobname][],
                        $depstream['jobfollowsjobstreammatchingabsolutefromminute'][$jobname][],
                        $temp,$temp);
               } else {
                  tws_get_at_time($row['MATCHING_FROM'],$depstream['jobfollowsjobstreammatchingabsolutefromhour'][$jobname][],
                     $depstream['jobfollowsjobstreammatchingabsolutefromminute'][$jobname][],$temp,
                     $depstream['jobfollowsjobstreammatchingabsolutefromdays'][$jobname][]);
                  $depstream['jobfollowsjobstreammatchingabsolutefromdir'][$jobname][] = "+";
               }
               if ($row['MATCHING_TO'] < 0) {
                  $depstream['jobfollowsjobstreammatchingabsolutetodir'][$jobname][] = "-";
                  $depstream['jobfollowsjobstreammatchingabsolutetodays'][$jobname][]= strval(-1*(floor($row['MATCHING_TO']/($day))));
                  $rest = ($row['MATCHING_TO']%($day)+($day));
                  tws_get_at_time($rest,$depstream['jobfollowsjobstreammatchingabsolutetohour'][$jobname][],
                        $depstream['jobfollowsjobstreammatchingabsolutetominute'][$jobname][],
                        $temp,$temp);
               } else {
                  tws_get_at_time($row['MATCHING_TO'],$depstream['jobfollowsjobstreammatchingabsolutetohour'][$jobname][],
                        $depstream['jobfollowsjobstreammatchingabsolutetominute'][$jobname][], $temp,
                        $depstream['jobfollowsjobstreammatchingabsolutetodays'][$jobname][]);
                  $depstream['jobfollowsjobstreammatchingabsolutetodir'][$jobname][] = "+";
               }
         }
      $count++;
   }
tws_log("-- Job -> Stream dependency depstream: ". var_export($depstream, true));

// Conditional Job -> Stream dependency
if($tws_config['cpuinfo']['version']>='9.3'){
tws_log("-- Conditional Job -> Stream dependency");
   if ($validfrom == '')
      $validfrom_expr = "DEP_JS.JST_VALID_FROM IS NULL";
   else $validfrom_expr = "DEP_JS.JST_VALID_FROM = '".db_string($composer_db,$validfrom)."'";
   // TODO: access rights checking
   if (($acc_sql=tws_sec_check('JOB', array('CPU'=>'PRED_WKC.WKC_NAME','NAME'=>'PRED_AJS.AJS_NAME')))===FALSE) return $depstream;

   $query = "
   SELECT
      WKC.WKC_NAME            WKS_NAME,
      JS.AJS_NAME             STREAM_NAME,

      DEP_JOD_WKC.WKC_NAME        DEP_WKS_NAME,
      DEP_AJS.AJS_NAME        DEP_STREAM_NAME,
      DEP_JS.JST_VALID_FROM   DEP_STREAM_VALID_FROM,
      DEP_JS.JST_VALID_TO     DEP_STREAM_VALID_TO,
      DEP_JOD_WKC.WKC_NAME    DEP_JOB_WKS,
      DEP_AJB.AJB_NAME        DEP_AS_JOB,
      JOD_NAME                DEP_JOB,";
      if($tws_config['cpuinfo']['version']>='9.5')
         $query .= "
         DEP_JS_FOL.FOL_PATH      DEP_JS_PATH,
         JOB_FOL.FOL_PATH JOB_FOLDER,";
      if($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
         DEP_WS_FOL.FOL_PATH      DEP_WS_PATH,
        JS_FOL.FOL_PATH JS_FOLDER,
        JS_WKC.FOL_PATH JSWS_FOLDER,
            ";
      $query .= "
      $schema.CDP_CONDITIONAL_DEPS.CDP_SUCCESS     ON_SUCCESS,
      $schema.CDP_CONDITIONAL_DEPS.CDP_ABEND       ON_ABEND,
      $schema.CDP_CONDITIONAL_DEPS.CDP_SUPPRESS    ON_SUPPRESS,
       $schema.CDP_CONDITIONAL_DEPS.CDP_RULE       MATCHING,
       $schema.CDP_CONDITIONAL_DEPS.CDP_RULE_START_OFFSET   MATCHING_FROM,
       $schema.CDP_CONDITIONAL_DEPS.CDP_RULE_END_OFFSET     MATCHING_TO,
       CJO.CJO_NAME JOIN_NAME,
       CJO.CJO_QUANTITY JOIN_QUANTITY,
       CJO.CJO_DESCRIPTION JOIN_DESCRIPTION
   FROM   (((((((((($schema.AJS_ABSTRACT_JOB_STREAMS  JS
      JOIN $schema.WKC_WORKSTATION_CLASSES            WKC         ON JS.WKC_ID = WKC.WKC_ID)
      JOIN $schema.CDP_CONDITIONAL_DEPS                           ON JS.AJS_ID = $schema.CDP_CONDITIONAL_DEPS.AJS_PRED_ID)
      JOIN $schema.JOB_JOBS                           DEP_JOB     ON DEP_JOB.JOB_ID = $schema.CDP_CONDITIONAL_DEPS.JOB_ID)
      JOIN $schema.AJB_ABSTRACT_JOBS                  DEP_AJB     ON DEP_AJB.AJB_ID = DEP_JOB.AJB_ID)
      JOIN $schema.JOD_JOB_DEFINITIONS                            ON $schema.JOD_JOB_DEFINITIONS.JOD_ID = DEP_JOB.JOD_ID)
      JOIN $schema.WKC_WORKSTATION_CLASSES            DEP_JOD_WKC ON $schema.JOD_JOB_DEFINITIONS.WKC_ID = DEP_JOD_WKC.WKC_ID)
      JOIN $schema.JST_JOB_STREAMS                    DEP_JS      ON DEP_JS.JST_ID = DEP_JOB.JST_ID)
      JOIN $schema.AJS_ABSTRACT_JOB_STREAMS           DEP_AJS     ON DEP_JS.AJS_ID = DEP_AJS.AJS_ID)
      JOIN $schema.WKC_WORKSTATION_CLASSES            DEP_WKC     ON DEP_AJS.WKC_ID = DEP_WKC.WKC_ID)
      LEFT JOIN $schema.CJO_CONDITIONAL_JOIN          CJO         ON CJO.CJO_ID = $schema.CDP_CONDITIONAL_DEPS.CJO_ID)";
      if($tws_config['cpuinfo']['version']>='9.5')
         $query .= "
         LEFT JOIN $schema.FOL_FOLDERS                DEP_JS_FOL  ON DEP_JS_FOL.FOL_ID = DEP_AJS.FOL_ID
         LEFT JOIN $schema.FOL_FOLDERS                JOB_FOL  ON JOB_FOL.FOL_ID = $schema.JOD_JOB_DEFINITIONS.FOL_ID";
      if($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
         LEFT JOIN $schema.FOL_FOLDERS                DEP_WS_FOL  ON DEP_WS_FOL.FOL_ID = DEP_JOD_WKC.FOL_ID
          LEFT JOIN $schema.FOL_FOLDERS                JS_FOL  ON JS_FOL.FOL_ID = JS.FOL_ID
         LEFT JOIN $schema.FOL_FOLDERS                JS_WKC  ON JS_WKC.FOL_ID = DEP_WKC.FOL_ID   ";
      $query .= "
      WHERE  CDP_TYPE = 'S' AND
         DEP_WKC.WKC_NAME = '".db_string($composer_db,$workstation)."' AND
         DEP_AJS.AJS_NAME = '".db_string($composer_db,$jobstream)."' AND
         DEP_AJB.AJB_NAME LIKE '".tws_preplike(db_string($composer_db,$job))."' ESCAPE '/' AND
      $validfrom_expr";
      if($tws_config['cpuinfo']['version']>='9.5')
         $query .= "
            AND DEP_JS_FOL.FOL_PATH = '".db_string($composer_db, $jobstream_folder)."'";
// TODO:
      if($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
            AND JS_WKC.FOL_PATH = '".db_string($composer_db, $workstation_folder)."'";

      if (!($r=db_query($composer_db, $query))) {
         tws_error('', 'Database query failed');
         return $depstream;
      }

      tws_log("Conditions job_dep_stream Query: $query");

      while(($row = db_fetch_row( $composer_db)) != false){
//         tws_log('Conditions job_dep_stream row: '.var_export($row, true));

      if($tws_config['cpuinfo']['version']>='9.5'){
         $job_folder = $row['JOB_FOLDER'];
         tws_log("job_folder: $job_folder");
         $pred_stream_folder = $row['JS_FOLDER'];
         tws_log("pred_stream_folder: $pred_stream_folder");
      }
      $pred_ws_folder = '';
        if ($tws_config['cpuinfo']['version'] >= '9.5002'){
            $jobname = $row['DEP_WS_PATH'] . $row['DEP_WKS_NAME'] . "#";
            $pred_ws_folder =$row['JSWS_FOLDER'];
        }else
            $jobname = $row['DEP_WKS_NAME'] . "#";
        if ($tws_config['cpuinfo']['version'] >= '9.5')
            $jobname .= $row['JOB_FOLDER'] . $row['DEP_JOB'];
        else
            $jobname .= $row['DEP_JOB'];

        // JOB ALIAS
        if ($row['DEP_JOB'] != $row['DEP_AS_JOB'])
            $jobname .= " AS " . $row['DEP_AS_JOB'];

      $depstream['jobfollowsjobstreamcpu'][$jobname][]= $pred_ws_folder.$row['WKS_NAME'];
      $depstream['jobfollowsjobstreamname'][$jobname][] = $pred_stream_folder.$row['STREAM_NAME'];
      $depstream['jobfollowsjobstreammatching'][$jobname][] = tws_typeval('MATCHING',$row['MATCHING']);
      $depstream['job_js_abend'][$jobname][] = $row['ON_ABEND'];
      $depstream['job_js_success'][$jobname][] = $row['ON_SUCCESS'];
      $depstream['job_js_suppress'][$jobname][] = $row['ON_SUPPRESS'];

      $depstream['job_js_join_name'][$jobname][] = $row['JOIN_NAME'];
      $depstream['job_js_join_quantity'][$jobname][] = $row['JOIN_QUANTITY'];
      $depstream['job_js_join_description'][$jobname][] = $row['JOIN_DESCRIPTION'];

      // the same with indexes for Netplan
         $depstream['dep_cpu'][$jobname][] = $row['WKS_NAME'];
         $depstream['dep_jobstream'][$jobname][] = $pred_stream_folder.$row['STREAM_NAME'];
         $depstream['match'][$jobname][] = tws_typeval('MATCHING',$row['MATCHING']);
         $depstream['match_from'][$jobname][] = $row['MATCHING_FROM'];
         $depstream['match_to'][$jobname][] = $row['MATCHING_TO'];

         switch (tws_typeval('MATCHING',$row['MATCHING'])) {
            case "RELATIVE":
               if ($row['MATCHING_FROM'] < 0) {
                  $row['MATCHING_FROM'] *= -1;
                  $depstream['jobfollowsjobstreammatchingrelativefromdir'][$jobname][] = "-";
               } else { $depstream['jobfollowsjobstreammatchingrelativefromdir'][$jobname][] = "+"; }
               tws_get_at_time(($row['MATCHING_FROM']),
                        $depstream['jobfollowsjobstreammatchingrelativefromhour'][$jobname][],
                        $depstream['jobfollowsjobstreammatchingrelativefromminute'][$jobname][],
                        $temp, $temp, 'RELATIVE_OFFSET');
               if ($row['MATCHING_TO'] < 0) {
                  $row['MATCHING_TO'] *= -1;
                  $depstream['jobfollowsjobstreammatchingrelativetodir'][$jobname][] = "-";
               } else { $depstream['jobfollowsjobstreammatchingrelativetodir'][$jobname][] = "+"; }
               tws_get_at_time($row['MATCHING_TO'],
                     $depstream['jobfollowsjobstreammatchingrelativetohour'][$jobname][],
                     $depstream['jobfollowsjobstreammatchingrelativetominute'][$jobname][],
                     $temp, $temp, 'RELATIVE_OFFSET');
               break;
            case "ABSOLUTE":
               $day = (1000 * 60 * 60 * 24);
               if ($row['MATCHING_FROM'] < 0) {
                  $depstream['jobfollowsjobstreammatchingabsolutefromdir'][$jobname][] = "-";
                  $depstream['jobfollowsjobstreammatchingabsolutefromdays'][$jobname][]= strval(-1*(floor($row['MATCHING_FROM']/($day))));
                  $rest = ($row['MATCHING_FROM']%($day)+($day));
                  tws_get_at_time($rest,$depstream['jobfollowsjobstreammatchingabsolutefromhour'][$jobname][],
                        $depstream['jobfollowsjobstreammatchingabsolutefromminute'][$jobname][],
                        $temp,$temp);
               } else {
                  tws_get_at_time($row['MATCHING_FROM'],$depstream['jobfollowsjobstreammatchingabsolutefromhour'][$jobname][],
                     $depstream['jobfollowsjobstreammatchingabsolutefromminute'][$jobname][],$temp,
                     $depstream['jobfollowsjobstreammatchingabsolutefromdays'][$jobname][]);
                  $depstream['jobfollowsjobstreammatchingabsolutefromdir'][$jobname][] = "+";
               }
               if ($row['MATCHING_TO'] < 0) {
                  $depstream['jobfollowsjobstreammatchingabsolutetodir'][$jobname][] = "-";
                  $depstream['jobfollowsjobstreammatchingabsolutetodays'][$jobname][]= strval(-1*(floor($row['MATCHING_TO']/($day))));
                  $rest = ($row['MATCHING_TO']%($day)+($day));
                  tws_get_at_time($rest,$depstream['jobfollowsjobstreammatchingabsolutetohour'][$jobname][],
                        $depstream['jobfollowsjobstreammatchingabsolutetominute'][$jobname][],
                        $temp,$temp);
               } else {
                  tws_get_at_time($row['MATCHING_TO'],$depstream['jobfollowsjobstreammatchingabsolutetohour'][$jobname][],
                        $depstream['jobfollowsjobstreammatchingabsolutetominute'][$jobname][], $temp,
                        $depstream['jobfollowsjobstreammatchingabsolutetodays'][$jobname][]);
                  $depstream['jobfollowsjobstreammatchingabsolutetodir'][$jobname][] = "+";
               }
         }
         $count++;
      }
   }
/*
// TODO:  Matching
   foreach($depstream['match'] as $jobname=>$i){
         switch ($depstream['jobfollowsjobstreammatching'][$jobname][$i]) {
            case "RELATIVE":
               if ($row['MATCHING_FROM'] < 0) {
                  $row['MATCHING_FROM'] *= -1;
                  $depstream['jobfollowsjobstreammatchingrelativefromdir'][$jobname][$i] = "-";
               } else { $depstream['jobfollowsjobstreammatchingrelativefromdir'][$jobname][$i] = "+"; }
               tws_get_at_time(($row['MATCHING_FROM']),
                        $depstream['jobfollowsjobstreammatchingrelativefromhour'][$jobname][$i],
                        $depstream['jobfollowsjobstreammatchingrelativefromminute'][$jobname][$i],
                        $temp, $temp, 'RELATIVE_OFFSET');
               if ($row['MATCHING_TO'] < 0) {
                  $row['MATCHING_TO'] *= -1;
                  $depstream['jobfollowsjobstreammatchingrelativetodir'][$jobname][$i] = "-";
               } else { $depstream['jobfollowsjobstreammatchingrelativetodir'][$jobname][$i] = "+"; }
               tws_get_at_time($row['MATCHING_TO'],
                     $depstream['jobfollowsjobstreammatchingrelativetohour'][$jobname][$i],
                     $depstream['jobfollowsjobstreammatchingrelativetominute'][$jobname][$i],
                     $temp, $temp, 'RELATIVE_OFFSET');
               break;
            case "ABSOLUTE":
               $day = (1000 * 60 * 60 * 24);
               if ($row['MATCHING_FROM'] < 0) {
                  $depstream['jobfollowsjobstreammatchingabsolutefromdir'][$jobname][$i] = "-";
                  $depstream['jobfollowsjobstreammatchingabsolutefromdays'][$jobname][$i]= strval(-1*(floor($row['MATCHING_FROM']/($day))));
                  $rest = ($row['MATCHING_FROM']%($day)+($day));
                  tws_get_at_time($rest,$depstream['jobfollowsjobstreammatchingabsolutefromhour'][$jobname][$i],
                        $depstream['jobfollowsjobstreammatchingabsolutefromminute'][$jobname][$i],
                        $temp,$temp);
               } else {
                  tws_get_at_time($row['MATCHING_FROM'],$depstream['jobfollowsjobstreammatchingabsolutefromhour'][$jobname][$i],
                     $depstream['jobfollowsjobstreammatchingabsolutefromminute'][$jobname][$i],$temp,
                     $depstream['jobfollowsjobstreammatchingabsolutefromdays'][$jobname][$i]);
                  $depstream['jobfollowsjobstreammatchingabsolutefromdir'][$jobname][$i] = "+";
               }
               if ($row['MATCHING_TO'] < 0) {
                  $depstream['jobfollowsjobstreammatchingabsolutetodir'][$jobname][$i] = "-";
                  $depstream['jobfollowsjobstreammatchingabsolutetodays'][$jobname][$i]= strval(-1*(floor($row['MATCHING_TO']/($day))));
                  $rest = ($row['MATCHING_TO']%($day)+($day));
                  tws_get_at_time($rest,$depstream['jobfollowsjobstreammatchingabsolutetohour'][$jobname][$i],
                        $depstream['jobfollowsjobstreammatchingabsolutetominute'][$jobname][$i],
                        $temp,$temp);
               } else {
                  tws_get_at_time($row['MATCHING_TO'],$depstream['jobfollowsjobstreammatchingabsolutetohour'][$jobname][$i],
                        $depstream['jobfollowsjobstreammatchingabsolutetominute'][$jobname][$i], $temp,
                        $depstream['jobfollowsjobstreammatchingabsolutetodays'][$jobname][$i]);
                  $depstream['jobfollowsjobstreammatchingabsolutetodir'][$jobname][$i] = "+";
               }
         }
   }
*/
   $depstream['jobfollowsjobstream_num']=$count;
   $depstream['count']=$count;
   tws_log('Result: '.var_export($depstream, true));
   return $depstream;
}


///////////////////////////////////////////////////////////////////////////////
//
// Get Job follows jobs
//    // Arguments:
//    workstation = parameter name
//    jobstream   = jobstream name
//    validfrom   = valid from
//    $job        = job name
//
//  return list of jobs which are predecessors to the job specified
//    SQL query return also the original name of job and its workstation (it is not used at the moment)
//
function tws_get_job_dep_job($workstation='@', $jobstream='@', $validfrom='', $job=''){
   global $tws_config, $composer_db;
   tws_log('-- tws_get_job_dep_job (start at '.basename(__FILE__).'['.__LINE__.'])');
   tws_log("-- tws_get_job_dep_job parameters: $workstation, $jobstream:$validfrom, $job");

   if($tws_config['cpuinfo']['version']>='9.5')
      list($jobstream_folder, $jobstream) = tws_divide_folder($jobstream);
   if($tws_config['cpuinfo']['version']>='9.5002')
      list($workstation_folder, $workstation) = tws_divide_folder($workstation);

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema = $composer_db['schema'];

   if ($validfrom == '') {
      $validfrom_expr = "JST.JST_VALID_FROM IS NULL";
      $st_name = 'JOB_DEP_JOB';
   } else {
      $validfrom_expr = "JST.JST_VALID_FROM = ?";
      $st_name = 'JOB_DEP_JOB_VALID';
   }

//access rights checking
   $secsel= array('CPU'=>'PRED_WKC.WKC_NAME','NAME'=>'PRED_AJB.AJB_NAME');
   if ($tws_config['cpuinfo']['version']>='9.5')
       $secsel['FOLDER'] = 'FOL_PATH';
   if ($acc_sql=tws_sec_check('JOB', $secsel)===FALSE) return $depjob;

      // --------------       COMMON PART    --------------------- //

   // normal conditioms

   if(!isset($composer_db[$st_name])){
      $query ="
         SELECT
           WKC.WKC_NAME          WORKSTATION,
           AJS.AJS_NAME          STREAM,
           JST.JST_VALID_FROM    VALIDFROM,
           AJB.AJB_NAME          ASJOB,
           JOB_WKC.WKC_NAME      JOB_WORKSTATION,
           JOD.JOD_NAME          JOB_NAME,

           PRED_WKC.WKC_NAME     PRED_WORKSTATION,
           PRED_AJS.AJS_NAME     PRED_STREAM,
           PRED_AJB.AJB_NAME     PRED_JOB,";
      ///  Stream folder
           if ($tws_config['cpuinfo']['version']>='9.5')
              $query .= "
            PREDJS_FOLDERS.FOL_PATH   PRED_STREAM_FOLDER,
            JOB_FOLDERS.FOL_PATH  JOB_FOLDER,";
      ///  WS folder
           if ($tws_config['cpuinfo']['version']>='9.5002')
              $query .= "
            WS_FOLDER.FOL_PATH   WS_FOLDER,
            WSJOB_FOLDERS.FOL_PATH  WSJOB_FOLDER,
            PREDWS_FOLDERS.FOL_PATH  PRED_WS_FOLDER, ";
           $query .= "
           FDP.FDP_TYPE          DEP_TYPE,
           FDP.FDP_RULE          MATCHING,
           FDP.FDP_RULE_START_OFFSET   MATCHING_FROM,
           FDP.FDP_RULE_END_OFFSET     MATCHING_TO
          FROM ((((((((((
                 $schema.FDP_FOLLOWS_DEPS          FDP
            JOIN $schema.JOB_JOBS                  JOB         ON JOB.JOB_ID = FDP.JOB_ID)
            JOIN $schema.AJB_ABSTRACT_JOBS         AJB         ON AJB.AJB_ID = JOB.AJB_ID)
            JOIN $schema.JST_JOB_STREAMS           JST         ON JST.JST_ID = JOB.JST_ID)
            JOIN $schema.AJS_ABSTRACT_JOB_STREAMS  AJS         ON AJS.AJS_ID = JST.AJS_ID)
            JOIN $schema.WKC_WORKSTATION_CLASSES   WKC         ON WKC.WKC_ID = AJS.WKC_ID)
            JOIN $schema.JOD_JOB_DEFINITIONS       JOD         ON JOD.JOD_ID = JOB.JOD_ID)
            JOIN $schema.WKC_WORKSTATION_CLASSES   JOB_WKC     ON JOB_WKC.WKC_ID = JOD.WKC_ID)
            JOIN $schema.AJB_ABSTRACT_JOBS         PRED_AJB    ON PRED_AJB.AJB_ID = FDP.AJB_PRED_ID)
            JOIN $schema.AJS_ABSTRACT_JOB_STREAMS  PRED_AJS    ON PRED_AJS.AJS_ID = PRED_AJB.AJS_ID)
            JOIN $schema.WKC_WORKSTATION_CLASSES   PRED_WKC    ON PRED_WKC.WKC_ID = PRED_AJS.WKC_ID)";
            if($tws_config['cpuinfo']['version']>='9.5')
               $query .= "
               LEFT JOIN $schema.FOL_FOLDERS   JS_FOLDER  ON  JS_FOLDER.FOL_ID = AJS.FOL_ID
                LEFT JOIN $schema.FOL_FOLDERS   JOB_FOLDERS  ON  JOB_FOLDERS.FOL_ID = JOD.FOL_ID
                LEFT JOIN $schema.FOL_FOLDERS   PREDJS_FOLDERS  ON  PREDJS_FOLDERS.FOL_ID = PRED_AJS.FOL_ID";
            if($tws_config['cpuinfo']['version']>='9.5002')
               $query .= "
               LEFT JOIN $schema.FOL_FOLDERS   WS_FOLDER  ON  WS_FOLDER.FOL_ID = WKC.FOL_ID
                LEFT JOIN $schema.FOL_FOLDERS   WSJOB_FOLDERS  ON  WSJOB_FOLDERS.FOL_ID = JOB_WKC.FOL_ID
                LEFT JOIN $schema.FOL_FOLDERS   PREDWS_FOLDERS  ON  PREDWS_FOLDERS.FOL_ID = PRED_WKC.FOL_ID";
         $query .= "
         WHERE
            WKC.WKC_NAME LIKE ? ESCAPE '/' AND
            AJS.AJS_NAME LIKE ? ESCAPE '/' AND
            AJB.AJB_NAME LIKE ? ESCAPE '/' AND ";
        $query .= "
            $validfrom_expr
            $acc_sql";
        if($tws_config['cpuinfo']['version']>='9.5')
                $query .= "
            AND JS_FOLDER.FOL_PATH = '".db_string($composer_db, $jobstream_folder)."'";
        if($tws_config['cpuinfo']['version']>='9.5002')
                $query .= "
            AND WS_FOLDER.FOL_PATH = '".db_string($composer_db, $workstation_folder)."'";
         $query .= "
         UNION ALL
         SELECT
           WKC.WKC_NAME WORKSTATION,
           AJS.AJS_NAME STREAM,
           JST.JST_VALID_FROM VALIDFROM,
           AJB.AJB_NAME ASJOB,
           JOB_WKC.WKC_NAME JOB_WORKSTATION,
           JOD.JOD_NAME JOB_NAME,

           PRED_WKC.WKC_NAME PRED_WORKSTATION,
           PRED_AJS.AJS_NAME PRED_STREAM,
           PRED_AJB.AJB_NAME PRED_JOB,";
           if ($tws_config['cpuinfo']['version']>='9.5')
               $query .= "
                PREDJS_FOLDERS.FOL_PATH   PRED_STREAM_FOLDER,
                JOB_FOLDERS.FOL_PATH  JOB_FOLDER, ";
           if ($tws_config['cpuinfo']['version']>='9.5002')
               $query .= "
               WS_FOLDER.FOL_PATH   WS_FOLDER,
               WSJOB_FOLDERS.FOL_PATH  WSJOB_FOLDER,
                PREDWS_FOLDERS.FOL_PATH  PRED_WS_FOLDER,";
           $query .= "
           FDP.FDP_TYPE DEP_TYPE,
           FDP.FDP_RULE MATCHING,
           FDP.FDP_RULE_START_OFFSET MATCHING_FROM,
           FDP.FDP_RULE_END_OFFSET MATCHING_TO
         FROM ((((((((((((
                 $schema.FDP_FOLLOWS_DEPS FDP
            JOIN $schema.JOB_JOBS JOB ON JOB.JOB_ID = FDP.JOB_ID)
            JOIN $schema.AJB_ABSTRACT_JOBS AJB ON AJB.AJB_ID = JOB.AJB_ID)
            JOIN $schema.JST_JOB_STREAMS JST ON JST.JST_ID = JOB.JST_ID)
            JOIN $schema.AJS_ABSTRACT_JOB_STREAMS AJS ON AJS.AJS_ID = JST.AJS_ID)
            JOIN $schema.WKC_WORKSTATION_CLASSES WKC ON WKC.WKC_ID = AJS.WKC_ID)
            JOIN $schema.JOD_JOB_DEFINITIONS JOD ON JOD.JOD_ID = JOB.JOD_ID)
            JOIN $schema.WKC_WORKSTATION_CLASSES JOB_WKC ON JOB_WKC.WKC_ID = JOD.WKC_ID)
            JOIN $schema.JOB_JOBS PRED_JOB ON PRED_JOB.JOB_ID = FDP.JOB_PRED_ID)
            JOIN $schema.AJB_ABSTRACT_JOBS PRED_AJB ON PRED_AJB.AJB_ID = PRED_JOB.AJB_ID)
            JOIN $schema.JST_JOB_STREAMS PRED_JST ON PRED_JST.JST_ID = PRED_JOB.JST_ID)
            JOIN $schema.AJS_ABSTRACT_JOB_STREAMS PRED_AJS ON PRED_AJS.AJS_ID = PRED_JST.AJS_ID)
            JOIN $schema.WKC_WORKSTATION_CLASSES PRED_WKC ON PRED_WKC.WKC_ID = PRED_AJS.WKC_ID) ";
if($tws_config['cpuinfo']['version']>='9.5')
               $query .= "
               LEFT JOIN $schema.FOL_FOLDERS   JS_FOLDER  ON  JS_FOLDER.FOL_ID = AJS.FOL_ID
                LEFT JOIN $schema.FOL_FOLDERS   JOB_FOLDERS  ON  JOB_FOLDERS.FOL_ID = JOD.FOL_ID
                LEFT JOIN $schema.FOL_FOLDERS   PREDJS_FOLDERS  ON  PREDJS_FOLDERS.FOL_ID = PRED_AJS.FOL_ID";
            if($tws_config['cpuinfo']['version']>='9.5002')
               $query .= "
               LEFT JOIN $schema.FOL_FOLDERS   WS_FOLDER  ON  WS_FOLDER.FOL_ID = WKC.FOL_ID
                LEFT JOIN $schema.FOL_FOLDERS   WSJOB_FOLDERS  ON  WSJOB_FOLDERS.FOL_ID = JOB_WKC.FOL_ID
                LEFT JOIN $schema.FOL_FOLDERS   PREDWS_FOLDERS  ON  PREDWS_FOLDERS.FOL_ID = PRED_WKC.FOL_ID";
         $query .= "
         WHERE
            WKC.WKC_NAME LIKE ? ESCAPE '/' AND
            AJS.AJS_NAME LIKE ? ESCAPE '/' AND
            AJB.AJB_NAME LIKE ? ESCAPE '/' AND
            $validfrom_expr
            $acc_sql";
        if ($tws_config['cpuinfo']['version'] >= '9.5')
            $query .= "
            AND JS_FOLDER.FOL_PATH = '" . db_string($composer_db, $jobstream_folder) . "'";
        if ($tws_config['cpuinfo']['version'] >= '9.5002')
            $query .= "
            AND WS_FOLDER.FOL_PATH = '" . db_string($composer_db, $workstation_folder) . "'";
      $stmt=new db_statement($composer_db, $query);
      if ($stmt->prepare()==FALSE){
         unset($stmt);
         tws_error('', 'Database query prepare failed: '.$query);
         return FALSE;
      }
      $composer_db[$st_name] = $stmt;
   }
   else $stmt = $composer_db[$st_name];

   $values = array(tws_preplike(db_string($composer_db,$workstation)), tws_preplike(db_string($composer_db,$jobstream)), tws_preplike(db_string($composer_db,$job)));
   if (!empty($validfrom))
      $values[] =  db_string($composer_db,$validfrom);
   $values[] = tws_preplike(db_string($composer_db,$workstation));
   $values[] = tws_preplike(db_string($composer_db,$jobstream));
   $values[] = tws_preplike(db_string($composer_db,$job));
   if (!empty($validfrom))
      $values[] =  db_string($composer_db,$validfrom);

   tws_log('-- tws_get_job_dep_job DB query: '.$stmt->sql());
   tws_log('tws_get_job_dep_job Query values: '.var_export($values, true));

   if ($stmt->execute($values)==false){
      tws_error('', 'Database query failed: '.$stmt->sql());
      return FALSE;
   }

   $depjob=Array();
   $i=0;
   $count = 0;
   $temp='';
   while( $stmt->fetch() ){
      $row = $stmt->row();
      tws_log("tws_get_job_dep_job row: ".var_export($row, true));

      $job_folder = '';
      if(!empty($row['JOB_FOLDER'])){
         $job_folder = $row['JOB_FOLDER'];
         $depjob['job_folder'] = $job_folder;
      }
      $pred_stream_folder = '';
      if(!empty($row['PRED_STREAM_FOLDER'])){
         $pred_stream_folder = $row['PRED_STREAM_FOLDER'];
      }
      $stream_folder = '';
      if(!empty($row['STREAM_FOL_ID'])){
         $stream_folder = $folders[$row['STREAM_FOL_ID']];
      }
      tws_log("stream_folder: $stream_folder");
      tws_log("pred_stream_folder: $pred_stream_folder");

      $jobname=$row['JOB_WORKSTATION']."#".$job_folder.$row['JOB_NAME'];
      $pred_workstation = $row['PRED_WORKSTATION'];
      if ($tws_config['cpuinfo']['version'] >= '9.5002'){
          $jobname= $row['WSJOB_FOLDER']. $jobname;
          $pred_workstation = $row['PRED_WS_FOLDER'].$pred_workstation;
      }

      if ($row['JOB_NAME'] != $row['ASJOB']) {
         $jobname.=" AS ".$row['ASJOB'];
      }
      $depjob['jobfollowsjobdeptype'][$jobname][]=$row['DEP_TYPE'];
      if ($row['DEP_TYPE']=='I') {
         $depjob['jobfollowsjobcpu'][$jobname][]='';
         $depjob['jobfollowsjobjobstream'][$jobname][]='';
      } else {
         $depjob['jobfollowsjobcpu'][$jobname][]=$pred_workstation;
         $depjob['jobfollowsjobjobstream'][$jobname][]=$pred_stream_folder.$row['PRED_STREAM'];
      }
      $depjob['jobfollowsjobname'][$jobname][]=$row['PRED_JOB'];
      $depjob['jobfollowsjobmatching'][$jobname][]=tws_typeval('MATCHING',$row['MATCHING']);

      // the same with indexes for NetPlan
         $depjob['dep_cpu'][$jobname][] = $pred_workstation;
         $depjob['dep_jobstream'][$jobname][] = $pred_stream_folder.$row['PRED_STREAM'];
         $depjob['dep_job'][$jobname][] = $row['PRED_JOB'];
         $depjob['dep_type'][$jobname][] = $row['DEP_TYPE'];
         $depjob['match'][$jobname][] = tws_typeval('MATCHING',$row['MATCHING']);
         $depjob['match_from'][$jobname][] = $row['MATCHING_FROM'];
         $depjob['match_to'][$jobname][] = $row['MATCHING_TO'];

      if($tws_config['cpuinfo']['version']>='9.3'){
         // to synhronize indexes with IWS 9.3
         $depjob['job_job_success'][$jobname][] = $row['ON_SUCCESS'];
         $depjob['job_job_abend'][$jobname][] = $row['ON_ABEND'];
         $depjob['job_job_fail'][$jobname][] = $row['ON_FAIL'];
         $depjob['job_job_execute'][$jobname][] = $row['ON_EXECUTE'];
         $depjob['job_job_supress'][$jobname][] = $row['ON_SUPPRESS'];
      }
		// tws_log("MATCHING: ".tws_typeval('MATCHING',$row['MATCHING']));
      switch (tws_typeval('MATCHING',$row['MATCHING'])) {
         case "RELATIVE":

            if ($row['MATCHING_FROM'] < 0) {
               $row['MATCHING_FROM'] *= -1;
               $depjob['jobfollowsjobmatchingrelativefromdir'][$jobname][] = "-";
            }
            else $depjob['jobfollowsjobmatchingrelativefromdir'][$jobname][] = "+";

            tws_get_at_time(($row['MATCHING_FROM']),
                     $jobfollowsjobmatchingrelativefromhour,
                     $jobfollowsjobmatchingrelativefromminute,
                     $temp, $temp, 'RELATIVE_OFFSET');

				// tws_log("-- MATCHING_FROM: $jobfollowsjobmatchingrelativefromhour:$jobfollowsjobmatchingrelativefromminute");
            $depjob['jobfollowsjobmatchingrelativefromhour'][$jobname][] = $jobfollowsjobmatchingrelativefromhour;
            $depjob['jobfollowsjobmatchingrelativefromminute'][$jobname][] = $jobfollowsjobmatchingrelativefromminute;

            if ($row['MATCHING_TO'] < 0) {
               $row['MATCHING_TO'] *= -1;
               $depjob['jobfollowsjobmatchingrelativetodir'][$jobname][] = "-";
            } else { $depjob['jobfollowsjobmatchingrelativetodir'][$jobname][] = "+"; }
            tws_get_at_time($row['MATCHING_TO'],
                  $depjob['jobfollowsjobmatchingrelativetohour'][$jobname][],
                  $depjob['jobfollowsjobmatchingrelativetominute'][$jobname][],
                  $temp, $temp, 'RELATIVE_OFFSET');
            break;
         case "ABSOLUTE":
            $day = (1000 * 60 * 60 * 24);
            if ($row['MATCHING_FROM'] < 0) {
               $depjob['jobfollowsjobmatchingabsolutefromdir'][$jobname][] = "-";
               $depjob['jobfollowsjobmatchingabsolutefromdays'][$jobname][]= strval(-1*(floor($row['MATCHING_FROM']/($day))));
               $rest = ($row['MATCHING_FROM']%($day)+($day));
               tws_get_at_time($rest, $depjob['jobfollowsjobmatchingabsolutefromhour'][$jobname],
                     $depjob['jobfollowsjobmatchingabsolutefromminute'][$jobname][],
                     $temp,$temp);
            }
            else {
               tws_get_at_time($row['MATCHING_FROM'],$depjob['jobfollowsjobmatchingabsolutefromhour'][$jobname][],
                  $depjob['jobfollowsjobmatchingabsolutefromminute'][$jobname][], $temp,
                  $depjob['jobfollowsjobmatchingabsolutefromdays'][$jobname][]);
               $depjob['jobfollowsjobmatchingabsolutefromdir'][$jobname][] = "+";
            }
            if ($row['MATCHING_TO'] < 0) {
               $depjob['jobfollowsjobmatchingabsolutetodir'][$jobname][] = "-";
               $depjob['jobfollowsjobmatchingabsolutetodays'][$jobname][]= strval(-1*(floor($row['MATCHING_TO']/($day))));
               $rest = ($row['MATCHING_TO']%($day)+($day));
               tws_get_at_time($rest,$depjob['jobfollowsjobmatchingabsolutetohour'][$jobname][],
                     $depjob['jobfollowsjobmatchingabsolutetominute'][$jobname][],
                     $temp,$temp);
            } else {
               tws_get_at_time($row['MATCHING_TO'],$depjob['jobfollowsjobmatchingabsolutetohour'][$jobname][],
                     $depjob['jobfollowsjobmatchingabsolutetominute'][$jobname][], $temp,
                     $depjob['jobfollowsjobmatchingabsolutetodays'][$jobname][]);
               $depjob['jobfollowsjobmatchingabsolutetodir'][$jobname][] = "+";
            }
            break;

         default:
            $depjob['jobfollowsjobmatchingrelativefromdir'][$jobname][] = '';
            $depjob['jobfollowsjobmatchingrelativefromhour'][$jobname][] = '';
            $depjob['jobfollowsjobmatchingrelativefromminute'][$jobname][] = '';
               $depjob['jobfollowsjobmatchingrelativetodir'][$jobname][] = '';
               $depjob['jobfollowsjobmatchingrelativetohour'][$jobname][] = '';
               $depjob['jobfollowsjobmatchingrelativetominute'][$jobname][] = '';


            $depjob['jobfollowsjobmatchingabsolutefromdir'][$jobname][] = '';
            $depjob['jobfollowsjobmatchingabsolutefromhour'][$jobname][] = '';
            $depjob['jobfollowsjobmatchingabsolutefromminute'][$jobname][] = '';
            $depjob['jobfollowsjobmatchingabsolutefromdays'][$jobname][]= '';

               $depjob['jobfollowsjobmatchingabsolutetodir'][$jobname][] = '';
               $depjob['jobfollowsjobmatchingabsolutetohour'][$jobname][] = '';
               $depjob['jobfollowsjobmatchingabsolutetominute'][$jobname][] = '';
               $depjob['jobfollowsjobmatchingabsolutetodays'][$jobname][] = '';
         }

      $i++;
      $count++;
      	//tws_log('Cur depjob: '.var_export($depjob, true));
   }
   tws_log('Result Job -> Job: '.var_export($depjob, true));

   // *****************   Conditional dependency Job -> Job    *********************** //

   if($tws_config['cpuinfo']['version']>='9.3'){
      // TODO: validfrom + access rights checking
      //
      if ($validfrom == '')
         $validfrom_expr = "DEP_JS.JST_VALID_FROM IS NULL";
      else
         $validfrom_expr = "DEP_JS.JST_VALID_FROM = '$validfrom'";
      $query = "
   SELECT
      CDP_TYPE,
       WKC.WKC_NAME PRED_WKS,
       JS.AJS_NAME PRED_STREAM,
       JOB.AJB_NAME PRED_JOB,
       JOB_WKC.WKC_NAME JOB_WORKSTATION,

       DEP_WKC.WKC_NAME DEP_WKS,
       DEP_AJS.AJS_NAME DEP_STREAM,
       DEP_JS.JST_VALID_FROM DEP_STREAM_VALID_FROM,
       DEP_JS.JST_VALID_TO DEP_STREAM_VALID_TO,
       DEP_AJB.AJB_NAME DEP_AS_JOB,
       JOD_NAME DEP_JOB,";
       if ($tws_config['cpuinfo']['version']>='9.5')
         $query .= "
                JOB_FOLDERS.FOL_PATH  JOB_FOLDER,
                PREDJS_FOLDERS.FOL_PATH PREDJS_FOLDER, ";
     if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
          WSJOB_FOLDERS.FOL_PATH  WSJOB_FOLDER,
          PREDWS_FOLDERS.FOL_PATH PREDWS_FOLDER,";
       $query .= "
       $schema.CDP_CONDITIONAL_DEPS.CDP_SUCCESS ON_SUCCESS,
       $schema.CDP_CONDITIONAL_DEPS.CDP_ABEND ON_ABEND,
       $schema.CDP_CONDITIONAL_DEPS.CDP_FAIL ON_FAIL,
       $schema.CDP_CONDITIONAL_DEPS.CDP_EXECUTE ON_EXECUTE,
       $schema.CDP_CONDITIONAL_DEPS.CDP_SUPPRESS ON_SUPPRESS,
         $schema.CDP_CONDITIONAL_DEPS.CDP_RULE MATCHING,
         $schema.CDP_CONDITIONAL_DEPS.CDP_RULE_START_OFFSET MATCHING_FROM,
         $schema.CDP_CONDITIONAL_DEPS.CDP_RULE_END_OFFSET MATCHING_TO,
         CJO.CJO_NAME JOIN_NAME,
         CJO.CJO_QUANTITY JOIN_QUANTITY,
         CJO.CJO_DESCRIPTION JOIN_DESCRIPTION,
         $hex_fce($schema.CDP_CONDITIONAL_DEPS.CDP_ID) CDP_ID
   FROM   (((((((((((($schema.AJB_ABSTRACT_JOBS JOB
     JOIN $schema.AJS_ABSTRACT_JOB_STREAMS JS ON JOB.AJS_ID = JS.AJS_ID)
     JOIN $schema.WKC_WORKSTATION_CLASSES WKC ON JS.WKC_ID = WKC.WKC_ID)
     JOIN $schema.JOB_JOBS ON JOB.AJB_ID = $schema.JOB_JOBS.AJB_ID)
     JOIN $schema.CDP_CONDITIONAL_DEPS ON $schema.JOB_JOBS.JOB_ID = $schema.CDP_CONDITIONAL_DEPS.JOB_PRED_ID)
     JOIN $schema.JOB_JOBS DEP_JOB ON DEP_JOB.JOB_ID = $schema.CDP_CONDITIONAL_DEPS.JOB_ID)
     JOIN $schema.AJB_ABSTRACT_JOBS DEP_AJB ON DEP_AJB.AJB_ID = DEP_JOB.AJB_ID)
     JOIN $schema.JOD_JOB_DEFINITIONS JOB_DEFINITION ON JOB_DEFINITION.JOD_ID = DEP_JOB.JOD_ID)
        JOIN $schema.WKC_WORKSTATION_CLASSES JOB_WKC ON JOB_WKC.WKC_ID = JOB_DEFINITION.WKC_ID)
     JOIN $schema.JST_JOB_STREAMS DEP_JS ON DEP_JS.JST_ID = DEP_JOB.JST_ID)
     JOIN $schema.AJS_ABSTRACT_JOB_STREAMS DEP_AJS ON DEP_JS.AJS_ID = DEP_AJS.AJS_ID)
     JOIN $schema.WKC_WORKSTATION_CLASSES DEP_WKC ON DEP_AJS.WKC_ID = DEP_WKC.WKC_ID)
     LEFT JOIN $schema.CJO_CONDITIONAL_JOIN CJO ON CJO.CJO_ID = $schema.CDP_CONDITIONAL_DEPS.CJO_ID)";
         if($tws_config['cpuinfo']['version']>='9.5')
             $query .= "
             LEFT JOIN $schema.FOL_FOLDERS   JOB_FOLDERS  ON  JOB_FOLDERS.FOL_ID = JOB_DEFINITION.FOL_ID
             LEFT JOIN $schema.FOL_FOLDERS   PREDJS_FOLDERS  ON  PREDJS_FOLDERS.FOL_ID = JS.FOL_ID
             LEFT JOIN $schema.FOL_FOLDERS   JS_FOLDERS  ON  JS_FOLDERS.FOL_ID = DEP_AJS.FOL_ID";
         if($tws_config['cpuinfo']['version']>='9.5002')
             $query .= "
             LEFT JOIN $schema.FOL_FOLDERS   WSJOB_FOLDERS  ON  WSJOB_FOLDERS.FOL_ID = JOB_WKC.FOL_ID
             LEFT JOIN $schema.FOL_FOLDERS   PREDWS_FOLDERS  ON  PREDWS_FOLDERS.FOL_ID = WKC.FOL_ID
            LEFT JOIN $schema.FOL_FOLDERS   JSWS_FOLDERS  ON  JSWS_FOLDERS.FOL_ID = DEP_WKC.FOL_ID";

  $query .= "
   WHERE  CDP_TYPE = 'I' AND
         DEP_WKC.WKC_NAME = '".db_string($composer_db, $workstation)."' AND
         DEP_AJS.AJS_NAME = '".db_string($composer_db,$jobstream)."' AND
         DEP_AJB.AJB_NAME LIKE '".tws_preplike(db_string($composer_db,$job))."' ESCAPE '/'
         AND $validfrom_expr ";
      if ($tws_config['cpuinfo']['version'] >= '9.5')
        $query .= "
        AND JS_FOLDERS.FOL_PATH = '" . db_string($composer_db, $jobstream_folder) . "'";
    if ($tws_config['cpuinfo']['version'] >= '9.5002')
        $query .= "
        AND JSWS_FOLDERS.FOL_PATH = '" . db_string($composer_db, $workstation_folder) . "'";
         $query .= "
   UNION ALL
   SELECT
      CDP_TYPE,
       WKC.WKC_NAME PRED_WKS,
       JS.AJS_NAME PRED_STREAM,
       JOB.AJB_NAME PRED_JOB,
       JOB_WKC.WKC_NAME JOB_WORKSTATION,

       DEP_WKC.WKC_NAME DEP_WKS,
       DEP_AJS.AJS_NAME DEP_STREAM,
       DEP_JS.JST_VALID_FROM DEP_STREAM_VALID_FROM,
       DEP_JS.JST_VALID_TO DEP_STREAM_VALID_TO,
       DEP_AJB.AJB_NAME DEP_AS_JOB,
       JOD_NAME DEP_JOB,";
        if ($tws_config['cpuinfo']['version']>='9.5')
           $query .= "
             JOB_FOLDERS.FOL_PATH  JOB_FOLDER,
            PREDJS_FOLDERS.FOL_PATH PREDJS_FOLDER,";
        if ($tws_config['cpuinfo']['version']>='9.5002')
               $query .= "
              WSJOB_FOLDERS.FOL_PATH  WSJOB_FOLDER,
                PREDWS_FOLDERS.FOL_PATH PREDWS_FOLDER,";
        $query .= "
       $schema.CDP_CONDITIONAL_DEPS.CDP_SUCCESS ON_SUCCESS,
       $schema.CDP_CONDITIONAL_DEPS.CDP_ABEND ON_ABEND,
       $schema.CDP_CONDITIONAL_DEPS.CDP_FAIL ON_FAIL,
       $schema.CDP_CONDITIONAL_DEPS.CDP_EXECUTE ON_EXECUTE,
       $schema.CDP_CONDITIONAL_DEPS.CDP_SUPPRESS ON_SUPPRESS,
       $schema.CDP_CONDITIONAL_DEPS.CDP_RULE MATCHING,
       $schema.CDP_CONDITIONAL_DEPS.CDP_RULE_START_OFFSET MATCHING_FROM,
       $schema.CDP_CONDITIONAL_DEPS.CDP_RULE_END_OFFSET MATCHING_TO,
         CJO.CJO_NAME JOIN_NAME,
         CJO.CJO_QUANTITY JOIN_QUANTITY,
         CJO.CJO_DESCRIPTION JOIN_DESCRIPTION,
       $hex_fce($schema.CDP_CONDITIONAL_DEPS.CDP_ID) CDP_ID
   FROM   ((((((((((($schema.AJB_ABSTRACT_JOBS JOB
     JOIN $schema.AJS_ABSTRACT_JOB_STREAMS JS ON JOB.AJS_ID = JS.AJS_ID)
     JOIN $schema.WKC_WORKSTATION_CLASSES WKC ON JS.WKC_ID = WKC.WKC_ID)
     JOIN $schema.CDP_CONDITIONAL_DEPS ON JOB.AJB_ID = $schema.CDP_CONDITIONAL_DEPS.AJB_PRED_ID)
     JOIN $schema.JOB_JOBS DEP_JOB ON DEP_JOB.JOB_ID = $schema.CDP_CONDITIONAL_DEPS.JOB_ID)
     JOIN $schema.AJB_ABSTRACT_JOBS DEP_AJB ON DEP_AJB.AJB_ID = DEP_JOB.AJB_ID)
     JOIN $schema.JOD_JOB_DEFINITIONS JOB_DEFINITION ON JOB_DEFINITION.JOD_ID = DEP_JOB.JOD_ID)
        JOIN $schema.WKC_WORKSTATION_CLASSES JOB_WKC ON JOB_WKC.WKC_ID = JOB_DEFINITION.WKC_ID)
     JOIN $schema.JST_JOB_STREAMS DEP_JS ON DEP_JS.JST_ID = DEP_JOB.JST_ID)
     JOIN $schema.AJS_ABSTRACT_JOB_STREAMS DEP_AJS ON DEP_JS.AJS_ID = DEP_AJS.AJS_ID)
     JOIN $schema.WKC_WORKSTATION_CLASSES DEP_WKC ON DEP_AJS.WKC_ID = DEP_WKC.WKC_ID)
     LEFT JOIN $schema.CJO_CONDITIONAL_JOIN CJO ON CJO.CJO_ID = $schema.CDP_CONDITIONAL_DEPS.CJO_ID) ";
       if($tws_config['cpuinfo']['version']>='9.5')
           $query .= "
           LEFT JOIN $schema.FOL_FOLDERS   JOB_FOLDERS  ON  JOB_FOLDERS.FOL_ID = JOB_DEFINITION.FOL_ID
           LEFT JOIN $schema.FOL_FOLDERS   PREDJS_FOLDERS  ON  PREDJS_FOLDERS.FOL_ID = JS.FOL_ID
           LEFT JOIN $schema.FOL_FOLDERS   JS_FOLDERS  ON  JS_FOLDERS.FOL_ID = DEP_AJS.FOL_ID";
       if($tws_config['cpuinfo']['version']>='9.5002')
           $query .= "
            LEFT JOIN $schema.FOL_FOLDERS   WSJOB_FOLDERS  ON  WSJOB_FOLDERS.FOL_ID = JOB_WKC.FOL_ID
            LEFT JOIN $schema.FOL_FOLDERS   PREDWS_FOLDERS  ON  PREDWS_FOLDERS.FOL_ID = WKC.FOL_ID
            LEFT JOIN $schema.FOL_FOLDERS   JSWS_FOLDERS  ON  JSWS_FOLDERS.FOL_ID = DEP_WKC.FOL_ID";
   $query .= "
        WHERE  CDP_TYPE = 'J' AND
         DEP_WKC.WKC_NAME = '".db_string($composer_db, $workstation)."'  AND
         DEP_AJS.AJS_NAME = '".db_string($composer_db,$jobstream)."' AND
         DEP_AJB.AJB_NAME LIKE '".tws_preplike(db_string($composer_db,$job))."' ESCAPE '/'
         AND $validfrom_expr ";
   if ($tws_config['cpuinfo']['version'] >= '9.5')
       $query .= "
        AND JS_FOLDERS.FOL_PATH = '" . db_string($composer_db, $jobstream_folder) . "'";
       if ($tws_config['cpuinfo']['version'] >= '9.5002')
           $query .= "
        AND JSWS_FOLDERS.FOL_PATH = '" . db_string($composer_db, $workstation_folder) . "'";
      tws_log("Conditional dependency Job -> Job query: $query");

      if (!db_query($composer_db, $query)) {
         tws_error('', 'Database query failed');
         return false;
      }

      while(($row = db_fetch_row( $composer_db)) != false){
         tws_log("Conditional dependency Job -> Job row: ". var_export($row, true));

         $job_folder = '';
         if(!empty($row['JOB_FOLDER'])){
            $job_folder = $row['JOB_FOLDER'];
         }
         if($tws_config['cpuinfo']['version']>='9.5002'){
             $jobname=$row['WSJOB_FOLDER']. $row['JOB_WORKSTATION']."#".$job_folder.$row['DEP_JOB'];
         }else {
             $jobname=$row['JOB_WORKSTATION']."#".$job_folder.$row['DEP_JOB'];
         }
         $pred_stream_folder = '';
         if(!empty($row['PREDJS_FOLDER'])){
            $pred_stream_folder = $row['PREDJS_FOLDER'];
            tws_log("pred_stream_folder: $pred_stream_folder");
         }
         $pred_ws_folder = '';
         if(!empty($row['PREDWS_FOLDER'])){
             $pred_ws_folder = $row['PREDWS_FOLDER'];
             tws_log("pred_ws_folder: $pred_ws_folder");
         }

         if ($row['DEP_JOB'] != $row['DEP_AS_JOB']) {
            $jobname.=" AS ".$row['DEP_AS_JOB'];
         }

         $depjob['jobfollowsjobdeptype'][$jobname][]=$row['CDP_TYPE'];
         if ($row['CDP_TYPE']=='I') {
            $depjob['jobfollowsjobcpu'][$jobname][]='';
            $depjob['jobfollowsjobjobstream'][$jobname][]='';
         } else {
             $depjob['jobfollowsjobcpu'][$jobname][]=$pred_ws_folder.$row['PRED_WKS'];
            $depjob['jobfollowsjobjobstream'][$jobname][] = $pred_stream_folder.$row['PRED_STREAM'];
         }
         $depjob['jobfollowsjobname'][$jobname][]=$row['PRED_JOB'];

         $depjob['job_job_success'][$jobname][] = $row['ON_SUCCESS'];
         $depjob['job_job_abend'][$jobname][] = $row['ON_ABEND'];
         $depjob['job_job_fail'][$jobname][] = $row['ON_FAIL'];
         $depjob['job_job_execute'][$jobname][] = $row['ON_EXECUTE'];
         $depjob['job_job_supress'][$jobname][] = $row['ON_SUPPRESS'];
         $depjob['cdp_id'][$jobname][] =  $row['CDP_ID'];
         $depjob['jobfollowsjobmatching'][$jobname][] = tws_typeval('MATCHING',$row['MATCHING']);

         // the same with indexes for NetPlan
         $depjob['dep_cpu'][$jobname][] = $row['PRED_WKS'];
         $depjob['dep_jobstream'][$jobname][] = $row['PRED_STREAM'];
         $depjob['dep_job'][$jobname][] = $row['PRED_JOB'];
         $depjob['dep_type'][$jobname][] = $row['CDP_TYPE'];
         $depjob['match'][$jobname][] = tws_typeval('MATCHING',$row['MATCHING']);
         $depjob['match_from'][$jobname][] = $row['MATCHING_FROM'];
         $depjob['match_to'][$jobname][] = $row['MATCHING_TO'];
         $depjob['job_job_join_name'][$jobname][] = $row['JOIN_NAME'];
         $depjob['job_job_join_quantity'][$jobname][] = $row['JOIN_QUANTITY'];
         $depjob['job_job_join_description'][$jobname][] = $row['JOIN_DESCRIPTION'];

      switch (tws_typeval('MATCHING',$row['MATCHING'])) {
         case "RELATIVE":
            if ($row['MATCHING_FROM'] < 0) {
               $row['MATCHING_FROM'] *= -1;
               $depjob['jobfollowsjobmatchingrelativefromdir'][$jobname][] = "-";
            } else { $depjob['jobfollowsjobmatchingrelativefromdir'][$jobname][] = "+"; }
            tws_get_at_time(($row['MATCHING_FROM']),
                     $depjob['jobfollowsjobmatchingrelativefromhour'][$jobname][],
                     $depjob['jobfollowsjobmatchingrelativefromminute'][$jobname][],
                     $temp, $temp, 'RELATIVE_OFFSET');
            if ($row['MATCHING_TO'] < 0) {
               $row['MATCHING_TO'] *= -1;
               $depjob['jobfollowsjobmatchingrelativetodir'][$jobname][] = "-";
            } else { $depjob['jobfollowsjobmatchingrelativetodir'][$jobname][] = "+"; }
            tws_get_at_time($row['MATCHING_TO'],
                  $depjob['jobfollowsjobmatchingrelativetohour'][$jobname][],
                  $depjob['jobfollowsjobmatchingrelativetominute'][$jobname][],
                  $temp, $temp, 'RELATIVE_OFFSET');
            break;
         case "ABSOLUTE":
            $day = (1000 * 60 * 60 * 24);
            if ($row['MATCHING_FROM'] < 0) {
               $depjob['jobfollowsjobmatchingabsolutefromdir'][$jobname][] = "-";
               $depjob['jobfollowsjobmatchingabsolutefromdays'][$jobname][]= strval(-1*(floor($row['MATCHING_FROM']/($day))));
               $rest = ($row['MATCHING_FROM']%($day)+($day));
               tws_get_at_time($rest,$depjob['jobfollowsjobmatchingabsolutefromhour'][$jobname][],
                     $depjob['jobfollowsjobmatchingabsolutefromminute'][$jobname][],
                     $temp,$temp);
            } else {
               tws_get_at_time($row['MATCHING_FROM'],$depjob['jobfollowsjobmatchingabsolutefromhour'][$jobname][],
                  $depjob['jobfollowsjobmatchingabsolutefromminute'][$jobname][], $temp,
                  $depjob['jobfollowsjobmatchingabsolutefromdays'][$jobname][]);
               $depjob['jobfollowsjobmatchingabsolutefromdir'][$jobname][] = "+";
            }
            if ($row['MATCHING_TO'] < 0) {
               $depjob['jobfollowsjobmatchingabsolutetodir'][$jobname][] = "-";
               $depjob['jobfollowsjobmatchingabsolutetodays'][$jobname][]= strval(-1*(floor($row['MATCHING_TO']/($day))));
               $rest = ($row['MATCHING_TO']%($day)+($day));
               tws_get_at_time($rest,$depjob['jobfollowsjobmatchingabsolutetohour'][$jobname][],
                     $depjob['jobfollowsjobmatchingabsolutetominute'][$jobname][],
                     $temp,$temp);
            }
            else {
               tws_get_at_time($row['MATCHING_TO'],$depjob['jobfollowsjobmatchingabsolutetohour'][$jobname][],
                     $depjob['jobfollowsjobmatchingabsolutetominute'][$jobname][], $temp,
                     $depjob['jobfollowsjobmatchingabsolutetodays'][$jobname][]);
               $depjob['jobfollowsjobmatchingabsolutetodir'][$jobname][] = "+";
            }
            break;
         default:
            $depjob['jobfollowsjobmatchingrelativefromdir'][$jobname][] = '';
            $depjob['jobfollowsjobmatchingrelativefromhour'][$jobname][] = '';
            $depjob['jobfollowsjobmatchingrelativefromminute'][$jobname][] = '';
               $depjob['jobfollowsjobmatchingrelativetodir'][$jobname][] = '';
               $depjob['jobfollowsjobmatchingrelativetohour'][$jobname][] = '';
               $depjob['jobfollowsjobmatchingrelativetominute'][$jobname][] = '';


            $depjob['jobfollowsjobmatchingabsolutefromdir'][$jobname][] = '';
            $depjob['jobfollowsjobmatchingabsolutefromhour'][$jobname][] = '';
            $depjob['jobfollowsjobmatchingabsolutefromminute'][$jobname][] = '';
            $depjob['jobfollowsjobmatchingabsolutefromdays'][$jobname][]= '';

               $depjob['jobfollowsjobmatchingabsolutetodir'][$jobname][] = '';
               $depjob['jobfollowsjobmatchingabsolutetohour'][$jobname][] = '';
               $depjob['jobfollowsjobmatchingabsolutetominute'][$jobname][] = '';
               $depjob['jobfollowsjobmatchingabsolutetodays'][$jobname][] = '';

         }

         $i++;
         $count++;
      }
   }
   tws_log('Result Job -> Job with conditions: '.var_export($depjob, true));

   $depjob['jobfollowsjob_num']=$j;
   $depjob['count']=$count;


// Raise custom (named) dep_jobs conditions if so
   if($tws_config['cpuinfo']['version']>='9.3'){
      tws_log('Raise custom (named) dep_jobs conditions');
      if(empty($depjob['cdp_id'])) $depjob['cdp_id'] = array();
      foreach($depjob['cdp_id'] as $jobname=>$dep){
         $in = '';
         foreach($dep as $cdp_id){
            // $cdp_id = bin2hex($cdp_id);
            $hex_id = ($composer_db['type']=='db2' ? "x'$cdp_id'" : "HEXTORAW('$cdp_id')");
            $in .= strtolower("$hex_id,");
         }
         $in = substr($in, 0, -1);
         $raw_to_hex_fce  = ($composer_db['type']=='db2' ? "HEX" : "RAWTOHEX");

         $query = "SELECT
            JOC.JOC_NAME,
            $raw_to_hex_fce(CDP.CDP_ID) CDP_ID
         FROM $schema.JOC_JOB_OUTPUT_CONDITIONS JOC
            JOIN $schema.CDR_CONDITIONAL_DEPS_REFS CDP ON CDP.JOC_ID = JOC.JOC_ID
         WHERE CDP.CDP_ID IN ($in)";

         if (!db_query($composer_db, $query)) {
            tws_error('', 'Database query failed');
            return $depjob;
         }
         $depjob['job_job_condition'][$jobname] = '';
         while(($row = db_fetch_row( $composer_db)) != false){
            $tmp[$row['CDP_ID']][] = $row['JOC_NAME'];
         }
         foreach($depjob['cdp_id'][$jobname] as $k=>$cdp_id){
            $l = 0;
            if(empty($tmp[$cdp_id])) continue;
            foreach($tmp[$cdp_id] as $condition){
               $depjob['job_job_condition'][$jobname][$k][$l] = $condition;
               $l++;
            }
            // $depjob['job_job_condition'][$jobname][$k] = substr($depjob['job_job_condition'][$jobname][$k], 0, -1);
         }
      }
   }

   // Raise dep_job return code mappings
   if($tws_config['cpuinfo']['version']>='9.3'){

      tws_log('Raise dep_job return code mappings');
      if(empty($depjob['dep_job'])) $depjob['dep_job'] = array(); // no job deps
      foreach($depjob['dep_job'] as $jobname=>$depjobnames){
         foreach($depjobnames as $k=>$depjobname){
            // if(empty($depjob['cdp_id'][$jobname])) continue; codemaps for all!
            if(empty($depjob['dep_cpu'][$jobname][$k]) )
               $depcpu = $workstation;
            else $depcpu = $depjob['dep_cpu'][$jobname][$k];
            $arr = tws_get_job_codemap($depcpu, $depjobname);
            //tws_log("job_codemap for $depcpu#".$depjobname.":".var_export($arr, true));
            if(!empty($arr['joc_name'])){
               foreach($arr['joc_name'] as $l=>$codemap){
                  $depjob['job_job_codemaps'][$jobname][$k][$l] = $codemap;
               }
            }
         }
      }

   }
/*
// TODO: Matching ???
   if(empty($depjob['jobfollowsjobmatching'])) $depjob['jobfollowsjobmatching'] = array();
   foreach($depjob['jobfollowsjobmatching'] as $jobname=>$arr){
      foreach($arr as $i=>$matching){
      switch ($depjob['jobfollowsjobmatching'][$jobname][$i]) {
         case "RELATIVE":
            if ($row['MATCHING_FROM'] < 0) {
               $row['MATCHING_FROM'] *= -1;
               $depjob['jobfollowsjobmatchingrelativefromdir'][$jobname][$i] = "-";
            } else { $depjob['jobfollowsjobmatchingrelativefromdir'][$jobname][$i] = "+"; }
            tws_get_at_time(($row['MATCHING_FROM']),
                     $depjob['jobfollowsjobmatchingrelativefromhour'][$jobname][$i],
                     $depjob['jobfollowsjobmatchingrelativefromminute'][$jobname][$i],
                     $temp, $temp, 'RELATIVE_OFFSET');
            if ($row['MATCHING_TO'] < 0) {
               $row['MATCHING_TO'] *= -1;
               $depjob['jobfollowsjobmatchingrelativetodir'][$jobname][$i] = "-";
            } else { $depjob['jobfollowsjobmatchingrelativetodir'][$jobname][$i] = "+"; }
            tws_get_at_time($row['MATCHING_TO'],
                  $depjob['jobfollowsjobmatchingrelativetohour'][$jobname][$i],
                  $depjob['jobfollowsjobmatchingrelativetominute'][$jobname][$i],
                  $temp, $temp, 'RELATIVE_OFFSET');
            break;
         case "ABSOLUTE":
            $day = (1000 * 60 * 60 * 24);
            if ($row['MATCHING_FROM'] < 0) {
               $depjob['jobfollowsjobmatchingabsolutefromdir'][$jobname][$i] = "-";
               $depjob['jobfollowsjobmatchingabsolutefromdays'][$jobname][$i]= strval(-1*(floor($row['MATCHING_FROM']/($day))));
               $rest = ($row['MATCHING_FROM']%($day)+($day));
               tws_get_at_time($rest,$depjob['jobfollowsjobmatchingabsolutefromhour'][$jobname][$i],
                     $depjob['jobfollowsjobmatchingabsolutefromminute'][$jobname][$i],
                     $temp,$temp);
            } else {
               tws_get_at_time($row['MATCHING_FROM'],$depjob['jobfollowsjobmatchingabsolutefromhour'][$jobname][$i],
                  $depjob['jobfollowsjobmatchingabsolutefromminute'][$jobname][$i], $temp,
                  $depjob['jobfollowsjobmatchingabsolutefromdays'][$jobname][$i]);
               $depjob['jobfollowsjobmatchingabsolutefromdir'][$jobname][$i] = "+";
            }
            if ($row['MATCHING_TO'] < 0) {
               $depjob['jobfollowsjobmatchingabsolutetodir'][$jobname][$i] = "-";
               $depjob['jobfollowsjobmatchingabsolutetodays'][$jobname][$i]= strval(-1*(floor($row['MATCHING_TO']/($day))));
               $rest = ($row['MATCHING_TO']%($day)+($day));
               tws_get_at_time($rest,$depjob['jobfollowsjobmatchingabsolutetohour'][$jobname][$i],
                     $depjob['jobfollowsjobmatchingabsolutetominute'][$jobname][$i],
                     $temp,$temp);
            } else {
               tws_get_at_time($row['MATCHING_TO'],$depjob['jobfollowsjobmatchingabsolutetohour'][$jobname][$i],
                     $depjob['jobfollowsjobmatchingabsolutetominute'][$jobname][$i], $temp,
                     $depjob['jobfollowsjobmatchingabsolutetodays'][$jobname][$i]);
               $depjob['jobfollowsjobmatchingabsolutetodir'][$jobname][$i] = "+";
            }
         }
      }
   }
*/
   tws_log('Result: '.var_export($depjob, true));
   return $depjob;
}

///////////////////////////////////////////////////////////////////////////////
//
// List of variable tables (parameter tables)
//
// Arguments:
//    parameter_table = variable table (parameter table) name (@=wildcard for all)
//    sqlcond = sql filter - conditions of the where clause
//
function tws_get_parameter_tables($parameter_table='@', $sqlfilter='1=1', $page_size = 0, $page = 1, $od_callback=null, $action='LIST') {
   tws_log('-- tws_get_parameter_tables(start at '.basename(__FILE__).'['.__LINE__.'])');
   global $tws_config, $composer_db;

   $parameter_tables=array();
   $parameter_tables['parameter_table_num']=0;

   $tmp = tws_divide_folder($parameter_table);
   $parameter_table = $tmp[1];
   $parameter_table_folder = $tmp[0];

//access rights checking
   if (($acc_sql=tws_sec_check('VARTABLE', array('NAME'=>'VAT_NAME'), '', $action))===FALSE) return $parameter_tables;

   $dbh=db_connect($composer_db,DB_PERSISTENT);
   if (!$dbh) {
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=$composer_db["schema"];
   $query="
     SELECT
        VAT_ID,
        VAT_NAME,
        VAT_DESCRIPTION,
        VAT_DEFAULT,
        VAT_MODIFY_OWNER,
        VAT_MODIFY_TIME,
        VAT_LOCK_OWNER,
        VAT_LOCK_TIME";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= ",
            FOL.FOL_PATH
            ";
      $query .= "
     FROM
        $schema.VAT_VARIABLE_TABLES";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
            LEFT JOIN $schema.FOL_FOLDERS FOL ON FOL.FOL_ID = $schema.VAT_VARIABLE_TABLES.FOL_ID";
      $query .= "
     WHERE
        VAT_NAME ".tws_sqllike(db_string($composer_db,$parameter_table))." ";
      if ($tws_config['cpuinfo']['version']>='9.5002' && !empty($parameter_table_folder))
		$query .= "  AND FOL.FOL_PATH = '$parameter_table_folder'";
		$query .=" AND $sqlfilter
		$acc_sql
		";		// TODO:  WHERE folder

   tws_log('DB query: '.$query);
   if (!($r=db_query($composer_db,$query))) {
      tws_log('Error: Database query failed');
      tws_error('', 'Database query failed');
      return FALSE;
   }
   $tl=tws_log();
   if ($page_size > 0) {
      $page_down = ($page - 1) * $page_size;
      $page_up = $page * $page_size;
   }
   while ($row = db_fetch_row($composer_db)) {
      $tl && tws_log(@var_export($row, true));
      $parameter_tables['parameter_table_num']++;
      if ($page_size > 0) {
         if ($page_down >= $parameter_tables['parameter_table_num']) {
            while (($page_down > $parameter_tables['parameter_table_num']) && db_fetch_row($composer_db, null)) {
              $parameter_tables['parameter_table_num']++;
            }
            continue;
         }
         if ($page_up < $parameter_tables['parameter_table_num']) {
            while (($page_up < $parameter_tables['parameter_table_num']) && db_fetch_row($composer_db, null)) {
               $parameter_tables['parameter_table_num']++;
            }
            break;
         }
      }
      $parameter_tables['parameter_table_id'          ][] = $row['VAT_ID'];
      $parameter_tables['parameter_table_name'        ][] = $row['VAT_NAME'];
      $parameter_tables['parameter_table_description' ][] = $row['VAT_DESCRIPTION'];
      $parameter_tables['parameter_table_default'     ][] = tws_yesno($row['VAT_DEFAULT']);
      $parameter_tables['parameter_table_creator'     ][] = $row['VAT_MODIFY_OWNER'];
      $parameter_tables['parameter_table_last_updated'][] = $row['VAT_MODIFY_TIME'];
      $parameter_tables['parameter_table_lock_by'     ][] = $row['VAT_LOCK_OWNER'];
      $parameter_tables['parameter_table_lock_on'     ][] = $row['VAT_LOCK_TIME'];
      if ($tws_config['cpuinfo']['version']>='9.5002'){
         if(empty($row['FOL_PATH']))
            $row['FOL_PATH'] = '/';
         $parameter_tables['parameter_table_folder'   ][] = $row['FOL_PATH'];
      }
   }
   tws_log('-- tws_get_parameter_tables(end up in '.basename(__FILE__).'['.__LINE__.'])');
   if (defined('IWD_PROCMAN')) return $parameter_tables; //procman::db_functions::db_fetch_row returns FALSE if there are no rows left
   return ($row===FALSE ? FALSE : $parameter_tables);
}


///////////////////////////////////////////////////////////////////////////////
//
// List of parameters
//
// Arguments:
//    parameter = parameter name (@=wildcard for all)
//    sqlcond = sql filter - conditions of the where clause
//
function tws_get_parameters($parameter='@', $sqlfilter='1=1', $page_size = 0, $page = 1, $od_callback=null, $action='LIST') {
   tws_log('-- get_db_parameters_list (start at '.basename(__FILE__).'['.__LINE__.'])');
   global $tws_config, $composer_db;

   $parameters=array();
   $parameters['parameter_num']=0;

//access rights checking
   if (($acc_sql=tws_sec_check('PARAMETER', array('CPU'=>'VAR_NAME', 'NAME'=>'VAR_NAME'), '', $action))===FALSE) return $parameters;

   $dbh=db_connect($composer_db,DB_PERSISTENT);
   if (!$dbh) {
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=$composer_db["schema"];

   if ($tws_config['cpuinfo']['version']<='8.4') {
      $query ="
        SELECT
           VAR_ID ,
           VAR_NAME ,
           VAR_VALUE ,
           VAR_MODIFY_OWNER ,
           VAR_MODIFY_TIME ,
           VAR_LOCK_OWNER ,
           VAR_LOCK_TIME
        FROM
            $schema.VAR_VARIABLES
        WHERE
           VAR_NAME ".tws_sqllike(db_string($composer_db,$parameter))." AND
            $sqlfilter
            $acc_sql
         ";
   }
   else {
      list($par,$vt)=array_reverse(explode('.',$parameter));
      $vt=='' && $vt='*';
      $tmp = tws_divide_folder($vt);
      $vt= $tmp[1];
      $vt_folder = $tmp[0];
      $query ="
        SELECT
           VAR.VAR_ID VAR_ID,
           VAT.VAT_NAME VAT_NAME,
           VAR.VAR_NAME VAR_NAME,
           VAR.VAR_VALUE VAR_VALUE,
           VAR.VAR_MODIFY_OWNER VAR_MODIFY_OWNER,
           VAR.VAR_MODIFY_TIME VAR_MODIFY_TIME,
           VAT.VAT_LOCK_OWNER VAR_LOCK_OWNER,
           VAT.VAT_LOCK_TIME VAR_LOCK_TIME";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= ",
            FOL.FOL_PATH";
      $query .= "
        FROM
           $schema.VAT_VARIABLE_TABLES VAT
           LEFT JOIN $schema.VAR_VARIABLES2 VAR ON VAT.VAT_ID=VAR.VAT_ID";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
            LEFT JOIN $schema.FOL_FOLDERS FOL ON FOL.FOL_ID = VAT.FOL_ID";
      $query .= "
        WHERE
           VAT_NAME ".tws_sqllike(db_string($composer_db,$vt))." AND
           VAR_NAME ".tws_sqllike(db_string($composer_db,$par))." AND ";
      if ($tws_config['cpuinfo']['version']>='9.5002' && !empty($vt_folder))
          $query .= "  FOL.FOL_PATH = '$vt_folder' AND ";
      $query .= "$sqlfilter
            $acc_sql
         ";
   }

   tws_log('DB query: '.$query);
   if( !($r=db_query($composer_db,$query)) ){
      tws_log('Error: Database query failed');
      tws_error('', 'Database query failed');
      return FALSE;
   }
   $tl=tws_log();
   if ($page_size > 0) {
      $page_down = ($page - 1) * $page_size;
      $page_up = $page * $page_size;
   }
   while ($row = db_fetch_row($composer_db)) {
      $tl && tws_log(@var_export($row, true));
      $parameters['parameter_num']++;
      if ($page_size > 0) {
         if ($page_down >= $parameters['parameter_num']) {
            while (($page_down > $parameters['parameter_num']) && db_fetch_row($composer_db, null)) {
              $parameters['parameter_num']++;
            }
            continue;
         }
         if ($page_up < $parameters['parameter_num']) {
            while (($page_up < $parameters['parameter_num']) && db_fetch_row($composer_db, null)) {
               $parameters['parameter_num']++;
            }
            break;
         }
      }
      $parameters['parameter_id'          ][] = $row['VAR_ID'];
      $parameters['parameter_table'       ][] = @$row['VAT_NAME'];
      $parameters['parameter_name'        ][] = $row['VAR_NAME'];
      $parameters['parameter_value'       ][] = $row['VAR_VALUE'];
      $parameters['parameter_creator'     ][] = $row['VAR_MODIFY_OWNER'];
      $parameters['parameter_last_updated'][] = $row['VAR_MODIFY_TIME'];
      $parameters['parameter_lock_by'     ][] = $row['VAR_LOCK_OWNER'];
      $parameters['parameter_lock_on'     ][] = $row['VAR_LOCK_TIME'];
      if ($tws_config['cpuinfo']['version']>='9.5002'){
         if(empty($row['FOL_PATH']))
            $row['FOL_PATH'] = '/';
         $parameters['parameter_table_folder'][] = $row['FOL_PATH'];
      }

   }
   tws_log('-- get_db_parameters_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
   if (defined('IWD_PROCMAN')) return $parameters; //procman::db_functions::db_fetch_row returns FALSE if there are no rows left
   return ($row===FALSE ? FALSE : $parameters);
}

///
/// Parameters report handler (used at IWS Database Report page)
/// \param sel SELECT attributes
/// \param crit items used to build WHERE clause
/// \param ord items used to build ORDER BY clause
/// \param pri items used to sort ORDER BY items
/// \param query (output parameter) resultant sql query string
/// \param dbds (output parameter) database descriptor name
/// \param mode controls the output mode (FETCH_ALL=all results returned in an in array, INIT=initialize the data stream, then fetching data by calling without parameters)
/// \return resultant fetched rows of the created query or the column name map if sel===null
function tws_parameters_report($sel=array(), $crit=array(), $ord=array(), $pri=array(), &$query='', &$dbds='', $mode='FETCH_ALL') {
   global $tws_config, $composer_db, $tws_types;
   static $db_cache=NULL, $sel_cache=NULL;

   if (func_num_args()==0) { //fetching data after a previous calling with mode='INIT'
      if ($db_cache===NULL || $sel_cache===NULL) {
         tws_error('Data fetch error', 'Not initialized data stream');
         return FALSE;
      }
      $sel=$sel_cache;
      $db=$db_cache;
      $mode='ROW'; //just internal flag, anything besides 'FETCH_ALL' has the same effect
   } else {
      $dbds='composer_db';
      $schema=$composer_db['schema'];
      if ($tws_config['cpuinfo']['version']<='8.4') {
         $colmap = array (
            'VAR_NAME'        => 'Parameter',
            'VAR_VALUE'       => 'Value'
         );
         if ($sel===null) return $colmap;
         $from="$schema.VAR_VARIABLES";
         $crit['VAR_NAME']=strtoupper($crit['VAR_NAME']);
      } else {
         $colmap = array (
            'VAT.VAT_NAME'        => 'Variable Table',
            'VAR.VAR_NAME'        => 'Parameter',
            'VAR.VAR_VALUE'       => 'Value'
         );
         if ($sel===null) return $colmap;
         $from="($schema.VAT_VARIABLE_TABLES VAT LEFT JOIN $schema.VAR_VARIABLES2 VAR ON VAT.VAT_ID=VAR.VAT_ID)";
         $crit['VAT.VAT_NAME']=strtoupper($crit['VAT.VAT_NAME']);
         $crit['VAR.VAR_NAME']=strtoupper($crit['VAR.VAR_NAME']);
      }
      // execute the report query
      if (($db=tws_report_query($$dbds,$from,$sel,$crit,$ord,$pri,$query))===FALSE) return FALSE; //database query failed
      if ($mode=='FETCH_ALL') {
         //initialize the output structure
         $rows=array();
      } else {
         //initialize the cache
         $sel_cache=$sel;
         $db_cache=$db;
         return $db;
      }
   }
   //fetch query rows
   while ($row=db_fetch_row($db)) {
      if ($mode=='FETCH_ALL') $rows[]=$row;
      else return $row;
   }
   if ($mode=='FETCH_ALL') return $rows;
   //reset the cache
   $db_cache=$sel_cache=NULL;
   return 0;
}


///////////////////////////////////////////////////////////////////////////////
//
// List of users
//
// Arguments:
//    user = user name (@=wildcard for all)
//    sqlcond = sql filter - conditions of the where clause
//
function tws_get_users($user='@#@', $sqlfilter='1=1', $page_size = 0, $page = 1, $od_callback=null, $action='LIST') {
   tws_log('-- get_db_users_list (start at '.basename(__FILE__).'['.__LINE__.'])');
   global $tws_config, $composer_db;

//initilization
   list($user,$workstation)=array_reverse(explode('#',$user));
   $workstation=='' && $workstation='@';

   $users=array();
   $users['user_num']=0;

//access rights checking
   if (($acc_sql=tws_sec_check('USEROBJ', array('CPU'=>'WKC_NAME','NAME'=>'WUS_NAME'), '', $action))===FALSE) return $users;
   if( $acc_sql == "AND WKC_NAME  LIKE '%' ESCAPE '/'")
      $acc_sql = "AND (WKC_NAME  LIKE '%' ESCAPE '/' OR WKC_NAME IS NULL)";

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if (!$dbh) {
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=$composer_db["schema"];
   $query ="
      SELECT
         WUS_ID ,
         WUS_NAME ,
         WKC_NAME ,
         WUS_MODIFY_OWNER ,
         WUS_MODIFY_TIME ,
         WUS_LOCK_OWNER ,
         WUS_LOCK_TIME
      FROM (
         $schema.WUS_WINDOWS_USERS WUS
         LEFT JOIN $schema.WKC_WORKSTATION_CLASSES WKC on WUS.WKC_ID = WKC.WKC_ID
         )
      WHERE
         WUS_NAME ".tws_sqllike(db_string($composer_db,$user),'')." AND
         ".(($workstation!='@' && $workstation!='*') ? "WKC_NAME ".tws_sqllike(db_string($composer_db,$workstation))." AND " : '')."
         $sqlfilter
         $acc_sql
      ";
   tws_log('DB query: '.$query);
   if( !($r=db_query($composer_db,$query)) ){
      tws_log('Error: Database query failed');
      tws_error('', 'Database query failed');
      return FALSE;
   }
   $tl=tws_log();
   if ($page_size > 0) {
      $page_down = ($page - 1) * $page_size;
      $page_up = $page * $page_size;
   }
   while ($row = db_fetch_row($composer_db)) {
      $tl && tws_log(@var_export($row, true));
      $users['user_num']++;
      if ($page_size > 0) {
         if ($page_down >= $users['user_num']) {
            while (($page_down > $users['user_num']) && db_fetch_row($composer_db, null)) {
              $users['user_num']++;
            }
            continue;
         }
         if ($page_up < $users['user_num']) {
            while (($page_up < $users['user_num']) && db_fetch_row($composer_db, null)) {
               $users['user_num']++;
            }
            break;
         }
      }
      $users['user_id'          ][] = $row['WUS_ID'];
      $users['user_name'        ][] = $row['WUS_NAME'];
      $users['user_workstation' ][] = $row['WKC_NAME'];
      $users['user_creator'     ][] = $row['WUS_MODIFY_OWNER'];
      $users['user_last_updated'][] = $row['WUS_MODIFY_TIME'];
      $users['user_lock_by'     ][] = $row['WUS_LOCK_OWNER'];
      $users['user_lock_on'     ][] = $row['WUS_LOCK_TIME'];
   }
   tws_log('-- get_db_users_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
   if (defined('IWD_PROCMAN')) return $users; //procman::db_functions::db_fetch_row returns FALSE if there are no rows left
   return ($row===FALSE ? FALSE : $users);
}

///
/// Users report handler (used at IWS Database Report page)
/// \param sel SELECT attributes
/// \param crit items used to build WHERE clause
/// \param ord items used to build ORDER BY clause
/// \param pri items used to sort ORDER BY items
/// \param query (output parameter) resultant sql query string
/// \param dbds (output parameter) database descriptor name
/// \param mode controls the output mode (FETCH_ALL=all results returned in an in array, INIT=initialize the data stream, then fetching data by calling without parameters)
/// \return resultant fetched rows of the created query or the column name map if sel===null
function tws_users_report($sel=array(), $crit=array(), $ord=array(), $pri=array(), &$query='', &$dbds='', $mode='FETCH_ALL') {
   global $tws_config, $composer_db, $tws_types;
   static $db_cache=NULL, $sel_cache=NULL;

   if (func_num_args()==0) { //fetching data after a previous calling with mode='INIT'
      if ($db_cache===NULL || $sel_cache===NULL) {
         tws_error('Data fetch error', 'Not initialized data stream');
         return FALSE;
      }
      $sel=$sel_cache;
      $db=$db_cache;
      $mode='ROW'; //just internal flag, anything besides 'FETCH_ALL' has the same effect
   } else {
      $dbds='composer_db';
      $colmap = array (
         'WKC.WKC_NAME' => 'Workstation',
         'WUS.WUS_NAME' => 'Full User Name'
      );
      if ($sel===null) return $colmap;
      $schema=$composer_db['schema'];
      $from="($schema.WUS_WINDOWS_USERS WUS LEFT JOIN $schema.WKC_WORKSTATION_CLASSES WKC on WUS.WKC_ID = WKC.WKC_ID)";
      $crit['WKC.WKC_NAME']=strtoupper($crit['WKC.WKC_NAME']);
      // execute the report query
      if (($db=tws_report_query($$dbds,$from,$sel,$crit,$ord,$pri,$query))===FALSE) return FALSE; //database query failed
      if ($mode=='FETCH_ALL') {
         //initialize the output structure
         $rows=array();
      } else {
         //initialize the cache
         $sel_cache=$sel;
         $db_cache=$db;
         return $db;
      }
   }
   //fetch query rows
   while ($row=db_fetch_row($db)) {
      if ($mode=='FETCH_ALL') $rows[]=$row;
      else return $row;
   }
   if ($mode=='FETCH_ALL') return $rows;
   //reset the cache
   $db_cache=$sel_cache=NULL;
   return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
// List of prompts
//
// Arguments:
//    prompt = prompt name (@=wildcard for all)
//    sqlcond = sql filter - conditions of the where clause
//
function tws_get_prompts($prompt='@', $sqlfilter='1=1', $page_size = 0, $page = 1, $od_callback=null, $action='LIST') {
   global $tws_config, $composer_db;

   tws_log('-- tws_get_prompts (start at '.basename(__FILE__).'['.__LINE__.'])');
   tws_log("-- tws_get_prompts: prompt = '$prompt', sqlfilter = '$sqlfilter'");


   list($prompt_folder, $prompt) = tws_divide_folder($prompt);
   $prompts=array();
   $prompts['prompt_num']=0;

//access rights checking
   if (($acc_sql=tws_sec_check('PROMPT', array('NAME'=>'RES_NAME'), '', $action))===FALSE) return $prompts;

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=$composer_db["schema"];
   $query ="
      SELECT
         RES_ID ,
         RES_NAME ,
         RES_TEXT ,
         RES_MODIFY_OWNER ,
         RES_MODIFY_TIME ,
         RES_LOCK_OWNER ,
         RES_LOCK_TIME";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= ",
                RES_FOLDERS.FOL_PATH
            ";
      $query .= "
      FROM
         $schema.RES_ABSTRACT_RESOURCES RES";
          if ($tws_config['cpuinfo']['version']>='9.5002')
             $query .= "
                LEFT JOIN $schema.FOL_FOLDERS RES_FOLDERS ON RES_FOLDERS.FOL_ID = RES.FOL_ID ";
      $query .= "
      WHERE RES_CLASS = 'P' AND
         RES_TYPE = 'P' AND
         RES_NAME ".tws_sqllike(db_string($composer_db,$prompt))." AND
         $sqlfilter
         $acc_sql";
          if ($tws_config['cpuinfo']['version']>='9.5002' && !empty($prompt_folder))
             $query .= "
            AND FOL_PATH =  '$prompt_folder'";

   tws_log('-- tws_get_prompts DB query: '.$query);
   if( !($r=db_query($composer_db,$query)) ){
      tws_log('Error: Database query failed');
      tws_error('', 'Database query failed');
      return FALSE;
   }
   $tl=tws_log();
   if ($page_size > 0) {
      $page_down = ($page - 1) * $page_size;
      $page_up = $page * $page_size;
   }
   while ($row = db_fetch_row($composer_db)) {
 //      tws_log('-- tws_get_prompts row:'. var_export($row, true));
      $prompts['prompt_num']++;
      if ($page_size > 0) {
         if ($page_down >= $prompts['prompt_num']) {
            while (($page_down > $prompts['prompt_num']) && db_fetch_row($composer_db, null)) {
               $prompts['prompt_num']++;
            }
            continue;
         }
         if ($page_up < $prompts['prompt_num']) {
            while (($page_up < $prompts['prompt_num']) && db_fetch_row($composer_db, null)) {
               $prompts['prompt_num']++;
            }
            break;
         }
      }
      $prompts['prompt_id'          ][] = $row['RES_ID'];
      $prompts['prompt_name'        ][] = $row['RES_NAME'];
      $prompts['prompt_text'        ][] = $row['RES_TEXT'];
      $prompts['prompt_creator'     ][] = $row['RES_MODIFY_OWNER'];
      $prompts['prompt_last_updated'][] = $row['RES_MODIFY_TIME'];
      $prompts['prompt_lock_by'     ][] = $row['RES_LOCK_OWNER'];
      $prompts['prompt_lock_on'     ][] = $row['RES_LOCK_TIME'];
      if ($tws_config['cpuinfo']['version']>='9.5002' && !empty($row['FOL_PATH']))
          $prompts['prompt_folder'][] = $row['FOL_PATH'];
   }
   tws_log('-- get_db_prompts (end up in '.basename(__FILE__).'['.__LINE__.'])');
   return $prompts;

}

///
/// Prompts report handler (used at IWS Database Report page)
/// \param sel SELECT attributes
/// \param crit items used to build WHERE clause
/// \param ord items used to build ORDER BY clause
/// \param pri items used to sort ORDER BY items
/// \param query (output parameter) resultant sql query string
/// \param dbds (output parameter) database descriptor name
/// \param mode controls the output mode (FETCH_ALL=all results returned in an in array, INIT=initialize the data stream, then fetching data by calling without parameters)
/// \return resultant fetched rows of the created query or the column name map if sel===null
function tws_prompts_report($sel=array(), $crit=array(), $ord=array(), $pri=array(), &$query='', &$dbds='', $mode='FETCH_ALL') {
   global $tws_config, $composer_db, $tws_types;
   static $db_cache=NULL, $sel_cache=NULL;

   if (func_num_args()==0) { //fetching data after a previous calling with mode='INIT'
      if ($db_cache===NULL || $sel_cache===NULL) {
         tws_error('Data fetch error', 'Not initialized data stream');
         return FALSE;
      }
      $sel=$sel_cache;
      $db=$db_cache;
      $mode='ROW'; //just internal flag, anything besides 'FETCH_ALL' has the same effect
   } else {
      $dbds='composer_db';
      $colmap = array (
         'RES_NAME' => 'Prompt',
         'RES_TEXT' => 'Prompt Text'
      );
      if ($sel===null) return $colmap;
      $schema=$composer_db['schema'];
      $from="$schema.RES_ABSTRACT_RESOURCES";
      $crit['RES_NAME']=strtoupper($crit['RES_NAME']);
      // execute the report query
      if (($db=tws_report_query($$dbds,$from,$sel,$crit,$ord,$pri,$query,"(RES_CLASS='P' AND RES_TYPE='P')"))===FALSE) return FALSE; //database query failed
      if ($mode=='FETCH_ALL') {
         //initialize the output structure
         $rows=array();
      } else {
         //initialize the cache
         $sel_cache=$sel;
         $db_cache=$db;
         return $db;
      }
   }
   //fetch query rows
   while ($row=db_fetch_row($db)) {
      if ($mode=='FETCH_ALL') $rows[]=$row;
      else return $row;
   }
   if ($mode=='FETCH_ALL') return $rows;
   //reset the cache
   $db_cache=$sel_cache=NULL;
   return 0;
}


///////////////////////////////////////////////////////////////////////////////
//
// List of resources
//
// Arguments:
//    resource = resource name (@=wildcard for all)
//    sqlcond = sql filter - conditions of the where clause
//
function tws_get_resources($resource='@', $sqlfilter='1=1', $page_size = 0, $page = 1, $od_callback=null, $action='LIST') {

   tws_log('-- tws_get_resources (start at '.basename(__FILE__).'['.__LINE__.'])');
   tws_log("-- tws_get_resources Parameters: resource = $resource, sqlfilter = $sqlfilter");
   global $tws_config, $composer_db;

   list($resource, $workstation)=array_reverse(explode('#',$resource));
   if($workstation=='') $workstation='@';

tws_log("-- tws_get_resources: workstation = $workstation, resource = $resource");

if ($tws_config['cpuinfo']['version']>='9.5002'){
   list($ws_folder, $workstation) = tws_divide_folder($workstation);
   if(empty($ws_folder)) $ws_folder = '@';
   list($res_folder, $resource) = tws_divide_folder($resource);
   if(empty($res_folder)) $res_folder = '@';
   tws_log("-- tws_get_resources: ws_folder = $ws_folder, workstation = $workstation");
   tws_log("-- tws_get_resources: res_folder = $res_folder, resource = $resource");
}
   $resources=array();
   $resources['resource_num']=0;

//access rights checking
   if (($acc_sql=tws_sec_check('RESOURCE', array('CPU'=>'WKC_NAME','NAME'=>'RES_NAME'), '', $action))===FALSE) return $resources;

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=$composer_db["schema"];
   $query ="
      SELECT
         RES_ID ,
         RES_NAME ,
         RES_DESCRIPTION ,
         RES_QUANTITY ,
         WKC_NAME ,
         RES_MODIFY_OWNER ,
         RES_MODIFY_TIME ,
         RES_LOCK_OWNER ,
         RES_LOCK_TIME";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= ",
            WKS_FOL.FOL_PATH WKS_FOL_PATH,
            RES_FOL.FOL_PATH RES_FOL_PATH";
      $query .= "
      FROM (
         $schema.RES_ABSTRACT_RESOURCES RES
         join $schema.WKC_WORKSTATION_CLASSES WKC on RES.WKC_ID = WKC.WKC_ID
         )";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
         LEFT JOIN $schema.FOL_FOLDERS WKS_FOL ON WKS_FOL.FOL_ID = WKC.FOL_ID
         LEFT JOIN $schema.FOL_FOLDERS RES_FOL ON RES_FOL.FOL_ID = RES.FOL_ID ";
      $query .= "
      WHERE RES_CLASS = 'R' AND
         RES_NAME ".tws_sqllike(db_string($composer_db, $resource))." AND
         WKC_NAME ".tws_sqllike(db_string($composer_db, $workstation))." AND
         $sqlfilter
         $acc_sql";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
         AND WKS_FOL.FOL_PATH ".tws_sqllike(db_string($composer_db, $ws_folder))."
         AND RES_FOL.FOL_PATH ".tws_sqllike(db_string($composer_db, $res_folder));

   tws_log('-- tws_get_resources. DB query: '.$query);
   if( !($r=db_query($composer_db,$query)) ){
      tws_log('-- tws_get_resources: Error: Database query failed');
      tws_error('', 'Database query failed');
      return FALSE;
   }
   $tl=tws_log();
   if ($page_size > 0) {
      $page_down = ($page - 1) * $page_size;
      $page_up = $page * $page_size;
   }
   while ($row = db_fetch_row($composer_db)) {
      $tl && tws_log(@var_export($row, true));
      $resources['resource_num']++;
      if ($page_size > 0) {
         if ($page_down >= $resources['resource_num']) {
            while (($page_down > $resources['resource_num']) && db_fetch_row($composer_db, null)) {
               $resources['resource_num']++;
            }
            continue;
         }
         if ($page_up < $resources['resource_num']) {
            while (($page_up < $resources['resource_num']) && db_fetch_row($composer_db, null)) {
               $resources['resource_num']++;
            }
            break;
         }
      }
      $resources['resource_id'          ][] = $row['RES_ID'];
      $resources['resource_name'        ][] = $row['RES_NAME'];
      $resources['resource_description' ][] = $row['RES_DESCRIPTION'];
      $resources['resource_quantity'    ][] = $row['RES_QUANTITY'];
      $resources['resource_workstation' ][] = $row['WKC_NAME'];
      $resources['resource_creator'     ][] = $row['RES_MODIFY_OWNER'];
      $resources['resource_last_updated'][] = $row['RES_MODIFY_TIME'];
      $resources['resource_lock_by'     ][] = $row['RES_LOCK_OWNER'];
      $resources['resource_lock_on'     ][] = $row['RES_LOCK_TIME'];
      if($tws_config['cpuinfo']['version']>='9.5002'){
         $resources['workstation_folder'][] = $row['WKS_FOL_PATH'];
         $resources['resource_folder'][] = $row['RES_FOL_PATH'];
      }
   }
   tws_log('-- get_db_resources_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
   return $resources;
}

///
/// Resources report handler (used at IWS Database Report page)
/// \param sel SELECT attributes
/// \param crit items used to build WHERE clause
/// \param ord items used to build ORDER BY clause
/// \param pri items used to sort ORDER BY items
/// \param query (output parameter) resultant sql query string
/// \param dbds (output parameter) database descriptor name
/// \param mode controls the output mode (FETCH_ALL=all results returned in an in array, INIT=initialize the data stream, then fetching data by calling without parameters)
/// \return resultant fetched rows of the created query or the column name map if sel===null
function tws_resources_report($sel=array(), $crit=array(), $ord=array(), $pri=array(), &$query='', &$dbds='', $mode='FETCH_ALL') {
   global $tws_config, $composer_db, $tws_types;
   static $db_cache=NULL, $sel_cache=NULL;

   if (func_num_args()==0) { //fetching data after a previous calling with mode='INIT'
      if ($db_cache===NULL || $sel_cache===NULL) {
         tws_error('Data fetch error', 'Not initialized data stream');
         return FALSE;
      }
      $sel=$sel_cache;
      $db=$db_cache;
      $mode='ROW'; //just internal flag, anything besides 'FETCH_ALL' has the same effect
   } else {
      $dbds='composer_db';
      $colmap = array (
         'WKC_NAME'        => 'Workstation',
         'RES_NAME'        => 'Resource',
         'RES_QUANTITY'    => 'Units',
         'RES_DESCRIPTION' => 'Description'
      );
      if ($sel===null) return $colmap;
      $schema=$composer_db['schema'];
      $from="($schema.RES_ABSTRACT_RESOURCES RES LEFT JOIN $schema.WKC_WORKSTATION_CLASSES WKC on RES.WKC_ID = WKC.WKC_ID)";
      $crit['WKC_NAME']=strtoupper($crit['WKC_NAME']);
      $crit['RES_NAME']=strtoupper($crit['RES_NAME']);
      // execute the report query
      if (($db=tws_report_query($$dbds,$from,$sel,$crit,$ord,$pri,$query,"(RES_CLASS='R')"))===FALSE) return FALSE; //database query failed
      if ($mode=='FETCH_ALL') {
         //initialize the output structure
         $rows=array();
      } else {
         //initialize the cache
         $sel_cache=$sel;
         $db_cache=$db;
         return $db;
      }
   }
   //fetch query rows
   while ($row=db_fetch_row($db)) {
      if ($mode=='FETCH_ALL') $rows[]=$row;
      else return $row;
   }
   if ($mode=='FETCH_ALL') return $rows;
   //reset the cache
   $db_cache=$sel_cache=NULL;
   return 0;
}


///////////////////////////////////////////////////////////////////////////////
//
// List of jobs
//
// Arguments:
//    workstation = workstation class  name (@=wildcard for all)
//    job = job name (@=wildcard for all)
//    sqlcond = sql filteri - conditions of the where clause
//
function tws_get_jobs($workstation='@', $job='@', $sqlfilter='', $page_size=0, $page=1, $od_callback=null, $action='LIST') {
   global $tws_config, $composer_db;
   tws_log('-- tws_get_jobs (start at '.basename(__FILE__).'['.__LINE__.'])');
   tws_log('-- tws_get_jobs - memory usage: '.intval(memory_get_usage()/1024).' kB');
   tws_log('-- tws_get_jobs - peak memory usage: '.intval(memory_get_peak_usage()/1024).' kB');

   tws_log("-- tws_get_jobs Parameters: workstation='$workstation', job='$job', sqlfilter = '$sqlfilter'");

   if ($sqlfilter=='') $sqlfilter='1=1';
   $jobs=array();
   $jobs['job_num']=0;

//access rights checking
   $secsel= array('CPU'=>'WKC_NAME','NAME'=>'JOD_NAME','LOGON'=>'JOD_USER_LOGIN','JCL'=>'JOD_TASK_STRING');
   if ($tws_config['cpuinfo']['version']>='9.5')
       $secsel['FOLDER'] = 'FOL_PATH';

   if (($acc_sql=tws_sec_check('JOB', $secsel, '', $action))===FALSE) return $jobs;
   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ) {
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=$composer_db["schema"];

   $ws_folder = '';
   if ($tws_config['cpuinfo']['version']>='9.5002'){
		list($ws_folder, $workstation) = tws_divide_folder($workstation);
//      if(empty($ws_folder)) $ws_folder = '/';
   }
   $job_folder = '';
   if ($tws_config['cpuinfo']['version']>='9.5'){
      list($job_folder, $job) = tws_divide_folder($job);
//      if(empty($job_folder)) $job_folder = '/';
   }
   tws_log(" -- tws_get_jobs - ws_folder = '$ws_folder', workstation = '$workstation'");
   tws_log(" -- tws_get_jobs - job_folder = '$job_folder', job = '$job'");

if( $page_size > 0)     // if flextable has page_size - it means that it is limit from admin
   $paging = true;
else $paging = false;

if( $paging ){    //
// TODO: add folders in WHERE to calculate jobs count
   $query ="
      SELECT count(*) CNT
      FROM ((   $schema.JOD_JOB_DEFINITIONS JOD
           JOIN $schema.WKC_WORKSTATION_CLASSES WKC on JOD.WKC_ID = WKC.WKC_ID
         ) JOIN $schema.JOS_JOB_STATISTICS JOS on JOD.JOD_ID = JOS.JOD_ID
         )";
         if($tws_config['cpuinfo']['version']>='9.5')
           $query .= "
               LEFT JOIN $schema.FOL_FOLDERS JOB_FOL ON JOB_FOL.FOL_ID = JOD.FOL_ID";  // 9.5 job folders
         if($tws_config['cpuinfo']['version']>='9.5002')
           $query .= "
               LEFT JOIN $schema.FOL_FOLDERS WS_FOL ON WS_FOL.FOL_ID = WKC.FOL_ID";  // 9.5 job folders
      $query .= "
      WHERE
         WKC_NAME ".tws_sqllike(db_string($composer_db, $workstation))." AND
         JOD_NAME ".tws_sqllike(db_string($composer_db, $job))." AND
         $sqlfilter
         $acc_sql";

         if($tws_config['cpuinfo']['version']>='9.5' && !empty($job_folder))
            $query .= "
            AND JOB_FOL.FOL_PATH = db_string($composer_db, $job_folder)";

         if($tws_config['cpuinfo']['version']>='9.5002' && !empty($ws_folder))
            $query .= "
            AND WS_FOL.FOL_PATH = db_string($composer_db, $ws_folder)";


   tws_log(" -- tws_get_jobs Count DB Query: $query");

   if( !($r=db_query($composer_db,$query)) ){
      tws_log('Error: Database query failed');
      tws_error('', 'Database query failed');
      return FALSE;
   }
   $row = db_fetch_row($composer_db);
   $jobs['job_num'] = $row['CNT'];
}
   tws_log(" -- tws_get_jobs Count Result: $query");

   $query ="
      SELECT
         JOD.JOD_ID ,
         JOD_NAME ,
         WKC_NAME ,
         JOD_TASK_TYPE ,
         JOD_TASK_STRING,
         JOD_USER_LOGIN ,
         JOD_DESCRIPTION ,
         JOS_LAST_RUN_DATE ,
         JOD_MODIFY_OWNER ,
         JOD_MODIFY_TIME ,
         JOD_LOCK_OWNER ,
         JOD_LOCK_TIME";
         if($paging && $composer_db['type']=='db2')
            $query .=",
               ROW_NUMBER() OVER(ORDER BY WKC_NAME, JOD_NAME) rnum";
      if($tws_config['cpuinfo']['version']>='9.5')
         $query .=",
            JOB_FOL.FOL_PATH JOB_FOLDER";     // 9.5 Job Folders
      if($tws_config['cpuinfo']['version']>='9.5002')
          $query .= ",
              WS_FOL.FOL_PATH WS_FOLDER";    // 9.5.2 WS Folders
      $query .= "
      FROM ((   $schema.JOD_JOB_DEFINITIONS JOD
           JOIN $schema.WKC_WORKSTATION_CLASSES WKC on JOD.WKC_ID = WKC.WKC_ID)
           JOIN $schema.JOS_JOB_STATISTICS JOS on JOD.JOD_ID = JOS.JOD_ID)";
         if($tws_config['cpuinfo']['version']>='9.5')
           $query .= "
               LEFT JOIN $schema.FOL_FOLDERS JOB_FOL ON JOB_FOL.FOL_ID = JOD.FOL_ID";  // 9.5 Job Folders
           if($tws_config['cpuinfo']['version']>='9.5002')
               $query .= "
               LEFT JOIN $schema.FOL_FOLDERS WS_FOL ON WS_FOL.FOL_ID = WKC.FOL_ID";  // 9.5.2 WS Folders
      $query .= "
      WHERE
         WKC_NAME ".tws_sqllike(db_string($composer_db,$workstation))." AND
         JOD_NAME ".tws_sqllike(db_string($composer_db,$job))."
         $acc_sql
         AND $sqlfilter";
         if($tws_config['cpuinfo']['version']>='9.5' && !empty($job_folder))
           $query .= "
            AND JOB_FOL.FOL_PATH = '$job_folder'";                   // 9.5 Job Folders
         if($tws_config['cpuinfo']['version']>='9.5002' && !empty($ws_folder))
           $query .= "
            AND WS_FOL.FOL_PATH = '$ws_folder'";                     // 9.5.2 WS Folders
      $query .= "
      ORDER BY WKC_NAME, JOD_NAME";
/*
   if($paging){
      if($composer_db['type']=='db2')
         $query = "SELECT * FROM ($query) WHERE rnum BETWEEN ".(($page-1)*$page_size +1)." AND ".($page*$page_size);
      else
         $query = "
         select *
         from (select a.*, rownum rnum
            from ($query)a
            where rownum <= ".($page*$page_size).") where rnum > ".(($page-1)*$page_size);
   }
tws_log("-- tws_get_jobs DB query rownum: $query");
*/
   if( !($r=db_query($composer_db,$query)) ){
      tws_log('Error: Database query failed');
      tws_error('', 'Database query failed');
      return FALSE;
   }

   $oc=$od_callback!==null;
   $tl=tws_log();

   while ($row = db_fetch_row($composer_db)) {
      $tl && tws_log(@var_export($row, true));
      if(!$paging) $jobs['job_num']++;

      $jb['job_id'          ] = $row['JOD_ID'];
      $jb['job_name'        ] = $row['JOD_NAME'];
      $jb['job_workstation' ] = $row['WKC_NAME'];
      $jb['job_task_type'   ] = $row['JOD_TASK_TYPE'];
      $jb['job_login'       ] = $row['JOD_USER_LOGIN'];
      $jb['job_description' ] = $row['JOD_DESCRIPTION'];
      $jb['job_last_run'    ] = $row['JOS_LAST_RUN_DATE'];
      $jb['job_creator'     ] = $row['JOD_MODIFY_OWNER'];
      $jb['job_last_updated'] = $row['JOD_MODIFY_TIME'];
      $jb['job_lock_by'     ] = $row['JOD_LOCK_OWNER'];
      $jb['job_lock_on'     ] = $row['JOD_LOCK_TIME'];
      if($tws_config['cpuinfo']['version']>='9.5')
         $jb['job_folder'] = $row['JOB_FOLDER'];
      if($tws_config['cpuinfo']['version']>='9.5002')
         $jb['job_workstation_folder'] = $row['WS_FOLDER'];
      if ($oc) {
         $jb['offset']=$jobs['job_num'];
         $od_callback($jb);
      }
      else {
         foreach ($jb as $key=>$val)
            $jobs[$key][]=$val;
      }
   }
   tws_log('-- get_db_jobs_list Result: '. var_export($jobs, true));
   tws_log('-- tws_get_jobs (end up in '.basename(__FILE__).'['.__LINE__.'])');
   tws_log('-- tws_get_jobs - memory usage: '.intval(memory_get_usage()/1024).' kB');
   tws_log('-- tws_get_jobs - peak memory usage: '.intval(memory_get_peak_usage()/1024).' kB');
   if (defined('IWD_PROCMAN')) return $jobs; //procman::db_functions::db_fetch_row returns FALSE if there are no rows left
   return ($row===FALSE ? FALSE : $jobs);
}

/// Get all job defintion data.
/// The output structure should correspond to the add/copy/modify form
/// \param workstation Workstation name (accurate name)
/// \param job Job name (accurate name)
function tws_get_job_def_data($workstation, $job) {
   global $tws_config, $composer_db;

   tws_log('-- tws_get_job_def_data (start at '.basename(__FILE__).'['.__LINE__.'])');
   tws_log("-- tws_get_job_def_data Parameters: workstation = $workstation, job = $job");

   $dbh = db_connect($composer_db, DB_PERSISTENT);
   if( !$dbh ){
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=$composer_db["schema"];

   if ($workstation=='' || $job=='') {
      tws_error("workstation='$workstation', job=='$job'", 'Missing job identifaction data.');
      return FALSE;
   }
   $workstation = strtoupper($workstation);
   $job = strtoupper($job);

// IWS 9.5002 - divide WS folder and WS name
   list($workstation_folder, $workstation_name) = tws_divide_folder($workstation);
   if ($tws_config['cpuinfo']['version'] >=9.5002 && empty($workstation_folder) )
       $workstation_folder = '/@';

// IWS 9.5 - divide folder and name
   list($job_folder, $job_name) = tws_divide_folder($job);
   if ($tws_config['cpuinfo']['version'] >=9.5 && empty($job_folder) )
       $job_folder = '/@';

// TODO: Add folders in SELECT WHERE

   $st_name = 'JOB_DEF_DATA';
   $hex_fce = ($composer_db['type']=='db2' ? 'HEX' : 'RAWTOHEX');

   if(!isset($composer_db[$st_name])){
      $query = "
      SELECT";
     if($tws_config['cpuinfo']['version'] >=9.5002)     // WS Folder
        $query .= "
           WC_FOL.FOL_PATH WS_FOLDER,";
      $query .= "
         WKC.WKC_NAME WORKSTATION,";
     if($tws_config['cpuinfo']['version'] >=9.5)     // WS Folder
        $query .= "
           JOB_FOL.FOL_PATH JOB_FOLDER,";
      $query .= "
         JOD.JOD_NAME JOB_NAME,
         JOD.JOD_TASK_TYPE TASK_TYPE,
         JOD.JOD_DESCRIPTION DESCRIPTION,
         JOD.JOD_COMMAND JOB_COMMAND,
         JOD.JOD_TASK_STRING SCRIPT,
         JOD.JOD_RETURN_CODE_MAPPING EXITCODEMAP,
         JOD.JOD_INTERACTIVE INTERACTIVE,
         REC_WKC.WKC_NAME RECOVERY_WORKSTATION,
         REC_JOD.JOD_NAME RECOVERY_JOB,   ";
      if($tws_config['cpuinfo']['version'] >= '9.5')
          $query .= "
          REC_JOB_FOL.FOL_PATH RECOVERY_JOB_FOLDER,
          JOB_FOL.FOL_PATH JOB_FOLDER,";
      if($tws_config['cpuinfo']['version'] >='9.5002')
           $query .= "
          REC_WS_FOL.FOL_PATH RECOVERY_WS_FOLDER,
          WC_FOL.FOL_PATH WS_FOLDER,";
      $query .="
         JOD.JOD_RECOVERY_OPTION RECOVERY_OPTION,
         JOD.JOD_USER_LOGIN LOGON,
         RES.RES_TEXT RECOVERY_PROMPT";
         if($tws_config['cpuinfo']['version'] >=9.4)        // Recovery Job
         $query .= ($tws_config['cpuinfo']['version']>=9.4 ? ',
            JOD.JOD_REC_REPEAT_AFFINITY, JOD.JOD_REC_REPEAT_INTERVAL, JOD.JOD_REC_REPEAT_OCCURRENCES' : '');

      $query .= "
      FROM (((( $schema.JOD_JOB_DEFINITIONS JOD
         JOIN $schema.WKC_WORKSTATION_CLASSES WKC ON WKC.WKC_ID = JOD.WKC_ID )
         LEFT JOIN $schema.JOD_JOB_DEFINITIONS REC_JOD ON JOD.JOD_RECOVERY_ID = REC_JOD.JOD_ID)
         LEFT JOIN $schema.WKC_WORKSTATION_CLASSES REC_WKC ON REC_JOD.WKC_ID=REC_WKC.WKC_ID)
         LEFT JOIN $schema.RES_ABSTRACT_RESOURCES RES ON RES.RES_ID=JOD.RES_ID)
         ";
        if ($tws_config['cpuinfo']['version']>='9.5')
            $query .="
            LEFT JOIN $schema.FOL_FOLDERS JOB_FOL ON JOB_FOL.FOL_ID = JOD.FOL_ID
            LEFT JOIN $schema.FOL_FOLDERS REC_JOB_FOL ON REC_JOD.FOL_ID=REC_JOB_FOL.FOL_ID ";

        if($tws_config['cpuinfo']['version']>='9.5002')
            $query .="
            LEFT JOIN $schema.FOL_FOLDERS WC_FOL ON WC_FOL.FOL_ID = WKC.FOL_ID
            LEFT JOIN $schema.FOL_FOLDERS REC_WS_FOL ON REC_WS_FOL.FOL_ID=REC_WKC.FOL_ID";
// TODO: Recovery Job
    $query .="
       WHERE";
        if($tws_config['cpuinfo']['version']>='9.5002')
            $query .="
                WC_FOL.FOL_PATH = ? AND";
        $query .="
         WKC.WKC_NAME= ? AND";
        if($tws_config['cpuinfo']['version']>='9.5')
            $query .="
               JOB_FOL.FOL_PATH = ? AND";
        $query .="
         JOD.JOD_NAME= ?";

      $stmt=new db_statement($composer_db, $query);
      if ($stmt->prepare()==FALSE){
         unset($stmt);
         tws_error('', 'Database query prepare failed: '.$query);
         return FALSE;
      }
      $composer_db[$st_name] = $stmt;
   }
   else $stmt = $composer_db[$st_name];

// Values:
   $values = array();
   if($tws_config['cpuinfo']['version']>='9.5002'){
       list($workstation_folder, $workstation) = tws_divide_folder($workstation);
       if(empty($workstation_folder))
           $workstation_folder = '/';
       $values[] = db_string($composer_db, $workstation_folder);
   }
   $values[] = db_string($composer_db, $workstation);

   if($tws_config['cpuinfo']['version']>='9.5'){
       list($job_folder, $job) = tws_divide_folder($job);
       if(empty($job_folder))
           $job_folder = '/';
       $values[] = db_string($composer_db, $job_folder);
   }
   $values[] = db_string($composer_db, $job);

tws_log('-- tws_get_job_def_data: DB query: '.$stmt->sql());
tws_log('-- tws_get_job_def_data: Query values: '.var_export($values, true));

   if ($stmt->execute($values)==false){
      tws_error('', 'Database query failed: '.$stmt->sql());
      return FALSE;
   }

   $job_data=array();
   if( $stmt->fetch() ){
      $row = $stmt->row();
      switch ($row['JOB_COMMAND']) {
         case "Y":
            $job_data['job_type']="command";
            break;
         case "N":
            $job_data['job_type']="script";
            break;
      }
      $job_data['workstation']=$row['WORKSTATION'];
      $job_data['name']=$row['JOB_NAME'];
      if(!empty($job_folder)) $job_data['job_folder'] = $job_folder;  // 9.5
      $job_data['task_type']=$row['TASK_TYPE'];
      $job_data['logon']=$row['LOGON'];
      $job_data['script']=$row['SCRIPT'];
      $job_data['description']=$row['DESCRIPTION'];
      $job_data['exitcodemap']=$row['EXITCODEMAP'];
      $job_data['interactive']=tws_yesno($row['INTERACTIVE']);
      switch ($row['RECOVERY_OPTION']) {
         case "S":
            $job_data['recovery_option']="STOP";
            break;
         case "R":
            $job_data['recovery_option']="RERUN";
            break;
         case "C":
            $job_data['recovery_option']="CONTINUE";
            break;
      }
      $job_data['recovery_workstation']=(isset($row['RECOVERY_WS_FOLDER']) ? $row['RECOVERY_WS_FOLDER'] : '').$row['RECOVERY_WORKSTATION'];
      $job_data['recovery_job']=(isset($row['RECOVERY_JOB_FOLDER']) ? $row['RECOVERY_JOB_FOLDER'] : '').$row['RECOVERY_JOB'];
      $job_data['recovery_prompt']=$row['RECOVERY_PROMPT'];
      $job_data['jod_id'] = $row['JOD_ID'];
      if($tws_config['cpuinfo']['version']>='9.4'){
         $job_data['recovery_same_workstation'] = $row['JOD_REC_REPEAT_AFFINITY'];
         tws_get_at_time($row['JOD_REC_REPEAT_INTERVAL'], $job_data['recovery_repeat_hour'],$job_data['recovery_repeat_minute'], $tmp, $tmp);
         $job_data['recovery_repeat_interval'] = $row['JOD_REC_REPEAT_INTERVAL'];
         $job_data['recovery_repeat_occurrences'] = $row['JOD_REC_REPEAT_OCCURRENCES'];
      }
   }


      if($tws_config['cpuinfo']['version']>='9.3'){
            //$jod_id = bin2hex($job_data['jod_id']);
            $jod_id = $job_data['jod_id'];
            $hex_id = ($composer_db['type']=='db2' ? "x'$jod_id'" : "HEXTORAW('$jod_id')");

         $query = "SELECT JOC_NAME,
                  JOC_MAPPING_EXPRESSION,
                  JOC_SUCC_CONDITION
                  FROM $schema.JOC_JOB_OUTPUT_CONDITIONS
                  WHERE JOD_ID = $hex_id";
         if (!db_query($composer_db, $query)) {
            tws_error('', 'Database query failed');
            return $job_data;
         }
         while(($row = db_fetch_row( $composer_db)) != false){
            $job_data['joc_name'][] = $row['JOC_NAME'];
            $job_data['joc_mapping_expression'][] = $row['JOC_MAPPING_EXPRESSION'];
            $job_data['joc_succ_condition'][] = $row['JOC_SUCC_CONDITION'];
         }
      }
      if($tws_config['cpuinfo']['version']>='9.5002'){
          $job_data['workstation'] =$workstation_folder.$job_data['workstation'];
      }
      tws_log('-- tws_get_job_def_data: return data : '.var_export($job_data, true));
   return $job_data;
}

// IWS 9.3
// return array of job's Return Code Maps:
// name, expression, 'set as successfull' flag
// used in jobstream defenition dependencies
// parameters:
// job workstation
// job definition name

function tws_get_job_codemap($workstation, $job){
   global $tws_config, $composer_db;

   $res = array();
   if($tws_config['cpuinfo']['version']<'9.3')
      return $res;

   if ($workstation=='' || $job=='') {
      tws_error("workstation='$workstation', job=='$job'", 'Missing job identifaction data.');
      return FALSE;
   }
   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=$composer_db["schema"];
   $st_name = 'JOB_CODEMAP';

   if(!isset($composer_db[$st_name])){
      $query = "
      SELECT
         JOC_NAME,
         JOC_MAPPING_EXPRESSION,
         JOC_SUCC_CONDITION
      FROM ($schema.JOD_JOB_DEFINITIONS JOD
            JOIN $schema.WKC_WORKSTATION_CLASSES WKC ON WKC.WKC_ID = JOD.WKC_ID )
            LEFT JOIN $schema.JOC_JOB_OUTPUT_CONDITIONS JOC ON JOC.JOD_ID = JOD.JOD_ID
      WHERE
         WKC.WKC_NAME= ? AND
         JOD.JOD_NAME= ?";

      $stmt=new db_statement($composer_db, $query);
      if ($stmt->prepare()==FALSE){
         unset($stmt);
         tws_error('', 'Database query prepare failed: '.$query);
         return FALSE;
      }
      $composer_db[$st_name] = $stmt;
   }
   else $stmt = $composer_db[$st_name];

   $values = array(db_string($composer_db,$workstation), db_string($composer_db,$job));

   tws_log('DB query: '.$stmt->sql());
   tws_log('Query values: '.var_export($values, true));

   if ($stmt->execute($values)==false){
      tws_error('', 'Database query failed: '.$stmt->sql());
      return FALSE;
   }

   while( $stmt->fetch() ){
      $row = $stmt->row();
      if(!empty($row['JOC_NAME'])){
         $res['joc_name'][] = $row['JOC_NAME'];
         $res['joc_mapping_expression'][] = $row['JOC_MAPPING_EXPRESSION'];
         $res['joc_succ_condition'][] = $row['JOC_SUCC_CONDITION'];
      }
   }
   tws_log('Result: '.var_export($res, true));
   return $res;
}

/// Get all job defintion data from XML string.
/// The output structure should correspond to the add/copy/modify form
/// \param $xml_string

function tws_get_job_jsdl_data ($xml_string) {
   if(empty($xml_string)) return array();

   // extract affinity first
   if(preg_match('/-twsAffinity/',$xml_string))
      list ($xml_string, $affinity) = explode('-twsAffinity', $xml_string);
   if ($affinity)
      list($affinity, $jsdl_data['affinity']) =  explode('=',$affinity);

   // export XML in array
   $xml = new XMLReader();
   $xml->xml($xml_string);
   $jsdl = tws_xml2assoc($xml);
   $xml->close();

   $application = array();
   $jsdl = $jsdl[0]['value'];

   // extract task type
   if ($jsdl[0]['tag'] == "jsdl:application") {
      $jsdl_data['task_type'] = $jsdl[0]['attributes']['name'];
      $task_type = strtoupper($jsdl_data['task_type']);

      $application = $jsdl[0]['value'][0];
   }
   else {
      foreach($jsdl as $tag) {
         if($tag['tag'] == "jsdl:application") {
            $application = $tag['value'][0];
            $jsdl_data['task_type'] = $tag['attributes']['name'];
            $task_type = strtoupper( $jsdl_data['task_type'] );
         }
      }
   }
   // extract attributes of first-level tag
   if($task_type == 'EXECUTABLE' && isset($application['attributes'])) {
      $jsdl_data['ex_interactive'] = $application['attributes']['interactive'];
      $jsdl_data['ex_script'] = $application['attributes']['path'];
      $jsdl_data['ex_directory'] = $application['attributes']['workingDirectory'];
   }
   elseif ($task_type == 'XAJOB' && isset($application['attributes'])) {
      $jsdl_data['xa_method'] = $application['attributes']['accessMethod'];
      $jsdl_data['xa_target'] = $application['attributes']['target'];
      $jsdl_data['xa_step'] = $application['attributes']['step'];
   }
   if(isset($application['attributes']['input']))
      $jsdl_data['stdin'] = $application['attributes']['input'];
   if(isset($application['attributes']['output']))
      $jsdl_data['stdout'] = $application['attributes']['output'];
   if(isset($application['attributes']['error']))
      $jsdl_data['stderr'] = $application['attributes']['error'];

   $application = $application['value'];

   // extract WS attributes
   if($task_type == 'WS') {
      $application = $application[0];
      $jsdl_data['ws_operation'] = $application['attributes']['operation'];
      $jsdl_data['ws_url'] = $application['attributes']['wsdlURL'];
      $application = $application['value'];
   }

   foreach($application as $tag) {
      // arguments
      if( preg_match('/:arguments/', $tag['tag'])) {
         $arguments=array();
         foreach ($tag['value'] as $argument) {
            $arguments[] = $argument['value'];
         }
         $jsdl_data['arguments'] = $arguments;
      }
      // credential
      elseif( preg_match('/:credential/', $tag['tag'])) {
         foreach ($tag['value'] as $credential) {
            if(preg_match('/:userName/', $credential['tag']))
               $jsdl_data['user'] = $credential['value'];
            elseif(preg_match('/:password/', $credential['tag']))
               $jsdl_data['password'] = $credential['value'];
         }
      }
      // environment
      elseif( preg_match('/:environment/', $tag['tag'])) {
         $variables=array();
         foreach ($tag['value'] as $variable) {
            $variables[$variable['attributes']['name']] = $variable['value'];
         }
         $jsdl_data['variables'] = $variables;
      }
   }

   // Zshadow
   if($task_type == 'ZSHADOWJOB') {
      foreach($application as $tag) {
         if( $tag['tag'] == 'zshadow:JobStream') {
            $jsdl_data['zshadow_jobstream'] = $tag['value'];
         }
         elseif( $tag['tag'] == 'zshadow:JobNumber') {
            $jsdl_data['zshadow_job'] = $tag['value'];
         }
      }
   }
   // Dshadow
   elseif($task_type == 'DISTRIBUTEDSHADOWJOB') {
      foreach($application as $tag) {
         if( $tag['tag'] == 'dshadow:Workstation') {
            $jsdl_data['dshadow_workstation'] = $tag['value'];
         }
         elseif( $tag['tag'] == 'dshadow:JobStream') {
            $jsdl_data['dshadow_jobstream'] = $tag['value'];
         }
         elseif( $tag['tag'] == 'dshadow:Job') {
            $jsdl_data['dshadow_job'] = $tag['value'];
         }
         elseif( $tag['tag'] == 'dshadow:matching') {
            $match = $tag['value'][0];
               if($match['tag'] == 'dshadow:previous')
                  $jsdl_data['matching'] = 'PREVIOUS';
               elseif($match['tag'] == 'dshadow:sameDay')
                  $jsdl_data['matching'] = 'SAMEDAY';
               elseif($match['tag'] == 'dshadow:relative') {
                  $jsdl_data['matching'] = 'RELATIVE';
                  $jsdl_data['relative_from'] = substr($match['attributes']['from'],0,1);
                  $jsdl_data['relative_fromhour'] = substr($match['attributes']['from'],1,2);
                  $jsdl_data['relative_frommin'] = substr($match['attributes']['from'],3);
                  $jsdl_data['relative_to'] = substr($match['attributes']['to'],0,1);
                  $jsdl_data['relative_tohour'] = substr($match['attributes']['to'],1,2);
                  $jsdl_data['relative_tomin'] = substr($match['attributes']['to'],3);
               }
               elseif($match['tag'] == 'dshadow:absolute') {
                  $jsdl_data['matching'] = 'ABSOLUTE';
                  list($time, $days) = explode(' ', $match['attributes']['from']);
                  $jsdl_data['absolute_fromhour'] = substr($time,0,2);
                  $jsdl_data['absolute_frommin'] = substr($time,2);
                  $jsdl_data['absolute_from'] = substr($days,0,1);
                  $jsdl_data['absolute_fromdays'] = substr($days,1);
                  list($time, $days) = explode(' ', $match['attributes']['to']);
                  $jsdl_data['absolute_tohour'] = substr($time,0,2);
                  $jsdl_data['absolute_tomin'] = substr($time,2);
                  $jsdl_data['absolute_to'] = substr($days,0,1);
                  $jsdl_data['absolute_todays'] = substr($days,1);
               }
         }
      }
   }
   // J2EE
   elseif($task_type == 'J2EE') {
      foreach($application as $tag) {
         if( $tag['tag'] == 'jsdlj:jms') {
            $jsdl_data['j2ee_operation'] = $tag['attributes']['operation'];
            $jsdl_data['j2ee_timeout'] = $tag['attributes']['timeout'];
            foreach($tag['value'] as $param) {
               if( $param['tag'] == 'jsdlj:connectionURL') {
                  $jsdl_data['j2ee_url'] = $param['value'];
               }
               elseif( $param['tag'] == 'jsdlj:connFactory') {
                  $jsdl_data['j2ee_factory'] = $param['value'];
               }
               elseif( $param['tag'] == 'jsdlj:destination') {
                  $jsdl_data['j2ee_destination'] = $param['value'];
               }
               elseif( $param['tag'] == 'jsdlj:message') {
                  $jsdl_data['j2ee_message'] = $param['value'];
               }
            }
         }
      }
   }
   // JAVA
   elseif($task_type == 'JAVA') {
      $javaParms = $application[0]['value'];
      foreach($javaParms as $tag) {
         if( $tag['tag'] == 'jsdljava:jarPath')
            $jsdl_data['java_path'] = $tag['value'];
         elseif( $tag['tag'] == 'jsdljava:className')
            $jsdl_data['java_class'] = $tag['value'];
         elseif( $tag['tag'] == 'jsdljava:parameters'){
            foreach ($tag['value'] as $variable) {
               $variables[$variable['attributes']['key']] = $variable['value'];
            }
            $jsdl_data['variables'] = $variables;
         }
      }
   }
   // DATABASE
   elseif($task_type == 'DATABASE') {
      $sqlAction = $application[0]['value'];
      foreach($sqlAction as $tag) {
         if( $tag['tag'] == 'jsdldatabase:dbms')
            $jsdl_data['db_dbms'] = $tag['value'];
         elseif( $tag['tag'] == 'jsdldatabase:server')
            $jsdl_data['db_server'] = $tag['value'];
         elseif( $tag['tag'] == 'jsdldatabase:port')
            $jsdl_data['db_port'] = $tag['value'];
         elseif( $tag['tag'] == 'jsdldatabase:database')
            $jsdl_data['db_name'] = $tag['value'];
         elseif( $tag['tag'] == 'jsdldatabase:driverPath')
            $jsdl_data['db_jar_path'] = $tag['value'];
         elseif( $tag['tag'] == 'jsdldatabase:driverClass')
            $jsdl_data['db_jdbc_driver'] = $tag['value'];
         elseif( $tag['tag'] == 'jsdldatabase:connectionUrl')
            $jsdl_data['db_jdbc_string'] = $tag['value'];
         elseif( $tag['tag'] == 'jsdldatabase:statements')
            $jsdl_data['db_query'] = $tag['value'][0]['value'];
         elseif( $tag['tag'] == 'jsdldatabase:credentials') {
            foreach ($tag['value'] as $credential) {
               if($credential['tag'] == 'jsdl:userName')
                  $jsdl_data['user'] = $credential['value'];
               elseif($credential['tag']=='jsdl:password')
                  $jsdl_data['password'] = $credential['value'];
            }
         }
      }
      if(!isset($jsdl_data['db_dbms'])) $jsdl_data['db_dbms'] = 'JDBC';
   }
   // FILETRANSFER
   elseif($task_type == 'FILETRANSFER') {
      if($application[0]['tag']=='jsdlfiletransfer:downloadInfo')
         $jsdl_data['ft_type'] = 'DOWNLOAD';
      elseif($application[0]['tag']=='jsdlfiletransfer:uploadInfo')
         $jsdl_data['ft_type'] = 'UPLOAD';
      $ft = $application[0]['value'];
      foreach ($ft as $param) {
         if($param['tag'] == 'jsdlfiletransfer:server')
            $jsdl_data['ft_server'] = $param['value'];
         elseif($param['tag'] == 'jsdlfiletransfer:localfile')
            $jsdl_data['ft_locfile'] = $param['value'];
         elseif($param['tag'] == 'jsdlfiletransfer:remotefile')
            $jsdl_data['ft_remfile'] = $param['value'];
         elseif($param['tag'] == 'jsdlfiletransfer:protocol')
            $jsdl_data['ft_protocol'] = strtoupper($param['value']);
         elseif($param['tag'] == 'jsdlfiletransfer:transferMode')
            $jsdl_data['ft_mode'] = $param['value'];
         elseif($param['tag'] == 'jsdlfiletransfer:localCredentials'){
            foreach ($param['value'] as $credential) {
               if($credential['tag'] == 'jsdlfiletransfer:username' || $credential['tag'] == 'jsdl:userName')
                  $jsdl_data['loc_user'] = $credential['value'];
               elseif($credential['tag'] == 'jsdlfiletransfer:password' || $credential['tag'] == 'jsdl:password')
                  $jsdl_data['loc_password'] = $credential['value'];
            }
         }
         elseif($param['tag'] == 'jsdlfiletransfer:remoteCredentials'){
            foreach ($param['value'] as $credential) {
               if($credential['tag'] == 'jsdlfiletransfer:username' || $credential['tag'] == 'jsdl:userName')
                  $jsdl_data['rem_user'] = $credential['value'];
               elseif($credential['tag'] == 'jsdlfiletransfer:password' || $credential['tag'] == 'jsdl:password')
                  $jsdl_data['rem_password'] = $credential['value'];
            }
         }
         elseif($param['tag'] == 'jsdlfiletransfer:codepageConversion'){
            foreach ($param['value'] as $codepage) {
               if($codepage['tag'] == 'jsdlfiletransfer:remoteCodepage')
                  $jsdl_data['rem_codepage'] = $codepage['value'];
               elseif($codepage['tag'] == 'jsdlfiletransfer:localCodepage')
                  $jsdl_data['loc_codepage'] = $codepage['value'];
            }
         }
      }
   }
   // XA-JOB
   elseif($task_type == 'XAJOB') {
      foreach($application as $tag) {
         if($tag['tag']=='jsdlxa:taskString')
            $jsdl_data['xa_string'] = $tag['value'];
      }
   }
   // IBM i
   elseif($task_type == 'IBMI') {
      $jsdl_data['ibm_command'] = $application[0]['value'][0]['value'][0]['value'];
   }
   // JCL
   elseif($task_type == 'JCL') {
		// values located at different levels of a nested, multidimensional array
		$jcl = $application[0]['value'];
		$jcl2 = $jcl[0]['value'];
		$jcl3 = $jcl2[0]['value'];
		$jcl4a = $jcl3[0]['tag']; // Type
		$jcl4b = $jcl3[0]['value'];
		$jcl5a = $jcl4b[0]['value']; // Dataset name or JCL definition
		$jcl5b = $jcl4b[1]['value']; // Member name
		if ($jcl4a == 'jsdljcl:byReference') {
			$jsdl_data['jcl_created'] = 'byReference';
			$jsdl_data['jcl_dataset'] = $jcl5a;
			$jsdl_data['jcl_member'] = $jcl5b;
		} else {
			$jsdl_data['jcl_created'] = 'byDefinition';
			$jsdl_data['jcl_definition'] = $jcl5a;
		}
	}

   return $jsdl_data;
}


// Geather job XML definition from fields
function tws_jsdl_geather_string(&$myPost) {

   foreach ($myPost as $key=>$val){
      if (is_array($val))
         $$key = $val;
      else $$key = htmlspecialchars($val);
   }
$cmd = '<?xml version="1.0" encoding="UTF-8"?>'."\n";
switch ($task_type) {
   // EXECUTABLE
   case 'executable':
      $cmd .= '<jsdl:jobDefinition xmlns:jsdl="http://www.ibm.com/xmlns/prod/scheduling/1.0/jsdl" xmlns:jsdle="http://www.ibm.com/xmlns/prod/scheduling/1.0/jsdle" name="executable">'."\n";
      $cmd .= '   <jsdl:application name="executable">'."\n";
      $cmd .= '      <jsdle:executable';
      if($stdin!='' && tws_check_arg($stdin, 'tws_file'))
         $cmd .= ' input="'.$stdin.'"';
      if($stdout!='' && tws_check_arg($stdout, 'tws_file'))
         $cmd .= ' output="'.$stdout.'"';
      if($stderr!='' && tws_check_arg($stderr, 'tws_file'))
         $cmd .= ' error="'.$stderr.'"';
      if(isset($ex_interactive))
         $cmd .= ' interactive="true"';
      if($ex_script!='')
         $cmd .= ' path="'.$ex_script.'"';
      if($ex_directory!='' && tws_check_arg($ex_directory, 'tws_file'))
         $cmd .= ' workingDirectory="'.$ex_directory.'"';
      $cmd .= '>'."\n";
      // Arguments
      if(isset($arguments)) {
         $cmd .= '      <jsdle:arguments>'."\n";
         foreach($arguments as $argument){
            $cmd .= '         <jsdle:value>'.htmlspecialchars($argument).'</jsdle:value>'."\n";
         }
         $cmd .= '      </jsdle:arguments>'."\n";
      }
      // Variables
      if(isset($variables)) {
         $cmd .= '      <jsdle:environment>'."\n";
         foreach($variables as $name=>$val){
            tws_check_arg($name, 'tws_alfanum');
            $cmd .= '         <jsdle:variable name="'.htmlspecialchars($name).'">'.htmlspecialchars($val).'</jsdle:variable>'."\n";
         }
         $cmd .= '      </jsdle:environment>'."\n";
      }
      // Credential
      if($user!='' && tws_check_arg($user, 'tws_user')){
         $cmd .= '      <jsdle:credential>'."\n";
         $cmd .= '         <jsdle:userName>'.$user.'</jsdle:userName>'."\n";
         if($password!='' && tws_check_arg($password, 'tws_passw'))
            $cmd .= '         <jsdle:password>'.$password.'</jsdle:password>'."\n";
         $cmd .= '      </jsdle:credential>'."\n";
      }
      $cmd .= '   </jsdle:executable>'."\n";
      break;
   // FILETRANSFER
   case 'filetransfer':
      $cmd .= '<jsdl:jobDefinition xmlns:jsdl="http://www.ibm.com/xmlns/prod/scheduling/1.0/jsdl" xmlns:jsdlfiletransfer="http://www.ibm.com/xmlns/prod/scheduling/1.0/jsdlfiletransfer" name="FILETRANSFER">'."\n";
      $cmd .= '   <jsdl:application name="filetransfer">'."\n";
      $cmd .= '      <jsdlfiletransfer:filetransfer>'."\n";
      if($ft_type == 'DOWNLOAD')
         $cmd .= '      <jsdlfiletransfer:downloadInfo>'."\n";
      else
         $cmd .= '      <jsdlfiletransfer:uploadInfo>'."\n";
      if ($ft_server!='' && tws_check_arg($ft_server, 'tws_node'))
         $cmd .= '         <jsdlfiletransfer:server>'.$ft_server.'</jsdlfiletransfer:server>'."\n";
      if ($ft_locfile!='' && tws_check_arg($ft_locfile, 'tws_file'))
         $cmd .= '         <jsdlfiletransfer:localfile>'.$ft_locfile.'</jsdlfiletransfer:localfile>'."\n";
      if ($ft_remfile!='' && tws_check_arg($ft_remfile, 'tws_file'))
         $cmd .= '         <jsdlfiletransfer:remotefile>'.$ft_remfile.'</jsdlfiletransfer:remotefile>'."\n";
      if ($loc_user!='' && tws_check_arg($loc_user, 'tws_user')){
         $cmd .= '         <jsdlfiletransfer:localCredentials>'."\n";
         $cmd .= '            <jsdl:userName>'.$loc_user.'</jsdl:userName>'."\n";
         if ($loc_password!='' && tws_check_arg($loc_password, 'tws_passw'))
            $cmd .= '            <jsdl:password>'.$loc_password.'</jsdl:password>'."\n";
         $cmd .= '         </jsdlfiletransfer:localCredentials>'."\n";
      }
      if ($rem_user!='' && tws_check_arg($rem_user, 'tws_user')){
         $cmd .= '         <jsdlfiletransfer:remoteCredentials>'."\n";
         $cmd .= '            <jsdl:userName>'.$rem_user.'</jsdl:userName>'."\n";
         if ($rem_password!='' && tws_check_arg($rem_password, 'tws_passw'))
            $cmd .= '            <jsdl:password>'.$rem_password.'</jsdl:password>'."\n";
         $cmd .= '         </jsdlfiletransfer:remoteCredentials>'."\n";
      }
      if ($ft_protocol!='' && tws_check_arg($ft_protocol, 'tws_name'))
         $cmd .= '         <jsdlfiletransfer:protocol>'.$ft_protocol.'</jsdlfiletransfer:protocol>'."\n";
      if ($ft_mode!='' && tws_check_arg($ft_mode, 'tws_name'))
         $cmd .= '         <jsdlfiletransfer:transferMode>'.$ft_mode.'</jsdlfiletransfer:transferMode>'."\n";
      if (@$rem_codepage!='' && @$loc_codepage!='') {
         $cmd .= '         <jsdlfiletransfer:codepageConversion>'."\n";
         $cmd .= '            <jsdlfiletransfer:remoteCodepage>'.$rem_codepage.'</jsdlfiletransfer:remoteCodepage>'."\n";
         $cmd .= '            <jsdlfiletransfer:localCodepage>'.$loc_codepage.'</jsdlfiletransfer:localCodepage>'."\n";
         $cmd .= '         </jsdlfiletransfer:codepageConversion>'."\n";
      }

      if($ft_type == 'DOWNLOAD')
         $cmd .= '      </jsdlfiletransfer:downloadInfo>'."\n";
      else
         $cmd .= '      </jsdlfiletransfer:uploadInfo>'."\n";
      $cmd .= '      </jsdlfiletransfer:filetransfer>'."\n";
      break;
   // DSHADOW
   case 'distributedShadowJob':
      $cmd .= '<jsdl:jobDefinition xmlns:dshadow="http://www.ibm.com/xmlns/prod/scheduling/1.0/dshadow" xmlns:jsdl="http://www.ibm.com/xmlns/prod/scheduling/1.0/jsdl">'."\n";
      $cmd .= '   <jsdl:application name="distributedShadowJob">'."\n";
      $cmd .= '      <dshadow:DistributedShadowJob>'."\n";
      if ($dshadow_jobstream!='' && tws_check_arg($dshadow_jobstream, 'tws_name'))
         $cmd .= '         <dshadow:JobStream>'.$dshadow_jobstream.'</dshadow:JobStream>'."\n";
      if ($dshadow_workstation!='' && tws_check_arg($dshadow_workstation, 'tws_name'))
         $cmd .= '         <dshadow:Workstation>'.$dshadow_workstation.'</dshadow:Workstation>'."\n";
      if ($dshadow_job!='' && tws_check_arg($dshadow_job, 'tws_name'))
         $cmd .= '         <dshadow:Job>'.$dshadow_job.'</dshadow:Job>'."\n";
      // Matching
      if ($matching!='') {
         $cmd .= '         <dshadow:matching>'."\n";
         if($matching == 'SAMEDAY')
            $cmd .= '            <dshadow:sameDay/>'."\n";
         elseif($matching == 'PREVIOUS')
            $cmd .= '            <dshadow:previous/>'."\n";
         elseif($matching == 'RELATIVE'){
            $from = sprintf('%1s%02d%02d', $relative_from, $relative_fromhour, $relative_frommin);
            $to = sprintf('%1s%02d%02d', $relative_to, $relative_tohour, $relative_tomin);
            $cmd .= '            <dshadow:relative from="'.$from.'" to="'.$to.'"/>'."\n";
         }
         elseif($matching == 'ABSOLUTE'){
            $from = sprintf('%02d%02d %1s%d', $absolute_fromhour, $absolute_frommin, $absolute_from, $absolute_fromdays);
            $to = sprintf('%02d%02d %1s%d', $absolute_tohour, $absolute_tomin, $absolute_to, $absolute_todays);
            $cmd .= '            <dshadow:absolute from="'.$from.'" to="'.$to.'"/>'."\n";
         }
         $cmd .= '         </dshadow:matching>'."\n";
      }
      $cmd .= '      </dshadow:DistributedShadowJob>'."\n";
      break;
   // ZSHADOW
   case 'zShadowJob':
      $cmd .= '<jsdl:jobDefinition xmlns:jsdl="http://www.ibm.com/xmlns/prod/scheduling/1.0/jsdl" xmlns:zshadow="http://www.ibm.com/xmlns/prod/scheduling/1.0/zshadow">'."\n";
      $cmd .= '   <jsdl:application name="zShadowJob">'."\n";
      $cmd .= '   <zshadow:ZShadowJob>'."\n";
      if ($zshadow_jobstream!='' && tws_check_arg($zshadow_jobstream, 'tws_name'))
         $cmd .= '         <zshadow:JobStream>'.$zshadow_jobstream.'</zshadow:JobStream>'."\n";
      if ($zshadow_job!='' && tws_check_arg($zshadow_job, 'tws_num'))
         $cmd .= '         <zshadow:JobNumber>'.$zshadow_job.'</zshadow:JobNumber>'."\n";
      $cmd .= '      <zshadow:matching>'."\n";
      $cmd .= '         <zshadow:previous/>'."\n";
      $cmd .= '      </zshadow:matching>'."\n";
      $cmd .= '   </zshadow:ZShadowJob>'."\n";
      break;
   // DATABASE
   case 'database':
      $cmd .= '<jsdl:jobDefinition xmlns:jsdl="http://www.ibm.com/xmlns/prod/scheduling/1.0/jsdl" xmlns:jsdldatabase="http://www.ibm.com/xmlns/prod/scheduling/1.0/jsdldatabase" name="database">'."\n";
      $cmd .= '   <jsdl:application name="database">'."\n";
      $cmd .= '   <jsdldatabase:database>'."\n";
      $cmd .= '      <jsdldatabase:sqlActionInfo>'."\n";
      if (isset($db_dbms) && $db_dbms != 'JDBC' && tws_check_arg($db_dbms, 'tws_name'))
         $cmd .= '         <jsdldatabase:dbms>'.$db_dbms.'</jsdldatabase:dbms>'."\n";
      if ($db_server!='' && tws_check_arg($db_server, 'tws_node'))
         $cmd .= '         <jsdldatabase:server>'.$db_server.'</jsdldatabase:server>'."\n";
      if ($db_port!='' && tws_check_arg($db_port, 'tws_num'))
         $cmd .= '         <jsdldatabase:port>'.$db_port.'</jsdldatabase:port>'."\n";
      if ($db_name!='' && tws_check_arg($db_name, 'tws_alfanum'))
         $cmd .= '         <jsdldatabase:database>'.$db_name.'</jsdldatabase:database>'."\n";
      if (isset($db_jdbc_driver) && $db_jdbc_driver!='')
         $cmd .= '         <jsdldatabase:driverClass>'.$db_jdbc_driver.'</jsdldatabase:driverClass>'."\n";
      if (isset($db_jdbc_string) && $db_jdbc_string!='')
         $cmd .= '         <jsdldatabase:connectionUrl>'.$db_jdbc_string.'</jsdldatabase:connectionUrl>'."\n";
      if ($db_jar_path!='')
         $cmd .= '         <jsdldatabase:driverPath>'.$db_jar_path.'</jsdldatabase:driverPath>'."\n";
      if ($db_query!='') {
         $cmd .= '         <jsdldatabase:statements>'."\n";
         $cmd .= '         <jsdldatabase:dbStatement type="sql">'.$db_query.'</jsdldatabase:dbStatement>'."\n";
         $cmd .= '         </jsdldatabase:statements>'."\n";
      }
      // Credentials
      if ($user!='' && tws_check_arg($user, 'tws_user')){
         $cmd .= '         <jsdldatabase:credentials>'."\n";
         $cmd .= '            <jsdl:userName>'.$user.'</jsdl:userName>'."\n";
         if ($password!='' && tws_check_arg($password, 'tws_passw'))
            $cmd .= '            <jsdl:password>'.$password.'</jsdl:password>'."\n";
         $cmd .= '         </jsdldatabase:credentials>'."\n";
      }
      $cmd .= '      </jsdldatabase:sqlActionInfo>'."\n";
      $cmd .= '   </jsdldatabase:database>'."\n";
      break;
   // JAVA
   case 'java':
      $cmd .= '<jsdl:jobDefinition xmlns:jsdl="http://www.ibm.com/xmlns/prod/scheduling/1.0/jsdl" xmlns:jsdljava="http://www.ibm.com/xmlns/prod/scheduling/1.0/jsdljava" name="java">'."\n";
      $cmd .= '   <jsdl:application name="java">'."\n";
      $cmd .= '   <jsdljava:java>'."\n";
      $cmd .= '   <jsdljava:javaParms>'."\n";
      if ($java_path!='')
         $cmd .= '      <jsdljava:jarPath>'.$java_path.'</jsdljava:jarPath>'."\n";
      if ($java_class!='')
         $cmd .= '      <jsdljava:className>'.$java_class.'</jsdljava:className>'."\n";
      // variables
      if(isset($variables)) {
         $cmd .= '      <jsdljava:parameters>'."\n";
         foreach($variables as $name=>$val){
             tws_check_arg($name, 'tws_alfanum') &&  tws_check_arg($val, 'tws_alfanum');
            $cmd .= '         <jsdljava:parameter key="'.htmlspecialchars($name).'">'.htmlspecialchars($val).'</jsdljava:parameter>'."\n";
         }
         $cmd .= '      </jsdljava:parameters>'."\n";
      }
      $cmd .= '   </jsdljava:javaParms>'."\n";
      $cmd .= '   </jsdljava:java>'."\n";
      break;
   // J2EE
   case 'j2ee':
      $cmd .= '<jsdl:jobDefinition xmlns:jsdl="http://www.ibm.com/xmlns/prod/scheduling/1.0/jsdl" xmlns:jsdlj="http://www.ibm.com/xmlns/prod/scheduling/1.0/jsdlj" name="j2ee">'."\n";
      $cmd .= '   <jsdl:application name="j2ee">'."\n";
      $cmd .= '   <jsdlj:j2ee>'."\n";
      if(isset($j2ee_operation) && $j2ee_operation=='receive') {
         $cmd .= '   <jsdlj:jms operation="receive"';
         if($j2ee_timeout != '' &&  tws_check_arg($j2ee_timeout, 'tws_num'))
            $cmd .= ' timeout="'.$j2ee_timeout.'"';
         $cmd .= '>';
      }
      else{
         $cmd .= '   <jsdlj:jms operation="send">'."\n";
      }
      if ($j2ee_url!='')
         $cmd .= '      <jsdlj:connectionURL>'.$j2ee_url.'</jsdlj:connectionURL>'."\n";
      if ($j2ee_factory!='')
         $cmd .= '      <jsdlj:connFactory>'.$j2ee_factory.'</jsdlj:connFactory>'."\n";
      if ($j2ee_destination!='')
         $cmd .= '      <jsdlj:destination>'.$j2ee_destination.'</jsdlj:destination>'."\n";
      if (isset($j2ee_message) && $j2ee_message!='')
         $cmd .= '      <jsdlj:message>'.$j2ee_message.'</jsdlj:message>'."\n";
      $cmd .= '   </jsdlj:jms>'."\n";
      // Credential
      if ($user!='' &&  tws_check_arg($user, 'tws_user')){
         $cmd .= '      <jsdlj:credential>'."\n";
         $cmd .= '            <jsdlj:userName>'.$user.'</jsdlj:userName>'."\n";
         if ($password!='' &&  tws_check_arg($password, 'tws_passw'))
            $cmd .= '            <jsdlj:password>'.$password.'</jsdlj:password>'."\n";
         $cmd .= '         </jsdlj:credential>'."\n";
      }
      $cmd .= '   </jsdlj:j2ee>'."\n";
      break;
   // XA Job
   case 'xajob':
      $cmd .= '<jsdl:jobDefinition xmlns:jsdl="http://www.ibm.com/xmlns/prod/scheduling/1.0/jsdl" xmlns:jsdlxa="http://www.ibm.com/xmlns/prod/scheduling/1.0/jsdlxa" name="xajob">'."\n";
      $cmd .= '<jsdl:application name="xajob">'."\n";
      $cmd .= '<jsdlxa:xajob';
      if ($xa_method!='')
         $cmd .= ' accessMethod="'.$xa_method.'"';
      if ($xa_step!='')
         $cmd .= ' step="'.$xa_step.'"';
      if ($xa_target!='')
         $cmd .= ' target="'.$xa_target.'"';
      if ($stdout!='' &&  tws_check_arg($stdout, 'tws_file'))
         $cmd .= ' output="'.$stdout.'"';
      if ($stderr!='' &&  tws_check_arg($stderr, 'tws_file'))
         $cmd .= ' error="'.$stderr.'"';
      $cmd .= '>'."\n";
      if ($xa_string!='')
         $cmd .= '<jsdlxa:taskString>'.$xa_string.'</jsdlxa:taskString>'."\n";
      // Variables
      if(isset($variables)) {
         $cmd .= '      <jsdlxa:environment>'."\n";
         foreach($variables as $name=>$val){
            tws_check_arg($name, 'tws_alfanum') &&  tws_check_arg($val, 'tws_alfanum');
            $cmd .= '         <jsdlxa:variable name="'.htmlspecialchars($name).'">'.htmlspecialchars($val).'</jsdlxa:variable>'."\n";
         }
         $cmd .= '      </jsdlxa:environment>'."\n";
      }
      // Credential
      if ($user!='' &&  tws_check_arg($user, 'tws_user')){
         $cmd .= '      <jsdlxa:credential>'."\n";
         $cmd .= '            <jsdlxa:userName>'.$user.'</jsdlxa:userName>'."\n";
         if ($password!='' &&  tws_check_arg($password, 'tws_passw'))
            $cmd .= '            <jsdlxa:password>'.$password.'</jsdlxa:password>'."\n";
         $cmd .= '         </jsdlxa:credential>'."\n";
      }
      $cmd .= '</jsdlxa:xajob>'."\n";
      break;
   // Web Service Job
   case 'ws':
      $cmd .= '<jsdl:jobDefinition xmlns:jsdl="http://www.ibm.com/xmlns/prod/scheduling/1.0/jsdl" xmlns:jsdlws="http://www.ibm.com/xmlns/prod/scheduling/1.0/jsdlws" name="ws">'."\n";
      $cmd .= '<jsdl:application name="ws">'."\n";
      $cmd .= '<jsdlws:ws>'."\n";
      $cmd .= '<jsdlws:wsToInvoke';
      if ($ws_operation!='')
         $cmd .= ' operation="'.$ws_operation.'"';
      if ($ws_url!='')
         $cmd .= ' wsdlURL="'.$ws_url.'"';
      $cmd .= '>'."\n";
      // Arguments
      if(isset($arguments)) {
         $cmd .= '      <jsdlws:arguments>'."\n";
         foreach($arguments as $argument){
            tws_check_arg($argument, 'tws_alfanum');
            $cmd .= '         <jsdlws:value>'.htmlspecialchars($argument).'</jsdlws:value>'."\n";
         }
         $cmd .= '      </jsdlws:arguments>'."\n";
      }
      // Credentials
      if ($user!='' && tws_check_arg($user, 'tws_user')){
         $cmd .= '      <jsdlws:credentials>'."\n";
         $cmd .= '            <jsdl:userName>'.$user.'</jsdl:userName>'."\n";
         if ($password!='' && tws_check_arg($password, 'tws_passw'))
            $cmd .= '            <jsdl:password>'.$password.'</jsdl:password>'."\n";
         $cmd .= '         </jsdlws:credentials>'."\n";
      }
      $cmd .= '</jsdlws:wsToInvoke>'."\n";
      $cmd .= '</jsdlws:ws>'."\n";
      break;
   // IBM i
   case 'ibmi':
      if (!isset($ibm_command) || $ibm_command=='') break;
      $cmd .= '<jsdl:jobDefinition xmlns:jsdl="http://www.ibm.com/xmlns/prod/scheduling/1.0/jsdl" xmlns:jsdlibmi="http://www.ibm.com/xmlns/prod/scheduling/1.0/jsdlibmi" name="ibmi">'."\n";
      $cmd .= '<jsdl:application name="ibmi">'."\n";
      $cmd .= '<jsdlibmi:ibmi>'."\n";
      $cmd .= '<jsdlibmi:IBMIParameters>'."\n";
      $cmd .= '<jsdlibmi:Task>'."\n";
         $cmd .= '<jsdlibmi:command>'.$ibm_command.'</jsdlibmi:command>'."\n";
      $cmd .= '</jsdlibmi:Task>'."\n";
      $cmd .= '</jsdlibmi:IBMIParameters>'."\n";
      $cmd .= '</jsdlibmi:ibmi>'."\n";
      break;
   // JCL
   case 'jcl':
      $cmd .= '<jsdl:jobDefinition xmlns:jsdl="http://www.ibm.com/xmlns/prod/scheduling/1.0/jsdl" xmlns:jsdljcl="http://www.ibm.com/xmlns/prod/scheduling/1.0/jsdljcl" name="JCL">'."\n";
      $cmd .= '  <jsdl:application name="jcl">'."\n";
      $cmd .= '    <jsdljcl:jcl>'."\n";
      $cmd .= '			<jsdljcl:JCLParameters>'."\n";
      $cmd .= '				<jsdljcl:jcl>'."\n";
      $cmd .= '					<jsdljcl:byRefOrByDef>'."\n";
	  if ($jcl_created == 'byReference') {
		$cmd .= '						<jsdljcl:byReference>'."\n";
		$cmd .= '							<jsdljcl:dataset>'.$jcl_dataset.'</jsdljcl:dataset>'."\n";
		$cmd .= '							<jsdljcl:member>'.$jcl_member.'</jsdljcl:member>'."\n";
		$cmd .= '						</jsdljcl:byReference>'."\n";
	  } else {
		$cmd .= '						<jsdljcl:byDefinition>'."\n";
		$cmd .= '							<jsdljcl:jclDefinition>'.$jcl_definition.'</jsdljcl:jclDefinition>'."\n";
		$cmd .= '						</jsdljcl:byDefinition>'."\n";
	  }
      $cmd .= '					</jsdljcl:byRefOrByDef>'."\n";
      $cmd .= '				</jsdljcl:jcl>'."\n";
      $cmd .= '			</jsdljcl:JCLParameters>'."\n";
      $cmd .= '			<jsdljcl:JOBParameters>'."\n";
      $cmd .= '				<jsdljcl:jobStreamName>${tws.jobstream.name}</jsdljcl:jobStreamName>'."\n";
      $cmd .= '				<jsdljcl:inputArrival>${tws.job.ia}</jsdljcl:inputArrival>'."\n";
      $cmd .= '			</jsdljcl:JOBParameters>'."\n";
      $cmd .= '		</jsdljcl:jcl>'."\n";
      break;
}  // Switch

$cmd .= '   </jsdl:application>
</jsdl:jobDefinition>';
   return $cmd;
}


/// Get SAP job defintion data
/// The output structure should correspond to the add/copy/modify form
function tws_get_job_sap_data ($task_string) {

   $script = $task_string;
   if($script[0] == '/') $script = substr($script,1);
   $script = trim($script);
   // extract parameters from $script string
   $params = tws_sap_getopt($script);

   foreach($params as $key=>$val) {
      switch ($key) {
         case'command' :
            $jsdl_data['r3job_cmd'] = $val;
            break;
         case'job' : $jsdl_data['r3job_name'] = $val;
            break;
         case'user' : $jsdl_data['r3job_user'] = $val;
            break;
         case'i' :
            if($val == 'pchain_')
               $jsdl_data['r3job_type'] = 'bwpc';
            elseif ($val == 'ipak_')
               $jsdl_data['r3job_type'] = 'bwip';
            else {
               $jsdl_data['r3job_type'] = 'std';
               $jsdl_data['r3job_id'] = $val;
            }
            break;
         case'c' : $jsdl_data['r3job_class'] = strtoupper($val);
            break;
         case'nobdcwait' : $jsdl_data['r3job_diswa'] = 'yes';
            break;
         case'debug' : $jsdl_data['r3job_debug'] = 'yes';
            break;
         case'trace' : $jsdl_data['r3job_trace'] = 'yes';
            break;
         case'imm':
            $jsdl_data['r3job_immed'] = 'yes';
            break;
         case'ENABLE_JOBLOG':
            $jsdl_data['r3job_log'] = 'ON';
            break;
         case'DISABLE_JOBLOG':
            $jsdl_data['r3job_log'] = 'OFF';
            break;
         case'ENABLE_SPOOLLIST':
            $jsdl_data['r3job_spool'] = 'ON';
            break;
         case'DISABLE_SPOOLLIST':
            $jsdl_data['r3job_spool'] = 'OFF';
            break;
         case'ENABLE_PCHAINLOG':
            $jsdl_data['r3job_chlog'] = 'ON';
            break;
         case'DISABLE_PCHAINLOG':
            $jsdl_data['r3job_chlog'] = 'OFF';
            break;
      }
   }
   if(!isset($jsdl_data['r3job_type'])) $jsdl_data['r3job_type'] = 'std';
   return $jsdl_data;
}

// Extract SAP options from command string
// called from tws_get_job_sap_data()
function tws_sap_getopt ($str) {
   $options = array();
   if(preg_match('/-nobdcwait/', $str)) {
      $options['nobdcwait'] = '';
      $str = preg_replace('/-nobdcwait/', '', $str);
   }
   if(preg_match('/-debug/', $str)) {
      $options['debug'] = '';
      $str = preg_replace('/-debug/', '', $str);
   }
   if(preg_match('/-trace/', $str)) {
      $options['trace'] = '';
      $str = preg_replace('/-trace/', '', $str);
   }
   if(preg_match('/-job (\S+)/', $str, $r)) {
      $options['job'] = $r[1];
      $str = preg_replace('/-job \S+/', '', $str);
   }
   if(preg_match('/-user (\S+)/', $str, $r)) {
      $options['user'] = $r[1];
      $str = preg_replace('/-user \S+/', '', $str);
   }
   if(preg_match('/-i (\S+)/', $str, $r)) {
      $options['i'] = $r[1];
      $str = preg_replace('/-i \S+/', '', $str);
   }
   if(preg_match('/-c (\S+)/', $str, $r)) {
      $options['c'] = $r[1];
      $str = preg_replace('/-c \S+/', '', $str);
   }
/*
 * The flag parameter has been incorrectly processed, see ERR16058.
 * Commenting this code out causes adding the -flag parameter  at the and of the SAP command line
 * without any special processing.
 *
   if(preg_match_all('/-flag (\S+)/', $str, $r)) {
      foreach($r[1] as $option)
         $options[$option] = '';
      $str = preg_replace('/-flag \S+/', '', $str);
   }
*/
   $str = trim($str);
   if ($str != '')
      $options['command'] = $str;
   return $options;
}


// Geather SAP job definition from fields
function tws_sap_geather_string(&$myPost) {
   /*
    * Adding the leading slash character has been removed within ERR16058
    * Reason: It has been found as useles in 2016-06
    * Note: the blank before the "-job" parameter has beer removed too!
    *
    *  $cmd = '/';
    */
   $cmd='';
   if($myPost['r3job_name']!='') // && tws_check_arg($myPost['r3job_name'], 'tws_alfanum')
      $cmd .= ' -job '.$myPost['r3job_name'];
   // std job
   if($myPost['r3job_type'] == 'std') {
      if($myPost['r3job_user']!='') // && tws_check_arg($myPost['r3job_user'], 'tws_user')
         $cmd .= ' -user '.$myPost['r3job_user'];
      if($myPost['r3job_id']!='')
         $cmd .= ' -i '.$myPost['r3job_id'];
      if($myPost['r3job_class']!='' && tws_check_arg($myPost['r3job_class'], 'tws_name'))
         $cmd .= ' -c '.$myPost['r3job_class'];
      if(isset($myPost['r3job_diswa']))
         $cmd .= ' -nobdcwait';
      if(isset($myPost['r3job_immed']))
         $cmd .= ' -flag imm';
      if($myPost['r3job_log'] == 'ON')
         $cmd .= ' -flag ENABLE_JOBLOG';
      elseif($myPost['r3job_log'] == 'OFF')
         $cmd .= ' -flag DISABLE_JOBLOG';
      if($myPost['r3job_spool'] == 'ON')
         $cmd .= ' -flag ENABLE_SPOOLLIST';
      elseif($myPost['r3job_spool'] == 'OFF')
         $cmd .= ' -flag DISABLE_SPOOLLIST';
   } // bwpc job
   elseif ($myPost['r3job_type'] == 'bwpc') {
      $cmd .= ' -i pchain_';
      if($myPost['r3job_chlog'] == 'ON')
         $cmd .= ' -flag ENABLE_PCHAINLOG';
      elseif($myPost['r3job_chlog'] == 'OFF')
         $cmd .= ' -flag DISABLE_PCHAINLOG';
   }
   else
      $cmd .= ' -i ipak_';

   if(isset($myPost['r3job_debug']))
      $cmd .= ' -debug';
   if(isset($myPost['r3job_trace']))
      $cmd .= ' -trace';
   if($myPost['r3job_cmd']!='')
      $cmd .= ' '.$myPost['r3job_cmd'];

   return $cmd;
}

///
/// Jobs report handler (used at IWS Database Report page)
/// \param sel SELECT attributes
/// \param crit items used to build WHERE clause
/// \param ord items used to build ORDER BY clause
/// \param pri items used to sort ORDER BY items
/// \param query (output parameter) resultant sql query string
/// \param dbds (output parameter) database descriptor name
/// \param mode controls the output mode (FETCH_ALL=all results returned in an in array, INIT=initialize the data stream, then fetching data by calling without parameters)
/// \return resultant fetched rows of the created query or the column name map if sel===null
function tws_jobs_report($sel=array(), $crit=array(), $ord=array(), $pri=array(), &$query='', &$dbds='', $mode='FETCH_ALL') {
   global $tws_config, $composer_db, $tws_types;
   static $db_cache=NULL, $sel_cache=NULL;

   if (func_num_args()==0) { //fetching data after a previous calling with mode='INIT'
      if ($db_cache===NULL || $sel_cache===NULL) {
         tws_error('Data fetch error', 'Not initialized data stream');
         return FALSE;
      }
      $sel=$sel_cache;
      $db=$db_cache;
      $mode='ROW'; //just internal flag, anything besides 'FETCH_ALL' has the same effect
   } else {
      $dbds='composer_db';
      $colmap = array();
         $colmap['WKC.WKC_NAME WORKSTATION']                ='Workstation';
         if($tws_config['cpuinfo']['version']>='9.5')
            $colmap['FOL_PATH']                    = 'Job Folder';
         $colmap['JOD.JOD_NAME NAME']                       = 'Job';
         $colmap['JOD.JOD_DESCRIPTION DESCRIPTION']         ='Description';
         $colmap['JOD.JOD_USER_LOGIN LOGON']                = 'Logon';
         $colmap['JOD.JOD_TASK_TYPE TASK_TYPE']             = 'Task Type';
         $colmap['JOD.JOD_COMMAND JOB_COMMAND']             = 'Command';
         $colmap['JOD.JOD_TASK_STRING SCRIPT']              = 'Script';
         $colmap['JOD.JOD_RETURN_CODE_MAPPING EXITCODEMAP'] = 'Exit Code Map';
         $colmap['REC_WKC.WKC_NAME RECOVERY_WORKSTATION']   = 'Recovery Workstation';
         $colmap['REC_JOD.JOD_NAME RECOVERY_JOB']           = 'Recovery Job';
         $colmap['JOD.JOD_RECOVERY_OPTION RECOVERY_OPTION'] = 'Recovery Option';
         $colmap['RES.RES_TEXT RECOVERY_PROMPT']            = 'Recovery Prompt';
         $colmap['JOS.JOS_ABORTED_RUNS NUM_ABEND']          = 'Num Abend';
         $colmap['JOS.JOS_SUCCESSFUL_RUNS NUM_SUCC']        = 'Num Succ';
         $colmap['JOS.JOS_LAST_RUN_DATE LAST_RUN']          = 'Last Run';
         $colmap['JOS.JOS_LAST_ELAPSED_TIME LAST_ELAPSE']   = 'Last Elapse';
         $colmap['JOS.JOS_MIN_ELAPSED_TIME MIN_ELAPSE']     = 'Min Elapse';
         $colmap['JOS.JOS_MAX_ELAPSED_TIME MAX_ELAPSE']     = 'Max Elapse';
         $colmap['JOS.JOS_LAST_CPU_TIME LAST_CPU']          = 'Last CPU';
         $colmap['JOS.JOS_MIN_CPU_TIME MIN_CPU']            = 'Min CPU';
         $colmap['JOS.JOS_MAX_CPU_TIME MAX_CPU']            = 'Max CPU';
         $colmap['JOS.JOS_TOTAL_ELAPSED_TIME TOTAL_ELAPSE'] = 'Total Elapse';
         $colmap['JOS.JOS_TOTAL_CPU_TIME TOTAL_CPU']        = 'Total CPU';

      if ($sel===null) return $colmap;
      $schema=$composer_db['schema'];
      $from="(((((
               $schema.JOD_JOB_DEFINITIONS JOD
               LEFT JOIN $schema.JOS_JOB_STATISTICS JOS ON JOS.JOD_ID = JOD.JOD_ID )
               LEFT JOIN $schema.WKC_WORKSTATION_CLASSES WKC ON WKC.WKC_ID = JOD.WKC_ID )
               LEFT JOIN $schema.JOD_JOB_DEFINITIONS REC_JOD ON JOD.JOD_RECOVERY_ID = REC_JOD.JOD_ID)
               LEFT JOIN $schema.WKC_WORKSTATION_CLASSES REC_WKC ON REC_JOD.WKC_ID=REC_WKC.WKC_ID)
               LEFT JOIN $schema.RES_ABSTRACT_RESOURCES RES ON RES.RES_ID=JOD.RES_ID)";
      if($tws_config['cpuinfo']['version']>='9.5')
         $from .=
         "LEFT JOIN $schema.FOL_FOLDERS FOL ON FOL.FOL_ID = JOD.FOL_ID";
      $crit['WKC.WKC_NAME WORKSTATION']=strtoupper($crit['WKC.WKC_NAME WORKSTATION']);
      if($tws_config['cpuinfo']['version']>='9.5')
         $crit['FOL_PATH']=strtoupper($crit['FOL_PATH']);
      $crit['JOD.JOD_NAME NAME']=strtoupper($crit['JOD.JOD_NAME NAME']);
      $crit['JOD.JOD_TASK_TYPE TASK_TYPE']=strtoupper($crit['JOD.JOD_TASK_TYPE TASK_TYPE']);
      $crit['REC_WKC.WKC_NAME RECOVERY_WORKSTATION']=strtoupper($crit['REC_WKC.WKC_NAME RECOVERY_WORKSTATION']);
      $crit['REC_JOD.JOD_NAME RECOVERY_JOB']=strtoupper($crit['REC_JOD.JOD_NAME RECOVERY_JOB']);
      $crit['JOD.JOD_RECOVERY_OPTION RECOVERY_OPTION']=strtoupper($crit['JOD.JOD_RECOVERY_OPTION RECOVERY_OPTION']);
      // execute the report query
      if (($db=tws_report_query($$dbds,$from,$sel,$crit,$ord,$pri,$query))===FALSE) return FALSE; //database query failed
      if ($mode=='FETCH_ALL') {
         //initialize the output structure
         $rows=array();
      } else {
         //initialize the cache
         $sel_cache=$sel;
         $db_cache=$db;
         return $db;
      }
   }
   //fetch query rows
   while ($row=db_fetch_row($db)) {
      if (array_key_exists('JOS.JOS_LAST_RUN_DATE LAST_RUN',$sel)) $row['LAST_RUN']=tws_iso_to_userdate($row['LAST_RUN'], null, FALSE, $composer_db['tz']);
      if (array_key_exists('JOS.JOS_LAST_ELAPSED_TIME LAST_ELAPSE',$sel)) $row['LAST_ELAPSE']=tws_get_at_time($row['LAST_ELAPSE'], $h,$m,$s,$d, 'DAY_OFFSET');
      if (array_key_exists('JOS.JOS_MIN_ELAPSED_TIME MIN_ELAPSE',$sel)) $row['MIN_ELAPSE']=tws_get_at_time($row['MIN_ELAPSE'], $h,$m,$s,$d, 'DAY_OFFSET');
      if (array_key_exists('JOS.JOS_MAX_ELAPSED_TIME MAX_ELAPSE',$sel)) $row['MAX_ELAPSE']=tws_get_at_time($row['MAX_ELAPSE'], $h,$m,$s,$d, 'DAY_OFFSET');
      if (array_key_exists('JOS.JOS_TOTAL_ELAPSED_TIME TOTAL_ELAPSE',$sel)) $row['TOTAL_ELAPSE']=tws_get_at_time($row['TOTAL_ELAPSE'], $h,$m,$s,$d, 'DAY_OFFSET');
      if ($mode=='FETCH_ALL') $rows[]=$row;
      else return $row;
   }
   if ($mode=='FETCH_ALL') return $rows;
   //reset the cache
   $db_cache=$sel_cache=NULL;
   return 0;
}


///////////////////////////////////////////////////////////////////////////////
//
// List of calendars
//
// Arguments:
//    calendar = calendar name (@=wildcard for all)
//    sqlcond = sql filter - conditions of the where clause
//
function tws_get_calendars( $calendar='@', $sqlfilter='1=1', $page_size = 0, $page = 1, $od_callback=null, $action='LIST') {
   tws_log('-- get_db_calendars_list (start at '.basename(__FILE__).'['.__LINE__.'])');
   global $tws_config, $composer_db;

   $calendars=array();
   $calendars['calendar_num']=0;

   $tmp = tws_divide_folder($calendar);
   $calendar = $tmp[1];
   $cal_folder  = $tmp[0];

//access rights checking
   if (($acc_sql=tws_sec_check('CALENDAR', array('CPU'=>'WKC_NAME','NAME'=>'CAL_NAME'), '', $action))===FALSE) return $calendars;

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=$composer_db["schema"];
   $query ="
      SELECT
         CAL_ID ,
         CAL_NAME ,
         CAL_DESCRIPTION ,
         CAL_ICALENDAR,
         CAL_MODIFY_OWNER ,
         CAL_MODIFY_TIME ,
         CAL_LOCK_OWNER ,
         CAL_LOCK_TIME";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= ",
            FOL.FOL_PATH";
      $query .= "
      FROM $schema.CAL_CALENDARS";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
            LEFT JOIN $schema.FOL_FOLDERS FOL ON FOL.FOL_ID = $schema.CAL_CALENDARS.FOL_ID";
      $query .= "
      WHERE
         CAL_NAME ".tws_sqllike(db_string($composer_db,$calendar))." ";
      if ($tws_config['cpuinfo']['version']>='9.5002' && !empty($cal_folder))
          $query .= "  AND FOL.FOL_PATH = '$cal_folder'";
      $query .=" AND $sqlfilter
         $acc_sql
      ";             //  TODO: WHERE folder

   tws_log('DB query: '.$query);
   if( !($r=db_query($composer_db,$query)) ){
      tws_log('Error: Database query failed');
      tws_error('', 'Database query failed');
      return FALSE;
   }
   $tl=tws_log();
   if ($page_size > 0) {
      $page_down = ($page - 1) * $page_size;
      $page_up = $page * $page_size;
   }
   while ($row = db_fetch_row($composer_db)) {
      $tl && tws_log(@var_export($row, true));
      $calendars['calendar_num']++;
      if ($page_size > 0) {
         if ($page_down >= $calendars['calendar_num']) {
            while (($page_down > $calendars['calendar_num']) && db_fetch_row($composer_db, null)) {
               $calendars['calendar_num']++;
            }
            continue;
         }
         if ($page_up < $calendars['calendar_num']) {
            while (($page_up < $calendars['calendar_num']) && db_fetch_row($composer_db, null)) {
               $calendars['calendar_num']++;
            }
            break;
         }
      }
      $calendars['calendar_id'          ][] = $row['CAL_ID'];
      $calendars['calendar_name'        ][] = $row['CAL_NAME'];
      $calendars['calendar_description' ][] = $row['CAL_DESCRIPTION'];
      $calendars['calendar_dates'       ][] = $row['CAL_ICALENDAR'];
      $calendars['calendar_creator'     ][] = $row['CAL_MODIFY_OWNER'];
      $calendars['calendar_last_updated'][] = $row['CAL_MODIFY_TIME'];
      $calendars['calendar_lock_by'     ][] = $row['CAL_LOCK_OWNER'];
      $calendars['calendar_lock_on'     ][] = $row['CAL_LOCK_TIME'];
      if ($tws_config['cpuinfo']['version']>='9.5002'){
         if(empty($row['FOL_PATH']))
            $row['FOL_PATH'] = '/';
         $calendars['calendar_folder'   ][] = $row['FOL_PATH'];
      }
   }
   tws_log('-- get_db_calendars_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
   if (defined('IWD_PROCMAN')) return $calendars; //procman::db_functions::db_fetch_row returns FALSE if there are no rows left
   return ($row===FALSE ? FALSE : $calendars);
}

///
/// Calendars report handler (used at IWS Database Report page)
/// \param sel SELECT attributes
/// \param crit items used to build WHERE clause
/// \param ord items used to build ORDER BY clause
/// \param pri items used to sort ORDER BY items
/// \param query (output parameter) resultant sql query string
/// \param dbds (output parameter) database descriptor name
/// \param mode controls the output mode (FETCH_ALL=all results returned in an in array, INIT=initialize the data stream, then fetching data by calling without parameters)
/// \return resultant fetched rows of the created query or the column name map if sel===null
function tws_calendars_report($sel=array(), $crit=array(), $ord=array(), $pri=array(), &$query='', &$dbds='', $mode='FETCH_ALL') {
   global $tws_config, $composer_db, $tws_types;
   static $db_cache=NULL, $sel_cache=NULL;

   if (func_num_args()==0) { //fetching data after a previous calling with mode='INIT'
      if ($db_cache===NULL || $sel_cache===NULL) {
         tws_error('Data fetch error', 'Not initialized data stream');
         return FALSE;
      }
      $sel=$sel_cache;
      $db=$db_cache;
      $mode='ROW'; //just internal flag, anything besides 'FETCH_ALL' has the same effect
   } else {
      $dbds='composer_db';
      $colmap = array (
         'CAL_NAME'        => 'Calendar',
         'CAL_DESCRIPTION' => 'Description',
         'CAL_ICALENDAR'   => 'Calendar Dates'
      );
      if ($sel===null) return $colmap;
      $schema=$composer_db['schema'];
      $from="$schema.CAL_CALENDARS";
      $crit['CAL_NAME']=strtoupper($crit['CAL_NAME']);
      // execute the report query
      if (($db=tws_report_query($$dbds,$from,$sel,$crit,$ord,$pri,$query))===FALSE) return FALSE; //database query failed
      if ($mode=='FETCH_ALL') {
         //initialize the output structure
         $rows=array();
      } else {
         //initialize the cache
         $sel_cache=$sel;
         $db_cache=$db;
         return $db;
      }
   }
   //fetch query rows
   while ($row=db_fetch_row($db)) {
      if (array_key_exists('CAL_ICALENDAR',$sel) && ($idates=explode(',',$row['CAL_ICALENDAR'])) ) {
         $dates=array();
         foreach ($idates as $idate) {
            $dates[]=tws_iso_to_userdate(preg_replace('/(\d{4})(\d{2})(\d{2})/','${1}-${2}-${3}',$idate),null,TRUE);
         }
         $row['CAL_ICALENDAR']=implode(', ',$dates);
      }
      if ($mode=='FETCH_ALL') $rows[]=$row;
      else return $row;
   }
   if ($mode=='FETCH_ALL') return $rows;
   //reset the cache
   $db_cache=$sel_cache=NULL;
   return 0;
}


///////////////////////////////////////////////////////////////////////////////
//
// List of domains
//
// Arguments:
//    domain = domain name (@=wildcard for all)
//    sqlcond = sql filter - conditions of the where clause
//
function tws_get_domains($domain='@', $sqlfilter='1=1', $page_size = 0, $page = 1, $od_callback=null, $action='LIST') {
   tws_log('-- get_db_domains_list (start at '.basename(__FILE__).'['.__LINE__.'])');
   global $tws_config, $composer_db;

   $domains=array();
   $domains['domain_num']=0;

//access rights checking
   //CPU.TYPE has no meaning in the context of workstation domains
   if (($acc_sql=tws_sec_check('CPU', array('CPU'=>'DOM1.DOM_NAME', 'TYPE'=>''), '', $action))===FALSE) return $domains;

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=$composer_db["schema"];
   $query ="
      SELECT
         DOM1.DOM_ID ,
         DOM1.DOM_NAME NAME,
         DOM1.DOM_DESCRIPTION,
         DOM2.DOM_NAME PARENT,
         WKS_NAME MANAGER,
         DOM1.DOM_MODIFY_OWNER ,
         DOM1.DOM_MODIFY_TIME ,
         DOM1.DOM_LOCK_OWNER ,
         DOM1.DOM_LOCK_TIME
      FROM ((      $schema.DOM_DOMAINS DOM1
         left join $schema.DOM_DOMAINS DOM2
         on DOM2.DOM_ID = DOM1.DOM_PARENT_ID )
         left join $schema.WKS_WORKSTATIONS WKS
         on (DOM1.DOM_ID = WKS.DOM_ID AND (WKS.WKS_AGENT_TYPE='M' OR (WKS.WKS_AGENT_TYPE IS NULL))))
      WHERE
         DOM1.DOM_NAME ".tws_sqllike(db_string($composer_db,$domain))." AND
         $sqlfilter
         $acc_sql
      ORDER BY DOM1.DOM_NAME
      ";
   tws_log('DB query: '.$query);
   if (!($r=db_query($composer_db,$query))) {
      tws_log('Error: Database query failed');
      tws_error('', 'Database query failed');
      return FALSE;
   }
   $tl=tws_log();
   if ($page_size > 0) {
      $page_down = ($page - 1) * $page_size;
      $page_up = $page * $page_size;
   }
   while ($row = db_fetch_row($composer_db)) {
      $tl && tws_log(@var_export($row, true));
      $domains['domain_num']++;
      if ($page_size > 0) {
         if ($page_down >= $domains['domain_num']) {
            while (($page_down > $domains['domain_num']) && db_fetch_row($composer_db, null)) {
               $domains['domain_num']++;
            }
            continue;
         }
         if ($page_up < $domains['domain_num']) {
            while (($page_up < $domains['domain_num']) && db_fetch_row($composer_db, null)) {
               $domains['domain_num']++;
            }
            break;
         }
      }
      $domains['domain_id'          ][] = $row['DOM_ID'];
      $domains['domain_name'        ][] = $row['NAME'];
      $domains['domain_description' ][] = $row['DOM_DESCRIPTION'];
      $domains['domain_parent'      ][] = $row['PARENT'];
      $domains['domain_manager'     ][] = $row['MANAGER'];
      $domains['domain_creator'     ][] = $row['DOM_MODIFY_OWNER'];
      $domains['domain_last_updated'][] = $row['DOM_MODIFY_TIME'];
      $domains['domain_lock_by'     ][] = $row['DOM_LOCK_OWNER'];
      $domains['domain_lock_on'     ][] = $row['DOM_LOCK_TIME'];
   }
   tws_log('-- get_db_domains_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
   if (defined('IWD_PROCMAN')) return $domains; //procman::db_functions::db_fetch_row returns FALSE if there are no rows left
   return ($row===FALSE ? FALSE : $domains);
}

///
/// Domains report handler (used at IWS Database Report page)
/// \param sel SELECT attributes
/// \param crit items used to build WHERE clause
/// \param ord items used to build ORDER BY clause
/// \param pri items used to sort ORDER BY items
/// \param query (output parameter) resultant sql query string
/// \param dbds (output parameter) database descriptor name
/// \param mode controls the output mode (FETCH_ALL=all results returned in an in array, INIT=initialize the data stream, then fetching data by calling without parameters)
/// \return resultant fetched rows of the created query or the column name map if sel===null
function tws_domains_report($sel=array(), $crit=array(), $ord=array(), $pri=array(), &$query='', &$dbds='', $mode='FETCH_ALL') {
   global $tws_config, $composer_db, $tws_types;
   static $db_cache=NULL, $sel_cache=NULL;

   if (func_num_args()==0) { //fetching data after a previous calling with mode='INIT'
      if ($db_cache===NULL || $sel_cache===NULL) {
         tws_error('Data fetch error', 'Not initialized data stream');
         return FALSE;
      }
      $sel=$sel_cache;
      $db=$db_cache;
      $mode='ROW'; //just internal flag, anything besides 'FETCH_ALL' has the same effect
   } else {
      $dbds='composer_db';
      $colmap = array (
         'DOM1.DOM_NAME NAME'    => 'Domain',
         'DOM1.DOM_DESCRIPTION'  => 'Description',
         'WKS_NAME MANAGER'      => 'Manager',
         'DOM2.DOM_NAME PARENT'  => 'Parent'
      );
      if ($sel===null) return $colmap;
      $schema=$composer_db['schema'];
      $crit['DOM1.DOM_NAME NAME']=strtoupper($crit['DOM1.DOM_NAME NAME']);
      $crit['WKS_NAME MANAGER']=strtoupper($crit['WKS_NAME MANAGER']);
      $crit['DOM2.DOM_NAME PARENT']=strtoupper($crit['DOM2.DOM_NAME PARENT']);
      $from="((
               $schema.DOM_DOMAINS DOM1 LEFT JOIN
               $schema.DOM_DOMAINS DOM2 ON DOM2.DOM_ID = DOM1.DOM_PARENT_ID ) LEFT JOIN
               $schema.WKS_WORKSTATIONS WKS ON (DOM1.DOM_ID = WKS.DOM_ID AND (WKS.WKS_AGENT_TYPE='M' OR (WKS.WKS_AGENT_TYPE IS NULL))))";
      // execute the report query
      if (($db=tws_report_query($$dbds,$from,$sel,$crit,$ord,$pri,$query))===FALSE) return FALSE; //database query failed
      if ($mode=='FETCH_ALL') {
         //initialize the output structure
         $rows=array();
      } else {
         //initialize the cache
         $sel_cache=$sel;
         $db_cache=$db;
         return $db;
      }
   }
   //fetch query rows
   while ($row=db_fetch_row($db)) {
      if ($mode=='FETCH_ALL') $rows[]=$row;
      else return $row;
   }
   if ($mode=='FETCH_ALL') return $rows;
   //reset the cache
   $db_cache=$sel_cache=NULL;
   return 0;
}


///////////////////////////////////////////////////////////////////////////////
//
// List of workstation_classes
//
// Arguments:
//    workstation_class = workstation_class name (@=wildcard for all)
//    sqlcond = sql filter - conditions of the where clause
//
function tws_get_workstation_classes($workstation_class='@', $sqlfilter='', $page_size = 0, $page = 1, $od_callback=null, $action='LIST') {
   global $tws_config, $composer_db;

   tws_log('-- get_db_workstation_classes_list (start at '.basename(__FILE__).'['.__LINE__.'])');
   tws_log("Parameter: workstation_class = $workstation_class");
   list($workstation_class_folder, $workstation_class) = tws_divide_folder($workstation_class);
   if(empty($workstation_class_folder) ) $workstation_class_folder = '@';
   tws_log("workstation_class_folder = $workstation_class_folder, workstation_class = $workstation_class");

   if ($sqlfilter=='') $sqlfilter='1=1';
   $workstation_classes=array();
   $workstation_classes['workstation_class_num']=0;

//access rights checking
   //CPU.TYPE has no meaning in the context of workstation classes
   if (($acc_sql=tws_sec_check('CPU', array('CPU'=>'WKC_NAME', 'TYPE'=>''), '', $action))===FALSE) return $workstation_classes;

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=$composer_db["schema"];
   $query ="
      SELECT
         WKC_ID ,
         WKC_NAME ,
         WKC_DESCRIPTION ,
         WKC_INCLUDE_IN_PLAN ,
         WKC_MODIFY_OWNER ,
         WKC_MODIFY_TIME ,
         WKC_LOCK_OWNER ,
         WKC_LOCK_TIME";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= ",
            FOL.FOL_PATH
            ";
      $query .= "
      FROM
         $schema.WKC_WORKSTATION_CLASSES";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
            LEFT JOIN $schema.FOL_FOLDERS FOL ON FOL.FOL_ID = $schema.WKC_WORKSTATION_CLASSES.FOL_ID";
      $query .= "
      WHERE
         WKC_TYPE = 'C' AND
         WKC_NAME ".tws_sqllike(db_string($composer_db,$workstation_class))." AND";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
            FOL_PATH ".tws_sqllike(db_string($composer_db, $workstation_class_folder))." AND";
         $query .= "
            $sqlfilter
         $acc_sql
      ";
   tws_log('-- get_db_workstation_classes_list -- DB query: '.$query);
   if( !($r=db_query($composer_db,$query)) ){
      tws_log('Error: Database query failed');
      tws_error('', 'Database query failed');
      return FALSE;
   }
   $tl=tws_log();
   if ($page_size > 0) {
      $page_down = ($page - 1) * $page_size;
      $page_up = $page * $page_size;
   }
   while ($row = db_fetch_row($composer_db)) {
//      tws_log("row = ".var_export($row, true));
      $workstation_classes['workstation_class_num']++;
      if ($page_size > 0) {
         if ($page_down >= $workstation_classes['workstation_class_num']) {
            while (($page_down > $workstation_classes['workstation_class_num']) && db_fetch_row($composer_db, null)) {
               $workstation_classes['workstation_class_num']++;
            }
            continue;
         }
         if ($page_up < $workstation_classes['workstation_class_num']) {
            while (($page_up < $workstation_classes['workstation_class_num']) && db_fetch_row($composer_db, null)) {
               $workstation_classes['workstation_class_num']++;
            }
            break;
         }
      }
      $workstation_classes['workstation_class_id'          ][] = $row['WKC_ID'];
      $workstation_classes['workstation_class_name'        ][] = $row['WKC_NAME'];
      $workstation_classes['workstation_class_description' ][] = $row['WKC_DESCRIPTION'];
      $workstation_classes['workstation_class_ignore'      ][] = tws_yesno(tws_neg(@$row['WKC_INCLUDE_IN_PLAN']));
      $workstation_classes['workstation_class_creator'     ][] = $row['WKC_MODIFY_OWNER'];
      $workstation_classes['workstation_class_last_updated'][] = $row['WKC_MODIFY_TIME'];
      $workstation_classes['workstation_class_lock_by'     ][] = $row['WKC_LOCK_OWNER'];
      $workstation_classes['workstation_class_lock_on'     ][] = $row['WKC_LOCK_TIME'];
      if ($tws_config['cpuinfo']['version']>='9.5002'){
         if(empty($row['FOL_PATH']))
            $row['FOL_PATH'] = '/';
         $workstation_classes['workstation_class_folder'   ][] = $row['FOL_PATH'];
      }
   }
   tws_log("-- get_db_workstation_classes_list --  workstation_classes: ". var_export($workstation_classes, true));
   tws_log('-- get_db_workstation_classes_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
   if (defined('IWD_PROCMAN')) return $workstation_classes; //procman::db_functions::db_fetch_row returns FALSE if there are no rows left
   return ($row===FALSE ? FALSE : $workstation_classes);
}

///////////////////////////////////////////////////////////////////////////////
//
// List of workstation_class Members
//
// Arguments:
//    class = workstation_class name (@=wildcard for all)
//    sqlcond = sql filter - conditions of the where clause
//
//    returns array of pairs (class + workstation)
//
function tws_get_class_members($class, $sql_filter="1=1") {
   global $tws_config, $composer_db;

   tws_log(" -- tws_get_class_members parameters: class = $class, sql_filter = $sql_filter");
   list($wkc_folder, $wkc_name) = tws_divide_folder($class);

//   if ($tws_config['cpuinfo']['version']>='9.5002'){
//   }
   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=$composer_db["schema"];
   $query="SELECT
            WKC.WKC_NAME CLASS_NAME,
            WKS.WKC_NAME WORKSTATION";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= ",
            WKC_FOL.FOL_PATH WKC_FOL_PATH,
            WKS_FOL.FOL_PATH WKS_FOL_PATH
            ";
      $query .= "
         FROM (( $schema.WKC_WORKSTATION_CLASSES WKC
            JOIN $schema.WAS_WORKSTATION_ASSOCIATIONS WAS ON WAS.WKC_ID = WKC.WKC_ID )
            JOIN $schema.WKC_WORKSTATION_CLASSES WKS ON WKS.WKC_ID = WAS.WKC_WORKSTATION_ID )";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
            LEFT JOIN $schema.FOL_FOLDERS WKC_FOL ON WKC_FOL.FOL_ID = WKC.FOL_ID
            LEFT JOIN $schema.FOL_FOLDERS WKS_FOL ON WKS_FOL.FOL_ID = WKS.FOL_ID
         ";
      $query .= "
         WHERE
            WKC.WKC_NAME ".tws_sqllike(db_string($composer_db, $wkc_name))." AND
            $sql_filter";
      if(!empty($wkc_folder))
         $query .= "
            AND WKC_FOL.FOL_PATH = '".db_string($composer_db, $wkc_folder)."'";
   tws_log(" -- tws_get_class_members query: $query");


   if( !($r=db_query($composer_db,$query)) ){
      tws_error('', 'Database query failed');
      return FALSE;
   }
   $members=array();
   $i=0;
   while($row=db_fetch_row($composer_db)){
      if(!empty($row['WKC_FOL_PATH']))

      $members['class_name'      ][$i]=$row['CLASS_NAME'];
      $members['workstation_name'][$i]=$row['WORKSTATION'];
      if ($tws_config['cpuinfo']['version']>='9.5002'){
          if(empty($row['WKS_FOL_PATH']))
              $row['WKS_FOL_PATH'] = '/';
          $members['workstation_folder'][$i] = $row['WKS_FOL_PATH'];
      }
      $i++;
   }
   $members['member_num']=$i;
   return $members;
}

function tws_create_backup_header(&$data, $obj_name="") {
   if (!is_array($obj_name)) $obj_name=array($obj_name);
   $header = "<backup>\n".
             "<creator>".tws_profile('auth_user_name')."</creator>\n".
             "<timestamp>".time()."</timestamp>\n";
   for($i=0; $i<count($obj_name); $i++) {
      if ($obj_name[$i] != "") {
         $header .= "<object>".$obj_name[$i]."</object>\n";
      }
   }
   $header .= "</backup>\n";
   $data = $header.$data;
}


//<backup>
//<creator>tws85</creator>
//<timestamp>1298466238</timestamp>
//</backup>
function tws_decode_backup_header($line) {
   static $in_header=NULL;
   if ($line===NULL) $in_header=NULL;
   if ($in_header===NULL && strpos($line,'<backup>')!==FALSE) $in_header=TRUE;
   if (!$in_header) return FALSE;
   if (strpos($line,'</backup>')!==FALSE) $in_header=FALSE;

   $head_in_array = preg_split('/(<[^>]*[^\/]>)/i', $line, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
   if (is_array($head_in_array) === TRUE && count($head_in_array) > 0 && trim($head_in_array[1]) !== "") {
      return (array(0 => preg_replace("/[^0-9a-zA-Z\s]/" ,"",$head_in_array[0]), 1 => $head_in_array[1]));
   } else {
      return array();
   }
}

function tws_get_backupfile($file) {
   //reset the header analyzer
   tws_decode_backup_header(NULL);

   $result = array();
   $result['content'] = "";
   $timestamp = 0;
   $creator = 'N/A';
   if (($fd = fopen($file, "r")) !== FALSE) {
      while (is_resource($fd) && !feof($fd) && (($buff = fgets($fd, 4096)) !== FALSE)) {
         if (($head = tws_decode_backup_header($buff)) === FALSE) {
            $result['content'] .= $buff;
         } elseif (count($head) > 0) {
            $newvar = $head[0];
            $$newvar = $head[1];
            if($head[0] == 'object') {
               $result['object'][] = $head[1];
            }
         }
      }
      if ($timestamp === 0) {
         $info = explode(".",$file);
         $timestamp = mktime(0,0,0,substr($info[1],4,2),substr($info[1],6,2),substr($info[1],0,4));
      }
      $result['creator'] = $creator;
      $result['timestamp'] = $timestamp;
   } else {
      tws_err("Unable to open backup file '$file' for reading.");
      return (FALSE);
   }
   fclose($fd);

   return ($result);
}

function tws_write_backup($data, $obj_type, $obj_name="") {
   global $webadmin_backup_dir, $tws_config;

   $bckfilename="$webadmin_backup_dir/$obj_type.".tws_rndstr().".backup";
   if (!($fbck=fopen($bckfilename, 'w'))) {
      tws_error(__FUNCTION__.": Unable to create backup file '$bckfilename'", "Unable to create backup file");
      return FALSE;
   }
   tws_create_backup_header($data, $obj_name);
   if (fwrite($fbck,$data)<1) {
      fclose($fbck);
      tws_error(__FUNCTION__.": Unable to write backup file '$bckfilename'", "Unable to write backup file");
      return FALSE;
   }
   fclose($fbck);
   tws_chmod($bckfilename,0644);
   return $bckfilename;
}

/// Returns the text definition of given db object
/// \param fromspec requeted object specification (e.g.: job=PC_X#JOB_Y)
/// \param backup object type (used in backup file name, file is created in webadmin_backup_dir)
///        if the backup parameter is emty string then no backup is made
/// \return string containing requested object definition
/// \return FALSE in case of error or if the specified object doesn't exist
function tws_composer_create_from($fromspec, $backup=FALSE, &$bckfilename='', $lock=FALSE, $full=FALSE) {
   global $webadmin_tmp_dir, $webadmin_backup_dir, $maestro_dir, $tws_config, $host_os;

// create array for non-array imput usage
   if (!is_array($fromspec)) $fromspec=array($fromspec);

// Preparation for backup mode
   if ($backup!==FALSE) {
      if (is_string($backup)) $backup_name=$backup;
      else {
         $from_pcs=explode('=',$fromspec[0]);
         $backup_name=trim($from_pcs[0]);
      }
      $bckfilename="$webadmin_backup_dir/$backup_name.".tws_rndstr().".backup";
      if (!($fbck=fopen($bckfilename,'w'))) {
         tws_error("Unable to create backup file '$bckfilename'", "Unable to create backup file");
         return FALSE;
      }
// Extract object names from $fromspec
      $obj_names=array();
      for($i=0; $i<count($fromspec); $i++) {
         $from_pcs=explode('=',$fromspec[$i]);
         $obj_names[$i] = $from_pcs[1];
      }
// Create a backup header and write to the backup file
      if ($backup!==FALSE) {
         $head = "";
         tws_create_backup_header($head, $obj_names);
         $num_bytes = fwrite($fbck,$head);
         if ($backup!==FALSE && $num_bytes<0) {
            fclose($fbck);
            tws_error("Unable to write header to backup file '$bckfilename'", "Unable to write header to backup file");
         }
      }
   }

   $total_edittext='';
   $obj_iter=0;
   $testnum=isset($tws_config['composer_testnum']) ? $tws_config['composer_testnum'] : 2;
   $wait_time=isset($tws_config['composer_waitsec']) ? $tws_config['composer_waitsec'] : 2;

// process all requested dumps
   foreach ($fromspec as $from) {
      $obj_iter++;
// temporrary filename
      $tmpfilename="$webadmin_tmp_dir/dbo.".tws_rndstr().".tmp";

//build the command
      $lock=$lock ? ' ;lock' : '';
      $full=$full ? ' ;full' : '';
      //$command="$maestro_dir/bin/composer $tws_config[composer_args] \"create $tmpfilename from $from $lock$full\" 2>&1";
      $command=new hwi_cmd(tws_sudo(''), "$maestro_dir/bin/composer", $tws_config['composer_args'], "create $tmpfilename from $from $lock$full", hwi_cmd::operator('2>&1',FALSE));

// We do more attempts as a workaround to the database connection staleing:
// After a certain amount of inactivity, either Oracle or websphere marks the database connection
// as "Stale", and it re-initializes the websphere->oracle jdbc connection... which probably
// works ok, but takes too long and composer times out. Other thing: composer command has
// a -timeout option.  Possibly setting a higher value would fix the problem too.
      $edittext='';
      $test=0;
      while (strlen(trim($edittext))==0) {
// Still some attempts?
         if (++$test>$testnum) {
            if (strpos($stdout,"not authorized to perform")!== FALSE) {
               tws_error($stdout,"You are not authorized to access $from");
            } else {
               tws_error(array('attr'=>"Unable to get required data from composer ($testnum atts.)", 'stdout'=>$stdout), "Unable to perform the action.");
            }
            return FALSE;
         }
// Wait before next attempt
         if ($test>1) {
            sleep($wait_time);
         }
// Execute the "create from command"
         $stdout='';
         tws_popen($command, $ec, $stdout, $stdout, "Y");
// Verify file was created
         clearstatcache();
         if (!file_exists("$tmpfilename")) {
            tws_error("Temporary file not created ($test/$testnum).", "Unable to create temporary file");
            continue; //continue to next attempt
         }
// Try to open and read the temporary file
         if (!($ftmp=fopen("$tmpfilename","r"))) {
            tws_error("Unable to open temporary file '$tmpfilename' ($test/$testnum)", "Unable to open temporary file");
            continue; //continue to next attempt
         }
         $linenum=0;
         while (!feof($ftmp)) {
            $linenum++;
            $num_bytes=0;
            $buffer=fgets($ftmp,4096);
//avoid repeated xml file header
            if ($linenum==1 && preg_match('/^<\?xml/',$buffer) && $obj_iter>1) continue;

            //TWS8.4 w/o fixpack patch
            $buffer=preg_replace('/^DAT:SCHEDULE/', 'SCHEDULE', $buffer);
            if (substr(trim($buffer),0,1)=='$' && $linenum==1) {
               if ($backup!==FALSE && $obj_iter==1) {
// write file header (e.g. $JOB, $CALENDAR, etc...)
                  $num_bytes=fwrite($fbck,$buffer);
               }
            } else {
               $edittext.=$buffer;
               if ($backup!==FALSE) {
                  $num_bytes=fwrite($fbck,$buffer);
               }
            }
            if ($backup!==FALSE && $num_bytes<0) {
               fclose($fbck);
               tws_error("Unable to write backup file '$bckfilename'", "Unable to write backup file");
            }
         }
         fclose($ftmp);
// Delete the temporary file (but not backup file!)
         unlink($tmpfilename);
      }

      $total_edittext.=$edittext;

   }

   if ($backup!==FALSE) {
      fclose($fbck);
      tws_chmod($bckfilename,0644);
   }
   return $total_edittext;
}


/// Returns the text definition of given jobstream
/// \return string containing the stream definition
/// \return FALSE in case of error or if the specified jobstream doesn't exist
function tws_get_jobstream_definition_text($cpu, $schedule, $valid_from, $full=FALSE) {
   global $composer_db;
   global $webadmin_tmp_dir, $maestro_dir, $tws_config, $host_os ;

   $js = $cpu."#".$schedule;
   if ($valid_from == "ALL"){
      $valid_expr = "";
   } else if ($valid_from == '') {
      $valid_expr = 'valid in '.tws_date_from_iso('0000-01-01').' '.tws_date_from_iso('0000-01-02');
   } else {
      $valid_expr = " valid from  ".tws_date_from_iso($valid_from);
   }
   if ($full) {
      $bk = '';
      return tws_composer_create_from("sched=$js $valid_expr", false, $bk, false, true);
   }
   else {
      return tws_composer_create_from("sched=$js $valid_expr");
   }
}

/// Locks IWS database objects
/// \param objspec requested object specification (e.g.: job=PC_X#JOB_Y)
/// \return FALSE in case of error or if the specified object doesn't exist
function tws_composer_lock($objspec) {
   global $tws_config;

   if (!is_array($objspec)) $objspec=array($objspec);

   foreach ($objspec as $cmd) {
      $command = new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/composer", $tws_config['composer_args'], 'lock', $cmd, hwi_cmd::operator('2>&1',FALSE));
      $stdout=''; $ec=0;
      //ERR10081
      //Added parsing of "AWSBIA307I Total objects locked: 0" in the output since composer
      //returns RC=0 even if it doesn't lock anything...
      $ec_popen=tws_popen($command, $ec, $stdout, $stdout, "Y");
      //not_locked=1 if this info message is returned from composer:
      //AWSBIA307I Total objects locked: 0.
      //Note: This has been added on 2016-07 to fix the problem of composer locking
      //correctly objects but returning incorrect return code "139"
      $not_locked=preg_match('/AWSBIA307[^\n]+0/',$stdout);
      if ($ec_popen===FALSE || ($ec!=0 && $not_locked)) {
         tws_error(array('stdout'=>$stdout, "EC_POPEN"=>$ec_popen, "EC_LOCK"=>$ec, 'Locked'=>tws_yesno($not_locked, 'NO','YES')), "Unable to lock $cmd");
         return FALSE;
      }
   }
   return TRUE;
}

/// Locks IWS database objects
/// \param objspec requested object specification (e.g.: job=PC_X#JOB_Y)
/// \param forced option for requested object specification (e.g.: job=PC_X#JOB_Y)
/// \return FALSE in case of error or if the specified object doesn't exist
function tws_composer_unlock($objspec, $forced=FALSE) {
   global $tws_config;

   if (!is_array($objspec)) $objspec=array($objspec);
   if ($forced) {
      $forced=';forced';
   } else {
      $forced='';
   }

   foreach ($objspec as $cmd) {
      $command = new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/composer", $tws_config['composer_args'],  "unlock $cmd$forced", hwi_cmd::operator('2>&1',FALSE));
      $stdout=''; $ec=0;
      //ERR10081
      //Added parsing of "AWSBIA308I Total objects unlocked: 0" in the output since composer
      //returns RC=0 even if it doesn't lock anything...
      $ec_popen=tws_popen($command, $ec, $stdout, $stdout, "Y");
      //not_locked=1 if this info message is returned from composer:
      //AWSBIA308I Total objects locked: 0.
      //Note: This has been added on 2016-07 to fix the problem of composer locking
      //correctly objects but returning incorrect return code "139"
      $not_unlocked=preg_match('/AWSBIA308[^\n]+0/',$stdout);
      if ($ec_popen===FALSE || ($ec!=0 && $not_unlocked)) {
         tws_error(array('stdout'=>$stdout, "EC_POPEN"=>$ec_popen, "EC_UNLOCK"=>$ec, 'Unlocked'=>tws_yesno($not_locked, 'NO','YES')), "Unable to ".($forced ? 'force' : '')." unlock $cmd");
         return FALSE;
      }
   }
   return TRUE;
}


///////////////////////////////////////////////////////////////////////////////
/// tws_get_job_jobstream_xref
///
/// Returns all jobstream membership for given job.
///
function tws_get_job_jobstream_xref($workstation, $job, $valid_from='', $include_drafts='yes', $sql_filter='') {
   global $tws_config, $composer_db;

   if( $sql_filter=='' ) $sql_filter='1=1';

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=$composer_db["schema"];

// IWS 9.5 Folders
// TODO: get stream for right job folder
      list($folder, $job)= tws_explode_folder($job);
      if($tws_config['cpuinfo']['version']>='9.5002'){
        $tmp = tws_explode_folder($workstation);
        $workstation = $tmp[1];
        $ws_folder = $tmp[0];
      }
// -----------------------

// jobstream membership query
   $member_query = "DEP_JOD_WKC.WKC_NAME ".tws_sqllike(db_string($composer_db,$workstation))." AND JOD_NAME ".tws_sqllike(db_string($composer_db,$job));
   if($tws_config['cpuinfo']['version']>='9.5002')
       $member_query .= " AND JOBWSFOL.FOL_PATH ".tws_sqllike(db_string($composer_db,$ws_folder));
// valid from query
   if ($valid_from!='') {
      $valid_query = "( JST_VALID_FROM <= '".db_string($composer_db,$valid_from)."' OR JST_VALID_FROM IS NULL) AND
                      ( JST_VALID_TO   >  '".db_string($composer_db,$valid_from)."' OR JST_VALID_TO   IS NULL) AND";
   } else {
      $valid_query = "";
   }
// include drafts query
   if ($include_drafts == "yes") {
      $draft_query = "";
   } else {
      $draft_query = "JST_DRAFT='N' AND";
   }

//build the query
   $jobstreams_query="SELECT
           DEP_JOD_WKC.WKC_NAME JOB_WORKSTATION,
           AJB_NAME,
           JOD_NAME,
           DEP_JS_WKC.WKC_NAME JOBSTREAM_WORKSTATION,
           AJS_NAME,
           JST_VALID_FROM,
           JST_VALID_TO, ";
           $jobstreams_query .= ($tws_config['cpuinfo']['version']>='9.5' ? "
           FOL.FOL_PATH ," : '') ;
           if($tws_config['cpuinfo']['version']>='9.5002')
               $jobstreams_query .= "
                WSFOL.FOL_PATH WSFOLDER,";
      $jobstreams_query .="
            JST_DRAFT
      FROM    (((((($schema.JOB_JOBS
         JOIN    $schema.AJB_ABSTRACT_JOBS ON $schema.AJB_ABSTRACT_JOBS.AJB_ID = $schema.JOB_JOBS.AJB_ID)
         JOIN    $schema.JOD_JOB_DEFINITIONS ON $schema.JOD_JOB_DEFINITIONS.JOD_ID = $schema.JOB_JOBS.JOD_ID)
         JOIN    $schema.WKC_WORKSTATION_CLASSES DEP_JOD_WKC ON $schema.JOD_JOB_DEFINITIONS.WKC_ID = DEP_JOD_WKC.WKC_ID)
         JOIN    $schema.JST_JOB_STREAMS ON $schema.JST_JOB_STREAMS.JST_ID = $schema.JOB_JOBS.JST_ID)
         JOIN    $schema.AJS_ABSTRACT_JOB_STREAMS ON $schema.JST_JOB_STREAMS.AJS_ID = $schema.AJS_ABSTRACT_JOB_STREAMS.AJS_ID)
         JOIN    $schema.WKC_WORKSTATION_CLASSES DEP_JS_WKC ON $schema.AJS_ABSTRACT_JOB_STREAMS.WKC_ID = DEP_JS_WKC.WKC_ID)";
         $jobstreams_query .= ($tws_config['cpuinfo']['version']>='9.5' ? "
            LEFT JOIN $schema.FOL_FOLDERS FOL ON $schema.AJS_ABSTRACT_JOB_STREAMS.FOL_ID = FOL.FOL_ID " : '');
         if($tws_config['cpuinfo']['version']>='9.5002')
             $jobstreams_query .= "
             LEFT JOIN $schema.FOL_FOLDERS WSFOL ON DEP_JS_WKC.FOL_ID = WSFOL.FOL_ID
             LEFT JOIN $schema.FOL_FOLDERS JOBWSFOL ON DEP_JOD_WKC.FOL_ID = JOBWSFOL.FOL_ID";
      $jobstreams_query .= "
      WHERE $valid_query $draft_query
         $member_query
         AND $sql_filter
      ORDER BY DEP_JOD_WKC.WKC_NAME, AJB_NAME";

   if( !($r=db_query($composer_db,$jobstreams_query)) ){
      tws_error('', 'Database query failed');
   }
   $jobstreams=array();
   $i=0;
   while ($row = db_fetch_row($composer_db)) {
      $jobstreams['job_workstation'      ][$i]=$row['JOB_WORKSTATION'];
      $jobstreams['job_name'             ][$i]=$row['AJB_NAME'];
      $jobstreams['job_def_name'         ][$i]=$row['JOD_NAME'];
      if($tws_config['cpuinfo']['version']>='9.5002')
          $row['JOBSTREAM_WORKSTATION'] = $row['WSFOLDER'].$row['JOBSTREAM_WORKSTATION'];
      $jobstreams['jobstream_workstation'][$i]=$row['JOBSTREAM_WORKSTATION'];
      $jobstreams['jobstream_name'       ][$i]=$row['AJS_NAME'];
      if(!empty($row['FOL_PATH'])){
         $jobstreams['jobstream_name'][$i]  = $row['FOL_PATH'].$jobstreams['jobstream_name'][$i];
         $jobstreams['jobstream_folder'] = $row['FOL_PATH'];
      }
      $jobstreams['jobstream_valid_from' ][$i]=$row['JST_VALID_FROM'];
      $jobstreams['jobstream_valid_to'   ][$i]=$row['JST_VALID_TO'];
      $jobstreams['jobstream_draft'      ][$i]=tws_yesno($row['JST_DRAFT']);
      $i++;
   }
   $jobstreams['jobstream_num']=$i;
   return $jobstreams;
}





//=============================================================================
//
//   $webadmin_db functions
//
//=============================================================================



///////////////////////////////////////////////////////////////////////////////
//
// List of jobnotes
//
// Arguments:
//    workstaion , job
//    title (if not entered, all will be returned)
//    sqlcond  - additional sql filter
//
//    if sqlcond equals to 'n.note_type_id=4' then workstation notes are returned
//
// Warning: the indexing of result is different form other results
//           because of groups (types) which must be processed separately
//
// Warning: uses the $webadmin_db
function tws_get_notes($workstation,$job,$title='',$sqlcond='1=1') {
   global $webadmin_db, $note_types_file;

   require($note_types_file);
   if (!isset($note_types)) {
      tws_error("Unable to load note types table from file '$note_types_file'.", "Notes types table not available.");
      return FALSE;
   }

   $dbh = db_connect($webadmin_db,DB_PERSISTENT);
   if (!$dbh) {
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=$webadmin_db["schema"];

   if ($workstation=='') {
      tws_error("Missing workstation name", "Database query error - missing arguments.");
      return FALSE;
   }
   $workstation = strtoupper($workstation);
   $job = strtoupper($job);
   if ($job===FALSE || $job===NULL || $job==='' || $job==='-') {
      $jobq="JOB='-'";
   } else {
      $jobq="JOB ".tws_sqllike(db_string($webadmin_db,$job));
   }
   if ($title=='' || $title===NULL) {
      $title_cond="1=1";
   } else {
      $title=db_string($webadmin_db,$title);
      $title_cond="title='$title'";
   }

   $query="SELECT
         NOTE_TYPE_ID,
         WORKSTATION,
         JOB,
         USERNAME,
         TITLE,
         NOTE_TEXT,
         TSTAMP,
         LAST_UPDATED
      FROM $schema.notes
      WHERE WORKSTATION ".tws_sqllike(db_string($webadmin_db,$workstation))."
         AND $jobq
         AND $title_cond
         AND $sqlcond
      ORDER BY
         WORKSTATION, JOB, NOTE_TYPE_ID";

   tws_log($query);
   if( !($r=db_query($webadmin_db,$query)) ){
      tws_error('', 'Database query failed');
      return FALSE;
   }

   $notes=Array();
   while ($row = db_fetch_row($webadmin_db)){
      $row['NOTE_TYPE']=$note_types[$row['NOTE_TYPE_ID']];
      if ($row['JOB']=='-') $row['JOB']='';
      $notes[]=$row;
      tws_log("$row[WORKSTATION] # $row[JOB]");
   }
   if ($row!==0) return FALSE;
   return $notes;
}

function tws_get_notes_exist ($workstation, $job, $sqlcond='1=1') {
   global $webadmin_db;

   $dbh = db_connect($webadmin_db,DB_PERSISTENT);
   if (!$dbh) {
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=$webadmin_db["schema"];

   $workstation = strtoupper($workstation);
   $job = strtoupper($job);
   if ($workstation=='')   $workstation = '-';
   if ($job===FALSE || $job===NULL || $job==='' || $job==='-') $jobq="JOB='-'";
   else $jobq="JOB ".tws_sqllike(db_string($webadmin_db,$job));

   $query="SELECT DISTINCT
         WORKSTATION,
         JOB
      FROM $schema.notes
      WHERE WORKSTATION ".tws_sqllike(db_string($webadmin_db,$workstation))."
         AND $jobq
         AND $sqlcond";

   if( !($r=db_query($webadmin_db,$query)) ){
      tws_error('', 'Database query failed');
      return FALSE;
   }

   $notes=Array();
   while ($row = db_fetch_row($webadmin_db)){
      if ($row['WORKSTATION'] != '-' && $row['JOB'] != '-')
         $name = $row['WORKSTATION'] .'#'. $row['JOB'];
      elseif ($row['WORKSTATION'] != '-')
         $name = $row['WORKSTATION'];
      else
         $name = $row['JOB'];
      $notes[$name]=''; // save as key. Then check if (isset($notes[$name]))
   }
   if(count($notes)==0) return false;
   return $notes;
}


//////////////////////////////////////////
//  function tws_workstation_notes_enabled()
//
//  returns index of the workstation note type if
//          workstation notes are enabled
//  (enabled means note_type = Workstation)
function tws_workstation_notes_enabled() {
   global $note_types_file;
   require $note_types_file;
   return array_search('Workstation', $note_types);
}

//  update_note()
//
function tws_update_note($cpu,$job,$title,$user,$note_type_id,$note_text) {
   global $webadmin_db;
   $dbh = db_connect($webadmin_db,DB_PERSISTENT);
   if (!$dbh) {
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }

   $title=db_string($webadmin_db,$title);
   $note_text=db_string($webadmin_db,$note_text);

   $job_cond=($job===NULL || $job===FALSE || $job==='' || $job==='-') ? "JOB='-'" : "JOB='".db_string($webadmin_db,$job)."' AND JOB!='-'";

   $schema=$webadmin_db["schema"];
   $query="UPDATE $schema.notes SET
            last_updated=CURRENT_TIMESTAMP,
            note_text='$note_text'
         WHERE note_type_id=$note_type_id AND
            workstation='".db_string($webadmin_db,$cpu)."' AND
            $job_cond AND
            username='".db_string($webadmin_db,$user)."' AND
            title='$title'";

   if( !($r=db_query($webadmin_db,$query)) || db_aff_rows($webadmin_db)!=1 ){
      tws_error('', 'Database query failed');
      return FALSE;
   }
   if (isset($webadmin_db['allow_persistent']) && tws_yesno($webadmin_db['allow_persistent'])=='NO'){
      if(!db_commit($webadmin_db)) { tws_error("Unable to COMMIT request."); return false;}
   }
   return TRUE;
}

//  rename_note()
//
function tws_rename_note($cpu,$job, $newcpu,$newjob, $note_type_cond='1=1') {
   global $webadmin_db;
   $dbh = db_connect($webadmin_db,DB_PERSISTENT);
   if (!$dbh) {
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $cpu=strtoupper($cpu); $job=strtoupper($job); $newcpu=strtoupper($newcpu); $newjob=strtoupper($newjob);

   $schema=$webadmin_db["schema"];
   $query="UPDATE $schema.notes SET
            workstation='$newcpu',
            job='$newjob'
         WHERE $note_type_cond AND
            workstation='".db_string($webadmin_db,$cpu)."' AND
            job='".db_string($webadmin_db,$job)."'
         ";

   if( !($r=db_query($webadmin_db,$query)) || db_aff_rows($webadmin_db)!=1 ){
      tws_error('', 'Database query failed');
      return FALSE;
   }
   if (isset($webadmin_db['allow_persistent']) && tws_yesno($webadmin_db['allow_persistent'])=='NO'){
      if(!db_commit($webadmin_db)) { tws_error("Unable to COMMIT request."); return false;}
   }
   return TRUE;
}


//  delete note
//
function tws_delete_note($note_type_cond, $cpu, $job, $title='', $user='') {
   global $webadmin_db;
   $dbh = db_connect($webadmin_db,DB_PERSISTENT);
   if (!$dbh) {
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }

   $title_cond = '';
   if(trim($title) != '')
      $title_cond = " AND title='".db_string($webadmin_db,$title)."'";

   if(trim($user) != '') {
      if ( tws_profile('is_admin') || $user == $_SERVER['PHP_AUTH_USER'] )
         $user_cond = " AND username='".db_string($webadmin_db,$user)."'";
      else
         $user_cond = " AND username='".db_string($webadmin_db,$_SERVER['PHP_AUTH_USER'])."'";
   }
   else {
      if ( tws_profile('is_admin') )
         $user_cond = '';
      else
         $user_cond = " AND username='".db_string($webadmin_db,$_SERVER['PHP_AUTH_USER'])."'";
   }


   $job_cond=($job===NULL || $job===FALSE || $job==='' || $job==='-') ? "JOB='-'" : "JOB='".db_string($webadmin_db,$job)."' AND JOB!='-'";
   if($cpu=='') $cpu = '-';

   $schema=$webadmin_db["schema"];
   $query="DELETE FROM $schema.notes WHERE
            $note_type_cond AND
            workstation='".db_string($webadmin_db,$cpu)."' AND
            $job_cond
            $user_cond
            $title_cond";

   if( !($r=db_query($webadmin_db,$query)) ){
      tws_error('', 'Database query failed');
      return FALSE;
   }
   if (isset($webadmin_db['allow_persistent']) && tws_yesno($webadmin_db['allow_persistent'])=='NO'){
      if(!db_commit($webadmin_db)) {tws_error("Unable to COMMIT request."); return false;}
   }
   return TRUE;
}

//  backup note
function tws_backup_note ($note_type_cond, $cpu, $job, $title='', $user='') {
   global $webadmin_db, $note_types_file, $webadmin_backup_dir, $maestro_dir, $tws_config;

   $dbh = db_connect($webadmin_db,DB_PERSISTENT);
   if (!$dbh) { tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $title_cond = '';
   if(trim($title) != '')
      $title_cond = " AND title='".db_string($webadmin_db,$title)."'";

   if(trim($user) != '') {
      if ( tws_profile('is_admin') || $user == $_SERVER['PHP_AUTH_USER'] )
         $user_cond = " AND username='".db_string($webadmin_db,$user)."'";
      else
         $user_cond = " AND username='".db_string($webadmin_db,$_SERVER['PHP_AUTH_USER'])."'";
   }
   else {
      if ( tws_profile('is_admin') )
         $user_cond = '';
      else
         $user_cond = " AND username='".db_string($webadmin_db,$_SERVER['PHP_AUTH_USER'])."'";
   }

   if($job===NULL || $job===FALSE || $job==='' || $job==='-') {
      $job_cond = "JOB='-'"; $job='-';
   }
   else
      $job_cond = "JOB='".db_string($webadmin_db,$job)."'";
   if($cpu=='') $cpu = '-';

   $schema=$webadmin_db["schema"];
   $query="SELECT * FROM $schema.notes WHERE
            $note_type_cond AND
            workstation='".db_string($webadmin_db,$cpu)."' AND
            $job_cond
            $user_cond
            $title_cond";

   if( !($r=db_query($webadmin_db,$query)) ) {
      tws_error('', 'Database query failed');
      return FALSE;
   }
   $notes=Array();
   while ($row = db_fetch_row($webadmin_db)){
      $notes[]=$row;
   }
// write backup to file
   $bckfilename="$webadmin_backup_dir/notes.".tws_rndstr().".backup";
   if (!($fbck=fopen($bckfilename,'w'))) {
      tws_error("Unable to create backup file '$bckfilename'", "Unable to create backup file");
      return FALSE;
   }
   // write header
   $head = "";
   if($cpu!='-' && $job!='-')
      $obj_name = "$cpu#$job";
   elseif($cpu!='-')
      $obj_name = $cpu;
   else
      $obj_name = $job;
   tws_create_backup_header($head, $obj_name);
   if (fwrite($fbck,$head)<0) {
      fclose($fbck);
      tws_error("Unable to write to backup file '$bckfilename'", "Unable to write to backup file");
   }
   foreach($notes as $note) {
      $str = "INSERT INTO $schema.NOTES ( ";
      $values = "VALUES ( ";
      foreach($note as $key=>$val){
         $str.= "$key, ";
         $values.= ($key == 'NOTE_TYPE_ID' ? "$val, " : "'$val', ");
      }
      $values = substr($values, 0, strlen($values)-2).");\n";
      $str = substr($str, 0, strlen($str)-2).") ". $values;
      fwrite($fbck,$str);
   }
   fclose($fbck);
   return TRUE;
}



// WARNING: When jobstream is DRAFT then it doesn't appropriately modify the valid_from
// and valid_to fields in jobstreams of the same name! Therefore, it is very useful here, to
// set $sqlfilter paramter to JST.JST_DRAFT='N', otherwise more matching jobstreams will be
// returned for given VALID_ON !!!
//
function tws_get_job_instances($job_workstation='@', $job='@', $valid_on='', $sqlfilter=''){
   global $tws_config, $composer_db;

   if( $sqlfilter=='' ) $sqlfilter='1=1';

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema = $composer_db['schema'];
   if ($valid_on == '') {
      $valid_cond = "1=1";
   } else {
      $valid_on = db_string($composer_db,$valid_on);
      $valid_cond = "( ((JST.JST_VALID_FROM IS NULL) AND (JST.JST_VALID_TO IS NULL))
                  OR   ((JST.JST_VALID_FROM IS NULL) AND (JST.JST_VALID_TO > '$valid_on'))
                  OR   ((JST.JST_VALID_FROM <= '$valid_on') AND (JST.JST_VALID_TO > '$valid_on'))
                  OR   ((JST.JST_VALID_FROM <= '$valid_on') AND (JST.JST_VALID_TO IS NULL))  )";
   }

   $query ="SELECT
           WKC.WKC_NAME WORKSTATION,
           AJS.AJS_NAME JOBSTREAM,
           JST.JST_VALID_FROM VALID_FROM,
           AJB.AJB_NAME JOBNAME,
           JOD_WKC.WKC_NAME JOB_WORKSTATION,
           JOD.JOD_NAME DEF_JOBNAME,
           JOB.JOB_START_OFFSET AT,
           JOB.JOB_COMMENT CMNT,
           JOB.JOB_TIMEZONE_ID TZ
         FROM (((((($schema.JOB_JOBS JOB
            JOIN $schema.AJB_ABSTRACT_JOBS AJB
            ON   AJB.AJB_ID = JOB.AJB_ID)
            JOIN $schema.AJS_ABSTRACT_JOB_STREAMS AJS
            ON   AJB.AJS_ID = AJS.AJS_ID)
            JOIN $schema.WKC_WORKSTATION_CLASSES WKC
            ON   WKC.WKC_ID = AJS.WKC_ID)
            JOIN $schema.JOD_JOB_DEFINITIONS JOD
            ON   JOD.JOD_ID = JOB.JOD_ID)
            JOIN $schema.WKC_WORKSTATION_CLASSES JOD_WKC
            ON   JOD.WKC_ID = JOD_WKC.WKC_ID)
            JOIN $schema.JST_JOB_STREAMS JST
            ON   JST.JST_ID = JOB.JST_ID)
         WHERE
            AJB.AJB_NAME ".tws_sqllike(db_string($composer_db,$job))." AND
            JOD_WKC.WKC_NAME ".tws_sqllike(db_string($composer_db,$job_workstation))." AND
            $valid_cond AND
            $sqlfilter";
   if( !($r=db_query($composer_db,$query)) ){
      tws_error('', 'Database query failed');
      return FALSE;
   }
   $jobs=Array();
   $i=0;
   $temp='';
   while ($row = db_fetch_row($composer_db)) {
      $jobs['workstation'    ][$i]=$row['WORKSTATION'];
      $jobs['jobstream'      ][$i]=$row['JOBSTREAM'];
      $jobs['valid_from'     ][$i]=$row['VALID_FROM'];
      $jobs['jobname'        ][$i]=$row['JOBNAME'];
      $jobs['job_workstation'][$i]=$row['JOB_WORKSTATION'];
      $jobs['def_jobname'    ][$i]=$row['DEF_JOBNAME'];
      tws_get_at_time($row['AT'],$jobs['athour'][$i],$jobs['atminute'][$i],$temp,$jobs['atplusdays'][$i]);
      $jobs['job_comment'    ][$i]=trim($row['CMNT'], "\r\n");
      $jobs['job_timezone'   ][$i]=$row['TZ'];
      $i++;
   }
   if ($row!==0) return FALSE;
   $jobs['job_num']=$i;
   return $jobs;
}

function tws_objspec_from_selection($selection, $obj_type) {
   $num_elements=count($selection);
   if($num_elements == 0) $selection = array();
   $objspec=array();
   switch ($obj_type) {
      case 'ws' :
      case 'wscl' :
      case 'dom' :
         for ($idx=0; $idx<$num_elements; $idx++) {
            $objspec[]="$obj_type=$selection[$idx]";
         }
         break;
      case 'cal' :
      case 'jd' :
      case 'res' :
      case 'prom' :
      case 'parm' :
      case 'vartable' :
      case 'rc' :
      case 'erule' : case 'er' : case 'eventrule' :
      case 'folder' :
         foreach ($selection as $name) {
            $objspec[]="$obj_type=$name";
         }
         break;
      case 'js' :
         for ($idx=0; $idx<$num_elements; ++$idx) {
            if (($pos = strpos($selection[$idx],":")) !== FALSE) {
               $js=substr($selection[$idx],0,$pos);
               $valid_from = "valid from ".tws_date_from_iso(tws_make_iso_valid_from(substr($selection[$idx],$pos+1)));
            } else {
               $js=$selection[$idx];
               $valid_from = 'valid in '.tws_date_from_iso('0000-01-01').' '.tws_date_from_iso('0000-01-02');
            }
            $objspec[]="js=$js $valid_from";
         }
         break;

      default:
         $objspec=FALSE;
         break;
   }
   return $objspec;
}



//==eds========================================================================

/// Returns the text definition of given event rule
/// \return string containing the stream definition
/// \return FALSE in case of error or if the specified event rule doesn't exist
function tws_get_evrule_definition_text($evrule) {
   return tws_composer_create_from("erule=$evrule");
}

///////////////////////////////////////////////////////////////////////////////
//
// List of event rules
//
// Arguments:
//    evrule = event rule name (@=wildcard for all)
//    sqlcond = sql filteri - conditions of the where clause
//
function tws_get_evrules($evrule='@', $sqlfilter='', $page_size = 0, $page = 1, $od_callback=null, $action='LIST') {
   tws_log('-- tws_get_evrules (start at '.basename(__FILE__).'['.__LINE__.'])');
   global $tws_config, $composer_db;

   if(trim($sqlfilter)=='') $sqlfilter="1=1";

   $evrules=array();
   $evrules['evrule_num']=0;

 $tmp = tws_divide_folder($evrule);
   $evrule = $tmp[1];
   $evrule_folder = $tmp[0];

//access rights checking
   if (($acc_sql=tws_sec_check('EVENTRULE', array('NAME'=>'EERU_NAME'), '', $action))===FALSE) return $evrules;

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if (!$dbh) {
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=isset($composer_db['schema_evt']) ? $composer_db['schema_evt'] : ($composer_db['type']=='db2' ? 'EVT' : $composer_db['schema']);
   $common_schema = $composer_db['schema'];
   $query ="
      SELECT
         EERU_ID,
         EERU_NAME,
         EERU_DESCRIPTION,
         EERU_TYPE,
         EERU_DRAFT,
         CASE
           when EERU_DRAFT='N' and EERU_STATUS='A' and EERU_PROCESS_STATUS='P' then 'A'
           when EERU_DRAFT='N' and EERU_STATUS='A' and EERU_PROCESS_STATUS='N' then 'UP'
           when EERU_DRAFT='N' and EERU_STATUS='A' and EERU_PROCESS_STATUS='E' then 'UE'
           when EERU_DRAFT='N' and EERU_STATUS='I' and EERU_PROCESS_STATUS='P' then 'I'
           when EERU_DRAFT='N' and EERU_STATUS='I' and EERU_PROCESS_STATUS='N' then 'AP'
           when EERU_DRAFT='N' and EERU_STATUS='I' and EERU_PROCESS_STATUS='E' then 'AE'
           when EERU_DRAFT='Y' and EERU_STATUS='A' and EERU_PROCESS_STATUS='N' then 'DP'
           when EERU_DRAFT='Y' and EERU_STATUS='A' and EERU_PROCESS_STATUS='E' then 'DE'
           when EERU_DRAFT='Y' and EERU_STATUS='I' and EERU_PROCESS_STATUS='P' then 'I'
           when EERU_DRAFT='Y' and EERU_STATUS='I' and EERU_PROCESS_STATUS='N' then 'I'
           else 'X'
         END EERU_STATUS,
         EERU_VALID_FROM,
         EERU_VALID_TO,
         EERU_START_OFFSET,
         EERU_END_OFFSET,
         EERU_TIMEZONE_ID,
         EERU_THRESHOLD_COUNT,
         EERU_TIME_INTERVAL,
         EERU_TIME_INTERVAL_MODE,
         EERU_GROUP_ATTRIBUTE_LIST,
         EERU_MODIFY_OWNER,
         EERU_MODIFY_TIME,
         EERU_LOCK_OWNER,
         EERU_LOCK_TIME,
         EERU_LOCK_SESSION";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= ",
            FOL.FOL_PATH";
      $query .= "
      FROM
         ${schema}.EERU_EVENT_RULES";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
            LEFT JOIN $common_schema.FOL_FOLDERS FOL ON FOL.FOL_ID = $schema.EERU_EVENT_RULES.FOL_ID";
      $query .= "
      WHERE
         EERU_NAME ".tws_sqllike(db_string($composer_db,$evrule))." ";
      if ($tws_config['cpuinfo']['version']>='9.5002' && !empty($evrule_folder))
	 $query .= "  AND FOL.FOL_PATH = '$evrule_folder'";
	 $query .=" AND $sqlfilter
         $acc_sql
      ";
   tws_log('DB query: '.$query);
   if (!($r=db_query($composer_db,$query))) {
      tws_log('Error: Database query failed');
      tws_error('', "Database query failed");
      return FALSE;
   }
   $tl=tws_log();
   if ($page_size > 0) {
      $page_down = ($page - 1) * $page_size;
      $page_up = $page * $page_size;
   }
   while ($row = db_fetch_row($composer_db)) {
      $tl && tws_log(@var_export($row, true));
      $evrules['evrule_num']++;
      if ($page_size > 0) {
         if ($page_down >= $evrules['evrule_num']) {
            while (($page_down > $evrules['evrule_num']) && db_fetch_row($composer_db, null)) {
               $evrules['evrule_num']++;
            }
            continue;
         }
         if ($page_up < $evrules['evrule_num']) {
            while (($page_up < $evrules['evrule_num']) && db_fetch_row($composer_db, null)) {
               $evrules['evrule_num']++;
            }
            break;
         }
      }
      $evrules['evrule_id'              ][] = $row['EERU_ID'];
      $evrules['evrule_name'            ][] = $row['EERU_NAME'];
      $evrules['evrule_description'     ][] = $row['EERU_DESCRIPTION'];
      $evrules['evrule_valid_from'      ][] = $row['EERU_VALID_FROM'];
      $evrules['evrule_valid_to'        ][] = $row['EERU_VALID_TO'];
      $evrules['evrule_start_offset'    ][] = tws_get_at_time($row['EERU_START_OFFSET'], $h, $m, $s, $d, 'DAY_OFFSET');
      $evrules['evrule_end_offset'      ][] = tws_get_at_time($row['EERU_END_OFFSET'], $h, $m, $s, $d, 'DAY_OFFSET');
      $evrules['evrule_timezone'        ][] = $row['EERU_TIMEZONE_ID'];
      $evrules['evrule_draft'           ][] = $row['EERU_DRAFT'];
      $evrules['evrule_type'            ][] = $row['EERU_TYPE'];
      $evrules['evrule_timeout'         ][] = ($row['EERU_TIME_INTERVAL']>0) ? floor($row['EERU_TIME_INTERVAL'] / 1000) : $row['EERU_TIME_INTERVAL']; //seconds
      $evrules['evrule_attr_correlation'][] = $row['EERU_GROUP_ATTRIBUTE_LIST'];
      $evrules['evrule_creator'         ][] = $row['EERU_MODIFY_OWNER'];
      $evrules['evrule_last_updated'    ][] = $row['EERU_MODIFY_TIME'];
      $evrules['evrule_status'          ][] = $row['EERU_STATUS'];
      $evrules['evrule_lock_by'       ][] = $row['EERU_LOCK_OWNER'];
      $evrules['evrule_lock_on'       ][] = $row['EERU_LOCK_TIME'];
      if ($tws_config['cpuinfo']['version']>='9.5002'){
         if(empty($row['FOL_PATH']))
            $row['FOL_PATH'] = '/';
         $evrules['evrule_folder'     ][] = $row['FOL_PATH'];
      }
   }
   tws_log('-- tws_get_evrules (end up in '.basename(__FILE__).'['.__LINE__.'])');
   return $evrules;
}

// prepare structures for return:
   function tws_get_evrules_from_post(&$post) {
       global $tws_config;
      // generic data
      $evrules=array();
      $evrules['evrule_num'               ]=1;
      $evrules['evrule_folder'       	  ][0]=tws_gpc_get($post['evrules']['evrule_folder'][0]);
      $evrules['evrule_name'              ][0]=isset($post['evrules']['evrule_name'][0]) ? tws_gpc_get($post['evrules']['evrule_name'][0]) : tws_gpc_get($post['evrule_namex']);
      if ($tws_config['cpuinfo']['version'] >= '9.5002'){
          if (empty(tws_gpc_get($post['evrule_namex'])))
              $evrules['evrule_folder'][0] = $post['evrules']['evrule_folder'][0];
              else { // input evrule_namex contains rule name with folder
                  $tmp = tws_divide_folder($evrules['evrule_name'][0]);
                  $evrules['evrule_folder'][0] = $tmp[0];
                  $evrules['evrule_name'][0] = $tmp[1];
              }
      }
      $evrules['evrule_description'       ][0]=tws_gpc_get($post['evrules']['evrule_description'][0]);
      $evrules['evrule_valid_from'        ][0]=tws_userdate_to_evtiso(tws_gpc_get($post['evrules']['evrule_valid_from'][0]), null, TRUE);
      $evrules['evrule_valid_to'          ][0]=tws_userdate_to_evtiso(tws_gpc_get($post['evrules']['evrule_valid_to'][0]), null, TRUE);
      $evrules['evrule_start_offset'      ][0]=tws_timeoffset_to_iso(tws_gpc_get($post['evrules']['evrule_start_offset'][0]));
      $evrules['evrule_end_offset'        ][0]=tws_timeoffset_to_iso(tws_gpc_get($post['evrules']['evrule_end_offset'][0]));
      $tz=tws_gpc_get($post['evrules']['evrule_timezone'][0]);
      $evrules['evrule_timezone'          ][0]=($tz=='NULL' ? '' : $tz);
      $evrules['evrule_draft'             ][0]=isset($post['evrules']['evrule_draft'][0]) ? tws_gpc_get($post['evrules']['evrule_draft'][0]) : 'N';
      $evrules['evrule_type'              ][0]=tws_gpc_get($post['evrules']['evrule_type'][0]);
      $evrules['evrule_timeout'           ][0]=tws_gpc_get($post['evrules']['evrule_timeout'][0]);
      $evrules['evrule_attr_correlation'  ][0]=array();
      if (is_array($post['evrules']['evrule_attr_correlation'][0])) {
         foreach ($post['evrules']['evrule_attr_correlation'][0] as $key=>$val) {
            $evrules['evrule_attr_correlation'][0][]=$key;
         }
      }
      return $evrules;
   }


///////////////////////////////////////////////////////////////////////////////
//
// List of event rules
//
// Arguments:
//    evrule = event rule name (@=wildcard for all)
//    sqlcond = sql filteri - conditions of the where clause
//
function tws_get_evrule_conditions($evrule='@', $sqlfilter='', $page_size = 0, $page = 1, $od_callback=null, $action='LIST') {
   tws_log('-- tws_get_evrule_conditions (start at '.basename(__FILE__).'['.__LINE__.'])');
   global $tws_config, $composer_db;

   if(trim($sqlfilter)=='') $sqlfilter="1=1";

   $events=array();
   $events['event_num']=0;
   $tmp = tws_divide_folder($evrule);
   $evrule = $tmp[1];
   $evrule_folder = $tmp[0];

//access rights checking
   if (($acc_sql=tws_sec_check('EVENTRULE', array('NAME'=>'EERU_NAME'), '', $action))===FALSE) return $events;

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if (!$dbh) {
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=isset($composer_db['schema_evt']) ? $composer_db['schema_evt'] : ($composer_db['type']=='db2' ? 'EVT' : $composer_db['schema']);
   $common_schema = $composer_db['schema'];
   $query ="
      SELECT
         EEFI_EVENT_NAME,
         EEFI_PLUGIN_NAME,
         EEFI_EVENT_TYPE,
         EEFI_PREDICATE,
         EEFI_POSITION,
         EEFI_SCOPE,
         EEFI_SPECIALIZED";
         if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= ",
            FOL.FOL_PATH";
      $query .= "
      FROM
         (${schema}.EERU_EVENT_RULES JOIN
          ${schema}.EEFI_EVENT_FILTERS ON ${schema}.EERU_EVENT_RULES.EERU_ID = ${schema}.EEFI_EVENT_FILTERS.EERU_ID)";
	  if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
            LEFT JOIN $common_schema.FOL_FOLDERS FOL ON FOL.FOL_ID = $schema.EERU_EVENT_RULES.FOL_ID";
      $query .= "
      WHERE
         EERU_NAME ".tws_sqllike(db_string($composer_db,$evrule))." ";
      if ($tws_config['cpuinfo']['version']>='9.5002' && !empty($evrule_folder))
	 $query .= "  AND FOL.FOL_PATH = '$evrule_folder'";
	 $query .=" AND $sqlfilter
         $acc_sql
         ORDER BY EEFI_POSITION
      ";
   tws_log('DB query: '.$query);
   if (!($r=db_query($composer_db,$query))) {
      tws_log('Error: Database query failed');
      tws_error('', "Database query failed");
      return FALSE;
   }
   $tl=tws_log();
   if ($page_size > 0) {
      $page_down = ($page - 1) * $page_size;
      $page_up = $page * $page_size;
   }
   while ($row = db_fetch_row($composer_db)) {
      $tl && tws_log(@var_export($row, true));
      $events['event_num']++;
      if ($page_size > 0) {
         if ($page_down >= $events['event_num']) {
            while (($page_down > $events['event_num']) && db_fetch_row($composer_db, null)) {
               $events['event_num']++;
            }
            continue;
         }
         if ($page_up < $events['event_num']) {
            while (($page_up < $events['event_num']) && db_fetch_row($composer_db, null)) {
               $events['event_num']++;
            }
            break;
         }
      }
      $events['evrule_event_name'       ][] = $row['EEFI_EVENT_NAME'];
      $events['evrule_event_plugin_name'][] = $row['EEFI_PLUGIN_NAME'];
      $events['evrule_event_type'       ][] = $row['EEFI_EVENT_TYPE'];
      $events['evrule_event_predicate'  ][] = $row['EEFI_PREDICATE'];
      $events['evrule_event_position'   ][] = $row['EEFI_POSITION'];
      $events['evrule_event_scope'      ][] = $row['EEFI_SCOPE'];
      $events['evrule_event_specialized'][] = $row['EEFI_SPECIALIZED'];
	  if ($tws_config['cpuinfo']['version']>='9.5002'){
         if(empty($row['FOL_PATH']))
            $row['FOL_PATH'] = '/';
         $evrules['evrule_folder'     ][] = $row['FOL_PATH'];
      }
   }
   tws_log('-- tws_get_evrule_conditions (end up in '.basename(__FILE__).'['.__LINE__.'])');
   return $events;
}

function tws_get_evrule_conditions_from_post(&$post) {
   //events
   $events=array();
   $events['event_num']=0;
   if (is_array($post['evrule_event_cond_position'])) {
      foreach ($post['evrule_event_cond_position'] as $i=>$j) {
         $events['event_num']++;
         $events['evrule_event_name'][$i]=tws_gpc_get($post['evrule_event_name'][$j]);
         $events['evrule_event_plugin_name'][$i]=tws_gpc_get($post['evrule_event_cond_plugin_name'][$j]);
         $events['evrule_event_type'][$i]=tws_gpc_get($post['evrule_event_cond_type'][$j]);
         $events['evrule_event_position'][$i]=tws_gpc_get($post['evrule_event_cond_position'][$j]);
         $events['evrule_event_predicate'][$i]='';
         foreach($post['evrule_event_cond_value'][$j] as $attrid=>$attr_instances) {
            foreach ($attr_instances as $k=>$attr_vals) {
               $attr_templ=new eda($attrid);
               $tws_attrid=$attr_templ->get_twsid();
               $events['evrule_event_predicate'][$i].='<attributeFilter name="'.$tws_attrid.'" operator="'.$post['evrule_event_cond_operator'][$j][$attrid][$k].'">';
               foreach ($attr_vals as $id_val=>$val) {
                  $val=tws_gpc_get($val);
                  if ($post['evrule_event_cond_operator'][$j][$attrid][$k]=='range') {
                     if (is_numeric($id_val)) continue;
                  } elseif (!is_numeric($id_val)) continue;
                  if ($attr_templ->get_basetype()=='tstamp') $val=tws_userdate_to_evtiso($val,null,!preg_match('/\d:\d/',$val));
                  else $val=htmlspecialchars($val);
                  $events['evrule_event_predicate'][$i].='<value>'.$val.'</value>';
               }
               $events['evrule_event_predicate'][$i].='</attributeFilter>';
            }
         }
         //FIXME:
         $events['evrule_event_specialized'][$i]='N';
         $events['evrule_event_scope'][$i]='';
      }
   }
   $events['evrule_folder'][0]=tws_gpc_get($post['evrules']['evrule_folder'][0]);
   return $events;
}


///////////////////////////////////////////////////////////////////////////////
//
// List of event rules
//
// Arguments:
//    evrule = event rule name (@=wildcard for all)
//    sqlcond = sql filteri - conditions of the where clause
//
function tws_get_evrule_actions($evrule='@', $sqlfilter='', $page_size = 0, $page = 1, $od_callback=null, $action='LIST') {
   tws_log('-- tws_get_evrule_actions (start at '.basename(__FILE__).'['.__LINE__.'])');
   global $tws_config, $composer_db;

   if(trim($sqlfilter)=='') $sqlfilter="1=1";

   $actions=array();
   $actions['action_num']=0;

   $tmp = tws_divide_folder($evrule);
   $evrule = $tmp[1];
   $evrule_folder = $tmp[0];

//access rights checking
   if (($acc_sql=tws_sec_check('EVENTRULE', array('NAME'=>'EERU_NAME'), '', $action))===FALSE) return $actions;

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if (!$dbh) {
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema_evt=isset($composer_db['schema_evt']) ? $composer_db['schema_evt'] : ($composer_db['type']=='db2' ? 'EVT' : $composer_db['schema']);
   $schema=isset($composer_db['schema']) ? $composer_db['schema'] : ($composer_db['type']=='db2' ? 'MDL' : $composer_db['schema']);
   $common_schema = $composer_db['schema'];

   $query ="
      SELECT
         EERU_NAME,
         ERAC_TYPE,
         ERAC_RESPONSE_TYPE,
         ERAC_PLUGIN_NAME,
         ERAC_PARAMETER_LIST,
         ERAC_DESCRIPTION,
         ERAC_POSITION,
         ERAC_SCOPE,
         ERAC_SPECIALIZED,
--         JOD_ID,
--         AJS_ID,
--         VAT_ID
         JOD_WKC.WKC_NAME JOD_WKC_NAME,
         JOD_NAME,
         JOD_DESCRIPTION,
         JOD_TASK_STRING,
         JOD_USER_LOGIN,
         AJS_WKC.WKC_NAME AJS_WKC_NAME,
         AJS_NAME
         ".($tws_config['cpuinfo']['version']<='8.4' ? '' : ', VAT_NAME, VAT_DESCRIPTION')."";
         if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= ",
            FOL.FOL_PATH";
      $query .= "
      FROM
         ((((((${schema_evt}.EERU_EVENT_RULES
               JOIN ${schema_evt}.ERAC_RULE_ACTIONS ON ${schema_evt}.EERU_EVENT_RULES.EERU_ID = ${schema_evt}.ERAC_RULE_ACTIONS.EERU_ID)
              LEFT JOIN ${schema}.JOD_JOB_DEFINITIONS ON ${schema_evt}.ERAC_RULE_ACTIONS.JOD_ID = ${schema}.JOD_JOB_DEFINITIONS.JOD_ID)
             LEFT JOIN ${schema}.WKC_WORKSTATION_CLASSES JOD_WKC ON ${schema}.JOD_JOB_DEFINITIONS.WKC_ID = JOD_WKC.WKC_ID)
            LEFT JOIN ${schema}.AJS_ABSTRACT_JOB_STREAMS ON ${schema_evt}.ERAC_RULE_ACTIONS.AJS_ID=${schema}.AJS_ABSTRACT_JOB_STREAMS.AJS_ID)
           LEFT JOIN ${schema}.WKC_WORKSTATION_CLASSES AJS_WKC ON ${schema}.AJS_ABSTRACT_JOB_STREAMS.WKC_ID = AJS_WKC.WKC_ID)
          ".($tws_config['cpuinfo']['version']<='8.4' ? '' : "LEFT JOIN ${schema}.VAT_VARIABLE_TABLES ON ${schema}.VAT_VARIABLE_TABLES.VAT_ID=${schema_evt}.ERAC_RULE_ACTIONS.VAT_ID")."
         )";
		 if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
            LEFT JOIN $common_schema.FOL_FOLDERS FOL ON FOL.FOL_ID = $schema_evt.EERU_EVENT_RULES.FOL_ID";
		 $query .= "
      WHERE
         EERU_NAME ".tws_sqllike(db_string($composer_db,$evrule))." ";
      if ($tws_config['cpuinfo']['version']>='9.5002' && !empty($evrule_folder)) //jozsef
	 $query .= "  AND FOL.FOL_PATH = '$evrule_folder'";
	 $query .=" AND $sqlfilter
         $acc_sql
      ORDER BY ERAC_POSITION
      ";
   tws_log('DB query: '.$query);
   if (!($r=db_query($composer_db,$query))) {
      tws_log('Error: Database query failed');
      tws_error('', "Database query failed");
      return FALSE;
   }
   $tl=tws_log();
   if ($page_size > 0) {
      $page_down = ($page - 1) * $page_size;
      $page_up = $page * $page_size;
   }
   while ($row = db_fetch_row($composer_db)) {
      $tl && tws_log(@var_export($row, true));
      $actions['action_num']++;
      if ($page_size > 0) {
         if ($page_down >= $actions['action_num']) {
            while (($page_down > $actions['action_num']) && db_fetch_row($composer_db, null)) {
               $actions['action_num']++;
            }
            continue;
         }
         if ($page_up < $actions['action_num']) {
            while (($page_up < $actions['action_num']) && db_fetch_row($composer_db, null)) {
               $actions['action_num']++;
            }
            break;
         }
      }

      $actions['evrule_event_name'           ][] = $row['EERU_NAME'];
      $actions['evrule_action_type'          ][] = $row['ERAC_TYPE'];
      $actions['evrule_action_response_type' ][] = $row['ERAC_RESPONSE_TYPE'];
      $actions['evrule_action_plugin_name'   ][] = $row['ERAC_PLUGIN_NAME'];
      $parms=array();
      foreach(explode(',',preg_replace("/\\\\,/", '&coma;', $row['ERAC_PARAMETER_LIST'])) as $val) {
         $val=str_replace('&coma;',',',$val);
         $stdparm=explode('=',$val,2);
         if (count($stdparm)==2 && !isset($parms[$stdparm[0]])) {
            $parms[$stdparm[0]]=$stdparm[1];
         } else {
            $parms[]=$val;
         }
      }
      $actions['evrule_action_parameter_list'][] = $parms;
      $actions['evrule_action_description'   ][] = $row['ERAC_DESCRIPTION'];
      $actions['evrule_action_position'      ][] = $row['ERAC_POSITION'];
      $actions['evrule_action_scope'         ][] = $row['ERAC_SCOPE'];
      $actions['evrule_action_specialized'   ][] = $row['ERAC_SPECIALIZED'];
      $actions['evrule_action_job_workstation'            ][] = $row['JOD_WKC_NAME'];
      $actions['evrule_action_job'                        ][] = $row['JOD_NAME'];
      $actions['evrule_action_job_description'            ][] = $row['JOD_DESCRIPTION'];
      $actions['evrule_action_job_task'                   ][] = $row['JOD_TASK_STRING'];
      $actions['evrule_action_job_login'                  ][] = $row['JOD_USER_LOGIN'];
      $actions['evrule_action_jobstream_workstation'      ][] = $row['AJS_WKC_NAME'];
      $actions['evrule_action_jobstream'                  ][] = $row['AJS_NAME'];
      $actions['evrule_action_parameter_table'            ][] = $row['AJS_WKC_NAME'];
      $actions['evrule_action_parameter_table_description'][] = $row['AJS_NAME'];
	  if ($tws_config['cpuinfo']['version']>='9.5002'){
         if(empty($row['FOL_PATH']))
            $row['FOL_PATH'] = '/';
         $actions['evrule_folder'     ][] = $row['FOL_PATH'];
      }
   }
   tws_log('-- tws_get_evrule_actions (end up in '.basename(__FILE__).'['.__LINE__.'])');
   return $actions;
}

function tws_get_evrule_actions_from_post(&$post) {
//actions
   $actions=array();
   $actions['action_num']=0;
   if (is_array($post['evrule_event_act_position'])) {
      foreach ($post['evrule_event_act_position'] as $i=>$j) {
         $actions['action_num']++;
         $actions['evrule_action_position'][$i]=tws_gpc_get($post['evrule_event_act_position'][$j]);
         $actions['evrule_action_plugin_name'][$i]=tws_gpc_get($post['evrule_event_act_plugin_name'][$j]);
         $actions['evrule_action_type'][$i]=tws_gpc_get($post['evrule_event_act_type'][$j]);
         $actions['evrule_action_response_type'][$i]=tws_gpc_get($post['evrule_event_act_response_type'][$j]);
         $actions['evrule_action_description'][$i]=tws_gpc_get($post['evrule_event_act_description'][$j]);
         $actions['evrule_action_parameter_list'][$i]=array();
         foreach($post['evrule_event_act_value'][$j] as $attrid=>$attr_instances) {
            $attr_templ=new eda($attrid);
            $tws_attrid=$attr_templ->get_twsid();
            foreach ($attr_instances as $k=>$attr_vals) {
               $val=tws_gpc_get($attr_vals[0]);
               if ($attr_templ->get_basetype()=='tstamp') $val=tws_userdate_to_evtiso($val,null,!preg_match('/\d:\d/',$val));
               $actions['evrule_action_parameter_list'][$i][$tws_attrid]=$val;
            }
         }
      }
   }
   $actions['evrule_folder'][0]=tws_gpc_get($post['evrules']['evrule_folder'][0]);
   return $actions;
}


function tws_get_evrule_xml($evrules, $events, $actions) {
   global $tws_config, $event_cond_types, $event_act_types;
   $rule_type_enum=array('F'=>'filter', 'S'=>'set', 'Q'=>'sequence');
   $action_response_type_enum=array('D'=>'onDetection', 'T'=>'onTimeOut');

//header+general options
   $xml ='<?xml version="1.0"?>'."\n";
   $xml.='<eventRuleSet'." \t".'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"'."\n";
   $xml.="\t\t".'xmlns="http://www.ibm.com/xmlns/prod/tws/1.0/event-management/rules"'."\n";
   $xml.="\t\t".'xsi:schemaLocation="http://www.ibm.com/xmlns/prod/tws/1.0/event-management/rules http://www.ibm.com/xmlns/prod/tws/1.0/event-management/rules/EventRules.xsd">'."\n";
   if ($tws_config['cpuinfo']['version']>='9.5002') {
		$xml.="\t".'<eventRule name="'.htmlspecialchars($evrules['evrule_folder'][0]).htmlspecialchars($evrules['evrule_name'][0]).'" ruleType="'.$rule_type_enum[$evrules['evrule_type'][0]].'" isDraft="'.tws_yesno($evrules['evrule_draft'][0],'yes','no').'">'."\n";
   } else {
	   $xml.="\t".'<eventRule name="'.htmlspecialchars($evrules['evrule_name'][0]).'" ruleType="'.$rule_type_enum[$evrules['evrule_type'][0]].'" isDraft="'.tws_yesno($evrules['evrule_draft'][0],'yes','no').'">'."\n";
   }
if ($evrules['evrule_description'][0]!='') $xml.="\t\t".'<description>'.htmlspecialchars($evrules['evrule_description'][0]).'</description>'."\n";
if ($evrules['evrule_timezone'][0]!='') $xml.="\t\t".'<timeZone>'.htmlspecialchars($evrules['evrule_timezone'][0]).'</timeZone>'."\n";
if ($evrules['evrule_valid_from'][0]!='' || $evrules['evrule_valid_to'][0]!='') {
   $xml.="\t\t".'<validity'.($evrules['evrule_valid_from'][0]!='' ? ' from="'.htmlspecialchars($evrules['evrule_valid_from'][0]).'"' : '').($evrules['evrule_valid_to'][0]!='' ? ' to="'.htmlspecialchars($evrules['evrule_valid_to'][0]).'"' : '').'/>'."\n";
}
if ($evrules['evrule_start_offset'][0]!='' || $evrules['evrule_end_offset'][0]!='') {
    $xml.="\t\t".'<activeTime'.($evrules['evrule_start_offset'][0]!='' ? ' start="'.htmlspecialchars($evrules['evrule_start_offset'][0]).'"' : '').($evrules['evrule_end_offset'][0]!='' ? ' end="'.htmlspecialchars($evrules['evrule_end_offset'][0]).'"' : '').'/>'."\n";
}
if ($evrules['evrule_timeout'][0]!='') {
   $xml.="\t\t".'<timeInterval amount="'.htmlspecialchars($evrules['evrule_timeout'][0]).'" unit="seconds"/>'."\n";
}

//event conditions
if (is_array($events['evrule_event_name'])) {
   foreach ($events['evrule_event_name'] as $i=>$evrule_event_name) {
      $xml.="\t\t".'<eventCondition name="'.htmlspecialchars($evrule_event_name).'" eventProvider="'.$event_cond_types[$events['evrule_event_plugin_name'][$i]]['class']['twsid'].'" eventType="'.$event_cond_types[$events['evrule_event_plugin_name'][$i]][ $events['evrule_event_type'][$i] ]['twsid'].'">'."\n";
      $xml.="\t\t\t".'<filteringPredicate>'."\n";
      $xml.="\t\t\t\t".rtrim(str_replace('</attributeFilter>', "\n\t\t\t\t".'</attributeFilter>'."\n\t\t\t\t", str_replace('<value>',"\n\t\t\t\t\t".'<value>',$events['evrule_event_predicate'][$i])))."\n";
      $xml.="\t\t\t".'</filteringPredicate>'."\n";
      $xml.="\t\t".'</eventCondition>'."\n";
   }
}

//correlated attrs
if (count($evrules['evrule_attr_correlation'][0])) {
   $xml.="\t\t".'<correlationAttributes>'."\n";
   foreach ($evrules['evrule_attr_correlation'][0] as $val) {
      $xml.="\t\t\t".'<attribute name="'.htmlspecialchars($val).'"/>'."\n";
   }
   $xml.="\t\t".'</correlationAttributes>'."\n";
}

//actions
if (is_array($actions['evrule_action_type'])) {
   foreach ($actions['evrule_action_type'] as $i=>$evrule_action_type) {
      $xml.="\t\t".'<action actionProvider="'.$event_act_types[$actions['evrule_action_plugin_name'][$i]]['class']['twsid'].'" actionType="'. $event_act_types[$actions['evrule_action_plugin_name'][$i]][ $evrule_action_type ]['twsid'].'" responseType="'.$action_response_type_enum[$actions['evrule_action_response_type'][$i]].'">'."\n";
      if (trim($actions['evrule_action_description'][$i])!='') $xml.="\t\t\t".'<description>'.htmlspecialchars($actions['evrule_action_description'][$i]).'</description>'."\n";
      foreach ($actions['evrule_action_parameter_list'][$i] as $name=>$val) {
         $xml.="\t\t\t".'<parameter name="'.$name.'">'."\n\t\t\t\t".'<value>'.htmlspecialchars($val).'</value>'."\n\t\t\t".'</parameter>'."\n";
      }
      $xml.="\t\t".'</action>'."\n";
   }
}

//footer
   $xml.="\t".'</eventRule>'."\n".'</eventRuleSet>';
   return $xml;
}

///////////////////////////////////////////////////////////////////////////////
//
// List of event rules instance )event rules monitor)
//
// Arguments:
//    arg = event rule name (@=wildcard for all), or filter array (see $evmonfilter)
//    sqlcond = sql filteri - conditions of the where clause
//
function tws_get_evrule_instances($arg='@', $sqlfilter='', $page_size = 0, $page = 1, $od_callback=null, $action='LIST') {
   tws_log('-- tws_get_evmon (start at '.basename(__FILE__).'['.__LINE__.'])');
   global $tws_config, $composer_db;

   if(trim($sqlfilter)=='') $sqlfilter="1=1";

   $evrules=array();
   $evrules['evrule_num']=0;

   $evrules_conds=array();
   if (!is_array($arg)) $filter=tws_fetch_filter_to_array($arg);
   else $filter['evrules']=$arg;

   foreach ($filter['evrules'] as $x) $evrules_conds[]='LLRC_TEXT_1 '.tws_sqllike(db_string($composer_db,$x));
   if (is_array($filter['types'])) foreach ($filter['types'] as $x) $types_conds[]='LLRC_TYPE_1=\''.tws_typekey('EERU_TYPE',$x).'\'';
   if (is_array($filter['states'])) foreach ($filter['states'] as $x) $states_conds[]='LLRC_TYPE_2=\''.tws_typekey('ERI_STATUS',$x).'\'';
   if (is_array($filter['timeout'])) $timeout_cond='LLRC_TYPE_3=\''.tws_yesno($filter['timeout'][0],'Y','N').'\'';

//access rights checking
   if (($acc_sql=tws_sec_check('EVENTRULE', array('NAME'=>'LLRC_TEXT_1'), '', $action))===FALSE) return $evrules;

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if (!$dbh) {
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=isset($composer_db['schema_log']) ? $composer_db['schema_log'] : ($composer_db['type']=='db2' ? 'LOG' : $composer_db['schema']);
   $query ="
      SELECT
         LLRC_TIMESTAMP ERI_LOGTIME,
         LLRC_TEXT_1 ERI_NAME,
         LLRC_TYPE_1 ERI_TYPE,
         LLRC_TYPE_2 ERI_STATUS,
         LLRC_TYPE_3 ERI_TIMEOUT
      FROM ${schema}.LLRC_LOG_RECORDS
      WHERE
         LLRC_CATEGORY = 'R' AND
         ".(is_array($evrules_conds) ? '('.implode(' OR ',$evrules_conds).') AND' : '')."
         ".(is_array($types_conds) ? '('.implode(' OR ',$types_conds).') AND' : '')."
         ".(is_array($states_conds) ? '('.implode(' OR ',$states_conds).') AND' : '')."
         ".(isset($timeout_cond) ? $timeout_cond.' AND' : '')."
         $sqlfilter
         $acc_sql
      ORDER BY LLRC_TIMESTAMP";
   tws_log('DB query: '.$query);
   if (!($r=db_query($composer_db,$query))) {
      tws_log('Error: Database query failed');
      tws_error('', "Database query failed");
      return FALSE;
   }
   $tl=tws_log();
   if ($page_size > 0) {
      $page_down = ($page - 1) * $page_size;
      $page_up = $page * $page_size;
   }
   while ($row = db_fetch_row($composer_db)) {
      $tl && tws_log(@var_export($row, true));
      $evrules['evrule_num']++;
      if ($page_size > 0) {
         if ($page_down >= $evrules['evrule_num']) {
            while (($page_down > $evrules['evrule_num']) && db_fetch_row($composer_db, null)) {
               $evrules['evrule_num']++;
            }
            continue;
         }
         if ($page_up < $evrules['evrule_num']) {
            while (($page_up < $evrules['evrule_num']) && db_fetch_row($composer_db, null)) {
               $evrules['evrule_num']++;
            }
            break;
         }
      }
      $evrules['evrule_name'        ][] = $row['ERI_NAME'];
      $evrules['evrule_logtime'     ][] = $row['ERI_LOGTIME'];
      $evrules['evrule_type'        ][] = $row['ERI_TYPE'];
      $evrules['evrule_status'      ][] = $row['ERI_STATUS'];
      $evrules['evrule_timeout'     ][] = $row['ERI_TIMEOUT'];
   }
   tws_log('-- tws_get_evrule_instances ('.basename(__FILE__).'['.__LINE__.'])');
   return $evrules;
}

///////////////////////////////////////////////////////////////////////////////
//
// List of event rules instances actions (triggered actions)
//
// Arguments:
//    evrule = event rule name (@=wildcard for all)
//    sqlcond = sql filteri - conditions of the where clause
//
function tws_get_evrule_instances_actions($arg='@', $sqlfilter='', $page_size = 0, $page = 1, $od_callback=null, $action='LIST') {
   tws_log('-- tws_get_evrule_instances_actions (start at '.basename(__FILE__).'['.__LINE__.'])');
   global $tws_config, $composer_db;

   if(trim($sqlfilter)=='') $sqlfilter="1=1";

   $evrules=array();
   $evrules['evrule_num']=0;

   $evrules_conds=array();
   if (!is_array($arg)) $filter=tws_fetch_filter_to_array($arg);
   else $filter['evrules']=$arg;

   foreach ($filter['evrules'] as $x) $evrules_conds[]='LLRC_TEXT_1 '.tws_sqllike(db_string($composer_db,$x));
   if (is_array($filter['types'])) foreach ($filter['types'] as $x) $types_conds[]='UPPER(LLRC_TEXT_3)=\''.tws_typekey('ERAC_TYPE',$x).'\'';
   if (is_array($filter['states'])) foreach ($filter['states'] as $x) $states_conds[]='LLRC_TYPE_2=\''.tws_typekey('ERI_STATUS',$x).'\'';

//access rights checking
   if ($tws_config['cpuinfo']['version']>='9.4')
       $secsel = array ('PROVIDER'=>'*');
   else
       $secsel= array ('NAME'=>'LLRC_TEXT_1');
   if (($acc_sql=tws_sec_check('ACTION', $secsel, '', $action))===FALSE) return $evrules;
//FIXME:
   $acc_sql='';

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if (!$dbh) {
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=isset($composer_db['schema_log']) ? $composer_db['schema_log'] : ($composer_db['type']=='db2' ? 'LOG' : $composer_db['schema']);
   $query ="
      SELECT
         LLRC_TEXT_1 ERI_NAME,
         LLRC_TYPE_1 ERI_TYPE,
         LLRC_TEXT_4 ERI_ACTION_PROVIDER,
         LLRC_TEXT_2 ERI_ACTION_SCOPE,
         LLRC_TEXT_3 ERI_ACTION_TYPE,
         LLRC_TYPE_2 ERI_ACTION_STATUS,
         LLRC_TEXT_5 ERI_ACTION_RESULT,
         LLRC_MESSAGE ERI_MESSAGE,
         LLRC_TIMESTAMP ERI_LOGTIME
      FROM $schema.LLRC_LOG_RECORDS
      WHERE LLRC_CATEGORY = 'A' AND
         ".(is_array($evrules_conds) ? '('.implode(' OR ',$evrules_conds).') AND' : '')."
         ".(is_array($types_conds) ? '('.implode(' OR ',$types_conds).') AND' : '')."
         ".(is_array($states_conds) ? '('.implode(' OR ',$states_conds).') AND' : '')."
         $sqlfilter
         $acc_sql
      ORDER BY LLRC_TIMESTAMP";
   tws_log('DB query: '.$query);
   if (!($r=db_query($composer_db,$query))) {
      tws_log('Error: Database query failed');
      tws_error('', "Database query failed");
      return FALSE;
   }
   $tl=tws_log();
   if ($page_size > 0) {
      $page_down = ($page - 1) * $page_size;
      $page_up = $page * $page_size;
   }
   while ($row = db_fetch_row($composer_db)) {
      $tl && tws_log(@var_export($row, true));
      $evrules['evrule_num']++;
      if ($page_size > 0) {
         if ($page_down >= $evrules['evrule_num']) {
            while (($page_down > $evrules['evrule_num']) && db_fetch_row($composer_db, null)) {
               $evrules['evrule_num']++;
            }
            continue;
         }
         if ($page_up < $evrules['evrule_num']) {
            while (($page_up < $evrules['evrule_num']) && db_fetch_row($composer_db, null)) {
               $evrules['evrule_num']++;
            }
            break;
         }
      }
      $evrules['evrule_name'     ][] = $row['ERI_NAME'];
      $evrules['evrule_type'     ][] = $row['ERI_TYPE'];
      $evrules['erac_provider'   ][] = $row['ERI_ACTION_PROVIDER'];
      $evrules['erac_scope'      ][] = $row['ERI_ACTION_SCOPE'];
      $evrules['erac_type'       ][] = $row['ERI_ACTION_TYPE'];
      $evrules['erac_status'     ][] = $row['ERI_ACTION_STATUS'];
      $evrules['erac_result'     ][] = $row['ERI_ACTION_RESULT'];
      $evrules['erac_message'    ][] = $row['ERI_MESSAGE'];
      $evrules['erac_logtime'    ][] = $row['ERI_LOGTIME'];
   }
   tws_log('-- tws_get_evrule_instances_actions (end in '.basename(__FILE__).'['.__LINE__.'])');
   return $evrules;
}

///////////////////////////////////////////////////////////////////////////////
//
// List of event rules instances messages (operator messages)
//
// Arguments:
//    evrule = event rule name (@=wildcard for all)
//    sqlcond = sql filteri - conditions of the where clause
//
function tws_get_evrule_instances_messages($arg='@', $sqlfilter='', $page_size = 0, $page = 1, $od_callback=null, $action='LIST') {
   tws_log('-- tws_get_evrule_instances_messages (start at '.basename(__FILE__).'['.__LINE__.'])');
   global $tws_config, $composer_db;

   if(trim($sqlfilter)=='') $sqlfilter="1=1";

   $evrules=array();
   $evrules['evrule_num']=0;

   $evrules_conds=array();
   if (!is_array($arg)) $filter=tws_fetch_filter_to_array($arg);
   else $filter['evrules']=$arg;

   foreach ($filter['evrules'] as $x) $evrules_conds[]='LLRC_TEXT_1 '.tws_sqllike(db_string($composer_db,$x));
   if (is_array($filter['severities'])) foreach ($filter['severities'] as $x) $severities_conds[]='LLRC_INFORMATION_TYPE=\''.tws_typekey('LLRC_TYPE',$x).'\'';

//access rights checking
   if (($acc_sql=tws_sec_check('ACTION', array('NAME'=>'LLRC_TEXT_1'), '', $action))===FALSE) return $evrules;
//FIXME:
   $acc_sql='';

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if (!$dbh) {
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=isset($composer_db['schema_log']) ? $composer_db['schema_log'] : ($composer_db['type']=='db2' ? 'LOG' : $composer_db['schema']);
   $query ="
      SELECT
         LLRC_TEXT_1 ERI_NAME,
         LLRC_TYPE_1 ERI_TYPE,
         LLRC_TEXT_2 ERI_SCOPE,
         LLRC_TEXT_3 ERAC_TYPE,
         LLRC_TEXT_4 ERAC_PROVIDER,
         LLRC_TEXT_5 Line_of_business,
         LLRC_TEXT_6 Owner_group,
         LLRC_INFORMATION_TYPE LLRC_TYPE,
         LLRC_MESSAGE LLRC_MESSAGE,
         LLRC_TIMESTAMP LLRC_LOGTIME
      FROM ${schema}.LLRC_LOG_RECORDS
      WHERE LLRC_CATEGORY = 'M' AND
         ".(is_array($evrules_conds) ? '('.implode(' OR ',$evrules_conds).') AND' : '')."
         ".(is_array($severities_conds) ? '('.implode(' OR ',$severities_conds).') AND' : '')."
         $sqlfilter
         $acc_sql
      ORDER BY LLRC_TIMESTAMP";
   tws_log('DB query: '.$query);
   if (!($r=db_query($composer_db,$query))) {
      tws_log('Error: Database query failed');
      tws_error('', "Database query failed");
      return FALSE;
   }
   $tl=tws_log();
   if ($page_size > 0) {
      $page_down = ($page - 1) * $page_size;
      $page_up = $page * $page_size;
   }
   while ($row = db_fetch_row($composer_db)) {
      $tl && tws_log(@var_export($row, true));
      $evrules['evrule_num']++;
      if ($page_size > 0) {
         if ($page_down >= $evrules['evrule_num']) {
            while (($page_down > $evrules['evrule_num']) && db_fetch_row($composer_db, null)) {
               $evrules['evrule_num']++;
            }
            continue;
         }
         if ($page_up < $evrules['evrule_num']) {
            while (($page_up < $evrules['evrule_num']) && db_fetch_row($composer_db, null)) {
               $evrules['evrule_num']++;
            }
            break;
         }
      }
      $evrules['evrule_name'     ][] = $row['ERI_NAME'];
      $evrules['evrule_type'     ][] = $row['ERI_TYPE'];
      $evrules['evrule_scope'    ][] = $row['ERI_SCOPE'];
      $evrules['erac_type'       ][] = $row['ERI_ACTION_TYPE'];
      $evrules['erac_provider'   ][] = $row['ERAC_PROVIDER'];
      $evrules['erac_scope'      ][] = $row['ERI_ACTION_SCOPE'];
      $evrules['llrc_type'       ][] = $row['LLRC_TYPE'];
      $evrules['llrc_message'    ][] = $row['LLRC_MESSAGE'];
      $evrules['llrc_logtime'    ][] = $row['LLRC_LOGTIME'];
   }
   tws_log('-- tws_get_evrule_instances_messages (end in '.basename(__FILE__).'['.__LINE__.'])');
   return $evrules;
}

// Associative Array from XML
// usage:
/*
 $xml = new XMLReader();
      $xml->xml($xml_string);
      $array = tws_xml2assoc($xml);
      $xml->close();
*/
function tws_xml2assoc($xml) {
     $tree = null;
   while($xml->read()) {
         switch ($xml->nodeType) {
             case XMLReader::END_ELEMENT: return $tree;
             case XMLReader::ELEMENT:
                 $node = array('tag' => $xml->name, 'value' => $xml->isEmptyElement ? '' : tws_xml2assoc($xml));
                 if($xml->hasAttributes)
                     while($xml->moveToNextAttribute())
                         $node['attributes'][$xml->name] = $xml->value;
                 $tree[] = $node;
             break;
             case XMLReader::TEXT:
             case XMLReader::CDATA:
                 $tree .= $xml->value;
            break;
      }
         }
     return $tree;
 }


///////////////////////////////////////////////////////////////////////////////
//
// List of run cycle groups
// IWS 9.1
//
function tws_get_runcycles( $runcycle='@', $sqlfilter='1=1', $page_size = 0, $page = 1, $od_callback=null, $action='LIST') {
   tws_log('-- get_db_runcycle_list (start at '.basename(__FILE__).'['.__LINE__.'])');
   global $tws_config, $composer_db;

   $runcycles=array();
   $runcycles['runcycle_num']=0;

   $tmp = tws_divide_folder($runcycle);
   $runcycle = $tmp[1];
   $runc_folder = $tmp[0];

//access rights checking
//   if (($acc_sql=tws_sec_check('RUNCYGRP', array('NAME'=>'RCG_NAME'), '', $action))===FALSE) return $runcycles;
// this change is for me only!

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=$composer_db["schema"];
   $query ="
      SELECT
         RCG_ID,
         RCG_NAME,
         RCG_DESCRIPTION,
         RCG_MODIFY_OWNER,
         RCG_MODIFY_TIME,
         RCG_LOCK_OWNER,
         RCG_LOCK_TIME,
         RCG_TIME_DEPENDENT,
         RCG_START_OFFSET,
         RCG_DEADLINE_OFFSET,
         RCG_LATEST_START_OFFSET,
         RCG_LATEST_START_ACTION,
         RCG_SATURDAY_FREE,
         RCG_SUNDAY_FREE,
         RCG_REPEAT_INTERVAL,
         RCG_REPEAT_END_TIME,
         VAT.VAT_NAME VAT_NAME,
         CAL.CAL_NAME RCG_CALENDAR";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= ",
            FOL.FOL_PATH,
            RCG.VAT_ID  RCG_VAT_ID
            ";
      $query .= "
      FROM
         ($schema.RCG_RUN_CYCLE_GROUPS RCG
          LEFT JOIN $schema.VAT_VARIABLE_TABLES VAT ON RCG.VAT_ID=VAT.VAT_ID)
          LEFT JOIN $schema.CAL_CALENDARS CAL ON CAL.CAL_ID = RCG.CAL_ID";
      if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
            LEFT JOIN $schema.FOL_FOLDERS FOL ON FOL.FOL_ID = RCG.FOL_ID";
      $query .= "
      WHERE
         RCG_NAME ".tws_sqllike(db_string($composer_db, $runcycle)) ;
      if ($tws_config['cpuinfo']['version']>='9.5002' && !empty($runc_folder))
          $query .= "
          AND FOL_PATH = '$runc_folder'";
      $query .="AND
         $sqlfilter
         $acc_sql
      ";
   // RCG_REPEAT_INTERVAL and RCG_REPEAT_END_TIME are reserved only now

   tws_log('DB query: '.$query);
   if (!($r=db_query($composer_db,$query))) {
      tws_log('Error: Database query failed');
      tws_error('', 'Database query failed');
      return FALSE;
   }
   $tl=tws_log();
   if ($page_size > 0) {
      $page_down = ($page - 1) * $page_size;
      $page_up = $page * $page_size;
   }
   while ($row = db_fetch_row($composer_db)) {
      $tl && tws_log(@var_export($row, true));
      $runcycles['runcycle_num']++;
      if ($page_size > 0) {
         if ($page_down >= $runcycles['runcycle_num']) {
            while (($page_down > $runcycles['runcycle_num']) && db_fetch_row($composer_db, null))
               $runcycles['runcycle_num']++;
            continue;
         }
         if ($page_up < $runcycles['runcycle_num']) {
            while (($page_up < $runcycles['runcycle_num']) && db_fetch_row($composer_db, null))
               $runcycles['runcycle_num']++;
            break;
         }
      }
      // $runcycles['runcycle_id'          ][] = $row['RCG_ID'];
      $runcycles['runcycle_name'        ][] = $row['RCG_NAME'];
      $runcycles['rcg_description'      ][] = $row['RCG_DESCRIPTION'];
      $runcycles['runcycle_creator'     ][] = $row['RCG_MODIFY_OWNER'];
      $runcycles['runcycle_last_updated'][] = $row['RCG_MODIFY_TIME'];
      $runcycles['runcycle_lock_by'     ][] = $row['RCG_LOCK_OWNER'];
      $runcycles['runcycle_lock_on'     ][] = $row['RCG_LOCK_TIME'];

      $runcycles['rcg_time_dependent']     [] = $row['RCG_TIME_DEPENDENT'];
      $runcycles['rcg_start_offset']       [] = $row['RCG_START_OFFSET'];
      $runcycles['rcg_deadline_offset']    [] = $row['RCG_DEADLINE_OFFSET'];
      $runcycles['rcg_latest_start_offset'][] = $row['RCG_LATEST_START_OFFSET'];
      $runcycles['rcg_latest_start_action'][] = $row['RCG_LATEST_START_ACTION'];
      $runcycles['rcg_saturday_free']      [] = $row['RCG_SATURDAY_FREE'];
      $runcycles['rcg_sunday_free']        [] = $row['RCG_SUNDAY_FREE'];
      $runcycles['rcg_repeat_interval']    [] = $row['RCG_REPEAT_INTERVAL'];
      $runcycles['rcg_repeat_end_time']    [] = $row['RCG_REPEAT_END_TIME'];
      $runcycles['rcg_calendar']           [] = $row['RCG_CALENDAR'];
      $vat_name = $row['VAT_NAME'];
      if ($tws_config['cpuinfo']['version']>='9.5002'){
         if(empty($row['FOL_PATH']))
            $row['FOL_PATH'] = '/';
         $runcycles['rcg_folder']          [] = $row['FOL_PATH'];
         $composer_db2 =   $composer_db;
         tws_log(var_export($composer_db2, true));
         $vartable = tws_get_vartable_folder($composer_db2, $row['RCG_VAT_ID']);
        if (!empty($vartable))
            $vat_name = $vartable['FOL_PATH'] . $row['VAT_NAME'];
      }
      $runcycles['vat_name']               [] = $vat_name;
   }
   tws_log('-- get_db_runcycle_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
   return $runcycles;
}


///////////////////////////////////////////////////////////////////////////////
//
// Get Runcycle Group runcycle data (ON / EXCEPT)
// IWS 9.1

function tws_get_rcg_runcycle_data($rcg, $rc_type='*', $rc_inclusive='*', $sqlcond='1=1'){
   global $tws_config, $composer_db;

   tws_log("-- tws_get_rcg_runcycle_data for $rcg (start at ".basename(__FILE__).'['.__LINE__.'])');

   if( empty($rcg)) {
      tws_error("rcg='$rcg'", "Database query error - missing argument(s)");
      return FALSE;
   }
   $tmp = tws_divide_folder($rcg);
   $rcg = $tmp[1];
   $runc_folder = $tmp[0];
   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema = $composer_db['schema'];

   $query ="SELECT
            RCG_NAME,
            RCY_TYPE RC_TYPE,
            RCY_NAME RC_NAME,
            RCY_DESCRIPTION RC_DESCRIPTION,
            RCY_INCLUSIVE RC_INCLUSIVE,
            RCY_VALID_FROM RC_VALID_FROM,
            RCY_VALID_TO RC_VALID_TO,
            RCY_TIME_DEPENDENT RC_TIME_DEPENDENT,
            RCY_START_OFFSET RC_AT,
            RCY_LATEST_START_OFFSET RC_UNTIL,
            RCY_LATEST_START_ACTION RC_ONUNTIL,
            RCY_DEADLINE_OFFSET RC_DEADLINE,
            RCY_FREE_DAYS_RULE RC_FREEDAYSRULE,
            RCY_ICALENDAR RC_ICALENDAR,
            CAL.CAL_NAME CALENDARNAME,
            RCY_OFFSET_TYPE OFFSETTYPE,
            RCY_OFFSET_VALUE OFFSETVALUE,
            RCY_SUBSET SUBSET,
            RCY_SUBSET_OPERATOR RC_AND
            ".($tws_config['cpuinfo']['version']<='8.4' ? '' : ', VAT.VAT_NAME RC_VAT_NAME')."
            ".($tws_config['cpuinfo']['version']>='9.5002' ? ', FOL.FOL_PATH, VAT.VAT_ID' : ' ')."
         FROM (($schema.RCG_RUN_CYCLE_GROUPS RCG
             JOIN $schema.RCY_RUN_CYCLES RCY
             ON RCY.RCG_PARENT_ID = RCG.RCG_ID)
             ".($tws_config['cpuinfo']['version']<='8.4' ? '' : " LEFT JOIN $schema.VAT_VARIABLE_TABLES VAT ON RCY.VAT_ID = VAT.VAT_ID").")
             LEFT JOIN $schema.CAL_CALENDARS CAL
             ON CAL.CAL_ID = RCY.CAL_ID ";
        if ($tws_config['cpuinfo']['version']>='9.5002')
         $query .= "
            LEFT JOIN $schema.FOL_FOLDERS FOL ON FOL.FOL_ID = RCG.FOL_ID ";
         $query .= " WHERE
            RCG_NAME = '".db_string($composer_db,$rcg)."' AND
            ".($tws_config['cpuinfo']['version']>='9.5002' ? ' FOL.FOL_PATH = \''.$runc_folder.'\' AND ' : ' ')."
            RCY_TYPE ".tws_sqllike(db_string($composer_db,$rc_type))." AND
            RCY_INCLUSIVE ".tws_sqllike(db_string($composer_db,$rc_inclusive))." AND
            $sqlcond
         ORDER BY RCY_SUBSET, RC_INCLUSIVE DESC
            ";
                  // ORDER changed because we need always first ON, then EXCEPT
   tws_log('DB query: '.$query);

   if( !($r=db_query($composer_db,$query)) ){
      tws_error($query, 'Database query failed');
      return FALSE;
   }
   $stream2=Array(
      'rc'=>Array()
   );
   $i=0;
   $temp='';
   while ($row = db_fetch_row($composer_db)) {
      tws_log(var_export($row, true));
      $stream2['rc']['rc_type'][$i]=$row['RC_TYPE'];
      $stream2['rc']['rc_on_except'][$i]=tws_yesno($row['RC_INCLUSIVE']);
      if ($stream2['rc']['rc_on_except'][$i] == "YES") {
         $stream2['rc']['rc_on_except'][$i] = "ON";
      } else {
         $stream2['rc']['rc_on_except'][$i] = "EXCEPT";
      }
      $stream2['rc']['rc_name'][$i]=$row['RC_NAME'];
      $stream2['rc']['rc_description'][$i]=$row['RC_DESCRIPTION'];
      $stream2['rc']['rc_subset'][$i]=$row['SUBSET'];
      $stream2['rc']['rc_and'][$i]=$row['RC_AND'];

      $stream2['rc']['rc_freedaysrule'][$i]=tws_typeval('FREEDAYSRULE',$row['RC_FREEDAYSRULE']);
      if ( tws_yesno($row['RC_TIME_DEPENDENT']) == "YES") {
         $stream2['rc']['rc_time_dep']["$i"]="YES";
      } else {
         $stream2['rc']['rc_time_dep']["$i"]="NO";
      }
      $stream2['rc']['rc_validfrom'][$i]=tws_iso_to_userdate($row['RC_VALID_FROM']);
      $stream2['rc']['rc_validto'][$i]=tws_iso_to_userdate($row['RC_VALID_TO']);
      $vat_name = $row['RC_VAT_NAME'];
        if ($tws_config['cpuinfo']['version'] >= '9.5002') {
            $composer_db2 = $composer_db;
            if (!$dbh2)
                $dbh2 = db_connect($composer_db2, DB_PERSISTENT);
            $vartable = tws_get_vartable_folder($composer_db2, $row['VAT_ID']);
            if (!empty($vartable))
                $vat_name = $vartable['FOL_PATH'] . $row['VAT_NAME'];
      }
      $stream2['rc']['rc_parameter_table'][$i]=$vat_name;

      tws_get_at_time($row['RC_AT'],$stream2['rc']['rc_athour'][$i],$stream2['rc']['rc_atminute'][$i],$temp,$stream2['rc']['rc_atplusdays'][$i]);
      tws_get_at_time($row['RC_UNTIL'],$stream2['rc']['rc_untilhour'][$i],$stream2['rc']['rc_untilminute'][$i],$temp,$stream2['rc']['rc_untilplusdays'][$i]);
      $stream2['rc']['rc_onuntil'][$i]=tws_typeval('ONUNTIL',$row['RC_ONUNTIL']);
      tws_get_at_time($row['RC_DEADLINE'],$stream2['rc']['rc_deadlinehour'][$i],$stream2['rc']['rc_deadlineminute'][$i],$temp,$stream2['rc']['rc_deadlineplusdays'][$i]);
      switch ($row['RC_TYPE']) {
         case "R":
            // first ensure that the ICALENDAR field ends with semicolon:
            $row['RC_ICALENDAR']=preg_replace('/;+$/',';',rtrim($row['RC_ICALENDAR']).';');
            // parse ICalendar field now
            $parts=explode(';',$row['RC_ICALENDAR']);
            $stream2['rc']['rc_freq'][$i]=substr($parts[0],strpos($parts[0],'=')+1);
            if (trim(substr($parts[1],0,9))=='INTERVAL=') {
               $stream2['rc']['rc_interval'][$i]=substr($parts[1],9);
            } else {
               // no interval (==1) (last part=='')
               $stream2['rc']['rc_interval'][$i]=1;
               $parts[2]=$parts[1];
            }
            if (@($pos=strpos($parts[2],"="))!==FALSE) {
               $stream2['rc']['rc_bydays'][$i]=substr($parts[2],$pos+1);
            } else {
               @$stream2['rc']['rc_bydays'][$i]=$parts[2];
            }
            // if montly, set correct type of monthly
            if ($stream2['rc']['rc_freq'][$i]=='MONTHLY') {
               $days=explode(",",$stream2['rc']['rc_bydays'][$i]);
               foreach ($days as $day) {
                  if (!is_numeric($day)) $stream2['rc']['rc_freq'][$i] = "MONTHLY2";
               }
            }
            break;
         case "C":   // Calendar
            $stream2['rc']['calendar'][$i]=$row['CALENDARNAME'];
            $stream2['rc']['offsettype'][$i]=tws_typeval('CAL_OFFSET_TYPE',$row['OFFSETTYPE']);
            $stream2['rc']['offsetvalue'][$i]=$row['OFFSETVALUE'];
            break;
         case "S":  // Single Dates
            $dates=explode(",",$row['RC_ICALENDAR']);
            $s=0;
            foreach ($dates as $date) {
               //$stream2['date']['date_on_except'][$i]=tws_yesno($row['RC_INCLUSIVE']);
               if (preg_match("/^([0-9]{4})([0-9]{2})([0-9]{2})/",$date, $dat)) {
                  //$stream2['rc']['date_year'][$i][$s]=$dat[1];
                  //$stream2['rc']['date_month'][$i][$s]=$dat[2];
                  $stream2['rc']['date_day'][$i][$s]= tws_iso_to_userdate($dat[1]."-".$dat[2]."-".$dat[3], null, true);
               $s++;
            }
            }
            break;
      }
      $i++;
   }
   $stream2['rc']['rc_num']=$i;
   return $stream2;
}


   // function made from tws_add_jobstream_exec
   // gather RC definition from form fields
   // used in tws_add_jobstream_exec.php & tws_add_runcycle_exec.php
   // return runcycle definition for composer

function tws_get_rc_def_from_form($values=NULL){
   //2016-05-12: Proecessing $values added by RS to fix the problem with missing RunCycles in IWD/ProcMan
   if ($values!==NULL) foreach($values as $key => $value) $$key=$value;
   else
      foreach($_POST as $key => $value){
         $$key=tws_gpc_get($value);
         $values[$key] = $value;
      }
   $cmd = array();

   if ($freedays_option == "specify") {
      if ($freedays_calendar != "" && tws_check_arg($freedays_calendar, 'tws_name')) {
         $cmd[] = " FREEDAYS " . $freedays_calendar;
         if ($freedays_sat != "YES")
            $cmd[] = " -SA";
         if ($freedays_sun != "YES")
            $cmd[] = " -SU";
         $cmd[] = "\n";
      }
   }

   if (empty($rc_on_except))
      return $cmd;

   $on_string=$except_string="";

   foreach ($rc_on_except as $key => $value){
      if (($value == "ON") && (trim($rc_name[$key])!="")) {
         $on_string = " ON ";

         $on_string .= tws_gather_rc_def($values, $key);
/*
         if($rc_type[$key] == 'G' && !empty($rcg[$key]))
            $on_string .= "RUNCYCLE RCG".++$rnum;
         elseif (trim($rc_name[$key])!="" && tws_check_arg($rc_name[$key], 'tws_name'))
            $on_string .= " RUNCYCLE ".$rc_name[$key];

         if ($rc_validfrom[$key]!="" && tws_check_arg($rc_validfrom[$key], 'tws_datetime')) {
            $rc_validfrom[$key] = tws_userdate_to_iso($rc_validfrom[$key], null, true);
            $on_string .= " VALIDFROM ".tws_date_from_iso($rc_validfrom[$key]);
         }
         if ($rc_validto[$key]!="" && tws_check_arg($rc_validto[$key], 'tws_datetime')) {
            $rc_validto[$key] = tws_userdate_to_iso($rc_validto[$key], null, true);
            $on_string .= " VALIDTO ".tws_date_from_iso($rc_validto[$key]);
         }
         $on_string .= " ";
         if ($rc_description[$key] != "")
            $on_string .= " DESCRIPTION \"".addcslashes($rc_description[$key],'"')."\" ";
         if ($rc_parameter_table[$key] != "" && tws_check_arg($rc_parameter_table[$key], 'tws_name'))
            $on_string .= " VARTABLE ".$rc_parameter_table[$key];

         switch ($rc_type[$key]) {
            case "R" : // Run Cycle specs
               if ($rc_freq[$key]=="MONTHLY2")
                  $on_string .= " \"FREQ=MONTHLY;";
               else
                  $on_string .= " \"FREQ=".$rc_freq[$key].";";

               if (($rc_interval[$key]!="") && ($rc_interval[$key]!=1)) $on_string .= "INTERVAL=".$rc_interval[$key].";";
               if ($rc_freq[$key]=="DAILY" && $rc_bydays[$key]!="") $on_string .= $rc_bydays[$key].";";
               if ($rc_freq[$key]=="WEEKLY") $on_string .= "BYDAY=".$rc_bydays[$key].";";
               if ($rc_freq[$key]=="MONTHLY") $on_string .= "BYMONTHDAY=".$rc_bydays[$key].";";
               if ($rc_freq[$key]=="MONTHLY2") $on_string .= "BYDAY=".$rc_bydays[$key].";";
               $on_string .= "\" ";
               break;
            case "C" : //Calendar specs
               $on_string .= ' '.$calendar[$key];
               if ($offsettype[$key]!="" && $offsetvalue[$key]!="") $on_string .= ' '.tws_sigint($offsetvalue[$key]).' '.$offsettype[$key];
               $on_string .= ' ';
               break;
            case "S" : //Single Dates
               $dates=array();
               foreach ($date_day[$key] as $s=>$val) {
                  $tmpdate = tws_userdate_to_iso ($date_day[$key][$s]);
                  $dates[]=tws_date_from_iso($tmpdate);
               }
               $on_string.=' '.implode(',', $dates).' ';
               break;
            case "G":   // RCG
               $on_string .= " \$RCG $rcg[$key] ";
               if ($rcg_offsettype[$key]!="" && $rcg_offsetvalue[$key]!="")
                  $on_string .= tws_sigint($rcg_offsetvalue[$key]).' '.$rcg_offsettype[$key];
               break;
         }

         $on_string .= " ".$rc_freedaysrule[$key]."\n";
         //time_dep
//         if ($rc_time_dep[$key]=="YES" || $rc_athour[$key] != "")  wrong condition!
         if (($dep_str=get_time_dep_string($values, $key))!="")
            $on_string .= "   ($dep_str)\n";
*/
         $cmd[] = $on_string;
      }
   }
   foreach ($rc_on_except as $key => $value){
      if ($value == "EXCEPT") {
         $except_string = " EXCEPT ";

         $except_string .= tws_gather_rc_def($values, $key);
/*
         if($rc_type[$key] == 'G' && !empty($rcg[$key]))
            $except_string .= "RUNCYCLE RCG".++$rnum." \$RCG $rcg[$key]\n";
         elseif (trim($rc_name[$key])!="" && tws_check_arg($rc_name[$key], 'tws_name'))
            $except_string .= " RUNCYCLE ".$rc_name[$key];

         if ( $rc_validfrom[$key]!="") {
            $rc_validfrom[$key] = tws_userdate_to_iso($rc_validfrom[$key], null, true);
            $except_string .= " VALIDFROM ".tws_date_from_iso($rc_validfrom[$key]);
         }
         if ($rc_validto[$key]!="" && tws_check_arg($rc_validto[$key], 'tws_datetime') ) {
            $rc_validto[$key] = tws_userdate_to_iso($rc_validto[$key], null, true);
            $except_string .= " VALIDTO ".tws_date_from_iso($rc_validto[$key]);
         }
         $except_string .= "";
         if ($rc_description[$key] != "")
            $except_string .= " DESCRIPTION \"".addcslashes($rc_description[$key],'"')."\" ";

         switch ($rc_type[$key]) {
            case "R" : // Run Cycle specs
               $except_string .= " \"FREQ=".$rc_freq[$key].";";
               if (($rc_interval[$key]!="") && ($rc_interval[$key]!=1)) $except_string .= "INTERVAL=".$rc_interval[$key].";";
               if ($rc_freq[$key]=="DAILY" && $rc_bydays[$key]!="") $except_string .= $rc_bydays[$key].";";
               if ($rc_freq[$key]=="WEEKLY") $except_string .= "BYDAY=".$rc_bydays[$key].";";
               if ($rc_freq[$key]=="MONTHLY") $except_string .= "BYMONTHDAY=".$rc_bydays[$key].";";
               if ($rc_freq[$key]=="MONTHLY2") $except_string .= "BYDAY=".$rc_bydays[$key].";";
               $except_string .="\" ";
               break;
            case "C" : //Calendar specs
               $except_string .= ' '.$calendar[$key];
               if ($offsettype[$key]!="" && $offsetvalue[$key]!="") $except_string .= ' '.tws_sigint($offsetvalue[$key]).' '.$offsettype[$key];
               $except_string .= ' ';
               break;
            case "S" : //Single Dates
               $dates=array();
               foreach ($date_day[$key] as $s=>$val) {
                  $tmpdate = tws_userdate_to_iso ($date_day[$key][$s]);
                  $dates[]=tws_date_from_iso($tmpdate);
               }
               $except_string.=' '.implode(',', $dates).' ';
               break;
         }

         $except_string .= $rc_freedaysrule[$key]."\n";
         //time_dep
         if ($rc_time_dep[$key]=="YES" || $rc_athour[$key] != "")
            if (($dep_str=get_time_dep_string($values, $key))!="") $except_string .= "   ($dep_str)\n";
 */
         $cmd[] = $except_string;
      }
   }
   return $cmd;
}

// used in previous function
function tws_gather_rc_def($values, $key){

   foreach($values as $var => $value) $$var=$value;

   if (trim($rc_name[$key])!="" && tws_check_arg($rc_name[$key], 'tws_name'))
      $on_string .= "RUNCYCLE ".$rc_name[$key];

   if ($rc_validfrom[$key]!="" && tws_check_arg($rc_validfrom[$key], 'tws_datetime')) {
      $rc_validfrom[$key] = tws_userdate_to_iso($rc_validfrom[$key], null, true);
      $on_string .= " VALIDFROM ".tws_date_from_iso($rc_validfrom[$key]);
   }
   if ($rc_validto[$key]!="" && tws_check_arg($rc_validto[$key], 'tws_datetime')) {
      $rc_validto[$key] = tws_userdate_to_iso($rc_validto[$key], null, true);
      $on_string .= " VALIDTO ".tws_date_from_iso($rc_validto[$key]);
   }
   $on_string .= " ";
   if ($rc_description[$key] != "")
      $on_string .= " DESCRIPTION \"".addcslashes($rc_description[$key],'"')."\" ";
   if ($rc_parameter_table[$key] != "" && tws_check_arg($rc_parameter_table[$key], 'tws_name'))
      $on_string .= " VARTABLE ".$rc_parameter_table[$key];

   switch ($rc_type[$key]) {
      case "R" : // Run Cycle specs
         if ($rc_freq[$key]=="MONTHLY2")
            $on_string .= " \"FREQ=MONTHLY;";
         else
            $on_string .= " \"FREQ=".$rc_freq[$key].";";

         if ($rc_interval[$key]!="") $on_string .= "INTERVAL=".$rc_interval[$key].";";
         if ($rc_freq[$key]=="DAILY" && $rc_bydays[$key]!="") $on_string .= $rc_bydays[$key].";";
         if ($rc_freq[$key]=="WEEKLY") $on_string .= "BYDAY=".$rc_bydays[$key].";";
         if ($rc_freq[$key]=="MONTHLY") $on_string .= "BYMONTHDAY=".$rc_bydays[$key].";";
         if ($rc_freq[$key]=="MONTHLY2") $on_string .= "BYDAY=".$rc_bydays[$key].";";
         $on_string .= "\" ";
         break;
      case "C" : //Calendar specs
         $on_string .= ' '.$calendar[$key];
         if ($offsettype[$key]!="" && $offsetvalue[$key]!="") $on_string .= ' '.tws_sigint($offsetvalue[$key]).' '.$offsettype[$key];
         $on_string .= ' ';
         break;
      case "S" : //Single Dates
         $dates=array();
         foreach ($date_day[$key] as $s=>$val) {
            $tmpdate = tws_userdate_to_iso ($date_day[$key][$s]);
            $dates[]=tws_date_from_iso($tmpdate);
         }
         $on_string.=' '.implode(',', $dates).' ';
         break;
      case "G":   // RCG
         $on_string .= " \$RCG $rcg[$key] ";
         if ($rcg_offsettype[$key]!="" && $rcg_offsetvalue[$key]!="")
            $on_string .= tws_sigint($rcg_offsetvalue[$key]).' '.$rcg_offsettype[$key];

         break;
   }
   $on_string .= " ".$rc_freedaysrule[$key];
// Subsets + OR/AND
   if(!empty($rc_subset[$key])){
      $on_string .= " SUBSET ".$rc_subset[$key];
      if(!empty($rc_and[$key]) && $rc_and[$key] == 'A')
         $on_string .= " AND ";
      else $on_string .= " OR ";
   }
   $on_string .= "\n";
   if (($dep_str=get_time_dep_string($values, $key))!="")
      $on_string .= " ($dep_str)\n";
   return $on_string;
}
//    Removed from tws_add_jobstream_exec.php
//    used in previous function
//
function get_time_dep_string($values, $key) {
   global $tws_config;
   foreach($values as $k=>$v) $$k=$v;

   $timedep_string="";
   if (($rc_athour[$key] != "") && ($rc_atminute[$key] != "")) {
      if($rc_time_dep[$key] == 'YES')
         $timedep_string .= "AT " . $rc_athour[$key] . $rc_atminute[$key];
      else $timedep_string .= "SCHEDTIME " . $rc_athour[$key] . $rc_atminute[$key];
      if ($rc_atplusdays[$key] != "") {
         $timedep_string .= " +".$rc_atplusdays[$key]." DAYS";
      }
   }
   if (($rc_untilhour[$key] != "") && ($rc_untilminute[$key] != "")) {
      if($tws_config['cpuinfo']['version']>'9.4' && empty($rc_jsuntil[$key]))
         $timedep_string .=" JSUNTIL " . $rc_untilhour[$key] . $rc_untilminute[$key];
      else
         $timedep_string .=" UNTIL " . $rc_untilhour[$key] . $rc_untilminute[$key];
      if (trim($rc_untilplusdays[$key]) != "") {
         $timedep_string .= " +".$rc_untilplusdays[$key]." DAYS";
      }
      if ($rc_onuntil[$key] == "CONT") {
         $timedep_string .= "  ONUNTIL CONT";
      } elseif ($rc_onuntil[$key] == "CANC") {
         $timedep_string .= "  ONUNTIL CANC";
      }
   }
   if (($rc_deadlinehour[$key] != "") && ($rc_deadlineminute[$key] != "")) {
      $timedep_string .=" DEADLINE " . $rc_deadlinehour[$key] . $rc_deadlineminute[$key];
      if ($rc_deadlineplusdays[$key] != "") {
         $timedep_string .= " +".$rc_deadlineplusdays[$key]." DAYS";
      }
   }
   if(!empty($rc_everyhour[$key])){
      $timedep_string .=" EVERY " . $rc_everyhour[$key] . $rc_everyminute[$key];
      $timedep_string .=" EVERYENDTIME " . $rc_everyendhour[$key] . $rc_everyendminute[$key];
      if ($rc_everyendplusdays[$key] != "") {
         $timedep_string .= " +".$rc_everyendplusdays[$key]." DAYS";
      }
   }
   return $timedep_string;
}

// List of workload applications (IWS 9.1)

function tws_get_applications($app='@', $sqlfilter='', $page_size = 0, $page = 1) {
   global $tws_config, $composer_db;
   tws_log('-- get_db_applications_list (start at '.basename(__FILE__).'['.__LINE__.'])');

   if(trim($sqlfilter)=='') $sqlfilter="1=1";

   $apps=array();
   $apps['app_num']=0;

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if (!$dbh) {
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=$composer_db["schema"];
   $query ="
   SELECT BHA_ID, BHA_NAME, BHA_DESCRIPTION, BHA_MODIFY_OWNER, BHA_MODIFY_TIME, BHA_LOCK_OWNER LO, BHA_LOCK_TIME LT
   FROM $schema.BHA_BATCH_APPLICATIONS
   WHERE
      BHA_NAME ".tws_sqllike(db_string($composer_db, $app))." AND
      $sqlfilter
   ORDER BY BHA_NAME
   ";
   tws_log('DB query: '.$query);
   if (!($r=db_query($composer_db,$query))) {
      tws_log('Error: Database query failed');
      tws_error('', "Database query failed");
      return FALSE;
   }
   $tl=tws_log();
   if ($page_size > 0) {
      $page_down = ($page - 1) * $page_size;
      $page_up = $page * $page_size;
   }
   while ($row = db_fetch_row($composer_db)) {
      $tl && tws_log(@var_export($row, true));
      $apps['app_num']++;
      if ($page_size > 0) {
         if ($page_down >= $apps['app_num']) {
            while (($page_down > $apps['app_num']) && db_fetch_row($composer_db, null))
               $apps['app_num']++;
            continue;
         }
         if ($page_up < $apps['app_num']) {
            while (($page_up < $apps['app_num']) && db_fetch_row($composer_db, null))
               $apps['app_num']++;
            break;
         }
      }
      $apps['app_id'          ][] = $row['BHA_ID'];
      $apps['app_name'        ][] = $row['BHA_NAME'];
      $apps['app_description' ][] = $row['BHA_DESCRIPTION'];
      $apps['app_creator'     ][] = $row['BHA_MODIFY_OWNER'];
      $apps['app_last_updated'][] = $row['BHA_MODIFY_TIME'];
      $apps['app_lock_by'   ][] = $row['LO'];
      $apps['app_lock_on'   ][] = $row['LT'];
   }
   tws_log('-- get_db_applications_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
   return $apps;
}

// Get workload application content (IWS 9.1)

function tws_get_app_data( $app ){
   global $tws_config, $composer_db;
   if (empty($app)) {
      tws_error("", 'Missing application name');
      return FALSE;
   }
   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=$composer_db["schema"];
   $query = "SELECT JST.JST_ID, WKC_NAME, AJS_NAME
   FROM
      $schema.BHA_BATCH_APPLICATIONS BHA
      JOIN $schema.BAJ_BATCH_APPLICATIONS_JS BAJ ON BHA.BHA_ID = BAJ.BHA_ID
      JOIN $schema.JST_JOB_STREAMS JST ON BAJ.JST_ID = JST.JST_ID
      JOIN $schema.AJS_ABSTRACT_JOB_STREAMS AJS ON JST.AJS_ID = AJS.AJS_ID
      JOIN $schema.WKC_WORKSTATION_CLASSES WKC ON AJS.WKC_ID = WKC.WKC_ID
   WHERE
      BHA_NAME='".db_string($composer_db, $app)."'";

   if( !($r=db_query($composer_db,$query)) ){
      tws_error($query, 'Database query failed');
      return FALSE;
   }
   $app_data=array();
   while ($row = db_fetch_row($composer_db)) {
      $app_data['jst_id'][]=$row['JST_ID'];
      $app_data['workstation'][]=$row['WKC_NAME'];
      $app_data['jobstream'][]=$row['AJS_NAME'];
   }
   return $app_data;
}

// Lock workload application
function tws_app_lock($app){
   global $tws_config, $composer_db;

   if (empty($app)) {
      tws_err('Missing application name'); return FALSE;
   }
   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_err('Cannot connect to database'); return FALSE;
   }
   if (($db_app = tws_get_applications($app)) == FALSE){
      tws_err("Can't get application '$app'"); return FALSE;
   }
   if ($db_app['app_num'] != 1){
      tws_err("Can't get application '$app'"); return FALSE;
   }
   $app_id = bin2hex($db_app['app_id'][0]);
   $schema=$composer_db["schema"];
   $hex_id = ($composer_db['type']=='db2' ? "x'$app_id'" : "HEXTORAW('$app_id')");
   // If Locked
   $sql = "SELECT BHA_LOCK_OWNER FROM $schema.BHA_BATCH_APPLICATIONS
         WHERE BHA_ID = $hex_id";
   if( !db_query($composer_db, $sql) ){
      tws_err('Database query failed', $sql); return FALSE;
   }
   if ($row = db_fetch_row($composer_db)){
      if(!empty($row['BHA_LOCK_OWNER']) && $row['BHA_LOCK_OWNER'] != $_SERVER['PHP_AUTH_USER'])
         return FALSE;
   }

   $cur_time = ($composer_db['type']=='db2' ? 'CURRENT_TIMESTAMP-CURRENT_TIMEZONE' : 'SYS_EXTRACT_UTC(CURRENT_TIMESTAMP)');
   $sql = "UPDATE $schema.BHA_BATCH_APPLICATIONS SET
           BHA_LOCK_OWNER = '$_SERVER[PHP_AUTH_USER]',
           BHA_LOCK_TIME = $cur_time
         WHERE BHA_ID = $hex_id";
   if( !db_query($composer_db, $sql) ){
      tws_err('Database query failed', $sql); return FALSE;
   }
   if (isset($composer_db['allow_persistent']) && tws_yesno($composer_db['allow_persistent'])=='NO'){
      if( !db_commit($composer_db)){
         tws_err("Unable to COMMIT request."); return FALSE;
      }
   }
   return true;
}

// Unlock workload application
function tws_app_unlock($app){
   global $tws_config, $composer_db;

   if (empty($app)) {
      tws_err('Missing application name'); return FALSE;
   }
   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_err('Cannot connect to database'); return FALSE;
   }
   if (($db_app = tws_get_applications($app)) == FALSE){
      tws_err("Can't get application '$app'"); return FALSE;
   }
   if ($db_app['app_num'] != 1){
      tws_err("Can't get application '$app'"); return FALSE;
   }
   $app_id = bin2hex($db_app['app_id'][0]);
   $schema=$composer_db["schema"];
   $hex_id = ($composer_db['type']=='db2' ? "x'$app_id'" : "HEXTORAW('$app_id')");

   $sql = "UPDATE $schema.BHA_BATCH_APPLICATIONS SET
           BHA_LOCK_OWNER = NULL,
           BHA_LOCK_TIME = NULL
         WHERE BHA_ID = $hex_id";
   if( !db_query($composer_db, $sql) ){
      tws_err('Database query failed', $sql); return FALSE;
   }
   if (isset($composer_db['allow_persistent']) && tws_yesno($composer_db['allow_persistent'])=='NO'){
      if( !db_commit($composer_db)){
         tws_err("Unable to COMMIT request."); return FALSE;
      }
   }
   return true;
}

// function to get ID from DB
// usage: SELECT hex_fce()
function hex_fce() {
   global $composer_db;
         $hex_id = ($composer_db['type']=='db2' ? "x'$app_id'" : "HEXTORAW('$app_id')");

   $hex_fce = ($composer_db['type']=='db2' ? 'HEX' : 'RAWTOHEX');
   return $hex_fce;
}
?>