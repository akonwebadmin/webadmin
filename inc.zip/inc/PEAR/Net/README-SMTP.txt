Net_SMTP PEAR Plugin
Version: 1.7.1
Modification: None
License: /LICENSE/PEAR-NET_SMTP.txt
