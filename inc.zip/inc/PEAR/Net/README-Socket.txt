Net_Socket 
Version: 1.0.14 
Modification: None
License: /LICENSE/PEAR-NET_SOCKET.txt
