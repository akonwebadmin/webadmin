Text_Highlighter 0.7.3 
Modifications: None
License: LICENSE/PEAR-TEXT_HIGHLIGHTER.txt

