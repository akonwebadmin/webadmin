Auth_SASL
version: 1.0.6
modifications: none
license file : ../../../LICENSE/PEAR-AUTH_SASL.txt
