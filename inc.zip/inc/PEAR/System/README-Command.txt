System_Command PEAR Plugin
Versiion: 1.0.8
Modifications: 
   - added escaping arguments that starts with '-' but contains nonalphanumeric chars
License: /LICENSE/PEAR-SYSTEM_COMMAND.txt
