Crypt_Blowfish PEAR Plugin
Version: 1.1.0RC2
Modifications: Constructors of ALL Blowfish classes converted to PHP5 standards
License: /LICENSE/PEAR-CRYPT_BLOWFISH.txt
