XML_Util 
Version: 1.3.0
Modifications: none
License : /LICENSE/PEAR-XML_UTIL.txt
