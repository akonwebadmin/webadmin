PEAR 1.10.1 (version of main PEAR class)
Modifications: none
License: ../LICENSE/PEAR.txt
