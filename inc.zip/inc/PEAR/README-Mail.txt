Mail
Version: 1.3.0 
modifications: none
license file : ../../../LICENSE/PEAR-MAIL.txt
