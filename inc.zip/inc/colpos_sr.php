<?php
//   HORIZONT Software GmbH, Munich
//

   $col[1]=2;
   $len[1]=25;
   $col[2]=37;
   $len[2]=4;
   $col[3]=47;
   $len[3]=4;
   $col[4]=56;
   $len[4]=3;
   $col[5]=61;
   $len[5]=962;
?>