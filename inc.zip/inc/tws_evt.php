<?php
//   HORIZONT Software GmbH, Garmischer Str. 8, D-80339 Munchen
//


function evt_js() {
if (true):
?>
<script type="text/javascript">

$("#opener").click(function() {
   $("#dialog").dialog( "open" );
   return false;
});


function addaval(obj,defval) {
   var c=obj.clone();
   var hhh=c.html();
   if (c.html().search(/^ OR/)) {
      c.html(' OR ' + c.html());
   }
   c.children('input.data').attr('value',defval);
   obj.after(c);
}

function rmaval(obj) {
   var vals=obj.siblings('span');
   if (vals.length) {
      obj.remove();
   }
}

function update_correlated_attrs() {
   for (var i=0; i<edas.used_attrs.length; i++) {
      if (edas.conds_count>1 && edas.used_attrs[i]==edas.conds_count) {
         //show
         $('input[name="evrules[evrule_attr_correlation][0]['+edas.attr_names[i]+']"]').first().parent().show();
      } else {
         //hide, uncheck
         $('input[name="evrules[evrule_attr_correlation][0]['+edas.attr_names[i]+']"]').first().attr('checked',false);
         $('input[name="evrules[evrule_attr_correlation][0]['+edas.attr_names[i]+']"]').first().parent().hide();
      }
   }
}

function evrule_event_atc_remove(i,atc) {
//update the cond attrs register
   if (atc=='cond') {
      var evtype=$('input[name="evrule_event_cond_type['+i+']"]').attr('value');
      edas.cond_removed(evtype);
      update_correlated_attrs();
      update_evrule_type($('table[name="evrule_event_cond"]').length-1);
   }
   var t=$('[id="evrule_event_'+atc+'['+i+']"]');
   if (t) t.remove();
}

function evrule_event_plugin_name_changed(i) {
   var curr_val=$('select[name="evrule_event_plugin_name['+i+']"] option:selected').first().val();
   $('select[name="evrule_event_type['+i+']"] option[class="'+curr_val+'"]').each(function() {
      $(this).show();
   });
   $('select[name="evrule_event_type['+i+']"] option:selected').attr('selected','');
   $('select[name="evrule_event_type['+i+']"] option[class="'+curr_val+'"]:first').attr('disabled',true);
   $('select[name="evrule_event_type['+i+']"] option[class!="'+curr_val+'"]').each(function() {
      $(this).hide();
   });
}

function evrule_event_plugin_attr_op_changed(i, att_name, j,atc) {
   var curr_op=$('select[name="evrule_event_'+atc+'_operator['+i+']['+att_name+']['+j+']"] option:selected').first().val();
   var att_val_LO=$('[name="evrule_event_'+atc+'_value['+i+']['+att_name+']['+j+'][LO]"]');
   var att_val_HI=$('[name="evrule_event_'+atc+'_value['+i+']['+att_name+']['+j+'][HI]"]');
   var att_vals=$('[name="evrule_event_'+atc+'_value['+i+']['+att_name+']['+j+'][]"]');

   if (curr_op=='range') {
      att_vals.each(function() { $(this).parent().hide() });
      att_val_LO.each(function() { $(this).show() });
      att_val_HI.each(function() { $(this).show() });
   } else {
      att_vals.each(function() { $(this).parent().show() });
      att_val_LO.each(function() { $(this).hide() });
      att_val_HI.each(function() { $(this).hide() });
   }
}

function evrule_event_plugin_attr_remove(i,j,name,q,atc) {
   if (q!='!') {
      var n=0;
      if (q=='+') {
         //find all occurences of the same attribute
         $('[name*="evrule_event_'+atc+'_value['+i+']['+name+']"]').each(function() {
            if ($(this).attr('name')!='evrule_event_'+atc+'_value['+i+']['+name+']['+j+'][]' &&
                $(this).attr('name')!='evrule_event_'+atc+'_value['+i+']['+name+']['+j+'][LO]' &&
                $(this).attr('name')!='evrule_event_'+atc+'_value['+i+']['+name+']['+j+'][HI]') n++;
         });
      } else n=1;
      if (n>0) {
         var tr=$('[id="evrule_event_'+atc+'_attr['+i+']['+j+']"]');
         if (tr) tr.remove();
      }
   }
}

function evrule_event_new_attr_changed(i,atc) {
   var curr_opt=$('select[name="evrule_event_'+atc+'_new_attr['+i+']"] option:selected').first().val();
   var q=eda.get_quant(curr_opt);

   //test if the attribute is already present
   if (q!='?' || $('table[id="evrule_event_'+atc+'_attrs['+i+']"] tr.'+curr_opt).length==0) {
      var last_tr=$('[id="evrule_event_'+atc+'_attrs['+i+']"] tr:last');
      //   $.dump(last_tr);
      var new_id=parseInt((last_tr.attr('id').split(']['))[1])+1;
      var fn_call='attr_generator_'+curr_opt+'('+i+','+new_id+');';
      last_tr.after(eval(fn_call));
      evrule_event_plugin_attr_op_changed(i,curr_opt,new_id,atc);
   }
   //reset - rewind - the combobox
   $('select[name="evrule_event_'+atc+'_new_attr['+i+']"] option:selected').attr('selected','');
   $('select[name="evrule_event_'+atc+'_new_attr['+i+']"] option[value=""]').attr('selected','selected');
}

function evrule_event_atc_add_changed(atc) {
   var curr_opt=$('select[name="evrule_event_'+atc+'_add"] option:selected').first().val();
   var ev_atcs=$('table[name="evrule_event_'+atc+'"]');
   var new_i=0;
   if (ev_atcs && ev_atcs.length>0) {
      ev_atcs.each(function() {
         var id=$(this).attr('id');
         var n=parseInt(id.slice(id.indexOf('[')+1,id.indexOf(']')));
         if (n>=new_i) new_i=n+1;
      });
   } else {
      new_i=0;
      ev_atcs=$('#last_'+atc);
   }
   var fn_call='event_type_generator_'+curr_opt+'('+new_i+');';
   ev_atcs.last().after(eval(fn_call));
   $('[name*="evrule_event_'+atc+'_operator['+new_i+']"]').each(function() {
      var chunks=$(this).attr('name').split('][')
      evrule_event_plugin_attr_op_changed(new_i,chunks[1],parseInt(chunks[2]),atc);
   });

   //update the cond attrs register
   if (atc=='cond') {
      edas.cond_added(curr_opt);
      update_correlated_attrs();
      update_evrule_type(new_i+1);
   }

   //reset - rewind - the combobox
   $('select[name="evrule_event_'+atc+'_add"] option:selected').attr('selected','');
   $('select[name="evrule_event_'+atc+'_add"] option[value=""]').attr('selected','selected');
}

function update_evrule_type(n) {
   var new_opt='F';
   var curr_opt=$('select[name="evrules[evrule_type][0]"] option:selected').first().val();
   var new_opt=curr_opt;
   if (n==1) new_opt='F';
   else if (n>1 && curr_opt=='F') new_opt='S';
   if (new_opt!=curr_opt) {
      $('select[name="evrules[evrule_type][0]"] option:selected').attr('selected','');
      $('select[name="evrules[evrule_type][0]"] option[value="'+new_opt+'"]').attr('selected','selected');
   }
}

/**
* http://plugins.jquery.com/project/swap-jumble
*/
(function($){
   $.fn.swap = function(b){
       b = $(b)[0];
       var a = this[0];
       var t = a.parentNode.insertBefore(document.createTextNode(''), a);
       b.parentNode.insertBefore(a, b);
       t.parentNode.insertBefore(b, t);
       t.parentNode.removeChild(t);
       return this;
   };

   $.fn.jumble = function(){
      var max = this.length;
      for (var i=0; i<max*2; i++) {
         var a = Math.floor(Math.random()*max);
         var b = a;
         while (b==a)
            b = Math.floor(Math.random()*max);
         $(this[a]).swap(this[b]);
      }
      return this;
   };
})(jQuery);

function ca_picker_click(obj) {
   var field=$(obj).prev();
   var c='<dl>';
   $('table[id*="evrule_event_cond["]').each(function() {  //    <tr id="evrule_event_cond_attr[0][0]" class="filename"><td styl
      var cond_type=$(this).find('input[name*="evrule_event_cond_type["]').attr('value');
      var cond_name=$(this).find('input[name*="evrule_event_name["]').attr('value');
      c+='<dt><strong>'+cond_name+'</strong>'+' ('+cond_type+')</dt><dd style="padding-bottom:10px"><ul style="margin:0;padding:0">';
      // 3.1.0: only the defined event attributes
      // $(this).find('tr[id*="evrule_event_cond_attr["]').each(function() {
      //   var aaa=cond_name+'.'+$(this).attr('class');
      //   c+='<li><a class="attrpicker" name="'+aaa+'" href="#">'+$(this).attr('class')+'</a></li>';
      // });
      var cas=eval('edas.'+cond_type);
      for (var i=0; i<cas.length; i++) {
         var arefname=cond_name+'.'+edas.attr_names[i];
         c+='<li><a class="attrpicker" name="'+arefname+'" href="#">'+edas.attr_names[i]+'</a></li>';
      }
      c+='</ul></dd>';
   });
   c+='</dl><p style="padding:0;margin:10px;border-top:solid 1px"><input id="variable_format" type="checkbox" checked/>Use machine readable format</p>'
   $('#dialog').html(c);

   $('a.attrpicker').click(function() {
      var vf='%';
      if ($('#dialog input#variable_format').attr('checked')) vf='$';
      field.val(field.val() + vf +'{'+$(this).attr('name')+'}');
      $('#dialog').dialog('close');
   });

   $('#dialog').dialog('open');
   return false;
}

$(function() {
   $('#last_act').after('<div id="dialog" title="Select a variable" style="padding:0"></div>');
   $('#dialog').dialog({
   autoOpen: false
   });
});


function evrule_event_atc_move(i,atc,dir) {
   var e1=$('table[id="evrule_event_'+atc+'['+i+']"]')
   if (dir=='up' && e1.prev().attr('name')=='evrule_event_'+atc) {
      e1.swap(e1.prev());
   } else if (dir=='down' && e1.next().attr('name')=='evrule_event_'+atc) {
      e1.swap(e1.next());
   }
// $.dump(evs.first());
}

function evrule_event_atc_collexp(i,atc,action,action_button) {
   var attr_tab=$('table[id="evrule_event_'+atc+'_attrs['+i+']"]');
   if ($(action_button).attr('value')=='_') {
      attr_tab.fadeOut();
      $('select[name="evrule_event_'+atc+'_new_attr['+i+']"]').hide();
      $(action_button).attr('value','^');
   } else {
      $('select[name="evrule_event_'+atc+'_new_attr['+i+']"]').show();
      attr_tab.fadeIn();
      $(action_button).attr('value','_');
   }
}

function evrule_collexp_all(atc, action, context) {
   var cx='';
   if (typeof(context)!="undefined") cx=context+' ';
   if (action=='collapse') {
      $(cx+'table[id*="evrule_event_'+atc+'_attrs"]').each(function() {
         $(this).hide();
      });
      $(cx+'select[name*="evrule_event_'+atc+'_new_attr"]').each(function() {
         $(this).hide();
      });
      $(cx+'input[name*="evrule_event_'+atc+'_collexp"]').each(function() {
        $(this).attr('value','^');
        $(this).show();
      });
   } else {
      $(cx+'table[id*="evrule_event_'+atc+'_attrs"]').each(function() {
         $(this).show();
      });
      $(cx+'select[name*="evrule_event_'+atc+'_new_attr"]').each(function() {
         $(this).show();
      });
      $(cx+'input[name*="evrule_event_'+atc+'_collexp"]').each(function() {
        $(this).attr('value','_');
        $(this).show();
      });
   }
}
</script>
<?php
endif;
}


   $event_cond_types=array(
      //
      //IMPORTANT NOTE: the key of each event type must be equal to strtolower(twsid)!!!!
      //
      'filemonitor'=>array('class' => array('name'=>'File Monitors',       'twsid'=>'FileMonitor'),
         'filecreated'           => array('name'=>'File Created',        'twsid'=>'FileCreated'),
         'filedeleted'           => array('name'=>'File Deleted',        'twsid'=>'FileDeleted'),
         'modificationcompleted' => array('name'=>'File Modified',       'twsid'=>'ModificationCompleted'),
         'logmessagewritten'     => array('name'=>'Log Message Written', 'twsid'=>'LogmessageWritten'),
      ),
      'twsobjectsmonitor'=>array('class' => array('name'=>'TWS Plan Events', 'twsid'=>'TWSObjectsMonitor'),
         'jobsubmit'                      => array('name'=>'Job Submit',                        'twsid'=>'JobSubmit'),
         'jobrestart'                     => array('name'=>'Job Restart',                       'twsid'=>'JobRestart'),
         'jobcancel'                      => array('name'=>'Job Cancel',                        'twsid'=>'JobCancel'),
         'joblate'                        => array('name'=>'Job Late',                          'twsid'=>'JobLate'),
         'jobuntil'                       => array('name'=>'Job Until',                         'twsid'=>'JobUntil'),
         //TWS9.x
         'jobpromoted'                    => array('name'=>'Job Promoted',                      'twsid'=>'JobPromoted'),
         'jobrisklevelchanged'            => array('name'=>'Job Risk Level Changed',            'twsid'=>'JobRiskLevelChanged'),
         'jobmaxdurationexceeded'         => array('name'=>'Job Exceeded Maximum Duration',     'twsid'=>'JobMaxDurationExceeded'),
         'jobmindurationnotreached'       => array('name'=>'Job Did not Reach Minimum Duration','twsid'=>'JobMinDurationNotReached'),
         'productalert'                   => array('name'=>'Product Alert',                     'twsid'=>'ProductAlert'),

         'jobstreamsubmit'                => array('name'=>'Jobstream Submit',                  'twsid'=>'JobStreamSubmit'),
         'jobstreamcancel'                => array('name'=>'Job Stream Cancel',                 'twsid'=>'JobStreamCancel'),
         'jobstreamstatuschanged'         => array('name'=>'Job Stream Status Changed',         'twsid'=>'JobStreamStatusChanged'),
         'jobstatuschanged'               => array('name'=>'Job Status Changed',                'twsid'=>'JobStatusChanged'),
         'jobstreamcompleted'             => array('name'=>'Job Stream Completed',              'twsid'=>'JobStreamCompleted'),
         'jobstreamuntil'                 => array('name'=>'Job Stream Until',                  'twsid'=>'JobStreamUntil'),
         'jobstreamlate'                  => array('name'=>'Job Stream Late',                   'twsid'=>'JobStreamLate'),
         'promptstatuschanged'            => array('name'=>'Prompt Status Changed',             'twsid'=>'PromptStatusChanged'),
         'workstationstatuschanged'       => array('name'=>'Workstation Status Changed',        'twsid'=>'WorkstationStatusChanged'),
         'childworkstationlinkchanged'    => array('name'=>'Child Workstation Link Changed',    'twsid'=>'ChildWorkstationLinkChanged'),
         'parentworkstationlinkchanged'   => array('name'=>'Parent Workstation Link Changed',   'twsid'=>'ParentWorkstationLinkChanged'),
         'applicationserverstatuschanged' => array('name'=>'Application Server Status Changed', 'twsid'=>'ApplicationServerStatusChanged'),
      ),
      'twsapplicationmonitor'=>array('class' => array('name'=>'TWS Application Monitor', 'twsid'=>'TWSApplicationMonitor'),
         'twsmessagequeues'  => array('name'=>'TWS Message Queues',  'twsid'=>'TWSMessageQueues'),
         'twsdiskmonitor'    => array('name'=>'TWS Disk Monitor',    'twsid'=>'TWSDiskMonitor'),
         'twsprocessmonitor' => array('name'=>'TWS Process Monitor', 'twsid'=>'TWSProcessMonitor'),
      ),
      'genericeventplugin'=>array('class' => array('name'=>'Custom Events', 'twsid'=>'GenericEventPlugin'),
         'event1' => array('name'=>'Generic Event', 'twsid'=>'Event1'),
      ),
   );

   $event_act_types=array(
      //
      //IMPORTANT NOTE: the key of each action type must be equal to strtolower(twsid)!!!!
      //
      'mailsender'=>array('class' => array('name'=>'Mail Sender', 'twsid'=>'MailSender'),
         'sendmail' => array('name'=>'Send Mail', 'twsid'=>'SendMail'),
      ),
      'twsaction'=>array('class' => array('name'=>'TWS Action', 'twsid'=>'TWSAction'),
         'sbs'   => array('name'=>'Submit Job Stream', 'twsid'=>'SBS'),
         'sbj'   => array('name'=>'Submit Job',        'twsid'=>'SBJ'),
         'sbd'   => array('name'=>'Submit Ad Hoc Job', 'twsid'=>'SBD'),
         'reply' => array('name'=>'Reply to Prompt',   'twsid'=>'Reply'),
      ),
      'genericactionplugin' => array('class' => array('name'=>'Generic Action Plug-In', 'twsid'=>'GenericActionPlugin'),
         'runcommand' => array('name'=>'Run Command', 'twsid'=>'RunCommand'),
       ),
      'teceventforwarder' => array('class' => array('name'=>'Tivoli Enterprise Console event forwarder', 'twsid'=>'TECEventForwarder'),
         'tecfwd' => array('name'=>'Forward event to Tivoli Enterprise Console', 'twsid'=>'TECFwd'),
      ),
      'messagelogger' => array('class' => array('name'=>'Message Logger','twsid'=>'MessageLogger'),
         'msglog' => array('name'=>'Message Logger', 'twsid'=>'MsgLog'),
      ),
   );

     class eda {
         static public $attr_types=array(
            //occurence: first char means 'attribute occurence', second char means 'number of one attribute values'
            //                                    display name                  type occurence opers wildcarsds default help-text
            'filename'                    => array('cond', 'FileName',                       'File Name',                         'string;x',     '!!:*',     '', 'The absolute path and filename of the specified file.'),
            'workstation'                 => array('cond', 'Workstation',                    'Workstation',                       'string;w',     '++=x',     '', 'The name of the workstation for which the event is generated.'),
            'workstations'                => array('cond', 'Workstation',                    'Workstation',                       'string;w',     '++=x',     '', 'The name of the workstation for which the event is generated.'),
            'sampleinterval'              => array('cond', 'SampleInterval',                 'Sample Interval',                      'int;s',     '+!:x',   '60', 'The interval (in seconds) with which the specified file is monitored.'),
            'hostname'                    => array('cond', 'HostName',                       'Host Name',                         'string;x',     '*+=*',     '', 'The fully qualified host name of the computer that sends the event.'),
            'hostname2'                   => array('cond', 'HostName',                       'Host Name',                         'string;x',     '0+=*',     '', 'The fully qualified host name of the computer that sends the event.'),
            'timestamp'                   => array('cond', 'TimeStamp',                      'Time Stamp',                          'tstamp',     '0!ix',     '', 'The time when the event is sent.'),
            'ipaddress'                   => array('cond', 'IPAddress',                      'IP Address',                        'string;x',     '0!:x',     '', 'The IP address of the computer that sends the event.'),
            'eventruleid'                 => array('cond', 'EventRuleID',                    'Event Rule ID',                     'string;x',     '0!:x',     '', 'The identifier of the event rule.'),
            'lastwritetime'               => array('cond', 'LastWriteTime',                  'Last Write Time',                     'tstamp',     '*+ix',     '', 'The time when the specified file was last modified.'),
            'matchexpression'             => array('cond', 'MatchExpression',                'Matches Expression',                'string;x',     '!!:x',     '', 'The string to look for in the log file(s) being monitored.'),
            'matches'                     => array('cond', 'Matches',                        'Number of Matches',                    'int;s',     '*+5x',     '', 'The number of matches found since monitoring started.'),
            'size'                        => array('cond', 'Size',                           'File Size',                            'int;l',     '*+ix',     '', 'The size of the log file (in bytes) when the most recent matching log file entry was found.'),
            'linetext'                    => array('cond', 'LineText',                       'Line text',                         'string;x',     '0!=x',     '', 'The contents of the line where the search string was found.'),
            'jobworkstation'              => array('cond', 'Workstation',                    'Job Workstation',                   'string;w',     '*+=*',    '*', 'The name of the workstation associated with the job instance.'),
            'jobstreamworkstation'        => array('cond', 'JobStreamWorkstation',           'Job Stream Workstation',            'string;w',     '++=*',    '*', 'The name of the workstation associated with the job stream containing the job instance.'),
            'jobstreamworkstation2'       => array('cond', 'JobStreamWorkstation',           'Job Stream Workstation',            'string;w',     '0+=*',    '*', 'The name of the workstation associated with the job stream containing the job instance.'),
            'jobstreamid'                 => array('cond', 'JobStreamID',                    'Job Stream ID',                     'string;x',     '0!=x',     '', 'The ID of the job stream instance containing the job instance (Sched ID).'),
            'jobstreamname'               => array('cond', 'JobStreamName',                  'Job Stream Name',                   'string;s',     '++=*',    '*', 'The name of the job stream instance containing the job instance.'),
            'jobstreamschedtime'          => array('cond', 'JobStreamSchedTime',             'Job Stream Scheduled Time',           'tstamp',     '*!ix',     '', 'The scheduled time of the job stream instance containing the job instance (Sched Time).'),
            'jobname'                     => array('cond', 'JobName',                        'Job Name',                          'string;j',     '++=*',    '*', 'The name of the job instance.'),
            'priority'                    => array('cond', 'Priority',                       'Priority',                             'int;p',     '*+5x',     '', 'The job priority.'),
            'monitored'                   => array('cond', 'Monitored',                      'Monitored',                             'bool',     '*!:x',     '', 'True if the job instance is key job.'),
            'actualstart'                 => array('cond', 'ActualStart',                    'Job Start Time',                      'tstamp',     '*!ix',     '', 'The actual start time of the job instance. Is significant only if he job has already started.'),
            'estimatedduration'           => array('cond', 'EstimatedDuration',              'Estimated Duration',                   'int;d',     '*!ix',     '', 'The estimated duration of the job. (seconds).'),
            'actualduration'              => array('cond', 'ActualDuration',                 'Actual Duration',                      'int;d',     '*!ix',     '', 'The actual duration of the job.'),
            'returncode'                  => array('cond', 'ReturnCode',                     'Return Code',                          'int;s',     '*+5x',     '', 'The return code of the job. It is significant only for completed or abended jobs.'),
            'lateststart'                 => array('cond', 'LatestStart',                    'Latest Start Time',                   'tstamp',     '*!ix',     '', 'The value of the until restriction of the job instance.'),
            'criticallateststart'         => array('cond', 'CriticalLatestStart',            'Critical Latest Start Time',          'tstamp',     '*!ix',     '', 'The value of the UNTIL critical restriction of the job instance.'),
            'deadline'                    => array('cond', 'Deadline',                       'Deadline',                            'tstamp',     '*!ix',     '', 'The value of the deadline restriction of the job instance.'),
            'status'                      => array('cond', 'Status',                         'Status',                             'enum;st',     '?+=x',     '', 'The new status of the job instance.'),
            'internalstatus'              => array('cond', 'InternalStatus',                 'Internal Status',                    'enum;is',     '?+=x',     '', 'The new internal status of the job instance.'),
            'internalstatus2'             => array('cond', 'InternalStatus',                 'Internal Status',                    'enum;is',     '0+=x',     '', 'The new internal status of the job instance.'),
            'streamstatus'                => array('cond', 'Status',                         'Status',                             'enum;sl',     '?+=x',     '', 'The new status of the job stream instance.'),
            'streamstatus2'               => array('cond', 'Status',                         'Status',                             'enum;sl',     '0+=x',     '', 'The new status of the job stream instance.'),
            'streaminternalstatus'        => array('cond', 'InternalStatus',                 'Internal Status',                    'enum;ia',     '?+=x',     '', 'The new internal status of the job stream instance.'),
            'untilaction'                 => array('cond', 'UntilAction',                    'UNTIL action',                       'enum;ua',     '?+=x',     '', 'The action taken after the until restriction time has elapsed.'),
            'login'                       => array('cond', 'Login',                          'Login',                             'string;x',     '*+=*',     '', 'The login of the user used to run the job.'),
            'everyfrequency'              => array('cond', 'EveryFrequency',                 'EVERY frequency',                      'int;d',     '*!ix',     '', 'The every frequency of the job instance.'),
            'errormessage'                => array('cond', 'ErrorMessage',                   'Error Message',                     'string;x',     '*+=*',     '', 'A message describing the cause of the job failure. It has significance only when the job instance goes in error (Fail) status.'),
            'plannumber'                  => array('cond', 'PlanNumber',                     'Plan Number',                          'int;s',     '0!:x',     '', 'The run number of the Plan running when the event was generated.'),
            'running'                     => array('cond', 'Running',                        'Running',                               'bool',     '*!:x',     '', 'Checked (TRUE) if the workstation is running. Unchecked (FALSE) if it is stopped.'),
            'stopreason'                  => array('cond', 'StopReason',                     'STOP Reason',                        'enum;sr',     '?+=x',     '', 'The reason why batchman (or jobman) was terminated. Significant only if one of them is not running.'),
            'stopreason2'                 => array('cond', 'StopReason',                     'STOP Reason',                        'enum;rs',     '0+=x',     '', 'The reason why the application server was terminated. Significant only if it is not running.'),
            'restarting'                  => array('cond', 'Restarting',                     'Restarting',                            'bool',     '*!:x',     '', 'True if the system will retry automatically to start the application server. Significant only if the application server is not running.'),
            'norestartreason'             => array('cond', 'NoRestartReason',                'No Restart Reason',                  'enum;rr',     '?+=x',     '', 'The reason why the system will not automatically start the application server. Is significant only if the application server is not running and Restarting is false.'),
            'workstation2'                => array('cond', 'Workstation',                    'Changed Child Workstation',         'string;w',     '++=*',    '*', 'The name of the child workstation that is changing link status.'),
            'parentworkstation'           => array('cond', 'ParentWorkstation',              'Parent Workstation',                'string;w',     '*+=*',     '', 'The name of the workstation that is sending the event.'),
            'linkstatus'                  => array('cond', 'LinkStatus',                     'Link Status',                        'enum;ls',     '?!=x',     '', 'The new link status of the workstation.'),
            'unlinkreason'                => array('cond', 'UnLinkReason',                   'UNLINK Reason',                      'enum;ur',     '0!=x',     '', 'Shows the reason why the workstation was unlinked. Available only if LinkStatus is Unlinked.'),
            'promptname'                  => array('cond', 'Name',                           'Prompt Name',                       'string;p',     '++=*',    '*', 'The name or the number of the prompt.'),
            'prompttext'                  => array('cond', 'Text',                           'Prompt Text',                       'string;x',     '*+=*',     '', 'The text of the prompt.'),
            'promptstatus'                => array('cond', 'Status',                         'Prompt Status',                      'enum;ps',     '?+=x',     '', 'The status of the prompt.'),
            'prompttype'                  => array('cond', 'Type',                           'Prompt Type',                        'enum;pt',     '?+=x',     '', 'The type of the prompt.'),
            'recoveryprompt'              => array('cond', 'RecoveryPrompt',                 'Recovery Prompt',                       'bool',     '*!:x',     '', 'Indicates if the prompt is a recovery prompt. Available only when the status is asked.'),
            'promptworkstation'           => array('cond', 'Workstation',                    'Workstation',                       'string;w',     '*+=*',     '', 'The name of the workstation associated with the job instance or job stream instance that owns the prompt. Available only for local prompts.'),
            'promptjobstreamworkstation'  => array('cond', 'JobStreamWorkstation',           'Job Stream Workstation',            'string;w',     '*+=*',     '', 'The name of the workstation associated with the job stream instance that owns the prompt (or that contains the job instance that owns the prompt). Available only for local prompts.'),
            'promptjobstreamid'           => array('cond', 'JobStreamID',                    'Job Stream ID',                     'string;x',     '*!:x',     '', 'The ID of the job stream instance that owns the prompt (or that contains the job instance that owns the prompt). Available only for local prompts.'),
            'promptjobstreamname'         => array('cond', 'JobStreamName',                  'Job Stream',                        'string;x',     '*+=*',     '', 'The name of the job stream instance that owns the prompt (or that contains the job instance that owns the prompt). Available only for local prompts.'),
            'promptjobstreamschedtime'    => array('cond', 'JobStreamSchedTime',             'Job Stream Scheduled Time',           'tstamp',     '*!ix',     '', 'The scheduled time of the job stream instance that owns the prompt (or that contains the job instance that owns the prompt). Available only for local prompts.'),
            'promptjobname'               => array('cond', 'JobName',                        'Job Name',                          'string;x',     '*+=*',     '', 'The name of the job instance that owns the prompt. Available only for local prompts owned by jobs.'),
            'param1'                      => array('cond', 'Param1',                         'Parameter 1',                       'string;x',     '++=*',     '', 'The value of parameter 1'),
            'fillingpercentage'           => array('cond', 'FillingPercentage',              'Filling Percentage',                   'int;p',     '!!x*',     '', 'The filling percentage.'),
            'mailboxname'                 => array('cond', 'MailboxName',                    'Mail Box Name',                      'enum;mb',     '!*=x',     '', 'The name of the Tivoli Workload Scheduler mailbox to monitor.'),
            'processname'                 => array('cond', 'ProcessName',                    'Process Name',                       'enum;pn',     '!*=x',     '', 'The name of the monitored Tivoli Workload Scheduler process.'),
            'mountpoint'                  => array('cond', 'MountPoint',                     'TWS Mount Point',                   'string;x',     '!*=x',     '', 'The mount point of the monitore Tivoli Workload Scheduler instance.'),
            'twspath'                     => array('cond', 'TWSPath',                        'TWS Path',                          'string;x',     '!*=x',     '', 'The fully qualified path where the Tivoli Workload Scheduler instance is installed.'),
            'sampleintervalo'             => array('cond', 'SampleInterval',                 'Sample Interval',                      'int;s',     '?!:x',   '60', 'The interval (in seconds) for monitoring the specified object.'),
            'severity3'                   => array('cond', 'Severity',                       'Severity',                           'enum;ev',     '?+=x',     '', 'The severity of the event.'),
            'risklevel'                   => array('cond', 'RiskLevel',                      'Job Risk Level',                     'enum;rl',     '?+=x',     '', 'The risk level of the job instance.'),
            'maxdurationaction'           => array('cond', 'MaxDurationAction',              'Maximum duration action',            'enum;xa',     '?+=x',     '', 'The action performed when the job duration exceeds the specified maximum duration.'),
            'mindurationaction'           => array('cond', 'MinDurationAction',              'Minimum duration action',            'enum;na',     '?+=x',     '', 'The action performed when the job duration is shorter than the specified minimum duration.'),

//actions attributes
            'host'                        => array('act',  'Host',                           'Host',                              'string;x',     '?!:x',     '', 'Host name or IP of the TEC recipient'),
            'port'                        => array('act',  'Port',                           'Port',                                 'int;s',     '?!:x',     '', 'Port number of the TEC recipient'),
            'message'                     => array('act',  'Message',                        'Message',                           'string;x',     '!!:x',     '', 'The event message'),
            'severity'                    => array('act',  'Severity',                       'Severity',                           'enum;sv',     '!!:x',     '', 'The severity of the event message'),
            'lob'                         => array('act',  'LOB',                            'Line of Business',                  'string;x',     '?!:x',     '', 'The line of business impacted by the situation reported by the event'),
            'parm_1'                      => array('act',  'Parm_1',                         'Parameter #1',                      'string;x',     '?!:x',     '', 'Custom Parameter #1'),
            'parm_2'                      => array('act',  'Parm_2',                         'Parameter #2',                      'string;x',     '?!:x',     '', 'Custom Parameter #2'),
            'parm_3'                      => array('act',  'Parm_3',                         'Parameter #3',                      'string;x',     '?!:x',     '', 'Custom Parameter #3'),
            'parm_4'                      => array('act',  'Parm_4',                         'Parameter #4',                      'string;x',     '?!:x',     '', 'Custom Parameter #4'),
            'parm_5'                      => array('act',  'Parm_5',                         'Parameter #5',                      'string;x',     '?!:x',     '', 'Custom Parameter #5'),
            'parm_6'                      => array('act',  'Parm_6',                         'Parameter #6',                      'string;x',     '?!:x',     '', 'Custom Parameter #6'),
            'parm_7'                      => array('act',  'Parm_7',                         'Parameter #7',                      'string;x',     '?!:x',     '', 'Custom Parameter #7'),
            'parm_8'                      => array('act',  'Parm_8',                         'Parameter #8',                      'string;x',     '?!:x',     '', 'Custom Parameter #8'),
            'parm_9'                      => array('act',  'Parm_9',                         'Parameter #9',                      'string;x',     '?!:x',     '', 'Custom Parameter #9'),
            'parm_10'                     => array('act',  'Parm_10',                        'Parameter #10',                     'string;x',     '?!:x',     '', 'Custom Parameter #10'),
            'to'                          => array('act',  'To',                             'To',                                'string;x',     '!!:x',     '', 'The main receiver list. Multiple addresses can be specified using commas as separators.'),
            'cc'                          => array('act',  'Cc',                             'Cc',                                'string;x',     '?!:x',     '', 'The copied receiver list. Multiple addresses can be specified using commas as separators.'),
            'bcc'                         => array('act',  'Bcc',                            'Bcc',                               'string;x',     '?!:x',     '', 'The blank copied receiver list. Multiple addresses can be specified using commas as separators.'),
            'subject'                     => array('act',  'Subject',                        'Subject',                           'string;x',     '!!:x',     '', 'The subject of the mail.'),
            'body'                        => array('act',  'Body',                           'Body',                                'text;x',     '?!:x',     '', 'The body of the mail.'),
            'severity2'                   => array('act',  'Severity',                       'Severity',                           'enum;sw',     '!!:x', 'Info', 'The severity of the message'),
            'objectkey'                   => array('act',  'ObjectKey',                      'Object Key',                        'string;x',     '!!:x',     '', 'A key identifying the object to which the message pertains.'),
            'source'                      => array('act',  'Source',                         'Source',                            'string;x',     '?!:x',     '', 'A custom string that identifies the source.'),
            'lob2'                        => array('act',  'LOB',                            'Line of Business',                  'string;x',     '?!:x',     '', 'The line of business impacted by the situation reported by the message.'),
            'group'                       => array('act',  'Group',                          'Group',                             'string;x',     '?!:x',     '', 'The group of operators in whose queue the message is placed.'),
            'jobstreamname2'              => array('act',  'JobStreamName',                  'Job Stream Name',                   'string;s',     '!!:x',     '', 'The name of the job stream.'),
            'jobstreamworkstationname2'   => array('act',  'JobStreamWorkstationName',       'Job Stream Workstation Name',       'string;w',     '!!:x',     '', 'The name of the workstation associated with the job stream.'),
            'jobstreamschedtime2'         => array('act',  'JobStreamSchedTime',             'Job Stream Scheduled Time',           'tstamp',     '?!:x',     '', 'The scheduled time of the jobstream instance.'),
            'jobstreamalias2'             => array('act',  'JobStreamAlias',                 'Job Stream Alias',                  'string;s',     '?!:x',     '', 'The job stream alias.'),
            'jobdefinitionname'           => array('act',  'JobDefinitionName',              'Job Name',                          'string;j',     '!!:x',     '', 'The name of the job as defined in the database.'),
            'jobdefinitionworkstationname'=> array('act',  'JobDefinitionWorkstationName',   'Job Workstation Name',              'string;w',     '!!:x',     '', 'The name of the workstation associated with the job as defined in the database.'),
            'jobjstreamname'              => array('act',  'JobJStreamName',                 'Job Stream Name',                   'string;s',     '?!:x',     '', 'The name of the job stream that contains the job.'),
            'jobjstreamworkstationname'   => array('act',  'JobJStreamWorkstationName',      'Job Stream Workstation Name',       'string;w',     '?!:x',     '', 'The name of the workstation associated with the job stream.'),
            'schedtimeresolutioncriteria' => array('act', 'SchedTimeResolutionCriteria','Job Stream SchedTime Resolution Criteria','enum;rc',     '?!:x',     '', 'The resolution criteria for the scheduled time of the job stream instance'),
            'jobalias'                    => array('act',  'JobAlias',                       'Job Alias',                         'string;j',     '?!:x',     '', 'The job alias.'),
            'jobuseuniquealias'           => array('act',  'JobUseUniqueAlias',              'Generate Unique Alias',                 'bool',     '!!:x', 'true', 'Generate a unique alias for the job.'),
            'jobtask'                     => array('act',  'JobTask',                        'Job Task',                          'string;x',     '!!:x',     '', 'The task to execute.'),
            'joblogin'                    => array('act',  'JobLogin',                       'Login',                             'string;x',     '!!:x',     '', 'The login name.'),
            'jobpriority'                 => array('act',  'JobPriority',                    'Priority',                             'int;p',     '?!:x',   '10', 'The job priority.'),
            'jobworkstationname'          => array('act',  'JobWorkstationName',             'Job Workstation',                   'string;w',     '!!:x',     '', 'The name of the workstation associated with the job.'),
            'jobtype'                     => array('act',  'JobType',                        'Job Type',                           'enum;jt',     '!!:x','Script','The job type.'),
            'promptname2'                 => array('act',  'PromptName',                     'Prompt Name',                       'string;p',     '!!:x',     '', 'The name of the prompt.'),
            'promptanswer'                => array('act',  'PromptAnswer',                   'Prompt Answer',                      'enum;yn',     '!!:x',     '', 'The reply to the prompt.'),
            'command'                     => array('act',  'Command',                        'Command',                           'string;x',     '!!:x',     '', 'The command that must be run.'),
            'workingdir'                  => array('act',  'WorkingDir',                     'Working directory',                 'string;x',     '?!:x',     '', 'The location where the command is to be run.'),
            'param01'                     => array('act',  'Param01',                        'Argument #1',                       'string;x',     '?!:x',     '', 'Command argument #1'),
            'param02'                     => array('act',  'Param02',                        'Argument #2',                       'string;x',     '?!:x',     '', 'Command argument #2'),
            'param03'                     => array('act',  'Param03',                        'Argument #3',                       'string;x',     '?!:x',     '', 'Command argument #3'),
            'param04'                     => array('act',  'Param04',                        'Argument #4',                       'string;x',     '?!:x',     '', 'Command argument #4'),
            'param05'                     => array('act',  'Param05',                        'Argument #5',                       'string;x',     '?!:x',     '', 'Command argument #5'),
            'param06'                     => array('act',  'Param06',                        'Argument #6',                       'string;x',     '?!:x',     '', 'Command argument #6'),
            'param07'                     => array('act',  'Param07',                        'Argument #7',                       'string;x',     '?!:x',     '', 'Command argument #7'),
            'param08'                     => array('act',  'Param08',                        'Argument #8',                       'string;x',     '?!:x',     '', 'Command argument #8'),
            'param09'                     => array('act',  'Param09',                        'Argument #9',                       'string;x',     '?!:x',     '', 'Command argument #9'),
            'param10'                     => array('act',  'Param10',                        'Argument #10',                      'string;x',     '?!:x',     '', 'Command argument #10'),
            'param11'                     => array('act',  'Param11',                        'Argument #11',                      'string;x',     '?!:x',     '', 'Command argument #11'),
            'param12'                     => array('act',  'Param12',                        'Argument #12',                      'string;x',     '?!:x',     '', 'Command argument #12'),
            'param13'                     => array('act',  'Param13',                        'Argument #13',                      'string;x',     '?!:x',     '', 'Command argument #13'),
            'param14'                     => array('act',  'Param14',                        'Argument #14',                      'string;x',     '?!:x',     '', 'Command argument #14'),
            'param15'                     => array('act',  'Param15',                        'Argument #15',                      'string;x',     '?!:x',     '', 'Command argument #15'),
            'env01'                       => array('act',  'Env01',                          'Environment Variable #1',           'string;x',     '?!:x',     '', 'Environment variable #1 for the command'),
            'env02'                       => array('act',  'Env02',                          'Environment Variable #2',           'string;x',     '?!:x',     '', 'Environment variable #2 for the command'),
            'env03'                       => array('act',  'Env03',                          'Environment Variable #3',           'string;x',     '?!:x',     '', 'Environment variable #3 for the command'),
            'env04'                       => array('act',  'Env04',                          'Environment Variable #4',           'string;x',     '?!:x',     '', 'Environment variable #4 for the command'),
            'env05'                       => array('act',  'Env05',                          'Environment Variable #5',           'string;x',     '?!:x',     '', 'Environment variable #5 for the command'),
            'env06'                       => array('act',  'Env06',                          'Environment Variable #6',           'string;x',     '?!:x',     '', 'Environment variable #6 for the command'),
            'env07'                       => array('act',  'Env07',                          'Environment Variable #7',           'string;x',     '?!:x',     '', 'Environment variable #7 for the command'),
            'env08'                       => array('act',  'Env08',                          'Environment Variable #8',           'string;x',     '?!:x',     '', 'Environment variable #8 for the command'),
            'env09'                       => array('act',  'Env09',                          'Environment Variable #9',           'string;x',     '?!:x',     '', 'Environment variable #9 for the command'),
            'env10'                       => array('act',  'Env10',                          'Environment Variable #10',          'string;x',     '?!:x',     '', 'Environment variable #10 for the command'),
            'env11'                       => array('act',  'Env11',                          'Environment Variable #11',          'string;x',     '?!:x',     '', 'Environment variable #11 for the command'),
            'env12'                       => array('act',  'Env12',                          'Environment Variable #12',          'string;x',     '?!:x',     '', 'Environment variable #12 for the command'),
            'env13'                       => array('act',  'Env13',                          'Environment Variable #13',          'string;x',     '?!:x',     '', 'Environment variable #13 for the command'),
            'env14'                       => array('act',  'Env14',                          'Environment Variable #14',          'string;x',     '?!:x',     '', 'Environment variable #14 for the command'),
            'env15'                       => array('act',  'Env15',                          'Environment Variable #15',          'string;x',     '?!:x',     '', 'Environment variable #15 for the command'),
         );

         static public $op_types = array (
            ':' => array ('eq'=>'='),
            '=' => array ('eq'=>'=', 'ne'=>'&ne;'),
            'x' => array ('le'=>'&lt;=', 'ge'=>'&gt;='),
            'i' => array ('le'=>'&lt;=', 'ge'=>'&gt;=', 'range'=>'between'),
            '5' => array ('eq'=>'=', 'ne'=>'&ne;', 'le'=>'&lt;=', 'ge'=>'&gt;=', 'range'=>'between'),
            'b' => array (),
         );

         static public $attr_value_types = array (
            'string;x'=>array(70,255),
            'string;w'=>array(20,16/*$tws_config['WORKSTATION_MAXLENGTH']*/),
            'string;s'=>array(20,16/*$tws_config['JOBSTREAM_MAXLENGTH']*/),
            'string;j'=>array(30,40/*$tws_config['JOB_MAXLENGTH']*/),
            'string;p'=>array(20,8/*$tws_config['PROMPT_MAXLENGTH']*/),

            'int;s'=>array(5,5),
            'int;l'=>array(14,14),
            'int;d'=>array(7,7),
            'int;p'=>array(3,3),

            'tstamp'=>array(),
            'bool'=>array(),

            //
            // IMPORTANT: 
            //
            // The values are case sensitive!!!
            //
            //TODO: implement user friendly values!
            'enum;st'=>array('Error','Held','Ready','Running','Successful','Undecided','Waiting'),
            'enum;is'=>array('READY','HOLD','EXEC','ABEND','SUCC','DONE','USER','FAIL','SUSP','WAIT','INTRO','WAITD','SCHED','ABENP','SUCCP','PEND','ERROR','EXTRN','BOUND'),
            'enum;ia'=>array('READY','HOLD','EXEC','STUCK','ABEND','SUCC','EXTRN'),
            'enum;ps'=>array('Asked','RepliedNo','RepliedYes'),
            'enum;sr'=>array('Abend','Stop'),
            'enum;sl'=>array('Blocked','Error','Held','Ready','Running','Successful','Undecided','Waiting'), //ERR16773 removed: 'Cancelled'
            'enum;rs'=>array('Unexpected End','Stop'),
            'enum;rr'=>array('No auto start','Maximum restart exceeded','Terminated too quickly'),
            'enum;ls'=>array('Linked', 'Unlinked'),
            'enum;ur'=>array('Broken','Dropped'),
            'enum;pt'=>array('Global','JobLocal','JobStreamLocal'),
            'enum;sv'=>array('Critical','Fatal','Normal','Warning'),
            'enum;ev'=>array('FATAL','ERROR','WARNING'),
            'enum;sw'=>array('Info','Warning','Error'),
            'enum;rc'=>array('Previous','Next','Any'),
            'enum;jt'=>array('Script','Command'),
            'enum;yn'=>array('Yes','No'),
            'enum;ua'=>array('Suppress','Continue','Cancel'),
            'enum;mb'=>array('appserverbox','clbox','courier','intercom','mailbox','monbox','moncmd','server','tomaster','pobox'),
            'enum;pn'=>array('agent','appservman','batchman','jobman','mailman','monman','netman'),
            'enum;rl'=>array('NORISK', 'POTENTIALRISK', 'HIGHRISK'),
            'enum;xa'=>array('Kill', 'Continue'),
            'enum;na'=>array('Continue', 'Abend', 'Confirm'),
         );

         function __construct($id) {
            $this->id=strtolower(trim($id));
            list($this->atc,$this->twsid, $this->title,$this->type, $this->props, $this->defval, $this->helptext)=self::$attr_types[$this->id];
            list($this->quant,$this->multival,$this->opers,$this->wilds)=array($this->props{0}, $this->props{1}, $this->props{2}, $this->props{3});
         }

         public function eda_js() {
            $s.="\nvar eda = {\n";
            $attr_ids=array();
            $attr_q=array();
            foreach (self::$attr_types as $attr_id=>$attr_desc) {
               $a=new eda($attr_id);
               $attr_ids[]=$a->get_id();
               $attr_q[]=$a->get_quant();
            }
            $s.='  attr_ids : ["'.implode('", "',$attr_ids).'"],'."\n";
            $s.='  attr_q : ["'.implode('", "',$attr_q).'"],'."\n";
            $s.='  get_idx : function (id) { var ret=-1; for (var i=0; i<this.attr_ids.length; i++) { if (id==this.attr_ids[i]) {ret=i; break} } return ret; },'."\n";
            $s.='  get_quant : function (id) { return this.attr_q[this.get_idx(id)]; }'."\n";
            $s.='}'."\n\n";
            return $s;
         }

         //attrs je pole ve kterem ma dany evrule_condition svoje atributy, pokud je
         //atribut vicenasobneho typu nebo pokud v poli neni vubec, tak se do pole prida, jinak se upravi existujici instance...
         //op = string, $val = value or array of values (in case op==between)
         //funkce vraci TRUE,FALSE, nebo objekt
         public function add(&$attrs, $op, $vals) {
            if (!is_array($vals)) {
               $vals=array($vals);
            }
            if (!$this->is_multioccur()) {
//check if the instance of this attribute is already present in $attrs array
               foreach ($attrs as &$attr) {
                  if ($attr->get_id()==$this->get_id()) {
                     $attr->op=trim($op);
                     $attr->val=$vals;
                     return true;
                  }
               }
            }
            $new=clone $this;
            $new->op=trim($op);
            $new->val=$vals;
            $attrs[]=$new;
            return true;
         }

         //TODO
         public function to_html($i, $j, $return=FALSE, $update=TRUE) {
            if ($this->get_quant()=='0') {
               if ($return!=FALSE) return '';
               return;
            }

            $ret='    <tr id="evrule_event_'.$this->atc.'_attr['.$i.']['.$j.']" class="'.$this->get_id().'"><td style="text-align:center">'.($this->get_quant()=='!' ? '&nbsp;' : '<input type="button" value="&times;" onclick="evrule_event_plugin_attr_remove('.$i.','.$j.',\''.$this->get_id().'\',\''.$this->quant.'\',\''.$this->atc.'\');" alt="Remove the attribute"/>').'</td><td><span class="attr_title" title="'.htmlspecialchars($this->get_helptext()).'">'.htmlspecialchars($this->get_title()).($this->is_mandatory() ? ' *' : '').'</span></td><td>'."\n";
            //operator
            if ($this->get_basetype()!='bool' && $this->atc!='act') {
               $ret.='      <select name="evrule_event_'.$this->atc.'_operator['.$i.']['.$this->get_id().']['.$j.']" onchange="evrule_event_plugin_attr_op_changed('.$i.',\''.$this->get_id().'\','.$j.',\''.$this->atc.'\');" title="Select the operator">'."\n";
               foreach (self::$op_types[$this->opers] as $op=>$op_html) {
                  $ret.='        <option value="'.$op.'" '.($this->op==$op ? ' selected' : '').'>'.$op_html.'</option>'."\n";
               }
               $ret.='      </select>'."\n";
            } else {
               $ret.='<input type="hidden" name="evrule_event_'.$this->atc.'_operator['.$i.']['.$this->get_id().']['.$j.']" value="eq"/>';
            }
            $ret.='    </td>'."\n";
            $ret.='    <td>';

            if ($this->atc=='act') {
               $ca_picker='<input type="button" class="ca_picker" value="Variable" onclick="ca_picker_click(this)"/>';
            } else {
               $ca_picker='';
            }

            if (preg_match('/workstation/i', $this->get_twsid())) {
               $tws_picker="<input style=\"margin-right:2px\" type=\"button\" name=\"workstation_list\" onClick=\"var tmpid='tmp'+Math.ceil(Math.random()*1000);$(this).parent().find('input').first().attr('id',tmpid); tws_picker_open('workstation_picker.php', 'fieldid='+tmpid+'&amp;fieldvalue=' + $(this).parent().find('input').first().attr('value'));\" value=\"List\">";
            } elseif (preg_match('/stream/i', $this->get_twsid())) {
               $tws_picker="<input style=\"margin-right:2px\" type=\"button\" name=\"jobstream_list\" onClick=\"var tmpid='tmp'+Math.ceil(Math.random()*1000);$(this).parent().find('input').first().attr('id',tmpid); tws_picker_open('jobstream_picker.php', 'cpux=*&amp;fieldid='+tmpid+'&amp;fieldvalue=' + $(this).parent().find('input').first().attr('value'));\" value=\"List\">";
            } elseif (preg_match('/job/i', $this->get_twsid())) {
               $tws_picker="<input style=\"margin-right:2px\" type=\"button\" name=\"job_list\" onClick=\"var tmpid='tmp'+Math.ceil(Math.random()*1000);$(this).parent().find('input').first().attr('id',tmpid); tws_picker_open('job_picker.php', 'cpux=*&amp;fieldid='+tmpid+'&amp;fieldvalue=' + $(this).parent().find('input').first().attr('value'));\" value=\"List\">";
            } else $tws_picker='';

            isset($this->val[0]) || $this->val[0]=$this->defval;

            switch ($this->get_basetype()) {
               case 'tstamp' :
                  $ret.='<span style="white-space:nowrap;">'.tws_datetime_picker('evrule_event_'.$this->atc.'_value['.$i.']['.$this->get_id().']['.$j.'][]',tws_iso_to_userdate(tws_userdate_to_iso($this->val[0], 'EVRULE_TS'))).'</span>';
                  $ret.=tws_datetime_picker('evrule_event_'.$this->atc.'_value['.$i.']['.$this->get_id().']['.$j.'][LO]',tws_iso_to_userdate(tws_userdate_to_iso($this->val[0], 'EVRULE_TS')));
                  $ret.='&nbsp;';
                  $ret.=tws_datetime_picker('evrule_event_'.$this->atc.'_value['.$i.']['.$this->get_id().']['.$j.'][HI]',tws_iso_to_userdate(tws_userdate_to_iso($this->val[1], 'EVRULE_TS')));
                  break;

               case 'int' : case 'string' :
                  $tinf=$this->get_typeinfo();
                  $size=$tinf[0];
                  $maxlength=$tinf[1];
                  for ($k=0; $k<count($this->val); $k++) {
                     $ret.='<span>'.($k>0 ? ' OR ' : '').'<input class="data" type="text" name="evrule_event_'.$this->atc.'_value['.$i.']['.$this->get_id().']['.$j.'][]" value="'.htmlspecialchars($this->val[$k]).'" size="'.$size.'" maxlength="'.$maxlength.'"/>'.$tws_picker.($this->is_multival() ? '<input class="rmorval" type="button" value="&times;" onclick="rmaval($(this).parent());" title="Remove this value"/><input type="button" value="+" onclick="addaval($(this).parent(),\''.$this->defval.'\');" title="Enter another value"/>' : '').$ca_picker.'</span>';
                  }
                  $ret.='    <input type="text" name="evrule_event_'.$this->atc.'_value['.$i.']['.$this->get_id().']['.$j.'][LO]" value="'.htmlspecialchars($this->val[0]).'" size="'.$size.'" maxlength="'.$maxlength.'"/>';
                  $ret.='    <input type="text" name="evrule_event_'.$this->atc.'_value['.$i.']['.$this->get_id().']['.$j.'][HI]" value="'.htmlspecialchars($this->val[1]).'" size="'.$size.'" maxlength="'.$maxlength.'"/>';
                  break;

               case 'bool' :
                  $ret.='    <input type="hidden" name="evrule_event_'.$this->atc.'_value['.$i.']['.$this->get_id().']['.$j.'][]" value="false"/><input type="checkbox" name="evrule_event_'.$this->atc.'_value['.$i.']['.$this->get_id().']['.$j.'][0]" value="true" checked="'.(strtolower(trim($this->val[0]))=='true' ? 'checked' : '').'"/>'.'&nbsp;';
                  break;

               case 'enum' :
                  if (is_array($tinf=$this->get_typeinfo())) {
                     $ret.='    <select name="evrule_event_'.$this->atc.'_value['.$i.']['.$this->get_id().']['.$j.'][]"'.($this->is_multival() ? ' size="'.count(self::$attr_value_types[$this->get_type()]).'" multiple' : '').'>';
                     foreach ($tinf as $aval) {
                        $selected='';
                        if (is_array($this->val)) {
                           foreach ($this->val as $val) {
                              if (trim(strtolower($val))==trim(strtolower($aval))) {
                                 $selected=' selected';
                                 break;
                              }
                           }
                        }
                        $ret.='<option value="'.$aval.'"'.$selected.'>'.htmlspecialchars($aval).'</option>'; //FIXME!!!
                     }
                     $ret.='</select>'."\n";
                  } else {
                     tws_error('Unexpected attribute value type: '.$this->get_type().', typeinfo: '.$tinf);
                  }
                  break;

               case 'text' :
                  $ret.='    <textarea name="evrule_event_'.$this->atc.'_value['.$i.']['.$this->get_id().']['.$j.'][]" style="width:300px; height:100px">'.htmlspecialchars($this->val[0]).'</textarea>'.$ca_picker;
                  break;

               default:
                  tws_error('Unsupported attribute value type: '.$this->get_basetype(), print_r($this,1));
                  break;
            }
            $ret.='    </td></tr>'."\n";

            if ($update) {
               $params_update_js='evrule_event_plugin_attr_op_changed('.$i.',\''.$this->get_id().'\','.$j.',\''.$this->atc.'\');';
               $ret.='    <script type="text/javascript">'.$params_update_js.'</script>'."\n";
            }

            if ($return!=FALSE) return $ret;
            echo $ret;
         }

         public function get_id() {return $this->id; }
         public function get_twsid() {return $this->twsid; }
         public function get_atc() { return $this->atc; }
         public function get_quant() { return $this->quant; }
         public function get_title() { return $this->title; }
         public function get_type() { return $this->type; }
         public function get_basetype() { list($basetype,$spec)=explode(';',$this->get_type()); return $basetype; }
         public function get_typeinfo() { return self::$attr_value_types[$this->get_type()]; }
         public function get_defval() { return $this->defval; }
         public function get_helptext() { return $this->helptext; }
         public function is_mandatory() { return ($q=$this->get_quant())=='!' || $q=='+'; }
         public function is_multioccur() { return ($q=$this->get_quant())=='*' || $q=='+'; }
         public function is_multival() { return $this->multival=='*' || $this->multival=='+'; }

         static public function get_generators($atc) {
            $s='<!-- attributes generators -->'."\n".'<script type="text/javascript">'."\n";
            foreach (self::$attr_types as $attr_id=>$attr_desc) {
               $attr=new eda($attr_id);
               if ($attr->get_atc()!=$atc || $attr->get_quant()=='0') continue;

               $s.='  //'.$attr_id.' attribute generator'."\n";
               $g=$attr->to_html('###i###','###j###',TRUE,FALSE);
               $generator='function attr_generator_'.$attr_id.'(i, j) {'."\n".'   var ret=\''.preg_replace('/###([a-zA-Z_][a-zA-Z0-9_]*)###/','\'+\\1+\'',trim(addcslashes(preg_replace("/\n/",' ',$g),'\''))).'\';'."\n   return ret;\n}\n";
               $s.='  '.$generator;
            }
            $s.='</script>'."\n";
            return $s;
         }
      }

      class edas {
         static public $attrs_cond=array(
            'filecreated'           => array('filename','workstation','sampleinterval','hostname',  'timestamp','ipaddress','eventruleid'),
            'filedeleted'           => array('filename','workstation','sampleinterval','hostname',  'timestamp','ipaddress','eventruleid'),
            'modificationcompleted' => array('filename','workstation','sampleinterval','hostname','lastwritetime',  'timestamp','ipaddress','eventruleid'),
            'logmessagewritten'     => array('filename','matchexpression','workstation','sampleinterval','matches','lastwritetime','size','hostname',  'timestamp','ipaddress','linetext','eventruleid'),

            'jobsubmit'                      => array('workstation'=>'jobworkstation','jobstreamworkstation','jobstreamname','jobstreamschedtime','jobname','priority','monitored','estimatedduration','lateststart','deadline','login','everyfrequency',  'jobstreamid','timestamp','hostname'=>'hostname2','ipaddress','plannumber'),
            'jobrestart'                     => array('workstation'=>'jobworkstation','jobstreamworkstation','jobstreamname','jobstreamschedtime','jobname','priority','monitored','actualstart','estimatedduration','actualduration','returncode','lateststart','deadline','login','everyfrequency',  'jobstreamid','timestamp','hostname'=>'hostname2','ipaddress','plannumber'),
            'jobcancel'                      => array('workstation'=>'jobworkstation','jobstreamworkstation','jobstreamname','jobstreamschedtime','jobname','priority','monitored','actualstart','estimatedduration','actualduration','returncode','lateststart','deadline','status','internalstatus','login','everyfrequency',  'jobstreamid','timestamp','hostname'=>'hostname2','ipaddress','plannumber'),
            'joblate'                        => array('workstation'=>'jobworkstation','jobstreamworkstation','jobstreamname','jobstreamschedtime','jobname','priority','monitored','actualstart','estimatedduration','actualduration','returncode','lateststart','deadline','status','internalstatus','login','everyfrequency',  'jobstreamid','timestamp','hostname'=>'hostname2','ipaddress','plannumber'),
            'jobuntil'                       => array('workstation'=>'jobworkstation','jobstreamworkstation','jobstreamname','jobstreamschedtime','jobname','priority','monitored','estimatedduration','lateststart','deadline','status','internalstatus','login','everyfrequency','untilaction',  'jobstreamid','timestamp','hostname'=>'hostname2','ipaddress','plannumber'),
            'jobstatuschanged'               => array('workstation'=>'jobworkstation','jobstreamworkstation','jobstreamname','jobstreamschedtime','jobname','priority','monitored','actualstart','estimatedduration','actualduration','returncode','lateststart','deadline','status','internalstatus','login','everyfrequency','errormessage',  'jobstreamid','timestamp','hostname'=>'hostname2','ipaddress','plannumber'),
            //TWS9.x:
            'jobpromoted'                    => array('workstation'=>'jobworkstation','jobstreamworkstation','jobstreamname','jobstreamschedtime','jobname','priority','monitored','actualstart','estimatedduration','criticallateststart','lateststart','deadline','status','internalstatus','login','everyfrequency',  'jobstreamid','timestamp','hostname'=>'hostname2','ipaddress','plannumber'),
            'jobrisklevelchanged'            => array('workstation'=>'jobworkstation','jobstreamworkstation','jobstreamname','jobstreamschedtime','jobname','priority','monitored','actualstart','estimatedduration','criticallateststart','lateststart','deadline','status','internalstatus','risklevel','login','everyfrequency',  'jobstreamid','timestamp','hostname'=>'hostname2','ipaddress','plannumber'),
            'jobmaxdurationexceeded'         => array('workstation'=>'jobworkstation','jobstreamworkstation','jobstreamname','jobstreamschedtime','jobname','priority','monitored','actualstart','estimatedduration','actualduration','returncode','lateststart','deadline','status','internalstatus','login','everyfrequency','maxdurationaction',  'jobstreamid','timestamp','hostname'=>'hostname2','ipaddress','plannumber','jobnumber'),
            'jobmindurationnotreached'       => array('workstation'=>'jobworkstation','jobstreamworkstation','jobstreamname','jobstreamschedtime','jobname','priority','monitored','actualstart','estimatedduration','actualduration','returncode','lateststart','deadline','status','internalstatus','login','everyfrequency','mindurationaction',  'jobstreamid','timestamp','hostname'=>'hostname2','ipaddress','plannumber','jobnumber'),

            'jobstreamsubmit'                => array('jobstreamworkstation','jobstreamname','jobstreamschedtime','priority','monitored','lateststart','deadline',  'workstation'=>'jobstreamworkstation2', 'jobstreamid','timestamp','hostname'=>'hostname2','ipaddress','plannumber'),
            'jobstreamcancel'                => array('jobstreamworkstation','jobstreamname','jobstreamschedtime','priority','monitored','lateststart','deadline',  'workstation'=>'jobstreamworkstation2', 'jobstreamid','timestamp','hostname'=>'hostname2','ipaddress','plannumber', 'status'=>'streamstatus2','internalstatus'=>'internalstatus2' ),
            'jobstreamstatuschanged'         => array('jobstreamworkstation','jobstreamname','jobstreamschedtime','priority','monitored','lateststart','deadline','status'=>'streamstatus','internalstatus'=>'streaminternalstatus',  'workstation'=>'jobstreamworkstation2', 'jobstreamid','timestamp','hostname'=>'hostname2','ipaddress','plannumber'),
            'jobstreamcompleted'             => array('jobstreamworkstation','jobstreamname','jobstreamschedtime','priority','monitored','lateststart','deadline','status'=>'streamstatus','internalstatus'=>'streaminternalstatus',  'workstation'=>'jobstreamworkstation2', 'jobstreamid','timestamp','hostname'=>'hostname2','ipaddress','plannumber'),
            'jobstreamuntil'                 => array('jobstreamworkstation','jobstreamname','jobstreamschedtime','priority','monitored','lateststart','deadline','status'=>'streamstatus','internalstatus'=>'streaminternalstatus','untilaction',  'workstation'=>'jobstreamworkstation2', 'jobstreamid','timestamp','hostname'=>'hostname2','ipaddress','plannumber'),
            'jobstreamlate'                  => array('jobstreamworkstation','jobstreamname','jobstreamschedtime','priority','monitored','lateststart','deadline','status'=>'streamstatus','internalstatus'=>'streaminternalstatus',  'workstation'=>'jobstreamworkstation2', 'jobstreamid','timestamp','hostname'=>'hostname2','ipaddress','plannumber'),

            'promptstatuschanged'            => array('name'=>'promptname','text'=>'prompttext','status'=>'promptstatus','type'=>'prompttype','recoveryprompt','workstation'=>'promptworkstation','jobstreamworkstation'=>'promptjobstreamworkstation','jobstreamname'=>'promptjobstreamname','jobstreamschedtime'=>'promptjobstreamschedtime','jobname'=>'promptjobname','jobstreamid','timestamp','hostname'=>'hostname2','ipaddress','plannumber'),
            'workstationstatuschanged'       => array('workstation','running','stopreason',  'timestamp','hostname'=>'hostname2','ipaddress','plannumber'),
            'childworkstationlinkchanged'    => array('workstation','parentworkstation','linkstatus',  'unlinkreason','timestamp','hostname'=>'hostname2','ipaddress','plannumber'),
            'parentworkstationlinkchanged'   => array('workstation','parentworkstation','linkstatus',  'unlinkreason','timestamp','hostname'=>'hostname2','ipaddress','plannumber'),
            'applicationserverstatuschanged' => array('workstation','running','stopreason','restarting','norestartreason',  'timestamp','hostname'=>'hostname2','ipaddress','plannumber'),
            //TWS9.x
            'productalert'                   => array('workstation','message','severity'=>'severity3','plannumber','timestamp'),

            'twsmessagequeues'               => array('fillingpercentage','mailboxname','sampleinterval'=>'sampleintervalo','workstation',  'timestamp','hostname'=>'hostname2','ipaddress','eventruleid'),
            'twsdiskmonitor'                 => array('fillingpercentage','mountpoint','sampleinterval'=>'sampleintervalo','workstation',  'timestamp','hostname'=>'hostname2','ipaddress','eventruleid'),
            'twsprocessmonitor'              => array('processname','twspath','sampleinterval'=>'sampleintervalo','workstation',  'timestamp','hostname'=>'hostname2','ipaddress','eventruleid'),

            'event1'                         => array('workstation'=>'workstations','param1'),
         );

         static public $attrs_act=array(
            'tecfwd'                => array('host','port','message','severity','lob','parm_1','parm_2','parm_3','parm_4','parm_5','parm_6','parm_7','parm_8','parm_9','parm_10'),
            'sendmail'              => array('to','cc','bcc','subject','body'),
            'msglog'                => array('message','severity'=>'severity2','objectkey','source','lob'=>'lob2','group'),
            'sbs'                   => array('jobstreamname'=>'jobstreamname2','jobstreamworkstationname'=>'jobstreamworkstationname2','jobstreamschedtime'=>'jobstreamschedtime2','jobstreamalias'=>'jobstreamalias2','parm_1','parm_2','parm_3','parm_4','parm_5','parm_6','parm_7','parm_8','parm_9','parm_10'),
            'sbj'                   => array('jobdefinitionname','jobdefinitionworkstationname','jobjstreamname','jobjstreamworkstationname','schedtimeresolutioncriteria','jobalias','jobuseuniquealias','parm_1','parm_2','parm_3','parm_4','parm_5','parm_6','parm_7','parm_8','parm_9','parm_10'),
            'sbd'                   => array('jobtask','joblogin','jobpriority','jobworkstationname','jobjstreamname','jobjstreamworkstationname','schedtimeresolutioncriteria','jobalias','jobuseuniquealias','jobtype'),
            'reply'                 => array('promptname'=>'promptname2','promptanswer'),
            'runcommand'            => array('command','workingdir','param01','param02','param03','param04','param05','param06','param07','param08','param09','param10','param11','param12','param13','param14','param15','env01','env02','env03','env04','env05','env06','env07','env08','env09','env10','env11','env12','env13','env14','env15'),
         );

         public function edas_js() {
            $s.="\nvar edas = {\n";
            $attr_names=array();
            $attr_titles=array();
            foreach (self::$attrs_cond as $cond=>$attrs) {
               $cond_attr_ids=array();
               foreach ($attrs as $att_twsname=>$attid) {
                  $attr=new eda($attid);
                  if (!is_string($att_twsname)) $att_twsname=$attid;
                  $att_twsname=strtolower(trim($att_twsname));
                  if (($i=array_search($att_twsname, $attr_names))===FALSE) {
                     $i=count($attr_names);
                     $attr_names[$i]=$att_twsname;
                     $attr_titles[$i]=$attr->get_title();
                  }
                  $cond_attr_ids[]=$i;
               }
               $s.='  '.$cond.' : ['.implode(', ',$cond_attr_ids).'],'."\n";
            }

            $s.='  attr_names : ["'.implode('", "',$attr_names).'"],'."\n";
            $s.='  attr_titles : ["'.implode('", "',$attr_titles).'"],'."\n";
            $s.='  used_attrs : ['.trim(str_pad('',count($attr_names)*2,'0,'),',').'],'."\n";
            $s.='  conds_count : 0,'."\n";
            $s.='  cond_added : function (cond) { var c=eval(\'this.\' + cond ); this.conds_count++; for(var i=0; i<c.length; i++) { this.used_attrs[c[i]]++; } },'."\n";
            $s.='  cond_removed : function (cond) { var c=eval(\'this.\' + cond ); this.conds_count--; for(var i=0; i<c.length; i++) { this.used_attrs[c[i]]--; } }'."\n";
            $s.='}'."\n\n";
            return $s;
         }

         function __construct($atc, $evtype, $attrs_store) {
            $this->atc=$atc;
            $this->attrs=array();
            $this->evtype=strtolower(trim($evtype));
            $attrs_desc=self::${'attrs_'.$atc}[$this->evtype];

            if ($attrs_desc) {
               foreach ($attrs_desc as $attr_id) {
                  $attr_id=strtolower(trim($attr_id));
                  $this->$attr_id=new eda($attr_id);
                  if ($attrs_store=='' && $this->$attr_id->is_mandatory()) $this->$attr_id->add($this->attrs, '=', $this->$attr_id->defval);
               }
               if ($atc=='cond' && is_string($attrs_store)) {
                  $attrs=simplexml_load_string('<xml>'.$attrs_store.'</xml>');
                  $vals=array();
                  foreach ($attrs->attributeFilter as $attr) {
                     $attr_id=strtolower(trim($attr->attributes()->name));
                     if (isset(self::$attrs_cond[$this->evtype][$attr_id]))
                        $attr_id=strtolower(trim(self::$attrs_cond[$this->evtype][$attr_id]));
                     foreach ($attr->value as $val)
                        $vals[$attr_id][] = $val;
                  }
                  foreach($vals as $attr_id => $val)
                     $this->$attr_id->add($this->attrs, $attr->attributes()->operator, $val);
               } 
               elseif ($atc=='act' && is_array($attrs_store)) {
                  foreach ($attrs_store as $attr_twsname=>$attr_value) {
                     $attr_id=strtolower(trim($attr_twsname));
                     if (isset(self::$attrs_act[$this->evtype][$attr_id])) $attr_id=strtolower(trim(self::$attrs_act[$this->evtype][$attr_id]));
                     if (isset($attr_id) && is_string($attr_id)) $attr_id=strtolower(trim($attr_id));
                     if (isset($this->$attr_id)) {
                        $this->$attr_id->add($this->attrs, ':', $attr_value);
                     } else {
                        tws_err("Unknown action attribute '$this->evtype.$attr_id'", print_r($attrs_store,1));
                     }
                  }
               }
            } else {
               tws_error('Unsupported event type: '.$this->evtype);
            }
         }

         public function to_html($i, $return=FALSE, $update=TRUE) {
            $ret='  <table style="font-size:0.8em" id="evrule_event_'.$this->atc.'_attrs['.$i.']">'."\n";
            $j=0;
            foreach ($this->attrs as $attr) {
               $ret.=$attr->to_html($i,$j,TRUE,$update);
               $j++;
            }
            $ret.='  </table>'."\n";
            if ($return) return $ret;
            echo $ret;
         }

      }


      function edas_box($i, &$data, $return, $update, $atc) {
         global $tws_config;

         switch ($atc) {
            case 'cond' :
               global $event_cond_types;
               $atc_key='event';
               $attrs_store=$data['evrule_event_predicate'][$i];
               $atc_plugin_name=trim(strtolower($data['evrule_event_plugin_name'][$i]));
               $atc_type=trim(strtolower($data['evrule_event_type'][$i]));
               $attrs=edas::$attrs_cond[$atc_type];
               $atc_name=$event_cond_types[ strtolower(trim($data['evrule_event_plugin_name'][$i])) ][ $atc_type ]['name'];
               $instname='';
               $descfield='<table style="margin-bottom:10px"><tr><td>Name:</td><td><input type="text" name="evrule_event_name['.$i.']" size="'.(intval($tws_config['EVENTRULE_EVENT_NAME_MAXLENGTH']/2)).'" maxlength="'.$tws_config['EVENTRULE_EVENT_NAME_MAXLENGTH'].'" value="'.htmlspecialchars($data['evrule_event_name'][$i]).'"/></td></tr></table>';
               break;
            case 'act' :
               global $event_act_types;
               $atc_key='action';
               $attrs_store=$data['evrule_action_parameter_list'][$i];
               $atc_plugin_name=trim(strtolower($data['evrule_action_plugin_name'][$i]));
               $atc_type=trim(strtolower($data['evrule_action_type'][$i]));
               $attrs=edas::$attrs_act[$atc_type];
               $atc_name=$event_act_types[ strtolower(trim($data['evrule_action_plugin_name'][$i])) ][ $atc_type ]['name'];
               $instname='';
               $descfield='<table style="margin-bottom:10px"><tr><td>Response Type:</td><td><select name="evrule_event_act_response_type['.$i.']"><option value="D" '.($data['evrule_action_response_type'][$i]=='D' ? 'selected' : '').'>On Detection</option><option value="T" '.($data['evrule_action_response_type'][$i]=='T' ? 'selected' : '').'>On Timeout</option></select></td></tr><tr><td>Description:</td><td><input type="text" name="evrule_event_act_description['.$i.']" size="50" maxlength="'.$tws_config['EVENTRULE_DESCRIPTION_MAXLENGTH'].'" value="'.htmlspecialchars($data['evrule_action_description'][$i]).'"/></td></tr></table>';
               break;
         }

         $ret='';

         $ret.='<table id="evrule_event_'.$atc.'['.$i.']" name="evrule_event_'.$atc.'" style="border:solid 1px; margin:2px 2px 10px 2px;">'."\n";
         $ret.='  <tr class="header"><th class="wireframe" style="white-space:nowrap;" ondblclick="evrule_event_atc_collexp('.$i.',\''.$atc.'\',\'collapse\',$(this).find(\'input[name=&quot;evrule_event_'.$atc.'_collexp['.$i.']&quot;]\'));">'."\n";
         $ret.='    <input type="hidden" name="evrule_event_'.$atc.'_position[]" value="'.$i.'"/>'."\n";
         $ret.='    <input type="hidden" name="evrule_event_'.$atc.'_plugin_name['.$i.']" value="'.$atc_plugin_name.'"/>'."\n";
         $ret.='    <input type="hidden" name="evrule_event_'.$atc.'_type['.$i.']" value="'.$atc_type.'"/>'."\n";
         $ret.='    <span style="float:left"><strong>'.$atc_name.'</strong></span><span class="rightnavi">'.$instname.'&nbsp;&nbsp;&nbsp;<input name="evrule_event_'.$atc.'_collexp['.$i.']" type="button" value="_" onclick="evrule_event_atc_collexp('.$i.',\''.$atc.'\',\'collapse\',this);"/><input type="button" value="&uarr;" onclick="evrule_event_atc_move('.$i.',\''.$atc.'\',\'up\')"/><input type="button" value="&darr;" onclick="evrule_event_atc_move('.$i.',\''.$atc.'\',\'down\')"/><input type="button" value="&times;" onclick="evrule_event_atc_remove('.$i.',\''.$atc.'\')"/></span></th></tr>'."\n";
         if ($descfield!='') {
            $ret.='  <tr><td>'.$descfield.'</td></tr>'."\n";
         }
         $ret.='  <tr><td>'."\n";
         $edas=new edas($atc, $data['evrule_'.$atc_key.'_type'][$i], $attrs_store);
         $ret.=$edas->to_html($i,TRUE,$update);
         $ret.='  </td></tr>'."\n";

         //anny additional attributes
         $reta1=$reta2=$reta3='';
         if (is_array($attrs)) {
            $reta1.='  <tr><td><select name="evrule_event_'.$atc.'_new_attr['.$i.']" onchange="evrule_event_new_attr_changed('.$i.',\''.$atc.'\')" title="Add another atttribute">'."\n";
            $reta1.='      <option value="" selected>+ Additional Attributes</option>'."\n";
            foreach ($attrs as $attr_id) {
               $attr=new eda($attr_id);
               if ($attr->get_quant()=='!' || $attr->get_quant()=='0' ) continue;
               $reta2.='      <option value="'.$attr->get_id().'">'.htmlspecialchars($attr->get_title()).'</option>'."\n";
            }
            $reta3.='    </select></td></tr>'."\n";
         } else {
            tws_error('Unsupported '.$atc_key.' type: '.$atc_type); //jozsef comment (error msg source)
         }
         if ($reta1!='' && $reta2!='' && $reta3!='') {
            $ret.=$reta1.$reta2.$reta3;
         }

         if ($atc=='cond' && $update) {
            $ret.='<script type="text/javascript">edas.cond_added(\''.$atc_type.'\');</script>'."\n";
         }
         $ret.='</table>'."\n";
         if ($return) return $ret;
         echo $ret;
      }


   function tws_get_evt_form_general($evrules,$edit=TRUE,$context='',$agatrs_only=FALSE) {
      global $tws_config;

      if ($agatrs_only) {
         $agatrs='<p><b>Type:</b><br/>&nbsp;&nbsp;&nbsp;<select name="evrules[evrule_type][0]">'."\n";
         foreach (array('F'=>'Single Event', 'S'=>'Set of Events', 'Q'=>'Sequence of Events') as $key=>$val) {
            $agatrs.='   <option value="'.$key.'" '.($evrules['evrule_type'][0]==$key ? 'selected' : '').'>'.$val.'</option>'."\n";
         }
         $agatrs.='</select></p>'."\n";
         $agatrs.='<p><b>Timeout:</b><br/>&nbsp;&nbsp;&nbsp;<input type="text" name="evrules[evrule_timeout][0]" class="tws_num" size="7" maxlength="10" value="'.((intval($evrules['evrule_timeout'][0]) > 0) ? $evrules['evrule_timeout'][0] : '').'">&nbsp;seconds</p>'."\n";
         $agatrs.='<p><b>Correlate events on:</b><br/>'."\n";
         $_attrs=array();
         foreach (edas::$attrs_cond as $_cond=>$_cattrs) {
            foreach ($_cattrs as $_a_twsname=>$_aid) {
               $a=new eda($_aid);
               if (!is_string($_a_twsname)) $_a_twsname=$_aid;
               $_a_twsname=strtolower(trim($_a_twsname));
               $_attrs[$_a_twsname]=$a->get_title();
            }
         }
         foreach ($_attrs as $_a_twsname=>$_atitle) {
            $agatrs.='<p style="padding:0;margin:0;white-space:nowrap;">&nbsp;&nbsp;&nbsp;<input type="checkbox" name="evrules[evrule_attr_correlation][0]['.$_a_twsname.']" value="yes" '.(is_array($evrules['evrule_attr_correlation'][0]) && in_array($_a_twsname,$evrules['evrule_attr_correlation'][0]) ? 'checked' : '').'/>&nbsp;'.$_atitle.'</p>'."\n";
         }
         if ($edit) {
            $agatrs.='<script type="text/javascript">'."\n";
            $agatrs.='  update_correlated_attrs();'."\n";
            $agatrs.='</script>'."\n";
         }
         return $agatrs;
      }
		
		
      $s ='<table border=0 cellspacing=0 style="background-color:transparent">'."\n";
	 
	  if ($tws_config['cpuinfo']['version']>='9.5002') { //jozsef
			if(empty($evrules['evrule_folder'][0])) $evrules['evrule_folder'][0] = '/';
		$s.='  <tr><td class=standard width=140>&nbsp;&nbsp;<b>Rule Folder:</b></td><td class=standard><input type="text" name="evrules[evrule_folder][0]" id="evrule_folder" required="required" size="'.$tws_config['EVENTRULE_MAXLENGTH'].'" maxlength="'.$tws_config['EVENTRULE_MAXLENGTH'].'" value="'.htmlspecialchars($evrules['evrule_folder'][0]).'"/></td>'.($edit ? '' : '<td rowspan="12" style="vertical-align:top; padding-left:50px">'.tws_get_evt_form_general($evrules,$edit,$context,TRUE).'</td>')."\n";
		$s.='<td>'.'<input type="button" name="folder_list" onClick="tws_picker_open(\'folder_picker.php\', \'fieldname=evrules[evrule_folder][0]&fieldvalue=\' + document.getElementById(\'evrule_folder\').value);" value="List" >'.'</td></tr>';
		
	  }
	  
	  
      $s.='  <tr><td class=standard width=140>&nbsp;&nbsp;<b>Rule Name:</b></td><td class=standard><input type="text" name="evrules[evrule_name][0]" class="tws_name" required="required" size="'.$tws_config['EVENTRULE_MAXLENGTH'].'" maxlength="'.$tws_config['EVENTRULE_MAXLENGTH'].'" value="'.htmlspecialchars($evrules['evrule_name'][0]).'"/></td>'.($edit ? '' : '<td rowspan="12" style="vertical-align:top; padding-left:50px">'.tws_get_evt_form_general($evrules,$edit,$context,TRUE).'</td>').'</tr>'."\n";
      $s.='  <tr><td class=standard valign="top" width=140>&nbsp;&nbsp;<b>Description:</b></td><td class=standard><input type="text" name="evrules[evrule_description][0]" class="tws_description" size="'.$tws_config['EVENTRULE_MAXLENGTH'].'" maxlength="'.$tws_config['EVENTRULE_DESCRIPTION_MAXLENGTH'].'" value="'.htmlspecialchars($evrules['evrule_description'][0]).'"/></td></tr>'."\n";
      $s.='  <tr><td>&nbsp;</td></tr>'."\n";
      $s.='  <tr><td class=standard width=140>&nbsp;&nbsp;<b>Valid from:</b></td><td class=standard>'.tws_datetime_picker('evrules[evrule_valid_from][0]',tws_iso_to_userdate($evrules['evrule_valid_from'][0],null,TRUE),'','',"'dropdown',false,'24',true,false,true").'</td></tr>'."\n";
      $s.='  <tr><td class=standard width=140>&nbsp;&nbsp;<b>Valid to:</b></td><td class=standard>'.tws_datetime_picker('evrules[evrule_valid_to][0]',tws_iso_to_userdate($evrules['evrule_valid_to'][0],null,TRUE),'','',"'dropdown',false,'24',true,false,true").'</td></tr>'."\n";
      $s.='  <tr><td>&nbsp;</td></tr>'."\n";
      $s.='  <tr><td class=standard width=140>&nbsp;&nbsp;<b>Daily start:</b></td><td class=standard>'.tws_datetime_picker('evrules[evrule_start_offset][0]',$evrules['evrule_start_offset'][0],'','',"'dropdown','only','24',false,false,true,false").'</td></tr>'."\n";
      $s.='  <tr><td class=standard width=140>&nbsp;&nbsp;<b>Daily end:</b></td><td class=standard>'.tws_datetime_picker('evrules[evrule_end_offset][0]',$evrules['evrule_end_offset'][0],'','',"'dropdown','only','24',false,false,true,false").'</td></tr>'."\n";
      $s.='  <tr><td>&nbsp;</td></tr>'."\n";
      $tz_disabled=(!tws_yesno(tws_get_tz_status(),TRUE,FALSE));
      $tz_status_warning=$tz_disabled && $evrules['time_zone'][0]!='';
      $s.='  <tr><td class=standard width=140>&nbsp;&nbsp;<b>'.($tz_disabled ? '<font color="#808080">Time Zone</font>' : 'Time Zone').'</b></td><td class=standard><select name="evrules[evrule_timezone][0]" '.($tz_disabled ? ' disabled' : '').'>'.tws_print_timezone_options($evrules['evrule_timezone'][0], TRUE).'</select>'.($tz_status_warning ? '<br/><p class="warning">Time Zone is set in Event Rule definition, but Time Zones are not enabled</p>' : '').'</td></tr>'."\n";
      $s.='  <tr><td>&nbsp;</td></tr>'."\n";
      $s.='  <tr><td class=standard colspan=2>&nbsp;&nbsp;<input type="checkbox" name="evrules[evrule_draft][0]" value="Y"'.($evrules['evrule_draft'][0]=='Y' ? ' checked' : '').'/>&nbsp;<b>Draft</b></td></tr>'."\n";
      $s.='</table>'."\n";
      return $s;
   }

function tws_get_evt_form($atc,$evrules,$data,$edit=TRUE,$context='') {
   global $tws_config, ${'event_'.$atc.'_types'};


//   if ($atc=='cond' && $tws_config['cpuinfo']['version']<='8.5') {
//      //TWS Application Provider has been added in TWS8.5.{0,1} fixpack 02 !!!
//      unset($event_cond_types['twsapplicationmonitor']);
//   }

   $s='';

   //generate all attribute templates
   $edit && ($s.=eda::get_generators($atc));

   //generate all event type template
   $s.='<script type="text/javascript">'."\n";
   if ($atc=='cond') {
      $s.=eda::eda_js();
      $s.=edas::edas_js();
   }
   if ($edit) {
      foreach (${'event_'.$atc.'_types'} as $pgroup=>$ptypes) {
         foreach ($ptypes as $eda_id=>$eda_type) {
            if ($eda_id=='class') continue;
            $i='###i###';
            $e_templ=array();
            if ($atc=='cond') {
               $e_templ['evrule_event_name'][$i] = $eda_id.'evt'.$i;
               $e_templ['evrule_event_plugin_name'][$i] = $pgroup;
               $e_templ['evrule_event_type'][$i] = $eda_id;
               $e_templ['evrule_event_predicate'][$i] = ''; //mandatory attrs will be generated automatically
            } elseif ($atc=='act') {
               $e_templ['evrule_action_description'][$i] = $eda_id.'act'.$i;
               $e_templ['evrule_action_plugin_name'][$i] = $pgroup;
               $e_templ['evrule_action_type'][$i] = $eda_id;
               $e_templ['evrule_action_parameter_list'][$i] = ''; //mandatory attrs will be generated automatically
            }
            $g=edas_box($i, $e_templ, TRUE, FALSE, $atc);
            $generator='function event_type_generator_'.$eda_id.'(i) {'."\n".'   var ret=\''.preg_replace('/###([a-zA-Z_][a-zA-Z0-9_]*)###/','\'+\\1+\'',trim(addcslashes(preg_replace("/\n/",' ',$g),'\''))).'\';'."\n   return ret;\n}\n";
            $s.='//'.$eda_type['name'].' template'."\n";
            $s.=$generator."\n";
         }
      }
   }
   $s.='</script>'."\n";

   switch ($atc) {
      case 'cond' :
         $add_atc_title='Add Event';
         $title='Events';
         $n=$data['event_num'];
         break;
      case 'act' :
         $add_atc_title='Add Action';
         $title='Actions';
         $n=$data['action_num'];
         break;
   }

   if ($edit && $atc=='cond') $s.='<table style="width:100%;background:none"><tr><td style="vertical-align:top">'."\n";

   //Add additional event/action
   $s.='<select style="font-size:0.9em" name="evrule_event_'.$atc.'_add" onchange="evrule_event_atc_add_changed(\''.$atc.'\');">'."\n";
   $s.='  <option value="" selected="selected">+ '.$add_atc_title.'</option>'."\n";
   foreach (${'event_'.$atc.'_types'} as $evtype=>$methods) {
      foreach ($methods as $key=>$val) {
         if ($key=='class') {
            $s.='  <optgroup label="'.$val['name'].'">'."\n";
            continue;
         }
         $s.='    <option class="'.$evtype.'" value="'.$key.'">'.$val['name'].'</option>'."\n";
      }
      $s.='  </optgroup>'."\n";
   }
   $s.='</select><br/>'."\n";

   $s.='<h3 tyle>'.$title.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="font-size:0.8em" href="#collapse_all" onclick="evrule_collexp_all(\''.$atc.'\',\'collapse\''.($context=='' ? '' : ',\''.$context.'\'').')">Collapse All</a> - <a style="font-size:0.8em" href="#expand_all" onclick="evrule_collexp_all(\''.$atc.'\',\'expand\''.($context=='' ? '' : ',\''.$context.'\'').')">Expand All</a></h3>'."\n";

   for($i=0; $i<$n; $i++) {
      $s.=edas_box($i,$data,TRUE,TRUE,$atc);
   }
   $s.='<a id="last_'.$atc.'" href="#last_'.$atc.'"></a>'."\n";

   if ($edit && $atc=='cond') {
      $s.='</td><td style="vertical-align:top">'."\n";
      $s.=tws_get_evt_form_general($evrules,$edit,$context,TRUE);
      $s.='</td></tr></table>'."\n";
   }
   $s.="\n";
   return $s;
}

function tws_evrule_display($evrule, $alias=null) {
   static $js=NULL;
   if ($evrule===NULL) { $js=FALSE; return TRUE; }
   if ($js===NULL) $js=TRUE;

   if (is_string($evrule)) {
      //------------------------------------------------------------------------------
      if (($evrules=tws_get_evrules($evrule))===FALSE) {
         tws_err('Unable to get event rule general data','event rule: '.$evrule);
      }
      if (($events=tws_get_evrule_conditions($evrule))===FALSE) {
         tws_err('Unable to get event rule conditions','event rule: '.$evrule);
      }
      if (($actions = tws_get_evrule_actions($evrule))===FALSE)  {
         tws_err('Unable to get event rule actions','event rule: '.$evrule);
      }
   } else {
      $evrules=$evrule['evrules'];
      $events=$evrule['events'];
      $actions=$evrule['actions'];
   }
   $er=($alias===null) ? $evrules['evrule_name'][0] : $alias;
   $cx='div#'.$er;

   $s= '<div id="'.$er.'">'."\n";
   $s.='   <!--========================================================================-->'."\n";
   $s.='   <div name="general">'."\n";
//   $s.='      <h3>General Options</h3>'."\n";
   $s.=tws_get_evt_form_general($evrules,FALSE,$cx);
   $s.='   </div>'."\n";
   $s.='   <!--========================================================================-->'."\n";
   $s.='   <table class="layout" style="background-color:transparent;width:100%"><tr><td style="background-color:transparent;width:50%;vertical-align:top"><div class="events" style="display:none">'."\n";
   $evt_form = tws_get_evt_form('cond',$evrules,$events,FALSE,$cx);
   $s.= $evt_form;
   tws_log("evt_form = $evt_form");
   $s.='   </div></td><td style="background-color:transparent;width:50%;vertical-align:top">'."\n";
   $s.='   <!--========================================================================-->'."\n";
   $s.='   <div class="actions" style="display:none">'."\n";
   $s.=tws_get_evt_form('act',$evrules,$actions,FALSE,$cx);
   $s.='   </div></td></tr></table>'."\n";
   $s.='</div>'."\n";

   $s.='<script type="text/javascript">'."\n";
   if ($js) {
      $s.='function evrule_set_display_mode(context) {'."\n";
      $s.='   var cx=\'\';'."\n";
      $s.='   if (typeof(context)!="undefined") cx=context+\' \';'."\n";

      $s.='   $(cx+\'input:button\').each(function() {'."\n";
      $s.='      $(this).hide();'."\n";
      $s.='   });'."\n";

      $s.='   $(cx+\'select[name*="new_attr"],select[name*="add"]\').each(function() {'."\n";
      $s.='      $(this).remove();'."\n";
      $s.='   });'."\n";

      $s.='   $(cx+\'select[name="evrules[evrule_timezone][0]"]\').each(function() {'."\n";
      $s.='      $(this).replaceWith(\'<input type="text" name="evrules[evrule_timezone][0]" value="\'+$(\'option:selected\',this).text()+\'"/>\');'."\n";
      $s.='   });'."\n";

      $s.='   $(cx+\'select[name*="evrule_event_act_response_type"]\').each(function() {'."\n";
      $s.='      $(this).replaceWith(\'<input type="text" name="\'+$(this).name+\'" value="\'+$(\'option:selected\',this).text()+\'"/>\');'."\n";
      $s.='   });'."\n";

      $s.='   $(cx+\'select[name*="evrules[evrule_type][0]"]\').each(function() {'."\n";
      $s.='      $(this).replaceWith(\'<input type="text" name="\'+$(this).name+\'" value="\'+$(\'option:selected\',this).text()+\'"/>\');'."\n";
      $s.='   });'."\n";

      $s.='   $(cx+\'select\').each(function() {'."\n";
      $s.='      var vals=new Array();'."\n";
      $s.='      $(this).find("option:selected").each(function() {'."\n";
      $s.='         vals.push($(this).text());'."\n";
      $s.='      });'."\n";
      $s.='      $(this).replaceWith(vals.join(\',\'));'."\n";
      $s.='   });'."\n";

      $s.='   $(cx+\'input\').each(function() {'."\n";
      $s.='      $(this).attr(\'readonly\',\'readonly\');'."\n";
      $s.='   });'."\n";

      $s.='   $(cx+\'input[name*="evrules[evrule_attr_correlation][0]"]\').each(function() {'."\n";
      $s.='      if ($(this).attr(\'checked\')) $(this).parent().show();'."\n";
      $s.='      else $(this).parent().hide();'."\n";
      $s.='   });'."\n";
      $s.='   $(cx+\'input:checkbox\').each(function() {'."\n";
      $s.='      $(this).attr(\'disabled\',\'disabled\');'."\n";
      $s.='   });'."\n";

      $s.='   $(cx+\'textarea\').each(function() {'."\n";
      $s.='      $(this).attr(\'readonly\',\'readonly\');'."\n";
      $s.='   });'."\n";

      $s.='   $(cx+\'a img[id*="_img"]\').each(function() {'."\n";
      $s.='      $(this).remove();'."\n";
      $s.='   });'."\n";

      $s.='   evrule_collexp_all(\'cond\', \'collapse\', cx);'."\n";
      $s.='   evrule_collexp_all(\'act\', \'collapse\', cx);'."\n";

      $s.='   $(cx+\'div.events\').css(\'display\',\'block\');'."\n";
      $s.='   $(cx+\'div.actions\').css(\'display\',\'block\');'."\n";
      $s.='};'."\n\n";
      $js=FALSE;
   }
   $s.='  $(function() { evrule_set_display_mode(\''.$cx.'\'); });'."\n";
   $s.='</script>'."\n";
   return $s;
}
?>
