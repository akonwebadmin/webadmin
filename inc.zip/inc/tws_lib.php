<?php
//   HORIZONT Software GmbH, Munich
//

/**
 * Error register. Use this function to store the last error message. Useful
 * mainly inside a function.
 *
 * @param (mixed) $msg Error message
 * @param (string) $attr Error caption attribute (message for users)
 * @param (string) $script Script name (insertd automaticaly if blank)
 * @param (int) $line Line number where the error occured
 * @return boolean
 *
 * Special effects:
 *   - calling tws_error with $msg===NULL, $attr===NULL causes emptying of the
 *     last error accumulator
 *
 *
 */
function tws_error($msg, $attr='', $script='', $line='') {
   global $tws_config;

   if ($msg===null && $attr===null) {
      $tws_config['last_error']=array();
      return TRUE;
   }

   if (is_object($msg)) {
      //support for PEAR_Error
      if (method_exists($msg,'getMessage') && method_exists($msg, 'toString')) {
         $attr=$msg->toString();
         $msg=$msg->getMessage();
      } else { //support for unknow objects (not intended for real use)
         $msg=get_class($msg);
         $attr=print_r($msg,1);
      }
   }

   $attr!==null && $attr=trim($attr);
   $script=='' && $script=$_SERVER['SCRIPT_NAME'];

   if ( ((is_string($msg) && $msg==='') || (is_array($msg) && count($msg)==0)) &&
        ($attr==='' || $attr===null) ) {
      // no/empty error message
      if (@count($tws_config['last_error']['msg']) > 0) {
         return TRUE;
      } else {
         return FALSE;
      }
   }

   tws_log() && tws_log('ERROR['.$script.'@'.$line.']: '.$attr.'. '.trim(is_array($msg) ? "\n".preg_replace("/\n\s*\n/", "\n", print_r($msg, 1)) : $msg));
   if (isset($tws_config['webadmin_log_file_max_size']) && $tws_config['webadmin_log_file_max_size'] == 0) { // don't write to log file
      $write = false;
   } else {                                           // test if the error is not same as last log
      if ($script == '') $script = $_SERVER['SCRIPT_NAME'];
      $session_error_record = array('msg' => $msg, 'attr' => $attr, 'script' => $script, 'line' => $line);
      if (tws_profile('tws_last_error') !== null) {
         $write = (tws_profile('tws_last_error') == $session_error_record) ? false : true;
      } else {
         $write = true;
      }
      tws_profile('tws_last_error', $session_error_record);
   }

   // write the error message to the webadmin log (see log file definition in php.ini)
   if ($write && ($tws_config['webadmin_log_file'] != '')) {
      $err_header = date('Y-m-d H:i:s').':'.$script.($line ? '['.$line.']' : '').($attr ? ':'.$attr : '');
      $err_body = trim(is_array($msg) ? "\n".preg_replace("/\n\s*\n/", "\n", print_r($msg, 1)) : $msg);
      if ($err_body != '') $err_body = "\n".$err_body;
      @error_log($err_header.$err_body."\n", 3, $tws_config['webadmin_log_file']);

      // test on filesize, check if it is not over the limit
      tws_test_size_and_clear_file($tws_config['webadmin_log_file']);
   }

// Is this error message an additional error message?
//   if (@count($tws_config['last_error']['msg'])>0) {
   if ($msg===null) {
      $tws_config['last_error']['msg']=array();
   } else {
      if (!is_array(@$tws_config['last_error']['msg'])) $tws_config['last_error']['msg']=array();
   }

   if ($attr===null) {
      $attr='';
   } elseif ($attr!=='') {
      // provide a dot at the end of the sentence
      preg_match("/[.;:]$/",$attr) || $attr=$attr.'.';
   }

//save previous attr;
   if (@trim($tws_config['last_error']['attr'])!='') {
      $tws_config['last_error']['msg']['attr']=$tws_config['last_error']['attr'];
   }

// Register the error messgae
   $tws_config['last_error']=array(
     'msg' => $tws_config['last_error']['msg'],
     'attr' => $attr,
     'script' => $script,
     'line' => $line,
     'time' => date('Y-m-d H:i:s')
   );

   while (count($tws_config['last_error']['msg'])>100) array_shift($tws_config['last_error']['msg']);
   if ((is_string($msg) && trim($msg)!=='') || (is_array($msg) && count($msg)>0)) {
      $tws_config['last_error']['msg'][]=$msg;
   }

   return TRUE;
}

/**
 * Function test log file size. If siye is greater than limit (in tws_config)
 * file is truncate to half.
 *
 * @param (string) $filename Name of log file (include path)
 * @return boolean False if file doesn't exist.
 */
function tws_test_size_and_clear_file($filename, $limit='') {
   if (file_exists($filename) == false)
     return false;

   global $tws_config;

   // get limit and convert it to bytes
   $limit==='' && $limit = isset($tws_config['webadmin_log_file_max_size']) ? $tws_config['webadmin_log_file_max_size'] : "5M";
   $limit = tws_max_size_to_bytes($limit);

   // test filesize only if limit is greater than 0
   clearstatcache();
   if (($limit > 0) && (filesize($filename) > $limit)) {
      $newfilename=$filename . ".tmp";
      //if( $tws_config['host_os']=='win32' ){
         $pos = intval($limit/2);
         $fp = fopen($filename, "r");
         fseek($fp, -$pos, SEEK_END);
         $newfp = fopen($newfilename, "w");
         while (!feof($fp)){
            $buffer=fread($fp,1048576);
            fwrite($newfp, $buffer);
         }
         fclose($fp);
         fclose($newfp);
         copy($newfilename,$filename);
         unlink($newfilename);
      /*
      } else {
         $cmd=new hwi_cmd("let n='wc -l $filename | cut -d'", "'-f1'/2",  '&& tail -$n ', hwi_cmd::operator("$filename > $newfilename", false), "&& mv $newfilename $filename");
         $stdout=$stderr=$ec="";
         tws_popen($cmd, $ec, $stdout, $stderr);
      }*/
   }
      // also check apache logs
      tws_apache_logs_test_size();
   return true;
}

function tws_apache_logs_test_size() {
   global $tws_config;

   // access log
   if (isset($tws_config['apache_access_log_max_size']) && $tws_config['apache_access_log_max_size']>0) {
      $limit = $tws_config['apache_access_log_max_size'];
      $limit = tws_max_size_to_bytes($limit);

      // try to find access log
      $filename = '';
      if (isset($tws_config['apache_access_log_file']))
         $filename = $tws_config['apache_access_log_file'];
      elseif (file_exists($tws_config['base_inst_dir'].'/httpd/logs/access_log'))
         $filename = $tws_config['base_inst_dir'].'/httpd/logs/access_log';

      if($filename != '' && filesize($filename) > $limit) {
         // cut file
         $newfilename=$filename . ".tmp";
         $pos = intval($limit/2);
         $fp = fopen($filename, "r");
         fseek($fp, -$pos, SEEK_END);
         $newfp = fopen($newfilename, "w");
         while (!feof($fp)){
            $buffer=fread($fp,1048576);
            fwrite($newfp, $buffer);
         }
         fclose($fp);
         fclose($newfp);
         copy($newfilename,$filename);
         unlink($newfilename);
      }
   }

   // error log
   if (isset($tws_config['apache_error_log_max_size']) && $tws_config['apache_error_log_max_size']>0) {
      $limit = $tws_config['apache_error_log_max_size'];
      $limit = tws_max_size_to_bytes($limit);

      // try to find access log
      $filename = '';
      if (isset($tws_config['apache_error_log_file']))
         $filename = $tws_config['apache_error_log_file'];
      elseif (file_exists($tws_config['base_inst_dir'].'/httpd/logs/error_log'))
         $filename = $tws_config['base_inst_dir'].'/httpd/logs/error_log';

      if($filename != '' && filesize($filename) > $limit) {
         // cut file
         $newfilename=$filename . ".tmp";
         $pos = intval(filesize($filename)/2);
         $fp = fopen($filename, "r");
         fseek($fp, -$pos, SEEK_END);
         $newfp = fopen($newfilename, "w");
         while (!feof($fp)){
            $buffer=fread($fp,1048576);
            fwrite($newfp, $buffer);
         }
         fclose($fp);
         fclose($newfp);
         copy($newfilename,$filename);
         unlink($newfilename);
      }
   }

}

function tws_max_size_to_bytes($limit) {
   if (!(is_numeric($limit))) {                       // is not numeric, convert to number
      $tmp_limit = floatval( $limit);                        // to number
      $tmp_unit = preg_replace('/^[0-9]+[\.]?[0-9]*[ ]*/', '', $limit); // get unit
      switch ($tmp_unit) {                            // convert to bytes
         case 'K':
            $limit = $tmp_limit * 1024;
            break;
         case 'M':
            $limit = $tmp_limit * pow(1024, 2);
            break;
         case 'G':
            $limit = $tmp_limit * pow(1024, 3);
            break;
         default:
            $limit = $tmp_limit;
            break;
      }
   }
   return $limit;
}

/// Error details formater. Prints last error message details (not the error title!)
function tws_perr($force_plain=false, $return=false) {
   global $tws_config;
   $err=@$tws_config['last_error'];

// test if the error log is not empty
   if (!isset($err) || count($err)==0 || (is_array($err['msg']) && count($err['msg'])==0) || $err['msg']=='') {
      return $return ? '' : FALSE;
   }

   if(tws_error_level() ) {
      $err_header=$err['time'].':'.$err['script'].($err['line']!='' ? '['.$err['line'].']' : '').': ';
      $err_header .= "\n";
   }
   else $err_header = "";

   if (is_array($err['msg']))
      $err_body = tws_print_error_body($err['msg']);
   else
      $err_body = $err['msg'];

   // reset last_error
   $tws_config['last_error']=array();

//   $err_body=is_array($err['msg']) ? "\n".preg_replace("/\n\s*\n/","\n",print_r($err['msg'],1)) : $err['msg'];
   $err_body=trim($err_body);

// prepare the the screen log message
   if (session_id() && !$force_plain) {
// error log output for html page
      $id=tws_rndstr('ELEMID');
      $errmsg="
<!-- ERROR LOG BEGIN -->
<script type=\"text/javascript\">
   function showerror$id () {
      linkelem=document.getElementById('errorlink$id');
      elem=document.getElementById('error$id');
      if (elem.style.display=='') {
         linkelem.innerHTML='Display Error Message';
         elem.style.display='none';
      } else {
         linkelem.innerHTML='Hide Error Message';
         elem.style.display='';
      }
   }
</script>
<a href=\"#\" id=\"errorlink$id\" onclick=\"showerror$id(); return false;\">Display Error Message</a>
<p id=\"error$id\" class=\"error\" style=\"display:none\">
  <span class=\"head\">".nl2br(htmlspecialchars($err_header))."</span><br/>\n".nl2br(htmlspecialchars($err_body, ENT_COMPAT | ENT_HTML401 | ENT_SUBSTITUTE))."
</p>
<!-- ERROR LOG END -->\n";
   } else {
// error log output message for cli env
      $errmsg=$err_header.$err_body."\n";
   }

// output on the screen
   if (!$return) {
      echo $errmsg;
      return TRUE;
   }
   return $errmsg;
}

function tws_print_error_body($array, $upkey='') {
   global $maestro_dir, $base_inst_dir, $tws_config;
   if(session_id())
      $isadmin = tws_error_level();
   else $isadmin = 1;
   $result='';

   foreach ($array as $key=>$val) {
      if (is_array($val)){
         static $haveErr = false;
         $result .= tws_print_error_body($val, $key);
         $result .= "\n";
         unset ($haveErr);
      }
      if( !$isadmin && "$key" != 'stdout' && "$upkey" != 'stdout' && "$key" != 'attr'){
         if($tws_config['last_error']['script'] == '/tws_db_query_action.php' && $key == 'message' )
            $haveErr = true; // show err msg from "tws_db_query_action.php"
         else
            continue;
      }
      if(is_object($val) && get_class($val)=="hwi_cmd" ){
         $result .= $val->compile('log');
         $result .= "\n";
      }

      if(is_string($val)){
         $val = preg_replace("/\n\s*\n/","\n",$val);
         $val = preg_replace("/\n$/","",$val);
         if($isadmin){     // ADMIN
            if(!is_numeric($key) && $key!='')
               $result .= "[$key] => $val\n";
            else
               $result .= $val."\n";
         }
         else {         // NOT ADMIN
            if("$key" == 'attr')
               $result .= $val."\n";
            else {      // stdout
               $str_arr = explode("\n", $val);
               foreach($str_arr as $str) {
                  if ($haveErr || preg_match('/AWS[0-9A-Z]{6}[EWI]/', $str)){
                     // remove path
                     $str = str_replace($base_inst_dir, '<WEBADMIN_DIR>', $str);
                     $str = str_replace($maestro_dir, '<TWS_DIR>', $str);
                     $result .= $str."\n";
                     $haveErr = true;        // after begining of error print all (may be on few lines)
                  }
               }
            }
         }
      }
   }
   return $result;
}

/// Print the last error message to the output.
// TODO: parameters description!

function tws_err($err_attr='', $last_error=''){
   global $tws_config, $force_plain;

// Update last error if requested
   if (tws_error($last_error, $err_attr)===FALSE) {
      return FALSE;
   }

// Form error message title
   $attr=@trim($tws_config['last_error']['attr']);
   if ($attr=='') {
      $attr="Error";
   } elseif (($prefix=strtolower(substr($attr,0,5)))!='error' && $prefix!='warni') {
      $attr="Error: ".$attr;
   }

// Print error message title
   if (session_id() && !$force_plain) {
      echo "<p class=\"error\">".htmlspecialchars($attr)."&nbsp;";
      tws_perr();
      echo "</p>\n";
   } else {
      echo $attr."\n";
      tws_perr($force_plain);
   }

   return TRUE;
}

// Print Warning without logging
function tws_warning($msg='') {
   if($msg!='')
      echo "<br><p class='warning'>$msg</p>";  // TODO:   htmlspecialchars() ???
}

/// Stop script execution with error message output
function tws_dyer($exitstatus=1, $last_error='', $backurl='') {
   global $tws_config, $rqst_opennew;
   if (!session_id()) {
      tws_err(null, $last_error);
      die($exitstatus);
   }
   tws_waiting(0);
   if (!is_int($exitstatus)) {
      $attr=preg_replace("/<\/body>\s*<\/html>/i",'',$exitstatus);
   } else $attr="";

   tws_err($attr, $last_error);

   if(tws_profile('opener') == basename($_SERVER['PHP_SELF']))   // list page
      die("</body>\n</html>");

   echo "<br><br>\n";
   if(!empty($rqst_opennew))
      echo "<input type='button' value='Close Window' onclick='window.close()'>\n";
   else echo "<input type='button' value='Ok' style='width:50px' onclick='dyer()'>\n";

   echo "
   <script type='text/javascript'>
   var backurl = '$backurl';
   function dyer(){
      if(typeof(jQuery)!='undefined' && $('#show').parents('.ui-dialog').is(':visible'))
         $('#show').dialog('close');
      else if(window.name == 'tws_popup')
         window.close();
      else if(backurl != '')
         window.location.replace(backurl);
      else window.location.replace('".tws_profile('opener')."');
   }
   </script>\n";

   die("</body>\n</html>");
}

///
function tws_mkdir($dir) {
   global $tws_config;
   if( $tws_config['host_os']=='win32' ){
      $cmd=new hwi_cmd('mkdir', $dir);
   } else {
      $dir=addcslashes($dir, ' ');
      if (tws_yesno($tws_config['virtual_hosts'],TRUE,FALSE)) $cmd=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), 'mkdir', '-p', $dir);
      else $cmd=new hwi_cmd('mkdir', '-p', $dir);
   }
   $stdout=$stderr="";
   tws_popen($cmd, $ec, $stdout, $stderr);

   clearstatcache();
   if ($ec!='0' || ($tws_config['host_os']!='win32' && (!file_exists($dir) || is_file($dir)))) {
      tws_error(array('cmd'=>$cmd->compile('log'), 'stdout'=>$stdout, 'stderr'=>$stderr), "Unable to create directory '$dir'");
      return FALSE;
   }
   return TRUE;
}

function tws_rmdir($dir) {
   global $tws_config;
   if( $tws_config['host_os']=='win32' ){
      $cmd=new hwi_cmd('rmdir', '/S', '/Q', $dir);
   } else {
      if (tws_yesno($tws_config['virtual_hosts'],TRUE,FALSE)) $cmd=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), 'rm', '-r', '-f', $dir);
      else $cmd=new hwi_cmd('rm', '-r', '-f', $dir);
   }
   $stdout=$stderr="";
   tws_popen($cmd, $ec, $stdout, $stderr);

   clearstatcache();
   if ($ec!='0' || ($tws_config['host_os']!='win32' && (file_exists($dir) || is_file($dir)))){
      tws_error(array('cmd'=>$cmd->compile('log'), 'stdout'=>$stdout, 'stderr'=>$stderr), "Unable to remove directory '$dir'");
      return FALSE;
   }
   return TRUE;
}

///
function tws_cp($src, $dst, $opts='--parents') {
   global $tws_config;
   clearstatcache();
   if (!file_exists(dirname($dst))) {
      if (preg_match('/--parents/',$opts) && !tws_mkdir(dirname($dst))) {
         return FALSE;
      } else {
         tws_error("tws_cp: Unable to copy file - parent directory ".dirname($dst)." does not exist.","Unable to copy file");
         return FALSE;
      }
   }
// cp $src -> $dst
   if (!file_exists($src) || !is_file($src)) {
      tws_error("tws_cp: Unable to copy '$src' -> '$dst'. The source file is not a regular file.", "Unable to copy file");
      return FALSE;
   }

   if (is_dir($dst)) $dst.=basename($src);
   if (copy($src, $dst)===FALSE && ($tws_config['host_os']!='win32' || ($tws_config['host_os']=='win32' && @filesize($dst)!==0))) {
      tws_error("tws_cp: Unable to copy '$src' -> '$dst'.", "Unable to copy file");
      return FALSE;
   }
   return TRUE;
}

///
function tws_mv($src, $dst, $opts='--parents') {
   global $tws_config;
   clearstatcache();
   if (!file_exists(dirname($dst))) {
      if (preg_match("/--parents/",$opts) && !tws_mkdir(dirname($dst))) {
         return FALSE;
      } else {
         tws_error("tws_mv: Unable to move file. Parent directory ".dirname($dst)." does not exist.", "Unable to move file");
         return FALSE;
      }
   }
// rename $src to $dst
   if (rename($src, $dst)===FALSE) {
      tws_error("tws_mv: Unable to move '$src' -> '$dst'.", "Unable to move file");
      return FALSE;
   }
   return TRUE;
}

// Warning: the $mode parameter MUST be given in the Octal value, it means: 0755 not '0755'. Also: 0775, 0664, 0644, 0666, etc.
function tws_chmod($filename, $mode /* !!!!OCTAL!!!! */, $owner_maestro=TRUE) {
   global $tws_config;
   if ($tws_config['host_os']!='win32') {
      if ($owner_maestro && tws_yesno($tws_config['virtual_hosts'],TRUE,FALSE)) {
         $mode='0'.decoct($mode);
         $cmd=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), 'chmod', $mode, $filename);
         $stdout=$stderr="";
         tws_popen($cmd, $rc, $stdout, $stderr);
         $rc=($rc!='0') ? FALSE : TRUE;
      } else {
         $rc=chmod($filename, $mode);
      }
      if (!$rc) {
         tws_error("Unable to change file mode '$mode' on '$filename'.");
         return FALSE;
      }
   }
   return TRUE;
}

/// Prepares values of the given structure for the required output.
/// \param var Input structure that is to be filtered (output parameter!).
/// \param htmlfilter Filter that is to be applied (htmlspecialchars by default)
///       htmlfilter==1 =>htmlspecialchars(stripslashes($var))
function tws_adjust4html(&$var, $htmlfilter='htmlspecialchars') {
   if( is_array($var) ){
      foreach( $var as $key=>$val ){
         tws_adjust4html( $var[$key], $htmlfilter );
      }
      return;
   }
   if ($htmlfilter==1) {
      $var=htmlspecialchars(stripslashes($var));
   } else {
      $var = $htmlfilter($var);
   }
}

/// Translating function for tws_types.
/// \param typename Type class name.
/// \param type Type value to be translated.
/// \return Returns the translation of the \c type ( \ref tws_types[\c typename][\c type]
///  or \c type in case that the translation in \ref tws_types is missing.
function tws_typeval($typename, $type) {
   global $tws_types;
   if (isset($tws_types[$typename][$type])) {
      return $tws_types[$typename][$type];
   } elseif (isset($tws_types[$typename][strtoupper(trim($type))])) {
      return $tws_types[$typename][strtoupper($type)];
   }
   return $type;
}
function tws_typekey($typename, $val) {
   global $tws_types;
   if (isset($tws_types[$typename][$val])) {
      return $val;
   } elseif (isset($tws_types[$typename][strtoupper(trim($val))])) {
      return $val;
   } elseif (($key=array_search($val, $tws_types[$typename]))!==FALSE) {
      return $key;
   } elseif (($key=array_search(strtoupper(trim($val)), $tws_types[$typename]))!==FALSE) {
      return $key;
   }
   return $val;
}


///
function tws_yesno($choice, $yes='YES', $no='NO', $numtreshold=0) {
   $choice=strtoupper(trim($choice));
   if ($choice=="YES" || $choice=="Y" ||
       $choice===true || $choice=='ON' || $choice=='ENABLED' || $choice=='ENABLE' ||
       ((is_numeric($choice) || is_int($choice)) && $choice>$numtreshold))
      return $yes;
   return $no;
}

//converts username from UPN (User Principal Name - user@domain) to DLLN (Down-Level Logon Name - domain\user)
function tws_upn2dlln($uname) {
   // user@domain
   $uname=str_replace("\\\\","\\",trim($uname));
   if (strpos($uname, '@')) {
      list($user, $domain) = explode('@', $uname);
      $uname=$domain."\\".$user;
   }
   if (strpos($uname, '\\')!==false) {
      list($domain, $user)=explode('\\', $uname);
      if (($pos=strpos($domain, '.'))!==false) $domain=substr($domain,0,$pos);
      $uname=$domain.'\\'.$user;
   }
   return $uname;
}

function tws_get_authtype() {
   global $tws_config;
   include $tws_config['base_inst_dir'].'/etc/authconf.php';
   return strtolower($authtype);
}

/// This function checks the authentication of the user.
/// \note It stops the script execution if the authentication is missing.
function tws_auth() {
   global $tws_config;

   // php session settings moved in tws_functions

   if (($authtype=tws_get_authtype())=="os") {

      if (tws_profile('auth_user_name')!==null && tws_profile('auth_user_name')!='') {
         //FIXME:
         //Setting up the HTTP Authentication variables because they are missing since using HTML login dialog
         //but many scripts are working with them
         $_SERVER['PHP_AUTH_USER']=tws_profile('auth_user_name');
         $_SERVER['PHP_AUTH_PW']= tws_decrypt(tws_profile('auth_user_pw'));
         return TRUE;
      }

      $_SERVER['PHP_AUTH_USER']=tws_upn2dlln($_POST['PHP_AUTH_USER']);
      $_SERVER['PHP_AUTH_PW']=$_POST['PHP_AUTH_PW'];
      if (isset($_POST['redirect']) && $_POST['redirect']!='') {
         //forward the redirect to new login attempt (taken from the last unsuccessful login)
         $redir='?redirect='.$_POST['redirect'];
      } else {
         $redir=(isset($_SERVER['REQUEST_URI']) && strlen($_SERVER['REQUEST_URI'])>1) ? '?redirect='.base64_encode($_SERVER['REQUEST_URI']) : '';
      }

// Begin - Troubleshooting options
      $inclpwd=FALSE;
      $inclcmd=FALSE;
// End - Troubleshooting options

      if (!isset($_SERVER['PHP_AUTH_USER']) || trim($_SERVER['PHP_AUTH_USER'])=='') {
         header('Location: /tws_login.php'.$redir);
         exit;
      }
      else {
         if (file_exists($tws_config['base_inst_dir'].'/httpd/conf/denyusers')) {
            $denied_users=file($tws_config['base_inst_dir']."/httpd/conf/denyusers");
            if (in_array($_SERVER['PHP_AUTH_USER'] . "\n",$denied_users)) {
               $fp6=fopen($tws_config['maestro_dir'].'/webadmin/log/lockout.log','a');
               $datestamp=date("YmdHis");
               fwrite($fp6,"$datestamp : Locked out User " . $_SERVER['PHP_AUTH_USER'] . " attempted to log in but was blocked\n");
               fclose($fp6);
               include($tws_config['base_inst_dir'].'/httpd/htdocs/lockedout.html');
               exit;
            }
         }
         if ($use_authusers == "yes") {
            if (file_exists($tws_config['base_inst_dir'].'/httpd/conf/authusers')) {
               $in_authusers=FALSE;
               $fp7=fopen($tws_config['base_inst_dir'].'/httpd/conf/authusers',"r");
               while ($buffer=fgets($fp7,4096)) {
                  $authusername=trim(strtok($buffer,":"));
                  if ($authusername == $_SERVER['PHP_AUTH_USER']) {
                     $in_authusers=TRUE;
                     break;
                  }
               }
               fclose($fp7);
               if ($in_authusers == FALSE) {
                  sleep(1);
                  header('Location: /tws_logout.php');
                  exit;
               }
            } else {
               sleep(1);
               header('Location: /tws_logout.php');
               exit;
            }
         }

         $buffer = $stderr = '';
         if ($tws_config['host_os']=='win32') {
            if (trim($_SERVER['PHP_AUTH_PW'])=='') {
               tws_error(array('username='.$_SERVER['PHP_AUTH_USER'], 'Platform=Win32', 'Autyhtype=OS', 'AuthMethod=sudo.exe'), 'Authentication failed. Empty password is not supported.');
            } else {
               $cmd=new hwi_cmd(tws_sudo('', $_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW']), 'cmd.exe', '/c', 'echo y');
               if ((tws_popen($cmd,$ec,$buffer,$stderr))===FALSE || $ec!=0 || substr($buffer,0,1)!='y') {
                  tws_error(array('cmd'=>$cmd->compile('log'), 'stdout'=>$buffer, 'stderr'=>$stderr, 'ec'=>$ec), 'Authentication failed');
               }
            }
         }
         else {
            //try ckpw1.3 first - with CREDS env parameter username:password in base64 encoding
            $ckpw_version=0;
            $shell=isset($tws_config['shell']) ? $tws_config['shell'] : '/bin/ksh';
            $pam=isset($tws_config['pam']) ? $tws_config['pam'] : 'login';
            $cmd = new hwi_cmd(); //hwi_lib_sys
            $cmd->setOption('SHELL', $shell);
            $cmd->pushCommandEnv('CREDS',hwi_cmd::hidden(base64_encode($_SERVER['PHP_AUTH_USER'].':'.$_SERVER['PHP_AUTH_PW'])));
            $cmd->pushCommandEnv('PAM',$pam);
            $cmd->pushCommand($tws_config['base_inst_dir'].'/bin/ckpw');
            $buffer=''; $stderr='';
            if ($rc_popen=hwi_popen($cmd,$ec,$buffer,$stderr)!==FALSE) {
               if (preg_match('/PAM/',$stderr) || preg_match('/PAM/', $buffer)) $ckpw_version=13;
               if ($ec==1 || preg_match('/Missing the parameters/',$stderr)) $ckpw_version=12;
               if ($ec==0 && $ckpw_version>12) {
                  //ckpw-1.3 available, authentication succesfull
                  $buffer='y';
               } elseif ($ckpw_version==12) {
                     //try ckpw1.2 - USER and PASS parameters unencoded
                     $cmd = new hwi_cmd(); //hwi_lib_sys
                     $cmd->setOption('SHELL', $shell);
                     $cmd->pushCommandEnv('USER',$_SERVER['PHP_AUTH_USER']);
                     $cmd->pushCommandEnv('PASS',hwi_cmd::hidden($_SERVER['PHP_AUTH_PW']));
                     $cmd->pushCommandEnv('PAM',$pam);
                     $cmd->pushCommand($tws_config['base_inst_dir'].'/bin/ckpw');
                     $buffer=''; $stderr='';
                     $rc_popen=hwi_popen($cmd,$ec,$buffer,$stderr);
                     if ($ec!=0) tws_error(array('stdout'=>$buffer, 'stderr'=>$stderr, 'ec'=>$ec), 'Authentication of user \''.$_SERVER['PHP_AUTH_USER'].'\' failed (ckpw-pam-1.2)');
                     else $buffer='y';
               } else tws_error(array('stdout'=>$buffer, 'stderr'=>$stderr, 'ec'=>$ec), 'Authentication of user \''.$_SERVER['PHP_AUTH_USER'].'\' failed (ckpw-pam)');
            } else tws_error(array('stdout'=>$buffer, 'stderr'=>$stderr), 'Calling authentication provider failed');
         }

// ckpw-1.1 (if 1.2 not available)
         if ($tws_config['host_os']!='win32' && $ckpw_version<12 && substr($buffer,0,1)!='y') {
            $auth_command="$shell -c \"echo '" . $_SERVER['PHP_AUTH_USER'] . "\\0000" . strtr($_SERVER['PHP_AUTH_PW'],array('$'=>'\$','\''=>'\'\"\'\"\'')) . "\\00000\\0000'|".$tws_config['base_inst_dir']."/bin/ckpw echo y\"";
            $auth_command_log="$shell -c \"echo '".$_SERVER['PHP_AUTH_USER']."\\0000*****"."\\00000\\0000'|".$tws_config['base_inst_dir']."/bin/ckpw echo y\"";

            $buffer=''; $stderr='';
            hwi_popen(array('cmd'=>$auth_command, 'log'=>$auth_command_log), $ec, $buffer, $stderr);

            if (substr($buffer,0,1)!='y') {
               // some unix shells may require echo option '-e' to correctly interpret backslashes)
               $auth_command="$shell -c \"echo -e '" . $_SERVER['PHP_AUTH_USER'] . "\\0000" . strtr($_SERVER['PHP_AUTH_PW'],array('$'=>'\$','\''=>'\'\"\'\"\'')) . "\\00000\\0000'|".$tws_config['base_inst_dir']."/bin/ckpw echo y\"";
               $auth_command_log="$shell -c \"echo -e '".$_SERVER['PHP_AUTH_USER']."\\0000*****"."\\00000\\0000'|".$tws_config['base_inst_dir']."/bin/ckpw echo y\"";

               $buffer=''; $stderr='';
               hwi_popen(array('cmd'=>$auth_command,'log'=>$auth_command_log),$ec,$buffer,$stderr);
            }
         }

// Another UNIX OS authentication method
         if ($tws_config['host_os']!='win32' && substr($buffer,0,1)!='y' && file_exists($tws_config['base_inst_dir'].'/bin/pwauth')) {
            $auth_command="$shell -c \"USER=\\\"".$_SERVER['PHP_AUTH_USER']."\\\" PASS=\\\"" . strtr($_SERVER['PHP_AUTH_PW'],array("\\"=>"\\\\",'"'=>'\"','$'=>'\$')) . "\\\" ".$tws_config['base_inst_dir']."/bin/pwauth && echo y\"";
            $auth_command_log="$shell -c \"USER=\\\"".$_SERVER['PHP_AUTH_USER']."\\\" PASS=\\\"*****\\\" ".$tws_config['base_inst_dir']."/bin/pwauth && echo y\"";
            $buffer=''; $stderr='';
            hwi_popen(array('cmd'=>$auth_command,'log'=>$auth_command_log),$ec,$buffer,$stderr);
         }

         if (substr($buffer,0,1)!='y') {
            $fp3=fopen($tws_config['maestro_dir'].'/webadmin/log/auth.log','a');
            $datestamp=date("YmdHis");
            $timestamp=time();
            $entry=$datestamp . ":" . $_SERVER['REMOTE_ADDR'] . ":" . $_SERVER['PHP_AUTH_USER'];
            if ($inclpwd) {
               $entry .= ":" . $_SERVER['PHP_AUTH_PW'];
            }
            if ($inclcmd) {
               $entry .= ":" . $auth_command;
            }
            $entry .= "\n";
            fwrite($fp3,$entry);
            fclose($fp3);
            if (isset($lockout)) {
               $fp4=fopen($tws_config['maestro_dir'].'/webadmin/log/auth.log','r');
               fseek($fp4,-8000,SEEK_END);
               if (!feof($fp4)) {
                  fgets($fp4,4096);
               }
               $fail_count=0;
               while (!feof($fp4)) {
                  $buffer=fgets($fp4,4096);
                  list($log_datestamp,$log_IP,$log_username)=explode(":",$buffer);
                  $log_username=trim($log_username);
                  if ($log_username == $_SERVER['PHP_AUTH_USER']) {
                     $log_year=substr($log_datestamp,0,4);
                     $log_month=substr($log_datestamp,4,2);
                     $log_day=substr($log_datestamp,6,2);
                     $log_hour=substr($log_datestamp,8,2);
                     $log_minute=substr($log_datestamp,10,2);
                     $log_second=substr($log_datestamp,12,2);
                     $log_timestamp=mktime($log_hour,$log_minute,$log_second,$log_month,$log_day,$log_year);
                     if ($log_timestamp > ($timestamp - 3600)) {
                        $fail_count++;
                     }
                  }
               }
               fclose($fp4);
               if ($fail_count >= $lockout) {
                  $user_denied=FALSE;
                  $fp5=fopen($tws_config['base_inst_dir'].'/httpd/conf/denyusers','r');
                  while ($buffer=fgets($fp5,4096)) {
                     $checkuser=trim($buffer);
                     if ($checkuser == trim($_SERVER['PHP_AUTH_USER'])) {
                        $user_denied=TRUE;
                     }
                  }
                  fclose($fp5);
                  if ($user_denied == FALSE) {
                     $fp5=fopen($tws_config['base_inst_dir'].'/httpd/conf/denyusers','a');
                     fwrite($fp5,$_SERVER['PHP_AUTH_USER'] . "\n");
                     fclose($fp5);
                  }
                  $fp6=fopen($tws_config['maestro_dir'].'/webadmin/log/lockout.log','a');
                  fwrite($fp6,"$datestamp : User " . $_SERVER['PHP_AUTH_USER'] . " Locked out after $lockout failed login attempts\n");
                  fclose($fp6);
               }
            }
            sleep(1);
            header('Location: /tws_login.php'.$redir);
            exit;
         }
      }
   }
   else {
      $_SERVER['PHP_AUTH_USER']=tws_upn2dlln($_SERVER['PHP_AUTH_USER']);
      if (tws_profile('auth_user_name')!==null && tws_profile('auth_user_name')===$_SERVER['PHP_AUTH_USER']) return TRUE;
   }

   //ERR17359
   session_regenerate_id();

//last sanity check - this condition can help if e.g. $authconf=='ldap', but the auth.conf file is for OS auth...
   if (trim($_SERVER['PHP_AUTH_USER'])=='') {
      sleep(1);
      //ERR18438: The realm name must be identical to the value of AuthName in auth.conf!!!
      //See the ERR18438 for more details
      header('WWW-Authenticate: Basic realm="IWS/WebAdmin"');
      header('HTTP/1.0 401 Unauthorized');
      include($tws_config['base_inst_dir'].'/httpd/htdocs/cancel.html');
   }

   $groupname = tws_groupname($_SERVER['PHP_AUTH_USER']);
   tws_profile('auth_user_name', $_SERVER['PHP_AUTH_USER']);
   tws_profile('auth_user_group', $groupname);
   tws_profile('auth_user_pw', tws_encrypt($_SERVER['PHP_AUTH_PW']));

// get IWS technical users map
// IWS authority = user name under that all IWS command shuld be executed (on windows we must strip the password out)
   if (($twsumap=tws_get_twsumap())!==FALSE && isset($twsumap[$_SERVER['PHP_AUTH_USER']])) {
      list($tws_authority,$tws_authority_pw)=explode(' ',preg_replace('/\s+/',' ',trim($twsumap[$_SERVER['PHP_AUTH_USER']])));
      tws_profile('twscli_authtype','os');
   } else {
      $tws_authority=$_SERVER['PHP_AUTH_USER'];
      $tws_authority_pw=$_SERVER['PHP_AUTH_PW'];
      tws_profile('twscli_authtype',$authtype);
   }
   tws_profile('tws_authority', $tws_authority);
   tws_profile('tws_authority_pw', tws_encrypt($tws_authority_pw));
//   tws_profile('tws_authority_pw', $tws_authority_pw);
   if ($tws_config['host_os']=='win32') {
      // get IWS technical users passwords
      tws_profile('sudo_auth', array($tws_authority, tws_encrypt($tws_authority_pw)));
   } else {
      tws_profile('sudo_auth', array($tws_authority));
   }

// check if the all_users dir is created
   clearstatcache();
   if (!file_exists($tws_config['webadmin_all_user_dir'])) {
      if (tws_mkdir($tws_config['webadmin_all_user_dir'])===FALSE) {
         tws_error("all_users directory '".$tws_config['webadmin_all_user_dir']."' cannot be created");
      } else tws_chmod($tws_config['webadmin_all_user_dir'], 0775);
   }
// create webadmin user home dir, if is not created (for first time logged users)
   if (!file_exists($tws_config['webadmin_user_home_dir'].'/'.$_SERVER['PHP_AUTH_USER'])) {
      if (tws_mkdir($tws_config['webadmin_user_home_dir'].'/'.$_SERVER['PHP_AUTH_USER'])===FALSE) {
         tws_error("User's home directory '".$tws_config['webadmin_user_home_dir'].'/'.$_SERVER['PHP_AUTH_USER']."' cannot be created");
      } else tws_chmod($tws_config['webadmin_user_home_dir'].'/'.$_SERVER['PHP_AUTH_USER'], 0775);
   }
// create use home .TWS dir
   $tmp = $tws_config['webadmin_user_home_dir'].'/'.$_SERVER['PHP_AUTH_USER'].'/.TWS';
   if (!file_exists($tmp)) {
      if (tws_mkdir($tmp)===FALSE) {
         tws_error("User's home directory '".$tmp."' cannot be created");
      } else tws_chmod($tmp, 0775);
   }

// create the credentials file (useropts file)  - but only in case that {conman|composer|planman}_args==''
   if ((isset($tws_config['tws_connparms']) && trim($tws_config['tws_connparms'])=='') ||
       (!isset($tws_config['tws_connparms']) && (trim($tws_config['composer_args'])=='' || trim($tws_config['conman_args'])=='' || trim($tws_config['planman_args'])==''))) {

      if ($tws_authority!='' && $tws_authority_pw!='') {
         //be sure localopts are loaded
         tws_get_localopts();
         $newline=$tws_config['host_os']!='win32' ? "\n" : "\r\n";
         $twsuseropts_filename=$tws_config['webadmin_user_home_dir'].'/'.$_SERVER['PHP_AUTH_USER'].'/.TWS'.'/'.(isset($tws_config['localopts']['useropts']) ? $tws_config['localopts']['useropts'] : 'tws');
         if (($fp=fopen($twsuseropts_filename,'w'))!==FALSE) {
            if (fwrite($fp,"USERNAME = ${tws_authority}${newline}PASSWORD = \"".tws_decrypt($tws_authority_pw)."\"")>0) {
               fclose($fp);
// 0666 because IWS CLIs *can be* executed through sudo. If it is security hazard, then the best way is to take full
// control over the useropts file - through the 'tws_connparms' configuration parameter in IWS/WebAdmin
               tws_chmod($twsuseropts_filename, 0666, FALSE); //owner of the file is not always the IWS maestro!
               tws_profile('tws_connparms', array("-file", $twsuseropts_filename));
               //useropts file encryption
               $cmd=new hwi_cmd(tws_sudo(''), $tws_config['maestro_dir'].'/bin/conman', tws_profile('tws_connparms'), '-gui', 'status', hwi_cmd::operator('2>&1', FALSE));
               $stdout='';

               //ERR18233 - if the useropts file is not encrypted, it must be deleted!!!
               if (tws_popen($cmd, $ec, $stdout, $stdout)===FALSE || $ec!='0' || ($fimg=file_get_contents($twsuseropts_filename))===FALSE || !preg_match('/PASSWORD\s*=\s*"ENCRYPT:/', $fimg)) {
                  tws_error(array('command'=>$cmd->compile('log'), 'stdout'=>$stdout, 'ec'=>$ec), 'WARNING: Useropts file encryption finished unexpectedly, it will be removed.');
                  $n=0;
                  while (!unlink($twsuseropts_filename) && (++$n<30)) {
                     tws_error($twsuseropts_filename, "ERROR: Unable to remove the useropts file ($n/30)");
                     sleep(1); //see ERR18233
                  }
               }

               if (tws_popen($cmd, $ec, $stdout, $stdout)===FALSE || $ec!='0') {
                  tws_error(array('command'=>$cmd->compile('log'), 'stdout'=>$stdout), 'WARNING: Useropts file encryption finished unexpectedly, it will be removed.');
                  $n=0;
                  while (!unlink($twsuseropts_filename) && (++$n<30)) {
                     tws_error($twsuseropts_filename, "ERROR: Unable to remove the useropts file ($n/30)");
                     sleep(1); //see ERR18233
                  }
               } else {
                  //Some customer were used to have WebAdmin to create the userpots files in the old location
                  //in webadmin/home/<user> folder (not in the .TWS subfolder), WebAdmin must still support it
                  if (tws_yesno($tws_config['useropts-3.1.5'], TRUE, FALSE)) {
                     $twsuseropts_filename_315=$tws_config['webadmin_user_home_dir'].'/'.$_SERVER['PHP_AUTH_USER'].'/.'.(isset($tws_config['localopts']['useropts']) ? $tws_config['localopts']['useropts'] : 'tws');
                     if (copy($twsuseropts_filename, $twsuseropts_filename_315)===FALSE) {
                        tws_error(array('useropts_316'=>$twsuseropts_filename, 'useropts_315'=>$twsuseropts_filename_315), 'WARNING: Failed to copy the useropts file to the old location.');
                     } else {
                        tws_chmod($twsuseropts_filename_315, 0666, FALSE);
                     }
                  }
               }

               //add home directory environment variable to force IWS utilities to search the useropts file in webadmin home directory
               if ($tws_config['host_os']=='win32') {
                  if (!isset($tws_config['twsenv']['USERPROFILE'])) {
                     $twsenv=array('USERPROFILE' => $tws_config['webadmin_user_home_dir'].'/'.$_SERVER['PHP_AUTH_USER']);
                     $tws_config['twsenv']['USERPROFILE']=$twsenv['USERPROFILE']; //appliad immeditaly (automatically in tws_config_init later)
                     tws_profile('twsenv', $twsenv);
                  }
               } else {
                  if (!isset($tws_config['twsenv']['HOME'])) {
                     $twsenv=array('HOME' => $tws_config['webadmin_user_home_dir'].'/'.$_SERVER['PHP_AUTH_USER']);
                     $tws_config['twsenv']['HOME']=$twsenv['HOME']; //appliad immeditaly (automatically in tws_config_init later)
                     tws_profile('twsenv', $twsenv);
                  }
               }
            } else {
               fclose($fp);
               tws_error("Unable to write user's IWS credentials file '$twsuseropts_filename'");
            }
         } else tws_error("Unable to create user's IWS credentials file '$twsuseropts_filename'");
      } else tws_error("Missing or incomplete authentication data. Cannot continue to prepare IWS credentials.");
   }

// set 'is_admin' status
   $authgroups=$tws_config['base_inst_dir'].'/httpd/conf/authgroups';
   if (file_exists($authgroups)) {
      if (!$fp2 = fopen($authgroups,"r")) {
         tws_profile('is_admin',FALSE);
      } else {
         while ($buffer=fgets($fp2,4096)) {
            $group=strtok($buffer,":");
            if ($group == "admin") {
               $members=trim(strtok(":"));
               $admins=explode(" ",$members);
            }
         }
         fclose($fp2);
         if (isset($admins)) {
            tws_profile('is_admin',in_array(tws_profile('auth_user_name'),$admins));
         } else {
            tws_profile('is_admin',FALSE);
         }
      }
   }
   tws_clear_dir($tws_config['webadmin_log_dir'], '*.tlog', $tws_config['webadmin_log_file_max_age']);

// load stored layout data
   $layout_filename=$tws_config['webadmin_user_home_dir'].'/'.$_SERVER['PHP_AUTH_USER'].$tws_config['user_setting_dir'].'/layout.php';
   if (file_exists($layout_filename)) {
      if (@include $layout_filename) {
         foreach ($layout as $t=>$val) {
            tws_profile($t, $val);
         }
      }
   }
   tws_audit_loginout('LOGIN');
   if ($authtype=='os' && isset($_POST['redirect']) && trim($_POST['redirect']!='')) {
      header('Location: /index.php?redirect='.trim($_POST['redirect']));
      exit;
   }
   return TRUE;
}

//    Log events 'LOGIN' and 'LOGOUT' in webadmin/_/log/tws_audit_login.log
function tws_audit_loginout($event){
   global $tws_config;
   if( array_key_exists('audit_login_file', $tws_config))
      $destination = $tws_config['audit_login_file'];
   else $destination = $tws_config['webadmin_log_dir'].'/tws_audit_login.log';

   if (!file_exists($destination)) {
      if (($fp = fopen($destination, 'w')))     // create file
         fclose($fp);                           // close file
      else return false;
   }
   $tz = date_default_timezone_get();
   $message = date('Y-m-d H:i:s T').' '.str_pad($event, 6, ' ').' USERNAME='.$_SERVER['PHP_AUTH_USER'].PHP_EOL;
   error_log($message, 3, $destination);
   tws_test_size_and_clear_file($destination);
   return;
}

function tws_get_twsumap() {
   global $tws_config;

//read the twsumap file:
   $catcmd=isset($tws_config['cat']) ? $tws_config['cat'] : ($tws_config['host_os']=='win32' ? "$tws_config[maestro_dir]/webadmin/bin/type" : '/bin/cat');
   $file="$tws_config[maestro_dir]/webadmin/etc/twsumap";
   $cmd=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), $catcmd, ($tws_config['host_os']=='win32' ? str_replace('/','\\',$file) : $file));
   $stdout=array(); $stderr='';
   if (tws_popen($cmd, $ec, $stdout, $stderr)===FALSE || $ec!=0) {
      tws_error(array("command"=>$cmd->compile('log'), "stdout"=>$stdout, "stderr"=>$stderr), "Unable to read $file.");
      return FALSE;
   }

   $tech_user='';
   $twsumap=array();
   foreach ($stdout as $buff) {
      //strip out comments
      if (preg_match('/^\s*#/', $buff)) continue;

      if (preg_match('/^\s*(\S+\s*\S*)\s*:([^:]*)$/', $buff, $_regs)) {
         $tech_user=trim($_regs[1]);
         $buff=$_regs[2];
      }

      if ($tech_user==='') continue;

      foreach (explode(' ',$buff) as $user) {
         $user=trim($user);
         if ($user==='') continue;
         $twsumap[$user]=$tech_user;
      }
   }

   return $twsumap;
}

function tws_connparms() {
   global $tws_config;

   if (($tws_connparms=tws_profile('tws_connparms'))!==null){
      $tws_config['tws_connparms']=$tws_connparms;
      $tws_config['conman_args']=$tws_config['tws_connparms'];
      $tws_config['composer_args']=$tws_config['tws_connparms'];
      $tws_config['planman_args']=$tws_config['tws_connparms'];
      return $tws_config['tws_connparms'];
   }
   if (!isset($tws_config['tws_connparms'])) {
      if (!isset($tws_config['composer_args'])) {
//Important note: tws_profile('tws_connparms') is set to "-file <useropts_file>" in the tws_auth in case that
//tws_connparms, composer_args, conman_args, planman_args is not set in the tws_config.php. Therefore normally the
//script should never get to this point!
         tws_error("Configuration error - IWS CLI connection parameters not defined in etc/tws_config.php");
         return FALSE;
      }
      $tws_config['tws_connparms']=$tws_config['composer_args'];
   }

//username and password replacements
   $tws_config['tws_connparms']=preg_replace('/<USERNAME>/', tws_profile('tws_authority'), $tws_config['tws_connparms']);
   $tws_config['tws_connparms']=preg_replace('/<PASSWORD>/', tws_decrypt(tws_profile('tws_authority_pw')), $tws_config['tws_connparms']);

   $tws_config['conman_args']=$tws_config['tws_connparms'];
   $tws_config['composer_args']=$tws_config['tws_connparms'];
   $tws_config['planman_args']=$tws_config['tws_connparms'];
   tws_profile('tws_connparms', $tws_config['tws_connparms']);
   return $tws_config['tws_connparms'];
}

function tws_dbprms($process_plain_passwords=FALSE) {
   global $tws_config, $webadmin_db, $composer_db;

// initialize the 'tz' parameter in case it is not defined
   if (!isset($composer_db['tz']) || $composer_db['tz']==='') $composer_db['tz']=0;

   $cdb_crypt=$composer_db['pass'];
   $wdb_crypt=$webadmin_db['pass'];

   @ini_set('track_errors', false);

// for all users - begin (db_config.php)
   $plain=array();
   if (@$cdb_crypt!="<DBPASS>") {
      if (substr($cdb_crypt,0,8)==='ENCRYPT:') {
         tws_log('-- tws_dbprms : Decrypting composer_db password...');
         $decrypt=tws_decrypt($cdb_crypt);
         $composer_db['pass']=trim($decrypt);
      }
      else {
         tws_log('-- tws_dbprms : Using plain text composer_db password...');
         $plain[]=$cdb_crypt;
      }
   }
   if (@$wdb_crypt!="<WA_DBPASS>") {
      if (substr($wdb_crypt,0,8)==='ENCRYPT:') {
         tws_log('-- tws_dbprms : Decrypting webadmin_db password...');
         $decrypt=tws_decrypt($wdb_crypt);
         $webadmin_db['pass']=@trim($decrypt);
      }
      else {
         tws_log('-- tws_dbprms : Using plain text webadmin_db password...');
         $plain[]=$wdb_crypt;
      }
   }
// for all users - end

// for admins - begin
   if ($process_plain_passwords) {
      tws_log('-- tws_dbprms : Encrypting passwords in db_config.php('.count($plain).') and twsumap ('.$_SERVER['SCRIPT_NAME'].')...');
//
// TODO: check any reason why $tws_config[maestro_dir]/webadmin/bin/type and $tws_config[maestro_dir]/webadmin/bin/copy
// could have been used. Maybe because of sudo and/or hwi_cmd???
//
      $catcmd=isset($tws_config['cat']) ? $tws_config['cat'] : ($tws_config['host_os']=='win32' ? "$tws_config[maestro_dir]/webadmin/bin/type" : '/bin/cat');
      $cpcmd=isset($tws_config['cp']) ? $tws_config['cp'] : ($tws_config['host_os']=='win32' ? "$tws_config[maestro_dir]/webadmin/bin/copy" : '/bin/cp');

//db_config.php encryption
      if (count($plain)>0) {
         if ($tws_config['host_os']!='win32') {
            $cmd=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), $catcmd, $tws_config['maestro_dir'].'/webadmin/etc/db_config.php');
         } else {
            $cmd=new hwi_cmd($catcmd, str_replace('/','\\',"$tws_config[maestro_dir]/webadmin/etc/db_config.php"));
         }
         $stdout='';$stderr='';
         if (tws_popen($cmd,$ec,$stdout,$stderr)!==FALSE && $ec==0) {
            $nreps=0;
            $n=0;
            foreach ($plain as $w) {
               $w_encrypted=tws_encrypt($w);
               $stdout=preg_replace("/(['\"]pass['\"]\s*=>\s*['\"])".preg_quote($w)."/", '${1}'.$w_encrypted,$stdout,1,$n);
               $nreps+=$n;
            }
            if ($nreps==count($plain)) {
               $tmpfile=$tws_config['webadmin_tmp_dir'].'/dbc'.tws_rndstr();
               if (($fp=fopen($tmpfile,'w'))!==FALSE && fwrite($fp,$stdout)>0) {
                  if ($tws_config['host_os']!='win32') {
                     $cmd2=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), $cpcmd, '-f', $tmpfile, $tws_config['maestro_dir'].'/webadmin/etc/db_config.php');
                  } else {
                     $cmd2=new hwi_cmd($cpcmd, '/Y', str_replace('/','\\',$tmpfile),  str_replace('/','\\', $tws_config['maestro_dir'].'/webadmin/etc/db_config.php'));
                  }
                  $stdout2='';$stderr2='';
                  if (tws_popen($cmd2,$ec2,$stdout2,$stderr2)===FALSE || $ec2!=0) {
                     tws_error(array('command'=>(@isset($cmd2['log']) ? $cmd2['log'] : $cmd2->compile('log')),'stdout'=>$stdout2,'stderr'=>$stderr2), "Unable to copy $tmpfile to ".$tws_config['maestro_dir']."/etc/db_config.php");
                  }
                  @fclose($fp);
                  //remove the tmpfile, tmpdir
                  @unlink($tmpfile);
               } else tws_error(array('cmd'=>$cmd2->compile('log'), 'stderr'=>$stderr2), "Unable to write $tmpfile");
            } else tws_error('','Unable to crypt passwords within the db_config.php file');
         } else {
            tws_error(array('cmd'=>$cmd->compile('log'), 'stdout'=>$stdout, 'stderr'=>$stderr), 'Unable to open db_config.php for reading');
         }
      }

//twsumap encryption - TODO:should be in separated function for better orientation
      if ($tws_config['host_os']!='win32') {
         $cmd=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), $catcmd, $tws_config['maestro_dir'].'/webadmin/etc/twsumap');
      } else {
         $cmd=new hwi_cmd($catcmd, str_replace('/','\\', $tws_config['maestro_dir'].'/webadmin/etc/twsumap'));
      }
      $stdout=array();
      if (tws_popen($cmd,$ec,$stdout,$stdout)!==FALSE && $ec==0) {
         $nreps=0;
         foreach ($stdout as $key=>$row) {
            //strip out comments
            if (preg_match('/^\s*#/', $row)) continue;

            if (preg_match('/^\s*(\S+)\s+(\S+)\s*:([^:]*$)/', $row, $_regs)) {
               $tech_user_name=$_regs[1];
               $tech_user_pw=$_regs[2];
               $buff=$_regs[3];
               if (substr($tech_user_pw,0,8)!=='ENCRYPT:') {
                  $crypt=tws_encrypt($tech_user_pw);
                  $nreps++;
               }
               $row=$tech_user_name.' '.$crypt.' : '.$buff;
               $stdout[$key]=$row;
            }
         }

         if ($nreps) {
            $tmpfile=$tws_config['webadmin_tmp_dir'].'/umpc'.tws_rndstr();
            if (($fp=fopen($tmpfile,'w'))!==FALSE && fwrite($fp,implode('',$stdout))>0) {
               if ($tws_config['host_os']!='win32') {
                  $cmd2=tws_sudo("$cpcmd -f $tmpfile $tws_config[maestro_dir]/webadmin/etc/twsumap", $tws_config['maestro_user']);
               } else {
                  $cmd2="$cpcmd /Y ".str_replace('/','\\',"$tmpfile $tws_config[maestro_dir]/webadmin/etc/twsumap");
               }
               $stdout2='';
               if (tws_popen($cmd2,$ec2,$stdout2,$stdout2)===FALSE || $ec2!=0) {
                  tws_error(array("Command"=>(@isset($cmd2['log']) ? $cmd2['log'] : $cmd2->compile('log')), 'stdout'=>$stdout2),"Unable to copy $tmpfile to $tws_config[maestro_dir]/etc/twsumap");
               }
               @fclose($fp);
               //remove the tmpfile, tmpdir
               @unlink($tmpfile);
            } else tws_error('',"Unable to write $tmpfile");
         }
      } else {
         tws_error(array('cmd'=>$cmd->compile('log'), 'stdout'=>$stdout), "twsumap not found");
      }
   }
}

function tws_encrypt($str){

   if (strpos($str, 'ENCRYPT:')!==false)
      return $str;   // already encrypted

   require_once('Crypt/Blowfish.php');

   if (!($blowfish=new Crypt_Blowfish('HORIZONTGmbH'))) {
      tws_error('',"Unable to create Blowfish object");
      return FALSE;
   }
   $encrypted='ENCRYPT:'.base64_encode($blowfish->encrypt($str));
   return $encrypted;
}

function tws_decrypt($crypt) {
   global $tws_config;

   //plain passwords enabled?
   if (isset($tws_config['conn_passwords_plain']) && tws_yesno($tws_config['conn_passwords_plain'], TRUE, FALSE)==TRUE) return $crypt;

   //not crypted?
   if (!preg_match('/ENCRYPT:(\S+)/', $crypt, $_x)) return $crypt;

   //caching session variables enabled?
   $cache= tws_yesno($tws_config['crypt_cache'],TRUE,FALSE);

   //already decrypted?
   $decrypt=tws_profile('tws_ENCRYPT:'.$_x[1]);
   if (!$cache || $decrypt===NULL) {
      require_once('Crypt/Blowfish.php');
      @ini_set('track_errors', false);

      if (!($blowfish=new Crypt_Blowfish('HORIZONTGmbH'))) {
         tws_error('',"Unable to create Blowfish object");
         return FALSE;
      }
      $decrypt=$blowfish->decrypt(base64_decode($_x[1]));

      // cache the decrypt
      if (is_string($decrypt)) {
         $decrypt=trim($decrypt);
         if ($cache) tws_profile('tws_ENCRYPT:'.$_x[1], $decrypt);
      } else {
         tws_error("Unable to decrypt password '$crypt'");
      }

      // destroy the object
      unset($blowfish);
   }

   return str_replace('ENCRYPT:'.$_x[1], $decrypt, $crypt);
}

function tws_license_check($method='enflic', $reload=FALSE) {
   global $tws_config;

// Reload the license evaluation status if the license cache expired or if it doesn't exists or if the reload is forced (parrameter reload)
   if (($licache=tws_profile($method.'cache'))===null || time()>($licacheexp=tws_profile('licacheexp')) || $reload) {
      $suffix=$tws_config['host_os']=='win32' ? '.exe' : '';
      $licache='';
      $stderr='';
      tws_log("-- tws_license_check : evaluating product license key ($method)");
      tws_popen(new hwi_cmd($tws_config['base_inst_dir'].'/bin/'.$method.$suffix, $tws_config['maestro_dir']), $ec, $licache, $stderr);
      tws_profile($method.'cache', base64_encode($licache));
      if (strpos($licache, 'Violation') !== false || (int)$ec > 0 || !empty($stderr)) {
         tws_error(__FUNCTION__ . ' error out:' . $licache . ' , ec:' . var_export($ec, true) . ', stderr:' . var_export($stderr, true));
      }
      $licacheexp=time()+12*60*60; //license cache expires in 12 hours...
      tws_profile('licacheexp',$licacheexp);
      if ($reload) return $licache;
   } else {
      tws_log("-- tws_license_check : reading product license key from cache ($method)");
      $licache=base64_decode($licache);
   }
   switch ($method) {
      case 'enflic' :
         eval($licache);
         break;
      case 'enf' :
         echo $licache;
         break;
   }
}

// input:
// tz: either the time shift in hours:mins :  +1:00, -1:00, ...
// or in seconds: +3600, -3600, ...
// or the IWS timezone name: EST, America/New_York
//
// returns: the time difference between given time zone and the GMT in seconds
function tws_get_timezone_offset($tz, $refdate=NULL) {
   global $tws_config, $tws_types;
   $refdate===NULL && $refdate='1970-01-01';

   if (strtoupper($tz)=='__SERVER__') {
      return @date_offset_get(@date_create($refdate));
   } elseif (strtoupper($tz)=='__MDM__') {
      tws_get_optmanopts();
      if (!tws_yesno($tws_config['optmanopts']['entimezone'], TRUE, FALSE)) {
         return tws_get_timezone_offset('__SERVER__', $refdate);
      } else {
         tws_get_cpuinfo();
         //if cpuinfo doesn't work, then Server timezone is considered
         if (!isset($tws_config['cpuinfo']['time_zone'])) return tws_get_timezone_offset('__SERVER__', $refdate);
         return tws_get_timezone_offset($tws_config['cpuinfo']['time_zone'], $refdate);
      }
   } else {
      $_tz=tws_phptz($tz);
      if (isset($tws_types['TIMEZONE'][$_tz])) {
         $dtz=date_default_timezone_get();
         tws_date_default_timezone_set($_tz);
         $toff=@date_offset_get(@date_create($refdate));
         if (!empty($dtz)) date_default_timezone_set($dtz);
         return $toff;
      }
      include('tws_tz.php');
      $tz_full=NULL;
      if (isset($tws_full_tz[$tz])) $tz_full=$tz;
      else {
         $_tz=strtoupper(trim($tz));
         $tz_full=NULL;
         foreach ($tws_full_tz as $key=>$val) {
            if (strtoupper($key)==$_tz) {
               $tz_full=$key;
               break;
            }
         }
      }
      if ($tz_full!==NULL) {
         $dtz=date_default_timezone_get();
         tws_date_default_timezone_set($tz_full);
         $toff=@date_offset_get(@date_create($refdate));
         if (!empty($dtz)) date_default_timezone_set($dtz);
         return $toff;
      }
   }

//otherwise try to get the timezone difference fro it's name
   if (preg_match('/([+-])?(\d+):(\d+)/', $tz, $_r)) {
//specified in hours shift to GMT
      $tz_sec=($_r[1]=='-' ? -1 : 1)*($_r[2]*3600+$_r[3]*60);
   } elseif (is_numeric($tz)) {
      $tz_sec=intval($tz);
   } else {
      tws_log('-- tws_get_timezone_offset: Unsupported Time Zone Name '.$tz);
      return FALSE;
   }
   return $tz_sec;
}


//Inversion function to  function tws_get_timezone_offset
//example tws_get_timezone_name(9000) returns 'Asia/Tehran'
function tws_get_timezone_name($offset) {
   global $tws_types;
   if (is_numeric($offset)) {
      $h=floor($offset/3600);
      $m=str_pad(floor(($offset-$h*3600)/60), 2, '0', STR_PAD_LEFT);
      foreach ($tws_types['TIMEZONE'] as $key=>$val) {
         if (preg_match(";(\w+/\w+) \(GMT\+$h:$m\);", $val)) {
            return $key;
         }
      }
   }
   tws_error("Unsupported timezone offset '$offset'");
   return FALSE;
}

// Use instead of standard date_default_timezone_set()
// include IWS backward timezones
function tws_date_default_timezone_set($tz) {
   if ( !date_default_timezone_set($tz)) {
      include_once 'tws_tz.php';
      return date_default_timezone_set($tws_backward_tz[$tz]);
   }
   return true;
}

/// Adjust the date format (e.g. obtained from the database) to be more human readable.
/// \param timestamp : Input time (date time) string in ISO format (YYYY-MM-DD [HH:MM:SS] [TZ])
///                    If the timezone is present then the offest value specified by $timestamp_offset is ignored!!!
/// \param date_format : output fomat. If null then is taken from user's profile. If not in profile then from localopts!
/// \param date_only output will contain only date (not the time)
/// \param timestamp_offset : offset of the input timestamp to UTC in seconds - SPECIAL value is FALSE - shifting due to timezones completely ignored
/// \param shortest : shortest output - the year is not displayed if it is same as the current year, seconds not displayed if equal to 00
/// \return Returns the input timestamp in user's date format, if timestamp_offset is NOT FALSE, then
///         the time is converted in user's timezone (specified in users's profile - if not specifed than the __SERVER__ timezone is assumed)
function tws_iso_to_userdate($timestamp, $date_format=null, $date_only=FALSE, $timestamp_offset=NULL, $shortest=FALSE) {
   global $tws_config, $tws_types;
   $date=$time='';

   $tlog=tws_log();
   // TODO: make debug mode, and write it only in debug mode
   // $tlog && $tlog="-- tws_iso_to_userdate('$timestamp','$date_format',".tws_yesno($date_only,'TRUE','FALSE').",'$timestamp_offset',".tws_yesno($shortest,'TRUE','FALSE').") : ";

   if (preg_match('/(\d{4})-(\d{2})-(\d{2}) ?(\d{2})?:?(\d{2})?:?(\d{2})?\.?\d*\s*([A-Za-z_\/]+)?$/', $timestamp, $d)) {
      if ($d[1]=='0000' || $d[1]=='CURR') {
         if ($d[2]=='00' && $d[3]=='00') {
            $date=FALSE;
            $d[2]=date('m');
            $d[3]=date('d');
         }
         $d[1]=date('Y');
      }
      if (!@$d[4]) $d[4]='00';
      if (!@$d[5]) $d[5]='00';
      if (!@$d[6]) $d[6]='00';

      if (is_null($date_format)) {
        $date_format=tws_profile('date_format');
        $tz=tws_profile('timezone');
        if ($tz=='') $tz='__SERVER__';
        $time_format = '';
      } else {
         $tz=null;
         list($date_format,$time_format,$tz)=explode(' ', $date_format);
         if (strtoupper($date_format)=='NULL') $date_format=tws_profile('date_format');
         if (!isset($tz) || strtoupper($tz)=='TZ') $tz=tws_profile('timezone');
         if ($tz=='') $tz='__SERVER__';
      }

      //automatic date_only mode if time equals to "99:99:99"
      //TODO: switch to date_only in case of any invalid time
      if ($d[4]=='99' && $d[5]=='99' && $d[6]=='99') {
         $date_only=TRUE;
         $tlog && $tlog.="DATE_ONLY=TRUE; ";
      } else {
         $tstr=$d[1].'-'.$d[2].'-'.$d[3].' '.$d[4].':'.$d[5].':'.$d[6];
         $tlog && $tlog.="TSTR=$tstr; ";

         //timezone given - if $timestamp_offset is FALSE then no shifting to user's timezone will happen
         //and the timzeone name will be returned
         if (!@$d[7]) $d[7]='';
         if ($timestamp_offset!==FALSE) {
            $tz_static='';
            if ($d[7]!='') {
               $ts=tws_get_timezone_offset($tz,$tstr)-tws_get_timezone_offset($d[7],$tstr);
               $tlog && $tlog.="TSa($tz,$d[7])=$ts; ";
            } elseif (is_numeric($timestamp_offset)) {
               $ts=tws_get_timezone_offset($tz,$tstr)-intval($timestamp_offset);
               $tlog && $tlog.="TSb($tz,$timestamp_offset)=$ts; ";
            } elseif (is_string($timestamp_offset)) {
               if ($timestamp_offset=='') $timestamp_offset='__SERVER__';
               $ts=tws_get_timezone_offset($tz,$tstr)-tws_get_timezone_offset($timestamp_offset,$tstr);
               $tlog && $tlog.="TSc($tz,$timestamp_offset)=$ts; ";
            } else {
               //no timezone correction of the input timestamp - assuming it's in UTC!!!
               $ts=0;
               $tlog && $tlog.="TSd=$ts; ";
            }

            $t=strtotime($d[1].'-'.$d[2].'-'.$d[3].' '.$d[4].':'.$d[5].':'.$d[6]);
            //now shift the time $t by $ts
            $t=date('Y-m-d H:i:s', $t+$ts);
            preg_match('/(\d{4})-(\d{2})-(\d{2}) ?(\d{2})?:?(\d{2})?:?(\d{2})?\.?\d*/', $t, $d);
         } else {
            $tz_static=$d[7];
            if (strtoupper(trim($tz_static))=='__SERVER__') {
               $tz_static=tws_get_timezone_name(tws_get_timezone_offset('__SERVER__'));
            }
            $tlog && $tlog.="TZ_STATIC=$tz_static; ";
         }
      }

//format the output
      if ($date!==FALSE) {
         $thisy=date('Y');
         switch ($date_format) {
           case 'm/d/Y':
             $date=$d[2].'/'.$d[3].($shortest && $d[1]===$thisy ? '' : '/'.$d[1]);
             break;
           case 'm-d-Y':
             $date=$d[2].'-'.$d[3].($shortest && $d[1]===$thisy ? '' : '-'.$d[1]);
             break;
           case 'd/m/Y':
             $date=$d[3].'/'.$d[2].($shortest && $d[1]===$thisy ? '' : '/'.$d[1]);
             break;
           case 'd-m-Y':
             $date=$d[3].'-'.$d[2].($shortest && $d[1]===$thisy ? '' : '-'.$d[1]);
             break;
           case 'Y/m/d':
             $date=($shortest && $d[1]===$thisy ? '' : $d[1].'/').$d[2].'/'.$d[3];
             break;
           case 'Y-m-d':
             $date=($shortest && $d[1]===$thisy ? '' : $d[1].'-').$d[2].'-'.$d[3];
             break;
           default:
               switch ($tws_config['localopts']['date format']) {
                  case '2': // d/m/Y
                     $date=$d[3].'/'.$d[2].($shortest && $d[1]===$thisy ? '' : '/'.$d[1]);
                     break;
                  case '1': // m/d/Y
                     $date=$d[2].'/'.$d[3].($shortest && $d[1]===$thisy ? '' : '/'.$d[1]);
                     break;
                  default: // Y/m/d
                     $date=($shortest && $d[1]===$thisy ? '' : $d[1].'/').$d[2].'/'.$d[3];
                     break;
               }
           break;
         }
         if ($date_only) {
            $tlog && $tlog.="= $date ."; // && tws_log($tlog);
            return $date;
         }
      } else {
         $date='';
      }

      switch ($time_format) {
         case 'hh:mm':
            $time=$d[4].':'.$d[5];
            break;
         default:
            $time=$d[4].':'.$d[5].($shortest && $d[6]==='00' ? '' : ':'.$d[6]);
            break;
      }

      $tlog && $tlog.='= '.trim($date.' '.$time.' '.$tz_static).' .'; // && tws_log($tlog);
      return trim($date.' '.$time.' '.$tz_static);
   }
   $tlog && $tlog.="W:NOT_SUPPORTED_TIMESTAMP_FORMAT = $timestamp ."; // && tws_log($tlog);
   return $timestamp;
}

function tws_user_date_format($time_format='hh:mm') {
   global $tws_config;
   $date_format=tws_profile('date_format');
   switch ($date_format) {
      case 'm/d/Y':
         $r='MM/DD/YYYY';
         break;
      case 'm-d-Y':
         $r='MM-DD-YYYY';
         break;
      case 'd/m/Y':
         $r='DD/MM/YYYY';
         break;
      case 'd-m-Y':
         $r='DD-MM-YYYY';
         break;
      case 'Y/m/d':
         $r='YYYY/MM/DD';
         break;
      case 'Y-m-d':
         $r='YYYY-MM-DD';
         break;
      default:
         switch ($tws_config['localopts']['date format']) {
            case '2': // d/m/Y
               $r='DD/MM/YYYY';
               break;
            case '1': // m/d/Y
               $r='MM/DD/YYYY';
               break;
            default: // Y/m/d
               $r='YYYY/MM/DD';
               break;
         }
   }
   return trim($r.' '.$time_format);
}

function tws_userdate_to_regs($date, $date_format=null, $date_only=FALSE) {
   global $tws_config;
   $y=$m=$d=$hh=$mm=$ss=$tz='';

   if (is_null($date_format)) $date_format=tws_profile('date_format');
   switch ($date_format) {
      case 'm/d/Y':
         if (($res=preg_match('/(\d{1,2})\/(\d{1,2})\/(\d{2,4}) ?(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?/', $date, $_d))) {
            $m=$_d[1]; $d=$_d[2]; $y=$_d[3];
         }
         break;
     case 'm-d-Y':
         if (($res=preg_match('/(\d{1,2})-(\d{1,2})-(\d{2,4}) ?(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?/', $date, $_d))) {
            $m=$_d[1]; $d=$_d[2]; $y=$_d[3];
         }
         break;
     case 'd/m/Y':
         if (($res=preg_match('/(\d{1,2})\/(\d{1,2})\/(\d{2,4}) ?(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?/', $date, $_d))) {
            $m=$_d[2]; $d=$_d[1]; $y=$_d[3];
         }
         break;
     case 'd-m-Y':
         if (($res=preg_match('/(\d{1,2})-(\d{1,2})-(\d{2,4}) ?(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?/', $date, $_d))) {
            $m=$_d[2]; $d=$_d[1]; $y=$_d[3];
         }
         break;
     case 'Y/m/d':
         if (($res=preg_match('/(\d{2,4})\/(\d{1,2})\/(\d{1,2}) ?(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?/', $date, $_d))) {
            $m=$_d[2]; $d=$_d[3]; $y=$_d[1];
         }
         break;
     case 'Y-m-d':
         if (($res=preg_match('/(\d{2,4})-(\d{1,2})-(\d{1,2}) ?(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?/', $date, $_d))) {
            $m=$_d[2]; $d=$_d[3]; $y=$_d[1];
         }
         break;
     case 'Y-m-dTH:i:s/Z': case 'EVRULE_TS' :
         if (($res=preg_match('/(\d{2,4})-(\d{1,2})-(\d{1,2})T(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?/', $date, $_d))) {
            $m=$_d[2]; $d=$_d[3]; $y=$_d[1];
         }
         break;
     case 'localopts':
     default:
         switch ($tws_config['localopts']['date format']) {
            case '2': // d/m/Y
               if (($res=preg_match('/(\d{1,2})\/(\d{1,2})\/(\d{2,4}) ?(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?/', $date, $_d))) {
                  $m=$_d[2]; $d=$_d[1]; $y=$_d[3];
               }
               break;
            case '1': // m/d/Y
               if (($res=preg_match('/(\d{1,2})\/(\d{1,2})\/(\d{2,4}) ?(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?/', $date, $_d))) {
                  $m=$_d[1]; $d=$_d[2]; $y=$_d[3];
               }
               break;
            case '0': // Y/m/d
            default: //TODO!
               if (($res=preg_match('/(\d{2,4})\/(\d{1,2})\/(\d{1,2}) ?(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?/', $date, $_d))) {
                  $m=$_d[2]; $d=$_d[3]; $y=$_d[1];
               }
               break;
         }
         break;
   }
   if (!$res) return FALSE;
   $regs=array();

   $regs['Y']=str_pad($y,4,date('Y'),STR_PAD_LEFT);
   $regs['m']=str_pad($m,2,'0',STR_PAD_LEFT);
   $regs['d']=str_pad($d,2,'0',STR_PAD_LEFT);

   if (@$_d[4]) $hh=$_d[4];
   if (@$_d[5]) $mm=$_d[5];
   if (@$_d[6]) $ss=$_d[6];
   $regs['H']=str_pad($hh,2,'0',STR_PAD_LEFT);
   $regs['i']=str_pad($mm,2,'0',STR_PAD_LEFT);
   $regs['s']=str_pad($ss,2,'0',STR_PAD_LEFT);

   //TZ
   $regs['T']='';
   switch ($date_format) {
      case 'Y-m-dTH:i:s/Z' : case 'EVRULE_TS' :
         if (preg_match('/\/([A-Za-z_\/]+)$/', trim($date), $_t)) $regs['T']=tws_phptz($_t[1]);
         break;
      default:
         if (preg_match('/[A-Za-z_\/]+$/', trim($date), $_t)) $regs['T']=tws_phptz($_t[0]);
         break;
   }

   return $regs;
}

function tws_phptz($tz) {
   global $tws_phptz; //defined in webadmin/etc/twsrc.php since TWA3.0.6
   $_tz=strtoupper(trim($tz));
   return isset($tws_phptz[$_tz]) ? $tws_phptz[$_tz] : $tz;
}

function tws_userdate_to_iso($date, $date_format=null, $date_only=FALSE) {
   if (($regs=tws_userdate_to_regs($date,$date_format))===FALSE)
      return FALSE;
   if ($date_only) return "$regs[Y]-$regs[m]-$regs[d]";
   if ($regs['T']==='' && ($utz=tws_profile('timezone'))!==NULL) {
      $regs['T']=$utz;
      tws_log('-- tws_userdate_to_iso : added user default time zone '.$utz.' to the timestamp \''.$date.'\' entered.');
   }
   return trim("$regs[Y]-$regs[m]-$regs[d] $regs[H]:$regs[i]:$regs[s] $regs[T]");
}

function tws_userdate_to_evtiso($date, $date_format=null, $date_only=FALSE) {
   if (($regs=tws_userdate_to_regs($date,$date_format))===FALSE)
      return FALSE;
   if ($date_only) return "$regs[Y]-$regs[m]-$regs[d]";
   if ($regs['T']==='' && ($utz=tws_profile('timezone'))!==NULL) {
      $regs['T']=$utz;
      tws_log('-- tws_userdate_to_evtiso : added user default time zone '.$utz.' to the timestamp \''.$date.'\' entered.');
   }
   return trim("$regs[Y]-$regs[m]-$regs[d]T$regs[H]:$regs[i]:$regs[s]".($regs['T']!='' ? '/'.$regs['T'] : ''));
}

//ts=16:00, 16:30:15, 16, 4 pm, 2:30 pm, etc...
function tws_timeoffset_to_iso($ts) {
   if (($res=preg_match('/(\d{1,2}):?(\d{1,2})?:?(\d{1,2})?\s*(\S+)?/', $ts, $_t))) {
      $hh=intval($_t[1]); $mm=intval($_t[2]); $ss=intval($_t[3]);
      if ($_t[4]!='' && $hh<=12 && preg_match('/^p.?m.?$/i', $_t[4])) $hh+=12;
      $hh=str_pad($hh,2,'0',STR_PAD_LEFT);
      $mm=str_pad($mm,2,'0',STR_PAD_LEFT);
      $ss=str_pad($ss,2,'0',STR_PAD_LEFT);
      $ts=$hh.':'.$mm.':'.$ss;
      return  $ts;
   }
   return false;
}

function tws_userdate_add_default_tz($date) {
   $date!='' && ($regs=tws_userdate_to_regs($date))!==FALSE && $regs['T']==='' && ($utz=tws_profile('timezone'))!==NULL && $date.=' '.$utz;
   return $date;
}

function tws_userdate_to_conman($timestamp) {
   if (($r=tws_userdate_to_regs($timestamp))!==FALSE) {
      $time=$r['H'].$r['i'];
      $date=tws_date_from_iso($r['Y'].'-'.$r['m'].'-'.$r['d']);
      $tz=$r['T']!='' ? 'tz '.$r['T'] : '';
      return trim("$time $date $tz");
   }
   if (preg_match('/(\d{1,2}):(\d{1,2}) ?([A-Za-z_\/]+)?$/', trim($timestamp), $r)) {
      $time=str_pad($r[1],2,'0',STR_PAD_LEFT).str_pad($r[2],2,'0',STR_PAD_LEFT);
      $tz=$r[3]!='' ? 'tz '.$r[3] : '';
      return trim("$time $tz");
   }
   return $timestamp;
}

//convert the conman timestamps format to the ISO format
//supported timestamps are: hhmmm MM/DD, hhmm MM/DD TZ timezone, MM/DD, hhmm, MM/DD
//if shortest==1 then: - the year is never returned if it is same as the current year,
//                     - seconds are not returned if they equal to 00
//                     - no date is returned if hhmm or hh:mm is on input
function tws_conman_to_iso($timestamp) {
   $r=explode(' ', $timestamp);
   $nr=count($r);
   $tz=$date_iso='';
   if ($nr>=4) {
      //format hhmm expected
      $time=substr($r[0],0,2).':'.substr($r[0],2,2).':00';
      $date_iso=tws_date_to_iso($r[1]);
      $r[2]=strtoupper(trim($r[2]));
      if ($r[2]=='TZ' || $r[2]=='TIMEZONE') $tz=$r[3];
   } elseif ($nr>=2) {
      //format hhmm expected
      $time=substr($r[0],0,2).':'.substr($r[0],2,2).':00';
      $date_iso=tws_date_to_iso($r[1]);
   } else {
      if (strpos($r[0],'/')===FALSE) {
         //time only, probably in format hh:mm or h:mm already
         if ((strpos($r[0],':')===FALSE)) {
            //format hhmm expected
            $time=substr($r[0],0,2).':'.substr($r[0],2,2).':00';
         } else {
            $time=$r[0].':00';
         }
        //TODO: symdate must be used here, remember the symdate changes when browsing the history plans!
         $date_iso='0000-00-00'; //the zeros will force the tws_iso_to_userdate to return only the time!
      } else {
         $date_iso=tws_date_to_iso($r[0]);
         $time='99:99:99';
      }
   }

   if (strpos(substr($date_iso,0,4), '-')!==FALSE) {
      //conman doesn't return the year, so it's needed to evaluate it!

      //the month of the timestamp
      $m=intval(substr($date_iso,0,2));
      //the year must be detected - different way for archive plans
      if (tws_profile('symphony')){ //in case of browsing the history plan
         $symdate=tws_profile('symdate');
         if (($pos=strpos($symdate, ' '))!==FALSE) $symdate=substr($symdate, 0, $pos);
         $symdate=tws_userdate_to_iso($symdate, null, true);
         if (preg_match('/(\d{4})-(\d{2})-\d{2}/', $symdate, $r)) {
            $ref_year=$r[1];
            $m=intval(substr($date_iso,0,2));
            $mshift=intval($r[2])-$m;
         } else {
            tws_log("-- tws_conman_to_iso: Unsupported symdate '$symdate', unable to detect the year");
            return trim($date_iso.' '.$time.' '.$tz);
         }
      } else {
         //this is for current sympohony plan
         $mshift=date('n')-$m;
         $ref_year=date('Y');
      }
      if (abs($mshift)<5) $yshift=0;
      else $yshift=$mshift>0 ? 1 : -1;
      $date_iso=($ref_year+$yshift).'-'.$date_iso;
   }

   return trim($date_iso.' '.$time.' '.$tz);
}

//uses tws_conman_to_iso and tws_iso_to_userdate to convert the conman timestamps format to the user format
function tws_conman_to_userdate($timestamp, $shortest=FALSE) {
   //tws_conman_to_iso may return time 99:99:99, then tws_iso_to_userdate fals to "date_only" mode automaticaly
   if (($userdate=tws_iso_to_userdate(tws_conman_to_iso($timestamp), NULL, FALSE, '__MDM__', $shortest))!==FALSE) {
      return trim($userdate);
   }
   //TODO: throw a warning
   return $timestamp;
}

/// Gets or Sets user profile variables.
/// \param key Profile variable name.
/// \param newval (optional) New value for the given profile variable.
/// \return Old value in case that \c newval is given or the current value of
/// the \c key profile variable.
function tws_profile($key, $newval=null, $storage=FALSE) {
   global $tws_config;

   if (php_sapi_name()=='cli' || isset($GLOBALS['_SESSIONR'])) {
      $sess=&$GLOBALS['_SESSIONR'];
   } else {
      $sess=&$_SESSION;
   }

   $currval=NULL;
   if (@array_key_exists($key, $sess)) {
      $currval=$sess[$key];
   }
   if (isset($newval)) {
      $sess[$key]=$newval;

      if ($storage!==FALSE) {
         $storage_filename=$tws_config['webadmin_user_home_dir'].'/'.tws_profile('auth_user_name').$tws_config['user_setting_dir'].'/'.$storage.'.php';
         if (file_exists($storage_filename)) {
            @include $storage_filename;
         }
         $storage_data=&$$storage;
         if (!is_array($storage_data)) $data=array();
         $storage_data[$key]=$newval;
         if (!@file_put_contents($storage_filename,"<?php\n\$${storage} = ".var_export($storage_data,TRUE).";\n?>")) {
            tws_error("storage objects: '$storage'; storage filename: '$storage_filename'", "Unable to save user profile data");
         }
      }
   }

   return $currval;
}

function tws_check_elname($elname) {
   $name_pattern = "/^[a-zA-Z0-9_\[\]]+$/";
   if( preg_match($name_pattern, $elname)) return true;
   else tws_dyer("Bad variable name '$elname'", $elname);
}

/// Returns a random string of required type.
/// Typicaly used while creating temporary file names.
/// \param type String format type. "FILENAME" by default.
/// \return Created random string.
function tws_rndstr($type="FILENAME") {
   switch( strtoupper($type) ){
      case "FILENAME" :
         $datestamp=date("Ymd");
         $rand_num=rand(1000000,9999999);
         return $datestamp.".".$rand_num;
      case "FILENAME_SHORT" :
         $datestamp=date("ymd");
         $rand_num=rand(10000,99999);
         return $datestamp.".".$rand_num;
      case "ELEMID" :
         $rand_num=rand(10000,99999);
         return $rand_num;
   }
   return false;
}

/// Function for storing reports to the files.
function tws_report_oc_template($buffer, $report_name='') {
   global $outfile, $cmdline, $tws_config;
   if (isset($cmdline) && $cmdline) $cmdline=FALSE;
   else $cmdline=FALSE;
   if (!empty($outfile)){
      if (dirname($outfile)== ".") {
         $filepath=$tws_config['webadmin_user_home_dir'].'/'.tws_profile('auth_user_name').'/'.$outfile;
         $filename = $outfile;
      } else {
         $filepath=$outfile;
      }
   } else {
      $filename=tws_rndstr().".str";
      $filepath=$tws_config['webadmin_user_home_dir'].'/'.tws_profile('auth_user_name').'/'.$filename;
   }
   if ($cmdline) {
      $msg="Store Report\n\n$report_name Results: ";
   } else {
      $msg="<html>\n<head>\n<title>Store Report</title>".tws_stylesheet(TRUE)."\n</head>\n<body>\n<h1>$report_name Results</h1>\n<br><br>\n";
   }
   if ($fp=fopen($filepath,"w")) {
      if (fwrite($fp,$buffer) != -1) {
         fclose($fp);
         tws_chmod($filepath, 0664, FALSE);
         if ($cmdline) {
            $msg.="Report successfully stored.\n\nOutput file location: $filepath\n\n";
         } else {
            $msg.="Report successfully stored.<br>\nURL:&nbsp;<a target=\"_blank\" href=\"tws_view_stored_report.php?selection=".@$filename."\">".@$filename."</a>\n";
            $msg.="<br><br>All stored reports can be found <a href=\"tws_stored_reports.php\">here</a>\n";
         }
         $htdocs=(isset($tws_config['base_inst_dir']) ? $tws_config['base_inst_dir'] : $tws_config['maestro_dir'].'/webadmin').'/httpd/htdocs';
         tws_cp($htdocs.'/default.css',dirname($filepath).'/');
         tws_cp($htdocs.'/webadmin_'.(tws_profile('skin') ? tws_profile('skin') : 'Default').'.css',dirname($filepath).'/');
      } else {
         if ($cmdline) {
            $msg.="Error storing $report_name.\n\n";
         } else {
            $msg.="<p class=\"warning\">Error storing $report_name [WRITE].</p>\n";
         }
      }
   } else {
      if ($cmdline) {
         $msg.="Error storing $report_name.\n\n";
      } else {
         $msg.="<p class=\"warning\">Error Storing $report_name [OPEN $filepath].</p>\n";
      }
   }
   if (!$cmdline) $msg.="</body>\n</html>\n";
   return $msg;
}

function tws_store_report_oc($buffer) {
   return tws_report_oc_template($buffer, "Cross Reference Report");
}

/// Returns column name applicable in WHERE or ORDER clause
/// eg: select WKS.WORKSTATION_NAME CPUNAME -> WKS.WORKSTATION_NAME
function tws_db_colname($selcol) {
   return preg_replace("/(\S+)\s+\S+/",'${1}',$selcol);
}

/// Builds and executes database query (used in database reports)
function tws_report_query($db,$from,$sel,$crit,$ord,$pri, &$query, $sqlfilter='') {
   db_connect($db,DB_PERSISTENT) or tws_error('', 'Cannot connect to database');

   $sqlsel=array();
   foreach ($sel as $key=>$val) {
      if ($val) {
         $sqlsel[]="$key";
      }
   }

   $sqlcrit=array();
   foreach ($crit as $key=>$val) {
      if ($val) {
         if (strpos($key, ' AT') || strpos($key, ' UNTIL') || strpos($key, ' DEADLINE'))
            $sqlcrit[]=tws_db_colname($key).$val;
         else
            $sqlcrit[]=tws_db_colname($key).' '.tws_sqllike($val, '');
      }
   }
   if ($sqlfilter!='') $sqlcrit[]=$sqlfilter;

   $sqlpreord=array();
   foreach ($ord as $key=>$val) {
      if ($val || $pri[$key]) {
         $rank=$pri[$key];
         if ($rank=='' || $rank==0) {
            $rank=max($pri)+1;
         }
         $sqlpreord[$rank][]=trim(tws_db_colname($key)." $val");
      }
   }
   ksort($sqlpreord);
   $sqlord=array();
   foreach ($sqlpreord as $level=>$sqlords) {
      foreach ($sqlords as $val) {
         $sqlord[]=$val;
      }
   }

   $query="
      SELECT ".implode(', ',$sqlsel)."
      FROM $from
      ".(count($sqlcrit)>0 ? 'WHERE '.implode(' AND ', $sqlcrit) : '')."
      ".(count($sqlord)>0 ? 'ORDER BY '.implode(', ', $sqlord) : '');

   if (!db_query($db,$query)) {
      tws_error('', 'Database query failed');
      return FALSE;
   }

   return $db;
}

/// User rights checking
/// \return TRUE if user has given rights or FALSE if not.
function tws_rights($rightX) {
   global $tws_config;
   require_once 'tws_rc.php';
   //load rights
   $usersec = $tws_config['maestro_dir'].'/webadmin/etc/usersec.php';
   if (is_file($usersec)) {
      include $usersec;
   } else {
      return FALSE;
   }
   $user = tws_profile('auth_user_name');
   $group = tws_profile('auth_user_group');

   if($group == 'admin') {
      if ($rightX == HIDEADVANCEDOPTS || $rightX == SAVEBACKUPS) return FALSE;
      return TRUE;
   }
   // select user_rights
   if (isset($rights[$user]) && $rightX!='w') {    // SAVEBACKUPS is for groups and for all only
      $user_right = $rights[$user];
   }
   elseif (isset($group_rights[$group])) {
      $user_right = $group_rights[$group];
   }
   else if (isset($default_rights)) {
      $user_right = $default_rights;
   }
   else {
      return FALSE;
   }
   // decide if the user is allowed to ...
   return (strpos($user_right, $rightX) !== FALSE ) ? TRUE : FALSE;
}

// Return max rows returned set for group in advanced group rights (flexytables only)
function tws_group_limit(){
   global $tws_config;
   //load rights
   $usersec = $tws_config['base_inst_dir'].'/etc/usersec.php';
   if (is_file($usersec))
      include $usersec;
   else return FALSE;
   $group = tws_profile('auth_user_group');
   if (isset($group_limit[$group]))
      return $group_limit[$group];
   if (isset($default_limit))
      return $default_limit;
   return 0;
}

/// Return Iws version.
/// The function stores the value of iws version to the tws_config as well.
function tws_get_webadmin_version() {
   global $tws_config;

   clearstatcache();

   if (($tws_config['webadmin_version']=tws_profile('webadmin_version'))!==null){
      if ( ($mtime = tws_profile('filemtime'))!==null ){
         if( $mtime['fixpack.info'] == filemtime($tws_config['base_inst_dir'].'/version/fixpack.info') ){
            $tws_config['webadmin_version']=tws_profile('webadmin_version');
            $tws_config['webadmin_plugin']=tws_profile('webadmin_plugin');
            return $tws_config['webadmin_version'];
         }
         elseif (strtolower(php_sapi_name()) != 'cli') {
            header("location:tws_upgraded.php");
            return;
         }
      }
   }

// Main version number
   if (!file_exists($tws_config['base_inst_dir'].'/version/version.info')) {
      $webadmin_version="0.0";
   } else {
      if (!$fp = fopen($tws_config['base_inst_dir'].'/version/version.info','r')) {
         $webadmin_version="0.0";
      } else {
         $webadmin_version=trim(fgets($fp,4096));
         fclose($fp);
      }
   }
// FixPack version string
   if (file_exists($tws_config['base_inst_dir'].'/version/fixpack.info')) {
      if ($fp = fopen($tws_config['base_inst_dir'].'/version/fixpack.info','r')) {
         $webadmin_fixpack=trim(fgets($fp,4096));
         $webadmin_version .= " $webadmin_fixpack";
         fclose($fp);
      }
      $mtime = filemtime($tws_config['base_inst_dir'].'/version/fixpack.info');
   }
   else $mtime =0;

// Patch version string
   if (file_exists($tws_config['base_inst_dir'].'/version/patch.info')) {
      if ($fp = fopen($tws_config['base_inst_dir'].'/version/patch.info','r')) {
         $webadmin_patch=trim(fgets($fp,4096));
         $webadmin_version .= " $webadmin_patch";
         fclose($fp);
      }
   }

   $tws_config['webadmin_version']=$webadmin_version;
   tws_profile('webadmin_version',$tws_config['webadmin_version']);
   tws_profile('filemtime', array('fixpack.info'=>$mtime));

// Plugins
   $webadmin_plugin=array();
   if (tws_zli_module_check()) {
      if (file_exists($tws_config['base_inst_dir'].'/httpd/htdocs/zli_net_module/zli_component.info')) {
         if ($fp = fopen($tws_config['base_inst_dir'].'/httpd/htdocs/zli_net_module/zli_component.info','r')) {
            $zli_mod_version=trim(fgets($fp,4096));
            $zli_mod_version = str_replace(',', '.', $zli_mod_version);
            $webadmin_plugin[]="NetPlan ActiveX module $zli_mod_version";
            fclose($fp);
         }
      }
      if (file_exists($tws_config['base_inst_dir'].'/httpd/htdocs/twazy/version.info')) {
          if ($fp = fopen($tws_config['base_inst_dir'].'/httpd/htdocs/twazy/version.info','r')) {
              $zli_mod_version=trim(fgets($fp,4096));
              $webadmin_plugin[]="Netplan JS/SVG Module  $zli_mod_version";
              fclose($fp);
          }
      }
   }

   $tws_config['webadmin_plugin']=implode(', ',$webadmin_plugin);
   tws_profile('webadmin_plugin',$tws_config['webadmin_plugin']);
}

/// Return iws version and other cpu info data
/// The function stores the value of iws version to the tws_config as well.
function tws_get_cpuinfo() {
   global $tws_config;

   if (($tws_config['cpuinfo']=tws_profile('cpuinfo'))!==null){
      return $tws_config['cpuinfo'];
   }
   if (!isset($tws_config['localopts'])){
      tws_get_localopts();
   }

   if (isset($tws_config['localopts']['thiscpu'])) {
      if ($tws_config['host_os']=='win32' && !isset($tws_config['maestro_pw'])) {
         $cmd=new hwi_cmd($tws_config['maestro_dir'].'/bin/cpuinfo', $tws_config['localopts']['thiscpu']);
      } else {
         $cmd=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), $tws_config['maestro_dir'].'/bin/cpuinfo', $tws_config['localopts']['thiscpu']);
      }
      $stdout=array();
      $stderr='';
      tws_popen($cmd, $ec, $stdout, $stderr);
      if ($ec!='0' || (count($stdout)<10 && trim($stderr)!='')) {
         tws_error($cmd->compile('log').' failed: '.$stderr, "Unable to get IWS Master's cpu info");
      } else {
         foreach ($stdout as $buffer) {
            list($field,$value)=explode(':', $buffer);
            $field=strtolower(trim($field));
            $value=trim($value);
            if ($field!='') {
               $tws_config['cpuinfo'][$field]=$value;
            }
         }
      }
      if (!isset($tws_config['cpuinfo']['version']) || $tws_config['cpuinfo']['version']=='') {
         if ($tws_config['host_os']=='win32') {
            $fname = $tws_config['maestro_dir'].'\version\maestro.info';
            $fp = fopen($fname, "r");
            if(!$fp) tws_error("Unable to open file '$fname'", 'Unable to get CPU version');
            $str = fgets($fp);
            if ($str == false) tws_error("Unable to read from file '$fname'", 'Unable to get CPU version');
            if (preg_match('/IBM Tivoli Workload Scheduler ([\d.]+)/', $str, $r)) $tws_config['cpuinfo']['version'] = $r[1];
            else tws_error('FILENAME:'.$fname."\n".'LINE#1:'.$str, 'Unable to get CPU version');
            fclose($fp);
         } else {
            //it would have been better to make sure the version command as executed as the IWS maestro and therefore use sudo,
            //but that would require modifying the sudoers file
            $cmd=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), $tws_config['maestro_dir'].'/version/version');
            $stdout=$stderr='';
            tws_popen($cmd,$ec,$stdout,$stderr);
            if (preg_match('/VERSION ([\d.]+)/',$stdout,$r)) $tws_config['cpuinfo']['version']=$r[1];
            else tws_error('CMD: '.$cmd->compile('log')."\n".'STDOUT: '.$stdout."\n".'STDERR: '.$stderr, 'Unable to get CPU version');
         }
      }
      if (isset($tws_config['cpuinfo']['version'])) {
         $version=$tws_config['cpuinfo']['version'];
         $tws_config['cpuinfo']['version_tws']=$version;
         if (strpos($version,".") !== FALSE) {
            $version_slices=explode(".",$version);
            if (count($version_slices) == 2) {
               $version=$version_slices[0] . "." . $version_slices[1];
            } elseif (count($version_slices) < 2) {
               $version=$version_slices[0];
            } elseif (count($version_slices) > 2) {
               $version=$version_slices[0] . ".";
               for ($i=1; $i<count($version_slices); $i++) {
                  $version .= $version_slices[$i];
               }
            }
         }
         $tws_config['cpuinfo']['version']=$version;
      } else {
         $tws_config['cpuinfo']['version']=$tws_config['cpuinfo']['version_tws']='';
      }
   } else {
      tws_error("Unable to get 'thiscpu' value.", "Unable to get cpuinfo");
      return FALSE;
   }

   if (isset($tws_config['cpuinfo']['host']) && isset($tws_config['cpuinfo']['node'])) {
      tws_profile('cpuinfo',$tws_config['cpuinfo']);
   }
   return $tws_config['cpuinfo'];
}

function tws_get_filecontent($fname, $use_cache=FALSE){
   global $tws_config;
   static $cache=array();

   if ($use_cache && isset($cache[$fname]) && ($mtime=filemtime($fname))==$cache[$fname]['mtime']) return $cache[$fname]['data'];
   if($tws_config['host_os']=='win32')  $fname = str_replace('/','\\',$fname);
   $cmd=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), $tws_config['cat'], $fname);
   $stdout=array(); $stderr='';
   if (tws_popen($cmd, $ec, $stdout, $stderr)===FALSE || $ec!=0) {
      tws_error(array("command"=>$cmd->compile('log'), "stdout"=>$stdout, "stderr"=>$stderr), "Unable to read $fname.");
      return false;
   }
   if ($use_cache) $cache[$fname]=array('mtime'=>$mtime, 'data'=>$stdout);
   return $stdout;
}
/// Gets time zone status.
/// The time zone status is stored to the tws_config global.
function tws_get_tz_status() {
   global $tws_config;

   if (($tws_config['tz_status']=tws_profile('tz_status'))!==null && $tws_config['tz_status']!='unknown'){
      return $tws_config['tz_status'];
   }

   if (!isset($tws_config['optmanopts'])){
      tws_get_optmanopts();
   }

   $tz_status=trim(strtoupper($tws_config['optmanopts']['entimezone']));
   if (!isset($tz_status) || ($tz_status!="YES" && $tz_status!="NO")) {
      $tz_status="unknown";
   }

   $tws_config['tz_status']=$tz_status;
   tws_profile('tz_status',$tz_status);
   return $tz_status;
}

///
function tws_get_localopts() {
   global $tws_config;

   if (($tws_config['localopts']=tws_profile('localopts'))!==null){
      return $tws_config['localopts'];
   }

   if (tws_yesno($tws_config['virtual_hosts'],TRUE,FALSE)) {
      $catcmd=isset($tws_config['cat']) ? $tws_config['cat'] : ($tws_config['host_os']!='win32' ? "/bin/cat" : "type");
      $cmd=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), $catcmd, $tws_config['maestro_dir'].'/localopts');
      $localopts=array(); $stderr=''; $ec=0;
      if (tws_popen($cmd, $ec, $localopts, $stderr)===FALSE || $ec!=0) {
         tws_error(array("virtual hosts"=> "Unable to read $tws_config[maestro_dir]/localopts", "stderr"=>$stderr, "Command"=>$cmd->compile('log')), "Unable to read localopts");
         return FALSE;
      }
   }
   else {
      if(file_exists("$tws_config[maestro_dir]/localopts"))
         $localopts_fname = "$tws_config[maestro_dir]/localopts";
      elseif(file_exists($tws_config['twsenv']['UNISONWORK']."/localopts"))
         $localopts_fname = $tws_config['twsenv']['UNISONWORK']."/localopts";
      else{
         tws_error("Can't find localopts file");
         return FALSE;
      }
      if (($localopts=file($localopts_fname))===FALSE) {    // file() function emits an E_WARNING error if the file does not exist.
             tws_error("Unable to open $localopts_fname", "Unable to read localopts");
             return FALSE;
      }
      else
          tws_log("localopts loaded from ".$localopts_fname);
   }

//process the file
   foreach ($localopts as $row) {
      if (preg_match("/^([^#][\w\s]+)=(.*)/", trim($row), $_opt)) {
         if (($cmnt_pos=strrpos($_opt[2],'#'))!==FALSE) {
            if ((($quot_pos=strrpos($_opt[2],'"'))!==FALSE && $quot_pos<$cmnt_pos) || $quot_pos===FALSE) {
               $_opt[2]=substr($_opt[2],0,$cmnt_pos);
            }
         }
         $key=strtolower(trim($_opt[1]));
         //the first occurence of an option is the valid
         if (!isset($tws_config['localopts'][$key])) $tws_config['localopts'][$key] = trim($_opt[2]);
      }
   }
   tws_profile('localopts',$tws_config['localopts']);
   return $tws_config['localopts'];
}

///
function tws_get_globalopts() {
   global $tws_config;

   if (($tws_config['globalopts']=tws_profile('globalopts'))!==null){
      return $tws_config['globalopts'];
   }

   if (tws_yesno($tws_config['virtual_hosts'],TRUE,FALSE)) {
      $catcmd=isset($tws_config['cat']) ? $tws_config['cat'] : ($tws_config['host_os']!='win32' ? "/bin/cat" : "type");
      $cmd=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), $catcmd, $tws_config['maestro_dir'].'/mozart/globalopts');
      $globalopts=array(); $stderr=''; $ec=0;
      if (tws_popen($cmd, $ec, $globalopts, $stderr)===FALSE || $ec!=0) {
         tws_error(array("virtual hosts"=> "Unable to read $tws_config[maestro_dir]/mozart/globalopts", "stderr"=>$stderr, "Command"=>$cmd->compile('log')), "Unable to read globalopts");
         return FALSE;
      }
   } else {
      if ( !file_exists("$tws_config[maestro_dir]/mozart/globalopts") || ($globalopts = file("$tws_config[maestro_dir]/mozart/globalopts")) === FALSE) {
            if (($globalopts = file($tws_config['twsenv']['UNISONWORK'] . "/mozart/globalopts")) === FALSE) {
                tws_error("Unable to open $tws_config[maestro_dir]/mozart/globalopts.", "Unable to read globalopts");
                return FALSE;
            }
            else {
                tws_log("globalopts loaded from " . $tws_config['twsenv']['UNISONWORK'] . "mozart/globalopts.");
            }
        }
        else {
            tws_log("globalopts loaded from $tws_config[maestro_dir]/mozart/globalopts");
        }
   }

// process the globalopts file
   foreach ($globalopts as $row) {
      if (preg_match("/^([^#][\w\s]+)=(.*)/", trim($row), $_opt)) {
         if (($cmnt_pos=strrpos($_opt[2],'#'))!==FALSE) {
            if ((($quot_pos=strrpos($_opt[2],'"'))!==FALSE && $quot_pos<$cmnt_pos) || $quot_pos===FALSE) {
               $_opt[2]=substr($_opt[2],0,$cmnt_pos);
            }
         }
         $key=strtolower(trim($_opt[1]));
         //the first occurence of an option is the valid
         if (!isset($tws_config['globalopts'][$key])) $tws_config['globalopts'][$key] = trim($_opt[2]);
      }
   }
   tws_profile('globalopts',$tws_config['globalopts']);
   return $tws_config['globalopts'];
}

///
function tws_get_optmanopts() {
   global $tws_config;

   if (($tws_config['optmanopts']=tws_profile('optmanopts'))!==null){
      return $tws_config['optmanopts'];
   }

   $optmanopts=array(); $stderr=''; $ec=0;
   if ($tws_config['host_os']=='win32' && !isset($tws_config['maestro_pw'])) {
      if (file_exists("$tws_config[webadmin_user_home_dir]/$tws_config[maestro_user]".'/.TWS/'.(isset($tws_config['localopts']['useropts']) ? $tws_config['localopts']['useropts'] : 'tws')))
         $cmd=new hwi_cmd($tws_config['maestro_dir'].'/bin/optman', "-file", "$tws_config[webadmin_user_home_dir]/$tws_config[maestro_user]".'/.TWS/'.(isset($tws_config['localopts']['useropts']) ? $tws_config['localopts']['useropts'] : 'tws'), 'ls');
      else
          $cmd=new hwi_cmd($tws_config['maestro_dir'].'/bin/optman', $tws_config['composer_args'], 'ls');
   } else {
      //
      // VERY IMPORTANT: It's very important that the IWS maestro user has a valid IWS Useropts in its OS home directory
      //
      $cmd=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), $tws_config['maestro_dir'].'/bin/optman', 'ls');
   }
   if (tws_popen($cmd, $ec, $optmanopts, $stderr)===FALSE || $ec!=0) {
      tws_error(array('cmd'=>$cmd->compile('log'), 'stdout'=>$optmanopts, 'stderr'=>$stderr, 'env'=>$_ENV), 'Unable to get optman options');
      return FALSE;
   }

// process the optman output
   foreach ($optmanopts as $row) {
      if (preg_match("/^([^#][\w\s]+)\/\s*\w+\s*=(.*)/", trim($row), $_opt)) {
         if (($cmnt_pos=strrpos($_opt[2],'#'))!==FALSE) {
            if ((($quot_pos=strrpos($_opt[2],'"'))!==FALSE && $quot_pos<$cmnt_pos) || $quot_pos===FALSE) {
               $_opt[2]=substr($_opt[2],0,$cmnt_pos);
            }
         }
         $tws_config['optmanopts'][strtolower(trim($_opt[1]))] = trim($_opt[2]);
      }
   }
   tws_profile('optmanopts',$tws_config['optmanopts']);
   return $tws_config['optmanopts'];
}

function tws_get_page_size() {
   global $tws_config;
   if (strtolower(php_sapi_name()) == 'cli') {
      return 0; // pagination off for cli
   } else if (isset($_GET['pagesize'])) {
      tws_log('-- tws_get_page_size : using temporary pagesize = '.$_GET['pagesize']);
      return $_GET['pagesize'];
   } else if (($pagesize=tws_profile('pagesize'))!==null && is_numeric($pagesize)) {
      tws_log('-- tws_get_page_size : custom pagesize = '.$pagesize);
      return ($pagesize > 0) ? $pagesize : 0;
   } else if (isset($tws_config['pagesize'])) {
      tws_log('-- tws_get_page_size : using $tws_config[pagesize] = '.$tws_config['pagesize']);
      return ($tws_config['pagesize'] > 0) ? $tws_config['pagesize'] : 0;
   } else {
      tws_log('-- tws_get_page_size : default pagesize = 100');
      return 100;
   }
}

//IMPORTANT: each webadmin script running through apache must have 'sudo_authority' definition in the profile (php session)
function tws_sudo($cmd='', $user='', $pw='') {
   global $tws_config;
   static $errc=array(); //error counter

   if (!defined('IWD_PROCMAN')) {
        $sudo_exec=$tws_config['base_inst_dir'].'/bin/sudo'.($tws_config['host_os']=='win32' ? '.exe' : '');
   } else {
        if (isset($tws_config['sudo'])) $sudo_exec=$tws_config['sudo'];
        elseif (isset($GLOBALS['hwi_config']['sudo'])) {
            $sudo_exec=$GLOBALS['hwi_config']['sudo'];
            if (!isset($tws_config['sudo_args'])) $tws_config['sudo_args']=$GLOBALS['hwi_config']['sudo_args'];
        }
   }

   if (!isset($tws_config['sudo_args'])) $tws_config['sudo_args']=($tws_config['host_os']=='win32' ? '' : '-H');

   $sudo_args=$tws_config['sudo_args'];
   if ($user=='') {
      //
      // new since 3.2.4
      // IMPORTANT NOTE: There are some IWS utilities that doesn't support connection parameters
      //                 and still looks for the credentials in $HOME/.TWS/useropts_<MDM> file.
      //                 Therefore the sudo's -H option cannot be used if the HOME (only if HOME environment variable exists)
      //                 as it forces the user's OS home.
      //
      // IMPORTANT NOTE: Only for calls where the user is the same as current IWS activity user. If some command is called as another user,
      //                 for examp;e, if optman is executed as the IWS Maestro, then we don't want the current user's HOME is used.
      //                 We need the -H option to be used in such case.
      //
      // Note: IMPORTANT some IWS utilities (e.g. jbxtract) is very old one, not supporting the connection parameters from commands line
      //       and taking the credentials from the $HOME/.TWS/useropts. Since WebAdmin 3.2.4 the sudo argument -H is removed as it overides
      //       the $HOME variable
      //
      // Tips: At installations where WebAdmin is not responsible for managing the useropts file it is necessary to
      //       to either set sudo_args to "-H -H" (only one is removed in tws_sudo) and/or it's necessary to specify the
      //       HOME variable in tws_config[twsenv] manually so WEBADMIN will not replace it
      if (isset($tws_config['twsenv']['HOME'])) $sudo_args=preg_replace('/-H/','',$sudo_args, 1);
   }

   $sudo="$sudo_exec $sudo_args ";
   $sudo_hidden_pw='';

   //$sudo_args is an array of options from now on. The options are simple expolded by the blank character. This has to be
   //imporved if there are more complicated sudo options in the future.
   $sudo_args=explode(' ', $sudo_args);

   if (($tws_authority=tws_profile('tws_authority'))===null) {
      if (php_sapi_name()!='cli') $tws_authority=$_SERVER['PHP_AUTH_USER'];
      else {
         if (isset($_SERVER['USER'])) $tws_authority=$_SERVER['USER'];
         elseif (isset($_SERVER['LOGNAME'])) $tws_authority=$_SERVER['LOGNAME'];
         else {
            tws_log('tws_sudo: tws_authority not specified, taking IWS Maestro user');
            if (!isset($errc['ERR1'])) {
               tws_error('cli='.php_sapi_name()."\n_SERVER=".print_r($_SERVER,1), 'tws_authority not specified, taking IWS Maestro user '.$tws_config['maestro_user']);
               $errc['ERR1']=1;
            }
            $tws_authority=$tws_config['maestro_user'];
         }
      }
   }
   $sudo_auth=tws_profile('sudo_auth'); //array(0=>username, 1=>password-win32 only)

   if ($user!='') {
      if ($tws_config['host_os']=='win32') {
//Important note !!! : Since 3.0.5 on win32 the force mapped auth is considered as set to 1 if it's not defined
         if ((!isset($tws_config['force_mapped_auth']) || tws_yesno($tws_config['force_mapped_auth'],TRUE,FALSE)) && $sudo_auth!==null) {
            if (!preg_match("/^$user/", $sudo_auth[0])) {
               tws_log("tws_sudo('".(is_string($cmd) ? $cmd : $cmd->compile('log')). "', '".$user."');", "WARNING: Although user '$user' is requested by script, alternately defined IWS authority user '$tws_authority' will be used.");
            }
            $sudo_hidden_pw="$sudo $tws_authority ******";
            $sudo.=$sudo_auth[0].' "'.tws_decrypt($sudo_auth[1]).'"';
            array_push($sudo_args, hwi_cmd::hidden(tws_decrypt($sudo_auth[1])));
         } else {
            if ($pw=='' && $user==$tws_config['maestro_user'])
               $pw=(isset($tws_config['maestro_pw'])? $tws_config['maestro_pw'] : '');
            if ($pw=='') {
               tws_log("tws_sudo('".(is_string($cmd) ? $cmd : $cmd->compile('log')). "', '$user',null);", "Missing user's password to complete sudo command. Trying to continue without sudo.");
               if (!isset($errc['ERR2'])) {
                  // tws_error( array( "cmd"=>(is_string($cmd) ? $cmd : $cmd->compile('log')), "stderr"=>"Missing user's password to complete sudo command. Trying to continue without sudo"), '');
                  $errc['ERR2']=1;
               }
               $sudo='';
            } else {
               $sudo_hidden_pw="$sudo $user *****";
               $sudo.=" $user \"$pw\"";
               array_push($sudo_args, $user, hwi_cmd::hidden($pw));
            }
         }
      } else {
// the mapped user has stronger priority than the user required by script if $tws_config['force_mapped_auth'] is set to true or 1
         if (tws_yesno(@$tws_config['force_mapped_auth'],TRUE,FALSE) && $sudo_auth!==null) {
// print warning message in case that the mapped user differs to the required user
            if (!preg_match("/^$user/", $sudo_auth[0])) {
               tws_log("tws_sudo('".(is_string($cmd) ? $cmd : $cmd->compile('log'))."', '$user');", "Although user '$user' is requested by script, alternately defined IWS authority user '$tws_authority' will be used.");
            }
            $sudo.=' -u '.$sudo_auth[0];
            array_push($sudo_args, '-u', $sudo_auth[0]);
         } else {
            $sudo.=" -u $user";
            array_push($sudo_args, '-u', $user);
         }
      }
   } else {
      if ($sudo_auth!==null) {
         $sudo_mode=isset($tws_config['sudo_mode']) ? strtolower($tws_config['sudo_mode']) : 'os,apache,ldap';
         if (strpos($sudo_mode,tws_profile('twscli_authtype'))===FALSE && (empty($cmd) || preg_match('/\/bin\/(conman|composer|planman|optman)/', (is_string($cmd) ? $cmd : var_export($cmd,TRUE))))) {
// dont't use sudo, but IWS credentials for apache, ldap (by default) authentication type when calling IWS utilities that supports it: (composer,planman,optman)
// IMPORTANT NOTE: in current versions of IWS - 8.3FP4, 8.4FP1 - conman ignores the connection parameters and still runs as
//                 the user that ows the process - in case of webadmin it is the <MAESTRO_USER>
// NOTE: since use of the hwi_cmd command the $cmd argument is not used, that's the reason of the "empty($cmd)" exception,
//
            $sudo='';
         } else {
            if ($tws_config['host_os']=='win32') {
               $sudo_hidden_pw="$sudo $tws_authority ******";
               $sudo.=$sudo_auth[0].' "'.tws_decrypt($sudo_auth[1]).'"';
               array_push($sudo_args, $sudo_auth[0], hwi_cmd::hidden(tws_decrypt($sudo_auth[1])));
            } else {
               $sudo.=' -u '.$sudo_auth[0];
               array_push($sudo_args, '-u', $sudo_auth[0]);
            }
         }
      } else {
// any webadmin script running through apache should never get into this branch, this is only for CLI usage
         if ($tws_config['host_os']=='win32') {
            if (isset($tws_config['maestro_user_passwd'])) {
               $sudo_hidden_pw="$sudo $tws_config[maestro_user] *****";
               $sudo.=" $tws_config[maestro_user] \"$tws_config[maestro_pw]\"";
               array_push($sudo_args, $tws_config['maestro_user'], hwi_cmd::hidden($tws_config['maestro_pw']));
            } else {
               tws_log("tws_sudo('".(is_string($cmd) ? $cmd : $cmd->compile('log'))."');", "Missing maestro user's password to complete sudo command. Trying to continue without sudo.");
               if (!isset($errc['ERR3'])) {
                  // tws_error( array( "cmd"=>(is_string($cmd) ? $cmd : $cmd->compile('log')), "stderr"=>"Missing user's password to complete sudo command. Trying to continue without sudo"), '');
                  $errc['ERR3']=1;
               }
               $sudo='';
               $sudo_args=array();
            }
         } else {
            $sudo.=" -u $tws_config[maestro_user]";
            array_push($sudo_args, '-u', $tws_config['maestro_user']);
         }
      }
   }

   if ($sudo!='') {
      if (is_array($cmd)) {
         foreach ($cmd as $c) $sudo_args[]=$c;
         $safe_args=TRUE;
      } elseif ($cmd=='') {
         $safe_args=TRUE;
      } else {
         $sudo_args[]=$cmd;
         $safe_args=FALSE;
      }
      $cmdstruct=array(
         'exec'=>$sudo_exec,
         'args'=>$sudo_args, /*sudo parameters formatted for the hwi_cmd class !!!*/
         'safe_args'=>$safe_args,
         'cmd'=>ltrim($sudo.' '.$cmd),
         'log'=>($sudo_hidden_pw!='' ? $sudo_hidden_pw : $sudo).' '.$cmd
      );
   } else {
      //warning - deprecated executions, possible security hole
      $cmdstruct=array(
         'cmd'=>$cmd,
         'log'=>$cmd,
         'safe_args'=>FALSE
      );
   }
   tws_log('-- tws_sudo : '.$cmdstruct['log']);
   return $cmdstruct;
}

///
/// Note: Manuall mode activated when $stdout===FALSE && $stderr===FALSE
///
function tws_popen($cmdstruct, &$exitcode, &$stdout, &$stderr, $stdin='', $env='') {
   return hwi_popen($cmdstruct, $exitcode, $stdout, $stderr, $stdin, $env);
}

function tws_pclose($pipes) {
   return hwi_pclose($pipes);
}

///
function tws_show_cmp_table($orig_column, $new_column, $orig_data, $new_data, $label_map=Array()) {
   if (count($orig_data)==1 && count($new_data)==1) {
      require_once "Text/Highlighter.php";
      require_once "Text/Highlighter/Renderer/Html.php";
      $renderer = new Text_Highlighter_Renderer_Html(); //array("numbers" => HL_NUMBERS_LI, "tabsize" => 3));
      $hlxml =& Text_Highlighter::factory("XML");
      $hlxml->setRenderer($renderer);

      $left=$hlxml->highlight($orig_data['xml']);
      $right=$hlxml->highlight($new_data['xml']);

      //line by line comparison
      $left=explode("\n",$left);
      $right=explode("\n",$right);
      $leftdesc=array($orig_column=>'');
      $rightdesc=array($new_column=>'');
      if (($ret=tws_compare($left, $right, 'TC', array($leftdesc,$rightdesc)))===FALSE) {
         return FALSE;
      }
      echo html_entity_decode($ret, ENT_QUOTES, 'UTF-8');
   } else {
      echo "<table class=\"cmp\">\n";
      echo "<tr>\n<th>Item</th><th>".htmlspecialchars($orig_column)."</th><th>".htmlspecialchars($new_column)."</th>\n";
      foreach ($orig_data as $key=>$val) {
         if (isset($label_map[$key]) && $label_map[$key]===FALSE) continue;
         if (is_array($val) || is_array($new_data[$key])){
            $val = tws_compare_print_r($val);
            if(isset($new_data[$key]))
               $newval = tws_compare_print_r($new_data[$key]);
            else $newval = '';
         }
         else
            $newval=$new_data[$key];

         $val=trim($val);
         $newval=trim($newval);
         if($val == '' && $newval == '') continue;

         $style=($val!=$newval) ? "class=\"highlight\"" : "";
         $orig_style=$new_style='';
         if ($orig_data[$key]===FALSE) $orig_style="style=\"text-align:center;font-weight:normal;font-style:italic;color:#a00000\"";
         if ($new_data[$key]===FALSE) $new_style="style=\"text-align:center;font-weight:normal;font-style:italic;color:#a00000\"";
         if (preg_match('/password/',$key)) {
            if($val!='') $val='******';
            if($newval!='') $newval='******';
         }
         echo "<tr>\n";
         echo "<td valign='top' $style>&nbsp;&nbsp;&nbsp;&nbsp;<b>".(@$label_map[$key] ? $label_map[$key] : $key)."</b>:</td>\n";
         echo "<td valign='top' $style $orig_style>".($orig_data[$key]===FALSE ? 'N/A' : tws_nl2br(htmlspecialchars($val)))."</td>\n";
         echo "<td valign='top' $style $new_style>".($new_data[$key]===FALSE ? 'N/A' : tws_nl2br(htmlspecialchars($newval)))."</td>\n";
         echo "</tr>\n";
      }
      echo "</table>\n";
   }
   return true;
}

function tws_nl2br($string) {
$string = str_replace(array("\r\n", "\r", "\n"), "<br/>", $string);
 return $string;
}
// return array for compare table
function tws_compare_print_r ($arr) {
   //ksort($arr);
   $str = '';
   foreach($arr as $i=>$j) {
      if(is_array($j)){
         $str .= tws_compare_print_r($j);
      }
      elseif (is_string($i)) {
         if($i == 'name' || $i == 'DisplayName') {
            $str = "$j:\n";
            $haveName = 1;
         }
         else {
            if ($haveName)
               $str .= "   $i: $j\n";
            else
               $str .= "$i: $j\n";
         }
      }
      else
         $str .= "$j\n";
   }
   return $str;
}

function tws_neg($v) {
   switch ($v) {
      case 'Y' : return 'N';
      case 'y' : return 'n';
      case 'N' : return 'Y';
      case 'n' : return 'y';
      case '1' : return '0';
      case '0' : return '1';
   }
   return '';
}

/// Make URL valid_from
/// prepares valid_from data to be send in URL
/// \param date in format YYYY-MM-DD (returned from DB)
/// \return empty string or ":YYYYMMDD"
function tws_make_url_valid_from($date) {
   if ( $date == "" ) {
      return "";
   } else {
      return ":".str_replace("-","",$date);
   }
}

/// Make ISO valid_from
/// extract ISO valid_from data from data sent via URL
/// \param data in format "YYYYMMDD"
/// \return in format YYYY-MM-DD (returned also from DB)
function tws_make_iso_valid_from($data) {
   $ret="";
   if (preg_match("/([0-9]{4})([0-9]{2})([0-9]{2})/",$data,$r)) {
      return $r[1]."-".$r[2]."-".$r[3];
   } else {
      return "";
   }
}

/// Date from ISO
/// converts ISO Date to composer date. The output format depends on the Date format in localopts.
/// \param date in format YYYY-MM-DD
/// \return date in format the composer will accept. FALSE in case that \c date is not in the form
///   NNNN-NN-NN, 'date format' option is unknown or its value is out of the supported range (0-3).
function tws_date_from_iso($date) {
   global $tws_config;

   if( preg_match( "/(\d{4})-(\d{2})-(\d{2})/", trim($date), $_date) ){
      switch( $tws_config['localopts']['date format'] ){
         case '0' : //0-yyyy/mm/dd
            return $_date[1].'/'.$_date[2].'/'.$_date[3];
         case '1' : //1-mm/dd/yyyy
            return $_date[2].'/'.$_date[3].'/'.$_date[1];
         case '2' : //2-dd/mm/yyyy
            return $_date[3].'/'.$_date[2].'/'.$_date[1];
         case '3' : //TODO:
            return $_date[1].'/'.$_date[2].'/'.$_date[3];
      }
   }
   return FALSE;
}

/// Composer Date to ISO
/// converts composer date to ISO Date. The input format depends on the Date format in localopts.
/// \param date in composer format
/// \return date in ISO format the composer will accept.
///
/// FALSE in case that composer date is not in the correct form
///
function tws_date_to_iso($composer_date) {
   global $tws_config;
   $iso_date=FALSE;
   switch ($tws_config['localopts']['date format']) {
      case '0' : //0-yyyy/mm/dd
         if (preg_match('/((\d{2,4})\/)?(\d{2})\/(\d{2})/', trim($composer_date), $_date))
            $iso_date=($_date[2]!='' ? str_pad($_date[2],4,date('Y'),STR_PAD_LEFT).'-' : '').$_date[3].'-'.$_date[4];
         break;
      case '1' : //1-mm/dd/yyyy
         if (preg_match('/(\d{2})\/(\d{2})(\/(\d{2,4}))?/', trim($composer_date), $_date))
            $iso_date=(@$_date[4]!='' ? str_pad($_date[4],4,date('Y'),STR_PAD_LEFT).'-' : '').$_date[1].'-'.$_date[2];
         break;
      case '2' : //2-dd/mm/yyyy
         if (preg_match('/(\d{2})\/(\d{2})(\/(\d{2,4}))?/', trim($composer_date), $_date))
            $iso_date=(@$_date[4]!='' ? str_pad($_date[4],4,date('Y'),STR_PAD_LEFT).'-' : '').$_date[2].'-'.$_date[1];
         break;
      case '3' : //TODO:
         $iso_date=FALSE;
   }
   return $iso_date;
}

function tws_get_jobstream_data($sel, $sep=';') {
   $s=explode($sep,$sel);
   if (count($s)!=4) {
      tws_error($sel,__FUNCTION__.' : Unexpected format of data');
      return FALSE;
   }
   return Array ('cpu'=>$s[0], 'schedule'=>$s[1], 'schedtime'=>$s[2], 'schedid'=>$s[3]);
}
function tws_get_job_data($sel, $sep=';') {
   $s=explode($sep,$sel);
   if (count($s)!=7) {
      tws_error($sel,__FUNCTION__.' : Unexpected format of data');
      return FALSE;
   }
   return Array ('cpu'=>$s[0], 'schedule'=>$s[1], 'schedtime'=>$s[2], 'schedid'=>$s[3], 'jobcpu'=>$s[4], 'job'=>$s[5], 'jobnum'=>$s[6]);
}
function tws_get_wks_data($sel, $sep=';') {
   $s=explode($sep,$sel);
   if (count($s)!=2) {
      tws_error($sel,__FUNCTION__.' : Unexpected format of data');
      return FALSE;
   }
   return Array ('cpu'=>$s[0], 'dom'=>$s[1]);
}
function tws_get_dom_data($sel, $sep=';') {
   $s=explode($sep,$sel);
   if (count($s)!=1) {
      tws_error($sel,__FUNCTION__.' : Unexpected format of data');
      return FALSE;
   }
   return Array ('dom'=>$s[0]);
}
function tws_get_res_data($sel, $sep=';') {
   $s=explode($sep,$sel);
   if (count($s)!=2) {
      tws_error($sel,__FUNCTION__.' : Unexpected format of data');
      return FALSE;
   }
   return Array ('cpu'=>$s[0], 'res'=>$s[1]);
}
function tws_get_prompt_data($sel, $sep=';') {
   $s=explode($sep,$sel,3); //prompt text may also contain semicolons!
   if (count($s)!=3) {
      tws_error($sel,__FUNCTION__.' : Unexpected format of data');
      return FALSE;
   }
   return Array ('num'=>$s[0], 'name'=>$s[1], 'text'=>$s[2]);
}
function tws_get_file_data($sel, $sep=';') {
   $s=explode($sep,$sel);
   if (count($s)!=2) {
      tws_error($sel,__FUNCTION__.' : Unexpected format of data');
      return FALSE;
   }
   return Array ('cpu'=>$s[0], 'filename'=>$s[1]);
}
function tws_get_parameter_data($sel, $sep='.') {
   list($pn,$pt)=array_reverse(explode($sep,$sel));
   return array('tab'=>$pt, 'name'=>$pn);
}

function tws_get_db_jobstream_data($sel) {
   list($js,$w)=array_reverse(explode('#',$sel));
   list($js,$vf)=explode(':',$js);
   if (isset($vf) && $vf!='') {
      $isovf=tws_make_iso_valid_from($vf);
      $vftext_tws='valid from '.tws_date_from_iso($isovf);
      $vftext_user='valid from '.tws_iso_to_userdate($isovf,null,TRUE);
   } else $isovf=$vftext_user=$vftext_tws='';
   return array('workstation'=>$w, 'jobstream'=>$js, 'validfrom_iso'=>$isovf, 'validfrom_text_user'=>$vftext_user, 'validfrom_text_tws'=>$vftext_tws);
}


function tws_flush_output() {
   ob_flush();
   flush();
}

////////////////////////////////////////////////////////////////
///
///   function tws_filter_info($file)
///
///  returns info from filter file
///
///   param: filename (including path)
///
function tws_filter_info($file) {
   $contents=implode('',file("$file"));
   $description_start=strpos($contents,"<description>");
   if ($description_start !== FALSE) {
      $description_end=strpos($contents,"</description>");
      if ($description_end !== FALSE) {
         $comment=substr($contents,($description_start + 13),($description_end - $description_start - 13));
      }
   }
   if (!isset($comment)) $comment='';
   $creator_start=strpos($contents,"<creator>");
   if ($creator_start !== FALSE) {
      $creator_end=strpos($contents,"</creator>");
      if ($creator_end !== FALSE) {
         $creator=substr($contents,($creator_start + 9),($creator_end - $creator_start - 9));
     }
   }
   if (!isset($creator)) $creator='';
   $selection_start=strpos($contents,"<selection>");
   if ($selection_start !== FALSE) {
      $selection_end=strpos($contents,"</selection>");
      if ($selection_end !== FALSE) {
         $selection=substr($contents,($selection_start + 11),($selection_end - $selection_start - 11));
      }
   }
   if (!isset($selection)) $selection='';

   $start=strpos($contents,"<category>");
   if ($start !== FALSE) {
      $end=strpos($contents,"</category>");
      if ($end !== FALSE)
         $category=substr($contents,($start + 10),($end - $start - 10));
   }
   if (!isset($category)) $category='';

   $ret = Array($comment, $creator, $selection, $category);
   return $ret;
}

//////////////////////////////////////////////////////////////////
///
///  function tws_get_filter_list
///
///  gets list of filters for all_users and actual user
///
///  param: $filter = part of filename (filter type)
///         $user = username
///         $all = include all user ?
///
function tws_get_filter_list($filter='', $user='', $all='yes') {
   global $tws_config;

   $file_num=0;
   if ($filter=='') $extension=".flt";
      else $extension = ".".$filter.".flt";
   $extension_len = strlen($extension) ;

   if ($all == "yes") {
      $alluser_dir=$tws_config['webadmin_all_user_dir'];
      $dp2=opendir($alluser_dir);
      $file_stripped = array();
      $file = array();
      while ($filename=readdir($dp2)) {
         if (substr($filename,$extension_len * -1) == $extension) {
            $file_num++;
            $file[$file_num]=$filename;
            $file_stripped[$file_num]=substr($filename,0,$extension_len * -1);

            list ($comment[$file_num], $creator[$file_num], $selection[$file_num], $category[$file_num] ) = tws_filter_info("$alluser_dir/$filename");

            $for_all[$file_num]="YES";
         }
      }
      closedir($dp2);
      if( ($pos95 = array_search('All.95', $file_stripped)) !== false && ($pos = array_search('All', $file_stripped)) !== false ){
         if($tws_config['cpuinfo']['version']>='9.5')
            // rename 'All.95' to 'All', filter to remove = 'All'
            $file_stripped[$pos95] = 'All';
         else $pos = $pos95;  // filter to remove = 'All.95'

         unset($file[$pos]);
         unset($file_stripped[$pos]);
         unset($comment[$pos]);
         unset($creator[$pos]);
         unset($selection[$pos]);
         unset($for_all[$pos]);
         unset($category[$pos]);
         $file_num --;
         // reindex results
         // I don't know why thete are indexed from 1 but not from 0,
         // so I'll not change it
         // so I need to use such strange combination, instead of simple array_values() f-ce

         $file = array_combine(range(1, count($file)), array_values($file));
         $file_stripped = array_combine(range(1, count($file_stripped)), array_values($file_stripped));
         $comment = array_combine(range(1, count($comment)), array_values($comment));
         $creator = array_combine(range(1, count($creator)), array_values($creator));
         $selection = array_combine(range(1, count($selection)), array_values($selection));
         $for_all = array_combine(range(1, count($for_all)), array_values($for_all));
         $category = array_combine(range(1, count($category)), array_values($category));
      }
   }

   if ($user == "")
      $user_dir=$tws_config['webadmin_user_home_dir'].'/'.tws_profile('auth_user_name');
   else
      $user_dir=$tws_config['webadmin_user_home_dir'].'/'.$user;
   $dp=opendir($user_dir);
   while ($filename=readdir($dp)) {
      if (substr($filename,$extension_len * -1) == $extension) {
         $file_num++;
         $file[$file_num]=$filename;
         $file_stripped[$file_num]=substr($filename,0,$extension_len * -1);

         list ($comment[$file_num], $creator[$file_num], $selection[$file_num], $category[$file_num] ) = tws_filter_info("$user_dir/$filename");

         $for_all[$file_num]='';
      }
   }
   closedir($dp);

   $fil=Array();
   if ($file_num > 0) {
      $fil['file'] = $file;
      $fil['file_stripped'] = $file_stripped;
      $fil['comment'] = $comment;
      $fil['creator'] = $creator;
      $fil['selection'] = $selection;
      $fil['for_all'] = $for_all;
      $fil['category'] = $category;
   }
   $fil['file_num']=$file_num;

   return $fil;
}

//////////////////////////////////////////
//
// function  tws_load_options()
//
// loads optios.php file from all_users dir and home dir at start of session
//
function tws_load_options($mode='') {
   global $tws_config;

   if (tws_profile('options_loaded')!="yes" || $mode!='') {
      $global_options=$tws_config['webadmin_all_user_dir'].$tws_config['user_setting_dir'].'/options32.php';
      $user_options=$tws_config['webadmin_user_home_dir'].'/'.tws_profile('auth_user_name').$tws_config['user_setting_dir'].'/options32.php';
      if (is_file($global_options)) {
         include($global_options);
      }
      if (is_file($user_options) && $mode!='GLOBAL_ONLY') {
         if (tws_rights('t')) {
            $glb_timeout =  tws_profile('timeout');
            $glb_pagesize = tws_profile('pagesize');
            $glb_enable_trace = tws_profile('enable_trace');
         }
         include($user_options);

         if (tws_rights('t')) {
            tws_profile('timeout', $glb_timeout);
            tws_profile('pagesize', $glb_pagesize);
            tws_profile('enable_trace', $glb_enable_trace);
         }
      }
      tws_profile('options_loaded','yes');
   }
   // if(empty($date_format)) get it from localopts
   $date_format = tws_profile("date_format");
   if(empty($date_format)){
      $date_format = tws_user_date_format('');
      $date_format = str_ireplace('YYYY', 'y', $date_format);
      $date_format = str_ireplace('MM', 'm', $date_format);
      $date_format = str_ireplace('DD', 'd', $date_format);
      tws_profile("date_format", $date_format);
   }
}

/////////////////////////////////////////////////////////////////////////
///
///   function  tws_report_info($file)
///
///   returns info from report file
///   param: filename including path
///
function tws_report_info($file) {
   $contents=implode('',file("$file"));

   $type_start=strpos($contents,"<type>");
   if ($type_start !== FALSE) {
      $type_end=strpos($contents,"</type>");
      if ($type_end !== FALSE) {
         $type=substr($contents,($type_start + 6),($type_end - $type_start - 6));
      } else {
         $type=" ";
      }
   } else {
      $type=" ";
   }

   $description_start=strpos($contents,"<description>");
   if ($description_start !== FALSE) {
      $description_end=strpos($contents,"</description>");
      if ($description_end !== FALSE) {
         $comment=substr($contents,($description_start + 13),($description_end - $description_start - 13));
      } else {
         $comment=" ";
      }
   } else {
      $comment=" ";
   }
   $creator_start=strpos($contents,"<creator>");
   if ($creator_start !== FALSE) {
      $creator_end=strpos($contents,"</creator>");
      if ($creator_end !== FALSE) {
         $creator=substr($contents,($creator_start + 9),($creator_end - $creator_start - 9));
      } else {
         $creator=" ";
      }
   } else {
      $creator=" ";
   }

   $ret=Array();
   $ret[]=$comment;
   $ret[]=$type;
   $ret[]=$creator;
   return $ret;
}

/////////////////////////////////////////////////////////////////////////
///
///  function get_reports()
///
///  returns list of reports defined for all users and logged user
///
///
function tws_get_reports($user='',$all='yes') {
   global $tws_config;
   $file_num=0;

   if ($user == '')
      $user = tws_profile('auth_user_name');
   $user_dir = $tws_config['webadmin_user_home_dir'].'/'.$user;

   if ($all == "yes") {
      $dp=opendir($tws_config['webadmin_all_user_dir']);
      while ($filename=readdir($dp)) {
         if (substr($filename,-4) == ".rpt") {
            list ($tcomment, $ttype, $tcreator) = tws_report_info($tws_config['webadmin_all_user_dir'].'/'.$filename);
            if ($tcreator == $user) continue;   // User's reports will be in the end of forall reports list
            $file_num++;
            list ($comment[$file_num], $type[$file_num], $creator[$file_num]) = array($tcomment, $ttype, $tcreator);
            $file[$file_num]=$filename;
            $file_stripped[$file_num]=substr($filename,0,-4);
            $forall[$file_num]="YES";
         }
      }
      rewinddir($dp);
      while ($filename=readdir($dp)) { // Now user's reports
         if (substr($filename,-4) == ".rpt") {
            list ($tcomment, $ttype, $tcreator) = tws_report_info($tws_config['webadmin_all_user_dir'].'/'.$filename);
            if ($tcreator != $user) continue;
            $file_num++;
            list ($comment[$file_num], $type[$file_num], $creator[$file_num]) = array($tcomment, $ttype, $tcreator);
            $file[$file_num]=$filename;
            $file_stripped[$file_num]=substr($filename,0,-4);
            $forall[$file_num]="YES";
         }
      }
      closedir($dp);
   }

   $dp=opendir($user_dir);
   while ($filename=readdir($dp)) {
      if (substr($filename,-4) == ".rpt") {
         $file_num++;
         $file[$file_num]=$filename;
         $file_stripped[$file_num]=substr($filename,0,-4);
         list ($comment[$file_num], $type[$file_num], $creator[$file_num]) = tws_report_info("$user_dir/$filename");
         $forall[$file_num]=" ";
      }
   }
   closedir($dp);

   if ($file_num > 0) {
      $reports['file']= $file;
      $reports['file_stripped'] = $file_stripped;
      $reports['type'] = $type;
      $reports['comment'] = $comment;
      $reports['forall']=$forall;
      $reports['creator']=$creator;
   }
   $reports['report_num'] = $file_num;
   return $reports;
}

///////////////////////////////////////////////////////
//
//   tws_get_user_dirs
//       returns array of user directories in home directory
//
function tws_get_user_dirs() {
   global $tws_config;
   $cwd=getcwd();
   chdir($tws_config['webadmin_user_home_dir']);
   $dp = opendir(".");
   $users=Array();
   while ($filename=readdir($dp)) {
      if (is_dir($filename)
         && ($filename != ".")
         && ($filename != "..")
         && ($filename != "all_users") ) {
         $users[]=$filename;
      }
   }
   closedir($dp);
   chdir($cwd);
   return $users;
}

///////////////////////////////////////
//
//   tws_save_severities($severity,$color)
//
function tws_save_severities($severity,$color) {
   global $severities_file;
   // reindex
   $i=0;
   foreach ($severity as $key => $val) {
      $n_severity[$i]=$severity[$key];
      $n_color[$i]=$color[$key];
      $i++;
   }
   $content ="<? \n";
   $content.="\$severity = ". var_export($n_severity,TRUE).";\n";
   $content.="\$color = ". var_export($n_color,TRUE).";\n";
   $content.="?>\n";

   $fp = fopen($severities_file,"w") or die("<p class=warning>Error: Cannot write to file</p>");
   $numbytes = fwrite($fp,$content);
   if ($numbytes == 0) {
      fclose($fp);
      die("<p class=warning>Error: Cannot write to file</p>");
   }
   fclose($fp);
   tws_chmod($severities_file, 0664);
}

///////////////////////////////////////////////////////
//
//    tws_event_type($event, $type)
//
//   returns true if $event belongs to a group events
//     used for custom events definition
function tws_event_type($event, $type) {
   switch ($type) {
      case "job":
         $ret = in_array($event,array(101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,204));
         break;
      case "jobstream":
         $ret = in_array($event,array(151,152,153,154,155,156,157,158,159,160,161,162,163,164,165));
         break;
      case "prompt":
         $ret = in_array($event,array(201,202,203));
         break;
   }
   return $ret;
}

///////////////////////////////////////////////////
//
//    tws_save_custom_events($custom_event)
//
function tws_save_custom_events($custom_event) {
   global $custom_events_file;
//reindex
   $i=0;
   $n_ce=array();
   foreach ($custom_event as $key => $value) {
      $n_ce[$i]=$value;
      $i++;
   }

   $content  = "<?\n";
   $content .= "\$custom_event = ".var_export($n_ce,TRUE).";\n";
   $content .= "?>\n";

   $fp = fopen($custom_events_file,"w") or die("<p class=warning>Error: Cannot write to file</p>");
   $numbytes = fwrite($fp,$content);
   if ($numbytes == 0) {
      fclose($fp);
      die("<p class=warning>Error: Cannot write to file</p>");
   }
   fclose($fp);
   tws_chmod($custom_events_file, 0664);
}


///
function tws_get_localparms($arg, $page_size = 0, $page = 1) {
   tws_log('-- get_db_localparms_list (start at '.basename(__FILE__).'['.__LINE__.'])');
   global $maestro_dir, $tws_config;
   $parms=Array();
   $parms['parm_num']=0;

   $catcmd=isset($tws_config['cat']) ? $tws_config['cat'] : ($tws_config['host_os']=='win32' ? "$tws_config[maestro_dir]/webadmin/bin/type" : '/bin/cat');

   if($tws_config['cpuinfo']['version']>='9.5')
       $pardir = $tws_config ["twsenv"]["UNISONWORK"];
   else
       $pardir = $maestro_dir;
   $file="$pardir/parameters";
   tws_log('-- get_db_localparms_list (loading file '.$file.')');
   if (($stdout = tws_get_filecontent($file))===FALSE)
      return FALSE;

      foreach ($stdout as $line) {
         $tl && tws_log($line);
         if (substr($line,0,2) === 'DM'){
            // TODO filtering against $arg
            $parms['parm_num']++;
            if ($page_size && (($page_down > $parms['parm_num']) || ($page_up < $parms['parm_num']))) {
               continue;
            }
            $maxlen=16;
            if($tws_config['cpuinfo']['version']<='8.4') $maxlen=8;
            $parms['parm_name' ][] = trim(substr($line, 2, $maxlen));
            $parms['parm_value'][] = trim(substr($line, $maxlen+2));
         }
      }
   tws_log('-- get_db_localparms_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
   return $parms;
}

function tws_symphony_info($symhony_filename) {
//just to ensure name without directories
   $fname=basename($symhony_filename);

// forecasts and trials created using IWS/WebAdmin
   if (preg_match("/([TF])(\d+)WA(\d+)/", $fname, $x)) {
   //   plan type-----^     MMs    ^--- plan duration in minutes
   //                       ^^^---actual start time (minutes since epoch)
   //   *plan types:{T=trial, F=forecast}
   //   *epoch=1.1.1970 00:00
      $actual_start_timestamp=$x[2]*60;
      $actual_end_timestamp=($x[2]+$x[3])*60;
      return array(
         'plan_type' => $x[0],
         'actual_date' => tws_date_from_iso(date("Y-m-d",$actual_start_timestamp)),
         'start_time' => date("H:i",$actual_start_timestamp),
         'actual_end_date' => tws_date_from_iso(date("Y-m-d",$actual_end_timestamp)),
         'end_time' => date("H:i",$actual_end_timestamp),
      );
   } else if (preg_match("/([M]).*/", $fname, $x)) {
      //archive symphonies (actual date+duration)
      return array(
         'plan_type' => $x[0],
      );
   } else if (preg_match("/([TF]).*/", $fname, $x)) {
      //trials and forecasts created not through webadmin
      return array(
         'plan_type' => $x[0],
      );
   }
   return FALSE;
}

/// compression_enabled returns true or false regarding to compression setting
function compression_enabled () {
   global $tws_config;

   if (file_exists($tws_config['webadmin_all_user_dir'].$tws_config['user_setting_dir'].'/nocompress')
       || isset($_SERVER['PHP_AUTH_USER']) && file_exists($tws_config['webadmin_user_home_dir'].'/'.$_SERVER['PHP_AUTH_USER'].$tws_config['user_setting_dir'].'/nocompress')
      ) {
      return FALSE;
   } else {
      return TRUE;
   }
}

/// place where resources can be automaticaly released at the end of a script
function tws_finalize() {
   global $composer_db, $webadmin_db;

   if (isset($composer_db) && (($composer_db['type']=='db2' && extension_loaded('ibm_db2')) || ($composer_db['type']=='oracle' && extension_loaded('oci8')))) @db_close($composer_db);
   if (isset($webadmin_db) && (($composer_db['type']=='db2' && extension_loaded('ibm_db2')) || ($composer_db['type']=='oracle' && extension_loaded('oci8')))) @db_close($webadmin_db);
   tws_log('FINALIZE','CLOSE');
}

/// refresh routine
function tws_twsconn_refresh() {
   global $tws_config;

// current timestamp
   $now_ts=@time();

   if (!isset($tws_config['localopts'])) {
      tws_get_localopts();
   }

// get master workstation name
   $master=isset($tws_config['localopts']['thiscpu']) ? $tws_config['localopts']['thiscpu'] : '@';

// refresh period
   if (($twsconn_refresh=isset($tws_config['twsconn_refresh']) ? $tws_config['twsconn_refresh'] : 300)==0) {
      // refreshing disabled
      return 0;
   }

// check if it is neccessary to do refresh
   if (!is_null($tws_config['last_twsconn_refresh']=tws_profile('last_twsconn_refresh')) &&
       ($now_ts - $tws_config['last_twsconn_refresh']) < $twsconn_refresh )
      return $tws_config['last_twsconn_refresh'];

// update the timestamp - should be here to avoid multiple executions of the following pings command
   tws_profile('last_twsconn_refresh',$now_ts);

// "ping" composer command
//   $command = "$tws_config[maestro_dir]/bin/composer \"list sched=$master#WEBADMIN\" 2>&1";
   $command=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), $tws_config['maestro_dir'].'/bin/composer', "list sched=$master#WEBADMIN", hwi_cmd::operator('2>&1', FALSE));
   $stdout=''; $ec=0;
   if (tws_popen($command, $ec, $stdout, $stdout)===FALSE || $ec!=0) {
      tws_error(array('stdout'=>$stdout, 'cmd'=>$command), "Composer connection refresh failed");
   }

// wait until the command processing finishes in database
   sleep(isset($tws_config['composer_waitsec']) ? $tws_config['composer_waitsec'] : 3);

   return $now_ts;
}


/// This function checks for the presence of zli_netmodlue module. Upon this
/// check function NetPlan buttons are displayed, Licence administration is
/// extended for another license key, etc...
function tws_zli_module_check () {
   global $tws_config;

// check for presence of <BASE_INST_DIR>/httpd/htdocs/zli_netmodlue directory
   return (file_exists($tws_config['base_inst_dir'].'/httpd/htdocs/zli_net_module'));
}

/**
 * Function return time stamp in sec.microsec.
 *
 * @return unknown
 */
function tws_getmicrotime() {
   list($usec, $sec) = explode(' ',microtime());
   return ((float)$usec + (float)$sec);
}

/**
 * Function return size of file (file name in parameter)
 *
 */
function tws_get_filesize($filename) {
   $filesize = @filesize($filename);
   if (is_bool($filesize) && ($filesize == false)) {
      return "unknown size";
   }
   else {
      $units = array("B", "kB", "MB", "GB");
      foreach($units as $unit) {
         if ($filesize < 1024) {
            return round($filesize, 2).$unit;
         } else {
            $filesize = (float)$filesize / 1024;
         }
      }
   }
}
/**
 * trace log function
 * In Procman hwi_config.php $hwi_config['log_level'][]=5;  set to trace
 * @param string $msg MessageFormatter
 * @param string $act action string OPEN, CLOSE, TO_STRING ...
 * @return boolean
 */
function tws_log($msg='', $act='') {
   static $tl=NULL;
   global $tws_config;
   static $flog=NULL, $log_filename='';

   if ($tl===NULL) $tl=tws_profile('enable_trace');

   if (defined('IWD_PROCMAN')) {
        global $hwi_config;
        if (in_array(5 /*TRACE*/, $hwi_config['log_level'])) {
            $tl = 'yes';
            $log_filename = session_id() . '.tlog';
            $flog = fopen($tws_config['webadmin_log_dir'] . '/' . $log_filename, 'a+');
        }
    }


   if ($tl!='yes') {
      return false;
   }

   if ($msg==='' && $act==='') { // trace logs enabled probe
      return true;
   }


   $laction =  strtoupper(trim($act));
   switch ($laction) {
      case 'OPEN' :
      case 'APPEND' :
         if ($msg!='') {
            $log_filename=trim($msg);
         } elseif (($sessid=session_id())) {
            $log_filename=$sessid.'.tlog';
         } else {
            $log_filename=time().'.'.rand(10000,99999).'.tlog';
         }
         if (!is_resource($flog)) {
             $fmode = array(
                    'OPEN' => 'w',
                    'APPEND' => 'a'
             );
             if (($flog=fopen($tws_config['webadmin_log_dir'].'/'.$log_filename,$fmode[$laction]/*'w'*/))==FALSE) {
               $log_filename='';
               return FALSE;
            }

         }
         return $log_filename;
      case 'CLOSE' :
         if (is_resource($flog)) {
            if ($msg!=='') tws_log($msg);
               fclose($flog);
         }
         $flog=NULL;
         break;
      case 'PRINT' :
         tws_log('','CLOSE');
         clearstatcache();
         $tmp_log_filename=(trim($msg)=='') ? $log_filename : $msg;
         if ($tmp_log_filename=='' || !file_exists($tws_config['webadmin_log_dir'].'/'.$tmp_log_filename)){
            tws_err("Unable to print log file: file name '".$tws_config['webadmin_log_dir'].'/'.$tmp_log_filename."' does not exist.");
         } else {
            if (($fp=fopen($tws_config['webadmin_log_dir'].'/'.$tmp_log_filename, 'r'))!==FALSE) {
               while (is_resource($fp) && !feof($fp) && ($buff=fgets($fp, 4096))!==FALSE) {
                  echo htmlspecialchars($buff);
               }
               fclose($fp);
            } else {
               tws_err("Unable to open trace log file '".$tws_config['webadmin_log_dir'].'/'.$tmp_log_filename."'.");
            }
         }
         break;
      case 'TO_STRING' :
         tws_log('', 'CLOSE');
         clearstatcache();
         $tmp_log_filename=(trim($msg)=='') ? $log_filename : $msg;
         if ($tmp_log_filename=='' || !file_exists($tws_config['webadmin_log_dir'].'/'.$tmp_log_filename)){
            return "Unable to read log file: file name '".$tws_config['webadmin_log_dir'].'/'.$tmp_log_filename."' does not exist.";
         } else {
            return htmlspecialchars(file_get_contents($tws_config['webadmin_log_dir'].'/'.$tmp_log_filename));
         }
         break;
      case 'GET' :
         tws_log('','CLOSE');
         clearstatcache();
         $tmp_log_filename=(trim($msg)=='') ? $log_filename : $msg;
         header("Content-type: text/plain");
         header("Accept-Ranges: bytes");
         header("Content-Length: ".filesize($tmp_log_filename));
         header("Content-Disposition: attachment; filename=\"$tmp_log_filename\"");
         if ($tmp_log_filename=='' || !file_exists($tmp_log_filename)){
            echo "Unable to get log file: file name '".$tws_config['webadmin_log_dir'].'/'.$tmp_log_filename."' does not exist.";
            return FALSE;
         } else {
            echo file_get_contents($tmp_log_filename);
            return TRUE;
         }
         break;
      default :
         if (is_resource($flog)) {
            if (is_array($msg)) $msg = implode(PHP_EOL, $msg);
            $msg=date("Y-m-d H:i:s")."  ".rtrim($msg)."\n";
            return fwrite($flog, $msg);
         }
         return FALSE;
   }
   return;
}

/**
 * Delete all files in specified directory which correspond specified pattern
 * and which are older (time of last modification in hours) than specified time.
 * @author martink ::.. 17-04-2008
 */
function tws_clear_dir($dir, $file_pattern, $age) {
   if (!isset($dir)) {
      global $tws_config;
      $dir = @$tws_config['maestro_dir'].'/webadmin/log';
   }
   if(($dp = @opendir($dir)) == false) {
      return;
   }
   (!isset($file_pattern)) && ($file_pattern = '*');
   $file_pattern = preg_replace('/\./', '\.', $file_pattern);
   $file_pattern = preg_replace('/\*/', '.*', $file_pattern);
   $file_pattern = preg_replace('/\?/', '.{1}', $file_pattern);
   $file_pattern = '/^'.$file_pattern.'$/';
   (!isset($age)) && ($age = 24);

   while (($file = readdir($dp)) !== false) {
      if (($file == '.') || ($file == '..')) {
         continue;
      } else if (
         (preg_match($file_pattern, $file)) &&
         (((float)(time() - filemtime($dir.'/'.$file))/3600) > $age)) {
         @unlink($dir.'/'.$file);
      }
    }
    closedir($dp);
}

function tws_sigint($val) {
   $int=intval($val);
   if ($int>0) return "+$int";
   return $int;
}

function tws_sqllike($s,$adflt='strtoupper') {
   static $ta=array('%'=>'/%', '_'=>'/_', '/'=>'//', '@'=>'%', '*'=>'%', '?'=>'_', "'"=>"''");   $tr=strtr(trim($s),$ta);
   return "LIKE '".($adflt=='' ? $tr : $adflt($tr))."' ESCAPE '/'";
}

// analogue of previous function for prepared statements
function tws_preplike($s,$adflt='strtoupper') {
   static $ta=array('%'=>'/%', '_'=>'/_', '/'=>'//', '@'=>'%', '*'=>'%', '?'=>'_', "'"=>"''");   $tr=strtr(trim($s),$ta);
   return ($adflt=='' ? $tr : $adflt($tr));
}

function tws_jokercmp($string, $mask, $case_sensitive=FALSE, $spec_wilds='tws') {
   static $in =array('\\'  , '.'  ,'^'  ,'$'  ,'{'  , '}' ,'('  ,  ')',  '[',  ']',  '+',  '*', '?',   ';',  '@');
   static $out=array('\\\\', '\\.','\\^','\\$','\\{','\\}','\\(','\\)','\\[','\\]','\\+', '.*', '.', '\\;', '.*');
   //conversion of masks to the PCRE format is time consuming action, therefore
   //the mask conversions are cached to avoid multiple conversions of the same mask

   switch ($spec_wilds) {
      case 'tws': default:
         static $cache_tws=array();
         @$rmask=$cache_tws[$mask];
         if (!isset($rmask)) {
            $rmask=str_replace($in,$out,$mask);
            $cache_tws[$mask]=$rmask;
         }
         break;
      case 'sql':
         //not optimal for mass usage, to be implemented analogously as the tws variant when needed
         $in_sql=$in;
         if (($i=array_search('@', $in_sql))===FALSE) $in_sql[]='%';
         else $in_sql[$i]='%';
         $rmask=str_replace($in_sql,$out,$mask);
         break;
   }

   return preg_match(';^'.$rmask.'$;'.($case_sensitive ? '' : 'i'), $string);
}

function tws_web_service($wsdl) {
   global $tws_config;

   if (isset($tws_config['tws_web_services']) && (is_array($tws_config['tws_web_services']) || tws_yesno($tws_config['tws_web_services'],TRUE,FALSE))) {

// check if the soap extension is loaded
      if (!extension_loaded('soap')) {
         tws_error('PHP Extensions loaded: '.implode(',',get_loaded_extensions()), 'WARNING: The \'tws_web_services\' option is ON, but the soap extension is not loaded permanently').
         $php_shlib_prefix = (PHP_SHLIB_SUFFIX === 'dll') ? 'php_' : '';
         /*
         if (($res=dl($php_shlib_prefix.'soap.'.PHP_SHLIB_SUFFIX))==FALSE) {
            tws_error($php_shlib_prefix.'soap.'.PHP_SHLIB_SUFFIX,'Unable to load PHP SOAP extension');
            tws_log('-- tws_web_service : Web Services Enabled, but PHP is unable to load the SOAP extension');
         }*/
         return FALSE;
      }

// check the conection parameter
      if (tws_profile('tws_authority_pw')===null) {
         tws_error('tws_authority='.tws_profile('tws_authority'), 'Unknown password of current IWS authority (incomplete IWS user mapping). Cannot initalize IWS WebService client.');
         return FALSE;
      }

// default/common web services setup
      tws_get_cpuinfo();
      if (isset($tws_config['tws_wsdl'])) $tws_wsdl=$tws_config['tws_wsdl'];
      else {
         $tws_wsdl=$tws_config['cpuinfo']['version']>='8.5' ? $tws_config['maestro_dir'].'/../'.'eWAS/profiles/twaprofile/config/cells/DefaultNode/applications/TWSEngineModel.ear/deployments/TWSEngineModel/PlanServicesWeb.war/WEB-INF/wsdl' : $tws_config['maestro_dir'].'/appserver/profiles/twsprofile/config/cells/DefaultNode/applications/TWSEngineModel.ear/deployments/TWSEngineModel/PlanServicesWeb.war/WEB-INF/wsdl';
      }
      $ws_port=isset($tws_config['tws_web_services_port']) ? $tws_config['tws_web_services_port'] : $tws_config['localopts']['port'];
      $tws_ws_parms = array (
         $wsdl.'_wsdl' => $tws_wsdl.'/'.$wsdl.'.wsdl',
         $wsdl.'_location' => 'https://localhost:'.$ws_port.'/PlanServicesWeb/services/'.$wsdl,
         'trace' => FALSE,
         'login' => tws_profile('tws_authority'),
         'password' => tws_decrypt(tws_profile('tws_authority_pw')),
      );

// add the user configuration
      if (is_array($tws_config['tws_web_services'])) {
         foreach($tws_config['tws_web_services'] as $key=>$val) $tws_ws_parms[$key]=$val;
      }

// create SOAP connection object to IWS web services
      $tws_ws_parms['location']=$tws_ws_parms[$wsdl.'_location'];
      try {
         $ws=new SoapClient($tws_ws_parms[$wsdl.'_wsdl'], $tws_ws_parms);
      } catch (Exception $e) {
         $tws_ws_parms['password']!='' && $tws_ws_parms['password']='*****';
         tws_error(array('parameters'=>$tws_ws_parms, 'exception'=>$e->__toString()), "Unable to initialize IWS web services SOAP client object (wsdl=$wsdl)");
         tws_log('-- tws_web_service : Unable to initialize IWS web services SOAP client object ('.$wsdl.'). More details in WebAdmin error log.');
         return FALSE;
      }
      tws_log('-- tws_web_service : IWS web services SOAP client object successfuly initalized ('.$wsdl.')');
      return $ws;
   }
   return FALSE;
}

function tws_audit($msg, $function='', $line='') {
   global $tws_config;

   isset($tws_config['webadmin_audit_log_file']) || $tws_config['webadmin_audit_log_file']=$tws_config['maestro_dir']."/webadmin/log/webadmin_audit.log";
   isset($tws_config['webadmin_audit_log_file_max_size']) || $tws_config['webadmin_audit_log_file_max_size']='5M';

   if ($tws_config['webadmin_audit_log_file_max_size']!=0 && $tws_config['webadmin_audit_log_file']!='') {
      $header=date('Y-m-d H:i:s').' USR='.tws_profile('auth_user_name').' TWSAUTH='.tws_profile('tws_authority').($function!=='' ? ' FN='.$function : '').($line!=='' ? ' LN='.$line : '');
      $body=trim(is_array($msg) ? "\n".preg_replace("/\n\s*\n/", "\n", print_r($msg, 1)) : $msg);

      @error_log($header.' : '.$body.PHP_EOL, 3, $tws_config['webadmin_audit_log_file']);

      // test on filesize, check if it is not over the limit
      tws_test_size_and_clear_file($tws_config['webadmin_audit_log_file'], $tws_config['webadmin_audit_log_file_max_size']);
   }
}

function tws_config_init() {
   global $tws_config;
   $tws_globals=array(
      'maestro_dir', 'maestro_user', 'host_os', 'virtual_hosts', 'kernel', 'base_inst_dir',
      'webadmin_backup_dir', 'webadmin_tmp_dir', 'webadmin_draft_dir', 'user_setting_dir', 'webadmin_user_home_dir', 'webadmin_all_user_dir',
      'note_types_file', 'severities_file', 'event_types_file', 'custom_severities_file', 'custom_events_file'
   );
   foreach ($tws_globals as $tws_global) {
      if (!isset($tws_config[$tws_global])) {
         if (!isset($GLOBALS[$tws_global])) {
            tws_error('--tws_config_init : Missing global variable $'.$tws_global.' declaration.');
         } else {
            $tws_config[$tws_global]=$GLOBALS[$tws_global];
         }
      }
   }
//optional or later-added globals
   if (empty($tws_config['hwf_root'])) $tws_config['hwf_root']=$tws_config['base_inst_dir'];
   if (!isset($tws_config['webadmin_log_dir'])) $tws_config['webadmin_log_dir']=$tws_config['maestro_dir'].'/webadmin/log';
   if (!isset($tws_config['dumpsec_user'])) $tws_config['dumpsec_user']=$tws_config['maestro_user'];
   if (!isset($tws_config['ajax_freq'])) $tws_config['ajax_freq']=60;
   if (!isset($tws_config['unlock_before'])) $tws_config['unlock_before']='YES';
   if (!isset($tws_config['jobhist_cleanup'])) $tws_config['jobhist_cleanup']='90';
   if (!isset($tws_config['events_cleanup'])) $tws_config['events_cleanup']='90';

//add/setup user specific configuration options
   if (($twsenv=tws_profile('twsenv')) && is_array($twsenv)) { //special IWS env variables of the current user (therefore stored in session), applied in tws_popen when executing IWS externals
      foreach ($twsenv as $key=>$val) $tws_config['twsenv'][$key]=$val;
   }
}

//note: used in event tracker => cannot cache the result!
function tws_get_enabled_events() {
   global $tws_config;
   $event_list_array=array();
   clearstatcache();
   if ($tws_config['cpuinfo']['version'] >= '9.5')
       $dir = $tws_config["twsenv"]["UNISONWORK"];
   else
       $dir = $tws_config['maestro_dir'];
   if (file_exists($dir.'/BmEvents.conf')) {
       $file=$dir.'/BmEvents.conf';
      if (($stdout = tws_get_filecontent($file, TRUE))===FALSE)
         return false;
      foreach ($stdout as $buffer) {
            if (!preg_match('/^\s*EVENTS\s*=\s*([0-9 ]*)/i', $buffer, $_r)) continue;
            $event_list_array=explode(' ',$_r[1]);
      }
      return $event_list_array;
   } else tws_error($dir."/BmEvents.conf file doesn't exists");
   return FALSE;
}

function tws_compare($in_left, $in_right, $mode = "TC", $multi = FALSE) {
   include_once "Text/Diff.php";
   include_once "Text/Diff/Renderer/unified.php";
   include_once "Text/Diff/Renderer/inline.php";
   include_once "Text/Diff/Renderer/context.php";

   if (class_exists("Text_Diff") === FALSE) {
      tws_error($stderr,"Missing PEAR Text_Diff Class");
      return FALSE;
   }

   $out = '';
   $diff = new Text_Diff('auto', array($in_left, $in_right));
   switch ($mode) {
      case ("TC") :
         $renderer = new Text_Diff_Renderer_unified();
         break;
      case ("INLINE") :
         $renderer = new Text_Diff_Renderer_inline();
         break;
      case ("CONTEXT") :
         $renderer = new Text_Diff_Renderer_context();
         break;
   }

   $render_result = $renderer->render($diff);
   if ($render_result == "") {
      $out="";
      foreach ($in_left as $str) {
         $out .= $str."<br>";
      }
      return $out;
   }
   if($mode == "INLINE") {
      return $render_result;
   }

   $left=array();
   $lrow=array();
   $right=array();
   $rrow=array();

   if($mode == "CONTEXT") {      // TODO if s-b want to use this mode - add here rows counters $lrow & $rrow as in TC mode :)
      $cur = &$left;
      $lines = explode("\n",$render_result);
      foreach ($lines as $str) {
         if (strpos($str, "***")=== 0 ) {
            $cur = &$left;
            continue;
         }
         if (strpos($str, "---")=== 0 ) {
            $cur = &$right;
            continue;
         }
         $cur[]=$str;
      }
      $count = max(count($left), count($right));

      $inc_arr = array(" ");
      for ($i=0; $i<$count; $i++) {
         $left[$i] = htmlspecialchars($left[$i]);
         $right[$i] = htmlspecialchars($right[$i]);
         if (strpos($left[$i], "+")===0) {
            $right = array_merge(
                       array_slice($right, 0, $i),
                       $inc_arr,
                       array_slice($right, $i)
                       );
            $left[$i] = "<ins>".substr($left[$i], 1)."</ins>";
         }
         if (strpos($right[$i], "+")===0) {
            $left = array_merge(
                       array_slice($left, 0, $i),
                       $inc_arr,
                       array_slice($left, $i)
                       );
            $right[$i] = "<del>".substr($right[$i], 1)."</del>";
         }
         if (strpos($left[$i], "-")===0) {
            $right = array_merge(
                       array_slice($right, 0, $i),
                       $inc_arr,
                       array_slice($right, $i)
                       );
            $left[$i] = "<del>".substr($left[$i], 1)."</del>";
         }
         if (strpos($right[$i], "-")===0) {
            $left = array_merge(
                       array_slice($left, 0, $i),
                       $inc_arr,
                       array_slice($left, $i)
                       );
            $right[$i] = "<del>".substr($right[$i], 1)."</del>";
         }
         if (strpos($left[$i], "!")===0) {
            $left[$i] = "<highlight>".substr($left[$i], 1)."</highlight>";
         }
         if (strpos($right[$i], "!")===0) {
            $right[$i] = "<highlight>".substr($right[$i], 1)."</highlight>";
         }
      }
   }

   if($mode == "TC") {
      $diffs = $diff->getDiff();

      foreach ($diffs as $edit) {
         if (is_a($edit, 'Text_Diff_Op_copy')) {
            foreach($edit->orig as $str) {
               $left[] = htmlspecialchars($str);
               $right[] = htmlspecialchars($str);
               $lrow[] = 1; $rrow[] = 1;
            }
         }
         elseif (is_a($edit, 'Text_Diff_Op_delete')) {
            foreach($edit->orig as $str) {
               $left[] = "<del>".htmlspecialchars($str)."</del>";
               $right[] = " ";
               $lrow[] = 1; $rrow[] = 0;
            }
         }
         elseif (is_a($edit, 'Text_Diff_Op_change')) {
            foreach($edit->orig as $str) {
               $left[] = '<span class="changed">'.htmlspecialchars($str).'</span>';
               $lrow[] = 1;
            }
            foreach($edit->final as $str) {
               $right[] = '<span class="changed">'.htmlspecialchars($str).'</span>';
               $rrow[] = 1;
            }
            if(count($edit->orig) > count($edit->final)) {
               $cnt = count($edit->orig) - count($edit->final);
               for($i=0; $i<$cnt; $i++) {
                  $right[] = " "; $rrow[] = 0;
               }
            }
            elseif (count($edit->orig) < count($edit->final)) {
               $cnt = count($edit->final) - count($edit->orig);
               for($i=0; $i<$cnt; $i++) {
                  $left[] = " "; $lrow[] = 0;
               }
            }
         }
         elseif (is_a($edit, 'Text_Diff_Op_add')) {
            foreach($edit->final as $str) {
               $left[] = " ";
               $right[] = "<ins>".htmlspecialchars($str)."</ins>";
               $lrow[] = 0; $rrow[] = 1;
            }
         }
      }
   }
   // format the results
   switch ($mode) {
      // like Total Commander comparator
      case ("CONTEXT") :
      case ("TC") :
         $rpos = $lpos = 0;
         $out .= "<table class=\"cmp\" style=\"border:none;\" cellspacing=0 cellpadding=4 width=\"100%\">\n";
         $out .= "<col width=\"1\">\n";
         $out .= "<col>\n";
         $out .= "<col>\n";
         $out .= "<col width=\"1\">\n";
         $out .= "<col>\n";
//   print header
         if ($multi) {
            $out .= "<tr>\n";
            foreach ($multi as $key => $value) {
               $out .= "<td style=\"border:none;\">&nbsp;</td>\n";
               $out .= "<td style=\"border-style: none none solid none;\">\n";
               $out .= "<table style=\"border:none;\" cellspacing=0 cellpadding=4 width=\"50%\">\n";
               foreach ($value as $name => $row) {
                  $out .= "<tr>\n";
                  $out .= "<td class=\"title\" style=\"text-align:left; border:none;\"><strong>$name:</strong></td>\n";
                  $out .= "<td class=\"title\" style=\"text-align:left; border:none;\">";
                  if (is_array($row)) {
                     foreach($row as $elrow) {
                        $out .= "$elrow\n";
                     }
                  }
                  else
                     $out .= $row;
                  $out .="</td>\n";
                  $out .= "</tr>\n";
               }
               $out .= "</table>\n";
               $out .= "</td>\n";
               if ($key == 0) {
                  $out .= "<td style=\"border:none;\">&nbsp;</td>\n";
               }
            }
            $out .= "</tr>\n";
         }

// print results
         $count = max(count($left), count($right));
         $lnum = 0;
         $rnum = 0;
         for ($i = 0; $i < $count; $i++) {
            if ($lrow[$i]) {$lnum ++; $slnum = $lnum;} else{$slnum = " ";}
            if ($rrow[$i]) {$rnum ++; $srnum = $rnum;} else{$srnum = " ";}
            $out .= "<tr>\n";
               $out .= "<td>$slnum</td>\n";
               $out .= '<td style="border-top:none;">'.$left[$i]."</td>\n";
            $out .= "<td style=\"background-color:transparent; border-top:none; border-bottom:none\">&nbsp;</td>\n";
               $out .= "<td>$srnum</td>\n";
               $out .= '<td style="border-top:none;">'.$right[$i]."</td>\n";
            $out .=  "</tr>\n";
         }
         $out .=  "</table>\n";
         break;

      // non formated output
   }
   return ($out);

}

function tws_escape_csv($string, $separator=",") {
   if (strpos($string,'"') !== FALSE) {
      $string='"' . str_replace('"','""',$string) . '"';
   } elseif (strpos($string,$separator) !== FALSE) {
      $string='"' . $string . '"';
   }
   return $string;
}

function tws_get_csv_separator(){
// in Europe csv separator is ';', in America is ','

   $csv_separator = ",";
   // Get timezone offset
   include_once "tws_tz.php";

   $tz=tws_profile('timezone');

   if (empty($tz))
      $tz=date_default_timezone_get();

   if(isset($tws_full_tz[$tz]) )
      $tz = $tws_full_tz[$tz];
   elseif(isset($tws_backward_tz[$tz]) )
      $tz = $tws_backward_tz[$tz];

   if(preg_match('/.*\(GMT([+-]\d+):\d+\)/', $tz, $offset) ){
      $offset = 0+$offset[1];
      if($offset>0 && $offset<7)
         $csv_separator = ";";
         // we are between London and China
   }
   return $csv_separator;
}
// $mask & $delimetr are for tws_check_arg() only
//
function tws_gpc_get($var, $mask=NULL, $delim=';') {
   if (is_string($var)) {
      $var=get_magic_quotes_gpc() ? stripslashes(trim($var)) : trim($var);
   } elseif (is_array($var)) {
      foreach ($var as $key=>&$val) {
         $val=tws_gpc_get($val, $mask);
      }
   }
   if(!empty($mask)) { // check datatype under mask
      tws_check_arg($var, $mask, $delim);
   }
   return $var;
}

function tws_fetch_filter_to_array($filter_txt, $filter_type='basic') {
   $filter_array=array();
   foreach (explode('+',$filter_txt) as $key=>$opt) {
      if ($key==0) {
         $pname='evrules';
         $pval=$opt;
      } else {
         list($pname,$pval)=explode('=',$opt);
      }
      if (isset($pname) && isset($pval)) {
         $pname=strtolower(trim($pname));
         $pval=explode(',',$pval);
         if (!is_array($pval)) $pval=array($pval);
         foreach($pval as &$val) $val=strtoupper(trim($val));
         $filter_array[$pname]=$pval;
      }
   }
   return $filter_array;
}

//Return group of given (or the currently logged in) user name
function tws_groupname ($username='') {
   global $tws_config;
   if ($username == '') { // current user
      if ( $groupname = tws_profile('auth_group_name') )  {
         return $groupname;
      }
      else {
         $username = tws_profile('auth_user_name');
         if (($groupname = tws_read_groupname ($username)) !== false) {
            tws_profile('auth_group_name', $groupname);
            return $groupname;
         }
      }
   }
   else {   // for certain user
      return tws_read_groupname ($username);
   }
   return '';
}

function tws_read_groupname ($username) {
   global $tws_config;
   $authgroups = $tws_config['base_inst_dir'].'/httpd/conf/authgroups';
   if (($fp=fopen($authgroups,"r")) === false) {
      tws_error($authgroups, "Can't open file '$authgroups'");
      return false;
   }
   while ($buffer=fgets($fp,4096)) {
      $groupname=strtok($buffer,":");
      $memberstr=trim(strtok(":"));
      $members=explode(" ",$memberstr);
      if ( !empty($members) && in_array ($username, $members) ) {
            fclose($fp);
            return $groupname;
      }
   }
   fclose($fp);
   // if have no apache group - take IWS User Section
   // don't take IWS User Section as it's slow with large data
   return '';
   //$groupname = array();
   //$groupname = tws_get_twssec_groups($username);
   //return $groupname[0];
}

//returns TRUE if $key action in $section is Permitted
function tws_permit_action ($section, $key) {
   require_once 'tws_lib_admin.php';

   if ( tws_profile('auth_user_group') == 'admin' ) return TRUE;

   $arr_permit = tws_get_actions($section);
   if( !isset($arr_permit) || empty($arr_permit) || !in_array($key, $arr_permit) )
      return FALSE;
   return TRUE;
}

// Access Denied (action button disabled)   //
function tws_access_denied () {
   tws_dyer('You are not authorized to perform the selected action.');
}


//
// DATABASE SECTION FILTERS functions
//

//   Make WHERE condition for single field selection from $dbfilter value
//
//   $dbfilter have format "+val1+val2~val3~val4"
//   return " ( NOT $dbfield_name LIKE val3 AND NOT $dbfield_name LIKE val4 AND ($dbfield_name LIKE val1 OR $dbfield_name LIKE val2) ) ";
//
//   Make WHERE condition for double field selection from $dbfilter value
//
//   $dbfilter have format "+cpu1#val1+cpu2#val2~cpu3#val3~cpu4#val4"
//   return " ( NOT ($dbfield_name1 LIKE cpu3 AND $dbfield_name2 LIKE val3) AND NOT ($dbfield_name1 LIKE cpu4 AND $dbfield_name2 LIKE val4)
//               AND ( ($dbfield_name1 LIKE cpu1 AND $dbfield_name2 LIKE val1) OR ($dbfield_name1 LIKE cpu2 AND $dbfield_name2 LIKE val2) )  ) ";
//

function tws_dbfilter_where ($dbfilter, $dbfield_name1, $dbfield_name2=NULL ) {
   global $tws_config;
   global $composer_db, $tws_config;
   tws_log("-- tws_dbfilter_where start. dbfilter = $dbfilter");
   tws_log("-- tws_dbfilter_where: dbfield_name1 = $dbfield_name1, dbfield_name2 = $dbfield_name2");

   $and = array();
   $xfilter = '';
   $schema = $composer_db['schema'];

   if($dbfilter == '' || $dbfilter == '@' || $dbfilter == '@#@') {
      return '1=1';
   }
   if (strpos($dbfilter, '[TMP]')) {
      $dbfilter = substr($dbfilter, 0, strpos($dbfilter, '[TMP]'));
   }
   if ( !preg_match_all('/[+~][^+~]+/',$dbfilter, $arr) ) {
      $arr[0][0] = '+'.$dbfilter;
   }

   if (is_null($dbfield_name2)) {   // single value
      tws_log("-- tws_dbfilter_where: dbfield_name2 is_null");
      foreach ($arr[0] as $val) {
         $op = substr($val,0,1);
         $val = substr($val,1);
         $val = strtr($val, '|', ',');
         $val_arr = explode(',', $val);
         $or = array();

         foreach($val_arr as $val) {
            list($folder, $val) = tws_divide_folder($val);
            if($op == '+') {
               if($dbfield_name1 == 'JOD_TASK_TYPE')
                  $or[] = "$dbfield_name1 " . tws_sqllike(db_string($composer_db, $val), '');
               else
                  $or[] = "$dbfield_name1 " . tws_sqllike(db_string($composer_db, $val));
            }
            else {
               if($dbfield_name1 == 'JOD_TASK_TYPE')
                  $and[] = "NOT $dbfield_name1 " . tws_sqllike(db_string($composer_db, $val), '');
               else
                  $and[] = "NOT $dbfield_name1 " . tws_sqllike(db_string($composer_db, $val));
            }
         }
         if($op == '+') {
            $and[] = ' ( '. implode(' OR ', $or) . ' ) ';
         }
         unset($or);
      }
   }
   else {                           // double value
      foreach ($arr[0] as $val) {
         $op = substr($val,0,1);
         $val = substr($val,1);
         if (strpos($val, '#') === false) {
            tws_error("--tws_dbfilter_formfields-- Wrong filter $filter format");
            return false;
         }
         $val_arr = explode(',', $val);
         $or = array();
         foreach($val_arr as $val) {
            list($val1, $val2) = explode('#', $val);

                // OBJ FOLDER
               if($tws_config['cpuinfo']['version']>='9.5' && $dbfield_name2 != 'RES_NAME'){      // straem/job
                  // explode name from folder
                  list($obj_folde, $val2) = tws_divide_folder($val2);
//                  if(empty($folder)) $folder = '/@';
               }

            // WS FOLDER
             if($tws_config['cpuinfo']['version']>='9.5002'){
                // stream, job, resource  - have WS folder
                // stream, job - have own folder too
// TODO:             if($dbfield_name2 == 'RES_NAME' || $dbfield_name2 != 'RES_NAME'
                  list($ws_folder, $val1) = tws_explode_folder($val1);
                 }

            if($op == '+') {
               $str =  '('.$dbfield_name1 .' '. tws_sqllike(db_string($composer_db, $val1)) . ' AND '. $dbfield_name2 .' '. tws_sqllike(db_string($composer_db, $val2)).$folder_expr;
               $str .=  ')';
               $or[] = $str;
            }
            else {
               $and[] = 'NOT ( '. $dbfield_name1 .' '. tws_sqllike(db_string($composer_db, $val1)) . ' AND '. $dbfield_name2 .' '. tws_sqllike(db_string($composer_db, $val2)) .$folder_expr.' )' ;
            }
         }
         if($op == '+') {
            $and[] = ' ( '. implode(' OR ', $or) . ' ) ';
         }
         unset($or);
      }
   }
   unset ($arr);

   $xfilter = implode(' AND ', $and);
   if ($xfilter != '') {$xfilter = '(' . $xfilter . ')';}
   return $xfilter;
}

// Set form fields arrays from $filter value
//
// $filter have format "+val1+val2~val3~val4"
// in this case $fields_arr2 must be NULL
//
// OR $filter have format "+cpu1#val1+cpu2#val2~cpu3#val3~cpu4#val4";
//
// $inc_fields_arr[] = 'eq'/'ne'
function tws_dbfilter_formfields($filter, &$fields_arr1, &$fields_arr2, &$inc_fields_arr, $delimeter='#') {
   $filter = strtr($filter,'*','@');
   if(is_null($fields_arr2)) {
      if ($filter == '' || $filter == '@') {
         $fields_arr1[0][0] = $filter;
         $inc_fields_arr[0] = 'eq';
         return true;
      }
      if (!preg_match_all('/[+~][^+~]+/',$filter, $arr) ) {
         $arr[0][0] = '+'.$filter;
      }
      $i=0;
      foreach ($arr[0] as $val) {
         $op = substr($val,0,1);
         $val = substr($val,1);
         $fields_arr1[$i] = explode(',', $val);
         if($op == '+') {
            $inc_fields_arr[$i] = 'eq';
         }
         else {
            $inc_fields_arr[$i] = 'ne';
         }
         $i++;
      }
      return true;
   }
   // else
   if($filter == '' || $filter == '@'.$delimeter.'@') {
      $fields_arr1[0][0] = '';
      $fields_arr2[0][0] = '';
      $inc_fields_arr[0] = 'eq';
      return true;
   }
   if (!preg_match_all('/[+~][^+~]+/',$filter, $arr) ) {
      $arr[0][0] = '+'.$filter;
   }
   $i=0;
   foreach ($arr[0] as $val) {
      $op = substr($val,0,1);
      $val = substr($val,1);
      $val_arr = explode(',',$val);
      foreach($val_arr as $val) {
         if (strpos($val, $delimeter) === false) {
            tws_error("--tws_dbfilter_formfields-- Wrong filter $filter format");
            return false;
         }
         list($val1, $val2) = explode($delimeter, $val);

         $fields_arr1[$i][] = $val1;
         $fields_arr2[$i][] = $val2;
      }
      if($op == '+') {
         $inc_fields_arr[$i] = 'eq';
      }
      else {
         $inc_fields_arr[$i] = 'ne';
      }
      $i++;
   }
   return true;
}

//   Make $filter value from the selected form fields
//
// $fieldname_inc_arr = 'eq'/'ne'
// return "+val1+val2~val3~val4"  OR
// return "+cpu1#val1+cpu2#val2~cpu3#val3~cpu4#val4" ;
function tws_dbfilter_value ($fieldname_arr1, $fieldname_arr2, $fieldname_inc_arr, $delimeter='#') {

   $filter="";

   if(is_null($fieldname_arr2)) {
      foreach ($fieldname_arr1 as $i => $fieldnames) {
         foreach ($fieldnames as $j=>$val) {
            $val = tws_gpc_get($val);
            $val = trim(strtr($val,'*','@'));
            if ($val == '' || $val == '@') {
               unset($fieldnames[$j]);
            }
            else $fieldnames[$j] = $val;
         }
         $fieldnames = array_values($fieldnames);
         if(count($fieldnames)) {
            $val = implode(',',$fieldnames);
            if($fieldname_inc_arr[$i] == 'eq') {$filter .= "+$val";}
            else {$filter .= "~$val";}
         }
      }
      if ($filter == "") { $filter = '@';}
      return $filter;
   }
   // else
   foreach ($fieldname_arr1 as $i => $fieldnames1) {
      $tmp = array();
      foreach ($fieldnames1 as $j => $val1) {
         $val1 = tws_gpc_get( $fieldname_arr1[$i][$j] );
         $val2 = tws_gpc_get( $fieldname_arr2[$i][$j] );
         $val1 = trim(strtr($val1,'*','@'));
         $val2 = trim(strtr($val2,'*','@'));
         if($val1 == '') {$val1 = '@';}
         if($val2 == '') {$val2 = '@';}
         if ( $val1 != '@' || $val2 != '@')  {
            $tmp[] = $val1.$delimeter.$val2;
         }
      }
      if(count($tmp)) {
         if($fieldname_inc_arr[$i] == 'eq') {$filter .= '+'.implode(',',$tmp);}
         else {$filter .= '~'.implode(',',$tmp);}
      }
   }
   if ($filter == "") { $filter = '@'.$delimeter.'@';}
   return $filter;
}

//
// PLAN SECTION FILTERS functions
//

// Analyze filter value
// return $arg for conman and $xfilter with additional conditions
// $filter have format +val1+val2~val3~val4[;keys][+key=keyvalue,]
//       or val1[;keys]  for older saved filters
function tws_planfilter_explode($filterval, $delimeter='') {
   $arg = $filterval;
   $xfilter = '';
   $inc = array();
   $exc = array();
   $keys = '';

// Keys
   if (strpos($filterval,';')) {
      $keys = substr($filterval, strpos($filterval,';'));
      $filterval = substr($filterval, 0, strpos($filterval,';'));
   }
   if ( preg_match('/[+][a-z]+=[^+]+/',$filterval, $matches, PREG_OFFSET_CAPTURE) ) {
      $keys .= substr($filterval, $matches[0][1]);
      $filterval = substr($filterval, 0, $matches[0][1]);
   }

//   TMP filter
   if (strpos($filterval,'[TMP]')) {
      $filterval = substr($filterval, 0, strpos($filterval,'[TMP]'));
   }

// explode the rest
   if ( preg_match_all('/[+~][^+~]+/',$filterval, $arr) ) {
      foreach ($arr[0] as $val) {
         $op = substr($val,0,1);
         $val = substr($val,1);
         $val = strtr($val, '|', ',');
         if($op == '+') {
            $inc[] = $val;
         }
         else {
            $exc[] = $val;
         }
      }
      if (count($inc) == 1 && strpos($inc[0],',')===false){
            $arg = $inc[0].$keys;
      }
      else {
         if ($delimeter == '') {
            $arg = '@'.$keys;
         }
         else {
            $arg = '@'.$delimeter.'@'.$keys;
         }
         foreach ($inc as $val) {
            $xfilter .= '+'.$val;
         }
      }
      foreach ($exc as $val) {
         $xfilter .= '~'.$val;
      }
   }
   $arr = array($arg, $xfilter);
   return ($arr);
}


//   Explode $filter value into $filter and $keys
// $filter have format  "+val1~val2+key1=keyval1+key2=keyval2" ;
function tws_planfilter_explode_keys ($filter) {
   $keys = '';

//   TMP filter
   if (($pos=strpos($filter,'[TMP]'))!==false ) {
      $filter = substr($filter, 0, $pos);
   }
/*
   if (strpos($filter,';')) {
      $keys = substr($filter, strpos($filter,';'));
      $filter = substr($filter, 0, strpos($filter,';'));
   }*/
   if ( preg_match('/[+~][a-z]+=[^+~]+/',$filter, $matches, PREG_OFFSET_CAPTURE) ) {
      $keys .= substr($filter, $matches[0][1]);
      $filter = substr($filter, 0, $matches[0][1]);
   }
   $arr = array($filter, $keys);
   return $arr;
}

// returns 0 or 1 - user/admin err_level. Show system information on error or not.
function tws_error_level() {
   if(session_id())
      return tws_rights('u');
   else return true;
}

function tws_import_request_variables($types, $prefix) {  //import_request_variables() REMOVED from PHP 5.4.0.
   $gpos = stripos($types, 'G');
   $ppos = stripos($types, 'P');

   if($gpos !== false && $ppos!== false){
      if($gpos>$ppos){  // PG
         foreach($_POST as $key=>$val)
            $GLOBALS[$prefix.$key] = $val;
         foreach($_GET as $key=>$val)
            $GLOBALS[$prefix.$key] = $val;
      }
      else{  // GP
         foreach($_GET as $key=>$val)
            $GLOBALS[$prefix.$key] = $val;
         foreach($_POST as $key=>$val)
            $GLOBALS[$prefix.$key] = $val;
      }
   }
   elseif ($gpos !== false ){    // G
      foreach($_GET as $key=>$val){
         $GLOBALS[$prefix.$key] = $val;
      }
   }
   elseif($ppos !== false ){     // P
      foreach($_POST as $key=>$val){
         $GLOBALS[$prefix.$key] = $val;
      }
   }
}

/* For Add Job Dialog
   Also used in composer module
*/
function tws_have_sap_method() {
   global $tws_config;

   if (($workstations = tws_get_workstations('@', " WKS_ACCESS_METHOD='r3batch'")) === FALSE){
      tws_warning('Unable to list workstations');
         return false;
   }
   elseif ($workstations['workstation_num']>0){
      return true;
   }
   elseif(tws_master_have_sap())
      return true;
   else
      return false;

}

function tws_master_have_sap() {
   global $tws_config;

   if ($tws_config['host_os'] == "win32" ) {
      if (file_exists($tws_config['maestro_dir']."/methods/r3batch.exe"))
         return true;
   }
   else {
      if (file_exists($tws_config['maestro_dir']."/methods/r3batch"))
         return true;
   }
   return false;
}
/*
// function instead of standard PHP 'list' function, because in PHP 7 it may be wrong
function tws_list($arr){

return $res;
}
*/
?>
