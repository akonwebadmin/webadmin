<?php
//   HORIZONT Software GmbH, Munich
//

/*
 * Function generate simply progress note.
 */
function tws_waiting($note, $path='') {
   switch ($note) {
      case '1':
         echo '<div id="hwa_overlay" class="ui-widget-overlay" style="z-index:1001; width:100%; height:100%;"></div>';
         $note = 'Loading page. Wait please.';
         echo '<div id="waiting"><img src="'.$path.'images/loading.gif" style="position:relative; top:1px; z-index:1002;" alt="Loading page. Wait please">&nbsp;'.$note."</div>\n";
         // if ($tws_config['host_os']=='win32') flush();
         tws_flush_output();
         break;
      case '0':
         echo "<script type='text/javascript'>
            if(typeof(jQuery)!='undefined'){
            $('#hwa_overlay').remove();
            $('#waiting').hide();\n";
         echo (intval(tws_profile('autorefresh'))>0 ? '}' : '$(window).focus();}')."\n";
         echo "</script>\n";
         break;
   }
}

function tws_display_info($filter, $b_symphony=TRUE) {
   if (!is_array($filter)) {
      $filter=array("Filter"=>$filter);
   }
   echo '<table style="background: transparent; text-align: left;">'."\n";
   $fn=0;
   foreach ($filter as $fname=>$fval) {
      $class = (++$fn == 1) ? 'blue' : 'purple';
      echo "<tr class=\"$class\">\n";
      echo "<td>".trim(htmlspecialchars($fname)).":</td>\n";
      if ($fval) {
         echo "<td>".ltrim(htmlspecialchars($fval))."</td>\n";
      } else {
         echo "<td>None</td>\n";
      }
      echo "</tr>\n";
   }
// symphony info - special filter
   if ($b_symphony) {
      if (tws_profile('symphony')) {
         $symdate=tws_profile('symdate');
         $symtype=tws_profile('symtype');
         if (strtoupper($symtype)=="ARCHIVED") $symtype="";
         else $symtype="<em>$symtype</em>";
         $class='green';
      } else {
         $symdate='Current';
         $class='blue';
      }
      echo "<tr class=\"$class\">\n";
      echo "<td>Symphony:</td>\n";
      echo "<td>".htmlspecialchars("$symtype $symdate")."</td>\n";
      echo "</tr>\n";
   }
   echo "</table>\n";
}

/// Display filter informatin paragraph.
/// The filter info is used on almost all webadmin pages.
/// Prints the formatted filter information to the output.
/// \param filter Filter
function tws_display_filterinfo($filter) {
   tws_display_info($filter, FALSE);
}

/// include menu.php
// return menu_item (0/1)
function tws_get_menu($item) {
   global $tws_config;
   $user_setting_dir = $tws_config['user_setting_dir'];

   $menu=tws_profile("menu");
   if ($menu !== null && is_array($menu)) {
      return isset($menu[$item]) ? $menu[$item] : 1; //if not configured, the all IWS/WebAdmin panels are available by default
   }
   $username = tws_profile('auth_user_name');
   $groupname = tws_profile('auth_user_group');

   $group_menu = $tws_config['webadmin_user_home_dir'].'/groups/'.$groupname.$user_setting_dir.'/menu.php';
   $user_menu = $tws_config['webadmin_user_home_dir'].'/'.$username.$user_setting_dir.'/menu.php';

   include($tws_config['base_inst_dir'].'/etc/menu.php');
   if (is_file($tws_config['webadmin_all_user_dir'].$tws_config['user_setting_dir'].'/menu.php')) {
      include($tws_config['webadmin_all_user_dir'].$tws_config['user_setting_dir'].'/menu.php');
   }
   if (is_file($group_menu)) {
      include($group_menu);
   }
   if (is_file($user_menu)) {
      include($user_menu);
   }

   //save individual menu variables into one structure for better handling
   $menu['Home'] = $Home;
   $menu['Options'] = $Options;
   $menu['Workstations'] = $Workstations;
   $menu['Domains'] = $Domains;
   $menu['Jobstreams'] = $Jobstreams;
   $menu['Jobs'] = $Jobs;
   $menu['Resources'] = $Resources;
   $menu['Prompts'] = $Prompts;
   $menu['Files'] = $Files;
   $menu['Plan_Filters'] = $Plan_Filters;
   $menu['Submit_Jobstream'] = $Submit_Jobstream;
   $menu['Submit_Job'] = $Submit_Job;
   $menu['Submit_Task'] = $Submit_Task;
   $menu['Set_Alternate_Plan'] = $Set_Alternate_Plan;
   $menu['Generate_New_Plan'] = $Generate_New_Plan;
   $menu['Workstations2'] = $Workstations2;
   $menu['Workstation_Classes'] = $Workstation_Classes;
   $menu['Domains2'] = $Domains2;
   $menu['Jobstreams2'] = $Jobstreams2;
   $menu['Calendars'] = $Calendars;
   $menu['Jobs2'] = $Jobs2;
   $menu['Resources2'] = $Resources2;
   $menu['Prompts2'] = $Prompts2;
   $menu['Parameters'] = $Parameters;
   $menu['Parameter_Tables'] = $Parameter_Tables;
   $menu['Local_Parms'] = $Local_Parms;
   $menu['Users'] = $Users;
   $menu['Event_Rules'] = $Event_Rules;
   $menu['Database_Filters'] = $Database_Filters;
   $menu['Saved_Drafts'] = $Saved_Drafts;
   $menu['Job_History'] = $Job_History;
   $menu['Job_Detail'] = $Job_Detail;
   $menu['TWS_Activity'] = $TWS_Activity;
   $menu['Production_Planning'] = $Production_Planning;
   $menu['Cross_Reference'] = $Cross_Reference;
   $menu['Critical_Jobs'] = $Critical_Jobs;
   $menu['SQL_Query'] = $SQL_Query;
   $menu['TWS_Database'] = $TWS_Database;
   $menu['User_Defined_Reports'] = $User_Defined_Reports;
   $menu['Stored_Reports'] = $Stored_Reports;
   $menu['Event_Monitor'] = $Event_Monitor;
   $menu['Database_Audit_Log'] = $Database_Audit_Log;
   $menu['Plan_Audit_Log'] = $Plan_Audit_Log;
   $menu['Notes'] = $Notes;
   $menu['Event_Rules_Monitor'] = $Event_Rules_Monitor;
   $menu['Actions_Monitor'] = $Actions_Monitor;
   $menu['Log_Messages_Monitor'] = $Log_Messages_Monitor;

   // admin have always all menu available
   if($groupname == 'admin')
      foreach($menu as $key=>$val)
         $menu[$key] = 1;

   tws_profile("menu",$menu);
   return isset($menu[$item]) ? $menu[$item] : 1; //if not configured, the all IWS/WebAdmin panels are available by default
}

/**
 * Function write DOCTYPE preambule. Now it supports three possible types for
 * HTML 4.01. Full list of possible DOCTYPE is at
 * http://www.w3.org/QA/2002/04/valid-dtd-list.html:
 * f (frame) | t (transitional) | s (strict). Default value is t.
 *
 * Martink 15-08-2007
 */
function tws_doctype($type = "t", $return = false) {
   switch ($type) {
      case 'f':
         $doctype = "<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Frameset//EN\" \"http://www.w3.org/TR/html4/frameset.dtd\">\n";
         break;
      case 's':
         $doctype = "<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">\n";
         break;
      case 't':
      default:
         $doctype = "<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n";
         break;
   }

   // deny frames from different domains (if not multi-master mode)
   $multi = tws_profile('mm_mode');
   if (empty($multi))
      header("X-Frame-Options: SAMEORIGIN");

   header("Content-type: text/html; charset=utf-8");

   if ($return)
      return $doctype;
   else
      echo $doctype;
}

/**
 * Writes html/head entry for styleshet(s)
 * @param bool $return Function returns string if true else print it
 * @param bool $no_javascript Parameter mainly for usage in frame with anchored
 * buttons; in IE has occured problem with content like <script ... - browser
 * hung; in addition, external javascript files are not needed
 * @param string $path
 * @return content of <head> ... </head> element
 * TODO: function name can confuse: concernes not only css stylesheets
 */
function tws_stylesheet($return = false, $no_javascript = false, $path = '/') {
   global $__keypress_handler, $tws_config, $tws_types, $ajax_table;

   $buff = '';
   $arg  = time();
   if ($no_javascript) { // for frames with buttons
      if (defined('IWD_PROCMAN')) {
         $buff .= '<script type="text/javascript" src="'.$path.'jquery/jquery.js"></script>'."\n";
      }
      else {
         $buff .= '<script type="text/javascript" src="'.$path.'jquery/js/jquery-1.11.0.min.js"></script>'."\n";
      }
      $buff .= "<script type='text/javascript' src='".$path."tws_js_functions.js?arg=$arg'></script>\n";
   }
   else {
      if (defined('IWD_PROCMAN')) {
         $buff .= '<script type="text/javascript"> var tws_dialog_type = "modal"; var tws_table_type = ""; </script>'."\n";
         $buff .= "<script type='text/javascript' src='".$path."tws_js_functions.js?arg=$arg'></script>\n";
      }
      else {
         $buff .= '<meta http-equiv="X-UA-Compatible" content="IE=Edge"/>';   // prevent IE from compatibility mode
         $buff .= tws_csssheet($return, $path);

         $buff .= '<link type="text/css" href="'.$path.'jquery/css/smoothness/jquery-ui-1.8.9.custom.css" rel="Stylesheet" >'."\n";
         $buff .= '<script type="text/javascript" src="'.$path.'jquery/js/jquery-1.11.0.min.js"></script>'."\n";
         $buff .= '<script type="text/javascript" src="'.$path.'jquery/js/jquery-ui-1.9.2.custom.min.js"></script>'."\n";
         $buff .= "<script type='text/javascript' src='".$path."tws_js_functions.js?arg=$arg'></script>\n";

         if (tws_profile('button_location') != 'bottom')
            $buff .= "<link rel='stylesheet' href='${path}action_menu.css' type='text/css'>\n";
         else $buff .= "<link rel='stylesheet' href='${path}action_menu_b.css' type='text/css'>\n";

         // DATATABLES
         if(tws_profile('table_type')=='flextable' && (strpos($_SERVER['SCRIPT_NAME'], 'x.php') || strpos($_SERVER['SCRIPT_NAME'], 'event_monitor.php') || strpos($_SERVER['SCRIPT_NAME'], 'audit_log.php')) ){
            $buff .= '<script type="text/javascript" src="'.$path.'DataTables-1.10.2/media/js/jquery.dataTables.min.js"></script>'."\n";
            $buff .= '<link type="text/css" rel="Stylesheet" href="'.$path.'DataTables-1.10.2/media/css/jquery.dataTables.css">'."\n";
            if(empty($ajax_table))
               $buff .= "<script type='text/javascript' src='".$path."tws_datatables.js?arg=$arg'></script>\n";
         }
         else $buff .= "<script type='text/javascript' src=\"${path}sorttable.js?arg=$arg\"></script>\n";
         if (isset($__keypress_handler) && $__keypress_handler===TRUE) {
           $buff .='<script type="text/javascript">'."\n";
           $buff .='  KeyEventFunction();'."\n";
           $buff .='</script>'."\n";
         }

         //css picker stuff (js init vars + js source code + css styles)
         $buff.='<script type="text/javascript">'."\n";
         $buff.='   var tws_path=\''.$path.'\';'."\n";
         $buff.='   var tws_dateformat_def=\''.tws_profile('date_format').'\';'."\n";
         $buff.='   var tws_tz_def=\''.tws_profile('timezone').'\';'."\n";

         if (is_array($tws_types['TIMEZONE']))
                 $tz_count = count($tws_types['TIMEZONE']);
         else
             $tz_count = 0;
         $buff.='   var tws_tz_keys=new Array('. $tz_count.');'."\n";
         $buff.='   var tws_tz_vals=new Array('. $tz_count.');'."\n";
         $i=0;

         if (!empty($tws_types['TIMEZONE'])){
             foreach ($tws_types['TIMEZONE'] as $key=>$val) {
                $buff.='   tws_tz_keys['.$i.']=\''.addcslashes($key,"'\\").'\';'."\n";
                $buff.='   tws_tz_vals['.$i.']=\''.addcslashes($val,"'\\").'\';'."\n";
                $i++;
             }
         }

         $buff.='</script>'."\n";

         // include js_filters if needed
         if (preg_match('/.*_filter.php$/', $_SERVER['SCRIPT_NAME']))
            $buff .= "<script type=\"text/javascript\" src=\"${path}tws_js_filters.js?arg=$arg\"></script>\n";

         // password strength
         $buff.='<script type="text/javascript">';
         if(isset($tws_config['password_strong']))
            $buff.='var tws_password_strong = "'.$tws_config['password_strong'].'";'."\n";
         else
            $buff.='var tws_password_strong = "off";'."\n";

         // standard/flexy tables
         if(tws_profile('table_type')=='flextable'){
            $buff.='var tws_table_type = "flextable";'."\n";
            $buff.='var tws_page_size = '.tws_get_page_size().";\n";
         }
         else
            $buff.='var tws_table_type = "standard";'."\n";

         // modal/popup dialogs
         if(tws_profile('dialog_type')=='modal')
            $buff.='var tws_dialog_type = "modal";'."\n";
         else
            $buff.='var tws_dialog_type = "popup";'."\n";
         // if https protocol
         if( isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']!='' && $_SERVER['HTTPS']!='off' )
            $buff.="var tws_https=1;\n";
         else
            $buff.="var tws_https=0;\n";

         // actions in popup windows

         if(tws_profile('action_refresh') == 'yes')
            $buff.="var action_refresh = true;\n";
         else {
            $buff.="var action_refresh = false;\n";
            if(tws_profile('action_popup_close') == 'yes')
               $buff.="var action_popup_close = true;\n";
            else
               $buff.="var action_popup_close = false;\n";
         }
         // button_location for submenus
         if (tws_profile('button_location') == 'bottom')
            $buff.="var button_location = 'bottom';\n";
         else $buff.="var button_location = 'top';\n";
         $buff.="</script>\n";

      }
   }

   if ($return)
      return $buff;
   else
      echo $buff;
}

function tws_adminstylesheet($return=FALSE, $javascript=FALSE, $path='../') {
   tws_stylesheet($return,$javascript,$path);
}

// navbar & topbar have only this part
function tws_csssheet($return = false, $path = '/') {
   $buff = '<meta name="author" content="HORIZONT IT; www.horizont-it.com" >'."\n";
   $buff.= '<meta name="copyright" content="HORIZONT IT; www.horizont-it.com" >'."\n";
   //$buff.= '<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" >'."\n";

   $buff.='<link href="'.$path.'default.css" rel="stylesheet" type="text/css">'."\n";
   $skin = tws_profile('skin') ? tws_profile('skin') : 'Default';
   $buff.= '<link rel="stylesheet" href="'.$path.'webadmin_'.$skin.'.css" type="text/css" >'."\n";

   if ($return)
      return $buff;
   else
      echo $buff;
}

function tws_selection_table($selection, $header='', $sep=';') {
   if (!is_array($selection)) $selection=array($selection);
   echo "\n<!-- selection table -->\n";
   echo "<table class=\"sel\">\n";
   if ($header) {
      echo "  <tr>\n";
      $tha=explode($sep,$header);
      foreach ($tha as $th) {
         echo "    <th>$th</th>\n";
      }
      echo "  </tr>";
   }
   for ($i=0; $i<count($selection); ++$i) {
      echo "  <tr>\n";
      $tda=is_array($tha) ? explode($sep,$selection[$i],count($tha)) : explode($sep,$selection[$i]);
      foreach ($tda as $td) {
         echo "    <td>".htmlspecialchars($td)."</td>\n";
      }
      echo "  </tr>\n";
   }
   echo "</table>\n\n";
}
function TWS_DISP_PLANJST_SEL($selection) {
   tws_check_arg($selection, "tws_name;tws_name;tws_datetime;tws_sched_id");
   tws_selection_table($selection, "Workstation;Jobstream;Sched Time;Sched ID");
}
function TWS_DISP_PLANJOB_SEL($selection) {
   tws_check_arg($selection, "tws_name;tws_name;tws_datetime;tws_sched_id;tws_name;tws_name;tws_num");
   tws_selection_table($selection, "Workstation;Jobstream;Sched Time;Sched ID;Job Workstation;Job;Job Num");
}
function TWS_DISP_PLANWKS_SEL($selection) {
   tws_check_arg($selection, "tws_name;tws_name");
   tws_selection_table($selection, "Workstation;Domain");
}
function TWS_DISP_PLANDOM_SEL($selection) {
   tws_check_arg($selection, "tws_name");
   tws_selection_table($selection, "Domain");
}
function TWS_DISP_PLANRES_SEL($selection) {
   tws_check_arg($selection, "tws_name;tws_name");
   tws_selection_table($selection, "Workstation;Resource");
}
function TWS_DISP_PLANPROMPT_SEL($selection) {
   tws_check_arg($selection, "tws_num;tws_any");
   tws_selection_table($selection, "Number;Prompt Name;Prompt Text");
   }
function TWS_DISP_PLANFILE_SEL($selection) {
   tws_check_arg($selection, "tws_name;tws_file");
   tws_selection_table($selection, "Workstation;File Name");
}

// validation of selection values
function tws_check_arg($selection, $mask, $sep=';') {
   if(empty($selection) || empty($mask))return true;
   $mask = strtolower($mask);
   if (!is_array($selection)) $selection=array($selection);
   else $selection = array_values($selection);

   $tha=explode($sep,$mask);
   for ($i=0; $i<count($selection); $i++) {
      if(is_array($selection[$i])) return tws_check_arg($selection[$i], $mask, $sep);
      $tda=is_array($tha) ? explode($sep,$selection[$i],count($tha)) : explode($sep,$selection[$i]);
      foreach ($tda as $key=>$td) {
         if(empty($tda[$key])) continue;
         switch($tha[$key]){
            case 'tws_name':
               $cond = '/^\/*[a-z\/]+[a-z0-9_\-#.\/]*$|^$/i';
               $expect='IWS name';
               break;
            case 'tws_num':
               $cond = '/^[+\-]?[0-9.]*$/';
               $expect='number';
               break;
            case 'tws_alfanum':
               $cond = '/^[a-z0-9_\-. @#\/]*$|^$/i';
               $expect='alphanumeric value';
               break;
            case 'tws_mask':
               $cond = '/^[a-z0-9_\-*@~?;%#,\/]*$/i';
               $expect='mask';
               break;
            case 'tws_datetime':
               $cond = '/^[0-9a-z\/\-: _]+$/i';
               $expect='date/time';
               break;
            case 'tws_sched_id':
               $cond = '/^[A-Z0-9_\-]*$/';   // _\- added to take tws_name instead of sched_id
               $expect='schedule id';
               break;
            case 'tws_file':
               $cond = '/^[a-z0-9_\-\/\\\\:. ~*?@%^]*$/i';
               $expect='filename';
               break;
            case 'tws_filter':
               $cond = '/^[a-z0-9_\-*^@?#!+~,.:;|=\[\]()&\/\\\\ "]*$/i';
               $expect='filter value';
               break;
            case 'tws_priority':
               $cond = '/^[0-9.]*|HI|GO|PRI$/';
               $expect='number';
               break;
            default: $cond='/.*/';
               $expect = '';
         }
         if(preg_match($cond, $tda[$key])==0){
            if (defined('IWD_PROCMAN')) {
            	tws_error('Unexpected format of data: "'.substr($tda[$key],0,256).'" Expected '. $expect);
            	return true;
         	}
            else
               tws_dyer('Unexpected format of data: '.substr($tda[$key],0,256). ' Expected '. $expect, 'REMOTE_ADDR=>'.$_SERVER['REMOTE_ADDR'].", PHP_AUTH_USER=>".$_SERVER['PHP_AUTH_USER']);
      	}
      }
   }
   return true;
}

function tws_autorefresh($refresh='') {
   if( !empty($refresh) )
      echo "<meta http-equiv=\"refresh\" content=\"$refresh\">\n";
}

// $t - object id name
// $default - means installation defaults (see etc/tws_rc.php)
function tws_set_layout($t, $default=FALSE) {
   global $tws_default_layout,$layout,$layout_column,$full_page, $tws_config;

   if ($default) {
      $layout=$tws_default_layout[$t];
   } else {
      if (!($layout=tws_profile($t."_layout")))
         if (!($layout=tws_profile("def_".$t."_layout")))
             $layout=$tws_default_layout[$t];
   }

   $layout_column=explode(":",$layout);
   if (substr($layout_column[0],0,1) == "*") {
      $full_page=FALSE;
      $layout_column[0]=substr($layout_column[0],1);
   } else {
      $full_page=TRUE;
   }
}

function tws_set_button_location() {
   global $button_location, $buttons, $target;
   $buttons = 'custom';
   $target = ' target="_parent"';
   if (!($button_location = tws_profile('button_location'))) {
      if(!($button_location = tws_profile('def_button_location'))){
         $buttons = 'default';
         $target = '';
      }
   }
}

/**
 * Function generate and print window title of page.
 *
 * martink ::.. last update 27-11-2007
 */
function tws_set_window_title($filter = '', $parent = true, $print = true) {
   global $tws_config;

   $filter = is_null($filter) ? ''   : $filter;
   $parent = is_null($parent) ? true : $parent;
   $print  = is_null($print) ?  true : $print;
   $title = tws_profile('window_title');
   if (is_null($title))
      $title = '';

   if ((is_string($title) || is_numeric($title)) && ((string)$title)) {
      if (strpos($title, '<U>')!==false) {
         $title = str_replace('<U>', $_SERVER['PHP_AUTH_USER'], $title);
      }

      if (strpos($title, '<W>')!==false || strpos($title, '<H>')!==false || strpos($title, '<V>')!==false || strpos($title, '<T>')!==false) {
         $cpuinfo = array();
         $cpuinfo = tws_get_cpuinfo();
      }

      if (strpos($title, '<W>')!==false) {
         $w = (isset($cpuinfo["host"])) ? $cpuinfo["host"] : '';
         $title = str_replace('<W>', $w, $title);
      }

      if (strpos($title, '<H>')!==false) {
         $h = (isset($cpuinfo["node"])) ? $cpuinfo["node"] : '';
         $title = str_replace('<H>', $h, $title);
      }

      if (strpos($title, '<V>')!==false) {
         $v = (isset($cpuinfo["version"])) ? $cpuinfo["version"] : '';
         $title = str_replace('<V>', $v, $title);
      }

      if (strpos($title, '<T>')!==false) {
         $t = (isset($cpuinfo["type"])) ? $cpuinfo["type"] : '';
         $title = str_replace('<T>', $t, $title);
      }

      if (strpos($title, '<BS>')!==false) {
         $bs = '??';
         $cmd=new hwi_cmd(tws_sudo('', $tws_config['maestro_user']), $tws_config['maestro_dir'].'/bin/conman', '-gui', 'status', hwi_cmd::operator('2>&1', FALSE));
         $stdout=array();
         if (tws_popen($cmd, $ec, $stdout, $stdout)===FALSE || $ec!=0) {
            tws_error(array("Command"=>$cmd->compile('log'), "stdout"=>$stdout), "Unable to get BATCHMAN status information");
         } else {
            foreach ($stdout as $buffer) {
               if (substr($buffer, 0, 2)!="^b") continue;
               if (strpos($buffer, "Batchman ") !== FALSE) {
                  $bs = substr($buffer, strpos($buffer, "Batchman ") + 9, 5);
                  if (($bs == "LIVES") || ($bs == "RULES")) {
                     $bs = 'running';
                  } else if ($bs == "down.") {
                     $bs = 'down';
                  }
               }
            }
         }
         $title = str_replace('<BS>', $bs, $title);
      }

      if (strpos($title, '<SD>')!==false) {
         if (($sd=tws_profile('symdate'))===null) $sd='current';
         $title = str_replace('<SD>', $sd, $title);
      }

      if (strpos($title, '<F>')!==false) {
         $title = str_replace('<F>', $filter, $title);
      }

      if (strpos($title, '<S>')!==false) {
         $title = str_replace('<S>', $_SERVER['SERVER_ADDR'].':'.$_SERVER['SERVER_PORT'], $title);
      }
   }

   $out_put =
      '   <script type="text/javascript">'."\n".
      '      changeWindowTitle("'.htmlspecialchars($title).'", '.($parent ? 'true' : 'false').');'."\n".
      '   </script>'."\n";

   if ($print)
      echo $out_put;
   else
      return $out_put;

   return;
}

function tws_print_check_clear_all($form) {
   echo '<p style="padding:0px; margin: 3px 0px;" id="check_clear_all"><a class="txtIcon" style="text-decoration: none;" href="javascript:CheckAll('.$form.');">Check All</a>&nbsp;-&nbsp;<a class="txtIcon" style="text-decoration: none;" href="Javascript:ClearAll('.$form.');">Clear All</a></p>'."\n";
}

function tws_print_navigation($count, $appendix = '') {
   if (tws_profile('table_type')=='flextable') return;

   //ERR17095 - Last table records hidden after action buttons bar => adding extra margin if buttons are at the bottom position
   static $first=TRUE;
   echo '<div class="navigation" '.(($first===FALSE && tws_profile('button_location')=='bottom') ? 'style="margin-bottom:50px"' : '').' >';
   if ($first===TRUE) $first=FALSE;

   if (($count < 1) || (($page_size = tws_get_page_size()) < 1) || tws_profile('table_type')=='flextable') {
      echo '</div>';
      return;
   }
   $page = isset($_GET['page']) ? $_GET['page'] : 1;
   if (is_float($page_count = $count/$page_size)) {
     $page_count = floor($page_count) + 1;
   }
   if ($page_count < 2) {
      echo '</div>';
      return;
   } else if ($page_count > 20) {
      $i = ($page - 10 > 0) ? $page - 10 : 1;
      $i = ($i + 19 < $page_count) ? $i : $page_count - 19;
      $i_max = $i + 19;
   } else {
      $i = 1;
      $i_max = $page_count;
   }
   $pars = '';
   foreach ($_GET as $key => $value) {
      ($key != 'page') && ($key != 'pagesize') && ($pars .= '&amp;'.$key.'='.urlencode($value));
   }
   $tmp = (($page > 1) ? ($page - 1) : '1');
   echo '<a class="txtIcon" href="?page=1'.$pars.'" title="first page :: 1 - '.$page_size.'">|&lt;</a><a class="txtIcon" href="?page='.$tmp.$pars.'" title="previous page :: '.(($tmp - 1)* $page_size + 1).' - '.($tmp * $page_size).'">&lt;</a>&nbsp;';
   if ($i > 1) {
      echo '...&nbsp;';
   }
   for ($i; $i <= $i_max; $i++) {
      echo '<a href="?page='.$i.$pars.'" title="page '.$i.' :: '.(($i - 1) * $page_size + 1).' - '.($i * $page_size).'">'.(($i == $page) ? '<strong>'.$i.'</strong>' : $i).'</a>&nbsp;';
   }
   if ($i_max < $page_count) {
      echo '...&nbsp;';
   }
   $tmp = $page + 1 < $page_count ? $page + 1 : $page_count;
   echo '<a class="txtIcon" href="?page='.$tmp.$pars.'" title="next page :: '.(($tmp - 1)* $page_size + 1).' - '.($tmp * $page_size).'">&gt;</a><a class="txtIcon" href="?page='.$page_count.$pars.'" title="last page :: '.(($page_count - 1) * $page_size + 1).' - '.($page_count * $page_size).'">&gt;|</a>';

   if (!tws_rights('t')) {
      echo '&nbsp;<a class="txtIcon" href="?pagesize=0'.$pars.'" title="display all">ALL</a>';
   }

   if (isset($appendix)) {
      echo '&nbsp;'.$appendix;
   }
   echo '</div>';
}

/**
 * Function print statistics of execution in Plan and Database section.
 */
function tws_print_stat($execution_time = '0', $log_file_name = '', $round = 3) {
   global $tws_config;
   $maestro_dir = $tws_config['maestro_dir'];

   $enable_trace = (tws_profile('enable_trace') == 'yes') ? 'yes' : 'no';
   echo '   <table style="background: transparent; margin: auto;">'."\n";
   if ($execution_time >= 0) {
      echo '      <tr><td style="text-align: left;">execution time</td><td>:</td><td style="text-align: left;">'.round($execution_time, $round).'s</td></tr>'."\n";
   }

   if ($enable_trace == 'no') {
      echo '      <tr><td colspan="3" style="text-align: left;"><a href="javascript:%20void%20window.alert(\'Trace%20logs%20are%20disabled%20now.%20You%20can%20enable%20IWS/WebAdmin%20trace%20logs%20in%20Options.\');">Trace logs are disabled.</a></td></tr>'."\n";
   }
   else if ($log_file_name) {
      $filesize = tws_get_filesize($maestro_dir.'/webadmin/log/'.$log_file_name);
      echo '      <tr>
                  <td colspan="3" style="text-align: left; height: 20px;">
                  <a href="javascript:%20void%20window.open(\'tws_display_log_file.php?file='.$log_file_name.'\',\'\',\'toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=yes\');"><img src="images/icons/trace_log.gif" style="border: none;" alt="trace log file" title="display trace log file ('.$filesize.')"/></a>
                  <a href="tws_get_compressed_file.php?mode=zip&amp;file='.$log_file_name.'"><img src="images/icons/trace_log_download_zip.gif" style="border: none;" alt="zip format" title="get trace log file in zip format"/></a>
                  <a href="tws_get_compressed_file.php?mode=gzip&amp;file='.$log_file_name.'"><img src="images/icons/trace_log_download_gzip.gif" style="border: none;" alt="gzip format" title="get trace log file in gzip format"/></a></td></tr>'."\n";
   }
   echo '   </table>'."\n";
}

/**
 * Function prints head of main data page - title and other information in one
 * row.
 */
function tws_print_head($title, $informations = array(), $path='') {
   static $head_cnt=0;
   $head_id=(++$head_cnt==1) ? '' : '_'.$head_cnt;

   if (!is_array($informations)) {
      $informations = (is_string($informations) && ($informations != '')) ? array('__help__' => $informations) : array();
   }
   if (!empty($informations['__html_header__'])) {
      tws_doctype('t');
      echo "<html>\n<head>\n<title>".htmlspecialchars($title)."</title>\n";
      tws_stylesheet(FALSE,FALSE,$path);
      echo "</head>\n<body>\n";
      tws_set_window_title($informations['__filter__'], $informations['__parent__']);
   }
   if (!defined('IWD_PROCMAN') && $head_cnt<=1) session_activity::session_activity_checker(new tws_page($title));

   $dfs = (array_key_exists('__filter__', $informations) || array_key_exists('__symphony__', $informations)) ? true : false;
   $dhi = (!empty($_COOKIE['wa3_dhi'])) ? true : false;


   echo '<table id="__head'.$head_id.'__" class="info" cellspacing="0" cellpadding="0">'."\n";
   echo '<colgroup><col width="*"><col width="5px"><col width="*"><col width="5px"><col width="16px"></colgroup>'."\n";
   echo '<tr><td style="vertical-align:top; min-width:300px;"><h1>'.htmlspecialchars($title).'</h1>'."\n";
   if (array_key_exists('__addition__', $informations)) {
      echo $informations['__addition__'];
   }
   if (array_key_exists('__navigation__', $informations)) {
      tws_print_navigation($informations['__navigation__'][0], $informations['__navigation__'][1]);
   }
   echo '</td>';
   if ($dfs) {
      if ($dhi) {
         echo '<td>&nbsp;</td><td id="__fs_info_td'.$head_id.'__" class=""><div id="__fs_info_div'.$head_id.'__" style="display:none; text-align:left">'."\n";
      } else {
         echo '<td>&nbsp;</td><td id="__fs_info_td'.$head_id.'__" class="info"><div id="__fs_info_div'.$head_id.'__" style="display:block; text-align:left; float:left;">'."\n";
      }
      if (array_key_exists('__filter__', $informations)) {
         if (!is_array($informations['__filter__'])) {
            $informations['__filter__'] = array('filter' => $informations['__filter__']);
         }
         echo '<table style="background:transparent; text-align:left">'."\n";
         foreach ($informations['__filter__'] as $fname=>$fval) {
            $class = (tws_profile('symphony') ? 'purple' : 'blue');
            echo "<tr class='$class'>";
            echo '<td>'.trim($fname).':</td>';
            $fval = ($fval ? htmlspecialchars(substr($fval,0,256)) : 'none');
            echo "<td colspan='2' style='word-wrap:break-word; word-break:break-all; white-space:pre-wrap;'>";
            if (!empty($informations['__filter_name__'])) {
               echo substr($informations['__filter_name__'],0,256);
            }
            else echo $fval;
            echo "</td></tr>\n";
         }
      }

      if (array_key_exists('__symphony__', $informations)) {
         if (tws_profile('symphony')) {
            $symdate = tws_profile('symdate');
            $symtype = tws_profile('symtype');
            $symtype = preg_match('/^ARCHIVED$/i', $symtype) ? '' : '<em>'.$symtype.'</em>';
            $class = 'green';
         } else {
            $symdate = 'current';
            $class = 'blue';
            $symtype='';
         }
         $informations['__symphony__'] = ltrim($symtype.' '.$symdate);
         echo '<tr class="'.$class.'"><td>symphony:</td><td>'.$informations['__symphony__'].'</td><td>'."\n";
         if (array_key_exists('__count__', $informations))
            echo "&nbsp;&nbsp;&nbsp; returned rows: <span class='count'>".$informations['__count__']."</span>";
         echo'</td></tr>'."\n";
      }
      elseif(array_key_exists('__count__', $informations))
         echo "<tr class='blue'><td>returned rows: <span class='count'>".$informations['__count__']."</span></td></tr>\n";;

      echo '</table>'."\n";
      echo '</div>'."\n";
      // autorefresh countdown
      if(tws_profile('autorefresh') && $head_cnt>1){
         echo '<div style="display:inline; float:right; text-align:center;">
            <div id="autorefresh_countdown"></div>'."\n";
            echo '<img id="autorefresh_pause" src="'.$path.'images/icons/stop.ico" style="cursor: pointer; _padding-right:10px" onclick="clearInterval(timer);" alt="pause" title="Stop Autorefresh">'."\n";
            echo '</div>'."\n";
         echo '<script type="text/javascript"> init_autorefresh_countdown('.tws_profile('autorefresh').');</script>'."\n";
      }
      elseif(tws_profile('action_refresh')!= 'yes' && $head_cnt>1)
         echo "<script type='text/javascript'> $(document).ready(function(){ init_refresh_countdown();});</script>\n";
      echo '</td>'."\n";
   }
   echo '<td>&nbsp;</td><td style="vertical-align: top;">'."\n";
   if (array_key_exists('__help__', $informations)) {
      echo '<img src="'.$path.'images/icons/bar_help.gif" style="cursor:pointer; _padding-right:10px" onclick="window.open(\''.$informations['__help__'].'\', \'\', \'height=400,width=600,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=yes\');" title="Open Help" alt="help">'."\n";
      unset($informations['__help__']);
   }
   if ($dhi) {
      echo '<img id="info_toggle'.$head_id.'" src="'.$path.'images/icons/bar_minus.gif" style="cursor: pointer; _padding-right:10px" onclick="onOffInformation(this);" alt="minus" title="Hide Summary Information"></td>'."\n";
   } else {
        echo '<img id="info_toggle'.$head_id.'" src="'.$path.'images/icons/bar_plus.gif" style="cursor: pointer; _padding-right:10px" onclick="onOffInformation(this);" alt="plus" title="Show Summary Information"></td>'."\n";
   }
   echo '</tr></table><!-- end of table#__head'.$head_id.'__ -->'."\n";

   echo '<div id="__detail_info'.$head_id.'__" style="width:100%; display:'.($dhi ? 'block' : 'none').';">'."\n";
   echo '<table class="info"><colgroup span="1"><tr><td class="info" style="text-align: left;">'."\n";
   echo '<table style="background: transparent;">'."\n";
   echo '<colgroup><col width="1"><col width="20"><col width="0"></colgroup>'."\n";
   foreach($informations as $key => $value) {
      $print = true;
      switch($key) {
         case '__time__':
            $key = 'execution time';
            $value = round($value, 3).'s';
            break;
         case '__log__':
            $key = 'trace log file';
            $log_file_name = $value;
            if (tws_profile('enable_trace') == 'yes') {
               global $tws_config;
               $filesize = tws_get_filesize($tws_config['maestro_dir'].'/webadmin/log/'.$log_file_name);
               $value =
                  '<a href="javascript:%20void%20window.open(\'tws_display_log_file.php?file='.$log_file_name.'\',\'\',\'toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=yes\');"><img src="images/icons/trace_log.gif" style="border: none;" alt="trace log file" title="display trace log file ('.$filesize.')"/></a>
                  <a href="tws_get_compressed_file.php?mode=zip&amp;file='.$log_file_name.'"><img src="images/icons/trace_log_download_gzip.gif" style="border: none;" alt="zip format" title="get trace log file in zip format"/></a>'."\n";
                  // gzip removed: <a href="tws_get_compressed_file.php?mode=gzip&amp;file='.$log_file_name.'"><img src="images/icons/trace_log_download_gzip.gif" style="border: none;" alt="gzip format" title="get trace log file in gzip format"/></a>
            } else {
               $value = '<a href="javascript:%20void%20window.alert(\'Trace%20logs%20are%20disabled%20now.%20You%20can%20enable%20IWS/WebAdmin%20trace%20logs%20in%20Options.\');">Trace logs are disabled.</a>'."\n";
            }
            break;
         case '__filter__':
            foreach ($informations['__filter__'] as $fkey => $fvalue) {
               echo '<tr><td style="font-weight: bold;">'.preg_replace('/ /', '&nbsp;', $fkey).'</td><td style="text-align: center;">:</td><td>'.htmlspecialchars(substr($fvalue,0,256)).'</td></tr>'."\n";
            }
            $print = false;
            break;
         case '__symphony__':
            $key = 'symphony';
            break;
         case '__count__':
            $key = 'returned rows';
            $value = "<span class='count'>$value</span>";
            break;
         case '__navigation__':
            if (($page_size = tws_get_page_size()) < 1) {
               $print = false;
               break;
            }
            if (is_float($page_count = $informations['__navigation__'][0]/$page_size)) {
               $page_count = floor($page_count) + 1;
            }
            if ($page_count < 2) {
               $print = false;
               break;
            }
            $page = isset($_GET['page']) ? $_GET['page'] : 1;
            $key = 'displayed rows';
            $tmp1 = ($page - 1) * $page_size + 1;
            $tmp2 = $page * $page_size;
            $tmp2 = $tmp2 < $informations['__navigation__'][0] ? $tmp2 : $informations['__navigation__'][0];
            $value = ($tmp2 - $tmp1 + 1).' | '.$tmp1.' - '.$tmp2.' | page '.htmlspecialchars($page).' of '.$page_count;
            break;
         case '__html_header__' : case '__parent__' : case '__addition__' :
            $print=false;

         default:
            $print=false;
            break;
      }
      if ($print) {
         echo '<tr><td style="font-weight: bold;">'.preg_replace('/ /', '&nbsp;', $key).'</td><td style="text-align: center;">:</td><td>'.$value.'</td></tr>'."\n";
      }
   }
   echo '<tr><td style="font-weight: bold;">license</td><td style="text-align: center;">:</td><td>'."\n";
   tws_license_check();
   echo '</td></tr></table></td></tr></table></div><!-- end of div#__detail_info'.$head_id.'__ -->'."\n";

   if ($head_cnt>1) {
      //replace old header by the new one
      ?>
      <script type="text/javascript">
         replaceHeader('<?=$head_id?>');
      </script>
      <?
   }
   else
      echo '<div id="picker_holder"> </div>'."\n";
}

function tws_print_foot() {
   echo "</body>\n</html>";
}

/**
 * Function generates string as (X)HTML code with hidden inputs.
 *
 * @param mix $variable
 */
function tws_create_hidden_inputs($value, $name = '', $valfilter='default') {
   $retval = '';
   if (is_array($value)) {
      foreach($value as $key => $val) {
         $retval .= tws_create_hidden_inputs($val, ($name ? $name.'['.$key.']' : $key), $valfilter);
      }
   } else if ($name) {
      if ($valfilter=='default') $value=tws_gpc_get($value);
      elseif ($valfilter==null) ;
      else $value=$valfilter($value);
      $retval = '<input type="hidden" name="'.htmlspecialchars($name).'" value="'.htmlspecialchars($value).'" />'."\n";
   }
   return $retval;
}

/**
 * Function translate column header to another (shorter) string
 */
function tws_html_column_header($header) {
   global $tws_layout_aliases;
   if (array_key_exists($header, $tws_layout_aliases)) {
      return $tws_layout_aliases[$header];
   }
   return $header;
}

function tws_print_timezone_options($tz, $return=FALSE) {
   global $tws_types;
   $s='';
   foreach ($tws_types['TIMEZONE'] as $key=>$val) {
      if ($val=='') $val="&nbsp;";
      $s.="  <option value=\"$key\"".($tz==$key ? " selected" : "").">$val</option>\n";
   }
   if (trim($tz) != '' && !array_key_exists($tz, $tws_types['TIMEZONE']) ){
      include('tws_tz.php');
      if(array_key_exists($tz, $tws_full_tz)) {
         $val = $tws_full_tz[$tz];
         $s.="  <option value=\"$tz\" selected>$val</option>\n";
      }
      else $s.="  <option value=\"$tz\" selected>$tz</option>\n";
   }
   if ($return) return $s;
   echo $s;
}

function tws_datetime_picker($input_id, $input_val, $input_name='', $path='', $attrs="'dropdown',true,'24',true,false,false,true") {
//                                                                                     scroller  show time hide rela- date  tz
//                                                                                               time fmt  sec  tives opt
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
// show time may be one of: true,false,'only'
// if $attrs == null - disable field and picker
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   if ($input_name=='') $input_name=$input_id;
   if (!is_null($attrs)) {
      $disabled='';
      $attra=explode(',',$attrs);
      $format_help=tws_user_date_format('');
      if ($attra[5]=='true') {
         $format_help='['.$format_help.']';
      }
      if ($attra[1]=='true') {
         $format_help.=' HH:mm';
      }
   } else {
      $disabled=' readonly="true"';
   }

   $input='<input type="text" id="'.$input_id.'" maxlength="40" size="25" name="'.$input_name.'" class="tws_date" value="'.htmlspecialchars($input_val).'" '.$disabled.'/>';
   if (!is_null($attrs)) {
      $input.='<a name="'.$input_name.'" class="picker" href="javascript:NewCssCal(\''.$input_id.'\',\''.tws_user_date_format('').'\','.$attrs.');">';
      $input.='<img name="'.$input_name.'" id="'.$input_id.'_img" src="'.$path.'images/cal.gif" width="16" height="16" alt="Pick a date" title="Date & Time picker ['.$format_help.']"/></a>';
   }
   return $input;
}

function tws_show_backup($return = FALSE, $path="/admin/") {
   $buff =  "<script type=\"text/javascript\">\n";
   $buff .= "   function showBackup(file) {\n";
   $buff .= "      var url = '".$path."tws_display_backup.php?file=' + escape(file);\n";
   $buff .= "      window.open(url, '', 'toolbar=no, menubar=no, location=no, scrollbars=yes, resizable=yes');\n";
   $buff .= "   }\n";
   $buff .= "</script>\n";

   if ($return) {
      return $buff;
   } else {
      echo $buff;
   }
}

function tws_js_htmlspecialchars($var) {
   return addcslashes(htmlspecialchars($var),"'\\");
}

// prints massages "No objects selected" or "Multiple objects selected"
function tws_check_selection($action, $selection) {
   $num_elements = is_array($selection) ? count($selection) : 0;

   if ($action != 'Add' && $action != 'Filter' && $action != 'Save Filter' && $action != 'Layout' && $action != 'Saved Drafts' && $action != 'Text Edit') {
      if (($num_elements == 0) ) {
         tws_doctype("t");
         echo "<html><body><head>".tws_stylesheet()."</head>";
         tws_warning("No objects selected!");
         tws_dyer ();
      }
   }
   if ($action == 'Modify' || $action == 'Rename' || $action == 'Copy' || $action == 'Submit Job' || $action == 'Submit Jobstream' || $action == 'Switch Manager' ) {
       if ($num_elements > 1) {
         tws_doctype("t");
         echo "<html><body><head>".tws_stylesheet()."</head>";
         tws_warning("Multiple objects selected. Can not be executed for more than one object at the same time.");
         tws_dyer ();
      }
   }
}

// provide validation of request via a Synchronizer Token Pattern
function tws_print_synchro_token() {
   global $tws_config;
   if(isset($tws_config['csrf_token']) && tws_yesno($tws_config['csrf_token']) == 'NO')
      return true;

   $path = '';
   if( strpos($_SERVER['PHP_SELF'], '/admin/')!== false)
      $path="../";

   echo "<input type='hidden' name='synchro_token' id='synchro_token' value=''>\n";

tws_waiting(1, $path);
echo "
<script type='text/javascript'>
$(document).ready(function(){
   var formaction = $('#synchro_token').closest('form').attr('action');
   if (formaction == ''){ // current file
      formaction = this.URL;
      formaction  = formaction.substring(formaction.lastIndexOf('/')+1);
   }
   var d = new Date();
   var t = Math.round(d.getTime()/1000);
   formaction = 'form='+formaction+'&time='+t;
   var scriptname = '$path'+'tws_print_synchro_token.php';

   $.ajax({
      type: 'POST',
      data: formaction,
      url: scriptname,
      success: function(result) {
            $('input#synchro_token').val(result);
            $('div#hwa_overlay').remove();
            $('div#waiting').hide();
           },
      error: function(jqXHR, Status, errorThrown ) {
          alert('ajax ' +Status+ ': ' +errorThrown+'. url: '+scriptname);
         },
      dataType: 'html'
   });
});
//window.onunload = function(){};
</script>";
   // Firefox 1.5
   // After travelling back in Firefox history, javascript won't run
   // that's why we need window.onunload = function(){};
   // http://stackoverflow.com/questions/2638292/after-travelling-back-in-firefox-history-javascript-wont-run
}

// provide validation of request via a Synchronizer Token Pattern
function tws_check_synchro_token() {
   global $tws_config;
   if(isset($tws_config['csrf_token']) && tws_yesno($tws_config['csrf_token']) == 'NO')
      return true;

   if(empty($_POST['synchro_token']) )
      tws_dyer('Security error: Request from invalid source. Empty csrf_token', 'REMOTE_ADDR=>'.$_SERVER['REMOTE_ADDR'].", PHP_AUTH_USER=>".$_SERVER['PHP_AUTH_USER']);

   $token = tws_profile('synchro_token');
   foreach($token as $val=>$arr){
      if( "$_POST[synchro_token]" == "$val" ){
         unset($token[$val]);
         tws_profile('synchro_token', $token);
         if(strpos($_SERVER['PHP_SELF'], "/".$arr['form'])!==false){
            if(time() - $arr['time'] < 1800) // expired after half hour
               return true;
            tws_warning('Security error: Request token expired, send request again');
            echo "<input type='button' value='Back' onclick='history.back();'>";
            die();
         }
      }
   }
   tws_dyer('Security error: Request from invalid source.', 'received csrf_token: '. $_POST['synchro_token']. ' REMOTE_ADDR=>'.$_SERVER['REMOTE_ADDR'].", PHP_AUTH_USER=>".$_SERVER['PHP_AUTH_USER']);
}

function tws_nossl_warning() {
   global $tws_config;

   if (!isset($tws_config['nossl_msg'])) $tws_config['nossl_msg']='Warning: This connection is not encrypted and so is not secure. Confidential data could be at risk and could be stolen or corrupted.';

   if ($tws_config['nossl_msg']!='' && (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS']=='off')) {
      echo '<p style="font-weight: bold;  border-width: 1px; border-left-width: 5px; border-style: solid; padding: 10px; background-color:#fffeef; font-family: Verdana, Geneva, Arial, Helvetica, sans-serif; font-size: 10pt; color:red; margin-bottom:20px">'.htmlspecialchars($tws_config['nossl_msg']).'</p>'."\n";
      return TRUE;
   }
   return FALSE;
}

//ERR17372 - Input Text Manipulation: Character Set
function tws_input_charset_validation() {
   if (function_exists('mb_http_input') && (!empty($_GET) || !empty($_POST)) && is_array($i_enc=mb_http_input('I'))) {
      foreach ($i_enc as $enc) {
         $enc=strtoupper($enc);
         if ($enc!='UTF-8' && $enc!='PASS') {
            tws_dyer('Unexpected input data encoding: '.$enc);
         }
      }
   }
}


class tws_page {
   private $title;
   private $timeout;
   public function __construct($title, $timeout=NULL) {
      global $tws_config;
      $this->title=$title;
      $this->timeout=($timeout===NULL ? (isset($tws_config['session_maxlifetime']) ? $tws_config['session_maxlifetime'] : 7200) : $timepout);
   }
   public function set_title($title) { $this->title=$title; return true; }
   public function get_title() { return $this->title; }
   public function set_timeout($timepout) { $this->timeout=$timeout; }
   public function get_timeout() { return $this->timeout; }
   public function get_page_id() { return $this->get_title(); }
}

if (!defined('IWD_PROCMAN')) {
   class session_activity {
      //active pages container. If page is closed, then it's last activity time record become
      //obsolete and then this page is removed from the container
      private static $apc=NULL;

      private static function load_apc() {
         if ((self::$apc=tws_profile('tws_apc'))===NULL) self::$apc=array();
      }
      private static function save_apc() {
         tws_profile('tws_apc', self::$apc);
      }
      //adds new page to the active pages container, at this moment only supports wai_page objects
      //this function returns special PID, that is then used by tws_session_activity JS function for updating
      //the page activity records
      public static function add_page($page, $ready=FALSE) {
         self::load_apc();
         //if page doesn't have ID then the title is taken. For this reason it is encoded to base64
         //to prevent problems with special chars or encoding in javascript
         if (!($pid=$page->get_page_id()) && !($pid=$page->get_title())) $pid="UNKNOWN";
         $pid=base64_encode($pid);
         $ct=time();
         self::$apc[$pid]=array(
            'act'=>$ct, //last activity is the current time
            'tim'=>($page->get_timeout()>0 ? $page->get_timeout() : 0),  //the expiration timeout of the page (0=NEVER)
            'exp'=>($ready ? ($page->get_timeout()>0 ? $ct+$page->get_timeout() : 0) : FALSE) //the expire time is either: 0=NEVER, FALSE=page is loading, or the timestamp
         );
         self::save_apc();
         return $pid;
      }
      //used for updating the active pages container. If the optional parameter $pid is given then
      //this page is updated. Pages that haven't been updated in last two pols are removed from the
      //active pages container
      public static function update($pid=NULL, $ready=FALSE) {
         global $tws_config;
         self::load_apc();
         $ct=time();
         if ($pid!==NULL && isset(self::$apc[$pid])) {
            self::$apc[$pid]['act']=$ct;
            //when the page is complete (ready=TRUE), then the "expire" time is set
            if (self::$apc[$pid]['exp']===FALSE && $ready==TRUE) {
               self::$apc[$pid]['exp']=(self::$apc[$pid]['tim']===0 ? 0 : $ct+self::$apc[$pid]['tim']);
            }
         }
         //remove 'dead' pages
         foreach (self::$apc as $pid=>$pd) {
            //pages with exp===FALSE are still rendered or they exit or were redirected before they ended. The maximum session lifetime is used for pages
            //that have timeout==0 (never ending). The other incomplete pages have their timeout to complete.
            if ($ct-$pd['act']>($pd['exp']===FALSE ? ($pd['tim']>0 ? $pd['tim'] : $tws_config['session_maxlifetime']) : $tws_config['ajax_freq']+1)) {
               unset(self::$apc[$pid]);
            }
         }
         self::save_apc();
      }
      //this function returns TRUE if there is any "active/not expired" page in the active pages container
      public static function is_active() {
         self::update();
         $ct=time();
         foreach (self::$apc as $pid=>$pd) {
            if ($pd['exp']==0 || $ct<=$pd['exp']) return TRUE; //NEVER expiring (exp===0) or INCOMPLETE PAGES (exp===FALSE) are supposed to be ACTIVE FOR EVER !!!!!!!
         }
         return FALSE;
      }
      //used for debugging content of the active pages container
      public static function debug() {
         self::load_apc();
         if (empty(self::$apc)) $res='session_activity::apc is empty...';
         else {
            $res='';
            foreach (self::$apc as $pid=>$pd) {
               $res.='Page "'.base64_decode($pid).'" ('.$pid.') - last activity='.date('Y-m-d H:i:s',$pd['act']).', expires='.($pd['exp']==0 ? ($pd['exp']===FALSE ? 'PAGE INCOMPLETE' : 'NEVER') : date('Y-m-d H:i:s',$pd['exp']))."\n";
            }
         }
         return $res;
      }
      public static function session_activity_checker($page, $open_script=TRUE, $fundef=TRUE) {
         global $tws_config;
         if ($open_script) echo "<script type=\"text/javascript\">\n";
         if ($fundef) { echo "
            //=============================================================================
            //PHP session activity test
            if ( typeof hwi_check_session_activity != 'function' ) {
               function hwi_check_session_activity(pid) {
                  //console.log('wai_package_1::hwi_check_session_activity - sending request');
                  $.ajax({
                     type: 'GET',
                     url: 'tws_ajax.php',
                     data : {
                        'action' : 'session_activity',
                        'pid' : pid,
                        'timem' : Date.now()
                     },
                     timeout: 500,
                     success: function(data) {
                        if (parseInt(data)==1) {
                           //console.log('wai_package_1::hwi_check_session_activity - received '+data+' - session active');
                        } else {
                           //console.log('wai_package_1::hwi_check_session_activity - received '+data+' - session closed - navigating to index.php');
                           window.top.location.replace('/index.php".(tws_get_authtype()=='os' ? '' : '?logout=1&oldauth='.urlencode($_SERVER['PHP_AUTH_USER']))."');
                        }
                     }
                  });
               }
            }\n";
         }
         if (tws_profile('tws_authority')) {
            $apc_pid=session_activity::add_page($page, TRUE);
            echo 'window.setInterval(hwi_check_session_activity, '.($tws_config['ajax_freq']*1000).', \''.$apc_pid.'\');'."\n";
         }
         if ($open_script) echo "</script>\n";
      }
   }
}//endif defined IWD_PROCMAN

/**
 * text area style for editing the Text definition of object
 * @param int $height height of text area window
 */
function tws_text_area_style($height){
echo "
<style type=\"text/css\">
   .CodeMirror-scroll {
        max-height: 85% !important;
        height:".(int)$height."em !important;
        width: 80%;
        max-width: 90%;
        border: 1px solid #ddd !important;
     }
</style>
";
}
?>
