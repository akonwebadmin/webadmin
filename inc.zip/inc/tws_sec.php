<?php
//   HORIZONT Software GmbH, Munich
//

//list of supported IWS security objects
$__tws_security_objects=array('JOB', 'SCHEDULE', 'RESOURCE', 'PROMPT', 'FILE', 'CPU', 'PARAMETER', 'CALENDAR', 'USEROBJ', 'VARTABLE', 'EVENTRULE', 'ACTION', 'RUNCYGRP');
if ($tws_config['cpuinfo']['version']>='9.5')
   $__tws_security_objects[] = 'FOLDER';
$__tws_security_access_rights=array('LIST', 'SUBMIT');


/**
 * Check user access rights to IWS objects based onn IWS security settings.
 * The function can also form SQL condition based on the access permissions.
 * @param string $class - IWS object type (SCHEDULE, JOB, etc...)
 * @param array $keymap - map of IWS security selector names to SQL names
 * @param string $tws_authority
 * @param string $access
 * @return boolean|string
 */
function tws_sec_check($class, $keymap=NULL, $tws_authority='', $access='LIST') {
   global $tws_config, $__tws_security_objects;

   if (!in_array($class, $__tws_security_objects)) {
      tws_error('requested class name=\''.$class.'\'', 'Unsupported IWS security request');
      return FALSE;
   }

   if ($tws_authority==='' && !($tws_authority=tws_profile('tws_authority'))) {
      tws_error(array('sapi'=>php_sapi_name(), $_SERVER), 'Unknown IWS authority name. Unable to apply IWS security settings');
      return FALSE;
   }

   tws_log("-- tws_sec_check : class $class, IWS authority: ".$tws_authority.", access=$access");

   $sec=tws_get_usersec($tws_authority, $access);
   if (is_array($sec[$class]) && count($sec[$class])) {
      if ($class!=='' && is_array($keymap)) {
         $acc_sql='';
         foreach ($sec[$class] as $rid=>&$rdef) {
            foreach ($rdef as $key=>&$val) {
               $op=$key{0}=='~' ? 'NOT' : '';
               $key=trim($key,'+~ ');
               //some objects may not have any criteria specified. Then '@' equals "ANY"
               if ($key=='@' && count($rdef)==1) {
                  $val=($op=='NOT' ? '0=1' : '1=1');
                  break;
               }
               if (!isset($keymap[$key])) {
                  tws_log("-- tws_sec_check - ERROR : unassigned SQL column name to attribute $key");
                  tws_err("Unassigned SQL column name to the TWS security attribute $key");
                  return FALSE;
               }
               if (empty($keymap[$key])) foreach ($val as $i=>$mask) $val[$i]='2=2'; //some attributes don't have SQL opposite in some context
               else foreach ($val as $i=>$mask) $val[$i]=$keymap[$key].' '.$op.' '.tws_sqllike($mask);
               $val=count($val)>1 ? '('.implode(($op=='NOT' ? ' AND ' : ' OR '),$val).')' : $val[0];
            }
            $rdef=count($rdef)>1 ? '('.implode(' AND ', $rdef).')' : implode(' AND ',$rdef);
         }
         (($nr=count($sec[$class]))>=1) && $acc_sql='AND '.($nr>1 ? '(' : '').implode(' OR ',$sec[$class]).($nr>1 ? ')' : '');
         tws_log("-- tws_sec_check - $access : \$sec[$class]=".print_r($sec[$class],1));
         tws_log("-- tws_sec_check - $access : \$acc_sql=$acc_sql");
         return $acc_sql;
      }
      return TRUE;
   } else {
      tws_error('', "Not authorized to $access objects of class '$class'"); //WARNING
      return FALSE;
   }
}

//default: returns the tws user sections (groups) and their members (logons)
//tws_authority!=='' => returns the array of groups the given user name is member
function tws_get_twssec_groups($tws_authority='') {
   $sections=tws_get_usersec();
   $groups=array();
   foreach ($sections as $k=>$sec) {
      foreach ($sec['user_attrs'] as $i=>$attr) {
         switch ($attr['name']) {
            case 'LOGON' :
               if ($attr['sign']=='+') {
                  foreach ($attr['value'] as $attval) {
                     if ($tws_authority==='') $groups[$sec['name']][]=$attval;
                     elseif (tws_jokercmp($tws_authority,$attval,FALSE,'tws')) {
                        $groups[]=$sec['name'];
                        break;
                     }
                  }
               }
         }
      }
   }
   return $groups;
}


//
// Private functions
//

function tws_sec_pop_tok($type='WORD') {
   global $__tws_sec_secfile, $__tws_sec_SPECS, $__tws_sec_lasttok, $__tws_sec_state;
   static $septoks=array();
   $septok=isset($septoks[$type]) ? $septoks[$type] : " \r\n\t";

   if (($tok=array_pop($__tws_sec_lasttok))===NULL) {
      if ($__tws_sec_state==='BOS') { //begin of user section
         $tok=strtok($__tws_sec_secfile, $septok);
         $__tws_sec_state='';
      } else $tok=strtok($septok);
   }

   if ($tok!==false) {
      switch ($type) {
         case 'KEYWORD':
            return strtoupper($tok);
         case 'WORD':
            return $tok;
         case 'VALUE':
            if (isset($__tws_sec_SPECS[$tok])) return $__tws_sec_SPECS[$tok];
            else return $tok;
      }
   } else {
      $__tws_sec_state='EOS'; //end of user section
      return FALSE;
   }
}

function tws_sec_push_tok($tok) {
   global $__tws_sec_lasttok;
   array_push($__tws_sec_lasttok,$tok);
}

function tws_fetch_user_section(&$user_section, $reload=FALSE, $force_eof=FALSE) {
   global $tws_config;
   static $pipes=NULL;
   if ($force_eof===TRUE) {
      if ($pipes!==NULL) hwi_pclose($pipes); //close streams, restart closed PHP session
      $pipes=NULL;
      return FALSE;
   }
   if ($reload) {
      if ($pipes!==NULL) hwi_pclose($pipes); //close streams, restart closed PHP session
      $pipes=NULL;
   }
   if ($pipes===NULL) {
      if ($tws_config['host_os']=='win32') {
         $command=new hwi_cmd($tws_config['maestro_dir'].'/bin/dumpsec'); //can't use sudo without dumpsec_user's password
      } else $command=new hwi_cmd(tws_sudo('', $tws_config['dumpsec_user']), $tws_config['maestro_dir'].'/bin/dumpsec');
      $stdout=FALSE;
      if (($pipes=hwi_popen($command, $ec, $stdout, $stdout))===FALSE || $ec!=0) {
         tws_error(array('STDERR'=>$stdout, 'CMD'=>$command->compile('log'), 'EC'=>$ec), 'Unable to read the IWS security file');
         return FALSE;
      }
   }

   $tl=tws_log();
   $user_section='';
   while (is_resource($pipes[1]) && !feof($pipes[1])) {
      if (($buffer=fgets($pipes[1], 4096))===FALSE) {
         usleep(10000);
         continue;
      }
      if (substr($buffer,0,4)==='USER') {
         $user_section=$buffer;
      } elseif ($user_section!='') {
         $user_section.=$buffer;
      }
      if (substr($buffer,0,3)==='END' || substr($buffer,0,8)==='CONTINUE') {
         return TRUE;
      }
   }
   if (feof($pipes[1])) {
      hwi_pclose($pipes);
      $pipes=NULL;
      $user_section='';
      return NULL; //NULL signalizes eon of file
   }
}

function tws_get_os_user_groups_membership($tws_authority) {
   global $tws_config;
   if (($users_groups=tws_profile('tws_users_groups'))===NULL) $users_groups=array();

   //use cached value if available
   if (isset($users_groups[$tws_authority])) {
      tws_log('-- tws_get_os_user_groups_membership: Cached groups membership: '.implode(', ',$users_groups[$tws_authority]));
      return $users_groups[$tws_authority];
   }

   if ($tws_config['host_os']=='win32') {
      //Important: if coding page is specified then whoami doesn't return all groups!!!
      $cmd=new hwi_cmd(tws_sudo(''), /*'chcp', '437', hwi_cmd::operator('AND'),*/ 'whoami', '/groups', '/fo', 'list');
      $stdout=array(); $stderr='';
      tws_popen($cmd, $ec, $stdout, $stderr, '', array('LC_ALL'=>'en_EN.UTF-8', 'LANG'=>'C')); //the env variables has likley no effect...
   } else {
      $cmd=new hwi_cmd('groups', $tws_authority);
      $stdout=array(); $stderr='';
      tws_popen($cmd, $ec, $stdout, $stderr);
   }

   if ($ec!='0' && empty($stdout)) {
      tws_error(array('cmd'=>$cmd->compile('log'), 'stdout'=>$stdout, 'stderr'=>$stderr, 'ec'=>$ec), "Unable to get user's groups membership");
      return FALSE;
   }

   $groups=array();
   if ($tws_config['host_os']=='win32') {
      //
      // GROUP INFORMATION
      // -----------------
      //
      // Group Name: Jeder
      // Type:       Well-known group
      // SID:        S-1-1-0
      // Attributes: Mandatory group, Enabled by default, Enabled group
      //
      // Group Name: PC131\tivoli
      // Type:       Alias
      // SID:        S-1-5-21-2912895299-1289607505-3886278679-1017
      // Attributes: Mandatory group, Enabled by default, Enabled group
      //
      // Group Name: VORDEFINIERT\Benutzer
      // Type:       Alias
      // SID:        S-1-5-32-545
      // Attributes: Mandatory group, Enabled by default, Enabled group
      //
      // Group Name: HORIZONT-IT\cz
      // Type:       Group
      // SID:        S-1-5-21-1790861158-912614567-3373464642-1168
      // Attributes: Mandatory group, Enabled by default, Enabled group
      $last_blank=FALSE;
      foreach($stdout as $line) {
         if ($last_blank && preg_match('/[^:]+:\s*(.+)/', $line, $_r)) {
            //the "whoami" always returns the data in the impicit Windows codepage
            $groupname=iconv(mb_detect_encoding(trim($_r[1]), mb_detect_order(), TRUE), 'UTF-8//IGNORE', trim($_r[1]));
            $groups[]=$groupname;
            list($domain,$group)=explode('\\',$groupname);
            if (isset($group)) $groups[]=$group;
         }
         $last_blank=(trim($line)=='');
      }
      //Example result:  Array (
      //    [0] => Jeder
      //    [1] => PC131\tivoli
      //    [2] => tivoli
      //    [3] => VORDEFINIERT\Benutzer
      //    [4] => Benutzer
      //    [5] => HORIZONT-IT\cz
      //    [6] => cz
   } else {
     list($groups, $u)=array_reverse(explode(':',$stdout[0]));
     $groups=explode(' ', $groups);
   }

   tws_log('-- tws_get_os_user_groups_membership: Detected membership in '.count($groups).' these groups: '.implode(', ',$groups));

   $tws_users_groups[$tws_authority]=$groups;
   tws_profile('tws_users_groups', $tws_users_groups);
   return $tws_users_groups[$tws_authority];
}

//tws security user sections parser
function tws_get_usersec($tws_authority='', $access='LIST') {
   global $tws_config;
   global $__tws_sec_secfile, $__tws_sec_state, $__tws_sec_SPECS, $__tws_sec_lasttok, $__tws_security_objects, $__tws_security_access_rights;

   $acc_rights=array();

   if ($tws_authority!=='') {
      if ($access=='LIST') {
         if (isset($tws_config['optmanopts']) && !tws_yesno($tws_config['optmanopts']['enlistsecchk'],TRUE,FALSE)) {
            tws_log('-- tws_get_usersec: Warning: optmanopts[enListSecChk] is OFF, LIST access to IWS objects is omitted');
            foreach ($__tws_security_objects as $obj) $acc_rights[$obj]=array(array('@'=>'@')); //ANY criteria, ANY value
            tws_profile('tws_sec_'.$access,'');
            return $acc_rights;
         }

         if (isset($tws_config['tws_secfile']) && !tws_yesno($tws_config['tws_secfile'],TRUE,FALSE)) {
            tws_log('-- tws_get_usersec: Warning: The impact of IWS Security File on querying IWS database is switched OFF');
            foreach ($__tws_security_objects as $obj) $acc_rights[$obj]=array(array('@'=>'@')); //ANY criteria, ANY value
            tws_profile('tws_sec_'.$access,'');
            return $acc_rights;
         }
      }
         //try if the security is not already cached
      if (($sec=tws_profile('tws_sec_'.$access))!==NULL && $sec!='') {
         //tws_log("-- tws_get_usersec: IWS Security Rules for $access (cached): ".print_r($sec,1));
         tws_log("-- tws_get_usersec: IWS Security Rules for $access cached");
         return $sec;
      }
   } else {
      //special mode = accumulator of all user section USER-definitions
      $sections=array();
   }

   $sec=array();
   while (($fs=tws_fetch_user_section($__tws_sec_secfile))!==FALSE) {
      $user_section_backup=$__tws_sec_secfile;
      if ($fs===NULL) {
         if ($tws_authority==='') {
            //in this special mode, just return the collected user section defintions
            return $sections;
         }

         $__tws_sec_state='FINAL';
      } else {
         //parser state machine initialization - begin of user section
         $__tws_sec_state='BOS';

         //PREPROCESSING:
         //process all the quotations - to avoid troubles with tokenization, replace all quotations
         //by $qN references (N=0,1,2,3) to a special container $__tws_sec_SPECS
         $__tws_sec_secfile=preg_replace("/[\\\\]\"/",'&slashedquot;',$__tws_sec_secfile);
         preg_match_all('/"([^"]*)"/',$__tws_sec_secfile,$quotes);
         foreach($quotes[1] as $key=>$val) {
            $__tws_sec_SPECS['$q'.$key]=preg_replace('/&slashedquot;/','\"',$val);
         }
         $n=0;$q=0;
         while (($__tws_sec_secfile=preg_replace('/"[^"]*"/','$q'.$q,$__tws_sec_secfile,1,$n)) && $n==1) $q++;
         //strip out all comments
         $__tws_sec_secfile=preg_replace("/[#*].*\n/","\n",$__tws_sec_secfile);
         //add one spaces before and after the operators
         $__tws_sec_secfile=preg_replace('/([,=+~])/',' \\1 ',$__tws_sec_secfile);
      }

      $__tws_sec_lasttok=array();
      $i=0;
      while (1) {
         switch ($__tws_sec_state) {
            case '' : case 'BOS' :
               if (tws_sec_pop_tok('KEYWORD')=='USER') $__tws_sec_state='SEC_NAME';
               break;

            case 'SEC_NAME':
               $sec['name']=tws_sec_pop_tok('VALUE');
               $__tws_sec_state='USER_ATTR_SIGN';
               $sec['user_attrs_count']=0;
               $sec['user_attrs']=array();
               break;

            case 'USER_ATTR_SIGN':
               $tok=tws_sec_pop_tok('WORD');
               if ($tok==',') $__tws_sec_state='USER_ATTR_VALUE';
               elseif ($tok=='+' || $tok=='~') {
                  //next user attribute
                  $sec['user_attrs'][ ++$sec['user_attrs_count']-1 ]['sign']=$tok;
                  $__tws_sec_state='USER_ATTR_NAME';
               } elseif (strtoupper($tok)=='BEGIN') {
                  $__tws_sec_state='BEGIN';
               } else {
                  $sec['user_attrs'][ ++$sec['user_attrs_count']-1 ]['sign']="+";
                  tws_sec_push_tok($tok);
                  $__tws_sec_state='USER_ATTR_NAME';
               }
               break;

            case 'USER_ATTR_NAME':
               $sec['user_attrs'][ $sec['user_attrs_count']-1 ]['name']=tws_sec_pop_tok('KEYWORD');
               if (($tok=tws_sec_pop_tok())!='=') {
                  tws_error("Token '$tok' instead of expected token '='\n".$user_section_backup, "Error while processing the IWS security file");
                  $__tws_sec_state='ERROR';
               }
               $__tws_sec_state='USER_ATTR_VALUE';
               break;

            case 'USER_ATTR_VALUE':
               $sec['user_attrs'][ $sec['user_attrs_count']-1 ]['value'][]=tws_sec_pop_tok('VALUE');
               $__tws_sec_state='USER_ATTR_SIGN';
               break;

            case 'BEGIN':
               //check if the user match, TODO: don't continue if tws_authority==='' !
               if ($tws_authority!=='') {
                  $cpu_match=NULL;
                  $user_match=NULL;
                  $group_match=NULL;
                  foreach ($sec['user_attrs'] as $i=>$attr) {
                     switch ($attr['name']) {
                        case 'CPU' :
                           //WebAdmin users are taken as users logged in the IWS MDM (where WebAdmin is installed)
                           $host=isset($tws_config['cpuinfo']['host']) ? $tws_config['cpuinfo']['host'] : $tws_config['localopts']['thiscpu'];
                           foreach ($attr['value'] as $attval) {
                              if (tws_jokercmp($host,$attval,FALSE,'tws') || strtoupper($attval)=='$MASTER' || strtoupper($attval)=='$THISCPU') $cpu_match=$attr['sign']=='+' ? TRUE : FALSE;
                              if ($cpu_match!==NULL) break;
                           }
                           break;
                        case 'LOGON' :
                            $user_match = FALSE;
                            foreach ($attr['value'] as $attval) {
                              if (tws_jokercmp($tws_authority,$attval,FALSE,'tws')) {
                                  $user_match=$attr['sign']=='+' ? TRUE : FALSE;
                              } 
                              if ($user_match) break;
                           }
                           break;
                        case 'GROUP' :
                           $group_match=FALSE;
                           $user_groups=tws_get_os_user_groups_membership($tws_authority);
                           foreach ($attr['value'] as $attval) {
                              foreach($user_groups as $group) {
                                 if (tws_jokercmp($group,$attval,FALSE,'tws')) $group_match=$attr['sign']=='+' ? TRUE : FALSE;
                                 if ($group_match) break 2;
                              }
                           }
                           break;
                     }
                  }
                  // match to user attributes CPU, LOGON, GROUP
                  if (!($cpu_match === FALSE || $user_match === FALSE || $group_match === FALSE) && (is_bool($cpu_match)||is_bool($user_match)||is_bool($group_match))) {
                     $sec['matching'][]=$sec['name'];
                     tws_log('-- tws_get_usersec: success security match to user attributes, CPU '.var_export($cpu_match,true).', LOGON '.var_export($user_match, true).', GROUP '.var_export($group_match, true));
                     $__tws_sec_state='OBJ_TYPE';
             
                  }else{    
                     $__tws_sec_state='EOS';
                  }
               } else {
                  //just collect the user section "USER-ship descriptions"
                  array_push($sections, $sec);
                  $__tws_sec_state='EOS';
               }
               break;

            case 'OBJ_TYPE':
               if (($objtype=tws_sec_pop_tok('KEYWORD'))!=='END' && $objtype!=='CONTINUE') {
                  @$sec[$objtype]['rules_count']++;
                  $ruleid=@$sec[$objtype]['rules_count']-1;
                  $sec[$objtype][$ruleid]['obj_attrs_count']=0;
                  $__tws_sec_state='OBJ_ATTR_SIGN';
               } else $__tws_sec_state=$objtype; //END or CONTINUE
               break;

            case 'OBJ_ATTR_SIGN':
               $tok=tws_sec_pop_tok('WORD');
               if ($tok==',') $__tws_sec_state='OBJ_ATTR_VALUE';
               elseif ($tok=='+' || $tok=='~') {
                  //next objtype[ruleid] attribute
                  $sec[$objtype][$ruleid]['obj_attrs'][ ++$sec[$objtype][$ruleid]['obj_attrs_count']-1 ]['sign']=$tok;
                  $__tws_sec_state='OBJ_ATTR_NAME';
               } elseif (strtoupper($tok)=='ACCESS') {
                  if (($tok=tws_sec_pop_tok())=='=') {
                     $__tws_sec_state='OBJ_ACCESS';
                  } else {
                     tws_sec_push_tok($tok);
                     $__tws_sec_state='OBJ_TYPE';
                  }
               } else {
                  $sec[$objtype][$ruleid]['obj_attrs'][ ++$sec[$objtype][$ruleid]['obj_attrs_count']-1 ]['sign']='+';
                  tws_sec_push_tok($tok);
                  $__tws_sec_state='OBJ_ATTR_NAME';
               }
               break;

            case 'OBJ_ATTR_NAME':
               $sec[$objtype][$ruleid]['obj_attrs'][ $sec[$objtype][$ruleid]['obj_attrs_count']-1 ]['name']=tws_sec_pop_tok('KEYWORD');
               if (($tok=tws_sec_pop_tok())!='=') {
                  tws_error("Token '$tok' instead of expected token '=' (objtype=$objtype).\n".$user_section_backup, "Error while processing the IWS security file");
                  $__tws_sec_state='ERROR';
               }
               $__tws_sec_state='OBJ_ATTR_VALUE';
               break;

            case 'OBJ_ATTR_VALUE':
               $sec[$objtype][$ruleid]['obj_attrs'][ $sec[$objtype][$ruleid]['obj_attrs_count']-1 ]['value'][]=tws_sec_pop_tok('VALUE');
               $__tws_sec_state='OBJ_ATTR_SIGN';
               break;

            case 'OBJ_ACCESS':
               $tok=tws_sec_pop_tok('VALUE');
               if ($tok=='SUBMITDB') $tok='SUBMIT';
               $sec[$objtype][$ruleid]['access'][]=$tok;
               if (($tok=tws_sec_pop_tok())!=',') {
                  tws_sec_push_tok($tok);
                  $__tws_sec_state='OBJ_TYPE';
               }
               break;

            case 'END': case 'CONTINUE': case 'FINAL' :
               //user's entries (the user match evaluated at BEGIN state)
               if ($__tws_sec_state=='FINAL') {
                  tws_log('-- tws_get_usersec: Final processing of all detected user sections for IWS authority \''.$tws_authority.'\'');
               } else {
                  tws_log('-- tws_get_usersec: Detected a matching user section \''.$sec['name'].'\' for IWS authority \''.$tws_authority.'\': '."\n".$user_section_backup);
               }
               if ($__tws_sec_state=='CONTINUE') {
                  //all matching user sections are loaded before their processing
                  $__tws_sec_state='EOS';
                  break;
               }

               //free the last user section header, it is not needed anymore
               unset($sec['name']);
               unset($sec['user_attrs_count']);
               unset($sec['user_attrs']);
               // Debug mode:  tws_log('-- tws_get_usersec: Detected IWS access rights entries for IWS authority \''.$tws_authority.'\': '.print_r($sec,1));

               //loop over all supported access rights
               foreach($__tws_security_access_rights as $accessx) {
                  //initialization of processing structures
                  foreach ($__tws_security_objects as $obj) {
                     $acc_rights[$obj]=array();
                     $stop[$obj]=FALSE;
                  }

                  //loop over all objects, process the access rules for each
                  foreach ($acc_rights as $obj=>$def) {
                     for ($r=0; $r<@$sec[$obj]['rules_count']; $r++) {
                        if (!is_array($sec[$obj][$r]['access'])) {
                           // there may appear the keyword ACCESS without any access right specifications. The meaning is (TWS8.4) NO ACCESS since this line.
                           // IMPORTANT: The previous access rights to the same objects are not affected by this rule! Any further rules ARE!!!
                           //
                           // Example:
                           //        SCHEDULE        CPU=@+NAME=S@   ACCESS=LIST,DISPLAY
                           //        SCHEDULE        CPU=@+NAME=@    ACCESS
                           //        SCHEDULE        CPU=@+NAME=U@   ACCESS=LIST,DISPLAY
                           // Result:
                           //        Only the schedules that match @#S@ are displayed
                           //
                           // Implementation: we create a STOP flag to each object rules list
                           $stop[$obj]=TRUE;
                        } elseif (!$stop[$obj]) {
                           switch ($accessx) {
                              case 'LIST' : //LIST is a special privilege - influence from the DISPLAY privilege
                                 if ((in_array('LIST',$sec[$obj][$r]['access']) || in_array('DISPLAY',$sec[$obj][$r]['access']) || in_array('@',$sec[$obj][$r]['access']))) {
                                    //some objects may not have any attributes specified, special rule is made to flag this
                                    if ($sec[$obj][$r]['obj_attrs_count']==0) $acc_rights[$obj][$r]['@']='@';
                                    else {
                                       for ($i=0; $i<$sec[$obj][$r]['obj_attrs_count']; $i++) {
                                          foreach ($sec[$obj][$r]['obj_attrs'][$i]['value'] as $v) {
                                             $acc_rights[$obj][$r][ ($sec[$obj][$r]['obj_attrs'][$i]['sign']).($sec[$obj][$r]['obj_attrs'][$i]['name']) ][]=$v;
                                          }
                                       }
                                    }
                                 }
                                 break;
                              default: //SUBMIT, etc...
                                 if (in_array($accessx,$sec[$obj][$r]['access']) || in_array('@',$sec[$obj][$r]['access'])) {
                                    //some objects may not have any attributes specified, special rule is made to flag this
                                    if ($sec[$obj][$r]['obj_attrs_count']==0) $acc_rights[$obj][$r]['@']='@';
                                    else {
                                       for ($i=0; $i<$sec[$obj][$r]['obj_attrs_count']; $i++) {
                                          foreach ($sec[$obj][$r]['obj_attrs'][$i]['value'] as $v) {
                                             $acc_rights[$obj][$r][ ($sec[$obj][$r]['obj_attrs'][$i]['sign']).($sec[$obj][$r]['obj_attrs'][$i]['name']) ][]=$v;
                                          }
                                       }
                                    }
                                 }
                                 break;
                           }//end switch
                        }
                     }
                  }
                  tws_log("-- tws_get_usersec: Evaluated access rights rules - $accessx : ".print_r($acc_rights,1));

                  //At this moment the security for selected IWS authority is known, so we force the fetcher
                  //to close the streams and, which is more important, to restart the session to be able to
                  //save the IWS security rules into the the user's session
                  tws_fetch_user_section($tmp='', FALSE, TRUE);

                  //save the processed access right to the user's session
                  tws_profile('tws_sec_'.$accessx, $acc_rights);
               }
               //return only the currently requested access right, although all of the supported access
               //rights were processed (to avoid multiple dumpsec executions and parsing)
               return tws_profile('tws_sec_'.$access);

            case 'EOS':
               //jump out to the loop over user sections
               break 2;

            case 'ERROR':
               if ($tws_authority!=='') return FALSE;
               $__tws_sec_state='EOS';
               break;
         }
      }
   }
   if ($tws_authority!=='') {
      tws_log('-- tws_get_usersec: User \''.$tws_authority.'\' doesn\'t match any IWS Security USER section.');
      //make sure the access rights are removed - no access for this user session
      foreach($__tws_security_access_rights as $accessx) {
         tws_profile('tws_sec_'.$accessx, FALSE);
      }
      return FALSE;
   }
   return $sections;
}

?>
