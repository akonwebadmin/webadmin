<?php
//   HORIZONT Software GmbH, Munich
//


/////////////////////////////////////////////////////////////
//
//                ADMIN Section
//               & Private Functions
//
/////////////////////////////////////////////////////////////


// ************************************** //
//                Action Buttons          //
//             Private Functions          //
// ************************************** //

// **********  return Array of Permitted Actions in $section  ************ //
function tws_get_actions($section) {
   global $tws_config, $tws_default_actions;

   $username = tws_profile('auth_user_name');
   $arr_permit = tws_get_user_actions($section, $username);
   return $arr_permit;
}


// **********  return Array of Permitted Actions for Group $groupname ************ //
function tws_get_group_actions($section, $groupname) {
   global $tws_config, $tws_default_actions;

   if (!isset($groupname) || $groupname == "") {
      return false;
   }
   if (!isset($section) || $section == "") {
      return false;
   }
   $user_setting_dir = $tws_config['user_setting_dir'];

   $allusers_fn = $tws_config['webadmin_user_home_dir'].'/all_users'.$user_setting_dir.'/actions.php';
   if (file_exists($allusers_fn)) {
      include ($allusers_fn);
   }
   $groupactions_fn = $tws_config['webadmin_user_home_dir'].'/groups/'.$groupname.$user_setting_dir.'/actions.php';
   if (file_exists($groupactions_fn)) {
      include ($groupactions_fn);
   }
   if (isset($tws_actions[$section])) {
      $str_permit = $tws_actions[$section];
   }
   else {
      $str_permit = $tws_default_actions[$section];
   }
   if($str_permit == '')
      return '';
   $arr_permit  = explode(':',$str_permit);
   return $arr_permit;
}

// **********  return Array of Permitted Actions for User $username  ************ //
function tws_get_user_actions($section, $username) {
   global $tws_config, $tws_default_actions;

   $username = $username;
   $groupname = tws_profile('auth_user_group');
   $groupname = $groupname;

   if (!isset($username) || $username == "") {return false;}
   if (!isset($section) || $section == "") {return false;}

   $user_setting_dir = $tws_config['user_setting_dir'];

   $allusers_fn = $tws_config['webadmin_user_home_dir'].'/all_users'.$user_setting_dir.'/actions.php';
   if (file_exists($allusers_fn)) {
      include ($allusers_fn);
   }
   $groupactions_fn = $tws_config['webadmin_user_home_dir'].'/groups/'.$groupname.$user_setting_dir.'/actions.php';
   if (file_exists($groupactions_fn)) {
      include ($groupactions_fn);
   }
   $useractions_fn = $tws_config['webadmin_user_home_dir'].'/'.$username.$user_setting_dir.'/actions.php';
   if (file_exists($useractions_fn)) {
      include ($useractions_fn);
   }
   if (isset($tws_actions[$section])) {
      $str_permit = $tws_actions[$section];
   }
   else {
      $str_permit = $tws_default_actions[$section];
   }
   if($str_permit == '')
      return '';
   $arr_permit  = explode(':',$str_permit);
   return $arr_permit;
}

// **********  return Array of Default Actions ************ //
function tws_get_default_actions($section) {
   global $tws_config, $tws_default_actions;
   $user_setting_dir = $tws_config['user_setting_dir'];

   $allusers_fn = $tws_config['webadmin_user_home_dir'].'/all_users'.$user_setting_dir.'/actions.php';
   if (file_exists($allusers_fn)) {
      include ($allusers_fn);
   }
   if (isset($tws_actions[$section])) {
      $str_permit = $tws_actions[$section];
   }
   else {
      $str_permit = $tws_default_actions[$section];
   }
   if($str_permit == '')
      return '';
   $arr_permit  = explode(':',$str_permit);
   return $arr_permit;
}

// **********  return Array of All Available Actions ************ //
function tws_get_all_actions($section) {
   global $tws_config, $tws_default_actions;

   $str_permit = $tws_default_actions[$section];
   $arr_permit  = explode(':',$str_permit);
   return $arr_permit;
}



// ***************************************
//
//    Display Group Menu - analogue of tws_display_menu_configuration($username)
//
//    if $groupname == 'default' (or smth. else :) - display default menu configuration from all_users or etc dir
//    called from tws_define_user_menu.php & tws_define_group_menu.php
//
// ***************************************

function tws_display_group_menu_configuration($groupname) {
   global $tws_config;
   $user_setting_dir = $tws_config['user_setting_dir'];
   $webadmin_user_home_dir = $tws_config['webadmin_user_home_dir'];
   $webadmin_all_user_dir = $tws_config['webadmin_all_user_dir'];
   $base_inst_dir = $tws_config['base_inst_dir'];

   include("$base_inst_dir/etc/menu.php");
   if (is_file($webadmin_all_user_dir.$user_setting_dir."/menu.php"))
      include($webadmin_all_user_dir.$user_setting_dir."/menu.php");
   if (is_file($webadmin_user_home_dir."/groups/".$groupname.$user_setting_dir."/menu.php") )
      include($webadmin_user_home_dir."/groups/".$groupname.$user_setting_dir."/menu.php");


   //TWS8.5 upgrade
   if ($tws_config['cpuinfo']['version']>='8.5') {
      if (!isset($Parameter_Tables)) $Parameter_Tables=1;
   } else {
      $Parameter_Tables=0;
   }

   // define section checkboxes
   $Plan_Section = 0;
   $tmp = array($Workstations,$Domains,$Jobstreams,$Jobs,$Resources,$Prompts,$Files,$Plan_Filters,$Event_Rules_Monitor,$Actions_Monitor,
                $Log_Messages_Monitor,$Submit_Jobstream,$Submit_Job,$Submit_Task,$Set_Alternate_Plan,$Generate_New_Plan);
   foreach ($tmp as $val) {
      if($val==1){
         $Plan_Section = 1; break;
      }
   }
   $Database_Section = 0;
   $tmp = array($Workstations2,$Workstation_Classes,$Domains2,$Jobstreams2,$Calendars,$Jobs2,$Resources2,$Prompts2,$Parameter_Tables,
                $Parameters,$Local_Parms,$Users,$Event_Rules,$Database_Filters,$Saved_Drafts,$Notes);
   foreach ($tmp as $val) {
      if($val==1){
         $Database_Section = 1; break;
      }
   }
   $Reports_Section = 0;
   $tmp = array($Job_History,$Job_Detail,$TWS_Activity,$Production_Planning,$TWS_Database,$Cross_Reference,$Critical_Jobs,$SQL_Query,
                $User_Defined_Reports,$Stored_Reports);
   foreach ($tmp as $val) {
      if($val==1){
         $Reports_Section = 1; break;
      }
   }
   $Log_Section = 0;
   $tmp = array($Event_Monitor,$Database_Audit_Log,$Plan_Audit_Log);
   foreach ($tmp as $val) {
      if($val==1){
         $Log_Section = 1; break;
      }
   }

   $filename="$base_inst_dir/etc/menu.xml";
   if (!$fp=fopen($filename,"r")) {
      tws_dyer("Can't open file '$base_inst_dir/etc/menu.xml'");
   }
   while ($buffer=fgets($fp,4096)) {
      if (substr($buffer,0,1) == "<") {
         $tok=strtok($buffer," >");
         switch($tok) {
           case "<menu":
             break;
           case "<br":
             echo "<tr><td>&nbsp;</td></tr>\n";
             break;
           case "<heading":
             $heading_start=strpos($buffer,"<heading>");
             if ($heading_start !== FALSE) {
                $heading_end=strpos($buffer,"</heading>");
                if ($heading_end !== FALSE) {
                  $heading_name = substr($buffer,($heading_start + 9),($heading_end - $heading_start - 9));
                  if(strpos($heading_name, ' ')===false)
                     $section_name = $heading_name;
                  else
                     $section_name = substr($heading_name, 0, strpos($heading_name, ' '));

                  $heading_num++;
                  echo "<tr><td class=standard><b><label><input type='checkbox' name='section[]' value='".$section_name."_Section'";
                  if (${$section_name."_Section"} == 1) echo " checked";
                  echo " onclick='checkSection(this, $heading_num)'/>";
                  echo "&nbsp;" . $heading_name . "</label></b></td></tr>\n";
                }
             }
             break;
           case "<item":
             $attrs = strtok(">");
             $item=strtok("<");
             //support of INIAS attribute (see menu.xml)
             $item_check = strtr(preg_match('/inias\s*=\s*"([^"]+)/i', $attrs, $inias) ? $inias[1] : $item, " ", "_");
             // Strip off trailing numbers 2 - 9
             $item = preg_replace("/[2-9]$/","",$item);
             // Replace spaces with &nbsp;
             $item = str_replace(" ", "&nbsp;", $item);
             $endtag=strtok("\n");

             if (preg_match('/href\s*=\s*"([^"]+)"/', $attrs, $href) && $endtag=="/item>") {
                //$href = $href[1];
                echo "<tr><td class=standard>&nbsp;&nbsp;&nbsp;<label><input type=\"checkbox\" name=\"menu_item[]\" class='$heading_num' value=\"$item_check\"";
                if (${$item_check}) {
                   echo " checked";
                }
                echo ">&nbsp;" . $item . "</label></td></tr>\n";
             }
             break;
         }
      }
   }
   fclose($fp);
   return TRUE;
}


// ***************************************
//
//    tws_display_menu_configuration(user)
//
//   prints menu configuration form for specified user
//   if user is not defined (or the menu does not exists) default_menu configuration is printed
//   used in tws_define_user_menu.php & tws_menu_configuration.php
//
// ***************************************

function tws_display_menu_configuration($user='all_users') {
   global $tws_config,$base_inst_dir,$webadmin_all_user_dir,$webadmin_user_home_dir,$maestro_dir,$user_setting_dir;

   include("$base_inst_dir/etc/menu.php");
   if (is_file($webadmin_all_user_dir.$user_setting_dir."/menu.php"))
      include($webadmin_all_user_dir.$user_setting_dir."/menu.php");
   if (is_file($webadmin_user_home_dir."/".$user.$user_setting_dir."/menu.php"))
      include($webadmin_user_home_dir."/".$user.$user_setting_dir."/menu.php");


   //TWS8.5 upgrade
   if ($tws_config['cpuinfo']['version']>='8.5') {
      if (!isset($Parameter_Tables)) $Parameter_Tables=1;
   } else {
      $Parameter_Tables=0;
   }
   // IWS 9.1 upgrade
   //$tws_config['cpuinfo']['version']='9.1';
   if ($tws_config['cpuinfo']['version']>='9.1'){
      if (!isset($Run_Cycle_Groups)) $Run_Cycle_Groups=1;
      if (!isset($Applications)) $Applications=1;
   } else {
      $Run_Cycles=0;
      $Applications=0;
   }
   // IWS 9.5 folders
   if ($tws_config['cpuinfo']['version']>='9.5'){
      if (!isset($Folders)) $Folders=1;
      else $Folders=0;
   }

   // define section checkboxes
   $Plan_Section = 0;
   $tmp = array($Workstations,$Domains,$Jobstreams,$Jobs,$Resources,$Prompts,$Files,$Plan_Filters,$Event_Rules_Monitor,$Actions_Monitor,
                $Log_Messages_Monitor,$Submit_Jobstream,$Submit_Job,$Submit_Task,$Set_Alternate_Plan,$Generate_New_Plan);
   foreach ($tmp as $val) {
      if($val==1){
         $Plan_Section = 1; break;
      }
   }
   $Database_Section = 0;
   $tmp = array($Workstations2,$Workstation_Classes,$Domains2,$Jobstreams2,$Calendars,$Jobs2,$Resources2,$Prompts2,$Parameter_Tables,
                $Parameters,$Local_Parms,$Users,$Event_Rules,$Database_Filters,$Saved_Drafts,$Notes, $Applications, $Run_Cycles);
   foreach ($tmp as $val) {
      if($val==1){
         $Database_Section = 1; break;
      }
   }
   $Reports_Section = 0;
   $tmp = array($Job_History,$Job_Detail,$TWS_Activity,$Production_Planning,$TWS_Database,$Cross_Reference,$Critical_Jobs,$SQL_Query,
                $User_Defined_Reports,$Stored_Reports);
   foreach ($tmp as $val) {
      if($val==1){
         $Reports_Section = 1; break;
      }
   }
   $Log_Section = 0;
   $tmp = array($Event_Monitor,$Database_Audit_Log,$Plan_Audit_Log);
   foreach ($tmp as $val) {
      if($val==1){
         $Log_Section = 1; break;
      }
   }

   $filename="$base_inst_dir/etc/menu.xml";
   if (!$fp=fopen($filename,"r")) {
       return FALSE;
   }
   $heading_num = 0;
   while ($buffer=fgets($fp,4096)) {
      if (substr($buffer,0,1) == "<") {
         $tok=strtok($buffer," >");
         switch($tok) {
           case "<menu":
             break;
           case "<br":
             echo "<tr><td>&nbsp;</td></tr>\n";
             break;
           case "<heading":
             $heading_start=strpos($buffer,"<heading>");
             if ($heading_start !== FALSE) {
                $heading_end=strpos($buffer,"</heading>");
                if ($heading_end !== FALSE) {
                  $heading_name = substr($buffer,($heading_start + 9),($heading_end - $heading_start - 9));
                  if(strpos($heading_name, ' ')===false)
                     $section_name = $heading_name;
                  else
                     $section_name = substr($heading_name, 0, strpos($heading_name, ' '));

                  $heading_num++;
                  echo "<tr><td class=standard><b><label><input type='checkbox' name='section[]' value='".$section_name."_Section'";
                  if (${$section_name."_Section"} == 1) echo " checked";
                  echo " onclick='checkSection(this, $heading_num)'/>";
                  echo "&nbsp;" . $heading_name . "</label></b></td></tr>\n";
                }
             }
             break;
           case "<item":
             $attrs = strtok(">");
             $item=strtok("<");
             //support of INIAS attribute (see menu.xml)
             $item_check = strtr(preg_match('/inias\s*=\s*"([^"]+)/i', $attrs, $inias) ? $inias[1] : $item, " ", "_");
             if( ($item == 'Applications' || $item == 'Run Cycles') && $tws_config['cpuinfo']['version']<'9.1')
                break;
             // Strip off trailing numbers 2 - 9
             $item = preg_replace("/[2-9]$/","",$item);
             // Replace spaces with &nbsp;
             $item = str_replace(" ", "&nbsp;", $item);
             $endtag=strtok("\n");

             if (preg_match('/href\s*=\s*"([^"]+)"/', $attrs, $href) && $endtag=="/item>") {
                //$href = $href[1];
                echo "<tr><td class=standard>&nbsp;&nbsp;&nbsp;<label><input type=\"checkbox\" name=\"menu_item[]\" class='$heading_num' value=\"$item_check\"";
                if (${$item_check}) {
                   echo " checked";
                }
                echo ">&nbsp;" . $item . "</label></td></tr>\n";
             }
             break;
         }
      }
   }
   fclose($fp);
   return TRUE;
}

// ***************************************
//
// tws_save_menu_configuration($menu_item, $user)
//
//    saves menu for user
//    tws_save_user_menu.php & tws_set_menu_configuration.php
//
// ***************************************

function tws_save_menu_configuration($menu_item, $user="all_users") {
   global $maestro_dir,$base_inst_dir,$webadmin_user_home_dir,$webadmin_all_user_dir,$user_setting_dir;
   if ($user=="all_users") {
      $dir=$webadmin_all_user_dir;
   } else {
      $dir=$webadmin_user_home_dir."/".$user;
   }

   if (!is_dir($dir)) {
      if (!mkdir($dir)) {
         tws_error(array('username'=>$user, 'userdir'=>$dir), "Missing user's IWS/WebAdmin home directory");
         return FALSE;
      }
   }
   if (!is_dir($dir.$user_setting_dir)) {
      if (!mkdir($dir.$user_setting_dir)) {
         tws_error(array('username'=>$user, 'userdir'=>$dir.$user_setting_dir), "Missing user's IWS/WebAdmin home directory");
         return FALSE;
      }
   }
   $dir = $dir.$user_setting_dir;
   $filename = $dir."/menu.php";
   $filename2="$base_inst_dir/etc/menu.xml";
   if (!$fp2=fopen($filename2,"r")) {
      tws_error('', 'Unable to open '.$filename2);
      return FALSE;
   } else {
      while ($buffer=fgets($fp2,4096)) {
         if (substr($buffer,0,1) == "<") {
            $tok=strtok($buffer," >");
            switch($tok) {
              case "<menu":
              case "<br":
              case "<heading":
                break;
              case "<item":
                $attrs=strtok(">");
                $item=strtok("<");
                //support of INIAS attribute (see menu.xml)
                $item_check = strtr(preg_match('/inias\s*=\s*"([^"]+)/i', $attrs, $inias) ? $inias[1] : $item, " ", "_");
                $endtag=strtok("\n");
                if (preg_match('/href\s*=\s*"([^"]+)"/', $attrs, $href) && $endtag=="/item>") {
                   $href=$href[1];
                   $all_items[]=$item_check;
                }
                break;
            }
         }
      }
   }
   fclose($fp2);

   if (is_file($filename)) {
      copy($filename, $filename.'.bak');
   }
   $fp=fopen($filename,'w');
   if (!$fp) {
      tws_error(array('username'=>$user, 'userdir'=>$dir.$user_setting_dir, 'filename'=>$filename), "Unable to create user's menu configuration file");
      return FALSE;
   }
   $content[]="<?php\n";
   foreach ($all_items as $item) {
      if (in_array($item,$menu_item)) {
         $content[]='$'.$item."=1;\n";
      } else {
         $content[]='$'.$item."=0;\n";
      }
   }
   $content[]="?>\n";
   foreach ($content as $line) {
      $num_bytes=fwrite($fp,$line);
      if ($num_bytes < 0) {
         fclose($fp);
         tws_error(array('username'=>$user, 'userdir'=>$dir.$user_setting_dir, 'filename'=>$filename), "Unable to write user's menu configuration file");
         return FALSE;
      }
   }
   fclose($fp);
   tws_chmod($filename,0644);

   // remove menu from Session
   if($user == 'all_users' || $user == $_SERVER['PHP_AUTH_USER'])
      tws_profile("menu", '');

// if saving all_users => create backup in etc/
// BAD IDEA, in etc/ will be menu.php which allws everything
/*   if ($user == "all_users") {
      $bckfile = "$maestro_dir/webadmin/etc/menu.php";
      if (is_file($bckfile)) {
         if (!copy($bckfile,"$bckfile.bak")) return FALSE;
      }
      if (!copy($filename,$bckfile)) return FALSE;
   }
*/
   return TRUE;
}

// ***************************************
//       Backup Administration
// ***************************************

// ***************************************
//    array tws_backup_parse_name ($text, $type)
//
//    find and return object names from $text
// ***************************************

function tws_backup_parse_name ($text, $type) {    // Not used
   $names = array();

   switch ($type) {
      case "job":
         $str = strtok($text, "\n");
         while ($str !== false ) {
            if(strpos($str, " ") !== 0 && strpos($str, "$") === false && trim($str) != "") {
               $names[] = trim($str);
            }
            $str = strtok("\n");
         }
         break;

      case "jobstream":
         $names = __tws_backup_parse_name ($text, "SCHEDULE");
         break;

      case "workstation":
         $names = __tws_backup_parse_name ($text, "CPUNAME");
         break;

      case "workstationclass":
         $names = __tws_backup_parse_name ($text, "CPUCLASS");
         break;

      case "domain":
         $names = __tws_backup_parse_name ($text, "DOMAIN");
         break;

      case "resource":
         $str = strtok($text, "\n");
         while ($str !== false ) {
            if(strpos($str, " ") !== 0 && strpos($str, "$") === false && trim($str) != "") {
               $str = substr($str, 0, strpos($str, " "));
               $names[] = trim($str);
            }
            $str = strtok("\n");
         }
         break;

      case "calendar":
         $str = strtok($text, "\n");
         while ($str !== false ) {
            if(strpos($str, " ") !== 0 && strpos($str, "$") === false && trim($str) != "") {
               $names[] = trim($str);
            }
            $str = strtok("\n");
         }
         break;

      case "prompt":
         $str = strtok($text, "\n");
         while ($str !== false ) {
            if(strpos($str, " ") !== 0 && strpos($str, "$") === false && trim($str) != "") {
               $str = substr($str, 0, strpos($str, " "));
               $names[] = trim($str);
            }
            $str = strtok("\n");
         }
         break;

      case "parameter_table":
         $names = __tws_backup_parse_name ($text, "VARTABLE");
         break;

      case "parm":
         $str = strtok($text, "\n");
         while ($str !== false ) {
            if(strpos($str, " ") !== 0 && strpos($str, "$") === false && trim($str) != "") {
               $str = substr($str, 0, strpos($str, " "));
               $str = substr($str, strpos($str, ".")+1);
               $names[] = trim($str);
            }
            $str = strtok("\n");
         }
         break;

      case "evrule":
         $str = strtok($text, "\n");
         while ($str !== false ) {
            if(strpos($str, "<eventRule ") !== false && preg_match('/name=([A-Za-z0-9"_]+)/',$str, $matches)) {
               $names[] = trim($matches[1],'"');
            }
            $str = strtok("\n");
         }
         break;
   }

   return $names;
}

function __tws_backup_parse_name ($text, $what) {     // Not used
   $names = array();
   $str = strtok($text, "\n");
   while ($str !== false ) {
      if(strpos($str, $what) === 0 ) {
         $str = str_replace($what, "", $str);
         $names[] = trim($str);
      }
      $str = strtok("\n");
   }
   return $names;
}



function tws_backup_get_current_content ($objtype, $objname) {
   if ($objtype == "evrule") {$objtype = "erule";}
   $res = "";
   for($i=0; $i<count($objname); $i++) {
      if ($objtype == "jobstream" && strpos($objname[$i],":")!==FALSE) {

         $obj = substr($objname[$i],0, strpos($objname[$i],":"));
         $valid = substr($objname[$i],strpos($objname[$i],":")+1);
         $tws_validfrom = tws_make_iso_valid_from($valid);
         $tws_validfrom=" valid from ".tws_date_from_iso($tws_validfrom);
         //var_dump($valid, $tws_validfrom);
         $res .= tws_composer_create_from("$objtype=".$obj.$tws_validfrom);
      }
      else {
         $res .= tws_composer_create_from("$objtype=".$objname[$i]);
      }
   }
   return $res;
}

function tws_get_sysid_command() {
   global $tws_config,$base_inst_dir;
   switch (strtolower($tws_config['kernel'])) {
      case 'linux'   : return new hwi_cmd('/sbin/ip', 'addr', hwi_cmd::operator('|'), 'grep', 'link/ether', hwi_cmd::operator('|'), 'awk', '{ print $2 }', hwi_cmd::operator('|'), 'head', '-1', hwi_cmd::operator('|'), 'tr', '-d', ':', hwi_cmd::operator('|'), 'tr', 'a-z', 'A-Z');
      case 'aix'     : return new hwi_cmd('uname', '-m');
      case 'hpux'    : return new hwi_cmd('uname', '-i');
      case 'solaris' : case 'solaris2.6' : case 'solaris8' : return new hwi_cmd('hostid');
      case 'win32'   : return new hwi_cmd($base_inst_dir.'/bin/getmac');
   }
   tws_error('tws_config[host_os]=\''.$tws_config['host_os'].'\'; tws_config[kernel]=\''.$tws_config['kernel'].'\'', "Unknown method for getting system ID on given kernel.");
   return FALSE;
}

?>
