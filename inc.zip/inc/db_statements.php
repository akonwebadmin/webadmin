<?php

//
// HORIZONT GmbH, Garmischer Str. 8, D-80339 Muenchen
//

require_once('db_functions.php');



/**
 * Value returned by function fetch when there are no more rows
 */
define ('DB_STATEMENT_NO_ROW', 0);



/**
 * The class db_statement is an extension of db_functions.php. An instance
 * of the class db_statement represents a single database statement with its
 * context. The fact, that the context is stored with the statement, alows
 * to work with more than one statement at a time. The storing and restoring
 * of the statement context is done automaticaly by the functions of the
 * class db_statement.
 */
class db_statement
{
    /**
     * Last ID used for a statement, used for naming statements.
     */
    private static $lastID = 0;

    /**
     * Descriptor of the database connection.
     */
    private $db;

    /**
     * ID of the statement.
     */
    private $id;

    /**
     * The SQL text of the statement, e.g. 'SELECT name FROM person'.
     */
    private $sql;

    /**
     * True if it is a prepared statement.
     */
    private $prepared = false;

    /**
     * True if the statement has been executed.
     */
    private $executed = false;

    /**
     * Result of the statement execution.
     */
    private $result;

    /**
     * Bound statement parameters, for Oracle only.
     */
    private $parameters;

    /**
     * Name of the prepared statement, for PostGreSQL only.
     */
    private $name;

    /**
     * Fetched row.
     */
    private $row = false;

    /**
     * What case the colum names in a fetch row shall have.
     */
    private $upperCase = true;

    /**
     * True case of the column names in a fetched row.
     */
    private $rowUpperCase = true;



    /**
     * Constructor. Creates an instance of the class db_statement.
     *
     * If the optional second parameter is omited, the SQL statement must be
     * initialized in a later call of functions init(), query() or
     * prepare().
     *
     * @param (array) structure used in db_connect from db_functions.php
     * @param (string) SQL statement
     * @param (string | bool) If the value of the parameter is 'lower' or false
     * the column names in a fetched row will be in lower case, otherwise in
     * upper case (default).
     */
    function __construct(&$db, $sql = null, $key_case = null)
    {
        $this->db = &$db;
        if (is_string($sql))
        {
            $this->sql = $sql;
            $this->id = ++db_statement::$lastID;
        }
        $this->upperCase = db_statement::upperCase($key_case);
    }



    /**
     * Destructor. It currently does nothing.
     */
    function __destruct()
    {
        if (isset($this->id))
            unset($this->id);
        if (isset($this->sql))
            unset($this->sql);
        if ($this->row !== false)
            unset($this->row);
        if (isset($this->result))
            unset($this->result);
        if (isset($this->parameters))
            unset($this->parameters);
        if (isset($this->name))
            unset($this->name);
        if (isset($this->db))
            unset($this->db);
    }



    private static function upperCase($key_case)
    {
        return !((is_bool($key_case) && !$key_case)
                 || (is_string($key_case) && $key_case == 'lower'));
    }



    /**
     * Get the statement id.
     *
     * @return (int | bool) internal id, false if not initialized
     */
    public function id()
    {
        if (isset($this->id))
            return $this->id;
        return false;
    }



    /**
     * Get the statement SQL.
     *
     * @return (string | bool) SQL statement, false if not initialized
     */
    public function sql()
    {
        if (isset($this->sql))
            return $this->sql;
        return false;
    }



    /**
     * Initializes the db_statement instance.
     *
     * @param (string) SQL statement
     */
    public function init($sql)
    {
        if (is_string($sql))
        {
            $this->sql = $sql;
            $this->id = ++db_statement::$lastID;
        }
        else if (isset($this->sql))
            unset($this->sql);
        if (isset($this->result))
            unset($this->result);
        if (isset($this->parameters))
            unset($this->parameters);
        if (isset($this->name))
            unset($this->name);
        $this->prepared = false;
        $this->executed = false;
        $this->row = false;
    }



    /**
     * Executes a statement without parameters. If it is a SELECT statement,
     * the rows can be fetched by the fetch() function.
     *
     * If the optional parameter is omited, the SQL text from a previous
     * initialization is being used by the function.
     *
     * @param (string) SQL statement
     * @return (bool) true on success, false on error
     */
    public function query($sql = null)
    {
        if (is_string($sql))
            $this->init($sql);
        $this->prepared = false;
        $this->executed = false;
        $this->row = false;
        if (!isset($this->sql))
        {
            db_last_error('The db_statement is not initialized.');
            return false;
        }
        if (db_query($this->db, $this->sql) === false)
            return false;
        if (isset($this->db['qresult']))
            $this->result = $this->db['qresult'];
        $this->executed = true;
        return true;
    }



    /**
     * Prepare a prepared statement.
     *
     * If the optional parameter is omited, the SQL text from a previous
     * initialization is being used by the function.
     *
     * @param (string) SQL statement
     * @return (bool) true on success, false on error
     */
    public function prepare($sql = null)
    {
        if (is_string($sql))
            $this->init($sql);
        $this->prepared = false;
        $this->executed = false;
        $this->row = false;
        if (!isset($this->sql))
        {
            db_last_error('The db_statement is not initialized.');
            return false;
        }
        if (db_prepare($this->db, $this->sql) === false)
            return false;
        if (isset($this->db['qresult']))
            $this->result = $this->db['qresult'];
        if (isset($this->db['stmt_params']))
            $this->parameters = $this->db['stmt_params'];
        if (isset($this->db['stmt_name']))
            $this->name = $this->db['stmt_name'];
        $this->prepared = true;
        return true;
    }



    /**
     * Execute a prepared statement. The statement must be previously
     * prepared by the call off the function prepare(). The count of
     * values in the parameter must match the count of parameters in
     * the prepared statement.
     *
     * If the optional parameter is omited, the function expects, that
     * the executed statement has no parameters.
     *
     * @param (array | scalar) value(s) of parameter(s) of the statement
     * @return (bool) true on success, false on error
     */
    public function execute($values = array())
    {
        $this->executed = false;
        $this->row = false;
        if (!isset($this->sql))
        {
            db_last_error('The db_statement is not initialized.');
            return false;
        }
        if (!$this->prepared)
        {
            db_last_error('Only prepared statements can be executed.');
            return false;
        }
        if (is_scalar($values))
            $values = array($values);
        else if (!is_array($values))
            $values = array();
        $this->db['stmt_sql'] = $this->sql;
        if (isset($this->result))
            $this->db['qresult'] = $this->result;
        else if (isset($this->db['qresult']))
            unset($this->db['qresult']);
        if (isset($this->parameters))
            $this->db['stmt_params'] = $this->parameters;
        else if (isset($this->db['stmt_params']))
            unset($this->db['stmt_params']);
        if (isset($this->name))
            $this->db['stmt_name'] = $this->name;
        else if (isset($this->db['stmt_name']))
            unset($this->db['stmt_name']);
        if (db_execute($this->db, null, $values) === false)
            return false;
        if (isset($this->db['qresult']))
            $this->result = $this->db['qresult'];
        $this->executed = true;
        $this->row = false;
        return true;
    }



    /**
     * Fetch the next row of a statement result.
     * 
     * The function may return the value DB_STATEMENT_NO_ROW which is a
     * 0 or in a case of an error the value false. So test the result with
     * the === operator.
     *
     * @param (string | bool) If the value of the parameter is null (default)
     * the value of the parameter key_case set in the constructor decides,
     * whether the column names in the fetched row will be upper or lower
     * case. If the value of the parameter is 'lower' or false the column
     * names in the fetched row will be in lower case, otherwise in upper
     * case.
     * @return (bool | int) true if a row has been fetched,
     * DB_STATEMENT_NO_ROW if there are no more rows to be fetched,
     * false on error
     */
    public function fetch($key_case = null)
    {
        $this->row = false;
        if (!isset($this->sql))
        {
            db_last_error('The db_statement is not initialized.');
            return false;
        }
        if (!$this->executed || !isset($this->result))
        {
            db_last_error('Only executed statements can be fetched.');
            return false;
        }
        if ($key_case === null)
            $this->rowUpperCase = $this->upperCase;
        else
            $this->rowUpperCase = db_statement::upperCase($key_case);
        $this->db['qresult'] = $this->result;
        $this->row = db_fetch_row($this->db,
                                  $this->rowUpperCase ? '' : 'lower');
        if ($this->row == false)
        {
            $this->executed = false;
            return DB_STATEMENT_NO_ROW;
        }
        return true;
    }



    /**
     * Get the value at the specified position in the fetched row. The
     * position may be an index (integer, first column has the index 1) or
     * a name of the column (string).
     *
     * @param (int | string) index or name of the requested column
     * @return (string | bool) value in the requested column, false on error
     */
    public function value($pos)
    {
        if (!isset($this->sql))
        {
            db_last_error('The db_statement is not initialized.');
            return false;
        }
        if ($this->row === false)
        {
            db_last_error('Can not get any value. No row fetched.');
            return false;
        }
        $retVal = '';
        if (is_int($pos))
        {
            if ($pos > 0 && $pos <= count($this->row))
            {
                $values = array_values($this->row);
                $retVal = $values[$pos - 1];
            }
            else
            {
                db_last_error('The fetched row does not contain any value '
                              .'at the position '.$pos.'.');
                return false;
            }
        }
        else if (is_string($pos))
        {
            $pos = $this->rowUpperCase ? strtoupper($pos)
                                       : strtolower($pos);
            if (isset($this->row[$pos]))
                $retVal = $this->row[$pos];
            else
            {
                db_last_error('The fetched row does not have any column '
                              .'with the name \''.$pos.'\'.');
                return false;
            }
        }
        return $retVal;
    }



    /**
     * Get the whole fetched row.
     *
     * @return (array | bool) the fetched row, false on error.
     */
    public function row()
    {
        if ($this->row == false)
        {
            db_last_error('No row fetched.');
            return false;
        }
        return $this->row;
    }



    /**
     * Fetch all rows of a statement result.
     *
     * @param (string | bool) If the value of the parameter is null (default)
     * the value of the parameter key_case set in the constructor decides,
     * whether the column names in the fetched row will be upper or lower
     * case. If the value of the parameter is 'lower' or false the column
     * names in the fetched row will be in lower case, otherwise in upper
     * case.
     * @return (array | bool) an array of rows, false on error.
     */
    public function fetch_all($key_case = null)
    {
        $this->row = false;
        if (!isset($this->sql))
        {
            db_last_error('The db_statement is not initialized.');
            return false;
        }
        if (!$this->executed || !isset($this->result))
        {
            db_last_error('Only executed statements can be fetched.');
            return false;
        }
        if ($key_case === null)
            $this->rowUpperCase = $this->upperCase;
        else
            $this->rowUpperCase = db_statement::upperCase($key_case);
        $this->executed = false;
        $this->db['qresult'] = $this->result;
        return db_fetch_all($this->db, $this->rowUpperCase ? '' : 'lower');
    }
}


//replaces all question marks '?' by a unique variable (name starting on $ppref)
function db_adj_stmt($stmt, $ppref) {
    $query = '';
    $last = strlen($stmt) - 1;
    $inStr = FALSE;
    $cntr = 0;
    for ($idx = 0; $idx <= $last; ++$idx)
    {
        $chr = $stmt[$idx];
        if ($inStr)
        {
            $query .= $chr;
            if ($chr == "'")
            {
                if ($idx < $last && $stmt[$idx + 1] == "'")
                    $query .= $stmt[++$idx];
                else
                    $inStr = FALSE;
            }
        }
        else
        {
            if ($chr == '?')
                $query .= $ppref.((string) ++$cntr);
            else
            {
                $query .= $chr;
                if ($chr == "'")
                    $inStr = TRUE;
            }
        }
    }
    return array($query, $cntr);
}

//to prepare (parse, compile) a db statement
function db_prepare(&$db, $stmt) {
    $result = array('stmt_sql' => $stmt);
    switch ($db["type"]) {
    case "db2":
        $options = array('autocommit' => DB2_AUTOCOMMIT_OFF);
        @$res = db2_prepare($db["conn"], $stmt, $options);
        if ($res !== FALSE)
            $db['qresult'] = $result['qresult'] = $res;
        break;
    case "oracle":
        $adjStmt = db_adj_stmt($stmt, ':p');
        @$res = oci_parse($db["conn"], $adjStmt[0]);
        if ($res !== FALSE) {
            $stmtParams = array();
            $cnt = $adjStmt[1];
            for ($idx = 0; $idx < $cnt; ++$idx) {
                $stmtParams[$idx] = '';
                oci_bind_by_name($res, ":p".($idx + 1), $stmtParams[$idx], 2048); //FIXME: 2048?
            }
            $db['qresult'] = $result['qresult'] = $res;
            $db['stmt_params'] = $result['stmt_params'] = $stmtParams;
        }
        break;
    case "pgsql":
        global $lastName;
        if (!isset($lastName))
            $lastName = 0;
        $db['stmt_name'] = (string) (++$lastName);
        $adjStmt = db_adj_stmt($stmt, '$');
        @$res = pg_prepare($db["conn"], $db['stmt_name'], $adjStmt[0]);
        if ($res !== FALSE)
            $result['stmt_name'] = $db['stmt_name'];
        break;
    default:
        db_last_error("Unknown DB type '".$db["type"]."'.");
        return FALSE;
    }
    if ($res === FALSE) { 
      ($e=@db_error($db))===FALSE && $e=array();
      $e['query failed']=$stmt;
      db_last_error($e);
      return FALSE;
    }
    $db['stmt_sql'] = $stmt;
    return $result;
}

//executes an already parsed (compiled, prepared) statement
function db_execute(&$db, $res, $values = array()) {
    /* set $res to the value returned by db_prepare */
    switch ($db["type"]) {
    case "db2":
        if (is_array($res) && isset($res['qresult'])
            && isset($res['stmt_sql'])) {
            $db['qresult'] = $res['qresult'];
            $db['stmt_sql'] = $res['stmt_sql'];
        }
        if (!isset($db['qresult']) || !isset($db['stmt_sql'])) {
            db_last_error('Missing prepare parameters for the DB statement. '
                          .'Execution is not possible.');
            return FALSE;
        }
        @$res = db2_execute($db['qresult'], $values);
        break;
    case "oracle":
        if (is_array($res) && isset($res['qresult'])
            && isset($res['stmt_params']) && isset($res['stmt_sql'])) {
            $db['qresult'] = $res['qresult'];
            $db['stmt_params'] = $res['stmt_params'];
            $db['stmt_sql'] = $res['stmt_sql'];
        }
        if (!isset($db['qresult']) || !isset($db['stmt_sql'])
            || !isset($db['stmt_params'])) {
            db_last_error('Missing prepare parameters for the DB statement. '
                          .'Execution is not possible.');
            return FALSE;
        }
        if (count($db['stmt_params']) != count($values)) {
            db_last_error("Wrong number of parameters for the prepared statement.");
            return FALSE;
        }
        for ($idx = 0; $idx < count($db['stmt_params']); ++$idx)
            $db['stmt_params'][$idx] = (string) $values[$idx];
        @$res = oci_execute($db['qresult'], OCI_DEFAULT);
        break;
    case "pgsql":
        if (is_array($res) && isset($res['stmt_name'])
            && isset($res['stmt_sql'])) {
            $db['stmt_name'] = $res['stmt_name'];
            $db['stmt_sql'] = $res['stmt_sql'];
        }
        if (!isset($db['stmt_name']) || !isset($db['stmt_sql'])) {
            db_last_error('Missing prepare parameters for the DB statement. '
                          .'Execution is not possible.');
            return FALSE;
        }
        @$res = pg_execute($db['stmt_name'], $values);
        if ($res !== FALSE) {
            $db['qresult'] = $res;
            $res = TRUE;
        }
        break;
    default:
        db_last_error("Unknown DB type '".$db["type"]."'.");
        return FALSE;
    }
    if (!$res) { 
      ($e=@db_error($db))===FALSE && $e=array();
      $e['query failed']=$db['stmt_sql'];
      $e['query values']=$db['stmt_params'];
      db_last_error($e);
    }
    return $res;
}


function hos_db_prep_query_sql (&$db, $sql, $parms = array (), $file = '', $line = '') {
    $stmt_id = hos_db_prep ($db, $sql, $file, $line);    
    if ($stmt_id === false)
        return false;              

    return hos_db_prep_query_id ($db, $stmt_id, $parms, $file, $line);       
}


function hos_db_prep_query_id (&$db, $stmt_id, $parms = array (), $file = '', $line = '') {
   
    if (false === $stmt_id->execute ($parms)) {
        $txt = wai_get_text ('DBExecute');
        $err = db_error ($db);
       
        if ($err !== false && isset ($err ['message']) && $err ['message'] != '')              
            $txt .= "\n ".wai_get_text ('Response').": ".$err ['message'];           
        if ($err !== false && isset ($err ['code']) && $err ['code'] != '')                 
            $txt .= "\n ".wai_get_text ('Code').": ".$err ['code'];
                           
        $txt .= "\n ".wai_get_text ('Query').": ".$stmt_id->sql ();
        $txt .= "\n ".wai_get_text ('Used parameters').":";
        $txt .= "\n ".hos_db_parm_dump ($parms);
       
        wai_error ("ERROR", $txt, $file, $line, 4);
        return false;
    }
    return true;   
}


function hos_db_prep (&$db, $sql, $file = '', $line = '') {
    $c_stmt = new db_statement ($db, $sql);
    if (false === $c_stmt->prepare ()) {
        $txt = wai_get_text ('DBPrepare');
        $err = db_error ($db);
        if ($err !== false && isset ($err ['message']) && $err ['message'] != '')
            $txt .= "\n ".wai_get_text ('Response').": ".$err ['message'];
       
        $txt .= "\n ".wai_get_text ('Query').": ".$sql;
        wai_error ("ERROR", $txt, $file, $line, 4);      
        return false;
    }
    return $c_stmt;
}


function hos_db_parm_dump ($a) {
    $str = "";
    foreach ($a as $key => $value)
        $str .= "[$key] => $value\n";
    return $str;
}

?>
