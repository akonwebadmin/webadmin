<?php
//   HORIZONT Software GmbH, Munich
//

///////////////////////////////////////////////////////////////////////////////
//
//       Folders functions
//

// Get all folders under mask into $res array
// arguments: folder_mask
// e.g used to show folders list in DB section
// return:
function tws_get_folders($arg='@', $xfilter='1=1') {
   global $tws_config, $composer_db;

   $arg = str_replace('*', '@', $arg);
   $xfilter = str_replace('*', '@', $xfilter);

   tws_log('-- tws_get_folders -- start with params: '. "arg = $arg, xfilter = $xfilter");

   if($xfilter == '1=1' && strpos($arg, '/') === false)
      if($arg != '@')
         $arg = '/'.$arg.'/';
      else $arg = '/'.$arg;
   $res=array();
   $res['folder_num']=0;

//access rights checking
// TODO:
//   if (($acc_sql=tws_sec_check('FOLDER', array('NAME'=>'FOL_NAME'), ''))===FALSE) return $folders;

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=$composer_db["schema"];
   $hex_fce = ($composer_db['type']=='db2' ? 'HEX' : 'RAWTOHEX');

   $query ="
      SELECT
         $hex_fce(FOL_ID) FOL_ID,
         FOL_PATH,
         FOL_MODIFY_OWNER,
         FOL_MODIFY_TIME,
         FOL_LOCK_OWNER,
         FOL_LOCK_TIME
      FROM
         $schema.FOL_FOLDERS
      WHERE
         FOL_PATH ".tws_sqllike(db_string($composer_db, $arg))." AND
         FOL_CANC_PENDING != 'Y' AND
         $xfilter";

   tws_log('-- get_db_folders -- DB query: '.$query);
   if( !($r=db_query($composer_db,$query)) ){
      tws_log('Error: Database query failed');
      tws_error('', 'Database query failed');
      return FALSE;
   }

   while ($row = db_fetch_row($composer_db)) {
      // tws_log(var_export($row, true));

      $res['folder_num']++;
      $res['folder_id'][] = $row['FOL_ID'];
      $res['folder_path'][] = $row['FOL_PATH'];
      $res['folder_creator'][] = $row['FOL_MODIFY_OWNER'];
      $res['folder_last_updated'][] = $row['FOL_MODIFY_TIME'];
      $res['folder_lock_by'][] = $row['FOL_LOCK_OWNER'];
      $res['folder_lock_time'][] = $row['FOL_LOCK_TIME'];
   }
   // tws_log('-- get_db_folders -- Results: ' . var_export($res, true));
   return $res;
}


// divide folder and object name
// Parameter: $name - e.g. /FOLDER1/SUBFOLDER1/JOB1
// Return: array (folder name, object_name)
function tws_divide_folder($name){
   global $tws_config, $composer_db;

   $name = strtoupper($name);
   tws_log("-- tws_divide_folder. Patameter: $name");

   $pos = strrpos($name, '/');

// no folder
   if( $pos === false){
      $res = array("", $name);
      tws_log("-- tws_divide_folder. No folder. Return: ".var_export($res, true));
      return $res;
   }
// folder exist
   $folder_name = substr($name, 0, $pos+1);
      $res = array($folder_name, substr($name, $pos+1));
      tws_log("-- tws_divide_folder. Folder exist. Return: ".var_export($res, true));
      return $res;
}

function tws_divide_dbfield_folder($field_name){

   $pos = strrpos($field_name, '/');

// no folder
   if( $pos === false){
      $res = array("", $field_name);
      return $res;
   }
// folder exist
   $folder_name = substr($field_name, 0, $pos);
      $res = array($folder_name, substr($field_name, $pos+1));
      return $res;
}

// -- tws_get_job_folder
//
// Arg: '/folder_name/stream_name'
// wildecards not allowed
// Return stream_name
// Set global $folder_name, $folder_id (in hex), folder_expression to use in select (such as xfilter
// )
function tws_get_job_folder($name){
   global $tws_config, $composer_db;
   global  $job_folder_expr, $job_folder, $job_folder_id; // tws 9.5 folders:

   $name = strtoupper($name);
   tws_log("-- tws_get_job_folder. Patameter: $name");
   // tws 9.5 folders:
   $job_folder_expr = $job_folder = $job_folder_id = '';

   // TODO: list($job_folder, $job_name) = tws_explode_folder($name); instead of below
   $pos = strrpos($name, '/');
   if($pos === false)
      return $name;
//       folder exist
   $job_name = substr($name, $pos+1);
   $job_folder = substr($name, 0, $pos+1);

   tws_log("-- tws_get_job_folder: job_folder = $job_folder, job_name = $job_name");

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema = $composer_db['schema'];
   $hex_fce = ($composer_db['type']=='db2' ? 'HEX' : 'RAWTOHEX');

   $query = "
      SELECT
      $hex_fce ($schema.FOL_FOLDERS.FOL_ID) FOL_ID
      FROM $schema.FOL_FOLDERS
      WHERE FOL_PATH = '$job_folder'
   ";
   tws_log("-- tws_get_job_folder DB query: $query");
   if (!($r=db_query($composer_db, $query))) {
      tws_error('', 'Database query failed');
      return false;
   }
   $row = db_fetch_row( $composer_db );
   if(empty($row)){
      tws_error('No qualified entries');
      return false;
   }
   tws_log("-- Result: ". var_export($row, true));
   $job_folder_id = ($composer_db['type']=='db2' ? "x'".$row['FOL_ID']."'" : "HEXTORAW('".$row['FOL_ID']."')");
   $job_folder_expr = "
      AND JOD.FOL_ID = $job_folder_id";

   return $job_name;
}

// divide last part of $folder
// 'Last part' may be folder name, job, or jobstream
// return array($folder_path, $name)
// if $folder not exist - return array('', $folder)

function tws_explode_folder($folder){
   global $tws_config;

   tws_log("-- tws_explode_folder. Patameter: $folder");
   // tws 9.5 folders:
   $pos = strrpos($folder, '/');
   if($pos === false)
      return (array('', $folder));  // empty folder path

// folder exist
   $folder_path = substr($folder, 0, $pos+1);
   $folder_name = substr($folder, $pos+1);
   return (array($folder_path, $folder_name));
}

// object name with folder
function tws_get_object_id($object_type, $object_name){
   global $tws_config, $composer_db;

   $object_type = strtolow($object_type);
   tws_log("-- get_object_id. Patameters: $object_type, $object_name");

   switch($object_type){
      case 'jobstream':
         $object_id = tws_get_jobstream_id($object_name);
         break;
      case 'job':
         $object_id = tws_get_job_id($object_name);
         break;
   }
   return $object_id;
}

// TODO: comment !

function tws_get_jobstream_folder($name){
   global $tws_config, $composer_db;
   global  $jobstream_folder_expr, $jobstream_folder, $jobstream_folder_id; // tws 9.5 folders:
         $jobstream_folder_expr = $jobstream_folder = $jobstream_folder_id = '';

   $name = strtoupper($name);
   tws_log("-- tws_get_jobstream_folder. Patameter: $name");

   // TODO: list($jobstream_folder, $jobstream_name) = tws_explode_folder($name); instead of below
   $pos = strrpos($name, '/');
   if( $pos === false)
      return '';  // no folder
//       folder exist
   $jobstream_folder = substr($name, 0, $pos+1);
   $jobstream_name = substr($name, $pos+1);

   tws_log("-- tws_get_jobstream_folder. pos = $pos, jobstream_folder = $jobstream_folder, jobstream_name = $jobstream_name");

      $dbh = db_connect($composer_db,DB_PERSISTENT);
      if( !$dbh ){
         tws_error('', 'Cannot connect to database');
         return FALSE;
      }
      $schema = $composer_db['schema'];
      $hex_fce = ($composer_db['type']=='db2' ? 'HEX' : 'RAWTOHEX');

      $query = "
         SELECT
         $hex_fce ($schema.FOL_FOLDERS.FOL_ID) FOL_ID
         FROM $schema.FOL_FOLDERS
         WHERE FOL_PATH " . tws_sqllike(db_string($composer_db, $jobstream_folder));
      tws_log("-- tws_get_jobstream_folder DB query: $query");
      if (!($r=db_query($composer_db, $query))) {
         tws_error('', 'Database query failed');
         return false;
      }
      $row = db_fetch_row( $composer_db );
      if(empty($row)){
         tws_error('No qualified entries');
         return false;
      }
      tws_log("-- Result: ". var_export($row, true));
      //$jobstream_folder_id = $row['FOL_ID'];
      $jobstream_folder_id = ($composer_db['type']=='db2' ? "x'".$row['FOL_ID']."'" : "HEXTORAW('".$row['FOL_ID']."')");
      $jobstream_folder_expr = " AND AJS.FOL_ID = $jobstream_folder_id";

   return $jobstream_name;
}

function zli_get_folder_id($obj_name){

   list($folder_name, $obj_name) = tws_divide_folder($obj_name);

   $res = tws_get_folders($folder_name);
         // tws_get_folders f-ce get '$folder_name' parameter as 'LIKE', so we need to check list under name
   if($res['folder_num'] == 0){
      tws_error("zli_get_folder_id: Can't get folders list for folder $folder_name");
      return false;
   }
   foreach($res['folder_id'] as $folder_id => $i){
      if($res['folder_path'] == $folder_name)
         break;
   }
   return $folder_id;
}
?>
