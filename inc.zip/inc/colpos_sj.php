<?php
//   HORIZONT Software GmbH, Munich
//

   $col[1]=2;           //cpu
   $len[1]=16;
   $col[2]=19;          //stream
   $len[2]=16;       
   $col[3]=36;          //schedtime
   $len[3]=10;
   $col[4]=47;          //job
   $len[4]=40;
   $col[5]=88;          //state
   $len[5]=5;
   $col[6]=94;          //Pr
   $len[6]=2;
   $col[7]=96;          //Start
   $len[7]=7;
   $col[8]=103;         //Elapse
   $len[8]=7;
   $col[9]=111;         //Return Code
   $len[9]=11;
   $col[10]=122;        //Deps
   $len[10]=901;
   $colspecial[1]=45;   
   $colspecial[2]=29;
   $lenspecial[2]=16;
   $lenspecial[3]=14;
 
   $logon_col[5]=88;     //job status
   $logon_len[5]=5; 
   $logon_col[6]=94;     //jobnum
   $logon_len[6]=10; 
   $logon_col[7]=104;    //logon
   $logon_len[7]=12; 
   $logon_col[8]=124;    //exit_code
   $logon_len[8]=10; 

   $script_col[4]=88;    //jcl
   $script_len[4]=255;   
   $script_col[5]=111;   //recovery option
   $script_len[5]=2;
   $script_col[6]=114;   //recovery job
   $script_len[6]=18;
   $script_col[7]=132;   //recovery prompt
   $script_len[7]=10;
?>