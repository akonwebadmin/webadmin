<?php
//   HORIZONT Software GmbH, Munich
//

$col[1]=2;
$len[1]=4;
$col[2]=8;
$len[2]=1015;
?>