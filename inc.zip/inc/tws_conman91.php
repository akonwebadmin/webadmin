<?php
//   HORIZONT Software GmbH, Munich
//


/**
 * Gets the list of plan workstations (and their status attrs)
 *
 * @param string $arg Workstation name or filter (see doc to ss)
 * DB has current Symphony only
 *
 * @return array List of workstations or FALSE when fail
 */
function tws_get_plan_workstation_db($arg, $page_size=0, $page=1, $od_callback=null){
   global $tws_config, $composer_db;

   tws_log('-- tws_get_plan_workstation_list (start at '.basename(__FILE__).'['.__LINE__.'])');

   $arg = strtr($arg,'*','@');
   //$arg = strtr($arg,'!','#');

   list ($filter, $keys) = tws_planfilter_explode_keys($arg, '!');
   $sqlfilter = tws_dbfilter_where ($filter, 'PDOM_NAME', 'PWKS_NAME');

   if ($sqlfilter === false)
      tws_dyer('Wrong filter format');

   $filterchunk = array();
   $filterchunk = explode('+',$keys);
   for ($i=0; $i<count($filterchunk); $i++) {
      if (substr($filterchunk[$i],0,6) == "types=") {
         $junk=strtok($filterchunk[$i],"=");
         $types=strtok("\n");
      } elseif (substr($filterchunk[$i],0,3) == "os=") {
         $junk=strtok($filterchunk[$i],"=");
         $oss=strtok("\n");
      } elseif (substr($filterchunk[$i], 0, 7) == 'states=') {
         $junk = strtok($filterchunk[$i], '=');
         $states = strtok("\n");
      }
   }
   if(!empty($types))
      $sqlfilter  .= " AND " . tws_dbfilter_where ($types, 'WKS_AGENT_TYPE');
   if(!empty($oss))
      $sqlfilter  .= " AND " . tws_dbfilter_where ($oss, 'WKS_OPERATING_SYSTEM');
   if(!empty($states))
      $xfilter  .= " AND " . tws_dbfilter_where ($types, 'WKS_STATE');

/*    TODO ???
   if(isset($action) && $action == 'Send as CSV'){
      include "tws_send_as_csv.php";
      tws_send_db_as_csv('workstation', $sqlfilter);
      exit;
   }
*/
   if(trim($sqlfilter)=='') $sqlfilter="1=1";

   $ws = array();
   $ws['cpu_num']=0;
   $oc=($od_callback!==null);

//access rights checking
   if (($acc_sql=tws_sec_check('CPU', array('CPU'=>'PWKS_NAME')))===FALSE) return $workstations;

// LIMIT-OFFSET   TODO
/* if ($page_size > 0)
      $offset = ($page-1) * $page_size;
*/
   $dbh = db_connect($composer_db, DB_PERSISTENT);
   if (!$dbh) {
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   if($composer_db['type'] == 'oracle')
      $schema=$composer_db["schema"];
   else $schema = 'PLN';

   $query ="
      SELECT
         PWKS_NAME,
         PDOM_NAME,
         PWKS_AGENT_TYPE,
         PWKS_OPERATING_SYSTEM,
         PWKS_ACCESS_METHOD,
         PWKS_FENCE,
         PWKS_LIMIT,
         PWKS_SYM_RUN_NUMBER,
         PWKS_START_TIME,
         PWKS_INITIALIZED,
         PWKS_JOBMAN_UP,
         PWKS_LINK_STATUS,
         PWKS_APPLICATION_SRV_STATUS,
         PWKS_WRITER_UP,
         PWKS_EVT_PROC_RUNNING,
         PWKS_USER_INFO,
         PWKS_VERSION
      FROM
         ( $schema.PWKS_WORKSTATIONS PWKS LEFT JOIN $schema.PDOM_DOMAINS PDOM ON PWKS.PDOM_ID=PDOM.PDOM_ID )
      WHERE
         $sqlfilter
         $acc_sql
      ORDER BY PWKS_NAME";

   tws_log('DB query: '.$query);
   if (!($r=db_query($composer_db,$query))) {
      tws_log('Error: Database query failed');
      tws_error('', "Database query failed");
      return FALSE;
   }

   while ($row = db_fetch_row($composer_db)) {
      tws_log(@var_export($row, true));

      $res['cpu_num']++;
      $ws['cpu_num']++;

      $ws['cpu']       = $row['PWKS_NAME'];
      $ws['domain']    = $row['PDOM_NAME'];
      $ws['run']       = $row['PWKS_SYM_RUN_NUMBER'];
      $ws['node']      = $row['PWKS_NODE_NAME'];
      $ws['node_os']   = $row['PWKS_OPERATING_SYSTEM'];
      $ws['node_type'] = $row['PWKS_AGENT_TYPE'];
      $ws['limit']     = $row['PWKS_LIMIT'];
      $ws['fence']     = $row['PWKS_FENCE'];
      $ws['method']    = $row['PWKS_ACCESS_METHOD'];     // TODO
      list ($ws['date'], $ws['time']) = explode(' ', $row['PWKS_START_TIME']);
      $ws['date'] = tws_userdate_to_conman(tws_iso_to_userdate($ws['date'], null, true));
      $ws['time'] = substr($ws['time'], 0, 5);
      $ws['user_info']  = $row['PWKS_USER_INFO'];
      $ws['version'] = $row['PWKS_VERSION'];

      switch ($row['PWKS_OPERATING_SYSTEM']){
         case 'U': $ws['node'] = 'UNIX'; break;
         case 'W': $ws['node'] = 'WIN'; break;
         case 'O': $ws['node'] = 'OTHR'; break;
      }
      switch ($row['PWKS_AGENT_TYPE']){
         case 'M': $ws['node'] .= ' MASTER'; break;
         case 'A': $ws['node'] .= ' AGENT'; break;
         case 'B': $ws['node'] .= ' BROKER'; break;
         case 'X': $ws['node'] .= ' X-AGENT'; break;
      }

      $ws['state'] = '';
      if($row['PWKS_INITIALIZED'] == 'Y')
         $ws['state'] .= 'I';
      if($row['PWKS_JOBMAN_UP'] == 'Y')
         $ws['state'] .= 'J';
      if($row['PWKS_LINK_STATUS'] != 'N')
         $ws['state'] .= $row['PWKS_LINK_STATUS'];
      if($row['PWKS_APPLICATION_SRV_STATUS'] != 'N')
         $ws['state'] .= 'A';
      if($row['PWKS_WRITER_UP'] == 'Y')
         $ws['state'] .= 'W';
      if($row['PWKS_EVT_PROC_RUNNING'] == 'Y')
         $ws['state'] .= 'E';


      if ($oc){
         $od_callback($ws);
      }
      else{
         foreach ($ws as $key=>$val){
            // ?? if($key != 'cpu_num')
               $res[$key][]=$val;
         }
      }
   }
   tws_log('-- get_db_workstations_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
   return $res;
}


/**
 * Gets the list of plan domains (and their status attrs)
 *
 * @param string $arg Domain name or filter (see doc to ss)
 * @param int $symphony Sympony file number (0 for current plan - see doc for setsym, listsym)
 * @return array List of domains or FALSE when fail
 */
function tws_get_plan_domain_db($arg, $page_size = 0, $page = 1) {
   global $tws_config, $composer_db;

   $domains=array();
   $domains['domain_num']=0;

   tws_log('-- tws_get_plan_domain_list (start at '.basename(__FILE__).'['.__LINE__.'])');

   $arg = strtr($arg,'*','@');
   $xfilter  = tws_dbfilter_where ($arg, 'PDOM_NAME');

   //access rights checking
   if (($acc_sql=tws_sec_check('CPU', array('CPU'=>'PDOM_NAME'), '', $action))===FALSE) return $domains;

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }

   if($composer_db['type'] == 'oracle')
      $schema=$composer_db["schema"];
   else $schema = 'PLN';

   $query ="
   SELECT
      PDOM_NAME,
      PDOM_MANAGER_NAME,
      PDOM_PARENT_NAME
   FROM $schema.PDOM_DOMAINS
   WHERE $xfilter
         $acc_sql
   ORDER BY PDOM_NAME";

   tws_log('DB query: '.$query);

   if (!($r=db_query($composer_db,$query))) {
      tws_log('Error: Database query failed');
      tws_error('', 'Database query failed');
      return FALSE;
   }
   $domain_num=0;
   while ($row = db_fetch_row($composer_db)) {
      tws_log(@var_export($row, true));
      $domain_num++;
      $domains['domain_num'] = $domain_num;
      $domains['domain'][$domain_num]    = $row['PDOM_NAME'];
      $domains['manager'][$domain_num]   = $row['PDOM_MANAGER_NAME'];
      $domains['parent'][$domain_num]    = $row['PDOM_PARENT_NAME'];
   }
   tws_log('-- tws_get_plan_domain_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
   return $domains;
}


/**
 * Gets the list of plan jobstreams (and their status attrs)
 *
 * @param string $arg Jobstream name or filter (see doc to ss)
 * @param int $symphony Sympony file number (0 for current plan - see doc for setsym, listsym)
 * @return array List of jobstreams or FALSE when fail
 */
function tws_get_plan_jobstream_db($arg, $page_size = 0, $page = 1, $od_callback=null) {
   global $tws_config, $composer_db;

   tws_log('-- tws_get_plan_jobstream_list (start at '.basename(__FILE__).'['.__LINE__.']), arg=\''.$arg.'\' symphony=\''.$symphony.'\'');

   if (($acc_sql=tws_sec_check('SCHEDULE', array('CPU'=>'PJST.PWKS_NAME','NAME'=>'PJST.PJST_NAME')))===FALSE) return $jobstreams;

   $arg = strtr($arg,'*','@');

   // EXPLODE FILTERS

   list($arg, $keys) = tws_planfilter_explode_keys ($arg);
   // extract all extended filters in $extf
   $extf=tws_ext_plan_filters($keys, $tmp_arg);

   // explode keys
   if ( preg_match_all('/[+~][a-z]+=[^+~]+/',$keys, $arr)){
      foreach($arr[0] as $key=>$val){
         list($key, $val) = explode('=', $val);
         if(empty($extf[$key]))
            $extf[$key] = $val;
         else $extf[$key] .= ", $val";
      }
   }

   $sqlfilter = '';
   if($arg != '@#@'){
      // extract (sched_time)
      if(preg_match('/(.+)\((.+)\)/', $arg, $match)){
         $arg = $match[1];
         $extf['+schedtime'] = $match[2];
      }
      $sqlfilter = tws_dbfilter_where ($arg, 'PJST.PWKS_NAME', 'PJST.PJST_NAME');
   }

var_dump($extf);

   if(isset($extf['xstate']) || isset($extf['-xstate']) || isset($extf['+state']) || isset($extf['~state']) ){
      if(isset($extf['xstate']))       $key = 'xstate';
      elseif(isset($extf['-xstate']))  $key = '-xstate';
      elseif(isset($extf['+state']))  $key = '+state';
      elseif(isset($extf['~state']))  $key = '~state';
      $val = $extf[$key];

      if( strpos($val, 'hold')!== false)
         $val .= ',W';
      $val = str_replace('succ', 'O', $val);
      $val = str_replace('stuck', 'B', $val);
      $val = str_replace('ready', 'R', $val);
      $val = str_replace('exec', 'S', $val);
      $val = str_replace('abend', 'E', $val);
      $val = str_replace('cancl', 'C', $val);
      $val = str_replace('hold', 'H', $val);
      $val = str_replace('cancelled', 'C', $val);

      $extf[$key] = $val;
   }

   $df = tws_profile('date_format');
   if ($df == "") $df = 'm/d/Y';
   $today = date($df)." 00:00";
   $tomorrow = date($df, strtotime("+1 day"))." 00:00";
   $yesterday = date($df, strtotime("-1 day"))." 00:00";
   $utc_offset = date('Z'); // Timezone offset in seconds

   $rel_format = array(
      'TODAY' => $today,
      'TOMORROW' => $tomorrow,
      'YESTERDAY' => $yesterday
   );
var_dump($rel_format);
   // Workload Application filter
   if(!empty($extf['xapp'])){
      $app_data = tws_get_app_data($extf['xapp']);
      if(!empty($app_data['jobstream']) && empty($extf['xstream'])) $extf['xstream'] = '';
      foreach($app_data['jobstream'] as $i=>$js){
         if(!empty($extf['xstream'])) $extf['xstream'] .= ",";
         $extf['xstream'] .= $app_data['workstation'][$i]."#".$app_data['jobstream'][$i];
      }
      unset($extf['xapp']);
   }

   foreach($extf as $key=>$val){
      if(!empty($sqlfilter)) $sqlfilter .= ' AND ';

      switch ($key){
         case 'xstream':
            $sqlfilter  .= tws_dbfilter_where ($extf['xstream'], 'PJST.PWKS_NAME', 'PJST.PJST_NAME');
            break;
         case '-xstream':
            $sqlfilter  .= tws_dbfilter_where ('~'.$extf['-xstream'], 'PJST.PWKS_NAME', 'PJST.PJST_NAME');
            break;

         case '-xstate':
         case '~state':
            $sqlfilter .= tws_dbfilter_where ('~'.$val, 'PJST.PJST_STATUS');
            break;
         case 'xstate':
         case '+state':
            $sqlfilter .= tws_dbfilter_where ($val, 'PJST.PJST_STATUS');
            break;

         case '+follows':  // => '@#@test'
            $sqlfilter .= tws_dbfilter_where ($val, 'DEPS.JOB_STREAM_PRED_WKS_NAME', 'DEPS.JOB_STREAM_PRED_NAME');
            break;
         case 'xfollows':     // PC90#DEMO_TEST4;0AAAAAAAAAAAACUF.@
            $arr = explode(',', $val);
            foreach($arr as $val){
               if(preg_match('/.+;(.+)\..+/', $val, $match) )
                  $sqlfilter .= tws_dbfilter_where ($match[1], 'PJST2.JSI_SYM_ID') .' AND ';
            }
            $sqlfilter = substr($sqlfilter,0, -5);
            break;

         case '+schedtime':   //  => 'TODAY'

            list($from, $to) = explode(',', $val);
            if(!empty($rel_format[$from])) $from = $rel_format[$from];
            if(!empty($rel_format[$to])) $to = $rel_format[$to];
            if(!empty($from)) $from = " PJST.PJST_SCHEDULED_TIME >= '". tws_userdate_to_iso($from)."'";
            if(!empty($to)) $to = " PJST.PJST_SCHEDULED_TIME < '". tws_userdate_to_iso($to)."'";
            if(!empty($from) && !empty($to)) $sqlfilter .= "$from AND $to";
            else $sqlfilter .= $from . $to;

/*
            list($lt,$ht)=explode(',', $val);
            if (!isset($ht)) {
               if ($lt=strtotime(($iso=tws_userdate_to_iso($lt))===FALSE ? trim($lt) : $iso))
                  $ht=$lt+86400;
            }
            else {
               $lt=strtotime(($iso=tws_userdate_to_iso($lt))===FALSE ? trim($lt) : $iso);
               $ht=strtotime(($iso=tws_userdate_to_iso($ht))===FALSE ? trim($ht) : $iso);
            }
            $lt -= $tz_offset;
            $ht -= $tz_offset;
            $lt = " PJST.PJST_SCHEDULED_TIME >= '". date("Y-m-d H:i:s", $lt). "'";
            $ht = " PJST.PJST_SCHEDULED_TIME < '". date("Y-m-d H:i:s", $ht). "'";
            $sqlfilter .= "$lt AND $ht";
*/
            break;
         case '+started':     // =>  '1311 10/01/2014,'
            list($from, $to) = explode(',', $val);
            if(!empty($from)) $from = " PJST.PJST_ACTUAL_START_TIME >= '". tws_userdate_to_iso($from)."'";
            if(!empty($to)) $to = " PJST.PJST_ACTUAL_START_TIME < '". tws_userdate_to_iso($to)."'";
            if(!empty($from) && !empty($to)) $sqlfilter .= "$from AND $to";
            else $sqlfilter .= $from . $to;
            break;
         case '+finished':    // => ',1026 2014/10/02'
            list($from, $to) = explode(',', $val);
            if(!empty($from)) $from = " PJST.PJST_ACTUAL_END_TIME => '". tws_userdate_to_iso($from)."'";
            if(!empty($to)) $to = " PJST.PJST_ACTUAL_END_TIME < '". tws_userdate_to_iso($to)."'";
            if(!empty($from) && !empty($to)) $sqlfilter .= "$from AND $to";
            else $sqlfilter .= $from . $to;
            break;
         case '+priority':    // => ',9'
            list($from, $to) = explode(',', $val);
            if(!empty($from)) $from = "PJST.PJST_PRIORITY >= $from";
            if(!empty($to)) $to = "PJST.PJST_PRIORITY <= $to";
            if(!empty($from) && !empty($to)) $sqlfilter .= "$from AND $to";
            else $sqlfilter .= $from . $to;
            break;
         case '+needs':       // => 'TEST_MASTER#res1'
            $sqlfilter .= tws_dbfilter_where ($val, 'RES_DEP.RESOURCE_WKS_NAME', 'RES_DEP.RESOURCE_NAME');
            break;
         case '+opens':       // => '@#c:/@.@ -d'
            $sqlfilter .= tws_dbfilter_where ($val, 'FILE_DEP.FILE_WKS_NAME', 'FILE_DEP.FILE_NAME');
            break;
         case '+prompt':      // => '1'
            $arr = explode(',', $val);
            $sqlfilter .= '(';
            foreach($arr as $val){
               $sqlfilter .= tws_dbfilter_where ($val, 'PROMPT_DEP.PROMPT'). ' OR ' ;
               $sqlfilter .= tws_dbfilter_where ($val, 'PROMPT_DEP.PROMPT_NUMBER'). ' OR ' ;
            }
            $sqlfilter = substr($sqlfilter,0, -4);
            $sqlfilter .= ')';
            break;
      }
   }
   if(empty($sqlfilter)) $sqlfilter = '1=1';
   var_dump($sqlfilter);


   $oc=($od_callback!==null);

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_log('Error: Cannot connect to database');
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   if($composer_db['type'] == 'oracle')
      $schema=$composer_db["schema"];
   else $schema = 'PLN';

   $query ="
   SELECT
      PJST.PWKS_NAME,
      PJST.PJST_NAME,
      PJST.PJST_SCHEDULED_TIME,
      PJST.PJST_STATUS,
      PJST.PJST_PRIORITY,
      PJST.PJST_LIMIT,
      PJST.PJST_ACTUAL_START_TIME,
      PJST.PJST_EARLIEST_START_TIME,
      PJST.PJST_ESTIMATED_DURATION,
      PJST.PJST_TOTAL_ELAPSED_TIME,
      PJST.PJST_TOTAL_JOBS,
      PJST.PJST_SUCCESSFUL_JOBS,
      PJST.JSI_SYM_ID,
      PJST.PJST_LATE,
      PJST.PJST_RELEASED,
      PJST.PJST_UNTIL_EXPIRED,
      PJST.PJST_UNTIL_TIME,
      PJST.PJST_CARRIED_FORWARD,
      PJST.PJST_CARRY_FORWARD,
      PJST.PJST_DEADLINE_TIME,
      PJST.PJST_DEADLINE_FLAG,
      DEPS.JOB_STREAM_PRED_WKS_NAME,
      DEPS.JOB_STREAM_PRED_NAME,
      DEPS.JOB_STREAM_PRED_SCHED_TIME,
      DEPS.JOB_PRED_JS_WKS_NAME,
      DEPS.JOB_PRED_JS_NAME,
      DEPS.JOB_PRED_NAME,
      DEPS.JOB_PRED_JS_SCHED_TIME,
      DEPS.SATISFIED DEPS_SATISFIED,
      PJST2.JSI_SYM_ID DEP_SYM_ID,
      PJST2.PJST_STATUS DEP_STATUS,
      FILE_DEP.FILE_WKS_NAME,
      FILE_DEP.FILE_NAME,
      FILE_DEP.SATISFIED FILES_SATISFIED,
      FILE_DEP.STATUS FILES_STATUS,
      PROMPT_DEP.PROMPT,
      PROMPT_DEP.PROMPT_NUMBER,
      PROMPT.STATUS PROMPT_STATUS,
      RES_DEP.RESOURCE_WKS_NAME,
      RES_DEP.RESOURCE_NAME,
      RES_DEP.QUANTITY_DEFINED,
      RES_DEP.SATISFIED RES_SATISFIED,
      RES_DEP.QUANTITY_AVAILABLE
   FROM $schema.PJST_JOB_STREAMS PJST
         LEFT JOIN $schema.PLAN_JOB_STREAM_PREDECESSORS_V DEPS on PJST.PJST_ID = DEPS.JOB_STREAM_ID
            LEFT JOIN $schema.PJST_JOB_STREAMS PJST2 ON DEPS.JOB_STREAM_PRED_ID = PJST2.PJST_ID
         LEFT JOIN $schema.PLAN_PROMPT_REFS_V PROMPT_DEP on PJST.PJST_ID = PROMPT_DEP.JOB_STREAM_REFS_ID AND PROMPT_DEP.JOB_REFS_ID IS NULL
            LEFT JOIN $schema.PLAN_PROMPTS_V PROMPT on PROMPT_DEP.PROMPT_ID = PROMPT.PROMPT_ID
         LEFT JOIN $schema.PLAN_FILE_REFS_V FILE_DEP on PJST.PJST_ID = FILE_DEP.JOB_STREAM_REFS_ID AND FILE_DEP.JOB_REFS_ID IS NULL
         LEFT JOIN $schema.PLAN_RESOURCE_REFS_V RES_DEP on PJST.PJST_ID = RES_DEP.JOB_REFS_STREAM_ID AND RES_DEP.JOB_REFS_ID IS NULL
   WHERE $sqlfilter
         $acc_sql
   ORDER BY PJST.PJST_SCHEDULED_TIME, PJST.JSI_SYM_ID";


   $db_status = array(
      'O' => 'SUCC',
      'B' => 'STUCK',
      'W' => 'HOLD',
      'H' => 'HOLD',
      'R' => 'READY',
      'S' => 'EXEC',
      'E' => 'ABEND',
      'C' => 'CANCL'
   );

   $pr_ststus = array(
      'N' => 'NO',
      'T' => 'INACT',
      'O' => 'INACT',
      'U' => 'INACT'
   );

   tws_log('DB query: '.$query);

   if (!($r=db_query($composer_db,$query))) {
      tws_log('Error: Database query failed');
      tws_error('', 'Database query failed');
      return FALSE;
   }

   $jobstreams=array();
   $jobstreams['nrows']=0;
   $res['nrows'] = 0;
   $jobstreams['schedid'][1] = '';

   while ($row = db_fetch_row($composer_db)) {
      tws_log(@var_export($row, true));

      if($jobstreams['schedid'][1] != $row['JSI_SYM_ID'] ){
         // new jobstream began - return old one
         if( !empty($jobstreams['schedid'][1])){
            if ($oc)
               $od_callback($jobstreams, 1,1);
            else{
               foreach ($jobstreams as $key=>$val){
                     $res[$key][]=$val;
               }
            }
         }

         $res['nrows']++;
         $jobstreams['nrows']++;

         $jobstreams['cpu'][1]         = $row['PWKS_NAME'];
         $jobstreams['schedule'][1]    = $row['PJST_NAME'];
         $jobstreams['schedtime'][1] = tws_userdate_to_conman(tws_iso_to_userdate($row['PJST_SCHEDULED_TIME'], null, FALSE, $composer_db['tz']));
         $jobstreams['priority'][1]    = $row['PJST_PRIORITY'];
         if(!empty($row['PJST_ACTUAL_START_TIME']))
            $jobstreams['start_time'][1]  = tws_userdate_to_conman(tws_iso_to_userdate($row['PJST_ACTUAL_START_TIME'], null, FALSE, $composer_db['tz']));
         elseif(!empty($row['PJST_EARLIEST_START_TIME']))
            $jobstreams['start_time'][1]  = "(".tws_userdate_to_conman(tws_iso_to_userdate($row['PJST_EARLIEST_START_TIME'], null, FALSE, $composer_db['tz'])).")";
         else $jobstreams['start_time'][1] = '';

         if(!empty($row['PJST_TOTAL_ELAPSED_TIME']))
            $jobstreams['elapse_time'][1] = sprintf("%02d", intval($row['PJST_TOTAL_ELAPSED_TIME']/60000/60)).":".sprintf("%02d",($row['PJST_TOTAL_ELAPSED_TIME']/60000)%60);
         elseif(!empty($row['PJST_ESTIMATED_DURATION']))
            $jobstreams['elapse_time'][1] = "(".sprintf("%02d", intval($row['PJST_ESTIMATED_DURATION']/60000/60)).":".sprintf("%02d", ($row['PJST_ESTIMATED_DURATION']/60000)%60).")";
         else $jobstreams['elapse_time'][1] = '';

         $jobstreams['num_jobs'][1]    = $row['PJST_TOTAL_JOBS'];
         $jobstreams['ok_jobs'][1]     = $row['PJST_SUCCESSFUL_JOBS'];
         $jobstreams['limit'][1]       = $row['PJST_LIMIT'];
         $jobstreams['schedid'][1]     = $row['JSI_SYM_ID'];
         if($row['PJST_LIMIT'] == '-1')
            $jobstreams['limit'][1] = '';
         else $jobstreams['limit'][1]       = $row['PJST_LIMIT'];

         $jobstreams['state'][1] = $db_status[$row['PJST_STATUS']];
         $jobstreams['entry_type'][1]  = 'schedule';
         $jobstreams['offset']         = $jobstreams['nrows']-1;
         $jobstreams['dep'][1] = array();
      }
      // DEPENDENCIES
      // Carry

      // STREAM dependences
      if(!empty($row['JOB_STREAM_PRED_NAME']) && $row['DEPS_SATISFIED']!= 'Y'){
         $schedtime = tws_userdate_to_conman(tws_iso_to_userdate($row['JOB_STREAM_PRED_SCHED_TIME'], null, FALSE, $composer_db['tz']));
         $jobstreams['dep'][1][] = $row['JOB_STREAM_PRED_WKS_NAME']."#".$row['JOB_STREAM_PRED_NAME'].'[('.$schedtime.'),('.$row['DEP_SYM_ID'].')].@$FOLLOWS:'.$db_status[$row['DEP_STATUS']].'$';
      }
      // JOB dependences
      if(!empty($row['JOB_PRED_NAME']) && $row['DEPS_SATISFIED']!= 'Y'){
         $schedtime = tws_userdate_to_conman(tws_iso_to_userdate($row['JOB_PRED_JS_SCHED_TIME'], null, FALSE, $composer_db['tz']));
         $jobstreams['dep'][1][] = $row['JOB_PRED_JS_WKS_NAME']."#".$row['JOB_PRED_JS_NAME'].'[('.$schedtime.'),('.$row['DEP_SYM_ID'].')].'.$row['JOB_PRED_NAME'].'$FOLLOWS:'.$db_status[$row['DEP_STATUS']].'$';
      }
      // FILES
      if(!empty($row['FILE_NAME']) && $row['FILES_SATISFIED']!= 'Y'){
         $jobstreams['dep'][1][] = $row['FILE_WKS_NAME'].'#'.$row['FILE_NAME'].'$OPENS:'.$pr_ststus[$row['FILES_STATUS']].'$';
      }
      // PROMPTS
      if(!empty($row['PROMPT_NUMBER']) && $row['PROMPT_STATUS']!= 'Y'){
         $pr = '#'.$row['PROMPT_NUMBER'];
         if(!empty($row['PROMPT']))
            $pr .= '('.$row['PROMPT'].')';
         $pr .= '$PROMPT:'.$pr_ststus[$row['PROMPT_STATUS']].'$';
         $jobstreams['dep'][1][] = $pr;
      }
      // RESOURCES
      if(!empty($row['RESOURCE_NAME']) && $row['RES_SATISFIED']!= 'Y'){
         $dep = '-'. $row['QUANTITY_DEFINED']. ' ' .$row['RESOURCE_WKS_NAME'].'#'.$row['RESOURCE_NAME'].'-$NEEDS:';
         if($row['QUANTITY_DEFINED'] <= $row['QUANTITY_AVAILABLE'])
            $dep .= 'AVAIL$';
         else $dep .= 'NO$';
         $jobstreams['dep'][1][] = $dep;
      }
      // LATE
      if($row['PJST_LATE']=='Y')
         $jobstreams['dep'][1][] = '[Late]';
      // RELEASED
      if($row['PJST_RELEASED']=='Y')
         $jobstreams['dep'][1][] = '[Released]';
      // UNTIL
      if(!empty($row['PJST_UNTIL_TIME'])){
         $dep = tws_iso_to_userdate($row['PJST_UNTIL_TIME'], null, FALSE, $composer_db['tz'], true);
         $dep = "<$dep".'$UNTIL:';
         if($row['PJST_UNTIL_EXPIRED']=='Y')
            $dep .= 'EXPIRED$';
         else $dep .= '$OK$';
         $jobstreams['dep'][1][] = $dep;
      }
      if(!empty($row['PJST_DEADLINE_TIME'])){
         $dep = tws_iso_to_userdate($row['PJST_DEADLINE_TIME'], null, FALSE, $composer_db['tz'], true);

      }
      $jobstreams['dep'][1] = array_unique($jobstreams['dep'][1]);
   }
   // return last jobstream
   if ($oc)
      $od_callback($jobstreams, 1,1);
   else{
      foreach ($jobstreams as $key=>$val){
            $res[$key][]=$val;
      }
   }

tws_log('-- tws_get_plan_jobstream_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
return $res;
}
?>