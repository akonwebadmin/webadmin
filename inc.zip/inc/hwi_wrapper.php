<?php
//   HORIZONT Software GmbH, Munich
//

//hwi_config wrapper
   $hwi_config=array(
      'host_os' => &$tws_config['host_os'],
      'hwi_popen_env' => &$tws_config['twsenv'], //reference is needed, as the tws_config[twsenv] is being updated during initialization
      'hwi_root' => $tws_config['maestro_dir'].'/webadmin',
      'proc_open_blocking' => &$tws_config['proc_open_blocking'],
      'proc_open_buffer' => &$tws_config['proc_open_buffer'],
      'proc_open_wait' => &$tws_config['proc_open_wait'],
      'tmp_dir' => &$webadmin_tmp_dir,
      'cmdexe-compat' => isset($tws_config['cmdexe-compat']) ? $tws_config['cmdexe-compat'] : TRUE,
      'force_session_write_close' => isset($tws_config['force_session_write_close']) ? $tws_config['force_session_write_close'] : FALSE,
   );

//required functions wrappers
   function wai_error($heading, $message, $script='', $line='', $level = 3, $code = '') {
      return tws_error($message, $heading, $script, $line);
   }

   function hwi_log($msg='', $act='') {
      return tws_log($msg, $act);
   }

   function wai_audit($message, $message_type=3, $destination='') {
      return tws_audit($message); 
   }

   function hwi_yesno($choice, $yes=TRUE, $no=FALSE, $numtreshold=0) {
      return tws_yesno($choice, $yes, $no, $numtreshold);
   }

   function hwi_info($heading, $message, $script = '', $line = '', $code = '') {
      wai_error($heading, $message, $script, $line, 1, $code);
   }
   function hwi_notice($heading, $message, $script = '', $line = '', $code = '') {
      wai_error($heading, $message, $script, $line, 2, $code);
   }
   function hwi_warning($heading, $message, $script = '', $line = '', $code = '') {
      wai_error($heading, $message, $script, $line, 3, $code);
   }
   function hwi_error($heading, $message, $script = '', $line = '', $code = '') {
      wai_error($heading, $message, $script, $line, 4, $code);
   }
   function hwi_trace($heading, $message, $script = '', $line = '', $code = '') {
      wai_error($heading, $message, $script, $line, 5, $code);
   }
?>
