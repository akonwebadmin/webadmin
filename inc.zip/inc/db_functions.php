<?php
//   HORIZONT Software GmbH, Munich
//


define ('DB_NOT_PERSISTENT', FALSE);
define ('DB_PERSISTENT', TRUE);

///
/// db_function interface last error registration
function db_last_error($err_msg){
   global $_last_error;
   if(@function_exists(@$_last_error)){
      $_last_error($err_msg);
   }
}

function db2_get_catalog($db2instance, $cache=TRUE) {
   global $tws_config;
   //support cache and invalidation of the host and port if the connection fails

   $tlog=function_exists('tws_log') && tws_log();

   if (isset($_SESSION['db2_get_catalog_cache'][$db2instance])) {
      if ($cache) {
         $tlog && tws_log('db2_get_catalog -- result from cache: '.print_r($_SESSION['db2_get_catalog_cache'][$db2instance],1));
         return $_SESSION['db2_get_catalog_cache'][$db2instance];
      } else unset($_SESSION['db2_get_catalog_cache'][$db2instance]);

      //$cache===NULL -> only clear the cache and exit - special case
      if ($cache===NULL) return;
   }

   $cmd=new hwi_cmd($tws_config['base_inst_dir'].'/etc/db2cat.sh', $db2instance);
   $stdout=array(); $stderr='';
   if (hwi_popen($cmd,$rc,$stdout,$stderr, '', array('LANG'=>'C'))!==FALSE && $rc==0) {
      $cat=array();
      $elem_type=FALSE;
      foreach ($stdout as $buff) {
         $tlog && tws_log('db2_get_catalog -- '.$buff);
         if (preg_match('/database\s+(\d+)\s+entry:/i',$buff, $r)) {
            $i=$r[1];
            $elem_type='db';
         } elseif (preg_match('/node\s+(\d+)\s+entry:/i',$buff, $r)) {
            $i=$r[1];
            $elem_type='node';
         } else {
            switch ($elem_type) {
               case 'db' :
                  if (preg_match('/Database\s+alias\s*=\s*(\S+)/i',$buff,$r)) {
                     $cat[$elem_type][$i]['alias']=$r[1];
                  } elseif (preg_match('/Database\s+name\s*=\s*(\S+)/i',$buff,$r)) {
                     $cat[$elem_type][$i]['name']=$r[1];
                  } elseif (preg_match('/Node\s+name\s*=\s*(\S+)/i',$buff,$r)) {
                     $cat[$elem_type][$i]['node']=$r[1];
                  } elseif (preg_match('/Directory\s+entry\s+type\s*=\s*(\S+)/i',$buff,$r)) {
                     $cat[$elem_type][$i]['type']=$r[1];
                  } elseif (preg_match('/Alternate\s+server\s+hostname\s*=\s*(\S+)/i', $buff,$r)) {
                     $cat[$elem_type][$i]['alt_host']=$r[1];
                  } elseif (preg_match('/Alternate\s+server\s+port\s+number\s*=\s*(\S+)/i', $buff,$r)) {
                     $cat[$elem_type][$i]['alt_port']=$r[1];
                  }
                  break;

               case 'node' :
                  if (preg_match('/Node\s+name\s*=\s*(\S+)/i',$buff,$r)) {
                     $cat[$elem_type][$i]['name']=$r[1];
                  } elseif (preg_match('/Directory\s+entry\s+type\s*=\s*(\S+)/i',$buff,$r)) {
                     $cat[$elem_type][$i]['type']=$r[1];
                  } elseif (preg_match('/Protocol\s*=\s*(\S+)/i',$buff,$r)) {
                     $cat[$elem_type][$i]['protocol']=$r[1];
                  } elseif (preg_match('/Hostname\s*=\s*(\S+)/i', $buff,$r)) {
                     $cat[$elem_type][$i]['host']=$r[1];
                  } elseif (preg_match('/Service\s+name\s*=\s*(\S+)/i', $buff,$r)) {
                     $cat[$elem_type][$i]['service_name']=$r[1]; //port
                  }
                  break;
            }
         }
      }
      $tlog && tws_log('db2_get_catalog -- result: '.print_r($cat,1));
      $_SESSION['db2_get_catalog_cache'][$db2instance]=$cat;
      return $cat;
   }
   $tlog && tws_log('db2_get_catalog -- Unable to get DB2 catalog data (db2instance='.$db2instance.')');
   db_last_error("Failed to get DB2 catalog data. \nErr: \n[stdout]=".implode("\n",$stdout)."\n".$stderr);
   return FALSE;
}

function db_connect(&$db,$persistent=DB_NOT_PERSISTENT) {
   $db['persistent']=(isset($db['allow_persistent']) && !tws_yesno($db['allow_persistent'],TRUE, FALSE)) ? DB_NOT_PERSISTENT : $persistent;
   if ($db['persistent']===DB_NOT_PERSISTENT && isset($db['conn']) && is_resource($db['conn'])) return $db['conn'];
   switch ($db['type']) {
   case 'db2':
      //avoid PHP Fatal error if ibm_db2 extension is not loaded
      if (!isset($db['conn']) && !function_exists('db_connect')) {
         db_last_error('IBM DB2 extension not available');
         return FALSE;
      }

      // i) if Apache is started with the DB2 environment variable DB2INSTANCE
      //    UNIX: in webadmin/etc/envvars the LD_LIBRARY_PATH will contain ~$DB2INSTANCE/sqllib/lib32 path
      //    WINDOWS: sqlllib/lib32 must be in the system PATH environment variable
      //
      // ii) if DB2INSTANCE is not defined than WebAdmin uses the internal DB2 CLI driver
      //     and connects using the host and port parameters
      //    UNIX: in webadmin/etc/envvars the LD_LIBRARY_PATH will contain <BASE_INST_DIR>/webadmin/lib/db2/lib
      //    WINDOWS: <BASE_INST_DIR>/webadmin/lib/db2/lib must be in the system PATH environment variable
      //
      // iii) if the DB2INSTANCE is defined as $db['db2instance'] (or $db['DB2INSTANCE'] ) while the 'host' then WebAdmin
      //      will try to get the host and port from tehe output of
      //          db2 "list database directory"
      //          db2 "list node directory"
      //      This process is implemented in webadmin/etc/db2dndirs.sh script (webadmin/etc/db2dndirs.sh) called
      //      and the output processed in function db2_get_catalog in this library
      if (trim($db['host'])!=='') {
         $db['conn_str']='DRIVER={IBM DB2 ODBC DRIVER};DATABASE='.$db['name'].';HOSTNAME='.$db['host'].';PORT='.(trim($db['port'])!=='' ? $db['port'] : 50000).';PROTOCOL=TCPIP;UID='.$db['user'].';PWD='.$db['pass'].';';
      } elseif ((isset($db['db2instance']) && trim($db['db2instance'])!='') || (isset($db['DB2INSTANCE']) && trim($db['DB2INSTANCE'])!='')) {
         $db['db2instance']=isset($db['db2instance']) ? $db['db2instance'] : $db['DB2INSTANCE'];
         if (($cat=db2_get_catalog($db['db2instance']))!==FALSE) {
            $db['conn_str']='';
            foreach ($cat['db'] as $dbx) {
               if (strtoupper($dbx['alias'])==strtoupper(trim($db['name']))) {
                  foreach ($cat['node'] as $node) {
                     if (strtoupper($node['name'])==strtoupper($dbx['node'])) {
                        $db['conn_str']='DRIVER={IBM DB2 ODBC DRIVER};DATABASE='.$db['name'].';HOSTNAME='.$node['host'].';PORT='.(isset($node['service_name']) ? $node['service_name'] : 50000).';PROTOCOL=TCPIP;UID='.$db['user'].';PWD='.$db['pass'].';';
                        break 2;
                     }
                  }
               }
            }
            if ($db['conn_str']=='') {
               db_last_error("Unable to get node hostname and port from the DB2 catalog: ".print_r($cat,1));
               //clear the cache of db2_get_catalog!
               db2_get_catalog($db['db2instance'], NULL);
            }
         }
      } else {
         //connection by DB2 catalog
         $db['conn_str']='';
      }

      if ($db['persistent']) {
         $options = array('autocommit' => DB2_AUTOCOMMIT_ON);
         $dbh = $db['conn_str']!=='' ? db2_pconnect($db['conn_str'], NULL, NULL, $options) : db2_pconnect($db['name'], $db['user'], $db['pass'], $options);
      } else {
         $options = array('autocommit' => DB2_AUTOCOMMIT_OFF);
         $dbh = $db['conn_str']!=='' ? db2_connect($db['conn_str'], NULL, NULL, $options) : db2_connect($db['name'], $db['user'], $db['pass'], $options);
      }
      //db2 returns date and time in ISO format by default
      break;
    case 'oracle':
      //avoid PHP Fatal error if oci8 extension is not loaded
      if (!isset($db['conn']) && !function_exists('oci_new_connect')) {
         db_last_error('Oracle OCI8 extension not available');
         return FALSE;
      }

      $db['conn_str']='';
      if ($db['host']!='') {
//easy connect
         $db['conn_str']='//'.$db['host'];
         if ($db['port']!='') $db['conn_str'].=':'.$db['port'];
         $db['conn_str'].='/';
      }
      $db['conn_str'].=$db['name'];
      if ($db['persistent']) {
         $dbh = oci_pconnect($db['user'], $db['pass'], $db['conn_str']);
      } else {
         $dbh = oci_new_connect($db['user'], $db['pass'], $db['conn_str']);
      }
      if ($dbh) {
         $stmt = oci_parse($dbh,"alter session set nls_date_format='YYYY-MM-DD'");
         $res = oci_execute($stmt);
         $stmt = oci_parse($dbh,"alter session set nls_timestamp_format='YYYY-MM-DD HH24:MI:SS.FF'");
         $res = oci_execute($stmt);
      }
      break;
   case 'pgsql':
      $db['conn_str']='host='.$db['host'].' port='.$db['port'].' dbname='.$db['name'].' user='.$db['user'].' password='.$db['pass'];
      if ($db['persistent']) {
         $dbh = pg_pconnect($db['conn_str']);
      } else {
         $dbh = pg_pconnect($db['conn_str'],PGSQL_CONNECT_FORCE_NEW);
         $stmt = pg_query($dbh,'BEGIN');
      }
      $stmt = pg_query($dbh,"SET DateStyle TO 'ISO' ");
      break;
   default:
      db_last_error("Unknown DB type '".$db['type']."'.");
      return FALSE;
   }
   if ($dbh) { $db['conn']=$dbh; }
   else db_last_error(@db_error($db));
   return $dbh;
}

function db_query(&$db,$query){
    //strip semi-colons at the end of the query
    $query=rtrim(trim($query),';');
    switch ($db["type"]) {
    case "db2":
        @$res = db2_exec($db["conn"],$query);
        break;
    case "oracle":
        $stmt = @oci_parse($db["conn"],$query);
        if ($stmt) {
            if (isset($db['stmth'])) {
               @oci_free_statement($db['stmth']);
               unset($db['stmth']);
            }
            $db['stmth']=$stmt;
            if ($db["persistent"]) {
                @$res = oci_execute($stmt);
            } else {
                @$res = oci_execute($stmt,OCI_DEFAULT); //start transaction
            }
            if ($res) { $res = $stmt; }
        } else $res = FALSE;
        break;
    case "pgsql":
        @$res = pg_query($db["conn"],$query);
        break;
    default:
        db_last_error("Unknown DB type '".$db["type"]."'.");
        return FALSE;
    }
    if ($res) { $db["qresult"] = $res; }
    else {
      ($e=@db_error($db))===FALSE && $e=array();
      $e['query failed']=$query;
      db_last_error($e);
    }
    return $res;
}

// case:
//   0,'' - don't change the case
//   1 - lowercase keys
//   2 - upercase keys (DEFAULT)
// NULL - no keys, just fetch status (bool)
//
// return values:
//   FALSE - unexpected end
//   0 - nothing to fetch (end of selected data)
//
function db_fetch_row(&$db, $case=2)
{
    if (!isset($db['qresult'])) { return FALSE; }
    switch ($db['type']) {
    case 'db2':
        // db2_fetch_assoc() have problems with LOB values
        $r = @db2_fetch_array($db['qresult']);
        if ($r) {
            for( $i=0; $i < count($r); $i++) {
                @$row[db2_field_name($db['qresult'],$i)] = $r[$i];
            }
        } else {
           $row=FALSE;
           $e = db_error($db);
           if ($e['code']!='') {
              tws_error(db_error($db), 'Unable to fetch all requested data');
              return FALSE;
           }
        }
        break;
    case 'oracle':
        @$row = oci_fetch_array($db["qresult"], OCI_ASSOC+OCI_RETURN_NULLS+OCI_RETURN_LOBS);
        break;
    case 'pgsql':
        $row = pg_fetch_assoc($db['qresult']);
        break;
    default:
        db_last_error('Unknown DB type \''.$db['type'].'\'');
        return FALSE;
    }
    if ($row) {
      if ($case === null) {
         return TRUE;
      } elseif ($case === 0) {
         return $row;
      } elseif ($case === 1) {
         $fcas = 'strtolower';
      } elseif ($case === 2) {
         $fcas = 'strtoupper';
      } else {
         $fcas = 'strtoupper';
      }
      foreach ($row as $key=>$val) {
         $res[$fcas($key)]=$val;
      }
      return $res;
    }
    return 0;
}

/*
// this is wrong usage, db2 and oracle do not provide this info
function db_num_rows($db)
{
    // this function returns the number of selected rows
    if (!isset($db["qresult"])) { return -1; }
    switch ($db["type"]) {
    case "db2":
        $num_rows=0;
        while (db2_fetch_row($db["qresult"])) {
            $num_rows++;
        }
        break;
    case "oracle":
        $num_rows=0;
        while (OCIfetch($db["qresult"])) {
            $num_rows++;
        }
        break;
    case "pgsql":
        $num_rows=pg_num_rows($db["qresult"]);
        break;
    default:
        return -1;
    }
    return $num_rows;
}
*/

function db_aff_rows($db)
{
    // this function returns the number of affected rows
    if (!isset($db["qresult"])) { return -2; }
    switch ($db["type"]) {
    case "db2":
        @$af_rows=db2_num_rows($db["qresult"]);
        break;
    case "oracle":
        @$af_rows=oci_num_rows($db["qresult"]);
        break;
    case "pgsql":
        @$af_rows=pg_affected_rows($db["qresult"]);
        break;
    default:
        db_last_error("Unknown DB type '".$db["type"]."'.");
        return -3;
    }
    return $af_rows;
}

function db_error($db) {
   switch ($db['type']) {
   case 'db2' :
      if (!$db['conn']) {
         $e['code']=db2_conn_error().db2_stmt_error();
         $e['message']=db2_conn_errormsg().db2_stmt_errormsg();
      } else {
         $e['code']=db2_conn_error($db["conn"]).db2_stmt_error();
         $e['message']=db2_conn_errormsg($db["conn"]).db2_stmt_errormsg();
      }
      break;
   case 'oracle':
      $e=array();
      if (!$db['conn']) {
         $e=oci_error();
      }
      if (isset($db['stmth'])) {
         $e['stmth']=oci_error($db['stmth']);
         @oci_free_statement($db['stmth']);
         unset($db['stmth']);
      }
      if (isset($db['qresult'])) {
         $e['qresult']=oci_error($db['qresult']);
      }
      if (empty($e)) {
         $e=oci_error($db['conn']);
      }
      break;
   case 'pgsql':
      $e['message']=pg_last_error($db['conn']);
      break;
   default:
      db_last_error("Unknown DB type '".$db['type']."'.");
      return FALSE;
   }
   if (!$db['conn']) {
//get the OS type
      $win32=defined('OS_WINDOWS') ? OS_WINDOWS : (strpos(strtoupper(php_uname()),'WIN')!==FALSE);

      $e['conn_str']=str_replace($db['pass'], '*****', $db['conn_str']);
      if ($win32) {
         $e['PATH']=getenv('PATH');
         $e['PATHEXT']=getenv('PATHEXT');
      } else {
         $e['LD_LIBRARY_PATH']=getenv('LD_LIBRARY_PATH');
         $e['LIBPATH']=getenv('LIBPATH');
         $e['SHLIB_PATH']=getenv('SHLIB_PATH');
      }
      if ($db['type']=='oracle') {
         $e['TNS_ADMIN']=getenv('TNS_ADMIN');
         $e['ORACLE_HOME']=getenv('ORACLE_HOME');
// reporting the TNS setup
         if ($e['TNS_ADMIN']!==FALSE) {
            $e['TNS_ADMIN/tnsnames.ora']=($f=file_get_contents($e['TNS_ADMIN'].'/tnsnames.ora')) === FALSE ? 'ERROR: Read access failed' : $f;
            $e['TNS_ADMIN/sqlnet.ora']=($f=file_get_contents($e['TNS_ADMIN'].'/sqlnet.ora')) === FALSE ? 'ERROR: Read access failed' : $f;
         }
         if ($e['ORACLE_HOME']!==FALSE) {
            $e['ORACLE_HOME/network/admin/tnsnames.ora']=($f=file_get_contents($e['ORACLE_HOME'].'/network/admin/tnsnames.ora')) === FALSE ? 'ERROR: Read access failed' : $f;
            $e['ORACLE_HOME/network/admin/sqlnet.ora']=($f=file_get_contents($e['ORACLE_HOME'].'/network/admin/sqlnet.ora')) === FALSE ? 'ERROR: Read access failed' : $f;
         }
      } elseif ($db['type']=='db2') {
         $e['DB2INSTANCE']=getenv('DB2INSTANCE');
      }
      $e['LANG']=getenv('LANG');
      $e['LOCALE']=getenv('LOCALE');
      $e['TZ']=getenv('TZ');

// reporting the content of the LD_LIBRARY_PATH (PATH on WIN32)
      foreach (explode($win32 ? ';' : ':', $win32 ? $e['PATH'] : $e['LD_LIBRARY_PATH']) as $p) {
         $stdout='';
         $cmd=$win32 ? (new hwi_cmd('dir', $p.'\\')) : (new hwi_cmd('ls', '-la', $p.'/'));
         hwi_popen($cmd, $ec, $stdout, $stdout);
         $e['ldlibs'][$p]=$stdout;
      }

// checking the dependencies of the PHP database directions (UNIX only)
      if (!$win32) {
         $ext=ini_get('extension_dir').'/';
         switch ($db['type']) {
         case 'db2' :
            $stdout='';
            $ext.='ibm_db2.'.PHP_SHLIB_SUFFIX;
            break;
         case 'oracle' :
            $stdout='';
            $ext.='oci8.'.PHP_SHLIB_SUFFIX;
            break;
         default :
            $ext='';
         }
         if ($ext) {
            $stdout='';
            $cmd=new hwi_cmd('ldd', $ext);
            hwi_popen($cmd, $ec, $stdout, $stdout);
            $e['ldd '.$ext]="\n".$stdout;
         }
      }
   }
   return $e;
}

function db_commit($db)
{
    if ($db["persistent"]) return TRUE;

    switch ($db["type"]) {
    case "db2":
        $ret = db2_commit($db["conn"]);
        break;
    case "oracle":
        $ret = oci_commit($db["conn"]);
        break;
    case "pgsql":
        $ret1 = pg_query($db["conn"],"COMMIT");
        $ret2 = pg_query($db["conn"],"BEGIN");
        $ret = ($ret1 && $ret2);
        break;
    default:
        db_last_error("Unknown DB type '".$db["type"]."'.");
        return FALSE;
    }
    if (!$ret) {
        ($e=@db_error($db))===FALSE && $e=array('Database transaction commit failed');
        db_last_error($e);
    }
    return $ret;
}

function db_table_columns($db,$table)
{
    $table = strtoupper($table);
    $schema = strtoupper($db['schema']);
    if(preg_match('/(.+)\.(.+)/', $table, $match)){
      $schema = $match[1];
      $table = $match[2];
    }
    $cols = array();
    switch ($db["type"]) {
    case "db2":
        $res = db2_exec($db["conn"],"select tabname,colname,typename,length,scale  from SYSCAT.COLUMNS where TABNAME='".$table."' and TABSCHEMA='$schema'");
        if ($res) {
            while ($row = db2_fetch_assoc($res)){
                $cols[$row["COLNAME"]]["name"] = $row["COLNAME"];
                $cols[$row["COLNAME"]]["type"] = $row["TYPENAME"];
                $cols[$row["COLNAME"]]["size"] = $row["LENGTH"];
                $cols[$row["COLNAME"]]["precision"] = $row["SCALE"];
                // DB2 returns CHARACTER instead of CHAR
                if ($cols[$row["COLNAME"]]["type"] == "CHARACTER") {
                    $cols[$row["COLNAME"]]["type"] = "CHAR";
                }
            }
        }
        break;
    case "oracle":
        $qry = "select * from  ALL_TAB_COLUMNS where table_name='".$table."' and owner='".$schema."'";
        $stmt = oci_parse($db["conn"],$qry);
        $res = oci_execute($stmt);
        if ($res) {
            while( ( $row = oci_fetch_array($stmt, OCI_ASSOC+OCI_RETURN_NULLS+OCI_RETURN_LOBS))!= false) {
                $cols[$row["COLUMN_NAME"]]["name"] = $row["COLUMN_NAME"];
                $cols[$row["COLUMN_NAME"]]["type"] = $row["DATA_TYPE"];
                if ($row["DATA_TYPE"] == 'NUMBER') {
                    $cols[$row["COLUMN_NAME"]]["size"] = $row["DATA_PRECISION"];
                } else {
                    $cols[$row["COLUMN_NAME"]]["size"] = $row["DATA_LENGTH"];
                }
                $cols[$row["COLUMN_NAME"]]["precision"] = $row["DATA_SCALE"];
                // Oracle returns TIMESTAMP(6) or similar
                if (preg_match("/TIMESTAMP.*/", $cols[$row["COLUMN_NAME"]]["type"])) {
                    $cols[$row["COLUMN_NAME"]]["type"] = "TIMESTAMP";
                }
                //Oracle returns NUMBER for numeric fields (INTEGER, DECIMAL)
                if ($cols[$row["COLUMN_NAME"]]["type"] == "NUMBER" &&
                    $cols[$row["COLUMN_NAME"]]["precision"] == 0 &&
                    $cols[$row["COLUMN_NAME"]]["size"] == "" )
                {
                    $cols[$row["COLUMN_NAME"]]["type"] = "INTEGER";
                }
                if ($cols[$row["COLUMN_NAME"]]["type"] == "NUMBER" &&
                    $cols[$row["COLUMN_NAME"]]["precision"] >= 0 &&
                    $cols[$row["COLUMN_NAME"]]["size"] >= 0 )
                {
                    $cols[$row["COLUMN_NAME"]]["type"] = "DECIMAL";
                }
                // VARCHAR2 = VARCHAR
                if ($cols[$row["COLUMN_NAME"]]["type"] == "VARCHAR2") {
                    $cols[$row["COLUMN_NAME"]]["type"]="VARCHAR";
                }
            }
        }

        if ($res) { $res = $stmt; }
        break;
    case "pgsql":
        $qry = "SELECT * FROM information_schema.columns WHERE table_name='".$table."' OR table_name='".strtolower($table)."'";
        $res = pg_query($db["conn"],$qry);
        if ($res) {
            while( $row = pg_fetch_assoc($res)) {
                $col_name=strtoupper($row["column_name"]);
                $cols[$col_name]["name"] = $col_name;
                $cols[$col_name]["type"] = strtoupper($row["data_type"]);
                if ($cols[$col_name]["type"] == "CHARACTER VARYING") {
                    $cols[$col_name]["type"]="VARCHAR";
                }
                if ($row["numeric_precision_radix"] == 2){
                    $cols[$col_name]["size"] = log($row["numeric_precision"]+0,$row["numeric_precision_radix"]+0);
                    $cols[$col_name]["precision"] = $row["numeric_scale"];
                } else if ($row["numeric_precision_radix"] == 10){
                    $cols[$col_name]["size"] = $row["numeric_precision"];
                    $cols[$col_name]["precision"] = $row["numeric_scale"];
                } else {
                   $cols[$col_name]["size"] = $row["character_maximum_length"];
                }
                // PgSQL returns TIMESTAMP WITH(OUT) TIMEZONE
                if (preg_match("/^TIMESTAMP.*/", $cols[$col_name]["type"])) {
                    $cols[$col_name]["type"] = "TIMESTAMP";
                }
                // PgSQL returns NUMERIC instead of DECIMAL
                if ($cols[$col_name]["type"] == "NUMERIC") {
                    $cols[$col_name]["type"] = "DECIMAL";
                }
                // PgSQL returns CHARACTER instead of CHAR
                if ($cols[$col_name]["type"] == "CHARACTER") {
                    $cols[$col_name]["type"] = "CHAR";
                }
            }
// for some reason PostgreSQL returns columns in reverse order
            $cols = array_reverse ($cols);
        }

        break;
    default:
        db_last_error("Unknown DB type '".$db["type"]."'.");
        return FALSE;
    }
    return $cols;
}

function type_check($data,$table_desc,&$err)
{
    // check if the $data array agree with the data types in table_desc
    $ret = TRUE;
    $err = array();

    foreach ($data as $dkey => $dvalue) {
        if (isset($table_desc[$dkey])) {
            $field=$table_desc[$dkey];

            switch ($field["type"]) {
            case "INTEGER":
                if (!is_int($dvalue)){
                    $ret=FALSE;
                    $err[$field["name"]]="INTEGER ERROR";
                    break;
                }
                break;
            case "DECIMAL":
                if (!preg_match("/^[0-9]{0,".$field["size"]."}\.[0-9]{0,".$field["precision"]."}$/", (string) $dvalue)) {
                    $ret=FALSE;
                    $err[$field["name"]]="DECIMAL format ERROR";
                    break;
                }
                break;
            case "CLOB":
                break;
            case "DATE":
                if (!check_date($dvalue) ) {
                    $ret=FALSE;
                    $err[$field["name"]]="DATE format ERROR";
                    break;
                }
                break;
            case "TIMESTAMP":
                @list($date,$time) = explode(' ',$dvalue);
                if (! (check_date($date) && check_time($time))) {
                    $ret=FALSE;
                    $err[$field["name"]]="TIMESTAMP format ERROR";
                    break;
                }
                break;
            case "VARCHAR":
            case "RAW":     // Oracle similar to 'CHAR FOR BIT DATA' in DB2
            case "CHAR":
                if (strlen($dvalue) > $field["size"]) {
                    $ret=FALSE;
                    $err[$field["name"]]=$field["type"]." length ERROR";
                    break;
                }
                break;
            default:
                $ret=FALSE;
                $err[$field["name"]]="Wrong field type";
            }
        } else {  // Data column not in the table_desc
            $ret=FALSE;
            $err[$dkey]=" Wrong index";
        }
    }
    return $ret;
}

function check_date($date){
    split_date($date,$year,$month,$day);
    @$ret=checkdate($month,$day,$year);
    return $ret;
}

function check_time($time){
    $ret = TRUE;
    split_time($time,$hour,$min,$sec,$ff);
    if (preg_match("/^[0-9]{2}$/",$hour)) $hour=intval($hour); else $ret=FALSE;
    if (preg_match("/^[0-9]{2}$/",$min)) $min=intval($min); else $ret=FALSE;
    if (preg_match("/^[0-9]{2}$/",$sec)) $sec=intval($sec); else $ret=FALSE;
    if (preg_match("/^[0-9]{0,6}$/",$ff)) $ff=intval($ff); else $ret=FALSE;
    if (($hour < 0 ) || ($hour > 23))
        $ret = FALSE;
    if (($min < 0 ) || ($min > 59))
        return FALSE;
    if (($sec < 0 ) || ($sec > 59))
        $ret = FALSE;
    if (($ff < 0 ))
        $ret = FALSE;
    return $ret;
}

function split_date($date,&$year,&$month,&$day){
    @list($year,$month,$day) = explode('-',$date);
}

function split_time($time,&$hour,&$minute,&$second,&$ff){
    @list($hour,$minute,$secpart) = explode(':',$time);
    @list($second,$ff) = explode('.',$secpart);
}

function split_timestamp($tst,&$year,&$month,&$day,&$hour,&$minute,&$second,&$ff){
    @list($date,$time) = explode(' ',$tst);
    split_date($date,$year,$month,$day);
    split_time($time,$hour,$minute,$second,$ff);
}

function db_close(&$db)
{
   switch ($db["type"]) {
      case "db2":
         $ret=db2_close($db['conn']);
         break;
      case "oracle":
         if (isset($db['stmth'])) {
            @oci_free_statement($db['stmth']);
            unset($db['stmth']);
         }
         return oci_close($db['conn']);
         break;
      case "pgsql":
         return pg_close($db['conn']);
         break;
      default:
         db_last_error("Unknown DB type '".$db["type"]."'.");
         return FALSE;
   }
   if ($db['persistent']===DB_NOT_PERSISTENT) unset($db['conn']);
}

///
/// This function provides ANSI SQL quoation to a string
/// that is to be inserted to the database.
///
/// Warning: the string should not contain escapes added by       //FIXME  magic quotation
/// magic quotation (use stripslashes in that case first)
function db_string($db, $str){
   switch ($db["type"]) {
      case "db2":
         //warning: db2_escape_string (ibm_db2-1.6.0) doesn'twork as expected,
         //therefore own escaping implementation is still used
         //$str=db2_escape_string($str);
         $str = preg_replace("/''/","'",$str);
         $str = preg_replace("/'/","''",$str);
         $str = preg_replace("/`/","''",$str);
         break;
      case "oracle":
         $str = preg_replace("/''/","'",$str);
         $str = preg_replace("/'/","''",$str);
         $str = preg_replace("/`/","''",$str);
         break;
      case "pgsql":
         $str = preg_replace("/`/","'",$str);
         $str=pg_escape_string($str);
         break;
      default:
         db_last_error("Unknown DB type '".$db["type"]."'.");
         return FALSE;
   }
   return $str;
}


/* template

function db_xxx($db)
{
    switch ($db["type"]) {
    case "db2":
        break;
    case "oracle":
        break;
    case "pgsql":
        break;
    default:
        return FALSE;
    }
}

 */

?>
