<?php
//   HORIZONT Software GmbH, Munich
//

   $col[1]=2;
   $len[1]=16;
   $col[2]=19;
   $len[2]=5;
   $col[3]=25;
   $len[3]=13;
   $col[4]=38;
   $len[4]=4;
   $col[5]=44;
   $len[5]=4;
   $col[6]=49;
   $len[6]=9;
   $col[7]=58;
   $len[7]=6;

if (isset($tws_config['cpuinfo']['version']) && $tws_config['cpuinfo']['version'] > '8.3') {

   $col[8]=65;
   $len[8]=11;
   $col[9]=76;
   $len[9]=40;
   $col[10]=117;
   $len[10]=910;
}
else {
   $col[8]=65;
   $len[8]=6;
   $col[9]=72;
   $len[9]=40;
   $col[10]=113;
   $len[10]=910;
}
?>