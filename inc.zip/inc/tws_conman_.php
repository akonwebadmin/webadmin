<?php
//   HORIZONT Software GmbH, Munich
//


//
// analyzes the exit status of a conman -gui command
//
function tws_process_conman_gui(&$cmdoutput, $del_prefix=TRUE) {
   $status=0;
   if (!is_array($cmdoutput)) $cmdoutput=explode("\n",$cmdoutput);
   foreach ($cmdoutput as $key=>$buffer) {
// translate AWS messages into gui messages
      $buffer=preg_replace("/^(\^[a-z])?(.*AWS[A-Z0-9]+)([A-Z]) /", '^${3}${2}${3} ', $buffer);
      if (substr($buffer,0,1)=='^') {
         $buffer{1}=strtolower($buffer{1});
         $prefix=substr($buffer,0,2);
         switch ($prefix) {
            case "^i" :
               strtolower(substr($buffer,2,21))=='error running command' && $status=1;
               break;
            case "^e" : case "^f" :
               if (!preg_match('/AWSDEQ008E.*tokenutils.c/', $buffer)) $status=1; //ERR18323 - false error in "tokenutils" library
               break;
            case "^w" :
               $status==0 && $status=2;
               break;
         }
         if ($del_prefix) $buffer=substr($buffer,2);
      }
      $cmdoutput[$key]=$buffer;
   }
   return $status;
}

// plan job & plan jobstream filters (xjob & xstream filters)
//
// divide $arg into extFilter, $arg to show and optimized $temparg for conman
// e.g.
//
function tws_ext_plan_filters(&$arg, &$newarg) {
   $extf=array();
   $TWSID="[A-Za-z0-9_@\-]+";
   if (preg_match("/($TWSID#)?($TWSID)\(([^)]*)\)/", $arg, $_r)) {
      // sched time filter defined
      $schtf=trim($_r[3]);
      if (strpos($schtf,',')!==FALSE || !preg_match("/^[0-2][0-9][0-6][0-9]( |\$)/", $schtf)) {
         // extended webadmin schedtime filter
         $extf['xschedtime']=$schtf;
         //remove the extended filter for conman
         $arg=preg_replace("/(($TWSID#)?($TWSID))\(([^)]*)\)/", '\1', $arg);
tws_log('-- tws_ext_plan_filters: Detected extended IWS/WebAdmin SCHEDTIME filter, value=\''.$schtf.'\', arg updated: arg=\''.$arg.'\'');
      }
   }

   if ( preg_match_all('/[+~]x[a-z]+=[^+~]+/',$arg, $arr)) {      // copy xfilters to $arr
      $arg = preg_replace('/[+~]x[a-z]+=[^+~]+/', '', $arg);      // remove xfilters from $arg
      $newarg='';
      foreach($arr[0] as $xparam) {
         list($xname, $xval) = explode('=', $xparam);

         if( substr($xname,0,1) == '+' ) {
            $xname = substr($xname,1);
            // optimize $arg
            $newarg=tws_extf_optimize_sjarg($xname, $xval);
         }
         else {
            $xname = '-'. substr($xname,1);
         }
         $extf[$xname] = $xval;
         tws_log('-- tws_ext_plan_filters: Detected extended IWS/WebAdmin '. $xname .' filter, value=\''.$xval.'\'');
      }
      tws_log("newarg = $newarg, arg=$arg");
      tws_log('arg updated: arg=\''.$newarg.$arg.'\'');
   }
   // If State include 'cancelled', all State come into ext.filter
   if( preg_match("/state=.*cancelled/", $arg) ) {
      preg_match('/[+~]state=[^+~]+/',$arg, $arr);
      $arg = preg_replace('/[+~]state=[^+~]+/', '', $arg);
      $op=substr($arr[0],0,1);
      $val=substr($arr[0], strpos($arr[0], '=')+1);
      if($op == '+')
         $extf['xstate'] = $val;
      elseif($op == '~')
         $extf['-xstate'] = $val;
   }
   return $extf;
}


function tws_extf_optimize_sjarg($xname, $xval){
   global $tws_config;
tws_log(" -- tws_extf_optimize_sjarg params: xname = $xname, xval = $xval");
   $newarg='';
   if($xname=='xjob'){
      $newcpu=''; $newstream=''; $newjob='';
      $and = explode('&', $xval);
      foreach($and as $andcond ) {
         $or = explode(',', $andcond);
         foreach($or as $orcond ) {
            list($cpu, $stream, $job) = tws_explode_job($orcond);
            if($newcpu=='') $newcpu=$cpu;
            elseif($newcpu!=$cpu) $newcpu = '@';
            if($newstream=='') $newstream=$stream;
            elseif($newstream!=$stream){
               $newstream = '@';
               if($tws_config['cpuinfo']['version']>='9.5')
                  $newstream = '/@/@';
            }
            if($newjob=='') $newjob=$job;
            elseif($newjob!=$job){
               $newjob = '@';
            }
         }
      }
      $newarg = $newcpu.'#'.$newstream.'.'.$newjob;
   }
   elseif($xname=='xstream'){
      $newcpu=''; $newstream='';
      $and = explode('&', $xval);
      foreach($and as $andcond ) {
         $or = explode(',', $andcond);
         foreach($or as $orcond ) {
            list($cpu, $stream) = tws_explode_job($orcond);
            if($newcpu=='') $newcpu=$cpu;
            elseif($newcpu!=$cpu) $newcpu = '@';

            if($newstream=='') $newstream=$stream;
            elseif($newstream!=$stream){
               $newstream = '@';
               if($tws_config['cpuinfo']['version']>='9.5')
                  $newstream = '/@';
            }
         }
      }
      $newarg = $newcpu.'#'.$newstream;
   }
   tws_log(" -- tws_extf_optimize_sjarg params Result: = newarg = $newarg");
   return $newarg;
}

/// Returns the original sched name that corresponds to the schedid in the plan
/// \return Array('cpu'=>workstation_name, 'schedule'=>'stream name', 'valid from'=>validform );
/// \return FALSE if given schedid doesn't exist or another error occured
function tws_get_original_schedname($schedid){
   global $composer_db, $tws_config;

   $dbh = db_connect($composer_db,DB_PERSISTENT);
   if( !$dbh ){
      tws_error('', 'Cannot connect to database');
      return FALSE;
   }
   $schema=$composer_db['schema'];
   $query ="SELECT
         JSI_SYM_ID SCHED_ID,
         WKC.WKC_NAME CPU,
         AJS.AJS_NAME SCHEDULE,
         JST.JST_VALID_FROM VALID_FROM,
         JSI_SCHEDULED_DATE SCHED_DATE,
         JSI_START_TIME START_TIME".
         $query .=($tws_config['cpuinfo']['version']>='9.5' ? ', FOL.FOL_PATH FOLDER' : '');     // 9.5 folders
      $query .="
      FROM (($schema.JSI_JOB_STREAM_INSTANCES JSI
         JOIN $schema.JST_JOB_STREAMS JST ON JST.JST_ID = JSI.JST_ID)
         JOIN $schema.AJS_ABSTRACT_JOB_STREAMS AJS  ON JST.AJS_ID = AJS.AJS_ID)
         JOIN $schema.WKC_WORKSTATION_CLASSES WKC ON WKC.WKC_ID = AJS.WKC_ID";
         $query .= ($tws_config['cpuinfo']['version']>='9.5' ? "
            LEFT JOIN $schema.FOL_FOLDERS FOL ON FOL.FOL_ID = AJS.FOL_ID" : '');  // 9.5 folders
      $query .= "
         WHERE JSI_SYM_ID = '".db_string($composer_db,$schedid)."'";

   tws_log("-- tws_get_original_schedname query: $query");
   if( !($r=db_query($composer_db,$query)) ){
      tws_error('', 'Database query failed');
      return FALSE;
   }

   $ret=array();
   if ($row=db_fetch_row($composer_db)) {
      $ret['cpu'] = $row['CPU'];
      $ret['schedule'] = $row['SCHEDULE'];
      if ($row['VALID_FROM'] == '') {
         $ret['valid_from'] = '';
      } else {
         $ret['valid_from'] = $row['VALID_FROM'];
      }
      $ret['sched_date']=$row['SCHED_DATE'];
      $ret['start_time']=$row['START_TIME'];
      if(!empty($row['FOLDER']))
         $ret['jobstream_folder'] = $row['FOLDER'];
   }
   tws_log("-- tws_get_original_schedname results: ". var_export($ret, true));
   return $ret;
}

function tws_get_original_jobname($cpu, $schedule, $schedid, $job){
   global $tws_config;
         // Find original jobstream
         $js_orig=tws_get_original_schedname($schedid);
         if(!empty($js_orig))
            $js = $js_orig;
         else{
            $dformat = tws_profile("date_format");
            if(!$dformat) $dformat = 'm/d/Y';
            $js = tws_get_jobstreams($cpu, $schedule, '' , tws_where_valid_in(tws_userdate_to_iso(date($dformat), $dformat, true)));
            if($js['jobstream_num']>0){
               if(isset($js['jobstream_valid_from'][0]) )
                  $js['$validfrom'] = $js['jobstream_valid_from'][0];
               else $js['$validfrom']='';
               $js['cpu'] = $js['jobstream_workstation'][0];
               $js['schedule'] = $js['jobstream_name'][0];
            }
            else{
               $js['cpu'] = $cpu;
               $js['schedule'] = $schedule;
               $js['$validfrom']='';
            }
         }

         $jobstream_jobs = tws_get_jobstream_jobs($js['cpu'],$js['schedule'],$js['validfrom']);
         if($jobstream_jobs['job_num']){
            foreach($jobstream_jobs['jobname'] as $j=>$jobname){
               if(strpos($jobname, ' AS ')== false) continue;
               list($job_orig, $alias) = explode(' AS ', $jobname);
               if($job == $alias){
                  list($t, $job_orig) = explode('#', $job_orig);
                  return $job_orig;
               }
            }
         }
   return "";
}

/// Returns job run status (history) information in a vector with values
/// associtaed to following keys:
/// \return Array('num_abend','num_succ','last_run','last_elapse','min_elapse'
///               'max_elapse','last_cpu','min_cpu','max_cpu','total_elapse'
///               'total_cpu')
/// Note, that some values inh the returned array can be NULL
function tws_get_job_stats($workstation, $job){
   global $tws_config, $composer_db;

   tws_log("-- tws_get_job_stats Parameters: workstation = $workstation, job = $job");

   if( $workstation!='' && $job!=''){
      $dbh = db_connect($composer_db,DB_PERSISTENT);
      if( !$dbh ){
         tws_error('', 'Cannot connect to database');
         return FALSE;
      }
      if($tws_config['cpuinfo']['version']>='9.5')
         list($folder, $job) = tws_divide_folder($job);
      $schema=$composer_db["schema"];
      $query = "SELECT
            JOS.JOS_ABORTED_RUNS NUM_ABEND,
            JOS.JOS_SUCCESSFUL_RUNS NUM_SUCC,
            JOS.JOS_LAST_RUN_DATE LAST_RUN,
            JOS.JOS_LAST_ELAPSED_TIME LAST_ELAPSE,
            JOS.JOS_MIN_ELAPSED_TIME MIN_ELAPSE,
            JOS.JOS_MAX_ELAPSED_TIME MAX_ELAPSE,
            JOS.JOS_LAST_CPU_TIME LAST_CPU,
            JOS.JOS_MIN_CPU_TIME MIN_CPU,
            JOS.JOS_MAX_CPU_TIME MAX_CPU,
            JOS.JOS_TOTAL_ELAPSED_TIME TOTAL_ELAPSE,
            JOS.JOS_TOTAL_CPU_TIME TOTAL_CPU,
            ".($tws_config['cpuinfo']['version']>'8.3' ? 'JOS.JOS_AVERAGE_ELAPSED_TIME' : '(JOS.JOS_TOTAL_ELAPSED_TIME / (JOS.JOS_ABORTED_RUNS + JOS.JOS_SUCCESSFUL_RUNS))')." AVERAGE_ELAPSED_TIME
         FROM (( $schema.JOD_JOB_DEFINITIONS JOD
            JOIN $schema.WKC_WORKSTATION_CLASSES WKC ON WKC.WKC_ID = JOD.WKC_ID )
            LEFT JOIN $schema.JOS_JOB_STATISTICS JOS ON JOS.JOD_ID = JOD.JOD_ID)";
         if($tws_config['cpuinfo']['version']>='9.5')
            $query .= "
               LEFT JOIN $schema.FOL_FOLDERS FOL ON FOL.FOL_ID = JOD.FOL_ID";
         $query .= "
         WHERE
            WKC.WKC_NAME='".db_string($composer_db,$workstation)."' AND
            JOD.JOD_NAME='".db_string($composer_db,$job)."' ";
         if($tws_config['cpuinfo']['version']>='9.5')
            $query .= "
            AND FOL.FOL_PATH = '".db_string($composer_db, $folder)."'";

      if (!($r=db_query($composer_db,$query))) {
         tws_error('', 'Database query error');
         return FALSE;
      }
      tws_log("-- tws_get_job_stats query = $query");

      if ($row=db_fetch_row($composer_db)) {
         tws_log("-- tws_get_job_stats result = ".var_export($row, true));
         return array_change_key_case($row, CASE_LOWER);
      } else {
         return array();
      }
   } else {
      tws_error("workstation='$workstation'; job='$job'", "Incorrect or missing parameters");
      return FALSE;
   }
}

// 'sj -gui' auxiliar functions
function tws_every_run_occurence( $line ){
   return preg_match( "/^.{3,4}\>\> {0,1}every run/", $line ) ? TRUE : FALSE;
}
function tws_rerun_as_occurence( $line ){
   return preg_match( "/^.{3,4}\>\> {0,1}rerun as/", $line ) ? TRUE : FALSE;
}
function tws_rerun_step_occurence( $line ){
   return preg_match( "/^.{3,4}\>\> {0,1}rerun step/", $line ) ? TRUE : FALSE;
}
function tws_recovery_occurence( $line ){
   return preg_match( "/^.{3,4}\>\> {0,1}recovery/", $line ) ? TRUE : FALSE;
}

/**
 * Gets the list of plan workstations (and their status attrs)
 *
 * @param string $arg Workstation name or filter (see doc to ss)
 * @param int $symphony Sympony file number (0 for current plan - see doc for setsym, listsym)
 * @return array List of workstations or FALSE when fail
 */
function tws_get_plan_workstation_list($arg, $symphony=0, $page_size=0, $page=1, $od_callback=null){
   global $tws_config;
   include 'colpos_sc.php';

   tws_log('-- tws_get_plan_workstation_list (start at '.basename(__FILE__).'['.__LINE__.'])');

   $symtype = tws_profile('symtype');

   $arg = strtr($arg,'*','@');
   list($arg, $extf) = tws_planfilter_explode($arg, '!');      // xfilters function
   $arg = strtok($arg, '+');
   $filterchunks = 0;
   while ($tok = strtok('+')) {
      $filterchunks++;
      $filterchunk[$filterchunks] = $tok;
   }
   for ($i = 1; $i <= $filterchunks; $i++) {
      if (substr($filterchunk[$i], 0, 6) == 'types=') {
         $junk = strtok($filterchunk[$i], '=');
         $type_list = strtok("\n");
         $types = explode(',', $type_list);
      } elseif (substr($filterchunk[$i], 0, 3) == 'os=') {
         $junk = strtok($filterchunk[$i], '=');
         $os_list = strtok("\n");
         $os = explode(',', $os_list);
      } elseif (substr($filterchunk[$i], 0, 7) == 'states=') {
         $junk = strtok($filterchunk[$i], '=');
         $state_list = strtok("\n");
         $states = explode(',', $state_list);
      }
   }

   if ($symphony) {
      // Get actual symphony file number
      if (($symphony_lognum = tws_symphony_lognum($symtype, tws_profile('symphony_filename'))) === FALSE){
         tws_log('Error: Unable to get symphomy log number ('.__FILE__.'['.__LINE__.'])');
         $symphony_lognum = $symphony;
      }
      $st = (strtolower(trim($symtype))) == 'archived' ? '' : $symtype;
      $command = new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/conman", $tws_config['conman_args'], "-gui", "setsym $st $symphony_lognum&sc $arg", hwi_cmd::operator('2>&1',FALSE));
   } else {
      $command = new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/conman", $tws_config['conman_args'], "-gui", "sc $arg", hwi_cmd::operator('2>&1',FALSE));
   }

//   $stdout = array();
   $stdout = false;
   if ( ($pipes=tws_popen($command, $ec, $stdout, $stdout)) === FALSE ){
      tws_error(array('command'=>$command->compile('log'), 'stdout'=>$stdout), 'Unable to open pipe');
      tws_log('Error: Unable to open pipe. ('.__FILE__.'['.__LINE__.'])');
      return FALSE;
   }

   $tl=tws_log();
   if ($page_size) {
      $first_onpage = ($page - 1) * $page_size + 1;
      $last_onpage  = $page * $page_size;
   }
   $cpu_num = 0;
   $res=array('cpu_num'=>0);
   $tmp=array();

   $ws_folder = '';
   if($tws_config['cpuinfo']['version']>='9.5002')
      $ws_folder = '/';

   while (is_resource($pipes[1]) && !feof($pipes[1])) {
      if (($buffer=fgets($pipes[1], 4096))===FALSE){
         @usleep($tws_config['proc_open_wait']);
         continue;
      }
      tws_log($buffer);
      // tws_log("WS Folder = $ws_folder");

      // FIX for IWS 9.x - some data have no '^d' prefix (ticket 18515)
      $prefix = substr($buffer,0,2);
      if($prefix == '^h')
         $data_strings = true;  // data strings begin
      if(substr($buffer,0,3) == '%sc')
         $data_strings = false;  // end of data
      if($data_strings && $prefix != '^h' && $prefix != '^d')
         $buffer = "^d".$buffer;


      if (substr($buffer,0,2) != '^d')
         continue;

         if(substr($buffer,2,2) == '>>'){  // IWS 9.5.2 // WS Folder begin
            $ws_folder =  trim(substr($buffer, 4));
            continue;
         }

      $trim = trim(substr($buffer,2));
      if($trim=='/')
         continue;

      $tmp['ws_folder'] = $ws_folder;
      $tmp['cpu']       = trim(substr($buffer,$col[1],$len[1]));
      $tmp['run']       = trim(substr($buffer,$col[2],$len[2]));
      $tmp['node']      = trim(substr($buffer,$col[3],$len[3]));
      $tmp['node_os']   = trim(strtok($tmp['node']," ")," *");
      $tmp['node_type'] = trim(strtok("\n"));
      if (isset($types)) {
         if (!in_array($tmp['node_type'], $types))
            continue;
      }
      if (isset($os)) {
         if (!in_array($tmp['node_os'], $os))
            continue;
      }
      //$cpu_num++;
      $res['cpu_num']++;

      $tmp['limit'] = trim(substr($buffer,$col[4],$len[4]));
      $tmp['fence'] = trim(substr($buffer,$col[5],$len[5]));
      $tmp['date']  = trim(substr($buffer,$col[6],$len[6]));
      $tmp['time']  = trim(substr($buffer,$col[7],$len[7]));
      $tmp['state'] = trim(substr($buffer,$col[8],$len[8]));
      if (isset($states)) {
         $state_ok=FALSE;
         if ((strpos($tmp['state'],"L") !== FALSE) || (strpos($tmp['state'],"F") !== FALSE)) {
            if (in_array("linked",$states))
               $state_ok=TRUE;
         }
         if ((strpos($tmp['state'],"L") === FALSE) && (strpos($tmp['state'],"F") === FALSE))  {
            if (in_array("unlinked",$states))
               $state_ok=TRUE;
         }
         if (strpos($tmp['state'],"I") !== FALSE) {
            if (in_array("jobmaninit",$states))
               $state_ok=TRUE;
         }
         if (strpos($tmp['state'],"I") === FALSE) {
            if (in_array("jobmannotinit",$states))
               $state_ok=TRUE;
         }
         if (strpos($tmp['state'],"J") !== FALSE) {
            if (in_array("jobmanrunning",$states))
               $state_ok=TRUE;
         }
         if (strpos($tmp['state'],"J") === FALSE) {
            if (in_array("jobmannotrunning",$states))
               $state_ok=TRUE;
         }
         if ($state_ok == FALSE) {
            $res['cpu_num']--;
            continue;
         }
      }
      $tmp['method'] = trim(substr($buffer,$col[9],$len[9]));
      $tmp['domain'] = trim(substr($buffer,$col[10]));

      if($res['cpu_num'] && $extf != '' && tws_plan_match_xfilter($tmp['domain'], $tmp['cpu'], $extf, '!') == false) {
         tws_log('-- tws_plan_match_xfilter: '. $tmp['domain'] . '!'.$tmp['cpu'] .' don\'t match xfilter condition and removed.');
         $res['cpu_num']--;
         continue;
      }

      if ($page_size && ( $res['cpu_num'] < $first_onpage || $res['cpu_num'] > $last_onpage) )
         continue;

      if ($res['cpu_num']) {
         if (function_exists($od_callback) )
            $od_callback($tmp);
         else {
            foreach ($tmp as $key=>$val)
               $res[$key][$res['cpu_num']] = $val;
         }
      }
   }
   $tws_config['host_os']=='win32' && $pipes['last_buffer']=$last_buffer;
   $rc=tws_pclose($pipes);
   tws_log('-- tws_get_plan_workstation_list - conman command return code: '.$rc);
   tws_log('-- tws_get_plan_workstation_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
   $res['rc'] = $rc;
   return $res;
}

function tws_plan_match_xfilter($val1, $val2, $xfilter, $div='#') {
   if ( !preg_match_all('/[+~][^+~]+/',$xfilter, $arr) ) {
      $arr[0][] = '+'.$xfilter;
   }
   $match = false;
   foreach ($arr[0] as $cond) {     // divided in AND conditions
      $op = substr($cond,0,1);
      $cond = substr($cond,1);
      $cond = strtr($cond, '|', ',');
      $cond_arr = explode(',', $cond);
      // divided in OR conditions
      foreach($cond_arr as $mask) {
         if (strpos($mask, $div)) {
            $cval1 = substr($mask,0,strpos($mask, $div));
            $cval2 = substr($mask,strpos($mask, $div)+1);
         }
         else return false;
         // ~ conditions first
         if($op == '~' && tws_jokercmp($val1, $cval1) && tws_jokercmp($val2, $cval2) )
            return false;
      }
      $match = false;
      foreach($cond_arr as $mask) {
         $cval1 = substr($mask,0,strpos($mask, $div));
         $cval2 = substr($mask,strpos($mask, $div)+1);
         if ($op == '+' && tws_jokercmp($val1, $cval1) && tws_jokercmp($val2, $cval2))
            $match = true;
         elseif ($op == '~' )
            $match = true;
      }
      if ($match == false) return false;
   }
   return true;
}

/**
 * Gets the list of plan domains (and their status attrs)
 *
 * @param string $arg Domain name or filter (see doc to ss)
 * @param int $symphony Sympony file number (0 for current plan - see doc for setsym, listsym)
 * @return array List of domains or FALSE when fail
 */
function tws_get_plan_domain_list($arg, $symphony=0, $page_size = 0, $page = 1) {
   global $tws_config;
   include 'colpos_sd.php';

   tws_log('-- tws_get_plan_domain_list (start at '.basename(__FILE__).'['.__LINE__.'])');

   $arg = strtr($arg,'*','@');
   list($arg, $extf) = tws_planfilter_explode($arg);     // xfilters function

   $symtype = tws_profile('symtype');

   if ($symphony) {
      // Get actual symphony file number
      if (($symphony_lognum = tws_symphony_lognum($symtype, tws_profile('symphony_filename'))) === FALSE) {
         tws_log('Error: Unable to get symphony log number ('.__FILE__.'['.__LINE__.'])');
         $symphony_lognum = $symphony;
      }
      $st = (strtolower(trim($symtype)))=='archived' ? '' : $symtype;
      $command = new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/conman", $tws_config['conman_args'], "-gui", "setsym $st $symphony_lognum&sd $arg", hwi_cmd::operator('2>&1',FALSE));
   } else {
      $command = new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/conman", $tws_config['conman_args'], "-gui", "sd $arg", hwi_cmd::operator('2>&1',FALSE));
   }

   $stdout=array();
   if (tws_popen($command, $ec, $stdout, $stdout)===FALSE) {
      tws_error(array('command'=>$command->compile('log'), 'stdout'=>$stdout), 'Unable to open pipe');
      tws_log('Error: Unable to open pipe. ('.__FILE__.'['.__LINE__.'])');
      return FALSE;
   }

   $domain_num = 0;
   $tl = tws_log();

      $page_down = ($page - 1) * $page_size + 1;
      $page_up = $page * $page_size;

   foreach($stdout as $buffer){
      $tl && tws_log($buffer);

      // FIX for IWS 9.x - some data have no '^d' prefix (ticket 18515)
      $prefix = substr($buffer,0,2);
      if($prefix == '^h')
         $data_strings = true;  // data strings begin
      if(substr($buffer,0,3) == '%sd')
         $data_strings = false;  // end of data
      if($data_strings && $prefix != '^h' && $prefix != '^d')
         $buffer = "^d".$buffer;


      if (substr($buffer,0,2) === '^d' && substr($buffer,0,3) !== '^d/') {
         $domain_num++;
         if ($page_size && (($page_down > $domain_num) || ($page_up < $domain_num))) {
            continue;
         }
         $domain[$domain_num]=trim(substr($buffer,$col[1],$len[1]));
         if (substr($domain[$domain_num],0,1) == "*") {
            $domain[$domain_num]=substr($domain[$domain_num],1);
         }
         $manager[$domain_num]=trim(substr($buffer,$col[2],$len[2]));
         if (substr($manager[$domain_num],0,1) == "*") {
            $manager[$domain_num]=substr($manager[$domain_num],1);
         }
         $parent[$domain_num]=trim(substr($buffer,$col[3],$len[3]));
         if (substr($parent[$domain_num],0,1) == "*") {
            $parent[$domain_num]=substr($parent[$domain_num],1);
         }
         // xfilter
         if($domain_num && $extf != '' && tws_domain_match_xfilter($domain[$domain_num], $extf) == false) {
            tws_log('-- tws_plan_match_xfilter: '. $domain[$domain_num] .' don\'t match xfilter condition and removed.');
            $domain_num--;
            continue;
         }
      }
   }

   $list = array(
      'domain_num' => $domain_num,
      'domain' => $domain,
      'manager' => $manager,
      'parent' => $parent,
      'rc' => $ec
   );

   tws_log('-- tws_get_plan_domain_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
   return $list;
}

function tws_domain_match_xfilter($val, $xfilter) {
   if ( !preg_match_all('/[+~][^+~]+/',$xfilter, $arr) ) {
      $arr[0][] = '+'.$xfilter;
   }
   $match = false;
   foreach ($arr[0] as $cond) {     // divided in AND conditions
      $op = substr($cond,0,1);
      $cond = substr($cond,1);
      $cond = strtr($cond, '|', ',');
      $cond_arr = explode(',', $cond);
      // divided in OR conditions
      foreach($cond_arr as $mask) {
         // ~ conditions first
         if($op == '~' && tws_jokercmp($val, $mask) )
            return false;
      }
      $match = false;
      foreach($cond_arr as $mask) {
         if ($op == '+' && tws_jokercmp($val, $mask) )
            $match = true;
         elseif ($op == '~' )
            $match = true;
      }
      if ($match == false) return false;
   }
   return true;
}



/**
 * Gets the list of plan jobstreams (and their status attrs)
 *
 * @param string $arg Jobstream name or filter (see doc to ss)
 * @param int $symphony Sympony file number (0 for current plan - see doc for setsym, listsym)
 * @return array List of jobstreams or FALSE when fail
 */
function tws_get_plan_jobstream_list($arg, $symphony=0, $page_size = 0, $page = 1, $od_callback=null) {
   global $tws_config;
   include 'colpos_ss.php';

   tws_log('-- tws_get_plan_jobstream_list (start at '.basename(__FILE__).'['.__LINE__.']), arg=\''.$arg.'\' symphony=\''.$symphony.'\'');
   tws_log('-- tws_get_plan_jobstream_list - memory usage: '.intval(memory_get_usage()/1024).' kB');
   tws_log('-- tws_get_plan_jobstream_list - peak memory usage: '.intval(memory_get_peak_usage()/1024).' kB');
   tws_log("-- tws_get_plan_jobstream_list - Parameters: arg = $arg");

   $symtype = tws_profile('symtype');
   $arg = strtr($arg,'*','@');
   $tmp_arg = '';

   $extf=tws_ext_plan_filters($arg, $tmp_arg);

   // Workload Application filter
   if(!empty($extf['xapp'])){
      $app_data = tws_get_app_data($extf['xapp']);
      if(!empty($app_data['jobstream']) && empty($extf['xstream'])) $extf['xstream'] = '';
      foreach($app_data['jobstream'] as $i=>$js){
         if(!empty($extf['xstream'])) $extf['xstream'] .= ",";
         $extf['xstream'] .= $app_data['workstation'][$i]."#".$app_data['jobstream'][$i];
      }
   }

   list($arg, $keys) = tws_planfilter_explode_keys ($arg);
   $arg = $tmp_arg.$arg.$keys;

   if ($symphony) {
      // Get actual symphony file number
      if (($symphony_lognum=tws_symphony_lognum($symtype, tws_profile('symphony_filename')))===FALSE){
         tws_log('Error: Unable to get symphony log number ('.__FILE__.'['.__LINE__.'])');
         $symphony_lognum = $symphony;
      }
      $st=(strtolower(trim($symtype)))=='archived' ? '' : $symtype;
      $command=new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/conman", $tws_config['conman_args'], "-gui", "setsym $st $symphony_lognum&ss $arg;showid", hwi_cmd::operator('2>&1',FALSE));
   }
   else {
      $command=new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/conman", $tws_config['conman_args'], "-gui", "ss $arg;showid", hwi_cmd::operator('2>&1',FALSE));
   }

   $stdout=FALSE;
   if (($pipes=tws_popen($command, $ec, $stdout, $stdout))===FALSE) {
      tws_error(array('command'=>$command->compile('log'), 'stdout'=>$stdout), 'Unable to open pipe');
      tws_log('Error: Unable to open pipe. ('.__FILE__.'['.__LINE__.'])');
      return FALSE;
   }

   $last_buffer=0;
   $tmp=array();
   $t=0;
   $last_sched=FALSE;
   $oc=function_exists($od_callback) ? TRUE : FALSE;
   $tl=tws_log();
   $all_cols=array('cpu','schedule','entry_type','schedid','schedtime','state','priority','start_time','elapse_time','num_jobs','ok_jobs','limit','dep','jobnum','exit_code');

   $sch_cols=array('cpu','schedule','dep','schedid','state');

   if($tws_config['cpuinfo']['version']>='9.5')
      $sch_cols[] = 'folder';

   if($tws_config['cpuinfo']['version']>='9.5002')
      $sch_cols[] = 'workstation_folder';

   $res=array('nrows'=>0, 'nscheds'=>0, 'max_deps'=>0);
   $skip_stream=false;
      $page_down = ($page - 1) * $page_size + 1;
      $page_up = $page * $page_size;
   $data_strings = false; // when data strings begin

   $curent_folder =  '';      // Stream folder
   if($tws_config['cpuinfo']['version']>='9.5')
      $curent_folder =  '/';

   $ws_folder = '';
   if($tws_config['cpuinfo']['version']>='9.5002')
      $ws_folder = '/';

   while (is_resource($pipes[1]) && !feof($pipes[1])) {
      if (($buffer=fgets($pipes[1], 4096))===FALSE){
         @usleep($tws_config['proc_open_wait']);
         continue;
      }
      tws_log($buffer);

      // FIX for IWS 9.x - some data have no '^d' prefix (ticket 18515)
      $prefix = substr($buffer,0,2);
      if($prefix == '^h')
         $data_strings = true;  // data strings begin
      if(substr($buffer,0,3) == '%ss')
         $data_strings = false;  // end of data
      if($data_strings && $prefix != '^h' && $prefix != '^d')
         $buffer = "^d".$buffer;

      if (substr($buffer,0,2)==='^d') {
/*
      if (substr($buffer,0,3)==='^d/') {
         // empty line '^d/'
         $trim = trim(substr($buffer, 3));
         if($trim==''){
            tws_log("-- tws_get_plan_jobstream_list - Empty Workstation Folder");
            $ws_folder = '/';
            //$t--;
            continue;
         }
*/

         if(substr($buffer,2,2) == '>>'){  // IWS 9.5 // Jobstream Folder begin
           $curent_folder =  trim(substr($buffer, 4));
           $ws_folder = '/';
           tws_log("-- tws_get_plan_jobstream_list - Workstation Folder: $ws_folder");
           tws_log("-- tws_get_plan_jobstream_list - Stream Folder: $curent_folder");
//           $t--;
           continue;
         }

         // IWS 9.5.2 // Workstation Folder begin
         if($tws_config['cpuinfo']['version']>='9.5002' && substr($buffer,2, 1) == '/'  ){
            $ws_folder =  trim(substr($buffer, 2));
            tws_log("-- tws_get_plan_jobstream_list - Workstation Folder: $ws_folder");
            tws_log("-- tws_get_plan_jobstream_list - Stream Folder: $curent_folder");
            $trim = trim(substr($buffer, 3));
            if(!empty($trim))
//               $t--;
            continue;
         }

         $t++;

//         if($tws_config['cpuinfo']['version']>='9.5002' && empty($ws_folder) )
//            $ws_folder = '/';
         $tmp['workstation_folder'][$t] = $ws_folder;
         $tmp['folder'][$t] = $curent_folder;

         $tmp['cpu'][$t]=trim(substr($buffer,$col[1],$len[1]));
         $tmp['schedule'][$t]=trim(substr($buffer,$col[2],$len[2]));
         $tmp['state'][$t]=trim(substr($buffer,$col[4],$len[4]));

         $tmp['dep'][$t]=array();
         $dep_num=0;
         $deps=trim(substr($buffer,$col[11]));
             foreach (explode(';',$deps) as $d) {
                if (($d=trim($d))==='')
                    continue;
                if (preg_match('/{([A-Z0-9_\- ]{16})}(.*)/',$d, $r)) { // get schedid
                    if (empty($tmp['schedid'][1]))
                        $tmp['schedid'][1] = trim($r[1]); // SHOT-499 one position shift of schedid against data when parsing, when pos 1 is empty
                    else
                        $tmp['schedid'][$t] = trim($r[1]);
                   if(!empty($r[2])){   // for TWS 9.4 / conditional
                      $dep_num++;
                      $tmp['dep'][$t][$dep_num]=$r[2];
                   }
                }
                else {
                        $dep_num++;
                        $tmp['dep'][$t][$dep_num]=$d;
                }
             }

         if ($tmp['cpu'][$t]!='' && $tmp['schedule'][$t]!='') {
            $skip_stream=false;
            $_schedtime=trim(substr($buffer,$col[3],$len[3])); //format "hhmm MM/DD"

            //Processing of the schedtime extended filter criteria
            if (isset($extf['xschedtime'])) {
               if (preg_match('/(\d{2})(\d{2}) (\d{2})\/(\d{2})/',$_schedtime)) {
                  //ERR18569: Around the end of the year it happened that the sched date detection failed.
                  //The previous solution based on the date of the job stream instance insertion to the production plan
                  //often failed, mainly for these two reasons:
                  //   - insert time was in previous year than the actual sched time (see ERR18569)
                  //   - sometimes no insert time stamp is provided by conman, just the [Carry] flag instead
                  //The better solution is to detect the date with regards to the symphony date. This is already
                  //implemented in the tws_lib.php::tws_conman_to_iso function.
                  $st=strtotime(tws_conman_to_iso($_schedtime)); //the year is autodetected by using the symphony date

                  list($lt,$ht)=explode(',',$extf['xschedtime']);
                  if (!isset($ht)) {
                    if ($lt=strtotime(($iso=tws_userdate_to_iso($lt))===FALSE ? trim($lt) : $iso)) {
                      $ht=$lt+86400;
                    }
                  } else {
                     $lt=strtotime(($iso=tws_userdate_to_iso($lt))===FALSE ? trim($lt) : $iso);
                     $ht=strtotime(($iso=tws_userdate_to_iso($ht))===FALSE ? trim($ht) : $iso);
                  }
                  if ($lt && $ht) {
                     $tl && tws_log('-- tws_get_plan_jobstream_list : Schedtime filter: detected schedtime st='.$st.' ('.date('Y-m-d H:i:s T', $st).') , $lt='.$lt.' ('.date('Y-m-d H:i:s T', $lt).'), $ht='.$ht.' ('.date('Y-m-d H:i:s T', $ht).')');
                     if (($lt && $st<$lt) || ($ht && $st>=$ht)) {
                        tws_log('---- : Jobstream\'s schedtime doesn\'t match the SCHEDTIME filter. Skipping...');
                        $skip_stream=true;
                        continue;
                     }
                  } else tws_log('-- tws_get_plan_jobstream_list : WARNING : Unsupported SCHEDTIME filter: '.$extf['xschedtime']);
               } else tws_log('-- tws_get_plan_jobstream_list : ERROR : Jobstream\'s sched time out of format: '.$_schedtime.'. The filter cannot be used.');
            }

            //Processing extended filters

            if(!empty($extf) && tws_jobstream_match_xfilter($tmp, $t, $extf) == false) {
               tws_log('-- tws_get_plan_jobstream_list : ' . $tmp['schedule'][$t]. ' doesn\'t match ext. filter. Skipping...');
               $tmp['dep'][$t]=array();
               $t--;
               $skip_stream=true;
               continue;
            }

            // new schedule entry - process the last sched if $oc && $t>1 && _entry_type==schedule
            $res['nscheds']++;
            $res['nrows']++;
            if(!empty($tmp['dep'][$t-1]))  // php warning avoid
               $deps_count = count($tmp['dep'][$t-1]);
            else $deps_count = 0;
            $res['max_deps']=max($res['max_deps'], $deps_count);

            $befpg=$page_size && ($page_down > $res['nrows']);
            $aftpg=$page_size && ($page_up < $res['nrows']);
            if ($befpg || $aftpg) {
               if ($aftpg && !$last_sched) {
                  if ($oc) {
                     $tmp['offset']=$res['nrows']-$t;
                     $od_callback($tmp,1,$t-1);
                  } else {
                     foreach ($all_cols as $key) {
                        for ($i=1; $i<$t; $i++) {
                           $res[$key][$res['nrows']-$t+$i]=$tmp[$key][$i];
                        }
                     }
                  }
                  $last_sched=TRUE;
               }
            } elseif ($res['nrows']>1) {
               if ($oc) {
                  $tmp['offset']=$res['nrows']-$t;
                  $od_callback($tmp,1,$t-1);
               } else {
                  foreach ($all_cols as $key) {
                     for ($i=1; $i<$t; $i++) {
                        $res[$key][$res['nrows']-$t+$i]=@$tmp[$key][$i];
                     }
                  }
               }
            }

            // copy the new row on the begining of the $tmp struct, rewind $t pointer to 1
            foreach ($sch_cols as $key) {
               $tmp[$key][1]=$tmp[$key][$t];
            }
            $t=1;

            // get new schedule items
            $tmp['entry_type'][$t]='schedule';
            $tmp['schedtime'][$t]=$_schedtime;
            $tmp['state'][$t]=trim(substr($buffer,$col[4],$len[4]));
            $tmp['priority'][$t]=trim(substr($buffer,$col[5],$len[5]));
            $tmp['start_time'][$t]=trim(substr($buffer,$col[6],$len[6]));
            $tmp['elapse_time'][$t]=$check=substr($buffer,$col[7],$len[7]);
            if(($check[7]==' ' || $check[7]==')') && substr($buffer,$col[10]-1,1)==' '){
               $tmp['elapse_time'][$t] = trim($check);
               $tmp['num_jobs'][$t] = trim(substr($buffer,$col[8],$len[8]));
               $tmp['ok_jobs'][$t] = trim(substr($buffer,$col[9],$len[9]));
               $tmp['limit'][$t] = trim(substr($buffer,$col[10],$len[10]));
            }
            else {
               if($check[7]==' ' || $check[7]==')'){
                  $tmp['elapse_time'][$t] = trim($check);
                  $check = trim(substr($buffer, $col[8], 16));
               }
               else{
                  $tmp['elapse_time'][$t] = trim(substr($tmp['elapse_time'][$t], 0, 7));
                  $check = trim(substr($buffer, $col[8]-1, 16));
               }
               if( ($pos = strpos($check, ')'))!== false){
                  $tmp['elapse_time'][$t] .= substr($check, 0, $pos+1);
                  $check = substr($check, $pos+1);
               }
               $arr = explode(' ', $check);
               foreach($arr as $k=>$val)
                  if($val=='')
                     unset($arr[$k]);
               $arr = array_values($arr);
               if(count($arr)==3){
                  $tmp['num_jobs'][$t] = $arr[0];
                  $tmp['ok_jobs'][$t] = $arr[1];
                  $tmp['limit'][$t] = $arr[2];
               }
               elseif(count($arr)==2 && strlen($arr[0])<6){ // 10000 0
                  $tmp['num_jobs'][$t] = $arr[0];
                  $tmp['ok_jobs'][$t] = $arr[1];
                  $tmp['limit'][$t] = '';
               }
               else{
                  if(count($arr)==2 ) // 100001000 1024
                     $tmp['limit'][$t] = $arr[1];
                  else $tmp['limit'][$t] = ''; // 100001000
                  // can't divide
                  $tmp['num_jobs'][$t] = '>1K';
                  $tmp['ok_jobs'][$t] = '>1K';
               }
            }
         }
         elseif (@count($tmp['dep'][$t-1])>0) {
            if (!$skip_stream) {
               // processing last schedule dependencie continuing on this line
               $dep_num=count($tmp['dep'][$t-1]);
               foreach ($tmp['dep'][$t] as $d) {
                   if(strpos($d, '|') === false){    // normal situation
                        $dep_num++;
                        $tmp['dep'][$t-1][$dep_num]=$d;
                   }
                   else{
                       $tmp['dep'][$t-1][$dep_num] .= $d;
                   }
               }
            }
            $t--;
         }
      }
      $last_buffer=$buffer;
   }

   $tws_config['host_os']=='win32' && $pipes['last_buffer']=$last_buffer;
   $rc=tws_pclose($pipes);
   tws_log('-- tws_get_plan_jobstream_list - conman command return code: '.$rc);

   //processing the very last schedule on the page
   if (!$last_sched) {
      if ($oc) {
         $tmp['offset']=$res['nrows']-$t;
         $od_callback($tmp,1,$t);
      } else {
         foreach ($all_cols as $key) {
            for ($i=1; $i<=$t; $i++) {
               $res[$key][$res['nrows']-$t+$i]=@$tmp[$key][$i];
            }
         }
      }
   }

   tws_log('-- tws_get_plan_jobstream_list - memory usage: '.intval(memory_get_usage()/1024).' kB');
   tws_log('-- tws_get_plan_jobstream_list - peak memory usage: '.intval(memory_get_peak_usage()/1024).' kB');
   tws_log('-- tws_get_plan_jobstream_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
   $res['rc']=$rc;

   tws_log(' -- tws_get_plan_jobstream_list res: '. var_export($res, true));

   return $res;
}


function tws_jobstream_match_xfilter(&$tmp, $t, &$extf) {
global $tws_exc_xfilters, $tws_inc_xfilters;

   // - xfilters
   foreach ($tws_exc_xfilters as $xkey) {
      if( !isset($extf[$xkey]) ) {continue;}
      $x_inc = array();
      $x_inc = explode('&',$extf[$xkey]);
      foreach ($x_inc as $xcond) {
         if ( tws_xfilter_match($xkey, $xcond, $tmp, $t ) ) {
            return false;
         }
      }
      unset ($x_inc );
   }

   // + xfilters
   foreach ($tws_inc_xfilters as $xkey) {
      if( !isset($extf[$xkey]) ) {continue;}
      $x_inc = array();
      $x_inc = explode('&',$extf[$xkey]);
      foreach ($x_inc as $xcond) {
         if ( !tws_xfilter_match($xkey, $xcond, $tmp, $t ) ) {
            return false;
         }
      }
      unset ($x_inc );
   }
return true;
}

/**
 * Gets the list of plan jobs (and their status attrs)
 *
 * @param string $arg Job name or filter (see doc to ss)
 * @param int $symphony Sympony file number (0 for current plan - see doc for setsym, listsym)
 * $param od_callback - output data callback handler
 * @return array List of jobs or FALSE when fail
 */
function tws_get_plan_job_list($arg, $symphony=0, $page_size = 0, $page = 1, $od_callback=null) {
   global $tws_config;
   include 'colpos_sj.php';

   tws_log('-- tws_get_plan_job_list (start at '.basename(__FILE__).'['.__LINE__.'])');
   tws_log("-- tws_get_plan_job_list Params: arg = $arg");

   $symtype = tws_profile('symtype');
   $arg = strtr($arg,'*','@');
   $tmp_arg = '';
   $extf=tws_ext_plan_filters($arg, $tmp_arg);
         tws_log("-- tws_get_plan_job_list extf = ". var_export($extf, true));

   // Workload Application filter
   if(!empty($extf['xapp'])){
      $app_data = tws_get_app_data($extf['xapp']);
      if(!empty($app_data['jobstream']) && empty($extf['xjob'])) $extf['xjob'] = '';
      foreach($app_data['jobstream'] as $i=>$js){
         if(!empty($extf['xjob'])) $extf['xjob'] .= ",";
         $extf['xjob'] .= $app_data['workstation'][$i]."#".$app_data['jobstream'][$i].".@";
      }
   }

   list($arg, $keys) = tws_planfilter_explode_keys ($arg);
   //if($arg=='') $arg = '@#@.@';
   $arg = $tmp_arg.$arg.$keys;

   if (strstr($arg,";deps")) {
      $mode="deps";
      $offset=2;
      $conman_command="sj";
   } elseif (strstr($arg,";ssd")) {
      $mode="ssd";
      $offset=2;
      $conman_command="ss";
      $arg=str_replace(";ssd",";deps",$arg);
   } elseif (strstr($arg,"+short")) {
      $mode="normal";
      $offset=0;
      $conman_command="sj";
      $arg=str_replace("+short",";short",$arg);
   } else {
      $mode="normal";
      $offset=0;
      $conman_command="sj";
     }

   if ($symphony) {
      // Get actual symphony file number
      if (($symphony_lognum=tws_symphony_lognum($symtype, tws_profile('symphony_filename')))===FALSE){
         tws_log('Error: Unable to get symphony log number ('.__FILE__.'['.__LINE__.'])');
         $symphony_lognum = $symphony;
      }
      $st=(strtolower(trim($symtype)))=='archived' ? '' : $symtype;
      $command=new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/conman", $tws_config['conman_args'], "-gui", "setsym $st $symphony_lognum&$conman_command $arg;showid", hwi_cmd::operator('2>&1',FALSE));
   } else {
      $command=new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/conman", $tws_config['conman_args'], "-gui", "$conman_command $arg;showid", hwi_cmd::operator('2>&1',FALSE));
      $ws_scheduling_factory=tws_web_service('SchedulingFactory');
   }

   $stdout=FALSE;
   if (($pipes=tws_popen($command, $ec, $stdout, $stdout))===FALSE) {
      tws_error(array('command'=>$command->compile('log'), 'stdout'=>$stdout), 'Unable to open pipe');
      tws_log('Error: Unable to open pipe. ('.__FILE__.'['.__LINE__.'])');
      return FALSE;
   }

// $pipes PARSING

   $last_buffer=0;
   $res=array('nrows'=>0, 'njobs'=>0, 'nscheds'=>0, 'max_deps'=>0);
   $tmp=array();
   $last_sched=FALSE;
   $g=$t=0;
   $oc=function_exists($od_callback) ? TRUE : FALSE;
   if (($tl=tws_log())) $tlog_buffer=array();

   $all_cols=array('cpu','jobcpu','jobrun','schedule','schedrun','entry_type','sched_idx','schedtime','schedid','job','state','priority','start_time','elapse_time','dep','jobnum', 'exit_code');

   $sch_cols=array('cpu','schedule','schedtime');
   if($tws_config['cpuinfo']['version']>='9.5002')
      $sch_cols[] = 'workstation_folder';

   if($tws_config['cpuinfo']['version']>='9.5')
      $sch_cols[] = 'folder';

   $page_down = ($page - 1) * $page_size + 1;
   $page_up = $page * $page_size;

   $data_strings = false; // when data strings begin

   $curent_folder =  '';
   if($tws_config['cpuinfo']['version']>='9.5')
      $curent_folder =  '/';   // 9.5 Stream Folders

   $ws_folder = '';
   if($tws_config['cpuinfo']['version']>='9.5002')
      $ws_folder =  '/';   // for 9.5.2  WS Folders

   while (is_resource($pipes[1]) && !feof($pipes[1])) {
      if (($buffer=fgets($pipes[1], 4096))===FALSE){
         @usleep($tws_config['proc_open_wait']);
         continue;
      }
      // FIX for IWS 9.x - some data have no '^d' prefix (ticket 18515)
      $prefix = substr($buffer,0,2);
      if($prefix == '^h')
         $data_strings = true;  // data strings begin
      // (attention: may be emty string after '^h')
      // ('sj' command is in the begining of output istead of on the end as 'ss' have)
      if($data_strings && $prefix != '^h' && $prefix != '^d' && $prefix != '--' && trim(substr($buffer,$col[2]+$offset) != ''))
         $buffer = "^d$buffer";
      // --------------------------------------------------

      if (substr($buffer,0,2) !== '^d')
         tws_log($buffer);
      else {
/*
         if(empty(trim(substr($buffer,3)))){     // empty '^d/' string
            tws_log("-- tws_get_plan_job_list - empty string");
            continue;
         }
 */
         $tlog_buffer[]=$buffer;
         $buffer=rtrim($buffer," \x15");

         $g++;
         $t++;
         $dep_num=0;
         $deps_continue=FALSE;

         if($tws_config['cpuinfo']['version']>='9.5002' && substr($buffer,2, 1) == '/'  ){
            $ws_folder =  trim(substr($buffer, 2));
            tws_log("-- tws_get_plan_job_list - Workstation Folder: $ws_folder");
            $t--;
            continue;
         }

         if(substr($buffer,2,2) == '>>'){  // Stream Folder begin
            $curent_folder =  trim(substr($buffer, 4));
            $ws_folder =  '/';
            tws_log("-- tws_get_plan_job_list - Stream Folder: $curent_folder");
            $t--;
            continue;
         }


         // Handle the case where job's cpu is not the same as schedule's cpu
         if (substr($buffer,$colspecial[1]+$offset,2)=="#)") {
            $tmp['jobcpu'][$t]=trim(strtr(substr($buffer,$colspecial[2]+$offset,$lenspecial[2]),"("," "));
            $tmp['workstation_folder'][$t] = $ws_folder;
            $tmp['cpu'][$t]=trim(substr($buffer,$col[1]+$offset,$lenspecial[3]));
            $tmp['schedule'][$t]='';
            $tmp['schedtime'][$t]='';
         }
         else {
            $tmp['cpu'][$t]=trim(substr($buffer,$col[1]+$offset,$len[1]));
            $tmp['schedule'][$t]=trim(substr($buffer,$col[2]+$offset,$len[2]));
            $tmp['schedtime'][$t]=trim(substr($buffer,$col[3]+$offset,$len[3]));
            $tmp['jobcpu'][$t]='';
         }
         // strip the jobrun info from the cpu field
         $tmp['jobrun'][$t]='';
         if (tws_every_run_occurence($buffer)) $tmp['jobrun'][$t]=">>every run";
         elseif (tws_rerun_as_occurence($buffer)) $tmp['jobrun'][$t]=">>rerun as";
         elseif (tws_rerun_step_occurence($buffer)) $tmp['jobrun'][$t]=">>rerun step";
         elseif (tws_recovery_occurence($buffer)) $tmp['jobrun'][$t]=">>recovery";
         if ($tmp['jobrun'][$t]!=''){
            $tmp['cpu'][$t]='';
            $tmp['schedule'][$t]='';
            $tmp['schedtime'][$t]='';
         }

         if ($tmp['cpu'][$t]!='' && $tmp['schedule'][$t]!='' && ($tmp['schedtime'][$t]!='' || $tmp['jobrun'][$t]=='')) { //TWS8.3: sometimes the schedtime is missing in the conman's output
            // new schedule entry
            if($tws_config['cpuinfo']['version']>='9.5')
               $tmp['folder'][$t] = $curent_folder;

            $tmp['workstation_folder'][$t] = $ws_folder;

            // first decide if to save the complete block of rows that defines the previous schedule entry schedule
            if ($g>1) {
               //dump the trace log buffer
               while ($tl && count($tlog_buffer)>1) tws_log(array_shift($tlog_buffer));
               //process the last complete jobstream
               $res['nrows']+=tws_sj_process_schedule_buffer($res,$tmp,$g-$t,$g,$t,$all_cols,$od_callback,$page_size,$page_down,$page_up,$extf);
            }

            //copy the new row on the begining of the $tmp struct, rewind $t pointer to 1
            foreach ($sch_cols as $key) {
               $tmp[$key][1]=$tmp[$key][$t];
            }
            $t=1;

            // read all the other schedule entry
            $res['nscheds']++;
            $tmp['schedrun'][1]=trim(substr($buffer,$col[4]+$offset,$len[4]));
            $tmp['job'][1]='';
            $tmp['jobcpu'][1]='';
            $tmp['entry_type'][1]='schedule';
            $tmp['sched_idx'][1]=$last_sched_idx=$oc ? 1 : $res['nrows']+1;
            $tmp['dep'][1]=array();
            $tmp['jobnum'][1]='';
            $tmp['schedid'][1]='';
         }
         elseif (($tmp['job'][$t]=trim(substr($buffer,$col[4]+$offset,$len[4])))!='' && $tmp['job'][$t]{0}!='*'){
            // job entry - read the job attributes
            $res['njobs']++;
            $tmp['entry_type'][$t]='job';
            $tmp['sched_idx'][$t]=$last_sched_idx;
            if ($tmp['jobcpu'][$t]=='') $tmp['jobcpu'][$t]=$tmp['cpu'][1];
            $tmp['dep'][$t]=array();
            $tmp['schedrun'][$t]='';
            $tmp['schedid'][$t]='';
            $tmp['jobnum'][$t]='';
         }
         elseif ($tmp['entry_type'][$t-1]!='') {
            $deps_continue=TRUE;
         }

         if($deps_continue) {
            // for dependencies that continue on next line(s)
            $g--;
            $t--;
            $dep_num=count($tmp['dep'][$t]);
         }
         elseif ($page_size==0 || $g>= $page_down && $g<=$page_up) {
            $tmp['state'][$t]=trim(substr($buffer,$col[5]+$offset,$len[5]));
            $tmp['priority'][$t]=trim(substr($buffer,$col[6]+$offset,$len[6]));

            $tst=$tmp['start_time'][$t]=trim(substr($buffer,$col[7]+$offset,$len[7]));
            // if web service
            if (!empty($ws_scheduling_factory) && $tmp['entry_type'][$t]=='job' && !strpos($tst,':')) {
               $search_jobid=$tmp['cpu'][$tmp['sched_idx'][$t]].';'.$tmp['schedid'][$tmp['sched_idx'][$t]].';'.$tmp['job'][$t];
               $sf_query = array (
                  'engineName' => 'null',
                  'filter' => array (
                     array ('dataType'=>'JOB_ID', 'value'=>array($tmp['cpu'][$tmp['sched_idx'][$t]].';'.$tmp['schedid'][$tmp['sched_idx'][$t]].';'.$tmp['job'][$t])),
                  )
               );
               try {
                  $tl & $tlog_buffer[]='-- tws_get_plan_job_list : Trying to get the accurate start timestamp from SchedulingFactory web service';
                  @$sf_result=$ws_scheduling_factory->queryJobs($sf_query);
                  $tl & $tlog_buffer[]='-- tws_get_plan_job_list : SchedulingFactory web service returned: '.$sf_result->queryJobsReturn->JobInstance->startTime.' (UTC)';
                  preg_match('/(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(\.\d{3})?Z/', $sf_result->queryJobsReturn->JobInstance->startTime, $_r);
                  if ($_r[1]>1970 && ((intval($_r[2])-($m_curr=date('n')))*($d_curr=date('j'))+intval($_r[3])-$d_curr)<=1) {
                     $st_u=gmmktime($_r[4],$_r[5],$_r[6],$_r[2],$_r[3],$_r[1]);
                     $tmp['start_time'][$t]=date('H:i',$st_u);
                  } else {
                     $tl & $tlog_buffer[]='-- tws_get_plan_job_list : Cannot use the Start Time from SchedulingFactory (1970)';
                  }
               } catch (Exception $e) {
                  $tws_ws_parms['password']!='' && $tws_ws_parms['password']='*****';
                  tws_error(array('ws_query: '=>$sf_query, 'exception'=>$e->__toString()), 'Query to SchedulingFactory web service failed (SOAP initization correct).');
                  $tl & $tlog_buffer[]='-- tws_get_plan_job_list : Query to SchedulingFactory web service failed ('.$sf_query['filter'][0]['value'][0].')';
               }
            }
//TODO: the value of elapse time field returned by conman equals to the estimated time for jobs that haven't finished yet. The value
//      is displayed in round brackets. WebAdmin can take the estimated time value from IWS statistics or
            $tmp['elapse_time'][$t]=trim(substr($buffer,$col[8]+$offset,$len[8]));
            $tmp['exit_code'][$t]=trim(substr($buffer,$col[9]+$offset,$len[9]));
         }

            $deps=trim(substr($buffer,$col[10]+$offset));
            // from TWS 9.3 there is no semicolon separator between schedid and other deps
            // so add it:
            if (preg_match("/^({[A-Z0-9_\- ]{16}})/", $deps, $r) ){  // TODO: make single condition
              if (preg_match("/^{[A-Z0-9_\- ]{16}};/", $deps) ) {
                 ;
              }
              else
                 $deps = preg_replace("/^{[A-Z0-9_\- ]{16}}/", "$r[1];", $deps) ;
            }
            foreach (explode(';',$deps) as $d) {
               if (($d=trim($d))=='') continue;
               if (preg_match("/^{([A-Z0-9_\- ]{16})}/",$d, $row)) { // get schedid
                  $tmp['schedid'][1]=trim($row[1]);
               }
               if(strpos($d, '|') !== false) // conditional continue
                  $tmp['dep'][$t][$dep_num] .= $d;
               else{
                  $dep_num++;
                  $tmp['dep'][$t][$dep_num]=$d;
                  // Check whether this dependency is a job number...
                  if (preg_match("/^#J(\d+)$/", $d, $r)) {
                     $tmp['jobnum'][$t]=$r[1];
                     strpos($tmp['start_time'][$t],':') && $tmp['jobnum'][$t].='.'.str_replace(':','',$tmp['start_time'][$t]);
                  }
               }
            }
            // update max_deps value FIXME: needs to be in the tws_sj_process_schedule_buffer !
            $res['max_deps']=max($res['max_deps'],$dep_num);
      }
      $last_buffer=$buffer;
   }
   $tws_config['host_os']=='win32' && $pipes['last_buffer']=$last_buffer;
   $rc=tws_pclose($pipes);

   //processing the very last schedule in the conman output
   if ($t>1) {
      //dump the trace log buffer
      while ($tl && count($tlog_buffer)) tws_log(array_shift($tlog_buffer));
      //process the last schedule buffer
      $t++;
      $res['nrows']+=tws_sj_process_schedule_buffer($res,$tmp,$g-$t+1,$g,$t,$all_cols,$od_callback,$page_size,$page_down,$page_up,$extf);
   }

   tws_log('-- tws_get_plan_job_list - res: '.var_export($res, true));

   tws_log('-- tws_get_plan_job_list - conman command return code: '.$rc);
   tws_log('-- tws_get_plan_job_list - memory usage: '.intval(memory_get_usage()/1024).' kB');
   tws_log('-- tws_get_plan_job_list - peak memory usage: '.intval(memory_get_peak_usage()/1024).' kB');
   tws_log('-- tws_get_plan_job_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
   $res['rc'] = $rc;
   return $res;
}

///private function, usage exclusively in tws_get_plan_job_list function,
///returns number of rows stored
function tws_sj_process_schedule_buffer(&$res,&$tmp,$offset,&$g,&$t,&$all_cols,$od_callback,$page_size,$page_down,$page_up,&$extf) {
   global $tws_inc_xfilters, $tws_exc_xfilters;

   //initialization
   static $tl=NULL;
   $tl===NULL && $tl=tws_log();
   $skip_stream=false;
   //removed jobs flags
   $tmp['x']=array();

   tws_log('-- tws_sj_process_schedule_buffer: Processing jobstream: '.$tmp['cpu'][1].'#'.$tmp['schedule'][1].'('.$tmp['schedtime'][1].')');
//   tws_log("-- tws_sj_process_schedule_buffer: extf = ". var_export($extf, true));

   //jobstream jobs extended filtering
   // -- after removing each job, actualize the counters: $res['njobs']--; $g--; $t--;
   // -- if all jobs are deleted, remove the jobstream record too at the end: $res['nscheds']--; $g-- (or $g=$offset+1); $t-- (or $t=1);

   //Processing of jobstream's sched time extended filter criteria
   if (isset($extf['xschedtime'])) {

      if (preg_match('/(\d{2})(\d{2}) (\d{2})\/(\d{2})/', $tmp['schedtime'][1])) { //format "hhmm MM/DD"
         //ERR18569: Around the end of the year it happened that the sched date detection failed.
         //The previous solution based on the date of the job stream instance insertion to the production plan
         //often failed, mainly for these two reasons:
         //   - insert time was in previous year than the actual sched time (see ERR18569)
         //   - sometimes no insert time stamp is provided by conman, just the [Carry] flag instead
         //The better solution is to detect the date with regards to the symphony date. This is already
         //implemented in the tws_lib.php::tws_conman_to_iso function.
         $st=strtotime(tws_conman_to_iso($tmp['schedtime'][1])); //the year is autodetected by using the symphony date

         list($lt,$ht)=explode(',', $extf['xschedtime']);
         if (!isset($ht)) {
           if ($lt=strtotime(($iso=tws_userdate_to_iso($lt))===FALSE ? trim($lt) : $iso)) {
             $ht=$lt+86400;
           }
         } else {
            $lt=strtotime(($iso=tws_userdate_to_iso($lt))===FALSE ? trim($lt) : $iso);
            $ht=strtotime(($iso=tws_userdate_to_iso($ht))===FALSE ? trim($ht) : $iso);
         }

         if ($lt && $ht) {
            tws_log('-- tws_sj_process_schedule_buffer : Schedtime filter: detected schedtime st='.$st.' ('.date('Y-m-d H:i:s T', $st).'), $lt='.$lt.' ('.date('Y-m-d H:i:s T', $lt).'), $ht='.$ht.' ('.date('Y-m-d H:i:s T', $ht).')');
            if (($lt && $st<$lt) || ($ht && $st>=$ht)) {
               tws_log('---- : Jobstream\'s schedtime doesn\'t match the SCHEDTIME filter. Skipping...');
               $res['nscheds']--;
               $res['njobs']=$res['njobs']-$t+2;
               $g=$offset+1;
               //$t=1;
               $skip_stream=true;
            }
         } else tws_log('-- tws_sj_process_schedule_buffer : WARNING - Unsupported SCHEDTIME filter: '.$extf['xschedtime']);
      } else tws_log('-- tws_sj_process_schedule_buffer : ERROR - Sched time value out of format');
   }

   //processing of other extended filtering criteria
   if (isset($extf)) {
      // - xfilters
      if (!$skip_stream) {
         //foreach ($tws_exc_xfilters as $xkey) {
         if( isset($extf['-xjob']) ) {
            $x_inc = array();
            $x_inc = explode('&',$extf['-xjob']);
            foreach ($x_inc as $xcond) {
               // check CPU & JobStreams first if $skip_stream
               $js_match = tws_extf_pred_match('-xjob', $xcond, $tmp);
               if($js_match  == -1) {  // skip_stream
                  $tl && tws_log('-- tws_sj_process_schedule_buffer -XFILTERS : Jobstream skipped');
                  $res['nscheds']--;
                  $res['njobs']=$res['njobs']-$t+2;
                  $g=$offset+1;
                  $skip_stream=true;
                  break;
               }
               elseif($js_match == 1) {   // jobstream match
                  $tl && tws_log('-- tws_sj_process_schedule_buffer -XFILTERS : Jobstream accepted');
                  continue;
               }
               else {   // check every job
                  for($i=2; $i<$t; $i++) {
                     if (!isset($tmp['x'][$i]) && tws_xfilter_match('-xjob', $xcond, $tmp, $i)) {
                        $tmp['x'][$i]=TRUE; //set up the "removed job flag"
                        $res['njobs']--;
                        $g--;
                     }
                  }
               }
            }
            unset ($x_inc );
         }
         // -xstate
         if( isset($extf['-xstate']) ) {
            for($i=2; $i<$t; $i++) {
               if (!isset($tmp['x'][$i]) && tws_xfilter_match('-xstate', $extf['-xstate'], $tmp, $i)) {
                  $tmp['x'][$i]=TRUE; //set up the "removed job flag"
                  $res['njobs']--;
                  $g--;
               }
            }
         }

         if (($t-count($tmp['x']))<=2) {
            $tl && tws_log("-- tws_sj_process_schedule_buffer -XFILTERS : All jobs of the jobstream removed, skipping jobstream...");
            $skip_stream=true;
            $res['nscheds']--;
            $g=$offset+1;
         }
      }

      // + xfilters
      if (!$skip_stream) {
         if( isset($extf['xjob']) ) {
            $x_inc = explode('&',$extf['xjob']);
            foreach ($x_inc as $xcond) {
               // check CPU & JobStreams first if $skip_stream
               $js_match = tws_extf_pred_match('xjob', $xcond, $tmp);
               if( $js_match == -1 ) {
                  // skip_stream
                  $tl && tws_log('-- tws_sj_process_schedule_buffer +XFILTERS : Jobstream skipped.');
                  $res['nscheds']--;
                  $res['njobs']=$res['njobs']-$t+2;
                  $g=$offset+1;
                  $skip_stream=true;
                  break;
               }
               elseif ($js_match == 1) {    // JS match
                  $tl && tws_log('-- tws_sj_process_schedule_buffer +XFILTERS : Jobstream accepted.');
                  continue;
               }
               else {   // check every job
                  for($i=2; $i<$t; $i++) {
                     if (!isset($tmp['x'][$i]) && !tws_xfilter_match('xjob', $xcond, $tmp, $i)) {
                        $tmp['x'][$i]=TRUE; //set up the "removed job flag"
                        $res['njobs']--;
                        $g--;
                     }
                  }
               }
            }
            unset ($x_inc );
         }
         // xstate
         if( isset($extf['xstate']) ) {
            for($i=2; $i<$t; $i++) {
               if (!isset($tmp['x'][$i]) && !tws_xfilter_match('xstate', $extf['xstate'], $tmp, $i)) {
                  $tmp['x'][$i]=TRUE; //set up the "removed job flag"
                  $res['njobs']--;
                  $g--;
               }
            }
         }
         // xfollows (successors only)
         if( isset($extf['xfollows']) ) {
            if ( !tws_xfilter_match('xfollows', $extf['xfollows'], $tmp, 1 ) ) {
               for($i=2; $i<$t; $i++) {
                  if (!isset($tmp['x'][$i]) && !tws_xfilter_match('xfollows', $extf['xfollows'], $tmp, $i ) ) {
                     $tmp['x'][$i]=TRUE; //set up the "removed job flag"
                     $res['njobs']--;
                     $g--;
                  }
               }
            }
         }

         // dependent objects
         $xkeys=array('xneeds', 'xprompt', 'xopens');
         foreach($extf as $xkey=>$xval){
            if(in_array($xkey,$xkeys)) {
               if ( !tws_xfilter_match($xkey, $extf[$xkey], $tmp, 1 ) ) {
                  for($i=2; $i<$t; $i++) {
                     if (!isset($tmp['x'][$i]) && !tws_xfilter_match($xkey, $extf[$xkey], $tmp, $i ) ) {
                        $tmp['x'][$i]=TRUE; //set up the "removed job flag"
                        $res['njobs']--;
                        $g--;
                     }
                  }
               }
            }
         }

         if (($t-count($tmp['x']))<=2) {
            $tl && tws_log("-- tws_sj_process_schedule_buffer +XFILTERS : All jobs of the jobstream removed, skipping jobstream...");
            $skip_stream=true;
            $res['nscheds']--;
            $g=$offset+1;
         }
      }
   }

// storing the jobstream (if not removed by the ext filtering)
   if (!$skip_stream) {
      //number of new valid rows
      $nr=$t-count($tmp['x'])-1;

      $befpg=$page_size && ($page_down > $res['nrows'] + $nr);
      $aftpg=$page_size && ($page_up < $res['nrows']);
      if (!$befpg && !$aftpg) {
         if ($od_callback!==null) {
            $tmp['offset']=$offset;
            $od_callback($tmp,1,$t-1);
         } else {
            foreach ($all_cols as $key) {
               $j=0;
               for ($i=1; $i<$t; $i++) {
                  if (isset($tmp['x'][$i])) continue;
                  $j++;
                  $res[$key][$offset+$j]=$tmp[$key][$i];
               }
            }
         }
      }

      $tl && tws_log('-- tws_sj_process_schedule_buffer: Accepted '.$nr.' lines.');
      return $nr;
   }

   tws_log('--tws_sj_process_schedule_buffer: Whole jobstream skipped. Accepted 0 lines.');
   return 0;
}

// preprocess extFilter match
// check if WS & JS match
// return:
// -1 - JS not match
// 0  - need to check every job in JS
// 1  - whole JS match

function tws_extf_pred_match($xkey, $xcond, &$tmp){

switch ($xkey) {
   case 'xjob':
      $xcond = strtr($xcond, '|', ',');
      $xcond_arr = explode(',',$xcond);
      $match = -1;
      foreach ($xcond_arr as $xcond) {
         list($xcpu, $xstream, $xjob) = tws_explode_job($xcond);
         $streamname = $tmp['schedule'][1];
            if( tws_jokercmp($streamname, $xstream) && tws_jokercmp($tmp['cpu'][1], $xcpu) ) {
            if($xjob == '@')
               $match = 1;    // whole JS match
            else
               $match = 0;    // check all jobs in JS
            break;
         }
      }
      return $match;

   case '-xjob':
      $xcond = strtr($xcond, '|', ',');
      $xcond_arr = explode(',',$xcond);
      $match = 1;
      foreach ($xcond_arr as $xcond) {
         list($xcpu, $xstream, $xjob) = tws_explode_job($xcond);
         if($xjob != '@') { $match = 0; continue;}
         $streamname = $tmp['schedule'][1];
            if( tws_jokercmp($streamname, $xstream) && tws_jokercmp($tmp['cpu'][1], $xcpu) ) {
            if($xjob == '@')
               $match = -1;      // whole JS don't match
            else
               $match = 0;       //  check all jobs in JS
            break;
         }
      }
      return $match;
   }
   return FALSE;
}

// **************    Private functions for Job Extended Filters
// if job $tmp[i] have key condition
// $tmp is passed by adress only for speed
function tws_xfilter_match($xkey, $xcond, &$tmp, $i) {
   global $tws_config;
   // tws_log(" -- tws_xfilter_match Params: xkey = $xkey, xcond = $xcond");
   switch ($xkey) {
      case 'xjob':
      case '-xjob':
         $xcond = strtr($xcond, '|', ',');
         $xcond_arr = explode(',',$xcond);
         $match = false;
         foreach ($xcond_arr as $xcond) {
            list($xcpu, $xstream, $xjob) = tws_explode_job($xcond);
            $streamname = $tmp['sched_idx'][$i];
            $streamname = $tmp['schedule'][$streamname];
//            if($tws_config['cpuinfo']['version']>='9.5'){
//              $folder = $tmp['folder'][$i];
//               var_dump($folder);
//               die;
//               $streamname = $folder.$streamname;
//              }
            if( tws_jokercmp($tmp['job'][$i], $xjob) && tws_jokercmp($streamname, $xstream) && tws_jokercmp($tmp['jobcpu'][$i], $xcpu) ) {
               $match = true;
            }
         }
         return $match;


      case 'xstream':
      case '-xstream':
         $xcond = strtr($xcond, '|', ',');
         $xcond_arr = explode(',',$xcond);
         $match = false;
         foreach ($xcond_arr as $xcond) {
            list($xcpu, $xstream) = tws_explode_job($xcond);
            $streamname = $tmp['schedule'][$i];
            if($tws_config['cpuinfo']['version']>='9.5'){
               $folder = $tmp['folder'][$i];
               $streamname = $folder.$streamname;
            }
// TODO: xfilters            tws_log("-- xfilter: $xstream, streamname: $streamname");

            if( tws_jokercmp($streamname, $xstream) && tws_jokercmp($tmp['cpu'][$i], $xcpu) ) {
               $match = true;
            }
         }
         return $match;

      case 'xstate':
      case '-xstate':
         $xcond = strtr($xcond, '|', ',');
         $xcond_arr = explode(',',$xcond);
         $match = false;
         foreach ($xcond_arr as $xcond) {
            if($xcond != 'cancelled') {
               if($tmp['state'][$i] == strtoupper($xcond)) $match = true;
            }
            else {
               if ( tws_read_dep($tmp['dep'][$i], 'cancelled') == 'Cancelled')
                  $match = true;
            }
         }
         return $match;

      case 'xfollows':  // Successors only
      case '-xfollows':
         $follows = tws_read_dep($tmp['dep'][$i], 'follows');
         if(empty($follows)) return false;

         $xcond = explode(',', $xcond);

         foreach($xcond as $xfollow){
            list($xcpu, $xstream, $xjob) = tws_explode_job($xfollow);
            list($xsname, $xsid) = tws_explode_stream($xstream);     // divide $xstream on pieces

            foreach( $follows as $follow ) {
               $follow = substr($follow, 0, strrpos($follow, '('));     // remove state
               list($fcpu, $fstream, $fjob) = tws_explode_job($follow);
               if($fcpu == '@' && $fstream!='@')   // jobstream.job == mdm#jobstream.job
                  $fcpu=isset($tws_config['cpuinfo']['host']) ? $tws_config['cpuinfo']['host'] : $tws_config['localopts']['thiscpu'];
               elseif($fcpu == '@' && $fstream =='@'){ // internal dependence
                  if($xjob == '@') continue;
                  $fcpu = $tmp['cpu'][$tmp['sched_idx'][$i]];
                  $fstream = $tmp['schedule'][$tmp['sched_idx'][$i]];
               }
               list($fsname, $fsid) = tws_explode_stream($fstream);     // divide $fstream on pieces

               if($xsid != '' && $fsid == '') {
                  $fsid = $tmp['schedid'][$tmp['sched_idx'][$i]];
                  if ($xsid != $fsid)
                     continue;
               }
               if ( $xjob != '@' )  {
                  if( !tws_jokercmp($fjob, $xjob) ) { continue;}
                  elseif ($fstream == '@' && $fcpu == '@' ) { return true;}
               }
               if ($xsname != '' || $xsid !='') {
                  if ($xsid !='') {
                     if(!isset($fsid) ||  $fsid == '') {$fsid = '@';}
                     if( !tws_jokercmp($fsid, $xsid) ) { continue;}
                     elseif ($fcpu == '@') { return true;}
                  }
                  elseif($xsname !='') {
                     if(!isset($fsname) ||  $fsname == '') {$fsname = '@';}
                     if( !tws_jokercmp($fsname, $xsname) )
                             continue;
                     elseif ($fcpu == '@')
                        return true;
                  }
               }
               if ( $xcpu != '@')  {
                  if( !tws_jokercmp($fcpu, $xcpu) )
                     continue;
               }
               return true;
            }
         }
         return false;

      case 'xneeds':    // dependent objects only
         $needs = tws_read_dep($tmp['dep'][$i], 'needs');
         if(!isset($needs)) return false;
         $xcond = strtr($xcond, '|', ',');
         $xcond_arr = explode(',',$xcond);
         $match = false;
         foreach ($xcond_arr as $xcond) {
            list($xcpu, $xres) = tws_explode_job($xcond);
            foreach( $needs as $need ) {
               $need = substr($need, 0, strrpos($need, '('));     // remove state
               list($ncpu, $nres) = tws_explode_job($need);
               $pos = strpos($nres, ' ');
               if($pos !== false)         // remove count
                  $nres = substr($nres, $pos+1);
               //if($nres == $xres && $ncpu == $xcpu)
               if( $nres == $xres && tws_jokercmp($xcpu, $ncpu) )  // need cpu may by "@"
                  $match=true;
            }
         }
         return $match;

      case 'xopens':        // dependent objects only
         $opens = tws_read_dep($tmp['dep'][$i], 'opens');
         if(!isset($opens)) return false;
         $xcond = strtr($xcond, '|', ',');
         $xcond_arr = explode(',',$xcond);
         $match = false;
         foreach ($xcond_arr as $xcond) {
            list($xcpu, $xfile) = tws_explode_filefilter($xcond);
            foreach( $opens as $open ) {
               $open = substr($open, 0, strrpos($open, '('));     // remove state
               list($ocpu, $ofile) = tws_explode_filefilter($open);
               if($ofile == $xfile && $ocpu == $xcpu)
                  $match=true;
            }
         }
         return $match;

      case 'xprompt':          // dependent objects only
         $prompts = tws_read_dep($tmp['dep'][$i], 'prompt');
         if(!isset($prompts)) return false;
         $xcond = strtr($xcond, '|', ',');
         $xcond_arr = explode(',',$xcond);
         $match = false;
         foreach ($xcond_arr as $xcond) {
            foreach( $prompts as $prompt ) {
               if(is_numeric($xcond)) {
                  $prompt = substr($prompt, strpos($prompt, '#')+1);      // extract prompt num
                  $prompt = substr($prompt, 0, strpos($prompt, '('));
               }
               else {   // global prompt
                  $prompt = substr($prompt, 0, strpos($prompt, ')'));     // extract prompt name
                  $prompt = substr($prompt, strpos($prompt, '(')+1);
               }
               if( "$prompt" == "$xcond")
                  $match = true;
            }
         }
         return $match;
   }
}

//Input string:
//cpu#sched.job
//Returns array:
//arr[0]...cpu name (or @)
//arr[1]...schedule name (or @)
//arr[2]...job name or (@)
// OR
// Input string = cpu#name
//Returns array:
//arr[0]...cpu (or @)
//arr[1]...name (or @)
function tws_explode_job($string) {
   static $cache=array();

   if (isset($cache[$string])) return $cache[$string];

   if (($s=strpos($string, '#'))!==FALSE) {
      $arr[0] = substr($string, 0, $s);
   } else $s=-1;

   if (($j=strpos($string, '.'))!==FALSE) {
      $arr[1] = substr($string, $s+1, $j-$s-1);
      $arr[2] = substr($string, $j+1);
   } else {
      $arr[1] = substr($string, $s+1);
   }

   @$arr[0]=='' && $ar[0]='@';
   @$arr[1]=='' && $ar[1]='@';
   @$arr[2]=='' && $ar[2]='@';

   $cache[$string]=$arr;
   return $arr;
}

function tws_explode_filefilter ($string) {
   $arr = array();
   //strtok($string,"#");
   if(strpos($string, '#')) {
      $arr[0] = substr($string, 0, strpos($string, '#'));
      $arr[1] = substr($string, strpos($string, '#')+1);
   }
   else {
      $arr[0] = '@';
      $arr[1] = $string;
      }
   return $arr;
}

//Input:
// eg NAME[(time),(ID)]
// or NAME;ID
// or NAME
// or @/*
//Returns array:
//arr[0] : stream name
//arr[1] : sched id (or empty string)
function tws_explode_stream($stream) {
   if (strpos($stream, ';')!==FALSE) {
      $arr = explode(';',$stream);
      return ($arr);
   }

   if (strpos($stream, '[(')!==FALSE) {
      $arr = array();
      $arr[0] = strtok($stream,'[');
      $arr[1] = substr( $stream, strrpos($stream,'(')+1 );
      $arr[1] = substr( $arr[1], 0, strpos($arr[1],')') );
      return ($arr);
   }

      $arr = array($stream, '');
      return $arr;
   }

//
//    return $dependence_name param from $dependences array in format @#@.@(state)
//
//    if $dep_name missmatch return all array
//
function tws_read_dep (&$dep, $dep_name=false) {

   $dep_num = count($dep);
   $deps = array();

for ($i=1; $i<=$dep_num; $i++) {
   if (substr($dep[$i],0,5) == "AT = ") {
      $deps['at'] = $dep[$i];
   }
   elseif (strpos($dep[$i],"\$PROMPT:") !== FALSE) {
      $depx=strtok($dep[$i],"$");
      $temp=strtok(":");
      $dep_state=strtok("$");
      $dep_link=substr(strtok($depx,"("),1);

      $deps['prompt'][] =  $depx . "(" . $dep_state . ")";
   }
   elseif (strpos($dep[$i],"\$FOLLOWS:") !== FALSE) { //RUN_APPS[(0800 09/10/11),(0AAAAAAAAAAAAALH)].@$FOLLOWS:ABEND$
      $depx=strtok($dep[$i],"$");                     // DAILY_BACKUP(2200 09/09/11).CD_ROOT$FOLLOWS:READY$
      $temp=strtok(":");                              // MAKEPLAN$FOLLOWS:HOLD
      $dep_state=strtok("$");
      if (strpos($depx,"::") !== FALSE) {
         // if Internetwork dependency, strip double-quotes    FIXME !!! checkit
         $depx=str_replace("\"","&quot;",$depx);
      }
      if (strpos($depx,".")===FALSE) {
         // if job dependency has no schedule name, add it        FIXME !!!   checkit
         //$depx="${selection_cpu}#${selection_schedule}".($selection_schedtime!='' ? "($selection_schedtime)" : '').".$depx";
         $mdm=isset($tws_config['cpuinfo']['host']) ? $tws_config['cpuinfo']['host'] : $tws_config['localopts']['thiscpu'];
         if ($mdm == '') {$mdm='@';}
         $depx="$mdm#@".".$depx";
      }
      if (strpos($depx,"#")===FALSE) {
         // In case that the workstation name of the dependency (dependent object) is missing,     FIXME !!!   checkit
         // then it is considered that it is the domain manager (master):
         //
         // before it was the same as the workstation of the selected job/jobstream (>>WRONG!<<):
         // $depx="${selection_cpu}#${depx}";
         $mdm=isset($tws_config['cpuinfo']['host']) ? $tws_config['cpuinfo']['host'] : $tws_config['localopts']['thiscpu'];
         if ($mdm == '') {$mdm='@';}
         $depx=$mdm.'#'.$depx;
      }

      $deps['follows'][] =  $depx . "(" . $dep_state . ")";
   }
   elseif (strpos($dep[$i],"\$OPENS:") !== FALSE) {
      $depx=strtok($dep[$i],"$");
      $temp=strtok(":");
      $dep_state=strtok("$");
      if (strpos($depx,'#')===FALSE) {
         // In case that the workstation name of the dependency (dependent object) is missing,  FIXME !!!   checkit
         // then it is considered that it is the domain manager (master):
         //
         // before it was the same as the workstation of the selected job/jobstream (>>WRONG!<<):
         // $depx="${selection_cpu}#${depx}";
            $mdm=isset($tws_config['cpuinfo']['host']) ? $tws_config['cpuinfo']['host'] : $tws_config['localopts']['thiscpu'];
            if ($mdm == '') {$mdm='@';}
         $depx=$mdm.'#'.$depx;
      }
      $dep_link=urlencode($depx);

      $deps['opens'][] =  $depx . "(" . $dep_state . ")";
   }
   elseif (strpos($dep[$i],"\$NEEDS:") !== FALSE) {
      $depx=strtok($dep[$i],"$");
      $temp=strtok(":");
      $dep_state=strtok("$");
      $depx=trim($depx,'-');
      if (strpos($depx,'#')===FALSE) {
         // In case that the workstation name of the dependency (dependent object) is missing,  FIXME !!!   checkit
         // then it is considered that it is the domain manager (master):
         //
         // before it was the same as the workstation of the selected job/jobstream (>>WRONG!<<):
         // $depx="${selection_cpu}#${depx}";
            $mdm=isset($tws_config['cpuinfo']['host']) ? $tws_config['cpuinfo']['host'] : $tws_config['localopts']['thiscpu'];
            if ($mdm == '') {$mdm='@';}
         $depx=$mdm.'#'.$depx;
      }
      $dep_link=urlencode($depx);

      $deps['needs'][] =  $depx . "(" . $dep_state . ")";
   }
   elseif (strpos($dep[$i],"\$UNTIL:") !== FALSE) {
      $depx=htmlspecialchars(strtok($dep[$i],"$"));
      $temp=strtok(":");
      $dep_state=strtok("$");

      $deps['until'] =  $depx . "(" . $dep_state . ")";
   }
   elseif (substr($dep[$i],0,1) == "&") {
      $depx="EVERY " . substr($dep[$i],1);

      $deps['every'] =  $depx;
   }
   elseif ($dep[$i] == "[Confirmed]") {
      $deps['confirmed'] =  'Confirmed';
   }
   elseif ($dep[$i] == "[Cancelled]") {
      $deps['cancelled'] =  'Cancelled';
   }
   elseif (preg_match('/<(\d+)([:\/])(\d+)/', $dep[$i], $_r)) {
      $depx='DEADLINE: '.$_r[1].$_r[2].$_r[3];

      $deps['deadline'] =  $depx;
   }
}

if($dep_name) {
   return $deps[$dep_name];
}

   return $deps;
}

/**
 * Gets the list of plan jobs - INFO mode
 *
 * @param string $arg Job name or filter (see doc to ss)
 * @param int $symphony Sympony file number (0 for current plan - see doc for setsym, listsym)
 * $param od_callback - output data callback handler
 * @return array List of jobs or FALSE when fail
 */
function tws_get_plan_job_info_list($arg, $symphony=0, $page_size = 0, $page = 1, $od_callback=null) {
   global $tws_config;
   include 'colpos_sj.php';

   tws_log('-- tws_get_plan_job_info_list (start at '.basename(__FILE__).'['.__LINE__.'])');
   tws_log('-- tws_get_plan_job_info_list - memory usage: '.intval(memory_get_usage()/1024).' kB');
   tws_log('-- tws_get_plan_job_info_list - peak memory usage: '.intval(memory_get_peak_usage()/1024).' kB');

   $symtype = tws_profile('symtype');

   if ($symphony) {
      // Get actual symphony file number
      if (($symphony_lognum=tws_symphony_lognum($symtype, tws_profile('symphony_filename')))===FALSE){
         tws_log('Error: Unable to get symphony log number ('.__FILE__.'['.__LINE__.'])');
         $symphony_lognum = $symphony;
      }
      $st=(strtolower(trim($symtype)))=='archived' ? '' : $symtype;
      $command=new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/conman", $tws_config['conman_args'], "-gui", "setsym $st $symphony_lognum&sj $arg;showid;info", hwi_cmd::operator('2>&1',FALSE));
   } else {
      $command=new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/conman", $tws_config['conman_args'], "-gui", "sj $arg;showid;info", hwi_cmd::operator('2>&1',FALSE));
   }

   $stdout=FALSE;
   if (($pipes=tws_popen($command, $ec, $stdout, $stdout))===FALSE) {
      tws_error(array('command'=>$command->compile('log'), 'stdout'=>$stdout), 'Unable to open pipe');
      tws_log('Error: Unable to open pipe. ('.__FILE__.'['.__LINE__.'])');
      return FALSE;
   }

   $last_buffer=0;
   $res=array('nrows'=>0, 'njobs'=>0, 'nscheds'=>0);
   $tmp=array();
   $last_sched=FALSE;
   $t=0;
   $offset=0;
   $oc=function_exists($od_callback) ? TRUE : FALSE;
   $tl=tws_log();

   $all_cols=array('cpu','jobcpu','jobrun','schedule','sched_idx','entry_type','schedtime','job','script', 'recovery_type', 'recovery_job', 'recovery_prompt', 'twsrcmap');
   $sch_cols=array('cpu','schedule','schedtime');

   $page_down = ($page - 1) * $page_size + 1;
   $page_up = $page * $page_size;

   while (is_resource($pipes[1]) && !feof($pipes[1])) {
      if (($buffer=fgets($pipes[1], 4096))===FALSE){
         @usleep($tws_config['proc_open_wait']);
         continue;
      }
      $tl && tws_log($buffer);
      if (substr($buffer,0,2) === '^d') {
         $tl && tws_log($buffer);
         $buffer=rtrim($buffer," \x15");
         $res['nrows']++;
         $t++;
         $dep_num=0;
         $deps_continue=FALSE;

         // Handle case where job's cpu is not the same as schedule's cpu
         if (substr($buffer,$colspecial[1]+$offset,2)=="#)") {
            $tmp['jobcpu'][$t]=trim(strtr(substr($buffer,$colspecial[2]+$offset,$lenspecial[2]),"("," "));
            $tmp['cpu'][$t]=trim(substr($buffer,$col[1]+$offset,$lenspecial[3]));
            $tmp['schedule'][$t]='';
            $tmp['schedtime'][$t]='';
         } else {
            $tmp['cpu'][$t]=trim(substr($buffer,$col[1]+$offset,$len[1]));
            $tmp['schedule'][$t]=trim(substr($buffer,$col[2]+$offset,$len[2]));
            $tmp['schedtime'][$t]=trim(substr($buffer,$col[3]+$offset,$len[3]));
            $tmp['jobcpu'][$t]='';
         }
         // strip the jobrun info from the cpu field
         $tmp['jobrun'][$t]='';
         if (tws_every_run_occurence($buffer)) $tmp['jobrun'][$t]=">>every run";
         elseif (tws_rerun_as_occurence($buffer)) $tmp['jobrun'][$t]=">>rerun as";
         elseif (tws_rerun_step_occurence($buffer)) $tmp['jobrun'][$t]=">>rerun step";
         elseif (tws_recovery_occurence($buffer)) $tmp['jobrun'][$t]=">>recovery";
         if ($tmp['jobrun'][$t]!=''){
            $tmp['cpu'][$t]='';
            $tmp['schedule'][$t]='';
            $tmp['schedtime'][$t]='';
         }

         if ($tmp['cpu'][$t]!='' && $tmp['schedule'][$t]!='' && ($tmp['schedtime'][$t]!='' || $tmp['jobrun'][$t]=='')) { //TWS8.3: sometimes the schedtime is missing in the conman's output
            // new schedule entry

            // first decide if to save the complete block of rows that defines the previous schedule entry schedule
            $befpg=$page_size && ($page_down > $res['nrows']);
            $aftpg=$page_size && ($page_up < $res['nrows']);
            if ($befpg || $aftpg) {
               //if we're out of current page
               if ($aftpg && !$last_sched) {
                  // save the last schedule
                  if ($oc) {
                     $tmp['offset']=$res['nrows']-$t;
                     $od_callback($tmp,1,$t-1);
                  } else {
                     foreach ($all_cols as $key) {
                        for ($i=1; $i<$t; $i++) {
                           $res[$key][$res['nrows']-$t+$i]=$tmp[$key][$i];
                        }
                     }
                  }
                  $last_sched=TRUE; //last schedule on page printed
               }
            } elseif ($res['nrows']>1) {
               // save the completed schedule block
               if ($oc) {
                  $tmp['offset']=$res['nrows']-$t;
                  $od_callback($tmp,1,$t-1);
               } else {
                  foreach ($all_cols as $key) {
                     for ($i=1; $i<$t; $i++) {
                        $res[$key][$res['nrows']-$t+$i]=$tmp[$key][$i];
                     }
                  }
               }
            }
            //copy the new row on the begining of the $tmp struct, rewind $t pointer to 1
            foreach ($sch_cols as $key) {
               $tmp[$key][1]=$tmp[$key][$t];
            }
            $t=1;

            // read all the other schedule entry
            $res['nscheds']++;
            $tmp['schedrun'][1]=trim(substr($buffer,$col[4]+$offset,$len[4]));
            $tmp['job'][1]='';
            $tmp['jobcpu'][1]='';
            $tmp['entry_type'][1]='schedule';
            $tmp['sched_idx'][1]=$last_sched_idx=$oc ? 1 : $res['nrows'];
         } elseif (($tmp['job'][$t]=trim(substr($buffer,$col[4]+$offset,$len[4])))!='' && $tmp['job'][$t]{0}!='*'){
            // job entry - read the
            $res['njobs']++;
            $tmp['entry_type'][$t]='job';
            $tmp['sched_idx'][$t]=$last_sched_idx;
            if ($tmp['jobcpu'][$t]=='') $tmp['jobcpu'][$t]=$tmp['cpu'][1];
            $tmp['recovery_type'][$t]='';
            $tmp['recovery_job'][$t]='';
            $tmp['recovery_prompt'][$t]='';
            $tmp['script'][$t]='';
            $tmp['twsrcmap'][$t]='';
         } elseif ($tmp['entry_type'][$t-1]!='') {
            // for dependencies that continue on next line(s)
            $res['nrows']--;
            $t--;
         }

         if ($tmp['entry_type'][$t]!='schedule') {
            $trt=trim(substr($buffer,$script_col[5]+$offset,$script_len[5]));
            if ($trt=='CO' || $trt=='RE' || $trt=='ST') {
               $tmp['recovery_type'][$t]=$trt;
               $tmp['recovery_job'][$t]=trim(substr($buffer,$script_col[6]+$offset,$script_len[6]));
               $tmp['recovery_prompt'][$t]=trim(substr($buffer,$script_col[7]+$offset,$script_len[7]));
               $script_length=$script_col[5]-$script_col[4];
            } else {
               $script_length=$script_len[4];
            }
            $scr=trim(substr($buffer,$script_col[4]+$offset,$script_length));
            if ($scr!=='') {
               if (preg_match('/\s*TWSRCMAP:\s*(.+)$/i', $scr, $_r)) {
                  $tmp['twsrcmap'][$t]=$_r[1];
                  $scr=preg_replace('/\s*TWSRCMAP:\s*.+$/', '', $scr);
               }
               $tmp['script'][$t]=$scr;
            }
         }
      }
      $last_buffer=$buffer;
   }

   $tws_config['host_os']=='win32' && $pipes['last_buffer']=$last_buffer;
   $rc=tws_pclose($pipes);
   tws_log('-- tws_get_plan_job_info_list - conman command return code: '.$rc);

   //processing the very last schedule on the page
   if (!$last_sched) {
      if ($oc) {
         $tmp['offset']=$res['nrows']-$t;
         $od_callback($tmp,1,$t);
      } else {
         foreach ($all_cols as $key) {
            for ($i=1; $i<=$t; $i++) {
               $res[$key][$res['nrows']-$t+$i]=$tmp[$key][$i];
            }
         }
      }
   }

   tws_log('-- tws_get_plan_job_info_list - memory usage: '.intval(memory_get_usage()/1024).' kB');
   tws_log('-- tws_get_plan_job_info_list - peak memory usage: '.intval(memory_get_peak_usage()/1024).' kB');
   tws_log('-- tws_get_plan_job_info_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
   return $res;
}


/**
 * Gets the list of plan jobs - LOGON mode
 *
 * @param string $arg Job name or filter (see doc to ss)
 * @param int $symphony Sympony file number (0 for current plan - see doc for setsym, listsym)
 * $param od_callback - output data callback handler
 * @return array List of jobs or FALSE when fail
 */
function tws_get_plan_job_logon_list($arg, $symphony=0, $page_size = 0, $page = 1, $od_callback=null) {
   global $tws_config;
   include 'colpos_sj.php';

   tws_log('-- tws_get_plan_job_logon_list (start at '.basename(__FILE__).'['.__LINE__.'])');
   tws_log('-- tws_get_plan_job_logon_list - memory usage: '.intval(memory_get_usage()/1024).' kB');
   tws_log('-- tws_get_plan_job_logon_list - peak memory usage: '.intval(memory_get_peak_usage()/1024).' kB');

   $symtype = tws_profile('symtype');

   if ($symphony) {
      // Get actual symphony file number
      if (($symphony_lognum=tws_symphony_lognum($symtype, tws_profile('symphony_filename')))===FALSE){
         tws_log('Error: Unable to get symphony log number ('.__FILE__.'['.__LINE__.'])');
         $symphony_lognum = $symphony;
      }
      $st=(strtolower(trim($symtype)))=='archived' ? '' : $symtype;
      $command=new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/conman", $tws_config['conman_args'], "-gui", "setsym $st $symphony_lognum&sj $arg;showid;logon", hwi_cmd::operator('2>&1',FALSE));
   } else {
      $command=new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/conman", $tws_config['conman_args'], "-gui", "sj $arg;showid;logon", hwi_cmd::operator('2>&1',FALSE));
   }

   $stdout=FALSE;
   if (($pipes=tws_popen($command, $ec, $stdout, $stdout))===FALSE) {
      tws_error(array('command'=>$command->compile('log'), 'stdout'=>$stdout), 'Unable to open pipe');
      tws_log('Error: Unable to open pipe. ('.__FILE__.'['.__LINE__.'])');
      return FALSE;
   }

   $last_buffer=0;
   $res=array('nrows'=>0, 'njobs'=>0, 'nscheds'=>0);
   $tmp=array();
   $last_sched=FALSE;
   $t=0;
   $offset=0;
   $oc=function_exists($od_callback) ? TRUE : FALSE;
   $tl=tws_log();

   $all_cols=array('cpu','jobcpu','jobrun','schedule','sched_idx','entry_type','schedtime','job','state', 'jobnum', 'logon', 'exit_code');
   $sch_cols=array('cpu','schedule','schedtime');

   $page_down = ($page - 1) * $page_size + 1;
   $page_up = $page * $page_size;

   while (is_resource($pipes[1]) && !feof($pipes[1])) {
      if (($buffer=fgets($pipes[1], 4096))===FALSE){
         @usleep($tws_config['proc_open_wait']);
         continue;
      }
      $tl && tws_log($buffer);
      if (substr($buffer,0,2) === '^d') {
         $tl && tws_log($buffer);
         $buffer=rtrim($buffer," \x15");
         $res['nrows']++;
         $t++;
         $dep_num=0;
         $deps_continue=FALSE;

         // Handle case where job's cpu is not the same as schedule's cpu
         if (substr($buffer,$colspecial[1]+$offset,2)=="#)") {
            $tmp['jobcpu'][$t]=trim(strtr(substr($buffer,$colspecial[2]+$offset,$lenspecial[2]),"("," "));
            $tmp['cpu'][$t]=trim(substr($buffer,$col[1]+$offset,$lenspecial[3]));
            $tmp['schedule'][$t]='';
            $tmp['schedtime'][$t]='';
         } else {
            $tmp['cpu'][$t]=trim(substr($buffer,$col[1]+$offset,$len[1]));
            $tmp['schedule'][$t]=trim(substr($buffer,$col[2]+$offset,$len[2]));
            $tmp['schedtime'][$t]=trim(substr($buffer,$col[3]+$offset,$len[3]));
            $tmp['jobcpu'][$t]='';
         }
         // strip the jobrun info from the cpu field
         $tmp['jobrun'][$t]='';
         if (tws_every_run_occurence($buffer)) $tmp['jobrun'][$t]=">>every run";
         elseif (tws_rerun_as_occurence($buffer)) $tmp['jobrun'][$t]=">>rerun as";
         elseif (tws_rerun_step_occurence($buffer)) $tmp['jobrun'][$t]=">>rerun step";
         elseif (tws_recovery_occurence($buffer)) $tmp['jobrun'][$t]=">>recovery";
         if ($tmp['jobrun'][$t]!=''){
            $tmp['cpu'][$t]='';
            $tmp['schedule'][$t]='';
            $tmp['schedtime'][$t]='';
         }

         if ($tmp['cpu'][$t]!='' && $tmp['schedule'][$t]!='' && ($tmp['schedtime'][$t]!='' || $tmp['jobrun'][$t]=='')) { //TWS8.3: sometimes the schedtime is missing in the conman's output
            // new schedule entry

            // first decide if to save the complete block of rows that defines the previous schedule entry schedule
            $befpg=$page_size && ($page_down > $res['nrows']);
            $aftpg=$page_size && ($page_up < $res['nrows']);
            if ($befpg || $aftpg) {
               //if we're out of current page
               if ($aftpg && !$last_sched) {
                  // save the last schedule
                  if ($oc) {
                     $tmp['offset']=$res['nrows']-$t;
                     $od_callback($tmp,1,$t-1);
                  } else {
                     foreach ($all_cols as $key) {
                        for ($i=1; $i<$t; $i++) {
                           $res[$key][$res['nrows']-$t+$i]=$tmp[$key][$i];
                        }
                     }
                  }
                  $last_sched=TRUE; //last schedule on page printed
               }
            } elseif ($res['nrows']>1) {
               // save the completed schedule block
               if ($oc) {
                  $tmp['offset']=$res['nrows']-$t;
                  $od_callback($tmp,1,$t-1);
               } else {
                  foreach ($all_cols as $key) {
                     for ($i=1; $i<$t; $i++) {
                        $res[$key][$res['nrows']-$t+$i]=$tmp[$key][$i];
                     }
                  }
               }
            }
            //copy the new row on the begining of the $tmp struct, rewind $t pointer to 1
            foreach ($sch_cols as $key) {
               $tmp[$key][1]=$tmp[$key][$t];
            }
            $t=1;

            // read all the other schedule entry
            $res['nscheds']++;
            $tmp['schedrun'][1]=trim(substr($buffer,$col[4]+$offset,$len[4]));
            $tmp['job'][1]='';
            $tmp['jobcpu'][1]='';
            $tmp['entry_type'][1]='schedule';
            $tmp['sched_idx'][1]=$last_sched_idx=$oc ? 1 : $res['nrows'];
         } elseif (($tmp['job'][$t]=trim(substr($buffer,$col[4]+$offset,$len[4])))!='' && $tmp['job'][$t]{0}!='*'){
            // job entry - read the
            $res['njobs']++;
            $tmp['entry_type'][$t]='job';
            $tmp['sched_idx'][$t]=$last_sched_idx;
            if ($tmp['jobcpu'][$t]=='') $tmp['jobcpu'][$t]=$tmp['cpu'][1];
            $tmp['state'][$t]=trim(substr($buffer,$logon_col[5]+$offset,$logon_len[5]));
            $tmp['jobnum'][$t]=trim(substr($buffer,$logon_col[6]+$offset,$logon_len[6]));
            $tmp['logon'][$t]=trim(substr($buffer,$logon_col[7]+$offset,$logon_len[7]));
            $tmp['exit_code'][$t]=trim(substr($buffer,$logon_col[8]+$offset,$logon_len[8]));
         } elseif ($tmp['entry_type'][$t-1]!='') {
            //should not happen in LOGON mode!
            $res['nrows']--;
            $t--;
         }
      }
      $last_buffer=$buffer;
   }

   $tws_config['host_os']=='win32' && $pipes['last_buffer']=$last_buffer;
   $rc=tws_pclose($pipes);
   tws_log('-- tws_get_plan_job_logon_list - conman command return code: '.$rc);

   //processing the very last schedule on the page
   if (!$last_sched) {
      if ($oc) {
         $tmp['offset']=$res['nrows']-$t;
         $od_callback($tmp,1,$t);
      } else {
         foreach ($all_cols as $key) {
            for ($i=1; $i<=$t; $i++) {
               $res[$key][$res['nrows']-$t+$i]=$tmp[$key][$i];
            }
         }
      }
   }

   tws_log('-- tws_get_plan_job_logon_list - memory usage: '.intval(memory_get_usage()/1024).' kB');
   tws_log('-- tws_get_plan_job_logon_list - peak memory usage: '.intval(memory_get_peak_usage()/1024).' kB');
   tws_log('-- tws_get_plan_job_logon_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
   return $res;
}



/**
 * Gets the list of plan resources (and their status attrs)
 *
 * @param string $arg Resource name or filter (see doc to ss)
 * @param int $symphony Sympony file number (0 for current plan - see doc for setsym, listsym)
 * @return array List of resources or FALSE when fail
 */
function tws_get_plan_resource_list($arg, $symphony=0, $page_size = 0, $page = 1) {
   global $tws_config;
   include 'colpos_sr.php';

   tws_log('-- tws_get_plan_resource_list (start at '.basename(__FILE__).'['.__LINE__.'])');

   $arg = strtr($arg,'*','@');
   list($arg, $extf) = tws_planfilter_explode($arg, '#');      // xfilters function

   $symtype = tws_profile('symtype');

   if ($symphony) {
      // Get actual symphony file number
      if (($symphony_lognum=tws_symphony_lognum($symtype, tws_profile('symphony_filename')))===FALSE){
         tws_log('Error: Unable to get symphony log number ('.__FILE__.'['.__LINE__.'])');
         $symphony_lognum = $symphony;
      }
      $st=(strtolower(trim($symtype)))=='archived' ? '' : $symtype;
      $command=new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/conman", $tws_config['conman_args'], "-gui", "setsym $st $symphony_lognum&sr $arg", hwi_cmd::operator('2>&1',FALSE));
   } else {
      $command=new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/conman", $tws_config['conman_args'], "-gui", "sr $arg", hwi_cmd::operator('2>&1',FALSE));
   }

   $stdout=array();
   if (tws_popen($command, $ec, $stdout, $stdout) === FALSE) {
      tws_error(array('command'=>$command->compile('log'), 'stdout'=>$stdout), 'Unable to open pipe');
      tws_log('Error: Unable to open pipe. ('.__FILE__.'['.__LINE__.'])');
      return FALSE;
   }

   $resource_num = 0;
   $tl = tws_log();
   $page_down = ($page - 1) * $page_size + 1;
   $page_up = $page * $page_size;

   $res_folder =  '';      // Stream folder
   if($tws_config['cpuinfo']['version']>='9.5')
      $res_folder =  '/';

   $ws_folder = '';
   if($tws_config['cpuinfo']['version']>='9.5002')
      $ws_folder = '/';


   foreach($stdout as $buffer){
      $tl && tws_log($buffer);

      // FIX for IWS 9.x - some data have no '^d' prefix (ticket 18515)
      $prefix = substr($buffer,0,2);
      if($prefix == '^h')
         $data_strings = true;  // data strings begin
      if(substr($buffer,0,3) == '%sr')
         $data_strings = false;  // end of data
      if($data_strings && $prefix != '^h' && $prefix != '^d')
         $buffer = "^d".$buffer;


      if (substr($buffer,0,2) === '^d'){

         $trim = trim(substr($buffer,2));
         if($trim=='/')             // empty line '^d/'
            continue;

         if(substr($buffer,2,2) == '>>'){  // IWS 9.5 // Resource Folder begin
            $res_folder =  trim(substr($buffer, 4));
            tws_log("-- tws_get_plan_resource_list - Resource Folder: $res_folder");
            continue;
         }

         // IWS 9.5.2 // Workstation Folder begin
         if($tws_config['cpuinfo']['version']>='9.5002' && substr($buffer,2, 1) == '/'  ){
            $ws_folder =  trim(substr($buffer, 2));
            tws_log("-- tws_get_plan_resource_list - Workstation Folder: $ws_folder");
            continue;
         }

         $resource_num++;

         if ($page_size && (($page_down > $resource_num) || ($page_up < $resource_num))) {
            continue;
         }

         $workstation_folder[$resource_num] = $ws_folder;
         $resource_folder[$resource_num] = $res_folder;

         $cpu_resource[$resource_num]=trim(substr($buffer,$col[1],$len[1]));     // resource cpu

         if ($cpu_resource[$resource_num] == "") {
            $cpu[$resource_num]="";
            $resource[$resource_num]="";
         }
         else {
            $cpu[$resource_num]=strtok($cpu_resource[$resource_num],"#");
            $resource[$resource_num]=strtok("#");
         }

         $total[$resource_num]=trim(substr($buffer,$col[2],$len[2]));
         $available[$resource_num]=trim(substr($buffer,$col[3],$len[3]));
         $in_use[$resource_num]=trim(substr($buffer,$col[4],$len[4]));
         $used_by[$resource_num]=trim(substr($buffer,$col[5]));
         if (substr($in_use[$resource_num],0,2) == "No") {
            $in_use[$resource_num]=" ";
            $used_by[$resource_num]="No holders of this resource";
         }
         if($resource_num && $extf != '' && tws_plan_match_xfilter($cpu[$resource_num], $resource[$resource_num], $extf) == false) {
            tws_log('-- tws_plan_match_xfilter: '. $cpu[$resource_num] .'#'. $resource[$resource_num] .' don\'t match xfilter condition and removed.');
            $resource_num--;
            continue;
         }
      }
   }

   $list = array(
      'resource_num' => $resource_num,
      'workstation_folder' => $workstation_folder,
      'cpu_resource' => $cpu_resource,
      'cpu' => $cpu,
      'resource_folder' => $resource_folder,
      'resource' => $resource,
      'total' => $total,
      'available' => $available,
      'in_use' => $in_use,
      'used_by' => $used_by,
       'rc' => $ec);

   tws_log('-- tws_get_plan_resource_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
   tws_log('-- tws_get_plan_resource_list Res: '. var_export($list, true) );

   return $list;
}

/**
 * Gets the list of plan prompts (and their status attrs)
 *
 * @param string $arg Prompt name or filter (see doc to ss)
 * @param int $symphony Sympony file number (0 for current plan - see doc for setsym, listsym)
 * @return array List of prompts or FALSE when fail
 */
function tws_get_plan_prompt_list($arg, $symphony=0, $page_size = 0, $page = 1) {
   global $tws_config;

   tws_log('-- tws_get_plan_prompt_list (start at '.basename(__FILE__).'['.__LINE__.'])');

   $symtype = tws_profile('symtype');
   // divide ;keys
   $extf=$arg; $keys='';
   if (($pos=strpos($arg,'[TMP]'))!==false )
      $arg = substr($arg, 0, $pos);
   if (($pos=strpos($arg,';'))!== false) {
      $keys = substr($arg, $pos);
      $extf = substr($arg, 0, $pos);
   }
   $arg = '@'.$keys;
   $nmptrn="[A-Z][A-Z0-9_\-]*";
   if ($tws_config['cpuinfo']['version'] >= '9.5002'){
       $arg ='/@/@'.$keys;
       $nmptrn="[A-Z\/][A-Z0-9_\-\/]*";
   }

   if ($symphony) {
      // Get actual symphony file number
      if (($symphony_lognum=tws_symphony_lognum($symtype, tws_profile('symphony_filename')))===FALSE){
         tws_log('Error: Unable to get symphony log number ('.__FILE__.'['.__LINE__.'])');
         $symphony_lognum = $symphony;
      }
      $st=(strtolower(trim($symtype)))=='archived' ? '' : $symtype;
      $command=new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/conman", $tws_config['conman_args'], "-gui", "setsym $st $symphony_lognum&sp $arg", hwi_cmd::operator('2>&1',FALSE));
   } else {
      $command=new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/conman", $tws_config['conman_args'], "-gui", "sp $arg", hwi_cmd::operator('2>&1',FALSE));
   }

   $stdout=array();
   if (tws_popen($command, $ec, $stdout, $stdout) === FALSE) {
      tws_error(array('command'=>$command->compile('log'), 'stdout'=>$stdout), 'Unable to open pipe');
      tws_log('Error: Unable to open pipe. ('.__FILE__.'['.__LINE__.'])');
      return FALSE;
   }

   $prompt_num = 0;
   $tl = tws_log();
   $page_down = ($page - 1) * $page_size + 1;
   $page_up = $page * $page_size;
   $state=$number=$prompt_name=$prompt_text=array();

   foreach($stdout as $buffer){
      $tl && tws_log($buffer);

      // FIX for IWS 9.x - some data have no '^d' prefix (ticket 18515)
      $prefix = substr($buffer,0,2);
      if($prefix == '^h')
         $data_strings = true;  // data strings begin
      if(substr($buffer,0,3) == '%sp')
         $data_strings = false;  // end of data
      if($data_strings && $prefix != '^h' && $prefix != '^d')
         $buffer = "^d".$buffer;

      if (substr($buffer,0,2) === '^d') {
         // in TWS 9.5 conman format can have strings: "^d/" or "^d>> /FOLDER/"
          if(substr($buffer,2,2) == '>>'){  // IWS 9.5 // Prompt Folder begin
              $current_folder =  trim(substr($buffer, 4));
              tws_log("prompt folder = $current_folder");
              continue;
        }
        if (trim(substr($buffer,3,5)) != '' && substr($buffer,2,2) != '>>') {
            $prompt_num++;
            $removed=false;
            if ($page_size && (($page_down > $prompt_num) || ($page_up < $prompt_num))) {
               continue;
            }
            $state[$prompt_num]=trim(substr($buffer,2,5));
// analyze the prompt name (eventually CF follow names)
            $open_paren=strpos($buffer,"(");
            $close_paren=$open_paren+1;
            $opnum=1;
            $clnum=0;
            while ($opnum!=$clnum && $close_paren<130 && $close_paren<strlen($buffer)) {
               if ($buffer{$close_paren}=='(') $opnum++;
               elseif ($buffer{$close_paren}==')') $clnum++;
               $close_paren++;
            }
            $close_paren--;
            $number[$prompt_num]=trim(substr($buffer,7,$open_paren-7));
            $prompt_name[$prompt_num]=trim(substr($buffer,$open_paren+1,$close_paren-$open_paren-1));
//check whether the prompt name is a global prompt or an adhoc
            if (preg_match("/^\s*($nmptrn)#($nmptrn)\[\((.*)\),\((.*)\)\](\.$nmptrn)?/", $prompt_name[$prompt_num], $row)) {
               $prompt_name[$prompt_num]=$row[1].'#'.$row[2].'[('.$row[3].')]'.@$row[5];
// check for follows
               if (preg_match("/^\s*follows\s+($nmptrn)#($nmptrn)\[\((.*)\),\((.*)\)\](\.$nmptrn)?,/i", substr($buffer,$close_paren+1), $row)) {
// move the closing parent position after the follows
                  $close_paren+=strlen($row[0]);
                  $prompt_name[$prompt_num].=' follows '.$row[1].'#'.$row[2].'[('.$row[3].')]'.$row[5];
               }
            }
            $prompt_text[$prompt_num]=trim(substr($buffer,$close_paren+1));
            if ($tws_config['cpuinfo']['version'] >= '9.5002'){
                if (!empty($current_folder)){
                    $prompt_folder [$prompt_num] = $current_folder;
                } else {
                    $prompt_folder [$prompt_num] = '/';
                }
            }

         } elseif(!$removed) {
            $prompt_text[$prompt_num] .= ' '. trim(substr($buffer,8));
            $prompt_text[$prompt_num]=trim($prompt_text[$prompt_num]);
         }
         // xfilter
         if($extf == '@' || $extf == '*'|| $extf == '/@/@') $extf = '';
         if($prompt_num && $extf != '' && tws_prompt_match_xfilter ($prompt_name[$prompt_num], $number[$prompt_num], $extf) == false) {
            tws_log('-- tws_prompt_match_xfilter: '. $prompt_name[$prompt_num] .' don\'t match xfilter condition and removed.');
            $prompt_num--;
            $removed=true;
            continue;
         }
      }
   }

   $list = array(
      'prompt_num' => $prompt_num,
      'state' => $state,
      'number' => $number,
      'prompt_name' => $prompt_name,
      'prompt_text' => $prompt_text,
      'rc' => $ec
   );
   if ($tws_config['cpuinfo']['version'] >= '9.5002')
       $list['prompt_folder'] = $prompt_folder;

   tws_log('-- tws_get_plan_prompt_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
   return $list;
}

function tws_prompt_match_xfilter($pname, $pnum, $xfilter) {
   if ( !preg_match_all('/[+~][^+~]+/',$xfilter, $arr) ) {
      $arr[0][] = '+'.$xfilter;
   }
   $match=false;
   foreach ($arr[0] as $cond) {
      $op = substr($cond,0,1);
      $cond = substr($cond,1);
      $cond = strtr($cond, '|', ',');
      $cond_arr = explode(',', $cond);
      foreach($cond_arr as $mask) {
         if($op == '~' && ( tws_jokercmp($pname, $mask) || $pnum == $mask) )
            return false;
      }
      $match = false;
      foreach($cond_arr as $mask) {
         if ($op == '+' && ( tws_jokercmp($pname, $mask) || $pnum == $mask) )
            $match=true;
         elseif ($op == '~' )
            $match = true;
      }
      if ($match == false) return false;
   }
   return true;
}

/**
 * Gets the list of plan files (and their status attrs)
 *
 * @param string $arg File name or filter (see doc to ss)
 * @param int $symphony Sympony file number (0 for current plan - see doc for setsym, listsym)
 * @return array List of files or FALSE when fail
 */
function tws_get_plan_file_list($arg, $symphony=0, $page_size = 0, $page = 1) {
   global $tws_config;
   include 'colpos_sf.php';

   tws_log('-- tws_get_plan_file_list (start at '.basename(__FILE__).'['.__LINE__.'])');

   $extf = $arg;        // xfilters function
   $arg = '@#@';
   if ($tws_config['cpuinfo']['version'] >= '9.5002')
       $arg ='/@/@#@';
   $symtype = tws_profile('symtype');

   if ($symphony) {
      // Get actual symphony file number
      if (($symphony_lognum=tws_symphony_lognum($symtype, tws_profile('symphony_filename')))===FALSE){
         tws_log('Error: Unable to get symphony log number ('.__FILE__.'['.__LINE__.'])');
         $symphony_lognum = $symphony;
      }
      $st=(strtolower(trim($symtype)))=='archived' ? '' : $symtype;
      $command=new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/conman", $tws_config['conman_args'], "-gui", "setsym $st $symphony_lognum&sf $arg", hwi_cmd::operator('2>&1',FALSE));
   } else {
      $command=new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/conman", $tws_config['conman_args'], "-gui", "sf $arg", hwi_cmd::operator('2>&1',FALSE));
   }

   $stdout=array();
   if (tws_popen($command, $ec, $stdout, $stdout) === FALSE) {
      tws_error(array('command'=>$command->compile('log'), 'stdout'=>$stdout), 'Unable to open pipe');
      tws_log('Error: Unable to open pipe. ('.__FILE__.'['.__LINE__.'])');
      return FALSE;
   }

   $file_num = 0;
   $tl = tws_log();
   $page_down = ($page - 1) * $page_size + 1;
   $page_up = $page * $page_size;
   $current_folder =  '';

   foreach($stdout as $buffer){
      $tl && tws_log($buffer);

      // FIX for IWS 9.x - some data have no '^d' prefix (ticket 18515)
      $prefix = substr($buffer,0,2);
      if($prefix == '^h')
         $data_strings = true;  // data strings begin
      if(substr($buffer,2,2) == '>>'){  // IWS 9.5 // Prompt Folder begin
             $current_folder =  trim(substr($buffer, 4));
             tws_log("workstation folder = $current_folder");
             continue;
      }
      if(substr($buffer,0,3) == '%sf')
         $data_strings = false;  // end of data
      if($data_strings && $prefix != '^h' && $prefix != '^d')
         $buffer = "^d".$buffer;


      if (substr($buffer,0,2) === '^d' && substr($buffer,0,3) !== '^d/') {
         $file_num++;
         if ($page_size && (($page_down > $file_num) || ($page_up < $file_num))) {
            continue;
         }
         $exists[$file_num]=trim(substr($buffer,$col[1],$len[1]));
         $file[$file_num]=trim(substr($buffer,$col[2],$len[2]));
         list($cpu[$file_num],$filename[$file_num])=explode('#',$file[$file_num]);
         if ($tws_config['cpuinfo']['version'] >= '9.5002' ){
             if (!empty($current_folder))
                $cpu[$file_num] = $current_folder.$cpu[$file_num];
             else
                 $cpu[$file_num] = '/'.$cpu[$file_num];
         }
         // xfilter
         if($file_num && $extf != '' && tws_file_match_xfilter($cpu[$file_num], $filename[$file_num], $extf) == false) {
             tws_log('-- tws_file_match_xfilter: '. $cpu[$file_num] .'#'. $filename[$file_num] .' don\'t match xfilter condition '.$extf.' and removed.');
            $file_num--;
            continue;
         }
      }
   }

   $list = array(
      'file_num' => $file_num,
      'exists' => $exists,
      'cpu' => $cpu,
      'filename' => $filename,
      'rc' => $ec
   );

   tws_log('-- tws_get_plan_file_list (end up in '.basename(__FILE__).'['.__LINE__.'])');
   return $list;
}

function tws_file_match_xfilter($cpu, $file, $xfilter) {
   global $tws_config;
   if ( !preg_match_all('/[+~][^+~]+/',$xfilter, $arr) ) {
      $arr[0][] = '+'.$xfilter;
   }
   if(preg_match('/\(.*\)/', $file))  // Qualifier
      $file = preg_replace('/\(.*\)/', '', $file);
   $match = false;
   $havecond = false;
   foreach ($arr[0] as $cond) {
      $op = substr($cond,0,1);
      $cond = substr($cond,1);
      $cond = strtr($cond, '|', ',');
      $cond_arr = explode(',', $cond);
      foreach($cond_arr as $mask) {
         if (strpos($mask, '#')) {
            $ccpu = substr($mask,0,strpos($mask, '#'));
            $cfile = substr($mask,strpos($mask, '#')+1);

         }
         else return false;
         // if file path
         $xfile = $file;
         //if(!strpos($xfilter, '\\') && !strpos($xfilter, '/') )
         //   $xfile = basename($xfile);
        // conditions
         if($op == '~' && tws_jokercmp($cpu, $ccpu) && tws_jokercmp($xfile, $cfile) )
            return false;
      }
      $match = false;
      foreach($cond_arr as $mask) {
         $ccpu = substr($mask,0,strpos($mask, '#'));
         $cfile = substr($mask,strpos($mask, '#')+1);
         $xfile = $file;
         $shortcpu = '';
         if ($tws_config['cpuinfo']['version'] >= '9.5002' && substr($ccpu,0,3)=== '/@/' ){
             $shortcpu = substr($ccpu,2);
         }
         tws_log(' ccpu '.$ccpu.' cfile '.$cfile.' op '.$op.' shortcpu '.$shortcpu);
         //if(!strpos($xfilter, '\\') && !strpos($xfilter, '/') )
         //   $xfile = basename($xfile);
        // conditions
         if ($op == '+') {
             if (tws_jokercmp($cpu, $ccpu)  && tws_jokercmp($xfile, $cfile) )
                 $match = true;
             elseif (!empty($shortcpu) && tws_jokercmp($cpu, $shortcpu)  && tws_jokercmp($xfile, $cfile))
                $match = true;
         }

         elseif ($op == '~' )
            $match = true;

      }
      if($match==false) return false;
   }
   return true;
}

/**
 * Gets the list of symphonies (and their status attrs)
 * @param string $symtype Symphony type: string mask containing semicolon separated list of
 *                        'archived','trial' or 'forecast' key words
 * @return array List of symphony or FALSE when fail
 */
function tws_get_symphony_list($symtypes = 'Archived;Trial;Forecast', $page_size = 0, $page = 1) {
   global $tws_config;

   tws_log('-- tws_get_symphony_list (start at '.basename(__FILE__).'['.__LINE__.'])');
   // Date Filter
   $listsym_filter = tws_profile('listsymfilter');
   if(!empty($listsym_filter)) {
      $tmp = strtok($listsym_filter, '+');
      $xfilter = strtok( "\n");
      if (!empty($xfilter)){
         $xfilter = '+'.$xfilter;
         $tmp='';
         $extf=tws_ext_plan_filters($xfilter, $tmp);
         if (isset($extf['xschedtime'])){
            list($schedlow,$schedhigh)=explode(',',$extf['xschedtime']);
            $schedlow = tws_userdate_to_iso($schedlow);
            $schedhigh = tws_userdate_to_iso($schedhigh);
         }
      }
   }

   $sym_num = 0;
   $tl = tws_log();
   $page_down = ($page - 1) * $page_size + 1;
   $page_up = $page * $page_size;

   foreach (explode(';',$symtypes) as $symtype){
      $st=(strtolower(trim($symtype)))=='archived' ? '' : $symtype;
      $command=new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/conman", $tws_config['conman_args'], "-gui", "listsym $st", hwi_cmd::operator('2>&1',FALSE));
      $stdout=array();
      if (tws_popen($command, $ec, $stdout, $stdout, '', array('LANG'=>'C')) === FALSE) {
         tws_error(array('command'=>$command->compile('log'), 'stdout'=>$stdout), 'Unable to open pipe');
         tws_log('Error: Unable to open pipe. ('.__FILE__.'['.__LINE__.'])');
         return FALSE;
      }
      $data_strings = false;  // FIX for IWS 9.x : they have now '^d/' before hedaer
      foreach ($stdout as $buffer){
         $tl && tws_log($buffer);
         $prefix = substr($buffer,0,2);
         if($prefix == '^h')
            $data_strings = true;  // data strings begin

         switch (strtolower(substr($buffer,0,2))){
            case "^h" :
               $data_strings = true;
               break;
            case "^d" :
               if(!$data_strings)
                  break;
               $sym_num++;
               /*
               if ($page_size && (($page_down > $sym_num) || ($page_up < $sym_num)))
                  continue;
               */
               $plan_type[$sym_num]=$symtype;
               $sched_date[$sym_num]=trim(substr($buffer,2,8));
               $actual_date[$sym_num]=trim(substr($buffer,13,8));
               $start_time[$sym_num]=trim(substr($buffer,22,5));
               $log_date[$sym_num]=trim(substr($buffer,30,8));
               $run_num[$sym_num]=trim(substr($buffer,39,6));
               $size[$sym_num]=trim(substr($buffer,47,5));
               $log_num[$sym_num]=trim(substr($buffer,54,4));
               //$filename[$sym_num]=trim(substr($buffer,60,17));
               $filename[$sym_num]=trim(substr($buffer,60));
               preg_match('/^\S+/', $filename[$sym_num], $matches);
               $filename[$sym_num] = $matches[0];

               if (isset($extf['xschedtime'])){
                  $curdate = strtotime(tws_conman_to_iso('0000 '.$sched_date[$sym_num]));
                  if (!empty($schedlow) && ($curdate < strtotime($schedlow))) {
                     $sym_num--;
                     break;
                  }
                  if (!empty($schedhigh) && ($curdate > strtotime($schedhigh))){
                     $sym_num--;
                     break;
                  }
               }
               break;
            case "^e" : case "^f" :
               if (!preg_match("/there are no objects that match the selection you have entered/i", $buffer)){
                  tws_error(array('stdout'=>$stdout), substr(preg_replace("/^(\^[a-z])?AWS[A-Z0-9]+([EF]) /", '^${2}', $buffer),2));
                  return FALSE;
               }
               break;
         }
      }
   }

   $list = array (
      'sym_num' => $sym_num,
      'plan_type' => $plan_type,
      'sched_date' => $sched_date,
      'actual_date' => $actual_date,
      'start_time' => $start_time,
      'log_date' => $log_date,
      'run_num' => $run_num,
      'size' => $size,
      'log_num' => $log_num,
      'filename' => $filename,
   );

   tws_log("-- tws_get_symphony_list (end up in ".basename(__FILE__)."[".__LINE__."])");
   return $list;
}

/**
 * Return current symphony log number of given symphony file name (and type)
 *
 * @param symtype $symptype Symphony type ('Archived', 'Trial' or 'Forecast')
 * @param symphony_filename $symphony_filename Symphony file name
 * @return log number or FALSE in case of error
 */
function tws_symphony_lognum($symtype,$symphony_filename) {
   tws_log("-- tws_symphony_lognum: symtype:'$symtype', symphony file name: '$symphony_filename'");
   if (($listsym=tws_get_symphony_list($symtype))!==FALSE &&
       ($pos=array_search($symphony_filename,$listsym['filename']))!==FALSE) {
      tws_log('-- tws_symphony_lognum: Symphony file name '.$symphony_filename.' is log num '.$listsym['log_num'][$pos].' in the symlist');
      return ($listsym['log_num'][$pos]);
   }
   tws_log('-- tws_symphony_lognum: Unable to locate symphony file name in the symphony list');
   return FALSE;
}

/**
 * returns symphony creation date in ISO format
 * $symphony : symphony log num
 */
function tws_get_symdate($symphony=0) {
   global $tws_config;
   $date=FALSE;
   $stdout=$stderr=array();
   $command=new hwi_cmd(tws_sudo('',$tws_config['maestro_user']), $tws_config['maestro_dir']."/bin/conman", "-gui", "setsym $symphony", hwi_cmd::operator('2>&1',FALSE));
   tws_log("-- tws_get_symdate: executing ". $command->compile('log'));
   if (tws_popen($command, $ec, $stdout, $stderr,'',array('LANG'=>'C'))!==FALSE) {
      foreach ($stdout as $buff) {
         tws_log($buff);
         if (preg_match('!(\d{2,}/\d{2,}/\d{2,})!', $buff, $r)) {
            $date=tws_userdate_to_iso($r[1],'localopts',TRUE);
            tws_log("-- tws_get_symdate: Detected current symphony creation date: $r[1] ($date)");
            break;
         }
      }
   } else tws_error(array('command'=>$command->compile('log'), 'stdout'=>$stdout), 'Unable to open pipe');
   if ($date===FALSE) {
      tws_log("-- tws_get_symdate: Unable to get current symphony creation date");
      tws_error($stdout, 'Unable to get current symphony creation date');
   }
   return $date;
}



//
// Generate forecast function
//
// @param sym_type (in!) - possible values: 'forecast' or 'trial'
// @param from (in!) - start time in format YYYYMMDDHHMM - only used if sym_type=='forecast'
// @param for (in!) - duration time in format [H]HHMM
// @param sym_lognum (out) - generated symphony file id number
// @param sym_filename (out) - generated symphony filename
// @return TRUE on success, FALSE on error
function tws_generate_forecast($sym_type, $from, $for, &$sym_lognum, &$sym_filename) {
   global $tws_config;

   $unique=tws_rndstr('FILENAME_SHORT');

   // analyzing 'for' parameter (common for trial & foreacast)
   if (preg_match('/(\d+)(\d{2})$/', $for, $for_regs)) {
      list($null, $for_hours, $for_mins)=$for_regs;
   } else {
      tws_error("Wrong format of parameter \$for='$for'", "Input parameters error. Unable to generate $sym_type.");
      return FALSE;
   }

   switch (strtolower($sym_type)) {
      case 'trial' :
         $command=new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/planman", $tws_config['planman_args'], "showinfo");
         $stdout=array();
         if (tws_popen($command, $ec, $stdout, $stdout, '', array('LANG'=>'C'))===FALSE) {
            tws_error(array('command'=>$command->compile('log'), 'stdout'=>$stdout), "Unable to get current plan information");
            return FALSE;
         }
         $output=implode(' ', $stdout);
         if (preg_match("/Production plan end time: (\d+)\/(\d+)\/(\d+) (\d+):(\d+)/", $output, $x)
               ||
             (preg_match("/Production plan end time: \(same as start time/", $output) &&
              preg_match("/Plan creation start time: (\d+)\/(\d+)\/(\d+) (\d+):(\d+)/", $output, $x))
            ){
            $prod_plan_end_iso=tws_date_to_iso($x[1].'/'.$x[2].'/'.$x[3])." $x[4]:$x[5]:00";
            $prod_plan_end_ts=strtotime($prod_plan_end_iso);
            $prod_plan_end_minsepoch=$prod_plan_end_ts/60;
            $trial_plan_duration_mins=$for_hours*60 + $for_mins;
         } else {
            tws_error(array('stdout'=>$output), "Unable to get the end time of the current plan");
            return FALSE;
         }

         $fpref='T';
         $filename=$prod_plan_end_minsepoch.'WA'.$trial_plan_duration_mins;
         $command=new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/planman", $tws_config['planman_args'], 'exttrial', $filename, '-for',  $for_hours.$for_mins, hwi_cmd::operator('2>&1',FALSE));

        // generate trial plan requires read access to the Symphony file
        if ($tws_config['cpuinfo']['version'] >= '9.5')
            $symdir = $tws_config["twsenv"]["UNISONWORK"];
        else
            $symdir = $tws_config['maestro_dir'];
        tws_chmod($symdir . '/Symphony', 0644);

         break;
      case 'forecast' :
         // analyzing 'from' parameter
         if (preg_match('/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(.+)?$/', $from, $from_regs)) {
            list($null, $from_year, $from_month, $from_day, $from_hour, $from_min,$time_zone)=$from_regs;
         } else {
            tws_error("Wrong format of parameter \$from='$from'", "Input parameters error. Unable to generate $sym_type");
            return FALSE;
         }
         $forecast_start_time_ts=strtotime("$from_year-$from_month-$from_day $from_hour:$from_min:00");
         $forecast_start_time_minsepoch=$forecast_start_time_ts/60;
         $forecast_duration_mins=$for_hours*60 + $for_mins;

         $fpref='F';
         $filename=$forecast_start_time_minsepoch.'WA'.$forecast_duration_mins;
         $to_utimestamp=$forecast_start_time_ts + $for_hours*60*60 + $for_mins*60;

         $tz=($time_zone!='' && $time_zone!='NULL') ? 'tz' : '';
         $tzname = ($time_zone!='' && $time_zone!='NULL') ? $time_zone : '';

         $command=new hwi_cmd(tws_sudo(''), "$tws_config[maestro_dir]/bin/planman", $tws_config['planman_args'], 'crtfc', $filename, "-from", tws_iso_to_userdate("$from_year-$from_month-$from_day",'LOCALOPTS',TRUE), $from_hour.$from_min, $tz,$tzname, "-to", tws_iso_to_userdate(date('Y-m-d',$to_utimestamp),'LOCALOPTS',TRUE), date('Hi',$to_utimestamp), $tz,$tzname, hwi_cmd::operator('2>&1',FALSE));
         break;
      default:
         tws_error("Unknown value of parameter \$sym_type='$sym_type'", "Input parameters error. Unable to generate forecast/trial");
         return FALSE;
   }

   set_time_limit(10*$tws_config['excmd_limit']);

   // The write permissions to the maestro_dir/schedTrial, maestro_dir/schedForecast, maestro_dir/schedlog
   // are not given to everyone. Therefore it can happen that
   $stdout=array();
   if (tws_popen($command, $ec, $stdout, $stdout, "N")===FALSE || ($rc=tws_process_conman_gui($stdout))!=0) {
      tws_error(array('command'=>$command->compile('log'),'ec'=>$ec,'stdout'=>$stdout), "Problems while generating $sym_type plan:");
      if ($rc==1) return FALSE;
   }

   // output parameters
   $sym_filename=$fpref.$filename;
   $sym_lognum=tws_symphony_lognum($sym_type, $sym_filename);

   return TRUE;
}
?>
