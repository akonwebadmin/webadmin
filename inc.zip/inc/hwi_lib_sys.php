<?php
//   HORIZONT Software GmbH, Munich
//

require_once 'System/Command.php';
define('SYSTEM_COMMAND_COMMAND_ENV_PLACEMENT', -101);
define('SYSTEM_COMMAND_INVALID_COMMAND_ENV',   -102);

//Examples of usage:
//
// $cmd=new hwi_cmd($hwi_config['maestro_dir'].'/bin/conman', 'status',  hwi_cmd::operator('2>&1',FALSE));
//
// $cmd=new hwi_cmd(tws_sudo(''), $tws_config['maestro_dir'].'/bin/conman', 'status',  hwi_cmd::operator('2>&1',FALSE), hwi_cmd::operator('1>','/tmp/result.txt'), hwi_cmd::operator('|'), 'tee', '-a', '/tmp/test_result.txt');
//

class hwi_cmd extends System_Command {
   //parameters: $command, $arguments
   public function __construct() {
      parent::__construct(); //calling the parent constructor
      $this->logSystemCommand='';
      $this->options['SYSTEM_DEFAULT_SHELL']=TRUE;

      $this->controlOperators['2>&1']='2>&1';
      $this->controlOperators['1>&2']='1>&2';
      $this->controlOperators['2>/dev/null']=OS_WINDOWS ? '2>nul' : '2>/dev/null';
      $this->controlOperators['1>/dev/null']=OS_WINDOWS ? '1>nul' : '1>/dev/null';
      $this->controlOperators['2>nul']=OS_WINDOWS ? '2>nul' : '2>/dev/null';
      $this->controlOperators['1>nul']=OS_WINDOWS ? '1>nul' : '1>/dev/null';

      $argv = func_get_args();
      if (func_num_args()>=1) {
         $rc=call_user_func_array(array($this,'pushCommand'), $argv);
      }
      return $rc;
   }

   function pushCommandEnv($name,$value) {
      if ($this->_initError) return $this->_initError;

      if (!is_null($this->previousElement) && !in_array($this->previousElement, $this->controlOperators)) {
         $this->commandStatus = -1;
         $error = PEAR::raiseError(null, SYSTEM_COMMAND_COMMAND_ENV_PLACEMENT, null, E_USER_WARNING, null, 'System_Command_Error', true);
      }

      if (!preg_match('/[a-z_]\w*/i', $name)) {
         $error = PEAR::raiseError(null, SYSTEM_COMMAND_INVALID_COMMAND_ENV, null, E_USER_WARNING, null, 'System_Command_Error', true);
      }

      $hidden=FALSE;
      if (is_array($value)) {
         if (isset($value['type']) && $value['type']=='hidden') {
            $value=$value['value'];
            $hidden=TRUE;
         } else {
            $value=implode(' ',$value); //TODO?
         }
      }

      // check for error here
      $x=' '.$name.'='.escapeshellarg($value).' ';
      $lx= $hidden ? ' '.$name.'='.escapeshellarg('*****') : $x;
      $this->systemCommand .= $x;
      $this->logSystemCommand .= $lx;
      return isset($error) ? $error : true;
   }

   function pushCommand($in_command) {
      $argv=func_get_args();
      if (is_array($in_command) && (isset($in_command['exec']))) {
         //such type of arguments structure desgined for sudo
         if (isset($in_command['args'])) {
            if (is_array($in_command['args'])) $argvexp=$in_command['args'];
            else $argvexp=array($in_command['args']);
         } else $argvexp=array();
         //additional argumets
         for ($i=1; $i<func_num_args(); $i++) $argvexp[]=$argv[$i];
         array_unshift($argvexp, $in_command['exec']);
         return call_user_func_array(array($this, 'pushCommand'), $argvexp);
      }

      $cmdline=array();$n=0;
      foreach($argv as $key=>$arg) {
         if (is_array($arg)) {
            if (isset($arg['type'])) {
               switch ($arg['type']) {
                  case 'hidden' : case 'password' :
                     $cmdline[$n]['argv'][]=$arg['value'];
                     $cmdline[$n]['argv_hidden'][]='*****';
                     break;
                  case 'operator':
                     if (!isset($this->controlOperators[$arg['value']])) $this->controlOperators[$arg['value']]=$arg['value'];
                     $cmdline[$n]['operators'][]=$arg;
                     if ($arg['rvalue']==='') $n++;
                     break;
               }
            } else {
               foreach ($arg as $val) {
                  if (trim($val)=='') continue;
                  $cmdline[$n]['argv'][]=$val;
                  $cmdline[$n]['argv_hidden'][]=($val);
               }
            }
         } elseif (trim($arg)!='') {
           $cmdline[$n]['argv'][]=$arg;
           $cmdline[$n]['argv_hidden'][]=$arg;
         }
      }

      for ($i=0; $i<=$n; $i++) {
         if (!isset($cmdline[$i]['argv']) || count($cmdline[$i]['argv'])==0) break;

         $bak_sys_cmd=$this->systemCommand;
         $bak_prev_elem=$this->previousElement;

         $this->systemCommand=$this->logSystemCommand;

         //version for log
         call_user_func_array((OS_WINDOWS ? array($this,'pushCommand_windows') : array('parent','pushCommand')), $cmdline[$i]['argv_hidden']);

         $this->logSystemCommand=$this->systemCommand;
         $this->systemCommand=$bak_sys_cmd;
         $this->previousElement=$bak_prev_elem;
         if (($rc=call_user_func_array((OS_WINDOWS ? array($this,'pushCommand_windows') : array('parent','pushCommand')), $cmdline[$i]['argv']))===TRUE) {
            $this->lastExec=$this->which($cmdline[$i]['argv'][0]); //
         } else {
            //ERROR
            return $rc;
         }

         //apply operators - if any
         if (isset($cmdline[$i]['operators'])) {
            foreach ($cmdline[$i]['operators'] as $oper) {
               if (($rc=$this->pushOperator($oper['value']))!==TRUE) {
                  //ERROR
                  return $rc;
               }
               $this->logSystemCommand.=' '.$this->controlOperators[$oper['value']].' ';
               if ($oper['rvalue']===FALSE || $oper['rvalue']!=='') {
                  //binary operator with given operand
                  if ($oper['rvalue']!==FALSE) {
                     $this->systemCommand=rtrim($this->systemCommand).$this->escapeshellarg($oper['rvalue']);
                     $this->logSystemCommand=rtrim($this->logSystemCommand).$this->escapeshellarg($oper['rvalue']);
                  }

                  $this->previousElement=$this->systemCommand;
               }
            }
         }
      }

      return $rc;
   }

   //rvalue===FALSE => unary operator, e.g. 2>&1
   //rvalue!='' => binary operator with given operand => unary operator
   //otherwise regular binary operator, it means that the next command will follow!!!
   static public function operator($operator, $rvalue='') {
      if ($rvalue!==FALSE && is_string($rvalue)) $rvalue=trim($rvalue);
      return array('type'=>'operator', 'value'=>$operator, 'rvalue'=>$rvalue);
   }

   static public function hidden($value) {
      return array('type'=>'hidden', 'value'=>$value);
   }

   function reset() {
      $this->lastExec=null;
      parent::reset();
   }

   function getLastExec() {
      if ($this->_initError) {
         return $this->_initError;
      }

      // if the command is empty or if the last element was a control operator, we can't continue
      if (is_null($this->previousElement) || $this->commandStatus == -1 || in_array($this->previousElement, $this->controlOperators)) {
         return PEAR::raiseError(null, SYSTEM_COMMAND_INVALID_COMMAND, null, E_USER_WARNING, $this->systemCommand, 'System_Command_Error', true);
      }

      if (is_array($this->lastExec)) $this->lastExec=$this->lastExec[0];

      return $this->lastExec;
   }

   function pushCommand_windows($in_command) {
      global $hwi_config;

      if ($this->_initError) {
         return $this->_initError;
      }

      if (!is_null($this->previousElement) && !in_array($this->previousElement, $this->controlOperators)) {
         $this->commandStatus = -1;
         $error = PEAR::raiseError(null, SYSTEM_COMMAND_COMMAND_PLACEMENT, null, E_USER_WARNING, null, 'System_Command_Error', true);
      }

      // check for error here
      if (($command=$this->which($in_command))===FALSE) {
         $error = PEAR::raiseError(null, SYSTEM_COMMAND_INVALID_COMMAND, null, E_USER_WARNING, "No such executable found: $in_command", 'System_Command_Error', true);
         $this->commandStatus = -1;
         $command=$in_command; //just to get the wrong command line into the error log
      }

      //split cmd.exe and its built-in command
      if(strpos($command, '::')!==FALSE)
         list($command,$subroutine)=explode('::', $command);
      else $subroutine = '';

      if (isset($hwi_config['cmdexe-compat']) && !hwi_yesno($hwi_config['cmdexe-compat'])) {
         $command=hwi_cmd::escapeshellcmd($command);
         if (strpos($command,' ')!==FALSE) {
              $command='^"'.str_replace(' ','^ ',$command).'^"';
         }
         $command.=$subroutine;
      } else {
         //More secure way, also avoids issue with blanks in the paths to the executable
         //on some systems this doesn't work though, $hwi_config['cmdexe-compat'] must be set to FALSE to overcome
         $this->__HWI_EXE=hwi_cmd::escapeshellcmd($command);
         $command='SET __HWI_EXE="'.(hwi_cmd::escapeshellcmd($command)).'"';
         $command.=' && call %__HWI_EXE%'.$subroutine;
      }

      $argv = func_get_args();
      array_shift($argv);
      foreach($argv as $arg) {
         if (($arg{0}=='-' || $arg{0}=='/') && preg_match(';^[a-z0-9_/\-]+$;i', $arg)) {
            $command .= ' ' . $arg;
         } elseif ($arg != '') {
            $command .= ' ' . hwi_cmd::escapeshellarg($arg);
         } else { //blank argument is also blank argument (see e.g. the blank password ticket ERR13416)
            $command .= ' ""';
         }
      }

      $this->previousElement = $command;
      $this->systemCommand .= $command;

      return isset($error) ? $error : true;
   }

   function which($program, $fallback=FALSE) {
      if ($program===NULL) return $fallback;

      //special hack to achieve the required initialization of the class
      if ($program=='sh' && (!isset($this->options['SYSTEM_DEFAULT_SHELL']) || $this->options['SYSTEM_DEFAULT_SHELL']))
            return 'SYSTEM_DEFAULT_SHELL';

      static $cache_last=array();
      if (count($cache_last)>0 && $program==$cache_last['program'] && $fallback==$cache_last['fallback'] && $cache_last['result']!==NULL)
         return $cache_last['result'];
      $cache_last=array('program'=>$program,'fallback'=>$fallback,'result'=>NULL);

      if (OS_WINDOWS) {

        //the PEAR::System::which() uses is_executable which doesn't work correctly with *cmd, *bat windows scripts
        //enforce API
        if (!is_string($program) || '' == $program) {
            $cache_last['result']=$fallback;
            return $fallback;
        }

        $cmdexe_subs=array('CALL', 'CD', 'CHCP', 'CHDIR', 'CHKDSK', 'CHKNTFS', 'COPY', 'DATE', 'DEL', 'DIR', 'DISKCOMP', 'DISKCOPY', 'ECHO', 'ERASE', 'FIND', 'FINDSTR', 'MKDIR', 'MD', 'MORE', 'MOVE', 'PATH', 'PRINT', 'PROMPT', 'RECOVER', 'REN', 'RENAME', 'REPLACE', 'RMDIR', 'SET', 'SORT', 'START', 'TIME', 'TREE', 'TYPE', 'VER', 'VERIFY', 'VOL', 'XCOPY');
        if (in_array(strtoupper(trim($program)), $cmdexe_subs)) {
           $subroutine=':: /C '.$program;
           $program='cmd.exe';
        } else $subroutine='';

        // full path given
        if (basename($program) != $program) {
            $path_elements[] = dirname($program);
            $program = basename($program);
        } else {
            // Honor safe mode
            if (!ini_get('safe_mode') || !$path = ini_get('safe_mode_exec_dir')) {
                $path = getenv('PATH');
                if (!$path) {
                    $path = getenv('Path'); // some OSes are just stupid enough to do this
                }
            }
            $path_elements = explode(PATH_SEPARATOR, $path);
        }

        $exe_suffixes = getenv('PATHEXT')
                             ? explode(PATH_SEPARATOR, getenv('PATHEXT'))
                             : array('.exe','.bat','.cmd','.com');
        // allow passing a command.exe param
        if (strpos($program, '.') !== false) {
            array_unshift($exe_suffixes, '');
        }
        // is_executable() is not available on windows for PHP4 is_executable doesn't work correctly on Windows
        $pear_is_executable = (FALSE && function_exists('is_executable')) ? 'is_executable' : 'is_file';

        foreach ($exe_suffixes as $suff) {
           foreach ($path_elements as $dir) {
              $file = $dir . DIRECTORY_SEPARATOR . $program . $suff;
              if (@$pear_is_executable($file)) {
                 $cache_last['result']=$file.$subroutine;
                 return $file.$subroutine;
              }
           }
        }
        //let's give a chance to PEAR::System::which() ...
        hwi_error("No such executable file", "Unknown executable '$program' (W)", __FILE__, __LINE__);
        $cache_last['result']=$fallback;
        return $fallback;
      }

      if (($rc=parent::which($program, $fallback))===$fallback) {
         hwi_error("No such executable file", "Unknown executable '$program' (U)", __FILE__, __LINE__);
      }
      $cache_last['result']=$rc;
      return $rc;
   }

   static function escapeshellcmd($cmd) {
      if (OS_WINDOWS) {
         $cmd=preg_replace(';[%"&|()];','^$0',$cmd);
         return $cmd;
      }
      return escapeshellcmd($cmd);
   }

   static function escapeshellarg($arg) {
      if (OS_WINDOWS) {
         //$arg=preg_replace(';[%&|()];','^$0',$arg);
         $arg=preg_replace(';["];','""',$arg);
         $arg= '"'.$arg.'"';
         return $arg;
      }
      return escapeshellarg($arg);
   }

   static private function start_command_windows($matches) {
      $path=pathinfo(trim($matches[0],'"'));
      return '/D "'.($path['dirname']=='' ? '.' : $path['dirname']).'" "'.$path['basename'].'"';
   }

   function compile($target='exec') {
      global $hwi_config;

      if (!isset($this->compiled) || $this->compiled==FALSE) {
         if ($this->_initError) return $this->_initError;

         // if the command is empty or if the last element was a control operator, we can't continue
         if (is_null($this->previousElement) || $this->commandStatus == -1 || in_array($this->previousElement, $this->controlOperators)) {
            return PEAR::raiseError(null, SYSTEM_COMMAND_INVALID_COMMAND, null, E_USER_WARNING, $this->logSystemCommand, 'System_Command_Error', true);
         }
   
         // Warning about impossible mix of options
         if (!empty($this->options['OUTPUT'])) {
            if (!empty($this->options['SHUTDOWN']) || !empty($this->options['NOHUP'])) {
               return PEAR::raiseError(null, SYSTEM_COMMAND_NO_OUTPUT, null, E_USER_WARNING, null, 'System_Command_Error', true);
            }
         }
                
         // if this is not going to stdout, then redirect to /dev/null
         if (empty($this->options['OUTPUT'])) {
            $this->systemCommand .= ' >/dev/null';
            $this->logSystemCommand .= ' >/dev/null';
         }
                   
         if (!OS_WINDOWS) {
            $suffix = '';
            // run a command immune to hangups, with output to a non-tty
            if (!empty($this->options['NOHUP'])) {
               $this->systemCommand = $this->options['NOHUP'] . $this->systemCommand;
               $this->logSystemCommand = $this->options['NOHUP'] . $this->systemCommand;
            } elseif (!empty($this->options['BACKGROUND'])) { // run a background process (only if not nohup)
               $suffix = ' &';
            }
                         
            $this->systemCommand.=$suffix;
            $this->logSystemCommand.=$suffix;
         } else {
            if (!empty($this->options['BACKGROUND'])) { // run a background process (only if not nohup)
               if (isset($hwi_config['cmdexe-compat']) && hwi_yesno($hwi_config['cmdexe-compat'])) {
                  //the compat mode doesn't work with BACKROUND option, stripping out the set __HWI_EXE and call %__HWI_EXE%...
                  $this->systemCommand=preg_replace('/SET __HWI_EXE=/', '', $this->systemCommand);
                  $this->systemCommand=preg_replace('/ && call %__HWI_EXE%/', '', $this->systemCommand);
                  $this->logSystemCommand=preg_replace('/SET __HWI_EXE=/', '', $this->logSystemCommand);
                  $this->logSystemCommand=preg_replace('/ && call %__HWI_EXE%/', '', $this->logSystemCommand);
               }
               //the cmd.exe interpretter on Windows does not correctly support quoted parameters of BAT, CMD, VBS scripts,
               //so it is needed to specify the "working directory" as parameter "/D" explictly:
               //NOT: START "ABC" /B "D:\somepath\abc.bat" "parameter"
               //BUT: START "ABC" /B /D "D:\somepath" "abc.bat" "parameter"
               $this->systemCommand=preg_replace_callback('/^"[^"]*"/', array('hwi_cmd', 'start_command_windows'), ltrim($this->systemCommand)); 
               $this->logSystemCommand=preg_replace_callback('/^"[^"]*"/', array('hwi_cmd', 'start_command_windows'), ltrim($this->logSystemCommand)); 
               //adding the START command to run at background
               $this->systemCommand='START "HWFEXT" /B '.$this->systemCommand;
               $this->logSystemCommand='START "HWFEXT" /B '.$this->logSystemCommand;
            }
         }
     
         if (!$this->options['SYSTEM_DEFAULT_SHELL'] || !$this->options['SHELL']=='SYSTEM_DEFAULT_SHELL') {
            $this->systemCommand = $this->which('echo') . ' ' . escapeshellarg($this->logSystemCommand) . ' | ' . $this->options['SHELL'];
            $this->logSystemCommand = $this->which('echo') . ' ' . escapeshellarg($this->systemCommand) . ' | ' . $this->options['SHELL'];
         }

         $this->compiled=TRUE;
      }
      return ($target=='exec' ? $this->systemCommand : $this->logSystemCommand);
   }
}


///
function hwi_sudo($user=null, $pw=null, $cmd=null) {
   global $hwi_config;

   $sudo_exec=$hwi_config['sudo'];
   $sudo=$sudo_exec.' '.$hwi_config['sudo_args'];
   $sudo_hidden_pw='';
 
   if ($user===NULL && $pw===NULL && $hwi_config['host_os']!='win32') {
      $user=wai_get_user();
   }

   if ($user!='') {
      if ($hwi_config['host_os']=='win32') {
//Important note !!! : Since 3.0.5 on win32 the force mapped auth is considered as set to 1 if it's not defined
         if ($pw===null) {
            hwi_error("Missing user's password to complete sudo command.", "hwi_sudo('$cmd','$user',null);", __FILE__, __LINE__, 4);
            return FALSE;
         } else {
            $sudo_hidden_pw="$sudo $user *****";
            $sudo.=" $user \"$pw\"";
            $sudo_args=array($hwi_config['sudo_args'], $user, array('value'=>$pw, 'type'=>'hidden'));
         }
      } else {
         $sudo.=" -u $user";
         $sudo_args=array($hwi_config['sudo_args'], '-u', $user);
      }
   } else {
      //TODO
      //continue without sudo, use a pedefined technical user account or abend
      $sudo='';
   }

   if ($sudo!='') {
      if (is_array($cmd)) {
         foreach ($cmd as $c) $sudo_args[]=$c;
         $safe_args=TRUE;
      } elseif ($cmd=='') {
         $safe_args=TRUE;
      } else {
         $sudo_args[]=$cmd;
         $safe_args=FALSE;
      }
      $cmdstruct=array(
         'exec'=>$sudo_exec,
         'args'=>$sudo_args, /*sudo parameters formatted for the hwi_cmd class !!!*/
         'safe_args'=>$safe_args,
         'cmd'=>ltrim($sudo.' '.$cmd),
         'log'=>($sudo_hidden_pw!='' ? $sudo_hidden_pw : $sudo).' '.$cmd
      );
   } else {
      //warning - deprecated executions, possible security hole
      $cmdstruct=array(
         'cmd'=>$cmd,
         'log'=>$cmd,
         'safe'=>FALSE
      );
   }

   hwi_log('-- hwi_sudo : '.$cmdstruct['log']);
   return $cmdstruct;
}


function hwi_popen($cmdstruct, &$exitcode, &$stdout, &$stderr, $stdin='', $env='') {
   global $hwi_config, $__hwi_popen_process_res;

// process the cmdstruct command structure
   $cmdlog='';
   if (is_object($cmdstruct)) {
      if (!is_string($cmd=$cmdstruct->compile('exec')) || strlen(trim($cmd))==0) {
         if (PEAR::isError($cmd)) {
            wai_error($cmd->toString(), $cmd->getMessage());
         } else {
            wai_error('command log:'.(is_string($cmdlog=$cmdstruct->compile('log')) ? $cmdlog : '---'), 'Invalid System Command');
         }
         return FALSE;
      } else $cmdlog=$cmdstruct->compile('log');
      //this is just a duplicate definiton of the __HWI_EXE environment variable (WINDOWS only) as sometimes
      //the SET __HWI_EXE=command && call %__HWI_EXE% crashes in "call" on unknown or empty __HWI_EXE variable
      //March 2014: commenting out due to issues with blanks in the executables path name
      //if (isset($cmdstruct->__HWI_EXE)) putenv("__HWI_EXE=".$cmdstruct->__HWI_EXE);
   } elseif (is_array($cmdstruct) && isset($cmdstruct['exec'])) {
      //this type only reserved for command structure returned by hwi_sudo (or tws_sudo)
      if (isset($cmdstruct['safe_args']) && !hwi_yesno($cmdstruct['safe_args'],TRUE,FALSE)) {
         //WARNING: deprecated, usafe argument, possible security hole
         wai_error('hwi_popen: Passing unsafe argument', "cmdstruct log: ".print_r($cmdstruct['log'],1), __FILE__, __LINE__, 3);
         $unsafe_arg=$unsafe_arg_log=array_pop($cmdstruct['args']);
         if (is_array($unsafe_arg)) {
            if (isset($unsafe_arg['type'])) {
               $unsafe_arg=$unsafe_arg['value'];
               if ($unsafe_arg['type']=='hidden') $unsafe_arg_log='*****';
               else $unsafe_arg_log=$unsafe_arg;
            } else {
               $unsafe_arg=$unsafe_arg_log=implode(' ',$unsafe_arg);
            }
         }
      }
      $cmd_obj=new hwi_cmd($cmdstruct);
      $cmd=trim($cmd_obj->compile('exec').' '.$unsafe_arg);
      $cmdlog=trim($cmd_obj->compile('log').' '.$unsafe_arg_log);
   } elseif (is_array($cmdstruct) && isset($cmdstruct['cmd'])) {
      if (isset($cmdstruct['safe_args']) && !hwi_yesno($cmdstruct['safe_args'],TRUE,FALSE)) {
         //WARNING: deprecated, usafe command line, possible security hole
         wai_error('hwi_popen : Deprecated calling type, unsafe command line', "cmdstruct log: ".print_r($cmdstruct['log'],1), __FILE__, __LINE__, 3);
      }
      $cmd=$cmdstruct['cmd'];
      if (isset($cmdstruct['log'])) $cmdlog=$cmdstruct['log'];

   } elseif (is_string($cmdstruct)) {
      //WARNING: deprecated, usafe command line, possible security hole
      wai_error('hwi_popen : Deprecated calling type, unsafe command line, missing audit log message', "cmdstruct: ".print_r($cmdstruct,1), __FILE__, __LINE__, 3);
      $cmd=$cmdlog=$cmdstruct;
   } else {
      wai_error('hwi_popen : Unknown command structure', "cmdstruct: ".print_r($cmdstruct,1), __FILE__, __LINE__, 4);
      return FALSE;
   }

// old and active environment variables
   $o_env=array();
   $a_env=array (
      'LANG'=>'C',
      'LINES'=>'0',
   );
   if ($hwi_config['host_os']=='win32') {
      $a_env['COLUMNS']='500';
   }

// default (common) popen environment (if available)
   if (isset($hwi_config['hwi_popen_env'])) {
      foreach ($hwi_config['hwi_popen_env'] as $key=>$val)
         $a_env[strtoupper(trim($key))]=$val;
   }

// temporary environment
   if (is_array($env)) {
      foreach ($env as $key=>$val)
         $a_env[strtoupper(trim($key))]=$val;
   }

//applying environment variables
   foreach ($a_env as $key=>$val) {
      $o_env[$key]=getenv($key);
      hwi_log("-- hwi_popen : setting $key=$val (old value=".$o_env[$key].")");
      if (trim($val)==='') {
         if ($key=='LD_PRELOAD') $cmd='LD_PRELOAD= '.$cmd;
         putenv("$key=");
         //This corrupts the php-fpm process!
         //putenv("$key"); 
      } else {
         putenv("$key=$val");
      }
   }

//descriptors
   $descriptorspec = array (
      0 => array("pipe", "r"),
      1 => array("pipe", "w"),
      2 => array("pipe", "w")
   );
   if ($hwi_config['host_os']!='win32') {
      $descriptorspec[3]=array("pipe", "w");
   }

//exitcodes workaround
   if ((is_object($cmdstruct) && $cmdstruct->options['BACKGROUND']) || (is_string($cmdstruct) && preg_match('/&$/', $cmd))) {
      //bacground processes - no exit code capturing ('&' must be the last character at the command line)
   } else {
      if ($hwi_config['host_os'] == 'win32') {
         //since sudo-1.3.exe (Windows) the return code is written by sudo!
         if (!preg_match(';sudo[a-z0-9._\-]*.exe;',$cmd)) {
            //$cmd .= " & echo %ERRORLEVEL% ";
            $cmd .= " && echo 0 || echo 1 ";
         }
      } else {
         $cmd .= " ; echo $? >&3";
      }
      //write session before the command execution (if needed)
      if (hwi_is_hanging_proc_open()) hwi_session_write_close();
   }

//log the command being executed
   $cmdlog!='' && hwi_log("-- hwi_popen : executing $cmdlog");

//start the process
   $__hwi_popen_process_res = proc_open($cmd, $descriptorspec, $pipes, $hwi_config['tmp_dir']);
   hwi_log("-- hwi_popen : created process '$__hwi_popen_process_res'");

//restoring original environment variables
   hwi_log('-- hwi_popen : restoring original environment variables');
   foreach ($o_env as $key=>$val) {
      if (trim($val)==='') {
         putenv("$key=");
         //This corrupts the php-fpm process!
         //putenv("$key"); 
      } else {
         putenv("$key=$val");
      }
   }

   if (is_object($cmdstruct) && isset($cmdstruct->__HWI_EXE)) putenv("__HWI_EXE=");

   if ((is_object($cmdstruct) && $cmdstruct->options['BACKGROUND']) || (is_string($cmdstruct) && preg_match('/&$/', $cmd))) {
      $cmdlog!='' && wai_audit('hwi_popen: EXEC '.$cmdlog);

      //background processes are only spawned, they become childs of init process (1)
      //processing of output streams would be possible, but then the command would not 
      //run at the background
      if ($stdin!='') {
         // send the stdin string
         fwrite($pipes[0], $stdin);
         fflush($pipes[0]);
         fclose($pipes[0]);
      }
      fclose($pipes[1]);
      fclose($pipes[2]);
      if ($hwi_config['host_os']!='win32') fclose($pipes[3]);
      $exitc = proc_close($__hwi_popen_process_res);
      return TRUE;
   }

   if (is_resource($__hwi_popen_process_res)) {
      if (isset($hwi_config['proc_open_blocking'])) {
         // block process stdout or stderr 0/1
         hwi_log('-- hwi_popen: configuring stream blocking mode : '.hwi_yesno($hwi_config['proc_open_blocking'], 'ON', 'OFF'));
         stream_set_blocking($pipes[1],$hwi_config['proc_open_blocking']);
         stream_set_blocking($pipes[2],$hwi_config['proc_open_blocking']);
         if ($hwi_config['host_os']!='win32') stream_set_blocking($pipes[3],$hwi_config['proc_open_blocking']);
      }

      if (isset($hwi_config['proc_open_buffer'])) {
         // size of buffer stdout or stderr, default is 8192 Bytes
         hwi_log('-- hwi_popen: configuring write buffer size: '.@$hwi_config['proc_open_buffer'].'B');
         stream_set_write_buffer($pipes[1],$hwi_config['proc_open_buffer']);
         stream_set_write_buffer($pipes[2],$hwi_config['proc_open_buffer']);
         if ($hwi_config['host_os']!='win32') stream_set_write_buffer($pipes[3],$hwi_config['proc_open_buffer']);
      }

      $cmdlog!='' && wai_audit('hwi_popen: EXEC '.$cmdlog);

 // write the STDIN data in the stdin stream
      if ($stdin!='') {
         // send the stdin string
         fwrite($pipes[0], $stdin);
         fflush($pipes[0]);
         fclose($pipes[0]);
      }

// mode initilization
      $fo=$fe=FALSE;
      if ($stdout===FALSE && $stderr===FALSE) { 
         //manual mode
         hwi_log('-- hwi_popen: running MANUAL mode');
         $pipes['__process_res']=$__hwi_popen_process_res;
         return $pipes;
      } else {
         //stdout
         if (!isset($stdout)) $stdout='';
         elseif (is_string($stdout)) {
            if (function_exists($stdout)) $fo=TRUE;
            else $stdout='';
         } elseif (is_array($stdout)) {
            $stdout=array();
         } else {
            $stdout='';
         }
         //stderr
         if (!isset($stderr)) $stderr='';
         elseif (is_string($stderr)) {
            if (function_exists($stderr)) $fe=TRUE;
            else $stderr='';
         } elseif (is_array($stderr)) {
            $stderr=array();
         } else {
            $stderr='';
         }
      }

// STDOUT processing
      $prev_stdout_row=null;
      while (is_resource($pipes[1]) && !feof($pipes[1])) {
         if (($row=fgets($pipes[1], 4096))===FALSE){
           hwi_log('-- hwi_popen: WARNING: reading from STDOUT failed, trying again in '.$hwi_config['proc_open_wait'].'us...');
           @usleep($hwi_config['proc_open_wait']);
           continue;
         }
         $last_stdout_row=$row;
         if (!is_null($prev_stdout_row)) {
            if (is_array($stdout))
               $stdout[]=$prev_stdout_row;
            elseif ($fo)
               $stdout($prev_stdout_row);
         else $stdout.=$prev_stdout_row;
         }
         $prev_stdout_row=$last_stdout_row;
      }
      fclose($pipes[1]);
      if ($hwi_config['host_os']!='win32') {
         if (is_array($stdout))
            $stdout[]=@$last_stdout_row;
         elseif ($fo)
            $stdout($last_stdout_row);
         else $stdout.=@$last_stdout_row;
      }
// STDERR processing
      while (is_resource($pipes[2]) && !feof($pipes[2])) {
         if (($row=fgets($pipes[2], 4096))===FALSE){
             hwi_log('-- hwi_popen: WARNING: reading from STDERR failed, trying again in '.$hwi_config['proc_open_wait'].'us...');
             @usleep($hwi_config['proc_open_wait']);
             continue;
         }
         if (is_array($stderr))
            $stderr[]=$row;
         elseif ($fe)
            $stderr($row);
         else $stderr.=$row;
      }
      fclose($pipes[2]);

      if ($hwi_config['host_os']!='win32') {
         while (is_resource($pipes[3]) && !feof($pipes[3])) {
            if (($row=fgets($pipes[3], 4096))===FALSE){
               hwi_log('-- hwi_popen: WARNING: reading from pipes[3] failed, trying again in '.$hwi_config['proc_open_wait'].'us...');
               @usleep($hwi_config['proc_open_wait']);
               continue;
            }
            $exitcode=rtrim($row,"\n");
            break;
         }
         fclose($pipes[3]);
      } else {
         $exitcode=trim($last_stdout_row);
      }

      $exitc = proc_close($__hwi_popen_process_res);
      if (hwi_is_hanging_proc_open()) hwi_session_restart();

      hwi_log("-- hwi_popen : process '$__hwi_popen_process_res' finished");
      return TRUE;
   }

   if (hwi_is_hanging_proc_open()) hwi_session_restart();

   hwi_error("External command execution failed", "command: $cmdlog"); //TODO: dictionary
   return FALSE;
}

//only in manual mode of strem (pipes) processing, see the hwi_popen modes
function hwi_pclose(&$pipes) {
   global $hwi_config;

   if ($hwi_config['host_os']!='win32') {
      //the streams 1 and 2 must be read before reading the stream 3 (otherwise problems with blocked reading!)
      while (is_resource($pipes[1]) && !feof($pipes[1])) fgets($pipes[1]); 
      while (is_resource($pipes[2]) && !feof($pipes[2])) fgets($pipes[2]); 
      $lastrow='';
      while (is_resource($pipes[3]) && !feof($pipes[3])) {
         if (($row=fgets($pipes[3], 4096))!==FALSE) {
            $lastrow=$row;
         }
      }
      is_resource($pipes[1]) && fclose($pipes[1]);
      is_resource($pipes[2]) && fclose($pipes[2]);
      fclose($pipes[3]);
      $exitcode=rtrim($lastrow,"\n");
   } elseif (isset($pipes['last_buffer'])) {
      $exitcode=trim($pipes['last_buffer']);
   }
   else $exitcode = '';

   $exitc = proc_close($pipes['__process_res']);

   if (hwi_is_hanging_proc_open()) hwi_session_restart();

   hwi_log("-- hwi_popen : process '$pipes[__process_res]' finished");
   return $exitcode;
}

// This function will convert a strring into a filename
// safe string (filename friendly). It would be possible
// to use some kind of coding, but this function keeps
// the human readibility of the result.
//
// Examples:
//
// input:'radek'              output:'radek
// input:'akce:radek'         output:'akceTradek
// input:'akce:\radek'        output:'akceT.radek
// input:'ab radek'           output:'ab_radek
// input:'sradek'             output:'sradek
// input:'radek$#'            output:'radekDH
// input:'horizont-it//radek' output:'horizont-it.radek
// input:'horizont-it\radek'  output:'horizont-it.radek
// input:'horizont-it\\radek' output:'horizont-it.radek
// input:'Radek Svitak'       output:'radek_svitak
// input:'CON'                output:'conX
// input:'CON.PRN'            output:'conX.prnX
// input:'CON.AUX.PRN'        output:'conX.auxX.prnX
// input:'CONNECT'            output:'connect
// input:'radek.horizont'     output:'radek.horizont
// input:'radek O'niel'       output:'radek_o'niel
// input:'radek.EXE'          output:'radek.exe
// input:'radek.com1.txt'     output:'radek.com1X.txt
// input:'lpt2.txt'           output:'lpt2X.txt
function hwi_filename_safe_string($s) {
   global $hwi_config;

   //all alhabetical characters small, cut all white space at the beginning and at the end
   //case insensitive - neccesary on windows
   $s=strtolower(trim($s));
   //all whitespace replace by underscore
   $s=preg_replace(';\s+;', '_', $s);
   //all slashes (both types) replace by dot ('.') - substring of slashes replaced by one dot
   $s=preg_replace(';[\\\/]+;', '.', $s);
   //substring of dots replaced by one dot
   $s=preg_replace(';\.+;', '.', $s);
   //special characters replaced by UPPERCASE letter
   $s=strtr($s,
      '@{}$=^+#()?[]~!&%*,:;<>|',
      'ABCDEFGHIJKLMNOPQRSTUVWY'
   );
   //this is neccessary on windows only, but in case of a migration in a future we apply it
   //in UNIX as well
   $s=preg_replace('/^(PRN|CON|AUX|CLOCK$|NUL|COM\d+|LPT\d+)$/im','$0X',str_replace('.',"\n",$s));
   $s=str_replace("\n",'.',$s);
   return $s;
}

function hwi_id_safe_string($s) {
   global $hwi_config;

   //all alhabetical characters small, cut all white space at the beginning and at the end
   //case insensitive - neccesary on windows
   $s=strtoupper(trim($s));
   //all whitespace replace by underscore
   $s=preg_replace(';\s+;', '_', $s);
   //all slashes (both types) replace by dot ('.') - substring of slashes replaced by one dot
   $s=preg_replace(';[^A-Z0-9_\-\^]+;', '', $s);
   //replace more underscores by one
   $s=preg_replace(';__+;', '_', $s);
   return $s;
}


// ------------------------------------------------
// HWI Session managemnent
// ------------------------------------------------
class hwi_session {
   //Key for encryption/decryption
   private static $_key;
   //Path of the session file
   private static $_path;
   //Session name (optional)
   private static $_name;
   //Size of the IV vector for encryption
   private static $_ivsize;
   //Cookie variable name of the key
   private static $_keyname;
   //Crypt method
   private static $_enc_type;
   
   private static $_sess_fp;

   //Generate a random key
   //fallback to mt_rand if PHP < 5.3 or no openssl available
   private static function _random_key($length=32) {
      if (function_exists('openssl_random_pseudo_bytes')) {
         $rnd = openssl_random_pseudo_bytes($length, $strong);
         if($strong === TRUE) return $rnd;
      }
      for ($i=0;$i<$length;$i++) {
         $sha= sha1(mt_rand());
         $char= mt_rand(0,30);
         $rnd.= chr(hexdec($sha[$char].$sha[$char+1]));
      }
      return $rnd;
   }

   //Open the session
   public static function open($save_path, $session_name) {
      global $hwi_config;

      self::$_path=$save_path.'/';   
      self::$_name=$session_name;
      self::$_enc_type='mcrypt';

      if ((isset($hwi_config['session_encmethod']) && $hwi_config['session_encmethod']!=='mcrypt') || !function_exists('mcrypt_get_iv_size')) {
         //fallback to base64
         self::$_enc_type='base64';
      }

      switch (self::$_enc_type) {
         case 'mcrypt': 
            self::$_keyname= "KEY_$session_name";
            self::$_ivsize=mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_CBC);
            $keylength=mcrypt_get_key_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_CBC);
            if (empty($_COOKIE[self::$_keyname])) {
               self::$_key= self::_random_key($keylength);
               $cookie_param = session_get_cookie_params();
               setcookie(
                  self::$_keyname,
                  base64_encode(self::$_key),
                  $cookie_param['lifetime'],
                  $cookie_param['path'],
                  $cookie_param['domain'],
                  $cookie_param['secure'],
                  $cookie_param['httponly']
               );
            } else {
               self::$_key= base64_decode($_COOKIE[self::$_keyname]);
            } 
            break;
         case 'base64':
            break;
      }
      return true;
   }

   //Close the session
   public static function close() {
       return true;
   }

   //Read and decrypt the session
   public static function read($id) {
      $sess_file = self::$_path.self::$_name."_$id";
      clearstatcache();
      if (file_exists($sess_file)) {
         if (($size=filesize($sess_file))>0) {
            if ((self::$_sess_fp=fopen($sess_file, 'r+'))!==FALSE) {
               while (!flock(self::$_sess_fp, LOCK_EX)) { //try to lock
                  usleep(rand(1, 10000));
               }
               $data=fread(self::$_sess_fp, $size);
            } else {
               trigger_error('hwi_session : unable to open session file \''.$sess_file.'\'', E_USER_WARNING); 
            }
         }
      }
      if (empty($data)) {
         //empty SESSION
         return FALSE;
      }
      switch (self::$_enc_type) {
         case 'mcrypt': 
            $iv= substr($data,0,self::$_ivsize);
            $encrypted= substr($data,self::$_ivsize);
            $decrypt = mcrypt_decrypt(MCRYPT_RIJNDAEL_256, self::$_key, $encrypted, MCRYPT_MODE_CBC, $iv);
            break;
         case 'base64':
            if (($decrypt=base64_decode($data))===FALSE) {
               trigger_error('hwi_session : session data decryption failed - \''.$sess_file.'\'', E_USER_WARNING); 
               return FALSE;
            }
            break;
      }
      return rtrim($decrypt, "\0"); 
   }
   
   //Encrypt and write the session
   public static function write($id, $data) {
      if (empty($data)) return 1;
      $sess_file = self::$_path.self::$_name."_$id";
      switch (self::$_enc_type) {
         case 'mcrypt':
            $iv= mcrypt_create_iv(self::$_ivsize, MCRYPT_RAND);
            $encrypted= mcrypt_encrypt(self::MCRYPT_RIJNDAEL_256, self::$_key, $data, MCRYPT_MODE_CBC, $iv);
            break;
         case 'base64':
            if (($encrypted=base64_encode($data))===FALSE) {
               trigger_error('hwi_session : session data encryption failed - \''.$sess_file.'\'', E_USER_WARNING); 
               return FALSE;
            }
            break;
      }
      clearstatcache();
      if (file_exists($sess_file) && is_resource(self::$_sess_fp)) {
         if (flock(self::$_sess_fp, LOCK_EX)) {
            rewind(self::$_sess_fp);
            ftruncate(self::$_sess_fp, 0);
            $return=fwrite(self::$_sess_fp, $encrypted);
            flock(self::$_sess_fp, LOCK_UN);
            fclose(self::$_sess_fp);
            self::$_sess_fp=NULL;
            return $return;
         } else {
            trigger_error('hwi_session : unable to lock session file for writing \''.$sess_file.'\'', E_USER_WARNING); 
            return FALSE;
         }
      }
      //create new
      $fp=fopen($sess_file, 'w');
      $return = fwrite($fp, $encrypted);
      fclose($fp);
      return $return;
   }

   //Destoroy the session
   public static function destroy($id) {
      $sess_file = self::$_path.self::$_name."_$id";
      self::$_sess_fp=NULL;
      switch (self::$_enc_type) {
         case 'mcrypt':
            setcookie(self::$_keyname, '', time() - 3600);
            break;
      }
      return(unlink($sess_file));
   }

   //Garbage Collector
   public static function gc($max) {
      foreach (glob(self::$_path.self::$_name.'_*') as $filename) {
         if (filemtime($filename) + $max < time()) {
            unlink($filename);
         }
      }
      return true;
   }
}

function hwi_session_start($mode='READ_WRITE') {
   if (strtoupper($mode)=='READONLY') {
      if (isset($_COOKIE[ini_get('session.name')])) {
         $sessfile1=session_save_path().'/sess_'.$_COOKIE[ini_get('session.name')];
         $sessfile2=session_save_path().'/'.ini_get('session.name').'_'.$_COOKIE[ini_get('session.name')];
         if (file_exists($sessfile=$sessfile1) || file_exists($sessfile=$sessfile2)) {
            
            $att=0; $fp=FALSE;
            while (++$att<=20 && $fp===FALSE) {
               if (($session_data=file_get_contents($sessfile))===FALSE) {
                  sleep(1);
               }
            }
            if ($session_data===FALSE) {
               trigger_error("Unable to read session data from session file '$sessfile' of {'$sessfile1', '$sessfile2'}...\n", E_USER_NOTICE);
               //may cause the "Cannot send session cache limiter - headers already sent" error message
               //on calling session_start() which may damage the output but avoids hanging inside session_start
               echo ' ';
            } else {
               $GLOBALS['_SESSIONR']=Session::unserialize($session_data);
            }
         }
      }
   } else {
      session_start();
   } 
}

//function that should be called to restart the already closed PHP session
//(e.g. closed by session_write_close()). The optional parameter can be used to
//restore the session data 
function hwi_session_restart($_SESSION_BACKUP=NULL) {
   //the purpose of this code is to test if the session is not locked by another process 
   //working with it in the meantime
   if (isset($_COOKIE[ini_get('session.name')])) {
      $sessfile1=session_save_path().'/sess_'.session_id();
      $sessfile2=session_save_path().'/'.ini_get('session.name').'_'.session_id();
      if (file_exists($sessfile=$sessfile1) || file_exists($sessfile=$sessfile2)) {
         $att=0; $fp=FALSE;
         while (++$att<=20 && $fp===FALSE) {
            if (($fp=fopen($sessfile, 'a'))===FALSE) {
               sleep(1);
           }
         }
         if ($fp===FALSE) {
            //will cause the "Cannot send session cache limiter - headers already sent" error message
            //on calling session_start() which may damage the output but avoids hangs inside session_start
            hwi_session_start('READONLY');
         } else {
            fclose($fp);
         }
         @hwi_session_start();
      } else {
         trigger_error("Session file doesn't exist {'$sessfile1', '$sessfile2'}. \$_COOKIE['".ini_get('session.name')."']=".$_COOKIE[ini_get('session.name')]."\n", E_USER_WARNING);
         hwi_session_start();
      }
   } else {
     hwi_session_start();
   }     
   if ($_SESSION_BACKUP!==NULL) $_SESSION=$_SESSION_BACKUP;
   else if (isset($GLOBALS['_SESSIONR'])) $_SESSION=$GLOBALS['_SESSIONR'];
   unset($GLOBALS['_SESSIONR']);
}

//https://bugs.php.net/bug.php?id=44942
function hwi_is_hanging_proc_open() {
   global $hwi_config, $__session;
   static $result=NULL;
   if ($result!==NULL) return $result;
   $result=(!isset($__session) || $__session) && //only if for scripts requiring the session
           (strpos(strtolower(php_sapi_name()), 'apache2')!==FALSE &&  //only for PHP as Apache module
            (strtoupper(substr(PHP_OS,0,3))==='WIN' && php_uname('r')<6.1 || //Windows Vista, Windows Server 2003 or older
               !defined('PHP_VERSION_ID') || PHP_VERSION_ID<50400) //or PHP prior to 5.4
             ||
             hwi_yesno($hwi_config['force_session_write_close']) //or if closing session is explicitly required
           ) 
           //this error occurs only if session handler is "files"
           && (strtolower(trim(ini_get('session.save_handler')))=='files');
   hwi_log('-- hwi_is_hanging_proc_open='.var_export($result,1).' [php_sapi_name='.php_sapi_name().', PHP_OS='.PHP_OS.', PHP_VERSION_ID='.PHP_VERSION_ID.' hwi_config[force_session_write_close]='.hwi_yesno($hwi_config['force_session_write_close'],'YES','NO').' session.save_handler='.ini_get('session.save_handler').']');
   return $result;
}

function hwi_session_write_close($mode='CLOSE') {
   if (isset($GLOBALS['_SESSIONR'])) return FALSE;

   //if (isset($_COOKIE[ini_get('session.name')])) {
      if (strtoupper($mode)=='READONLY') $GLOBALS['_SESSIONR']=$_SESSION;
      hwi_log("-- hwi_popen : closing the session. (#".count($_SESSION).")");
      session_write_close();
   //}
   return TRUE;
}

function hwi_session_regenerate_id($delete_old_session=FALSE) {
   if (!isset($GLOBALS['_SESSIONR'])) session_regenerate_id($delete_old_session);
}

class Session {
    public static function unserialize($session_data) {
        $method = ini_get("session.serialize_handler");
        switch ($method) {
            case "php":
                return self::unserialize_php($session_data);
                break;
            case "php_binary":
                return self::unserialize_phpbinary($session_data);
                break;
            default:
                throw new Exception("Unsupported session.serialize_handler: " . $method . ". Supported: php, php_binary");
        }
    }

    private static function unserialize_php($session_data) {
        $return_data = array();
        $offset = 0;
        while ($offset < strlen($session_data)) {
            if (!strstr(substr($session_data, $offset), "|")) {
                throw new Exception("invalid data, remaining: " . substr($session_data, $offset));
            }
            $pos = strpos($session_data, "|", $offset);
            $num = $pos - $offset;
            $varname = substr($session_data, $offset, $num);
            $offset += $num + 1;
            $data = unserialize(substr($session_data, $offset));
            $return_data[$varname] = $data;
            $offset += strlen(serialize($data));
        }
        return $return_data;
    }

    private static function unserialize_phpbinary($session_data) {
        $return_data = array();
        $offset = 0;
        while ($offset < strlen($session_data)) {
            $num = ord($session_data[$offset]);
            $offset += 1;
            $varname = substr($session_data, $offset, $num);
            $offset += $num;
            $data = unserialize(substr($session_data, $offset));
            $return_data[$varname] = $data;
            $offset += strlen(serialize($data));
        }
        return $return_data;
    }
}


//TODO: add support of PHP's internal get_browser function based on the ini_get('browsecap') parameter
function hwi_get_browser($user_agent=NULL, $return_array=TRUE) {
   if ($user_agent===NULL && $return_array===TRUE && ($browser=wai_session('hwi_browser'))!==NULL && 
       ($browser['BROWSER']!='IE' || $_SERVER['SCRIPT_NAME']!='/index.php')) {
      //cache is ignored in case of IExplorer and out of the index.php - the reason is that we need to catch 
      //switching of the compatibility mode!
      return $browser;
   }
   
   global $hwi_config;
   $oml=ini_get('memory_limit');
   ini_set('memory_limit', -1);

   try {
      require_once 'browscap.php';
      $bc = new Browscap($hwi_config['hwi_root'].'/inc/');
      $bc->updateMethod=Browscap::UPDATE_LOCAL;
      $bc->doAutoUpdate=FALSE;
      $bc->localFile=$hwi_config['hwi_root'].'/inc/browscap.ini';
      $bc->cacheFilename='browscap.obj.php';
      $browser = $bc->getBrowser($user_agent, $return_array);
      unset($bc);
   } catch(Exception $e) {
      unset($bc);
      $browser=FALSE;
   }

   if (is_array($browser)) $browser=array_change_key_case($browser, CASE_UPPER);
   
   ini_set('memory_limit', $oml);
   if ($user_agent===NULL && $return_array===TRUE) wai_session('hwi_browser', $browser);
   return $browser;
}

?>
