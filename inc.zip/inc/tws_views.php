<?php
//   HORIZONT Software GmbH, Munich
//

/*    Public functions:

tws_dbobject_to_array($object, $id);

   Get <object> with ID from DB and put it into array with structure under tws_composer
   <id> is the full object name, e.g. WS#STREAM.JOB
   e.g. ('job', 'WS#STREAM.JOB')

tws_arr_to_form($object, $action, $arr='')

   // Show form with previously saved object
   // actions are: 'add', 'modify', 'copy', 'display'
   // e.g. ('job', 'display', $arr)

tws_form_to_arr($object, $post)

tws_arr_to_composer($object, $arr)

-----------------------------------------
Submit:

iwd_show_submit_form(obj, id)
      Show submit form from id ('WS#JS' or 'WS#JOB')
      e.g. iwd_show_submit_form('job', 'WS#JOB');

array  iwd_submit_to_arr(obj, post)
      Put data from submit form into array
      in fact result = $_POST

string  iwd_submit_to_conman(obj, arr)
      Return command for submit
      obj = 'job'/'jobstream'


 iwd_arr_to_submit(obj, arr, display='')
         Show submit form from array
*/

// Get <object> with ID from DB and put it into array with structure under tws_composer
// <id> is the full object name, e.g. WS#STREAM.JOB
function tws_dbobject_to_array($object, $id){
   if (defined('IWD_PROCMAN')) {
      $eold=error_reporting(E_ERROR | E_WARNING);
      $de_old=ini_get('display_errors');
      ini_set('display_errors', 0);
   }

   $fce = "tws_$object"."_to_arr";
   $arr = $fce($id);

   $arr['tws_id'] = $id;

   if (defined('IWD_PROCMAN')) {
      error_reporting($eold);
      ini_set('display_errors', $de_old);
   }
   return $arr;
}

// Show form with previously saved object
//

function tws_arr_to_form($object, $action, $arr=''){
   if (defined('IWD_PROCMAN')) {
      $eold=error_reporting(E_ERROR | E_WARNING);
      $de_old=ini_get('display_errors');
      ini_set('display_errors', 0);
   }
   if(empty($arr))
      $arr = array();
   else { ?>
      <input type="hidden" name="tws_id" value="<?=$arr['tws_id']?>">
      <input type="hidden" name="object" value="<?=$object?>">
   <? }
   $fn = "tws_show_$object"."_form";
   $fn($arr, $action);
   if (defined('IWD_PROCMAN')) {
      error_reporting($eold);
      ini_set('display_errors', $de_old);
   }
   return TRUE;
}

function tws_form_to_arr($object, $post){
   if (defined('IWD_PROCMAN')) {
      $eold=error_reporting(E_ERROR | E_WARNING);
      $de_old=ini_get('display_errors');
      ini_set('display_errors', 0);
   }
   foreach($post as $key=>$value){
      if(is_string($value))
         $post[$key] = trim($value);
   }
   switch ($object) {
      case 'parameter' :
         $post['tws_id']=((isset($post['parameter_table']) && trim($post['parameter_table'])!='') ? $post['parameter_table'] : 'MAIN_TABLE').'.'.$post['parameter_name'];
         break;
      case 'prompt':
         $post['tws_id']=$post['prompt_name'];
         break;
      case 'resource':
         $post['tws_id']=$post['resource_workstation'].'#'.$post['resource_name'];
         break;
      case 'job':
         $post['tws_id']=$post['workstation'].'#'.$post['job'];
         break;
      case 'jobstream':
         //ERR18606: IWD_PROCMAN - storing all TWS dates in the YYYY-MM-DD ISO format
         if (($post['validfrom']=trim($post['validfrom']))!='' && ($post['validfrom']=tws_userdate_to_iso($post['validfrom'], NULL, TRUE))===FALSE) {
             tws_error($post['validfrom'], 'Unsupported validfrom date format');
             return FALSE;
         }
         if (($post['validto']=trim($post['validto']))!='' && ($post['validto']=tws_userdate_to_iso($post['validto'], NULL, TRUE))===FALSE) {
             tws_error($post['validto'], 'Unsupported validto date format');
             return FALSE;
         }
         $i=0;
         while (isset($post['rc_type'][$i])) {
            if (($post['rc_validfrom'][$i]=trim($post['rc_validfrom'][$i]))!='' && ($post['rc_validfrom'][$i]=tws_userdate_to_iso($post['rc_validfrom'][$i], NULL, TRUE))===FALSE) {
               tws_error($post['rc_validfrom'][$i], 'Unsupported runcycle validfrom date format');
               return FALSE;
            }
            if (($post['rc_validto'][$i]=trim($post['rc_validto'][$i]))!='' && ($post['rc_validto'][$i]=tws_userdate_to_iso($post['rc_validto'][$i], NULL, TRUE))===FALSE) {
               tws_error($post['rc_validto'][$i], 'Unsupported runcycle validto date format');
               return FALSE;
            }
            $s=0;
            while (isset($post['date_day'][$i][$s])) {
               if (($post['date_day'][$i][$s]=trim($post['date_day'][$i][$s]))!='' && ($post['date_day'][$i][$s]=tws_userdate_to_iso($post['date_day'][$i][$s], NULL, TRUE))===FALSE) {
                  tws_error($post['date_day'][$i][$s], 'Unsupported runcycle single date date format');
                  return FALSE;
               }
               $s++;
            }
            $i++;
         }

         //in tws_id segment we need the jobstream validfrom in ISO format - see above the conversion
         //it is then propagated to data['validfrom'] in iwd_dbjs::propagate()
         $post['tws_id']=$post['workstation'].'#'.$post['jobstream'].($post['validfrom']!='' ? ':'.$post['validfrom'] : '');
         break;
      case 'calendar':
         $post['tws_id']=$post['calendar_name'];
         $post['calendar_dates'] = str_replace(' ', '', $post['calendar_dates']);
         $tmp = explode(',', $post['calendar_dates']);
         $post['calendar_dates'] = "";
         foreach($tmp as $date)
            $post['calendar_dates'] .= "'$date',";
         $post['calendar_dates'] = substr($post['calendar_dates'], 0,-1);
         $post['calendar_folder'] = $post['calendar_folder'];
         break;
   }
   if (defined('IWD_PROCMAN')) {
      error_reporting($eold);
      ini_set('display_errors', $de_old);
   }
   return $post;
}

function tws_arr_to_composer($object, $arr, $header=true){
   if (defined('IWD_PROCMAN')) {
      $eold=error_reporting(E_ERROR | E_WARNING);
      $de_old=ini_get('display_errors');
      ini_set('display_errors', 0);
   }
   $fn = "tws_$object"."_to_composer";
   $result=($fn($arr, $header));
   if (defined('IWD_PROCMAN')) {
      error_reporting($eold);
      ini_set('display_errors', $de_old);
   }
   return $result;
}

/*
Private Functions
            tws_show_****_form($array)

draw appropriate form and fill it with values from $array

*/

function tws_show_resource_form($values, $action){
   $action = strtolower($action);
   tws_specialchars($values);
   $disabled = $readonly = '';
   if ($action=='modify') {
      $disabled = 'disabled';
      echo '<script type="text/javascript" src="/tws_js_validators.js"></script>'."\n";
   } elseif ($action=='display') {
      $disabled = 'disabled';
      $readonly = 'readonly';
   }

?>
<table border=0 class='standard' style="padding-left:10px;">
<tr>
   <td><b>Workstation:</b></td>
   <td><input type="text" name="resource_workstation" class="tws_name" required="required" size='16' maxlength='16' value="<?=$values['resource_workstation']?>" <?=$disabled?> >
   <? if($disabled){ ?>
      <input type="hidden" name="resource_workstation" value="<?=$values['resource_workstation']?>">
   <? }
   else { ?>
        <input type="button" name="workstation_list" onClick="tws_picker_open('workstation_picker.php', 'fieldname=resource_workstation&amp;fieldvalue=' + document.contents.resource_workstation.value);" value="List">
   <? } ?>
   </td>
</tr>
<tr>
   <td><b>Resource Name:</b></td>
   <td><input type="text" name="resource_name" class="tws_name" required="required" size='12' maxlength='8' value="<?=$values['resource_name']?>" <?=$disabled?> >
   <? if($disabled){ ?>
      <input type="hidden" name="resource_name" value="<?=$values['resource_name']?>">
   <? } ?>
</td>
</tr>
<tr>
   <td><b>Units:</b></td>
   <td><input type="text" name="resource_quantity" required="required" class="tws_num" size='4' maxlength='4' value="<?=$values['resource_quantity']?>" <?=$readonly?>></td>
</tr>
<tr>
   <td><b>Description:</b></td>
   <td><input type="text" name="resource_description" size='64' maxlength='64' value="<?=$values['resource_description']?>"></td>
</tr>
</table>
<?
}

function tws_show_prompt_form($values, $action){
   global $tws_config;

   $action = strtolower($action);
   tws_specialchars($values);
   $disabled = $readonly = '';
   if ($action=='modify') {
      $disabled = 'disabled';
      echo '<script type="text/javascript" src="/tws_js_validators.js"></script>'."\n";
   } elseif ($action=='display') {
      $disabled = 'disabled';
      $readonly = 'readonly';
   }

?>
<table border=0 class='standard' style="padding-left:10px;">
<? if ($tws_config['cpuinfo']['version']>='9.5002'){ ?>
<tr>
   <td><b>Prompt Folder:</b></td>
   <td><input type="text" name="prompt_folder" class="tws_name" required="required" size=60 maxlength=200 value="<?=$values['prompt_folder']?>" <?=$disabled?> >
       <? if($action != 'modify' && $action != 'display'){ ?>
       	<input type="button" name="folder_list" onClick="tws_picker_open('folder_picker.php', 'fieldname=prompt_folder&fieldvalue=' + document.contents.prompt_folder.value);" value="List" >
      <? }
      if($action == 'modify'){ ?>
         <input type="hidden" name="prompt_folder" value="<?=$values['prompt_folder']?>" >
      <? } ?>
   </td>
</tr>
<? } ?>
<tr>
   <td><b>Prompt Name:</b></td>
   <td><input type="text" name="prompt_name" class="tws_name" required="required" size='12' maxlength='8' value="<?=$values['prompt_name']?>" <?=$disabled?> >
   <? if($disabled){ ?>
      <input type="hidden" name="prompt_name" value="<?=$values['prompt_name']?>">
   <? } ?>
   </td>
</tr>
<tr>
   <td><b>Text:</b></td>
   <td><input type="text" name="prompt_text" size=60 maxlength=200  value="<?=$values['prompt_text']?>" <?=$readonly?>></td>
</tr>
</table>
<?
}

function tws_show_parameter_form($values, $action){
   global $tws_config;
   $action = strtolower($action);
   tws_specialchars($values);
   $disabled = $readonly = '';
   if ($action=='modify') {
      $disabled = 'disabled';
      echo '<script type="text/javascript" src="/tws_js_validators.js"></script>'."\n";
   } elseif ($action=='display') {
      $disabled = 'disabled';
      $readonly = 'readonly';
   }
   $tname = $values['parameter_table'];
   if ($tws_config['cpuinfo']['version']>='9.5002')
       $tname = $values['parameter_table_folder'].$tname;
?>
<table border=0 class='standard' style="padding-left:10px;">
<tr>
   <td><b>Table:</b></td>
   <td><input type="text" name="parameter_table" class="tws_name" size='60' maxlength="80" value="<?=$tname?>" <?=$disabled?>>
   <? if($disabled){ ?>
      <input type="hidden" name="parameter_table" value="<?=$tname?>">
   <? } else { ?>
      <input type="button" name="parameter_table_list" onClick="tws_picker_open('parameter_table_picker.php', 'fieldname=parameter_table&amp;fieldvalue=' + document.contents.parameter_table.value);" value="List">
   <? } ?>
   </td>
</tr>
<tr>
   <td><b>Name:</b></td>
   <td><input type="text" name="parameter_name" class="tws_name" required="required" size='16' maxlength='64' value="<?=$values['parameter_name']?>" <?=$disabled?>>
   <? if($disabled){ ?>
      <input type="hidden" name="parameter_name" value="<?=$values['parameter_name']?>">
   <? } ?>
   </td>
</tr>
<tr>
   <td><b>Value:</b></td>
   <td><input type="text" name="parameter_value" size='80' maxlength="1024" value="<?=$values['parameter_value']?>" <?=$readonly?>></td>
</tr>
</table>
<?
}


function tws_show_parameter_table_form($values, $action){
   global $tws_config;
   $action = strtolower($action);
   tws_specialchars($values);
   $disabled = $readonly = '';
   if ($action=='modify') {
      $disabled = 'disabled';
      echo '<script type="text/javascript" src="/tws_js_validators.js"></script>'."\n";
   } elseif ($action=='display') {
      $disabled = 'disabled';
      $readonly = 'readonly';
   }
   $pt_folder=is_array($values['parameter_table_folder']) ? $values['parameter_table_folder'][0] : $values['parameter_table_folder'];
   $pt_name=is_array($values['parameter_table_name']) ? $values['parameter_table_name'][0] : $values['parameter_table_name'];
   $pt_description=is_array($values['parameter_table_description']) ? $values['parameter_table_description'][0] : $values['parameter_table_description'];
   $pt_default=is_array($values['parameter_table_default']) ? $values['parameter_table_default'][0] : $values['parameter_table_default'];
?>
<script type="text/javascript" src="tws_insert_row.js"></script>

<table border=0 class='standard' style="padding-left:10px;">
<? if ($tws_config['cpuinfo']['version']>='9.5002'){ ?>
<tr>
   <td><b>Folder:</b></td>
   <td><input type="text" name="parameter_table_folder" class="" required="required" size=80 maxlength=80 value="<?=$pt_folder?>" <?=$disabled?> >
       <? if($action != 'modify' && $action != 'display'){ ?>
       	<input type="button" name="folder_list" onClick="tws_picker_open('folder_picker.php', 'fieldname=parameter_table_folder&fieldvalue=' + document.contents.parameter_table_folder.value);" value="List" >
      <? }
      if($action == 'modify'){ ?>
         <input type="hidden" name="parameter_table_folder" value="<?=$pt_folder?>" >
      <? } ?>
   </td>
</tr>
<? } ?>
<tr>
   <td><b>Name:</b></td>
   <td><input type="text" name="parameter_table_name" class="tws_name" required="required" size='80' maxlength='80' value="<?=$pt_name?>" <?=$disabled?> >
   <? if($disabled){ ?>
      <input type="hidden" name="parameter_table_name" value="<?=$pt_name?>">
   <? } ?>
   </td>
</tr>
<tr>
   <td><b>Description:</b></td>
   <td><input type="text" name="parameter_table_description" size='80' maxlength='120' value="<?=$pt_description?><?=$readonly?>"></td>
</tr>
<tr>
   <td><b>Default:</b></td>
   <td><input type="checkbox" name="parameter_table_default" value="yes" <?=(tws_yesno($pt_default,TRUE,FALSE) && $copy!='yes'?'checked':'')?> ></td>
</tr>
<tr>
   <td style="vertical-align:top"><b>Parameters:</b></td>
   <td>
      <table id="rdrs" border=0>
         <tr>
            <td>Name:</td>
            <td><input type="text" name="parameter_name[0]" class="tws_name" size='16' maxlength='64' value="<?=$values['parameter_name'][0]?>" <?=$readonly?>></td>
            <td>Value:</td>
            <td><input type="text" name="parameter_value[0]" size='80' maxlength='1024' value="<?=$values['parameter_value'][0]?>" <?=$readonly?>></td>
            <td><?if(!$readonly){?>
               <input type="button" name="add" value=" + " onClick="AddRow(this);">
            <? } ?>
            </td>
         </tr>
      <?
      for($j=1; $j<count($values['parameter_name']); $j++){ ?>
         <tr>
            <td>Name:</td>
            <td><input type="text" name="parameter_name[<?=$j?>]" class="tws_name" size='16' maxlength='64' value="<?=$values['parameter_name'][$j]?>" <?=$readonly?>></td>
            <td>Value:</td>
            <td><input type="text" name="parameter_value[<?=$j?>]" size='80' maxlength='1024' value="<?=$values['parameter_value'][$j]?>" <?=$readonly?>></td>
            <td></td>
         </tr>
      <? } ?>
      </table>
   </td>
</tr>
</table>

<?
}

function tws_show_job_form($values, $action){
   global $tws_config;

   tws_log('-- tws_show_job_form (start at '.basename(__FILE__).'['.__LINE__.'])');
   tws_log("-- tws_show_job_form Parameters: action = $action, $values = ".var_export($values, true));

   $action = strtolower($action);
   tws_specialchars($values);

   if ($action=='modify' || $action=='display') $disabled = 'disabled';
   else $disabled = '';

   if ($action=='display') {
      $readonly = 'readonly';
      $display = 'yes';
   } else {
      $readonly  = '';
      $display = '';
      echo '<script type="text/javascript" src="/tws_js_validators.js"></script>'."\n";
   }
   foreach($values as $key=>$value)
      $$key = $value;

$task_types = array();
$task_types[] =  "";
$task_types[] =  "WINDOWS";
$task_types[] =  "UNIX";
$task_types[] =  "OTHER";
$task_types[] =  "SAP";
$task_types[] =  "executable";
$task_types[] =  "distributedShadowJob";
$task_types[] =  "zShadowJob";
$task_types[] =  "filetransfer";
$task_types[] =  "database";
$task_types[] =  "ws";
$task_types[] =  "j2ee";
$task_types[] =  "java";
$task_types[] =  "xajob";
$task_types[] =  "ibmi";
$task_types[] =  "jcl";

if(!in_array($task_type, $task_types))
   tws_dyer("This job type is not supported by IWS/WebAdmin interface, cannot continue.");
?>
<script type="text/javascript">

   // Call it on change Job Type
   function hide_all() {
      $('table.add_job').css('display','none');
      $('table.add_job input').attr('disabled', 'disabled');
      $('table.add_job select').attr('disabled', 'disabled');
      $('table.add_job textarea').attr('disabled', 'disabled');
      $('tr#stdin').css('display', '');
      <? if ($display!='yes'){?>
         $('input#workstation_list').removeAttr('disabled');
      <? } ?>
      hide_sec_interactive();
      show_recovery();
   }

   function show_sec_85() {
      document.getElementById('sec_85').style.display='';
      $('table#sec_85 input:text').removeAttr('disabled');
      <? if ($display!='yes') : ?>
      $('table#sec_85 input').removeAttr('disabled');
      $('table#sec_85 select').removeAttr('disabled');
      <? endif; ?>
      hide_sec_interactive();
      show_codemap();
   }
   function hide_sec_interactive(display) {
      document.getElementById('interactive').disabled=true;
      var x=document.getElementById('sec_interactive');
      if (display) {
         x.style.display='';
         x.style.color='#808080';
      } else {
         //x.style.display='none';
      }
   }
   function show_sec_interactive() {
      var x=document.getElementById('sec_interactive');
      x.style.display='';
      x.style.color=sec_interactive_color;
      <?php if ($display!='yes') : ?>
      document.getElementById('interactive').disabled=false;
      <? endif; ?>
   }

   function show_codemap() {
      document.getElementById('codemap').style.display='';
      $('table#codemap input').removeAttr('disabled');
   }

   function show_sec_sap() {
      document.getElementById('sec_sap').style.display='';
      $('table#sec_sap input:text').removeAttr('disabled');
      <?php if ($display!='yes') : ?>
      $('table#sec_sap input').removeAttr('disabled');
      $('table#sec_sap textarea').removeAttr('disabled');
      $('table#sec_sap select').removeAttr('disabled');
      <? endif; ?>
      show_codemap();
   }

   function hide_recovery() {
      document.getElementById('recovery').style.display='none';
   }
   function show_recovery() {
      document.getElementById('recovery').style.display='';
      $('table#recovery input').removeAttr('disabled');
      <?php if ($display!='yes') : ?>
      $('table#recovery select').removeAttr('disabled');
      <? endif; ?>
   }
   function show_affinity(){
      document.getElementById('affinity').style.display='';
      $('table#affinity input').removeAttr('disabled');
   }
   function show_environment(){
      document.getElementById('environment').style.display='';
      $('table#environment input').removeAttr('disabled');
   }
   function show_credentials(){
      document.getElementById('credentials').style.display='';
      $('table#credentials input').removeAttr('disabled');
   }
   function show_arguments(){
      $('td.arguments input.argument').remove();   // remove all added arguments
      document.getElementById('arguments').style.display='';
      $('table#arguments input').removeAttr('disabled');
   }
   function show_variables(){
      $('tr.variables').remove();   // remove all added variables
      document.getElementById('variables').style.display='';
      $('table#variables input').removeAttr('disabled');
   }

   function show_executable() {
      document.getElementById('executable').style.display='';
      $('table#executable input:text').removeAttr('disabled');
      <?php if ($display!='yes') : ?>
      $('table#executable input').removeAttr('disabled');
      $('table#executable select').removeAttr('disabled');
      <? endif; ?>
      show_affinity();
      show_environment();
      show_credentials();
      show_arguments();
      show_variables();
      show_codemap();
   }
   function show_dshadow() {
      document.getElementById('dshadow').style.display='';
      document.getElementById('matching').style.display='';
      $('table#dshadow input:text').removeAttr('disabled');
      $('table#matching input:text').removeAttr('disabled');
      <?php if ($display!='yes') : ?>
      $('table#dshadow input').removeAttr('disabled');
      $('table#dshadow select').removeAttr('disabled');
      $('table#matching input').removeAttr('disabled');
      $('table#matching select').removeAttr('disabled');
      <? endif; ?>
   }

   function show_zshadow() {
      document.getElementById('zshadow').style.display='';
      $('table#zshadow input').removeAttr('disabled');
   }
   function show_filetransfer() {
      document.getElementById('filetransfer').style.display='';
      $('table#filetransfer input').removeAttr('disabled');
      <?php if ($display!='yes') : ?>
      $('table#filetransfer select').removeAttr('disabled');
      <? endif; ?>
      document.getElementById('ftp_credentials').style.display='';
      $('table#ftp_credentials input').removeAttr('disabled');
      show_affinity();
      show_codemap();
      change_ft_mode();
   }
   function show_database() {
      document.getElementById('database').style.display='';
      $('table#database input:text').removeAttr('disabled');
      <?php if ($display!='yes') : ?>
      $('table#database input').removeAttr('disabled');
      $('table#database select').removeAttr('disabled');
      $('table#database textarea').removeAttr('disabled');
      <? endif; ?>
      show_credentials();
      show_affinity();
      show_codemap();
   }

   function show_ws() {
      document.getElementById('ws').style.display='';
      $('table#ws input').removeAttr('disabled');
      show_affinity();
      show_credentials();
      show_arguments();
      show_codemap();
   }
   function show_j2ee() {
      document.getElementById('j2ee').style.display='';
      $('table#j2ee input').removeAttr('disabled');
      $('table#j2ee textarea').removeAttr('disabled');
      <?php if ($display!='yes') : ?>
      $('table#j2ee select').removeAttr('disabled');
      <? endif; ?>
      show_affinity();
      show_credentials();
      show_codemap();
   }
   function show_java() {
      document.getElementById('java').style.display='';
      $('table#java input').removeAttr('disabled');
      show_affinity();
      show_variables();
      show_codemap();
   }
   function show_xa() {
      document.getElementById('xa').style.display='';
      $('table#xa input').removeAttr('disabled');
      show_affinity();
      show_variables();
      show_environment();
      $('input[name="stdin"]').attr('disabled', 'disabled');
      $('tr#stdin').css('display', 'none');
      show_credentials();
      show_codemap();
   }
   function show_ibm() {
      document.getElementById('ibm').style.display='';
      $('table#ibm input').removeAttr('disabled');
      show_affinity();
      show_codemap();
   }
   function show_jcl() {
	  document.getElementById('jcl').style.display='';
	  <?php if ($action=='display') : ?>
	  $('table#jcl input').removeAttr('required');
	  <? endif; ?>
	  <?php if ($action!='display') : ?>
	  $('table#jcl input').removeAttr('disabled');
	  $('table#jcl textarea').removeAttr('disabled');
	  <? endif; ?>
	  <?php if ($action!='display' && $jcl_created=='byDefinition') : ?>
	  $('table#jcl textarea').removeAttr('readonly');
	  <? endif; ?>
	  <?php if ($action!='display' && $jcl_created=='byReference') : ?>
	  $('table#jcl input').removeAttr('readonly');
	  <? endif; ?>
	  show_codemap();
   }

// SAP section functions
   function r3type_change() {
      var obj = document.getElementById('r3job_type');
      var tasktype = obj.options[obj.selectedIndex].value;
      switch (tasktype) {
         case "std":
            sap_showall();
            hide_obj('r3job_chlog');
            break;
         case "bwip":
            $('table#sec_sap tr').css('display', '');
            $('table#sec_sap input').removeAttr('disabled');
            $('table#sec_sap select[name!="r3job_type"]').removeAttr('disabled');
            hide_obj('r3job_id');
            hide_obj('r3job_user');
            hide_obj('r3job_spool');
            hide_obj('r3job_log');
            hide_obj('r3job_class');
            hide_obj('r3job_chlog');
            hide_obj('r3job_diswa');
            hide_obj('r3job_immed');
            break;
         case "bwpc":
            $('table#sec_sap tr').css('display', '');
            $('table#sec_sap input').removeAttr('disabled');
            $('table#sec_sap select[name!="r3job_type"]').removeAttr('disabled');
            hide_obj('r3job_id');
            hide_obj('r3job_user');
            hide_obj('r3job_spool');
            hide_obj('r3job_log');
            hide_obj('r3job_class');
            hide_obj('r3job_diswa');
            hide_obj('r3job_immed');
            break;
      }
   }
   function sap_showall() {
      $('table#sec_sap tr').css('display', '');
      $('table#sec_sap input:text').removeAttr('disabled');
      <?php if ($display!='yes') : ?>
      $('table#sec_sap input').removeAttr('disabled');
      $('table#sec_sap textarea').removeAttr('disabled');
      $('table#sec_sap select[name!="r3job_type"]').removeAttr('disabled');
      <?php endif; ?>
   }
   function hide_obj(tr_id) {
      $('input[name="'+tr_id+'"]').removeAttr('checked');
      $('input[name="'+tr_id+'"]').attr('disabled', 'disabled');
      $('select[name="'+tr_id+'"]').val('');
      $('select[name="'+tr_id+'"]').attr('disabled', 'disabled');
      $('tr#'+tr_id).css('display', 'none');
   }


   // J2EE change
   function j2ee_operation_change() {
      var obj = document.getElementById('j2ee_operation');
      var tasktype = obj.options[obj.selectedIndex].value;
      switch (tasktype) {
         case "send":
            $('tr#j2ee_message').css('display', '');
            $('table#j2ee textarea').removeAttr('disabled');

            $('tr#j2ee_timeout').css('display', 'none');
            $('input[name="j2ee_timeout"]').attr('disabled', 'disabled');
            break;
         case "receive":
            $('tr#j2ee_message').css('display', 'none');
            $('table#j2ee textarea').attr('disabled', 'disabled');

            $('tr#j2ee_timeout').css('display', '');
            $('input[name="j2ee_timeout"]').removeAttr('disabled');
            break;
      }
   }

   // Database change
   function db_dbms_change() {
      var obj = document.getElementById('db_dbms');
      var tasktype = obj.options[obj.selectedIndex].value;
      switch (tasktype) {
         case "db2":
         case "oracle":
         case "mssql":
            $('table#database input').removeAttr('disabled');
            $('tr#db_server').css('display', '');
            $('tr#db_port').css('display', '');
            $('tr#db_name').css('display', '');

            $('tr#jdbc_driver').css('display', 'none');
            $('input[name="db_jdbc_driver"]').attr('disabled', 'disabled');
            $('tr#jdbc_string').css('display', 'none');
            $('input[name="db_jdbc_string"]').attr('disabled', 'disabled');
            break;
         case "JDBC":
            $('table#database input').removeAttr('disabled');

            $('tr#db_server').css('display', 'none');
            $('input[name="db_server"]').attr('disabled', 'disabled');
            $('tr#db_port').css('display', 'none');
            $('input[name="db_port"]').attr('disabled', 'disabled');
            $('tr#db_name').css('display', 'none');
            $('input[name="db_name"]').attr('disabled', 'disabled');

            $('tr#jdbc_driver').css('display', '');
            $('tr#jdbc_string').css('display', '');
            break;
      }
   }
   // Filetransfer Mode - CodePage
   function change_ft_mode() {
      var obj = document.getElementById('ft_mode');
      var mode = obj.options[obj.selectedIndex].value;
      if(mode == 'ascii') {
         $('tr#ft_codepage').css('display','');
         $('tr#ft_codepage input').removeAttr('disabled');
      }
      else {
         $('tr#ft_codepage').css('display','none');
         $('tr#ft_codepage input').attr('disabled', 'disabled');
      }
   }
   // Matching
   function showMatch() {
      var obj = document.getElementById('matching_sel');
      var selection = obj.value;
      if(selection=='RELATIVE') {
         $('div#relative').css('display','block');
         $('div#relative input').removeAttr('disabled');
         $('div#relative select').removeAttr('disabled');
         $('div#absolute').css('display','none');
         $('div#absolute input').attr('disabled', 'disabled');
         $('div#absolute select').attr('disabled', 'disabled');
      }
      else if (selection=='ABSOLUTE') {
         $('div#relative').css('display','none');
         $('div#relative input').attr('disabled', 'disabled');
         $('div#relative select').attr('disabled', 'disabled');
         $('div#absolute').css('display','block');
         $('div#absolute input').removeAttr('disabled');
         $('div#absolute select').removeAttr('disabled');
      }
      else {
         $('div#relative').css('display','none');
         $('div#absolute').css('display','none');
         $('div#relative input').attr('disabled', 'disabled');
         $('div#relative select').attr('disabled', 'disabled');
         $('div#absolute input').attr('disabled', 'disabled');
         $('div#absolute select').attr('disabled', 'disabled');
      }
   }

   function insertArgument () {
      var count = $('td.arguments input').size();
      i=count + 1;
      $('td.arguments').append('<input type="text" class="argument" name="arguments['+i+']"/>');
   }
   function insertVariables () {
      var count = $('tr.variables').size();
      i=count + 1;
      $('table.variables').append('<tr class="variables"><td><input type="text" class="variables tws_alfanum" name="var_name['+i+']"/></td><td><input type="text" class="variables" name="var_val['+i+']"/></td></tr>');
   }

   function tws_cmp_vals (val1, val2) {
      if(val1 != val2)
         alert("Password values not correspond, please reenter passwords once again");
   }

// Call Workstation picker
   function select_workstations() {
      var obj = document.getElementById('sel_task_type');
      var tasktype = obj.options[obj.selectedIndex].value;
      if(tasktype == "UNIX" || tasktype == "WINDOWS"  || tasktype == "OTHER") {
         tws_picker_open('workstation_picker.php', 'fieldname=workstation&fieldvalue=' + document.contents.workstation.value);
      }
      else if (tasktype=="zShadowJob"){
         tws_picker_open('workstation_picker.php', 'os=Z&type=E&fieldname=workstation&fieldvalue=' + document.contents.workstation.value);
      }
      else if (tasktype=="SAP"){
         tws_picker_open('workstation_picker.php', 'method=r3batch&fieldname=workstation&fieldvalue=' + document.contents.workstation.value);
      }
      else{
         tws_picker_open('workstation_picker.php', 'type[]=A&type[]=E&type[]=L&type[]=Y&fieldname=workstation&fieldvalue=' + document.contents.workstation.value);
      }
   }

   function type_change(obj) {
      var tasktype = obj.options[obj.selectedIndex].value;
      hide_all();

      switch (tasktype) {
         case "": default:
            hide_recovery();
            $('input#workstation_list').attr('disabled', 'disabled');
            break;
         case "UNIX":
            show_sec_85();
            break;
         case "WINDOWS":
            show_sec_85();
            show_sec_interactive();
            break;
         case "OTHER":
            show_sec_85();
            break;
         case "SAP":
            show_sec_sap();
            r3type_change()
            break;
         case "executable":
            show_executable();
            break;
         case "distributedShadowJob":
            show_dshadow();
            showMatch();
            break;
         case "zShadowJob":
            show_zshadow();
            break;
         case "filetransfer":
            show_filetransfer();
            break;
         case "database":
            show_database();
            db_dbms_change();
            break;
         case "ws":
            show_ws();
            break;
         case "j2ee":
            show_j2ee();
            j2ee_operation_change();
            break;
         case "java":
            show_java();
            break;
         case "xajob":
            show_xa();
            break;
         case "ibmi":
            show_ibm();
            break;
		 case "jcl":
            show_jcl();
            break;
      }
   }

function sel_template(obj){
   var tmpl_num = obj.selectedIndex;

   var tmpl_val = {"tws_id":"CZ14#MMRX9G6G","object":"job","template":"","task_type":"SAP","workstation":"CZ14","job":"MMRX9G6G","description":"0251PFUD RHAUTUPD_NEW","r3_logon":"twsfta","r3job_type":"std","r3job_name":"MMRX9G6G","r3job_id":"","r3job_user":"","r3job_trace":"yes","r3job_debug":"yes","r3job_diswa":"yes","r3job_immed":"yes","r3job_cmd":"-s1 type=A -s1 report=RHAUTUPD_NEW -s1 variant=XXPG_PFUD_ALL -s1 prnew -s1 lang=EN -s1 user=B001XX-PG","r3job_spool":"ON","r3job_log":"","r3job_class":"","exitcodemap":"","recovery_option":"CONTINUE","recovery_workstation":"","recovery_job":"","recovery_prompt":"","action":"Update"};
   if(tmpl_num != 0){
      var key;
      for (key in tmpl_val) {
         if($(':checkbox[name="'+key+'"]').length>0)
            $(':checkbox[name="'+key+'"]').prop('checked', true);
         else
            $('[name="'+key+'"]').val(tmpl_val[key]);
      }
   }
   type_change(document.getElementById('sel_task_type'));
}


</script>

<style type="text/css">
   table.add_job, table.common {
      width:95%;
   }
   table.add_job, table.add_job td, table.common, table.common td {
      border-collapse:collapse;
      padding:3px;
   }
   body {
      margin-left:10px;
      padding-left:10px;
   }
</style>

<!-- COMMON PART -->

<table class="common">
<tr>
<td  colspan=3>
<h3>General</h3>
</td>
</tr>
<tr>
<td  width=180><b>Task Type:</b></td>
<td width=15> * </td>
<td >
<select id="sel_task_type" name="task_type" required="required" onChange="type_change(this);" <?=($readonly?'disabled':'')?>>
   <option value=""        <? if ($task_type == "") echo " selected";?>></option>
   <option value="WINDOWS" <? if ($task_type == "WINDOWS") echo " selected"; ?>>WINDOWS</option>
   <option value="UNIX"    <? if ($task_type == "UNIX") echo " selected"; ?>>UNIX</option>
   <option value="OTHER"   <? if ($task_type == "OTHER") echo " selected"; ?>>OTHER</option>
<? if (tws_have_sap_method() ) { ?>
   <option value="SAP"     <? if ($task_type == "SAP") echo " selected"; ?>>SAP</option>
<? } ?>
<? if ($tws_config['cpuinfo']['version']>='8.6'){ ?>
   <option value="executable"    <? if ($task_type == "executable") echo " selected"; ?>>Executable</option>
   <option value="distributedShadowJob" <? if ($task_type == "distributedShadowJob") echo " selected"; ?>>Shadow Distributed</option>
   <option value="zShadowJob"    <? if ($task_type == "zShadowJob") echo " selected"; ?>>Shadow z/OS</option>
   <option value="filetransfer"  <? if ($task_type == "filetransfer") echo " selected"; ?>>File Transfer</option>
   <option value="database"      <? if ($task_type == "database") echo " selected"; ?>>Database</option>
   <option value="ws"    <? if ($task_type == "ws") echo " selected"; ?>>Web Services</option>
   <option value="j2ee"  <? if ($task_type == "j2ee") echo " selected"; ?>>J2EE</option>
   <option value="java"  <? if ($task_type == "java") echo " selected"; ?>>Java</option>
   <option value="xajob" <? if ($task_type == "xajob") echo " selected"; ?>>XA Job</option>
   <option value="ibmi"  <? if ($task_type == "ibmi") echo " selected"; ?>>IBM i</option>
   <option value="jcl"  <? if ($task_type == "jcl") echo " selected"; ?>>JCL</option>
<? } ?>
</select>
</td>
</tr>

<tr>
<td ><b>Workstation:</b></td>
<td> * </td>
<td >
<input type="text" name="workstation" class="tws_name" required="required" style='width:16em;' maxlength="16" value="<?=(isset($workstation)?$workstation:'')?>" <?=$disabled?>>
<? if($disabled){ ?>
   <input type="hidden" name="workstation" value="<?=$workstation?>">
<? } else { ?>
   <input type="button" name="workstation_list" id="workstation_list" value="List" onClick="select_workstations();">
<? } ?>
</td>
</tr>

<? if($tws_config['cpuinfo']['version']>='9.5'){
     if(empty($job_folder)) $job_folder = '/';
?>
<tr>
   <td><b>Job Folder:</b></td>
   <td></td>
   <td><input type="text" name="job_folder" style="width:15em;" maxlength="16" value="<?=$job_folder?>" <?if($action=='display' || $action=='modify' ) echo "readonly"?>>
       <? if($action != 'modify' && $action != 'display'){ ?>
       	<input type="button" name="folder_list" onClick="tws_picker_open('folder_picker.php', 'fieldname=job_folder&fieldvalue=' + document.contents.job_folder.value);" value="List" >
      <?}?>
   </td>
</tr>
<? } ?>

<tr>
<td ><b>Job Name:</b></td>
<td> * </td>
<td><input type="text" name="job" class="tws_name" required="required" value="<?=(isset($job)?$job:'')?>" style='width:28em;' maxlength="<?=$tws_config['JOB_MAXLENGTH']?>" <?=$disabled?>>
<? if($disabled){ ?>
   <input type="hidden" name="job" value="<?=$job?>">
<? } ?>
</td>
</tr>
<tr>
<td ><b>Description:</b></td>
<td> </td>
<td><input type="text" name="description" size=60 maxlength=64 value="<?=(isset($description) ? str_replace("\\\"","\"", $description):'')?>" <?=$readonly?>></td>
</tr>
</table>

<!-- STANDARD JOBS -->

<table id='sec_85' class="add_job">
<tr><td colspan=3> </td></tr>
<tr>
<td width=180><b>Job Type:</b></td>
<td width=15> </td>
<td>
   <select name="job_type" <?=($readonly?'disabled':'')?>>
      <option value="script" <? if ($job_type != "command") echo " selected";?> >Script</option>
      <option value="command"<? if ($job_type == "command") echo " selected";?> >Command</option>
   </select>
<span id="sec_interactive">
   <label><input type="checkbox" name="interactive"  id="interactive" value="YES" <? if(isset($interactive) && strtoupper($interactive) == "YES") echo ' checked';?>>Interactive</label>
</span>
</td>
</tr>

<tr>
<td nowrap><b>Script / Command:</b></td>
<td> * </td>
<td nowrap>
<input type="text" name="script" required="required" size=60 maxlength=4095 value="<?=(isset($script)?$script:'')?>" <?=$readonly?>>
<input type="button" name="parameter_list" value="Add Parameter" onClick="tws_picker_open('parameter_picker.php', 'fieldname=script&amp;caret=yes&amp;insert=yes&amp;parameter_tablex=@');" <?=($readonly?'disabled':'')?>>
</td>
</tr>

<tr>
<td><b>Logon:</b></td>
<td> * </td>
<td>
<input type="text" name="logon" required="required" size=25 maxlength=47 value="<?=(isset($logon)?$logon:'')?>" <?=$readonly?>>
<input type="button" name="parameter_list" value="Add Parameter" onClick="tws_picker_open('parameter_picker.php', 'fieldname=logon&amp;caret=yes&amp;insert=yes&amp;parameter_tablex=@');" <?=($readonly?'disabled':'')?>>
</td>
</tr>
</table>

   <!-- AFFINITY -->

<table id="affinity" class="add_job">
<tr><td width="180"><b>Affinity Job Name:</b></td>
   <td width=15> </td>
   <td>
   <input type="text" name="affinity" class="tws_name" size="60" value="<?=(isset($affinity)?$affinity:'')?>" <?=$readonly?>>
   <input type="button" name="affinity_job_list"  value="List" class="list" onClick="tws_picker_open('job_picker.php', 'fieldname=affinity&fieldvalue=' + document.contents.affinity.value + '&cpux=' + document.contents.workstation.value);" <?=($readonly?'disabled':'')?>>
   </td>
</tr>
</table>


   <!-- EXECUTABLE -->

<table id="executable" class="add_job">
<tr><td colspan=3> </td></tr>
<tr>
<td width=180 nowrap><b>Working Directory:</b></td>
<td width=15> </td>
<td><input type="text" name="ex_directory" class="tws_file" size=60 value="<?=(isset($ex_directory)?$ex_directory:'')?>" <?=$readonly?>></td>
</tr>
<tr>
<td width=180 nowrap><b>Script / Command:</b></td>
<td> * </td>
<td><input type="text" name="ex_script" required="required" size=60 value="<?=(isset($ex_script)?$ex_script:'')?>" <?=$readonly?>></td>
</tr>
<tr>
<td> </td>
<td> </td>
<td><label><input type="checkbox" name="ex_interactive" value="true" <? if(isset($ex_interactive) && $ex_interactive == 'true') echo " checked";?>>Interactive</label></td>
</tr>
</table>


   <!-- Web Service -->

<table id="ws" class="add_job">
<tr><td colspan=3> </td></tr>
<tr>
<td width=180 nowrap><b>Web Service URL:</b></td>
<td width=15> * </td>
<td><input type="text" name="ws_url" required="required" size=40 value="<?=(isset($ws_url)?$ws_url:'')?>" <?=$readonly?>></td>
</tr>
<tr>
<td nowrap><b>Web Service Command:</b></td>
<td> * </td>
<td><input type="text" name="ws_operation" required="required" size=40 value="<?=(isset($ws_operation)?$ws_operation:'')?>" <?=$readonly?>></td>
</tr>
</table>

<!-- SAP -->
<table id="sec_sap" class="add_job">
<tr>
<td width=180><b>Logon:</b></td>
<td width=15> * </td>
<td>
<input type="text" name="r3_logon" required="required" size=25 maxlength=47 value="<?=(isset($r3_logon)?$r3_logon:'')?>" <?=$readonly?>>
<input type="button" name="parameter_list" value="Add Parameter" onClick="tws_picker_open('parameter_picker.php', 'fieldname=r3_logon&amp;caret=yes&amp;insert=yes&amp;parameter_tablex=@');" <?=($readonly?'disabled':'')?>>
</td>
</tr>
<tr><td colspan="2"><h3>R/3 specific options</h3></td>
    <td><?php
        if (defined('IWD_PROCMAN')) {
            $iwd_env=$GLOBALS['iwd']->get_env();
            $x=new wai_input('text', 'solman');
            $x->set_id(strtoupper($action).'_DBJD_SOLMANTIC');//IWD_MOD_EDIT.CONTENTS.NEW_DBJD_SOLMANTIC
            $x->set_disabled(TRUE); //disabled by default
            $x->app_sec_init();
            if ($readonly) $x->set_disabled(TRUE);
            if (!$x->get_disabled() || $x->show_id()) { ?>
                <div style="position:fixed; right:90px; top:150px; width:200px; padding:10px; border:solid 1px #A0A0A0; background-color:#e0e0e0"><b>SolMan Ticket:</b>
                    <?php $x->print_html();?>
                    <br>
                    <input type="button" value="Load Parameters" onClick="solman_set()" <?=($readonly?'disabled':'')?>>
                    <script type="text/javascript">
                        /* prevent submit form on ENTER press */
                        $('input#NEW_DBJD_SOLMANTIC').on('keydown', function(e) {
                            if (e.which == 13) {
                                e.preventDefault();
                                solman_set();
                            }
                        });
                        function solman_set(){
                            var val = $('input[name="solman"]').val();
                            var url = '/iwd_solman.php';
                            var req = 'solman_interface=<?=$iwd_env['solman_interface']?>&id='+val;
                            $.ajax({
                                type: 'GET',
                                url: url,
                                data: req,
                                //crossDomain: true,
                                success: function(result) {
                                    if(typeof(result['d']) == "undefined"){
                                       alert("Unable to get data of ticket "+ $('input#NEW_DBJD_SOLMANTIC').val()+". Invalid ticket number.");
                                       return;
                                    }
                                    result = result['d'];
                                    if(typeof(result['Jobname']) != "undefined"){
                                       $('input#r3job_name').val(result['Jobname']);

                                       var jobname = "<?=strtoupper(hos_substitute_input('%(client).', hos_get_all_hwm_variables()))?>";
                                       jobname = jobname + result['Jobname'].replace(/ /g, '_');
                                       $('input[name="job"]').val(jobname);
                                    }
                                    if(typeof(result['Description']) != "undefined")
                                       $('input[name="description"]').val(result['Description']);

                                    if(typeof(result['StepSet']['results']) != "undefined" && result['StepSet']['results'].length > 0){
                                       var arr = result['StepSet']['results'];
                                       var r3job_cmd = '';
                                       for(i=0; i<arr.length; i++){
                                          if(typeof(arr[i]['Stepcount']) != "undefined"){
                                             r3job_cmd += "-s"+arr[i]['Stepcount']+" type=A ";
                                             if(typeof(arr[i]['Progname']) != "undefined")
                                                r3job_cmd += "-s"+arr[i]['Stepcount']+" report="+arr[i]['Progname']+' ';
                                             if(typeof(arr[i]['Btcvariant']) != "undefined")
                                                r3job_cmd += "-s"+arr[i]['Stepcount']+" variant="+arr[i]['Btcvariant']+' ';
                                             if(typeof(arr[i]['Spras']) != "undefined")
                                                r3job_cmd += "-s"+arr[i]['Stepcount']+" lang="+arr[i]['Spras']+' ';
                                             if(typeof(arr[i]['Authcknam']) != "undefined")
                                                r3job_cmd += "-s"+arr[i]['Stepcount']+" user="+arr[i]['Authcknam']+' ';
                                          }
                                       }
                                       r3job_cmd += "-flag type=exec";
                                       $('textarea#r3job_cmd').val(r3job_cmd);
                                    }
/*
["Stepcount"]=>   -s<Stepcount> type=A
["Progname"]=>  -s<Stepcount> report=<Progname>
["Btcvariant"]=>  -s<Stepcount> variant=<BTCVARIANT>
["Spras"]=> -s<Stepcount> lang=<Spras>
["Authcknam"]=> s<Stepcount> user=<Authcknam>

-flag type=exec

-s1 type=A -s1 report=/BAY0/GLBC_UPDATEUSERS_SNC -s1 variant='<USER>' -s1 lang=EN -s1 prnew -s1 user=HR-PROD-SNC
*/
                                    //$('select#r3job_class_select').val(result['Jobclass']);
                                    //$('input#r3job_cmd').val(result['Jobname']);
                                },
                                error: function(jqXHR, Status, errorThrown ) {
                                    alert('ajax ' +Status+ ': ' +errorThrown+'. url: '+ url + '?'+ req);
                                },
                                dataType: 'json'
                            });
                        }
                    </script>
                <div>
            <?php }
        } ?>
    </td>
</tr>
<tr>
<td><b>Job Type:</b></td>
<td> </td>
<td>
   <select name="r3job_type" id="r3job_type" onChange="r3type_change();" <?=($readonly?'disabled':'')?>>
      <option value="std" <? if (!isset($r3job_type) || $r3job_type == "std") echo " selected";?>>Standard</option>
      <option value="bwip" <? if (isset($r3job_type) && $r3job_type == "bwip") echo " selected"; ?>>BW InfoPackage</option>
      <option value="bwpc" <? if (isset($r3job_type) && $r3job_type == "bwpc") echo " selected"; ?>>BW Process Chain</option>
   </select>
</td>
</tr>
<tr>
<td><b>Job Name:</b></td>
<td> </td>
<td>
<input type="text" name="r3job_name" id="r3job_name" value="<?=(isset($r3job_name)?$r3job_name:'')?>" size="<?=$tws_config['JOB_MAXLENGTH']?>" maxlength="<?=$tws_config['JOB_MAXLENGTH']?>" <?=$readonly?>>
<? if ($display!='yes' && tws_have_sap_method() ){ ?>
<input type="button" name="job_list" value="List" onClick="tws_picker_open('sapjob_picker.php', 'fieldname=r3job_name&amp;jobid_field=r3job_id&amp;jobuser_field=r3job_user&amp;fieldvalue=' + document.contents.r3job_name.value + '&amp;job_type=' + document.contents.r3job_type.value + '&amp;cpux=' + document.contents.workstation.value);">
<? } ?>
</td>
</tr>
<tr id="r3job_id">
<td><b>Job ID:</b></td>
<td> </td>
<td><input type="text" name="r3job_id" id="r3job_id" size=16 maxlength=16  value="<?=(isset($r3job_id)?$r3job_id:'')?>" <?=$readonly?>></td>
</tr>
<tr id="r3job_user">
<td><b>User Name:</b></td>
<td> </td>
<td><input type="text" name="r3job_user" id="r3job_user" size=16 maxlength=16  value="<?=(isset($r3job_user)?$r3job_user:'')?>" <?=$readonly?>>
</td>
</tr>
<tr>
<td><b>Settings:</b></td>
<td> </td>
<td>
<label><input type="checkbox" name="r3job_trace" value="yes" <? if(isset($r3job_trace) && $r3job_trace=='yes') echo " checked";?> <?=$readonly?>>Trace</label>&nbsp;&nbsp;
<label><input type="checkbox" name="r3job_debug" value="yes" <? if(isset($r3job_debug) && $r3job_debug=='yes') echo " checked";?> <?=$readonly?>>Debug</label>&nbsp;&nbsp;
<label><input type="checkbox" name="r3job_diswa" value="yes" <? if(isset($r3job_diswa) && $r3job_diswa=='yes') echo " checked";?> <?=$readonly?>>Disable BDC Wait</label>&nbsp;&nbsp;
<label><input type="checkbox" name="r3job_immed" value="yes" <? if(isset($r3job_immed) && $r3job_immed=='yes') echo " checked";?> <?=$readonly?>>Launch Immediately</label>
</td>
</tr>
<tr>
<td><b>R/3 Command Line:</b></td>
<td> </td>
<td>
   <textarea name="r3job_cmd" id="r3job_cmd" cols=60 rows="5"><?=(isset($r3job_cmd)?$r3job_cmd:'')?></textarea>
</td>
</tr>
<tr id="r3job_spool">
<td><b>Job Spoollist:</b></td>
<td> </td>
<td>
   <select name="r3job_spool" <?=($readonly?'disabled':'')?>>
      <option value="" <? if (!isset($r3job_spool) || $r3job_spool == "") echo " selected"; ?>></option>
      <option value="ON" <? if (isset($r3job_spool) && $r3job_spool == "ON") echo " selected"; ?>>ON</option>
      <option value="OFF" <? if (isset($r3job_spool) && $r3job_spool == "OFF") echo " selected"; ?>>OFF</option>
   </select>
</td>
</tr>
<tr id="r3job_log">
<td><b>Job Log:</b></td>
<td> </td>
<td>
   <select name="r3job_log" <?=($readonly?'disabled':'')?>>
      <option value="" <? if (!isset($r3job_log) || $r3job_log == "") echo " selected"; ?>></option>
      <option value="ON" <? if (isset($r3job_log) && $r3job_log == "ON") echo " selected"; ?>>ON</option>
      <option value="OFF" <? if (isset($r3job_log) && $r3job_log == "OFF") echo " selected"; ?>>OFF</option>
   </select>
</td>
</tr>
<tr id="r3job_class">
<td><b>Job Class:</b></td>
<td> </td>
<td><?php
    if (defined('IWD_PROCMAN')) {
        $x=new wai_select('r3job_class', array('-'=>'', 'A'=>'A', 'B'=>'B', 'C'=>'C'));
        $x->set_id(strtoupper($action).'_DBJD_R3JOB_CLASS');//IWD_MOD_EDIT.CONTENTS.NEW_DBJD_R3JOB_CLASS
        $x->set_translate(FALSE);
        $x->set_selected(isset($r3job_class) ? $r3job_class : '');
        $x->set_disabled($readonly=='' ? FALSE : TRUE);
        $x->app_sec_init();
        $x->print_html();
    } else {
        ?>
        <select name="r3job_class" id="r3job_class_select" <?=($readonly?'disabled':'')?> >
            <option value="" <? if (!isset($r3job_class) || $r3job_class == "") echo " selected"; ?>></option>
            <option value="A" <? if (isset($r3job_class) && $r3job_class == "A") echo " selected"; ?>>A</option>
            <option value="B" <? if (isset($r3job_class) && $r3job_class == "B") echo " selected"; ?>>B</option>
            <option value="C" <? if (isset($r3job_class) && $r3job_class == "C") echo " selected"; ?>>C</option>
        </select>
        <?php
    }
?></td>
</tr>
<tr id="r3job_chlog">
<td><b>PChain Log:</b></td>
<td> </td>
<td>
   <select name="r3job_chlog" <?=($readonly?'disabled':'')?>>
      <option value="" <? if (!isset($r3job_chlog) || ($r3job_chlog == "")) echo " selected"; ?>></option>
      <option value="ON" <? if (isset($r3job_chlog) && ($r3job_chlog == "ON")) echo " selected"; ?>>ON</option>
      <option value="OFF" <? if (isset($r3job_chlog) && ($r3job_chlog == "OFF")) echo " selected"; ?>>OFF</option>
   </select>
</td>
</tr>
</table>


   <!-- Shadow Distributed -->

<table id="dshadow" class="add_job">
<tr>
<td colspan=3><h3>Remote Job</h3></td>
</tr>
<tr>
   <td width="180"><b>Workstation:</b></td>
   <td width=15> * </td>
   <td>
   <input type="text" name="dshadow_workstation" required="required" class="tws_name" value="<?=(isset($dshadow_workstation)?$dshadow_workstation:'')?>" size="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" maxlength="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" <?=$readonly?>>
   <? if ($display!='yes') { ?>
   <input type="button" name="dshadow_workstation_list" value="List" onClick="tws_picker_open('workstation_picker.php', 'fieldname=dshadow_workstation&amp;includeclasses=no&amp;fieldvalue=' + document.contents.dshadow_workstation.value);" >
   <? } ?>
   </td>
</tr>
<tr><td><b>Jobstream:</b></td>
   <td> * </td>
   <td>
   <input type="text" name="dshadow_jobstream" required="required" class="tws_name" value="<?=(isset($dshadow_jobstream)?$dshadow_jobstream:'')?>" size="<?=($tws_config['JOBSTREAM_MAXLENGTH']+$tws_config['SCHEDID_MAXLENGTH']+1)?>" maxlength="<?=($tws_config['JOBSTREAM_MAXLENGTH']+$tws_config['SCHEDID_MAXLENGTH']+1)?>" <?=$readonly?>>
   <? if ($display!='yes') { ?>
   <input type="button" name="dshadow_jobstream_list"  value="List" onClick="tws_picker_open('jobstream_picker.php', 'fieldname=dshadow_jobstream&amp;fieldvalue=' + document.contents.dshadow_jobstream.value + '&amp;cpux=' + document.contents.dshadow_workstation.value);">
   <? } ?>
   </td>
</tr>
<tr>
   <td><b>Job:</b></td>
   <td> * </td>
   <td>
   <input type="text" name="dshadow_job" required="required" class="tws_name" value="<?=(isset($dshadow_job)?$dshadow_job:'')?>" size="<?=$tws_config['JOB_MAXLENGTH']?>" maxlength="<?=$tws_config['JOB_MAXLENGTH']?>" <?=$readonly?>>
   <? if ($display!='yes') { ?>
   <input type="button" name="dshadow_job_list"  value="List" class="list" onClick="tws_picker_open('job_picker.php', 'fieldname=dshadow_job&fieldvalue=' + document.contents.dshadow_job.value + '&cpux=' + document.contents.dshadow_workstation.value + '&schedulex==' + document.contents.dshadow_jobstream.value);" >
   <? } ?>
   </td>
</tr>
<tr>
<td> </td>
<td> </td>
<td>
   <? if( $exitcodemap == 'COMPLETE_IF_BIND_FAILS')
      $dshadow_complete = "YES";
   ?>
 <label><input type="checkbox" name="dshadow_complete" value="YES" <? if($dshadow_complete == "YES") echo " checked";?> <?=$readonly?>>Complete if bind fails</label>
</td>
</tr>
</table>


   <!-- Shadow ZOS -->
<table id="zshadow" class="add_job">
<tr><td colspan=3><h3>Remote Job</h3></td></tr>
<tr>
   <td width="180"><b>Jobstream:</b></td>
   <td width=15> * </td>
   <td><input type="text" name="zshadow_jobstream" required="required" class="tws_name" value="<?=(isset($zshadow_jobstream)?$zshadow_jobstream:'')?>" size="<?=($tws_config['JOBSTREAM_MAXLENGTH']+$tws_config['SCHEDID_MAXLENGTH']+1)?>" maxlength="<?=($tws_config['JOBSTREAM_MAXLENGTH']+$tws_config['SCHEDID_MAXLENGTH']+1)?>" <?=$readonly?>></td>
</tr>
<tr>
   <td><b>Job Number:</b></td>
   <td> * </td>
   <td><input type="text" name="zshadow_job" required="required" class="tws_num" value="<?=(isset($zshadow_job)?$zshadow_job:'')?>" <?=$readonly?>></td>
</tr>
<tr>
<td> </td>
<td> </td>
<td>
   <? if( $exitcodemap == 'COMPLETE_IF_BIND_FAILS') $zshadow_complete = "YES"; ?>
 <label><input type="checkbox" name="zshadow_complete" value="YES" <? if($zshadow_complete == "YES") echo " checked";?> <?=$readonly?>>Complete if bind fails</label>
</td>
</tr>
</table>


   <!-- FILETRANSFER -->
<table id="filetransfer" class="add_job">
<tr><td colspan=3><h3>File Transfer</h3></td></tr>
<tr>
   <td width="180"> </td>
   <td width=15></td>
   <td>
   <select name="ft_type" <?=$readonly?'disabled':''?>>
      <option value="UPLOAD" <? if (!isset($ft_type) || $ft_type=="UPLOAD") echo " selected";?> >Upload</option>
      <option value="DOWNLOAD"<? if (isset($ft_type) && $ft_type=="DOWNLOAD") echo " selected";?> >Download</option>
   </select>
   </td>
</tr>
<tr><td><b>Protocol:</b></td>
   <td></td>
   <td>
   <select name="ft_protocol" <?=$readonly?'disabled':''?>>
      <option value="FTP" <? if (!isset($ft_protocol) || $ft_protocol=="UPLOAD") echo " selected";?> >FTP</option>
      <option value="WINDOWS"<? if (isset($ft_protocol) && $ft_protocol=="WINDOWS") echo " selected";?> >Windows</option>
      <option value="SSH"<? if (isset($ft_protocol) && $ft_protocol=="SSH") echo " selected";?> >SSH</option>
   </select>
   </td>
</tr>
<tr>
   <td><b>Server:</b></td>
   <td>*</td>
   <td><input type="text" name="ft_server" required="required" size="40" value="<?=(isset($ft_server)?$ft_server:'')?>" <?=$readonly?>>
   </td>
</tr>
<tr>
   <td><b>Remote file:</b></td>
   <td>*</td>
   <td><input type="text" name="ft_remfile" required="required" class="tws_file" size="40" value="<?=(isset($ft_remfile)?$ft_remfile:'')?>" <?=$readonly?>></td>
</tr>
<tr>
   <td><b>Local file:</b></td>
   <td>*</td>
   <td><input type="text" name="ft_locfile" required="required" class="tws_file" size="40" value="<?=(isset($ft_locfile)?$ft_locfile:'')?>" <?=$readonly?>></td>
</tr>
<tr><td><b>Transfer mode:</b></td>
   <td></td>
   <td>
   <select name="ft_mode" id="ft_mode" onchange="change_ft_mode();" <?=$readonly?'disabled':''?>>
      <option value="binary" <? if (!isset($ft_mode) || $ft_mode=="binary") echo " selected";?> >Binary</option>
      <option value="ascii"<? if (isset($ft_mode) && $ft_mode=="ascii") echo " selected";?> >Text</option>
   </select>
   </td>
</tr>
<tr id="ft_codepage">
   <td><b>Convert codepage:</b></td>
   <td> </td>
   <td>
      <table><tr><td>Remote codepage:</td><td>Local codepage:</td></tr>
         <tr>
         <td><input type="text" name="rem_codepage" value="<?=(isset($rem_codepage)?$rem_codepage:'')?>" <?=$readonly?>></td>
         <td><input type="text" name="loc_codepage" value="<?=(isset($loc_codepage)?$loc_codepage:'')?>" <?=$readonly?>></td>
         </tr>
      </table>
   </td>
</tr>
</table>


   <!-- DATABASE -->

<table id="database" class="add_job">
<tr>
   <td valign="top" width=180><b>SQL Query:</b></td>
   <td valign="top" width=15> * </td>
   <td>
<textarea name="db_query" cols="80" rows="15" wrap="soft" <?=$readonly?> >
   <? if(isset($db_query)) echo $db_query; ?>
</textarea>
   </td>
</tr>
<tr><td colspan=3><h3>Database Connection</h3></td></tr>
<tr>
   <td><b>DBMS:</b></td>
   <td> </td>
   <td>
   <select name="db_dbms" id="db_dbms" onChange="db_dbms_change();" <?=$readonly?'disabled':''?>>
      <option value="db2" <? if (!isset($db_dbms) || $db_dbms == "db2") echo " selected";?> >DB2</option>
      <option value="oracle"<? if (isset($db_dbms) && $db_dbms == "oracle") echo " selected";?> >Oracle</option>
      <option value="mssql"<? if (isset($db_dbms) && $db_dbms == "mssql") echo " selected";?> >MS SQL</option>
      <option value="JDBC"<? if (isset($db_dbms) && $db_dbms == 'JDBC') echo " selected";?> >JDBC</option>
   </select>
   </td>
</tr>
<tr id="db_server">
   <td><b>Server:</b></td>
   <td> * </td>
   <td><input type="text" name="db_server" required="required" value="<?=(isset($db_server)?$db_server:'')?>" <?=$readonly?> ></td>
</tr>
<tr id="db_port">
   <td><b>Port:</b></td>
   <td> * </td>
   <td><input type="text" name="db_port" required="required" class="tws_num" value="<?=(isset($db_port)?$db_port:'')?>" <?=$readonly?>></td>
</tr>
<tr id="db_name">
   <td><b>Database name:</b></td>
   <td> * </td>
   <td><input type="text" name="db_name" required="required" value="<?=(isset($db_name)?$db_name:'')?>" <?=$readonly?>></td>
</tr>

<tr id="jdbc_driver">
   <td><b>JDBC driver class:</b></td>
   <td> * </td>
   <td><input type="text" name="db_jdbc_driver" required="required" size="40" value="<?=(isset($db_jdbc_driver)?$db_jdbc_driver:'')?>" <?=$readonly?>></td>
</tr>
<tr id="jdbc_string">
   <td><b>JDBC connection string:</b></td>
   <td> * </td>
   <td><input type="text" name="db_jdbc_string" required="required" size="40" value="<?=(isset($db_jdbc_string)?$db_jdbc_string:'')?>" <?=$readonly?>></td>
</tr>
<tr>
   <td><b>JDBC jar class path:</b></td>
   <td> </td>
   <td><input type="text" name="db_jar_path" size="40" value="<?=(isset($db_jar_path)?$db_jar_path:'')?>" <?=$readonly?>></td>
</tr>
</table>

   <!-- J2EE -->

<table id="j2ee" class="add_job">
<tr><td colspan=3><h3>JMS</h3></td></tr>

<tr><td width="180"><b>Operation:</b></td>
   <td width=15> </td>
   <td>
   <select name="j2ee_operation" id="j2ee_operation" onChange="j2ee_operation_change();" <?=$readonly?'disabled':''?>>
      <option value="send" <? if(!isset($j2ee_operation) || $j2ee_operation=="send") echo " selected";?> >Send</option>
      <option value="receive"<? if(isset($j2ee_operation) && $j2ee_operation=="receive") echo " selected";?> >Receive</option>
   </select>
   </td>
</tr>

<tr id="j2ee_message">
   <td valign="top"><b>Message:</b></td>
   <td valign="top"> * </td>
   <td><textarea name="j2ee_message" cols="80" rows="15" wrap="soft" <?=$readonly?> >
      <? if (isset($j2ee_message)) echo $j2ee_message; ?>
      </textarea>
   </td>
</tr>
<tr id="j2ee_timeout">
   <td><b>Timeout:</b></td>
   <td> </td>
   <td><input type="text" name="j2ee_timeout" class="tws_num" value="<?=(isset($j2ee_timeout)?$j2ee_timeout:'')?>" <?=$readonly?>></td>
</tr>
<tr>
   <td><b>Connection Factory:</b></td>
   <td> * </td>
   <td><input type="text" name="j2ee_factory" size='40' required="required" value="<?=(isset($j2ee_factory)?$j2ee_factory:'')?>" <?=$readonly?>></td>
</tr>
<tr>
   <td><b>Destination:</b></td>
   <td> * </td>
   <td><input type="text" name="j2ee_destination" size='40' required="required" value="<?=(isset($j2ee_destination)?$j2ee_destination:'')?>" <?=$readonly?>></td>
</tr>
<tr>
   <td><b>Connection URL:</b></td>
   <td> </td>
   <td><input type="text" name="j2ee_url" size='60' value="<?(isset($j2ee_url)?$j2ee_url:'')?>" <?=$readonly?>></td>
</tr>
</table>


   <!-- JAVA -->

<table id="java" class="add_job">
<tr>
   <td width="180"><b>Jar Path:</b></td>
   <td width=15> </td>
   <td><input type="text" name="java_path" value="<?=(isset($java_path)?$java_path:'')?>" <?=$readonly?>></td>
</tr>
<tr>
   <td><b>Class Name to run:</b></td>
   <td>*</td>
   <td><input type="text" name="java_class" required="required" value="<?=(isset($java_class)?$java_class:'')?>" <?=$readonly?>></td>
</tr>
</table>


   <!-- IBM -->

<table id="ibm" class="add_job">
<tr>
   <td width="180"><b>Command:</b></td>
   <td width=15> * </td>
   <td><input type="text" name="ibm_command" required="required" size="60" value="<?=(isset($ibm_command)?$ibm_command:'')?>" <?=$readonly?>></td>
</tr>
</table>

   <!-- XA JOB -->

<table id="xa" class="add_job">
<tr><td  colspan=3>&nbsp;</td>
</tr>
<tr><td width="180"><b>Access Method:</b></td>
   <td width=15> * </td>
   <td>
   <input type="text" name="xa_method" required="required" size="20" maxlength="16" value="<?=(isset($xa_method)?$xa_method:'')?>" <?=$readonly?>>
   <? if ($display!='yes'){ ?>
   <input type="button" name="xa_method_list" value="List" onClick="tws_picker_open('method_picker.php', 'fieldname=xa_method');">
   <? } ?>
   </td>
</tr>
<tr><td><b>Option file:</b></td>
   <td> * </td>
   <td>
   <input type="text" name="xa_target" required="required" value="<?=(isset($xa_target)?$xa_target:'')?>" <?=$readonly?>>
   <? if ($display!='yes'){ ?>
   <input type="button" name="xa_optfile_list" value="List" onClick="tws_picker_open('optfile_picker.php', 'fieldname=xa_target&amp;method=' + document.contents.xa_method.value);"/>
   <? } ?>
   </td>
</tr>
<tr><td><b>Task String:</b></td>
   <td> * </td>
   <td><input type="text" name="xa_string" required="required" size="60" value="<?=(isset($xa_string)?$xa_string:'')?>" <?=$readonly?>></td>
</tr>
<tr><td><b>Step:</b></td>
   <td> </td>
   <td><input type="text" name="xa_step" value="<?=(isset($xa_step)?$xa_step:'')?>" <?=$readonly?>></td>
</tr>
</table>

 <!-- JCL -->

<table id="jcl" class="add_job">
	<tr>
		<td colspan=3><h3>JCL</h3></td>
	</tr>
	<tr>
		<td colspan=3><label><input onclick=
		"document.getElementById('jcl_dataset').disabled=false;
		document.getElementById('jcl_member').disabled=false;
		document.getElementById('jcl_member').required=true;
		document.getElementById('jcl_dataset').removeAttribute('readonly');
		document.getElementById('jcl_member').removeAttribute('readonly');
		document.getElementById('jcl_definition').disabled=true;
		document.getElementById('jcl_definition').readonly = true;
		document.getElementById('jcl_created').value='byReference';"
		type="radio" id="jcl_by_reference" name="jcl_radio_select" <?if($jcl_created=='byReference') echo "checked"?> disabled><b>by reference</b></label>
		</td>

	</tr>
	<tr>
		<td colspan=3><br/></td>
	</tr>
	<tr>
		<td width="180"><b>Dataset name:</b></td>
		<td width="15"></td>
		<td><input type="text" id='jcl_dataset' name="jcl_dataset" maxlength="44" size="40" value="<?=(isset($jcl_dataset)?$jcl_dataset:'')?>" readonly disabled></td>

	</tr>
	<tr>
		<td><b>Member name:</b></td>
		<td>*</td>
		<td><input type="text" id='jcl_member' name="jcl_member" maxlength="8" size="8" value="<?=(isset($jcl_member)?$jcl_member:'')?>" <?if($jcl_created=='byReference') echo "required"?> readonly disabled></td>
	</tr>
	<tr>
		<td><br/></td>
	</tr>
	<tr>
		<td><br/></td>
	</tr>
	<tr>
		<td colspan=3><label><input onclick=
		"document.getElementById('jcl_dataset').disabled=true;
		 document.getElementById('jcl_member').required=false;
		 document.getElementById('jcl_member').removeAttribute('class');
		 document.getElementById('jcl_member').disabled=true;
		 document.getElementById('jcl_definition').disabled=false;
		 document.getElementById('jcl_definition').readOnly=false;
		 document.getElementById('jcl_created').value='byDefinition';"
		 type="radio" id="jcl_by_definition" name="jcl_radio_select" <?if($jcl_created=='byDefinition') echo "checked"?> disabled><b>by definition</b></label>
		</td>
	</tr>
	<tr>
		<td><br/></td>
	</tr>
	<tr>
		<td valign="top"><b>JCL definition:</b></td>
		<td valign="top">*</td>
		<td><textarea name="jcl_definition" id="jcl_definition" cols="80" rows="15" wrap="soft" disabled readonly><?=(isset($jcl_definition)?$jcl_definition:'')?></textarea></td>
	</tr>
	<tr>
		<td><input type="hidden" id="jcl_created" name="jcl_created" value="<?echo $jcl_created?>"/></td>
	</tr>
</table>


   <!-- ARGUMENTS -->

<table id="arguments" class="add_job">
<tr>
<td width="180"><b>Arguments:</b></td>
<td width=15></td>
<td>
   <table><tr><td class="arguments">
   <input type="text" name="arguments[0]" value="<?=(isset($arguments[0])?$arguments[0]:'')?>" <?=$readonly?>>
   <?
   if(isset($arguments)) {
      for ($i=1; $i<count($arguments); $i++) { ?>
      <input type="text" name="arguments[<?=$i?>]" value="<?=$arguments[$i]?>" <?=$readonly?>>
   <? }
   } ?>
   </td>
   <td>
   <? if ($display!='yes'){?>
   <input type="button" value="+" onclick="insertArgument();">
   <? } ?>
   </td></tr>
   </table>
</td>
</tr>
</table>

   <!-- VARIABLES / PARAMETERS -->

<table id="variables" class="add_job">
<tr>
<td width="180" valign="top"><b>
<? if($task_type == 'java') echo 'Parameters:';
   else echo 'Variables:';
if(empty($var_name)) {$var_name[0]=''; $var_val[0]='';}
?></b>
</td>
<td width=15></td>
<td>
   <table class="variables">
      <tr><td>name</td><td>value</td></tr>
      <tr><td>
         <input type="text" name="var_name[0]" class="tws_alfanum" value="<?=htmlspecialchars($var_name[0])?>" <?=$readonly?>>
      </td><td>
         <input type="text" name="var_val[0]" value="<?=htmlspecialchars($var_val[0])?>" <?=$readonly?>>
      </td><td>
         <? if ($display!='yes'){ ?>
         <input type="button" value="+" onclick="insertVariables();">
         <? } ?>
   </td></tr>
   <? for($i=1; $i<count($var_name); $i++){?>
         <tr><td>
         <input type="text" name="var_name[<?=$i?>]" class="tws_alfanum" value="<?=$var_name[$i]?>" <?=$readonly?>>
         </td><td>
         <input type="text" name="var_val[<?=$i?>]" value="<?=$var_val[$i]?>" <?=$readonly?>>
         </td></tr>
   <? } ?>
   </table>
</td>
</tr>
</table>


   <!-- MATCHING -->

<table id="matching" class="add_job">
<tr><td  colspan=3>&nbsp;</td></tr>
<tr><td width="180"><b>Matching</b></td>
   <td width=15></td>
   <td>
<table border=0 cellspacing=0 cellpadding=0 class="transparent">
   <tr><td>
   <select name="matching" id="matching_sel" onchange="showMatch();" <?=$readonly?'disabled':''?>>
      <option value="SAMEDAY" <? if (!isset($matching) || $matching=="SAMEDAY") echo " selected";?> >Same day</option>
      <option value="PREVIOUS"<? if (isset($matching) && $matching=="PREVIOUS") echo " selected";?> >Previous day</option>
      <option value="RELATIVE"<? if (isset($matching) && $matching=="RELATIVE") echo " selected";?> >Relative</option>
      <option value="ABSOLUTE"<? if (isset($matching) && $matching=="ABSOLUTE") echo " selected";?> >Absolute</option>
   </select>&nbsp;&nbsp;
   </td>
   <td>
      <div id="relative" style="display:none;">
      from <select name="relative_from" <?=$readonly?'disabled':''?>>
         <option value="+"<? if (!isset($relative_from) || $relative_from == "+") echo " selected";?> >+</option>
         <option value="-"<? if (isset($relative_from) && $relative_from == "-") echo " selected";?> >-</option>
      </select>
      <input type="text" name="relative_fromhour" class="tws_hour" size=2 maxlength=2 <?
         if (isset($relative_fromhour) && $relative_fromhour >=0) echo " value='$relative_fromhour'";?>>&nbsp;:
      <input type="text" name="relative_frommin" class="tws_minute" size=2 maxlength=2 <?
         if (isset($relative_frommin) && $relative_frommin >=0) echo " value='$relative_frommin'"; ?>>&nbsp;&nbsp;
      to <select name="relative_to" <?=$readonly?'disabled':''?>>
         <option value="+" <? if (!isset($relative_to) || $relative_to == "+") echo " selected";?> >+</option>
         <option value="-" <? if (isset($relative_to) && $relative_to == "-") echo " selected";?> >-</option>
      </select>
      <input type="text" name="relative_tohour" class="tws_hour" size=2 maxlength=2 <?
         if (isset($relative_tohour) && $relative_tohour >=0) echo " value='$relative_tohour'";?>>&nbsp;:
      <input type="text" name="relative_tomin" class="tws_minute" size=2 maxlength=2 <?
         if (isset($relative_tomin) && $relative_tomin >=0) echo " value='$relative_tomin'";?>>
      </div>

      <div id="absolute" style="display:none;">
      from <input type="text" name="absolute_fromhour" class="tws_hour" size=2 maxlength=2 <?
         if (isset($absolute_fromhour) && $absolute_fromhour >=0) echo " value='$absolute_fromhour'";?>>&nbsp;:
      <input type="text" name="absolute_frommin" class="tws_minute" size=2 maxlength=2 <?
         if (isset($absolute_frommin) && $absolute_frommin >=0) echo " value='$absolute_frommin'";?>>
      <select name="absolute_from" <?=$readonly?'disabled':''?>>
         <option value="+"<? if (!isset($absolute_from) || $absolute_from == "+") echo " selected";?> >+</option>
         <option value="-"<? if (isset($absolute_from) && $absolute_from == "-") echo " selected";?> >-</option>
      </select>
      <input type="text" name="absolute_fromdays" class="tws_num" size=2 maxlength=5 <?
         if (isset($absolute_fromdays) && $absolute_fromdays >0) echo " value='$absolute_fromdays'";?>>&nbsp;days
      to <input type="text" name="absolute_tohour" class="tws_hour" size=2 maxlength=2 <?
         if (isset($absolute_tohour) && $absolute_tohour >0) echo " value='$absolute_tohour'";?> >&nbsp;:
      <input type="text" name="absolute_tomin" class="tws_minute" size=2 maxlength=2 <?
         if (isset($absolute_tomin) && $absolute_tomin >=0) echo " value='$absolute_tomin'";?> >
      <select name="absolute_to" <?=$readonly?'disabled':''?>>
         <option value="+"<? if (!isset($absolute_to) || $absolute_to == "+") echo " selected";?> >+</option>
         <option value="-"<? if (isset($absolute_to) && $absolute_to == "-") echo " selected";?> >-</option>
      </select>
      <input type="text" name="absolute_todays" class="tws_num" size=2 maxlength=5 <?
         if (isset($absolute_todays) && $absolute_todays >0) echo " value='$absolute_todays'";?> >&nbsp;days
      </div>
   </td>
   </tr>
</table>
   </td>
</tr>

</table>


   <!-- CREDENTIALS -->

<table id="credentials" class="add_job">
<tr><td colspan=3><h3>Credentials</h3></td></tr>
<tr>
   <td width="180"><b>User:</b></td>
   <td width=15></td>
   <td><input type="text" name="user" value="<?=(isset($user)?$user:'')?>" <?=$readonly?>>
   </td>
</tr>
<tr><td><b>Password:</b></td>
   <td></td>
   <td>
   <? if (isset($password) && strpos($password, '{aes}')!== FALSE ){  ?>
      <input type="password" name="passwordx" autocomplete='off' value="******" <?=$readonly?>>
      <input type="hidden" name="password" value="<?=$password?>">
   <? } else { ?>
   <input type="password" name="password" autocomplete='off' value="<?=(isset($password)?$password:'')?>" <?=$readonly?>>
   <? } ?>
   </td>
</tr>
</table>


   <!-- FILETRANSFER CREDENTIALS -->

<table id="ftp_credentials" class="add_job">
<tr>
<td  colspan=3>
<h3>Remote Credentials</h3>
</td>
</tr>
<tr><td width="180"><b>User name:</b></td>
   <td width=15>*</td>
   <td><input type="text" name="rem_user" required="required" value="<?=(isset($rem_user)?$rem_user:'')?>" <?=$readonly?>></td>
</tr>
<tr><td><b>Password:</b></td>
   <td>*</td>
   <td>
   <? if (isset($rem_password) && strpos($rem_password, '{aes}')!== FALSE){ ?>
   <input type="password" name="rem_passwordx" required="required" autocomplete='off' value="******" <?=$readonly?>>
   <input type="hidden" name="rem_password" value="<?=$rem_password?>">
   <? } else { ?>
   <input type="password" name="rem_password" required="required" autocomplete='off' value="<?=(isset($rem_password)?$rem_password:'')?>" <?=$readonly?>>
   <? } ?>
   </td>
</tr>
<tr><td colspan=3><h3>Local Credentials</h3></td></tr>
<tr>
   <td><b>User name:</b></td>
   <td>*</td>
   <td><input type="text" name="loc_user" required="required" value="<?=(isset($loc_user)?$loc_user:'')?>" <?=$readonly?>></td>
</tr>
<tr>
   <td><b>Password:</b></td>
   <td>*</td>
   <td>
   <? if (isset($loc_password) && strpos($loc_password, '{aes}')!== FALSE){ ?>
   <input type="password" name="loc_passwordx" required="required" autocomplete='off' value="******" <?=$readonly?>>
   <input type="hidden" name="loc_password" value="<?=$loc_password?>">
   <? } else { ?>
   <input type="password" name="loc_password" required="required" autocomplete='off' value="<?=(isset($loc_password)?$loc_password:'')?>" <?=$readonly?>>
   <? } ?>
   </td>
</tr>
</table>


   <!-- ENVIRONMENT -->

<table id="environment" class="add_job">
<tr><td colspan=3><h3>Environment</h3></td></tr>
<tr id="stdin">
   <td width="180"><b>Standard Input:</b></td>
   <td width=15></td>
   <td><input type="text" name="stdin" class="tws_file" value="<?=(isset($stdin)?$stdin:'')?>" <?=$readonly?>></td>
</tr>
<tr>
   <td><b>Standard Output:</b></td>
   <td></td>
   <td><input type="text" name="stdout" class="tws_file" value="<?=(isset($stdout)?$stdout:'')?>" <?=$readonly?>></td>
</tr>
<tr>
   <td><b>Standard Error:</b></td>
   <td></td>
   <td><input type="text" name="stderr" class="tws_file" value="<?=(isset($stderr)?$stderr:'')?>" <?=$readonly?>></td>
</tr>
</table>




   <!-- Return Code Mapping -->

<h3>Return Code Mapping</h3>
<table id="codemap" class="add_job">
<?
if($tws_config['cpuinfo']['version']>='9.3'){
   if(empty($joc_mapping_expression)){
      if(!empty($exitcodemap)){
         $joc_name[0] = 'CONDSUCC';
         $joc_mapping_expression[0]=$exitcodemap;
         $joc_succ_condition[0]='Y';
      }
      else{
         $joc_name[0] = '';
         $joc_mapping_expression[0]='';
         $joc_succ_condition[0]='N';
      }
   }
foreach($joc_name as $i=>$name){
?>
<tr>
   <td width=180 nowrap>
      <b>Condition Name:</b><br>
      <b>Condition Value:</b>
   </td>
   <td width=15> </td>
   <td>
      <input type="text" name="joc_name[<?=$i?>]" size=25 maxlength=25 value="<?=$joc_name[$i]?>" <?=$readonly?>>
      <input type="checkbox" name="joc_succ_condition[<?=$i?>]" value="Y" <?=($joc_succ_condition[$i]=='Y'? 'checked' : '')?>> Successful<br>
      <input type="text" name="joc_mapping_expression[<?=$i?>]" size="50" maxlength="256" class="tws_codemap" value="<?=$joc_mapping_expression[$i]?>" <?=$readonly?>>&nbsp;&nbsp;
      <? if($i==0){ ?>
      </td>
      <td>
      <input  type="button" class="button plusbutton" name="AND" title="AND" value="+" onclick="AddRow(this);">
      </td>
      <? } else echo"<td></td>";
      ?>
</tr>
<? }
} else { ?>
<tr>
   <td width=180 nowrap> </td>
   <td width=15> </td>
   <td><input type="text" name="exitcodemap" size=50 maxlength=256 value="<?=(isset($exitcodemap)?$exitcodemap:'')?>" <?=$readonly?>></td>
</tr>
<? } ?>
</table>


   <!-- RECOVERY OPTIONS -->

<table id="recovery" class="add_job">
<tr><td colspan=3><h3>Recovery Options</h3></td></tr>
<tr>
<td width=180><b>Action:</b></td>
<td width=15></td>
<td>
   <select name="recovery_option" id="recovery_option" <?=($readonly?'disabled':'')?> onchange="recovery_changed()" >
      <option value="STOP" <? if (!isset($recovery_option) || $ft_protocol=="STOP") echo " selected";?> >Stop</option>
      <option value="CONTINUE"<? if (isset($recovery_option) && $recovery_option=="CONTINUE") echo " selected";?> >Continue</option>
      <option value="RERUN"<? if (isset($recovery_option) && $recovery_option=="RERUN") echo " selected";?> >Rerun</option>
   </select>
<? if($tws_config['cpuinfo']['version']>='9.4'){ ?>
   <span id="rerun_options" style="display:none">
      Retry after (hh:mm):
      <input type="text" name="recovery_repeat_hour" size="2" value="<?=(isset($recovery_repeat_hour)?$recovery_repeat_hour:'')?>">:
      <input type="text" name="recovery_repeat_minute" size="2" value="<?=(isset($recovery_repeat_minute)?$recovery_repeat_minute:'')?>">
      Number of attempts: <input type="text" name="recovery_repeat_occurrences" size="2" value="<?=(isset($recovery_repeat_occurrences)?$recovery_repeat_occurrences:'')?>">
   </span>
 <? } ?>
</td>
</tr>
<tr id="tr_recovery_prompt"><td ><b>Recovery Prompt:</b></td>
<td></td>
<td><input type="text" name="recovery_prompt" size=50 maxlength=64 value="<?=(isset($recovery_prompt)?$recovery_prompt:'')?>" <?=$readonly?>>
</td>
</tr>
<tr><td nowrap><b>Recovery Job:</b></td>
<td></td>
<td nowrap>
<table style="border-collapse:collapse;"><tr><td>Workstation:</td><td>Job:</td></tr>
<tr><td>
<input type="text" name="recovery_workstation" class="tws_name" style="width:15em;" maxlength="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" value="<?=(isset($recovery_workstation)?$recovery_workstation:'')?>" <?=$readonly?>>
<? if ($display!='yes'){ ?>
<input type="button" name="workstation_list" onClick="tws_picker_open('workstation_picker.php', 'fieldname=recovery_workstation&amp;fieldvalue=' + document.contents.recovery_workstation.value);" value="List">
<? } ?>
</td><td>
<input type="text" name="recovery_job" class="tws_name" value="<?=(isset($recovery_job)?$recovery_job:'')?>" size="<?=$tws_config['JOB_MAXLENGTH']?>" maxlength="<?=$tws_config['JOB_MAXLENGTH']?>" <?=$readonly?>>
<? if ($display!='yes'){ ?>
<input type="button" name="job_list" onClick="tws_picker_open('job_picker.php', 'fieldname=recovery_job&amp;fieldvalue=' + document.contents.recovery_job.value + '&amp;cpux=' + document.contents.recovery_workstation.value);" value="List">
<? } ?>
</td></tr></table>
</td>
</tr>
<tr id="same_ws"><td></td><td colspan="2">
<? /*
   if($tws_config['cpuinfo']['version']>'9.4'){
      echo "<label><input type='checkbox' value='Y' name='recovery_same_workstation' id='recovery_same_workstation'>"
      ."Run on the same workstation (applicable to pool and dynamic pool workstations only)</label>";
      if(isset($recovery_same_workstation) && $recovery_same_workstation=='Y'){
?>
         <script>
         // set same_workstation checkbox
         $('input#recovery_same_workstation').attr('checked', true);
         </script>
<?    }

} */?>

</td><tr>
</table>

<script>
   function recovery_changed(){
      var myval = $('select#recovery_option option:selected').val();
      $('tr#tr_recovery_prompt').show();
      $('tr#tr_recovery_prompt input').prop('disabled', false);

      if(myval == 'RERUN'){
         $('span#rerun_options').show();
         $('span#rerun_options input').prop('disabled', false);
      }
      else{
         $('span#rerun_options').hide();
         $('span#rerun_options input').prop('disabled', true);
      }
   }
   recovery_changed();
</script>

<script type="text/javascript">
   sec_interactive_color=document.getElementById('sec_interactive').style.color;
   type_change(document.getElementById('sel_task_type'));
</script>
<?
}

/*  tws_show_jobstream_form  */
function tws_show_jobstream_form($values, $action){
   global $tws_types, $tws_config;

   $action = strtolower($action);
   tws_specialchars($values);

if (defined('IWD_PROCMAN')) {
?>
   <script type="text/javascript" src="/jquery/jquery.js"></script>
   <script type="text/javascript" src="/jquery/jquery-ui.js"></script>
   <script type="text/javascript" src="/tws_js_functions.js"></script>
   <link rel="stylesheet" type="text/css" href="/jquery/jquery-ui_default.css"/>
   <link rel="stylesheet" type="text/css" href="/css/wai_default.css"/>
<? } ?>
<style type="text/css">
td.rc_inc {
    background-color:#0F0;
}
td.red{
   color:red;
}
</style>
<script type="text/javascript" src="tws_insert_row.js"></script>
<?
   include("tws_add_jobstream_js.php");   // contain all JS functions

   if ($action=='display') {
      $readonly = 'readonly';
      $disabled = 'disabled';
      $display = 'yes';
      echo "<div id='picker_holder'></div>";
   } else {
      $readonly  = '';
      $disabled = '';
      $display = '';
      echo '<script type="text/javascript" src="/tws_js_validators.js"></script>'."\n";
   }

   //ERR18606: IWD_PROCMAN - all TWS dates stored in the YYYY-MM-DD ISO format
   if (defined('IWD_PROCMAN')) {
      empty($values['validfrom']) || $values['validfrom']=tws_iso_to_userdate($values['validfrom'], NULL, TRUE);
      empty($values['validto']) || $values['validto']=tws_iso_to_userdate($values['validto'], NULL, TRUE);
      $i=0;
      while (isset($values['rc_type'][$i])) {
         empty($values['rc_validfrom'][$i]) || $values['rc_validfrom'][$i]=tws_iso_to_userdate($values['rc_validfrom'][$i], NULL, TRUE);
         empty($values['rc_validto'][$i]) || $values['rc_validto'][$i]=tws_iso_to_userdate($values['rc_validto'][$i], NULL, TRUE);
         $s=0;
         while (isset($values['date_day'][$i][$s])) {
            $values['date_day'][$i][$s]=tws_iso_to_userdate($values['date_day'][$i][$s], NULL, TRUE);
            $s++;
         }
         $i++;
      }
   }

   foreach($values as $key=>$value)
      $$key = $value;

   // if (is_array($run_data['rc'])) foreach ($run_data['rc'] as $key => $value) $$key=$value; unused 'rc' index
   if (is_array($dep_stream))  foreach($dep_stream as $key => $value) $$key=$value;
   if (is_array($dep_job)) foreach($dep_job as $key => $value) $$key = $value;
   if (is_array($dep_net)) foreach($dep_net as $key => $value) $$key = $value;
   if (is_array($dep_res)) foreach ($dep_res as $key => $value) $$key = $value;
   if (is_array($joblist)) foreach ($joblist as $key => $value) $$key=$value;
   if (is_array($job_dep_net)) foreach ($job_dep_net as $key => $value) $$key=$value;
   if (is_array($job_js_deps)) foreach ($job_js_deps as $key => $value) $$key=$value;
   if (is_array($job_job_deps)) foreach ($job_job_deps as $key => $value) $$key=$value;
   if (is_array($job_res)) foreach ($job_res as $key => $value) $$key=$value;
?>
<!-- *****************  Tabs  ***************** -->
<div id='tabs'>
   <ul>
      <li><a href='#general'>General Options</a></li>
      <li><a href='#calendar'>On/Except/Freedays</a></li>
      <li><a href='#dependencies'>Dependencies</a></li>
      <? if($tws_config['cpuinfo']['version']>'9.4'){ ?>
         <li><a href='#startcond_div'>Start Conditions</a></li>
      <? } ?>
      <li><a href='#jobs'>Job Instances</a></li>
   </ul>

<!--  GENERAL  -->

<div id='general'>
<table border=0 cellspacing=0 class="standard transparent">

<tr><td><b>Workstation: </b></td>
<td>
   <input type="text" name="workstation" class="tws_name" required="required" size="60" maxlength="200" value="<?=$workstation_folder.$workstation?>" <? if($action=='modify') echo "readonly" ?>> (*)
<? if($action != 'modify' && $action != 'display'){ ?>
   <input type="button" name="workstation_list" value="List" onClick="tws_picker_open('workstation_picker.php', 'includeclasses=yes&amp;fieldname=workstation&amp;fieldvalue=' + document.contents.workstation.value);">
<? } ?>
</td></tr>

<? if($tws_config['cpuinfo']['version']>='9.5'){
// STREAM FOLDER
?>
<tr>
   <td><b>Stream Folder:</b></td>
   <td>
      <input type="text" name="jobstream_folder" required="required" style="width:15em;" value="<?=$jobstream_folder?>" <?if($action=='display' || $action=='modify' ) echo "readonly"?>>
      <? if($action != 'modify' && $action != 'display'){ ?>
      	<input type="button" name="folder_list" onClick="tws_picker_open('folder_picker.php', 'fieldname=jobstream_folder&fieldvalue=' + document.contents.jobstream_folder.value);" value="List" >
      <? } ?>
   </td>
</tr>
<? } ?>
<tr><td nowrap><b>Jobstream Name: </b></td>
   <td><input type="text" name="jobstream" class="tws_name" required="required" style="width:15em;" maxlength="16" value="<?=$jobstream?>" <? if($action=='modify') echo "readonly" ?>> (*)
</td>
</tr>

<tr><td><b>Valid from:</b></td>
<td>
   <? if ($action == 'modify' || $action == 'display') $attrs = null;
      else $attrs = "'dropdown',false,'24',true,false,false";
      echo tws_datetime_picker('validfrom', $validfrom,'','',$attrs);
   ?>
      <input type="hidden" name="validto" id="validto" value="<?=$validto?>">
</td>
</tr>
<tr><td><b>Description:</b></td>
<td><input type="text" name="description" id="description" size=72 maxlength=120 value="<?=$description?>" <?=$readonly?>></td>
</tr>
<tr><td valign="top"><b>Comment:</b></td>
<td><?php
if (defined('IWD_PROCMAN')) {
    $x=new wai_textarea('comment', $comment);
    $x->set_id(strtoupper($action).'_DBJS_COMMENT');//IWD_MOD_EDIT.CONTENTS.NEW_DBJS_COMMENT
    $x->set_rows(5);
    $x->set_cols(72);
    $x->set_readonly($readonly=='' ? FALSE : TRUE);
    $x->set_css_class('tws_comment');
    $x->set_wrap('soft');
    $x->app_sec_init();
    $x->print_html();
} else {
    echo '<textarea name="comment" class="tws_comment" cols="72" rows="5" wrap="soft" '.$readonly.'>'.$comment.'</textarea>'."\n";
}
?></td></tr>
<tr><td> </td></tr>
<tr><td>
<?
if (tws_yesno($time_dependent, true, false) || tws_yesno($attimedep, true, false) || (empty($athour) && empty($atminute)) ){
   // AT
   $at_title = 'At:';
   $attimedep = 'checked';
}
else{
   // SCHEDTIME
   $at_title = 'Schedtime:';
   $attimedep = '';
}
?>
      <b class='schedtime'><?=$at_title?></b>
   </td>
<td>
   <input type="text" name="athour" id="athour" class="tws_hour" size=2 maxlength=2 value="<?=$athour?>" <?=$readonly?>> :
   <input type="text" name="atminute" id="atminute" class="tws_minute" size=2 maxlength=2 value="<?=$atminute?>" <?=$readonly?>> plus
   <input type="text" name="atplusdays" id="atplusdays" class="tws_number" size=3 maxlength=3 value="<?=$atplusdays?>" <?=$readonly?>> days
   <label> <input type="checkbox" name="attimedep" value="yes" <?=$attimedep?> onclick="change_at_title(this)">Use as time dependency</label>
   <script type="text/javascript">
      function change_at_title(me){
         if( $(me).is(':checked') )
            $('b.schedtime').text('At:');
         else $('b.schedtime').text('Schedtime:');
      }
   </script>
</td>
</tr>
<tr><td><b>Until:</b></td>
<td>
   <input type="text" name="untilhour" class="tws_hour" size=2 maxlength=2 value="<?=$untilhour?>" <?=$readonly?>> :
   <input type="text" name="untilminute" class="tws_minute" size=2 maxlength=2 value="<?=$untilminute?>" <?=$readonly?>> plus
   <input type="text" name="untilplusdays" class="tws_num" size=3 maxlength=3 value="<?=$untilplusdays?>" <?=$readonly?>> days
<? if ($tws_config['cpuinfo']['version']>'9.4') { ?>
      <label><input type='checkbox' name='jsuntil' value='Y' <?=(strtoupper($jsuntil=='Y')?'checked':'')?>>Apply to each job</label>
<? } ?>
</td>
</tr>
<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;<b>Until Action:</b></td>
<td>
<select name="onuntil">
   <option value="SUPPR" <?=($onuntil == "" || strtoupper($onuntil) == "SUPPR")?"selected":''?>>Suppress</option>
   <option value="CONT" <?=(strtoupper($onuntil) == "CONT" ? "selected":'')?>>Continue</option>
   <option value="CANC" <?=(strtoupper($onuntil) == "CANC" ? "selected":'')?>>Cancel</option>
</select>
</td>
</tr>
<tr><td><b>Deadline:</b></td>
<td>
   <input type="text" name="deadlinehour" class="tws_hour" size=2 maxlength=2 value="<?=$deadlinehour?>" <?=$readonly?>> :
   <input type="text" name="deadlineminute" class="tws_minute" size=2 maxlength=2 value="<?=$deadlineminute?>" <?=$readonly?>> plus
   <input type="text" name="deadlineplusdays" class="tws_num" size=3 maxlength=3 value="<?=$deadlineplusdays?>" <?=$readonly?>> days
</td>
</tr>
<tr><td>
<b><? if (!tws_yesno(tws_get_tz_status(),TRUE,FALSE)) echo "<font color=\"#808080\">"; ?>Time Zone:<? if (!tws_yesno(tws_get_tz_status(),TRUE,FALSE)) echo "</font>"; ?></b>
</td>
<td>
   <select name="time_zone"<?php if (!tws_yesno(tws_get_tz_status(),TRUE,FALSE)) echo " disabled"; ?>>
   <? tws_print_timezone_options($time_zone); ?>
   </select>
   <? if ($tz_status_warning) echo "<br/><font color=\"#ff0000\"><b>Warning: Time Zone is set in Jobstream definition, but Time Zones are not enabled</b></font>"; ?>
</td>
</tr>
<tr>
<td><b>Matching:</b></td>
<td>
<table border=0 cellspacing=0 cellpadding=0 class="transparent">
   <tr><td>
   <select name="matching" id="matching" onchange="showMatch(this.value);">
      <option value="SAMEDAY" <? if (!isset($matching) || $matching=="SAMEDAY") echo " selected";?> >Same day</option>
      <option value="PREVIOUS"<? if ($matching=="PREVIOUS") echo " selected";?> >Previous day</option>
      <option value="RELATIVE"<? if ($matching=="RELATIVE") echo " selected";?> >Relative</option>
      <option value="ABSOLUTE"<? if ($matching=="ABSOLUTE") echo " selected";?> >Absolute</option>
   </select>
   </td>
   <td>
      <div id="relative" <? if($matching!="RELATIVE") echo 'style="display:none;"'?>>
      from <select name="matchingrelativefromdir">
         <option value="+"<? if ($matchingrelativefromdir == "+") echo " selected";?> >+</option>
         <option value="-"<? if ($matchingrelativefromdir == "-") echo " selected";?> >-</option>
      </select>
      <input type="text" name="matchingrelativefromhour" class="tws_num" size=2 maxlength=2 value="<?=$matchingrelativefromhour?>" <?=$readonly?>> :
      <input type="text" name="matchingrelativefromminute" class="tws_minute" size=2 maxlength=2 value="<?=$matchingrelativefromminute?>" <?=$readonly?>>&nbsp;&nbsp;
      to <select name="matchingrelativetodir">
         <option value="+" <? if ($matchingrelativetodir == "+") echo " selected";?> >+</option>
         <option value="-" <? if ($matchingrelativetodir == "-") echo " selected";?> >-</option>
      </select>
      <input type="text" name="matchingrelativetohour" class="tws_num" size=2 maxlength=2 value="<?=$matchingrelativetohour?>" <?=$readonly?>> :
      <input type="text" name="matchingrelativetominute" class="tws_minute" size=2 maxlength=2 value="<?=$matchingrelativetominute?>" <?=$readonly?>>
      </div>

      <div id="absolute" <? if ($matching!="ABSOLUTE") echo 'style="display:none;"'?> >
      from <input type="text" name="matchingabsolutefromhour" class="tws_hour" size=2 maxlength=2 value="<?=$matchingabsolutefromhour?>" <?=$readonly?>> :
      <input type="text" name="matchingabsolutefromminute" class="tws_minute" size=2 maxlength=2 value="<?=$matchingabsolutefromminute?>" <?=$readonly?>>
      <select name="matchingabsolutefromdir">
         <option value="+"<? if ($matchingabsolutefromdir == "+") echo " selected";?> >+</option>
         <option value="-"<? if ($matchingabsolutefromdir == "-") echo " selected";?> >-</option>
      </select>
      <input type="text" name="matchingabsolutefromdays" class="tws_num" size=2 maxlength=5 value="<?=$matchingabsolutefromdays?>" <?=$readonly?>> days
      to <input type="text" name="matchingabsolutetohour" class="tws_hour" size=2 maxlength=2 value="<?=$matchingabsolutetohour?>" <?=$readonly?>> :
      <input type="text" name="matchingabsolutetominute" class="tws_minute" size=2 maxlength=2 value="<?=$matchingabsolutetominute?>" <?=$readonly?>>
      <select name="matchingabsolutetodir">
         <option value="+"<? if ($matchingabsolutetodir == "+") echo " selected";?> >+</option>
         <option value="-"<? if ($matchingabsolutetodir == "-") echo " selected";?> >-</option>
      </select>
      <input type="text" name="matchingabsolutetodays" class="tws_num" size=2 maxlength=5 value="<?=$matchingabsolutetodays?>" <?=$readonly?>> days
      </div>
   </td>
   </tr>
</table>
</td>
</tr>
<tr><td> </td></tr>
<tr><td><b>Priority:</b></td>
<td>
   <input type="text" name="priority" class="tws_priority" size=3 maxlength=3 value="<?=$priority?>" <?=$readonly?>>
   <input type="button" value="Hold" onClick="setPrio(0)">
   <input type="button" value="High" onClick="setPrio('HI')">
   <input type="button" value="Go" onClick="setPrio('GO')">
</td>
</tr>
<tr><td><b>Limit:</b></td>
<td><input type="text" name="limit" class="tws_num" size=3 maxlength=3 value="<?=($limit>=0?$limit:'')?>" <?=$readonly?>></td>
</tr>
<? if ($tws_config['cpuinfo']['version']>='8.5'){ ?>
      <tr><td><b>Parameter Table:</b></td>
         <td>
            <input type="text" name="parameter_table" class="tws_name" size="20" maxlength="80" value="<?=$parameter_table?>" <?=$readonly?>>
            <? if(!$disabled){ ?>
            <input type="button" name="parameter_table_list"  value="List" onClick="tws_picker_open('parameter_table_picker.php', 'fieldname=parameter_table&amp;fieldvalue=' + document.contents.parameter_table.value);"/>
            <? } ?>
         </td>
      </tr>
<? }
   if ($tws_config['cpuinfo']['version']>='9.3') {
   ?>
      <tr>
         <td class="standard">&nbsp;&nbsp;<b>If an instance is still running:</b></td>
         <td class="standard">
            <select name='running_rule'>
               <option value='P'>Run in parallel</option>
               <option value='N' <? if ($running_rule == "N") echo " selected";?> >Don't start new instance</option>
               <option value='E' <? if ($running_rule == "E") echo " selected";?>>Queue new instance</option>
            </select>
         </td>
      </tr>
      <?
   }
?>
<tr>
<tr><td> </td></tr>
<tr>
   <td colspan=2><b><label><input type="checkbox" name="keysched" value="YES" <? if($keysched=="YES") echo "checked";?> <?=$readonly?'disabled':''?>> Monitored Jobstream</label></b></td>
</tr>
<tr>
   <td colspan=2><b><label><input type="checkbox" name="carryforward" value="YES" <? if($carryforward=="YES") echo "checked";?> <?=$readonly?'disabled':''?>> Carryforward</label></b></td>
</tr>
<tr>
   <td colspan=2><b><label><input type="checkbox" name="draft" value="YES" <? if($draft=="YES") echo "checked";?> <?=$readonly?'disabled':''?>> Draft</label></b></td>
</tr>

</table>
</div>

<!-- RUN CYKLE -->

<div id='calendar'>
<br>
<b><label><input type="checkbox" name="request" value="YES" <? if($request=="YES") echo "checked";?> <?=$readonly?'disabled':''?>> On Request</label></b>
<br>

<? include "tws_add_runcycle_inc.php";     // TODO:  ?>

<table border=0 cellspacing=0 class="transparent">
<tr><td colspan="2"><h3> Free Days:</h3></td></tr>
<tr>
   <td> <b>Calendar:</b></td>
<td>
<table border=0 cellspacing=0 class="transparent">
<tr>
   <td><label><input type="radio" name="freedays_option" value="default"<? if(($freedays_option == "") || ($freedays_option == "default") || ($freedays_calendar == "")) echo " checked"; ?> onclick="enable_freedays(false);" >Use Default</label></td>
</tr>
<tr>
   <td><label><input type="radio" name="freedays_option" value="specify" <? if (($freedays_option == "specify") && ($freedays_calendar != "")) echo " checked"; ?>  onclick="enable_freedays(true);">Specify Calendar:</label></td>
<td>
   <input type="text" name="freedays_calendar" class="tws_name" style="width:20em;" <? if (($freedays_option == "specify") && (isset($freedays_calendar))) echo " value=\"".htmlspecialchars($freedays_calendar)."\""; ?> >
   <input type="button" name="freedays_calendar_list" value="List" onClick="tws_picker_open('calendar_picker.php', 'includestock=no&amp;fieldname=freedays_calendar&amp;fieldvalue=' + document.contents.freedays_calendar.value );"/>
</td>
</tr>
<tr><td> </td></tr>
<tr>
<td>Consider as Free Days:&nbsp;&nbsp;</td>
<td>
   <label><input type="checkbox" name="freedays_sat" value="YES" <?php if (($freedays_option == "") || ($freedays_option == "default") || ($freedays_calendar == "") || ($freedays_sat == "YES")) echo " checked"; ?>>Saturday</label>&nbsp;&nbsp;
   <label><input type="checkbox" name="freedays_sun" value="YES" <?php if (($freedays_option == "") || ($freedays_option == "default") || ($freedays_calendar == "") || ($freedays_sun == "YES")) echo " checked"; ?>>Sunday</label>
</td>
</tr>
</table>
</td>
</tr>
</table>

</div>

<!-- Dependencies -->

<div id='dependencies'>

<table border=0 cellspacing=0 class="transparent standard">
<!-- Jobstream Dependencies -->
<tr><td width = "300"><h3>Jobstream Dependencies</h3></td>
<td>&nbsp;&nbsp;<input type="button" name="add" value=" + " onClick="addfollowsjobstreamrow('followsjobstream');"></td>
</tr>
<tr><td colspan="2">
<table id="followsjobstream" border=0 cellspacing=5 class="transparent">
<? if (!is_array($followsjobstreamcpu))
      $followsjobstreamcpu = array();  // don't show empty form & avoid warning

foreach ($followsjobstreamcpu as $index => $value) {
?>
<tr>
   <td>(<?=($index+1)?>) - Workstation:
      <input type="text" name="followsjobstreamcpu[<?=$index?>]" class="tws_name" style="width:20em;" value="<?=$value?>">
      <input type="button" name="workstation_list" value="List" onClick="tws_picker_open('workstation_picker.php', 'includeclasses=yes&amp;fieldname=followsjobstreamcpu[<?=$index?>]&amp;fieldvalue=' + document.contents.elements['followsjobstreamcpu[<?=$index?>]'].value);" >
   </td>
   <td> Jobstream:
   <? if(!empty($followsjobstreamfolder[$index]))
      $followsjobstreamname[$index] = $followsjobstreamfolder[$index].$followsjobstreamname[$index];
   ?>
      <input type="text" name="followsjobstreamname[<?=$index?>]" class="tws_name" style="width:20em;" value="<?=$followsjobstreamname[$index]?>">
      <input type="button" name="jobstream_list" value="List" onClick="tws_picker_open('jobstream_picker.php', 'fieldname=followsjobstreamname[<?=$index?>]&amp;fieldvalue=' + document.contents.elements['followsjobstreamname[<?=$index?>]'].value + '&amp;cpux=' + document.contents.elements['followsjobstreamcpu[<?=$index?>]'].value);" >
   </td>
</tr>
<tr><td colspan=2 style="padding-left:20px;">
<? if($tws_config['cpuinfo']['version']>='9.3'){ ?>
      <label><input type="checkbox" name="js_js_abend[<?=$index?>]" value="Y" <?=(!empty($js_js_abend[$index]) && $js_js_abend[$index] == 'Y' ?'checked':'')?>>On ABEND</label>
      <label><input type="checkbox" name="js_js_success[<?=$index?>]" value="Y" <?=(!empty($js_js_success[$index]) && $js_js_success[$index] == 'Y' ?'checked':'')?>>On SUCCESS</label>
      <label><input type="checkbox" name="js_js_suppress[<?=$index?>]" value="Y" <?=(!empty($js_js_suppress[$index]) && $js_js_suppress[$index] == 'Y' ?'checked':'')?>>On SUPPRESS</label>
<? } ?>
</td></tr>
   <tr><td style="padding-left:20px;">Dependency resolution:
         <select name="followsjobstreammatching[<?=$index?>]" onchange="showFollowsJsMatch(this.value, <?=$index?>);">
            <option value="DEFAULT" <? if ($followsjobstreammatching[$index]=="" || $followsjobstreammatching[$index]=="DEFAULT") echo " selected";?>>Default</option>
            <option value="SAMEDAY" <? if ($followsjobstreammatching[$index]=="SAMEDAY") echo " selected"?> >Same day</option>
            <option value="PREVIOUS" <? if ($followsjobstreammatching[$index]=="PREVIOUS") echo " selected"?> >Previous day</option>
            <option value="RELATIVE" <? if ($followsjobstreammatching[$index]=="RELATIVE") echo " selected"?> >Relative</option>
            <option value="ABSOLUTE" <? if ($followsjobstreammatching[$index]=="ABSOLUTE") echo " selected"?> >Absolute</option>
         </select>
      </td>
      <td>
      <div id="followsJsMatchRelative<?=$index?>" <? if($followsjobstreammatching[$index]!="RELATIVE") echo 'style="display:none;"'?> >
         from <select name="followsjobstreammatchingrelativefromdir[<?=$index?>]">
            <option value="+" <? if ($followsjobstreammatchingrelativefromdir[$index] == "+") echo " selected";?> >+</option>
            <option value="-" <? if ($followsjobstreammatchingrelativefromdir[$index] == "-") echo " selected";?> >-</option>
         </select>
         <input type="text" name="followsjobstreammatchingrelativefromhour[<?=$index?>]" class="tws_num" size=2 maxlength=2 value="<?=$followsjobstreammatchingrelativefromhour[$index]?>" > :
         <input type="text" name="followsjobstreammatchingrelativefromminute[<?=$index?>]" class="tws_minute" size=2 maxlength=2 value="<?=$followsjobstreammatchingrelativefromminute[$index]?>" >
         to <select name="followsjobstreammatchingrelativetodir[<?=$index?>]">
            <option value="+" <? if ($followsjobstreammatchingrelativetodir[$index] == "+") echo " selected";?> >+</option>
            <option value="-" <? if ($followsjobstreammatchingrelativetodir[$index] == "-") echo " selected";?> >-</option>
         </select>
         <input type="text" name="followsjobstreammatchingrelativetohour[<?=$index?>]" class="tws_num" size=2 maxlength=2 value="<?=$followsjobstreammatchingrelativetohour[$index]?>" > :
         <input type="text" name="followsjobstreammatchingrelativetominute[<?=$index?>]" class="tws_minute" size=2 maxlength=2 value="<?=$followsjobstreammatchingrelativetominute[$index]?>" >
      </div>

      <div id="followsJsMatchAbsolute<?=$index?>" <? if($followsjobstreammatching[$index]!="ABSOLUTE") echo 'style="display:none;"'?>>
         from <input type="text" name="followsjobstreammatchingabsolutefromhour[<?=$index?>]" class="tws_hour" size=2 maxlength=2 value="<?=$followsjobstreammatchingabsolutefromhour[$index]?>" > :
         <input type="text" name="followsjobstreammatchingabsolutefromminute[<?=$index?>]" class="tws_minute" size=2 maxlength=2 value="<?=$followsjobstreammatchingabsolutefromminute[$index]?>" >
         <select name="followsjobstreammatchingabsolutefromdir[<?=$index?>]">
            <option value="+" <? if ($followsjobstreammatchingabsolutefromdir[$index] == "+") echo " selected";?> >+</option>
            <option value="-" <? if ($followsjobstreammatchingabsolutefromdir[$index] == "-") echo " selected";?> >-</option>
         </select>
         <input type="text" name="followsjobstreammatchingabsolutefromdays[<?=$index?>]" class="tws_num" size=2 maxlength=5 value="<?=$followsjobstreammatchingabsolutefromdays[$index]?>" > days
         to <input type="text" name="followsjobstreammatchingabsolutetohour[<?=$index?>]" class="tws_hour" size=2 maxlength=2 value="<?=$followsjobstreammatchingabsolutetohour[$index]?>" > :
         <input type="text" name="followsjobstreammatchingabsolutetominute[<?=$index?>]" class="tws_minute" size=2 maxlength=2 value="<?=$followsjobstreammatchingabsolutetominute[$index]?>" >
         <select name="followsjobstreammatchingabsolutetodir[<?=$index?>]">
            <option value="+" <? if ($followsjobstreammatchingabsolutetodir[$index] == "+") echo " selected";?> >+</option>
            <option value="-" <? if ($followsjobstreammatchingabsolutetodir[$index] == "-") echo " selected";?> >-</option>
         </select>
         <input type="text" name="followsjobstreammatchingabsolutetodays[<?=$index?>]" class="tws_num" size=2 maxlength=5 value="<?=$followsjobstreammatchingabsolutetodays[$index]?>"> days
      </div>
      </td>
      </tr>
      <tr><td colspan=2 style="padding-left:20px;">
      <? if($tws_config['cpuinfo']['version']>='9.4'){
         if(!empty($js_js_join_name[$index])){
            $description = $js_js_join_description[$index];
            $quantity = $js_js_join_quantity[$index];
            $title = "Description: $description\nQuantity: $quantity";
            echo "Joined into <input type='text' name='js_js_join_name[$index]' value='$js_js_join_name[$index]' readonly='readonly'>
               <img src='images/icons/bar_help.gif' title='$title' border='0'/>
                <input type = 'hidden' name = 'js_js_join_quantity[$index]' value='$js_js_join_quantity[$index]'>
                <input type = 'hidden' name = 'js_js_join_description[$index]' value='$js_js_join_description[$index]'>";
         }
      } ?>
      </td></tr>
<? } ?>
</table>
</td></tr>
<!-- Job Dependencies -->
<tr><td><h3> Job Dependencies</h3></td>
<td>&nbsp;&nbsp;<input type="button" name="add" value=" + " onClick="addfollowsjobrow('followsjob');"></td>
</tr>
<tr><td colspan="2">
<table id="followsjob" border=0 cellspacing=5 class="transparent">
<? if (!is_array($followsjobcpu))
      $followsjobcpu = array();  // don't show empty form & avoid warning
   foreach ($followsjobcpu as $index => $value) {
?>
      <tr><td>(<?=($index+1)?>) - Workstation:</td><td>Jobstream:</td><td>Job:</td></tr>
      <tr>
         <td nowrap>
         <input type="text" name="followsjobcpu[<?=$index?>]" id="followsjobcpu<?=$index?>" class="tws_name" style="width:20em;" value="<?=$followsjobcpu[$index]?>">
         <input type="button" name="workstation_list" value="List" onClick="tws_picker_open('workstation_picker.php', 'includeclasses=yes&amp;fieldname=followsjobcpu[<?=$index?>]&amp;fieldvalue=' + document.contents.elements['followsjobcpu[<?=$index?>]'].value);">
         </td>
         <td nowrap>
         <? if(!empty($followsjobfolder[$index]))
            $followsjobjobstream[$index] = $followsjobfolder[$index].$followsjobjobstream[$index];
         ?>

         <input type="text" name="followsjobjobstream[<?=$index?>]" id="followsjobjobstream<?=$index?>" class="tws_name" style="width:20em;" value="<?=$followsjobjobstream[$index]?>">
         <input type="button" name="jobstream_list" value="List" onClick="tws_picker_open('jobstream_picker.php', 'fieldname=followsjobjobstream[<?=$index?>]&amp;fieldvalue='+document.contents.elements['followsjobjobstream[<?=$index?>]'].value + '&amp;cpux=' + document.contents.elements['followsjobcpu[<?=$index?>]'].value);">
         </td>
         <td nowrap>
         <input type="text" name="followsjobname[<?=$index?>]" id="followsjobname<?=$index?>" style="width:15em;" maxlength=40 class="tws_name" value="<?=$followsjobname[$index]?>">
         <input type="button" name="job_list" value="List" onClick="tws_picker_open('job_instance_picker.php', 'jobfieldname=followsjobname[<?=$index?>]&amp;jsfieldname=followsjobjobstream[<?=$index?>]&amp;wksfieldname=followsjobcpu[<?=$index?>]&amp;fieldvalue=' + document.contents.elements['followsjobname[<?=$index?>]'].value + '&amp;cpux=' + document.contents.elements['followsjobcpu[<?=$index?>]'].value + '&amp;schedulex=' + document.contents.elements['followsjobjobstream[<?=$index?>]'].value);">
         </td>
      </tr>
      <tr>
         <td colspan='3' style='padding-left:20px;'>
         <? if($tws_config['cpuinfo']['version']>='9.3'){ ?>
            <div id="js_job_execute<?=$index?>">
            <label><input type="checkbox" name="js_job_execute[<?=$index?>]" value="Y" <?=($js_job_execute[$index] == 'Y'?'checked':'')?> onclick="js_job_oncondition(<?=$index?>)">On EXECUTE</label>&nbsp;&nbsp;
            </div>
            <div id="js_job_state<?=$index?>">
            <label><input type="checkbox" name="js_job_abend[<?=$index?>]" value="Y" <?=($js_job_abend[$index] == 'Y'?'checked':'')?> onclick="js_job_oncondition(<?=$index?>)">On ABEND</label>
            <label><input type="checkbox" name="js_job_fail[<?=$index?>]" value="Y" <?=($js_job_fail[$index] == 'Y'?'checked':'')?> onclick="js_job_oncondition(<?=$index?>)">On FAIL</label>
            <label><input type="checkbox" name="js_job_success[<?=$index?>]" value="Y" <?=($js_job_success[$index] == 'Y'?'checked':'')?> onclick="js_job_oncondition(<?=$index?>)">On SUCCESS</label>
            <label><input type="checkbox" name="js_job_suppress[<?=$index?>]" value="Y" <?=($js_job_suppress[$index] == 'Y'?'checked':'')?> onclick="js_job_oncondition(<?=$index?>)">On SUPPRESS</label>
            </div>
            <?
            echo "<div id='js_job_condition$index'>";
            if(empty($js_job_codemaps[$index])) $js_job_codemaps[$index] = array();
            foreach($js_job_codemaps[$index] as $j=>$joc_name){ ?>
               <label><input type="checkbox" name="js_job_condition[<?=$index?>][<?=$j?>]" value="<?=$joc_name?>" id="<?=$joc_name.$index?>" onclick="js_job_oncondition(<?=$index?>)"><?=$joc_name?></label>
               <input type="hidden" name="js_job_codemaps[<?=$index?>][<?=$j?>]" value="<?=$joc_name?>">
            <? }
            if(empty($js_job_condition[$index])) $js_job_condition[$index] = array();
            $k=0;
            foreach($js_job_condition[$index] as $condition){ ?>
               <script>
               $('input#<?=$condition.$index?>').attr('checked', true);
               </script>
            <? $k++;
            }
            echo "</div>";
            ?>
            <script>
               js_job_oncondition(<?=$index?>);
               $('input#followsjobname<?=$index?>').on('keyup',
                 {index: <?=$index?>},
                  tws_js_job_change);

            </script>
         <? } ?>
         </td>
      </tr>
      <tr>
      <td style="padding-left:20px;" colspan="3">
      <div style="float:left; padding-right:20px;">
         Dependency resolution:
         <select name="followsjobmatching[<?=$index?>]" onchange="showFollowsJobMatch(this.value, <?=$index?>);">
            <option value="DEFAULT" <? if ($followsjobmatching[$index]=="" || $followsjobmatching[$index]=="DEFAULT") echo " selected";?>>Default</option>
            <option value="SAMEDAY" <? if ($followsjobmatching[$index]=="SAMEDAY") echo " selected"?> >Same day</option>
            <option value="PREVIOUS" <? if ($followsjobmatching[$index]=="PREVIOUS") echo " selected"?> >Previous day</option>
            <option value="RELATIVE" <? if ($followsjobmatching[$index]=="RELATIVE") echo " selected"?> >Relative</option>
            <option value="ABSOLUTE" <? if ($followsjobmatching[$index]=="ABSOLUTE") echo " selected"?> >Absolute</option>
         </select>
      </div>
      <div id="followsJobMatchRelative<?=$index?>" style="float:left; <?=($followsjobmatching[$index]!="RELATIVE" ? 'display:none;"' : '"')?>>
         from <select name="followsjobmatchingrelativefromdir[<?=$index?>]">
            <option value="+" <? if ($followsjobmatchingrelativefromdir[$index] == "+") echo " selected";?> >+</option>
            <option value="-" <? if ($followsjobmatchingrelativefromdir[$index] == "-") echo " selected";?> >-</option>
         </select>
         <input type="text" name="followsjobmatchingrelativefromhour[<?=$index?>]" class="tws_num" size=2 maxlength=2 value="<?=$followsjobmatchingrelativefromhour[$index]?>" >:<input type="text" name="followsjobmatchingrelativefromminute[<?=$index?>]" class="tws_minute" size=2 maxlength=2 value="<?=$followsjobmatchingrelativefromminute[$index]?>" >
         to <select name="followsjobmatchingrelativetodir[<?=$index?>]">
            <option value="+" <? if ($followsjobmatchingrelativetodir[$index] == "+") echo " selected";?> >+</option>
            <option value="-" <? if ($followsjobmatchingrelativetodir[$index] == "-") echo " selected";?> >-</option>
         </select>
         <input type="text" name="followsjobmatchingrelativetohour[<?=$index?>]" class="tws_num" size=2 maxlength=2 value="<?=$followsjobmatchingrelativetohour[$index]?>">:<input type="text" name="followsjobmatchingrelativetominute[<?=$index?>]" class="tws_minute" size=2 maxlength=2 value="<?=$followsjobmatchingrelativetominute[$index]?>">
      </div>
      <div id="followsJobMatchAbsolute<?=$index?>" style="float:left; <?=($followsjobmatching[$index]!="ABSOLUTE" ? 'display:none;"' : '"') ?> >
         from <input type="text" name="followsjobmatchingabsolutefromhour[<?=$index?>]" class="tws_hour" size=2 maxlength=2 value="<?=$followsjobmatchingabsolutefromhour[$index]?>">:<input type="text" name="followsjobmatchingabsolutefromminute[<?=$index?>]" class="tws_minute" size=2 maxlength=2 value="<?=$followsjobmatchingabsolutefromminute[$index]?>">
         <select name="followsjobmatchingabsolutefromdir[<?=$index?>]">
            <option value="+" <? if ($followsjobmatchingabsolutefromdir[$index] == "+") echo " selected";?> >+</option>
            <option value="-" <? if ($followsjobmatchingabsolutefromdir[$index] == "-") echo " selected";?> >-</option>
         </select>
         <input type="text" name="followsjobmatchingabsolutefromdays[<?=$index?>]" class="tws_num" size=2 maxlength=5 value="<?=$followsjobmatchingabsolutefromdays[$index] >0?>"> days
         to <input type="text" name="followsjobmatchingabsolutetohour[<?=$index?>]" class="tws_hour" size=2 maxlength=2 value="<?=$followsjobmatchingabsolutetohour[$index]?>">:<input type="text" name="followsjobmatchingabsolutetominute[<?=$index?>]" class="tws_minute" size=2 maxlength=2 value="<?=$followsjobmatchingabsolutetominute[$index]?>">
         <select name="followsjobmatchingabsolutetodir[<?=$index?>]">
            <option value="+" <? if ($followsjobmatchingabsolutetodir[$index] == "+") echo " selected";?> >+</option>
            <option value="-" <? if ($followsjobmatchingabsolutetodir[$index] == "-") echo " selected";?> >-</option>
         </select>
         <input type="text" name="followsjobmatchingabsolutetodays[<?=$index?>]" class="tws_num" size=2 maxlength=5 value="<?=$followsjobmatchingabsolutetodays[$index]?>"> days
      </div>
      </td></tr>
      <tr><td style="padding-left:20px;" colspan="3">
      <? if($tws_config['cpuinfo']['version']>='9.4'){
         if(!empty($js_job_join_name[$index])){
            $description = $js_job_join_description[$index];
            $quantity = $js_job_join_quantity[$index];
            echo "Joined into <input type='text' name='js_job_join_name[$index]' value='$js_job_join_name[$index]' readonly='readonly'>
               <img src='images/icons/bar_help.gif' title='Description: $description\nQuantity: $quantity' border='0'/>
                <input type = 'hidden' name = 'js_job_join_quantity[$index]' value='$js_job_join_quantity[$index]'>
                <input type = 'hidden' name = 'js_job_join_description[$index]' value='$js_job_join_description[$index]'>";
         }
      } ?>
         </td></tr>
<? } ?>
</table>
</td></tr>
<!-- Internetwork Dependencies -->
<tr><td><h3> Internetwork Dependencies</h3></td>
<td>&nbsp;&nbsp;<input type="button" name="add" value=" + " onClick="addfollowsnetrow('followsnet');"></td>
</tr>
<tr><td colspan="2">
<table id="followsnet" border=0 cellspacing=5 class="transparent">
<? if (!is_array($followsnetworkagent))
      $followsnetworkagent = array();  // don't show empty form & avoid warning
   foreach ($followsnetworkagent as $index => $value) { ?>
      <tr><td nowrap> (<?=($index+1)?>) - Network Agent:
      <input type="text" name="followsnetworkagent[<?=$index?>]" class="tws_name" style='width:15em;' maxlength='16' value="<?=$followsnetworkagent[$index]?>">
      <input type="button" name="workstation_list" onClick="tws_picker_open('workstation_picker.php', 'includexagents=only&amp;fieldname=followsnetworkagent[<?=$index?>]&amp;fieldvalue=' + document.contents.elements['followsnetworkagent[<?=$index?>]'].value);" value="List">
      </td>
      <td nowrap> Dependency:
      <input type="text" name="followsnetworkdep[<?=$index?>]" size=50 maxlength=74 value="<?=$followsnetworkdep[$index]?>">
      </td></tr>
   <? } ?>
</table>
</td></tr>
<!-- Global Prompt Dependencies -->
<tr><td><h3>Global Prompt Dependencies</h3></td>
<td>&nbsp;&nbsp;<input type="button" name="add" value=" + " onClick="addpromptrow('promptdep');"></td>
</tr>
<tr><td colspan="2">
<table id="promptdep" border=0 cellspacing=5 class="transparent">
<? if (!is_array($promptname))
      $promptname = array();  // don't show empty form & avoid warning
   foreach ($promptname as $index => $value) { ?>
      <tr><td>
      (<?=($index+1)?>) - Prompt:
      <input type="text" name="promptname[<?=$index?>]" class="tws_name" style='width:20em;' value="<?=$value?>">
      <input type="button" name="prompt_list" onClick="tws_picker_open('prompt_picker.php', 'fieldname=promptname[<?=$index?>]&amp;fieldvalue=' + document.contents.elements['promptname[<?=$index?>]'].value);" value="List">
      </td></tr>
   <? } ?>
</table>
</td></tr>
<!-- Ad-Hoc Prompt Dependencies -->
<tr><td><h3> Ad-Hoc Prompt Dependencies</h3></td>
<td>&nbsp;&nbsp;<input type="button" name="add" value=" + " onClick="addlocalpromptrow('localpromptdep');"></td>
</tr>
<tr><td colspan="2">
<table id="localpromptdep" border=0 cellspacing=5 class="transparent">
<? if (!is_array($prompttext))
      $prompttext = array();  // don't show empty form & avoid warning
   foreach ($prompttext as $index => $value) { ?>
      <tr><td>
      (<?=($index+1)?>) - Prompt Text: <input type="text" name="prompttext[<?=$index?>]" size=80 maxlength=200 value="<?=$value?>">
      </td></tr>
<? } ?>
</table>
</td></tr>
<!-- File Dependencies -->
<tr><td><h3> File Dependencies</h3></td>
<td>&nbsp;&nbsp;<input type="button" name="add" value=" + " onClick="addopensrow('opens');"></td>
</tr>
<tr><td colspan="2">
<table id="opens" border=0 cellspacing=5 class="transparent">
<? if (!is_array($openscpu))
      $openscpu = array();  // don't show empty form & avoid warning
   foreach ($openscpu as $index => $value) { ?>
      <tr><td nowrap>
      (<?=($index+1)?>) - Workstation: <input type="text" name="openscpu[<?=$index?>]" class="tws_name" style='width:20em;' value="<?=$value?>">
      <input type="button" name="workstation_list" onClick="tws_picker_open('workstation_picker.php', 'fieldname=openscpu[<?=$index?>]&amp;fieldvalue=' + document.contents.elements['openscpu[<?=$index?>]'].value);" value="List">
      </td><td nowrap>
      Filename: <input type="text" name="opensfile[<?=$index?>]" class='tws_file' size=32 maxlength=148 value="<?=$opensfile[$index]?>">
      </td><td nowrap>
      Qualifier: <input type="text" name="opensqual[<?=$index?>]" size=16 maxlength=128 value="<?=$opensqual[$index]?>">
      </td></tr>
<? } ?>
</table>
</td>
</tr>
<!-- Resource Dependencies -->
<tr><td><h3> Resource Dependencies</h3></td>
<td>&nbsp;&nbsp;<input type="button" name="add" value=" + " onClick="addresourcerow('resourcedep');"></td>
</tr>
<tr><td colspan="2">
<table id="resourcedep" border=0 cellspacing=5 class="transparent">
<? if (!is_array($needscpu))
      $needscpu = array();  // don't show empty form & avoid warning
   foreach ($needscpu as $index => $value) { ?>
      <tr><td>
      (<?=($index+1)?>) - Workstation:
      <input type="text" name="needscpu[<?=$index?>]" class="tws_name" style='width:20em;' value="<?=$value?>">
      <input type="button" name="workstation_list" onClick="tws_picker_open('workstation_picker.php', 'fieldname=needscpu[<?=$index?>]&amp;fieldvalue=' + document.contents.elements['needscpu[<?=$index?>]'].value);" value="List">
      </td><td> Resource:
      <input type="text" name="resource[<?=$index?>]" class="tws_name" style='width:15em;' value="<?=$resource[$index]?>">
      <input type="button" name="resource_list" onClick="tws_picker_open('resource_picker.php', 'fieldname=resource[<?=$index?>]&amp;fieldvalue=' + document.contents.elements['resource[<?=$index?>]'].value + '&amp;cpux=' + document.contents.elements['needscpu[<?=$index?>]'].value);" value="List">
      </td><td> Units:
      <input type="text" name="units[<?=$index?>]" class="tws_num" size=4 maxlength=4 value="<?=$units[$index]?>">
      </td></tr>
<? } ?>
</table>
</td>
</tr>
</table>
</div>

<!-- Start Conditions -->
<? if($tws_config['cpuinfo']['version']>'9.4'){ ?>
<div id='startcond_div'>
   <? if(empty($startcond_select)) $startcond_select = ''; ?>
   <table border=0 cellspacing=4 class="transparent">
   <tr><td width='180'><b>Start Condition Type:</b></td>
   <td nowrap>
   <select name="startcond_select" id="startcond_select" onchange = "startcond_change()">
      <option value=""></option>
      <option value="C" <?=($startcond_select == 'C' ? 'selected':'')?>>File Created</option>
      <option value="M" <?=($startcond_select == 'M' ? 'selected':'')?>>File Modified</option>
      <option value="J" <?=($startcond_select == 'J' ? 'selected':'')?>>Job Condition Met</option>
   </select>
   <script type="text/javascript">
   function startcond_change(){
      if( $('select#startcond_select').val() == 'J' ){
         $('div#startcond_file').hide();
            $('div#startcond_file input').attr('disabled', true);
         $('div#startcond_job').show();
            $('div#startcond_job input').attr('disabled', false);
      }
      else if($('select#startcond_select').val() == ''){
         $('div#startcond_file').hide();
            $('div#startcond_file input').attr('disabled', true);
         $('div#startcond_job').hide();
            $('div#startcond_job input').attr('disabled', true);
      }
      else{    // file condition
         $('div#startcond_file').show();
            $('div#startcond_file input').attr('disabled', false);
         $('div#startcond_job').hide();
            $('div#startcond_job input').attr('disabled', true);
      }
   }
   </script>
   </td></tr>
   </table>
   <div id="startcond_file">
      <table border=0 cellspacing=4 class="transparent">
      <tr><td width='180'><b>Workstation:</b></td>
      <td nowrap><input type="text" name="filecond_cpu" required="required" class="tws_name" maxlength='16' value="<?=(isset($filecond_cpu)?$filecond_cpu:'')?>">
      <input type="button" name="filecond_cpu_list" onClick="tws_picker_open('workstation_picker.php', 'fieldname=filecond_cpu&amp;fieldvalue=' + document.contents.filecond_cpu.value);" value="List">
      </td>
      </tr>
      <tr><td><b>Filename:</b></td>
      <td nowrap><input type="text" name="filecond_file" required="required" class='tws_file' size=32 maxlength=148 value="<?=(isset($filecond_file)?$filecond_file:'')?>">
      <input type="button" name="filecond_file_parameter" value="Add Parameter" onClick="tws_picker_open('parameter_picker.php', 'fieldname=filecond_file&amp;caret=yes&amp;insert=yes&amp;parameter_tablex=@');">
      </td></tr>
      <tr><td></td>
      <td><label><input type="checkbox" name="filecond_group" value="Y" <? if(isset($filecond_group) && $filecond_group == 'Y') echo " checked";?>>Group multiple files</label>
      </td></tr>
      <tr><td><b>Login:</b></td>
      <td nowrap><input type="text" name="filecond_login" required="required" size='25' maxlength='47' value="<?=(isset($filecond_login)?$filecond_login:'')?>">
      <input type="button" name="filecond_login_parameter" value="Add Parameter" onClick="tws_picker_open('parameter_picker.php', 'fieldname=filecond_login&amp;caret=yes&amp;insert=yes&amp;parameter_tablex=@');">
      </td></tr>
      <tr><td><b>Sample interval (s):</b></td>
      <td nowrap><input type="text" name="filecond_interval" required="required" class='tws_num' maxlength="9" value="<?=(isset($filecond_interval)?$filecond_interval:300)?>">
      <label><input type="checkbox" name="filecond_once" value="Y" <? if(isset($filecond_once) && $filecond_once == 'Y') echo " checked";?>>Start once</label>
      </td></tr>
      <tr><td><b>Output file:</b></td>
      <td nowrap><input type="text" name="filecond_output" class='tws_file' size=32 maxlength=148 value="<?=(isset($filecond_output)?$filecond_output:'')?>">
      <input type="button" name="filecond_output_parameter" value="Add Parameter" onClick="tws_picker_open('parameter_picker.php', 'fieldname=filecond_output&amp;caret=yes&amp;insert=yes&amp;parameter_tablex=@');">
      </td></tr>
      <tr><td><b>Additional Parameters:</b></td>
      <td nowrap><input type="text" name="filecond_add" size=32 maxlength=148 value="<?=(isset($filecond_add)?$filecond_add:'')?>">
      <input type="button" name="filecond_add_parameter" value="Add Parameter" onClick="tws_picker_open('parameter_picker.php', 'fieldname=filecond_add&amp;caret=yes&amp;insert=yes&amp;parameter_tablex=@');">
      </td></tr>
      <tr><td><b>Create job:</b></td>
      <td nowrap><input type="text" name="filecond_create_job" class="tws_name" value="<?=(isset($filecond_create_job)?$filecond_create_job:'')?>" style='width:28em;' maxlength="<?=$tws_config['JOB_MAXLENGTH']?>">
      </td></tr>
      </table>
   </div>
   <div id="startcond_job">
      <?/*
         STARTCOND JOB PC106#ALTPASS OUTCOND "rc=0" INTERVAL 300
        ( ALIAS ALTPASS_RES [RERUN]-if not once)
      */?>
      <table border=0 cellspacing=4 class="transparent">
      <tr><td width='180'><b>Workstation:</b></td>
      <td nowrap><input type="text" name="jobcond_cpu" required="required" class="tws_name" maxlength='16' value="<?=(isset($jobcond_cpu)?$jobcond_cpu:'')?>">
      <input type="button" name="jobcond_cpu_list" onClick="tws_picker_open('workstation_picker.php', 'fieldname=jobcond_cpu&amp;fieldvalue=' + document.contents.jobcond_cpu.value);" value="List">
      </td></tr>
      <tr><td><b>Job:</b></td>
      <td nowrap><input type="text" name="jobcond_job" required="required" class='tws_name' size=32 maxlength="<?=$tws_config['JOB_MAXLENGTH']?>" value="<?=(isset($jobcond_job)?$jobcond_job:'')?>">
      <input type="button" name="jobcond_job_list" onClick="tws_picker_open('job_picker.php', 'fieldname=jobcond_job&amp;fieldvalue=' + document.contents.elements['jobcond_job'].value + '&amp;cpux=' + document.contents.elements['jobcond_cpu'].value);" value="List">
      </td></tr>
      <tr><td><b>Output condition value:</b></td>
      <td nowrap><input type="text" name="jobcond_output" required="required" style='width:28em;' value="<?=(isset($jobcond_output)?$jobcond_output:'')?>"></td></tr>
      <tr><td><b>Sample Interval (s):</b></td>
      <td nowrap><input type="text" name="jobcond_interval" required="required" class='tws_num' maxlength="9" value="<?=(isset($jobcond_interval)?$jobcond_interval:300)?>">
      <label><input type="checkbox" name="jobcond_once" value="Y" <? if(isset($jobcond_once) && $jobcond_once == 'Y') echo " checked";?>>Start once</label>
      </td></tr>
      <tr><td><b>Create job:</b></td>
      <td nowrap><input type="text" name="jobcond_create_job" class="tws_name" value="<?=(isset($jobcond_create_job)?$jobcond_create_job:'')?>" style='width:28em;' maxlength="<?=$tws_config['JOB_MAXLENGTH']?>">
      </td></tr>
      </table>
   </div>
   <script> startcond_change(); </script>
</div>
<? } ?>

<!-- JOBS -->

<div id='jobs'>

<table border=0 cellspacing=0 class="transparent standard">
<tr><td colspan=2><h3>Current Jobs</h3></td></tr>
<tr>
   <td rowspan=4 align="center" >
      <select name="jobs" id="jobs" size=16 style="min-width:36em;" multiple="multiple" onChange="selectJob('jobs','showjob');">
      <?
      /* Prepared for IWS 9.5.2
        if (is_array($jobname)) {

            foreach ($jobname as $index => $value) {
               $jname = $value;     // User can change aliases, and then returns from saving JS
               if(preg_match('/ as /i', $jname))
                  $jname = substr($jname, 0, strpos($jname, ' '));
               if (!empty($jobalias[$value]))
                  $jname .= " AS $jobalias[$value]";

               list($wsname, $jname) = explode('#', $jname);

               //  IWS 9.5
               if ($tws_config['cpuinfo']['version'] >=9.500){
                  $jsname = $js_folder[$value].$js_name;
               }
               //  IWS 9.5.2
               if ($tws_config['cpuinfo']['version'] >=9.5002)
                  $wsname = $ws_folder[$value].$wsname;

               // $jname = "$wsname#$jsname";
               echo "<option value=\"".htmlspecialchars($wsname)."\">".htmlspecialchars($job_name)."</option>\n";
            }
         }
      */
      ?>

      <? if (is_array($jobname)) {
            foreach ($jobname as $index => $value) {
               $jname = $value;     // User can change aliases, and then returns from saving JS
               if(preg_match('/ as /i', $jname))
                  $jname = substr($jname, 0, strpos($jname, ' '));
               if (!empty($jobalias[$value]))
                  $jname .= " AS $jobalias[$value]";
               echo "<option value=\"".htmlspecialchars($jname)."\">".htmlspecialchars($jname)."</option>\n";
            }
         } ?>
      </select>
   </td>
   <td> </td>
   <td rowspan=4 id="jobproperties" valign='top'> </td>
</tr>
<tr><td> <input type="image" src="images/MoveUp.gif" title="Up" name="up" alt="Up" value="Up" onClick="movecolup('jobs'); return false;"></td></tr>
<tr><td> <input type="image" src="images/MoveDown.gif" title="Down" name="down" alt="Down" value="Down" onClick="movecoldown('jobs'); return false;"></td></tr>
<tr><td> </td></tr>
<tr><td> </td></tr>

<tr><td align="center" colspan=2> <input type="text" name="showjob" size=58 maxlength=58 readonly></td></tr>
<tr><td colspan=2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="button" name="setdep" value="Job Properties" disabled onClick="modifyJob('jobs', '<?=$action?>');"/>&nbsp;&nbsp;
<? if (!defined('IWD_PROCMAN')) { ?>
   <input type="button" name="jobinfo" value="Job Definition" disabled onClick="displayJobDef('jobs');"/>&nbsp;&nbsp;
<? } ?>
   <input type="button" name="deletejob" value="Remove Job Instance" disabled onClick="removeJob('jobs');"/>
</td></tr>

<tr><td colspan=2> </td></tr>
<tr><td colspan=2><h3>Add New Job Instance</h3></td></tr>
<tr><td colspan=2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="button" name="addjob" value="Add Existing Job" onClick="tws_picker_open('addjob_picker.php', 'allowmultiple=yes');">&nbsp;&nbsp;
<? if (!defined('IWD_PROCMAN')) { ?>
   <input type="button" name="newjob" value="Create New Job Definition" onClick="window.open('tws_add_job.php?newjob=yes','newjob','width=' + newjobwidth + ',height=' + newjobheight + ',toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=yes');"/>
<? } ?>
</td></tr>
</table>
   <script type="text/javascript">
   if ( $('select[name="jobs"] option:selected').size() == 0 ) {
      $('input[name="setdep"]').prop('disabled', 'disabled');
      $('input[name="jobinfo"]').prop('disabled', 'disabled');
      $('input[name="deletejob"]').prop('disabled', 'disabled');
   }
   </script>
</div>

<br>

<div style="display: none;">
<table id="storage" border=0 cellspacing=0>
<?    // All information about every JOB
   if (is_array($jobdescription)) {
      foreach ($jobdescription as $index => $value)
         if(!empty($value))
         echo "<tr><td><input type='hidden' name='jobdescription[$index]' value='$value'></td></tr>\n";
   }
   if (is_array($jobalias)) {
      foreach ($jobalias as $index => $value)
         if(!empty($value))
         echo "<tr><td><input type='hidden' name='jobalias[$index]' value='$value'></td></tr>\n";
   }
   if (is_array($job_folder)) {
      foreach ($job_folder as $index => $value)
         if(!empty($value)){
            echo "<tr><td><input type='hidden' name='job_folder[$index]' value='$value'></td></tr>\n";
         }
   }
   if (is_array($jobathour)) {
      foreach ($jobathour as $index => $value)
         if(!empty($value))
         echo "<tr><td><input type='hidden' name='jobathour[$index]' value='$value'></td></tr>\n";
   }
   if (is_array($jobatminute)) {
      foreach ($jobatminute as $index => $value)
         if(!empty($value))
         echo "<tr><td><input type='hidden' name='jobatminute[$index]' value='$value'></td></tr>\n";
   }
   if (is_array($jobatplusdays)) {
      foreach ($jobatplusdays as $index => $value)
         if(!empty($value))
         echo "<tr><td><input type='hidden' name='jobatplusdays[$index]' value='$value'></td></tr>\n";
   }
      if (is_array($job_time_dependent)) {
      foreach ($job_time_dependent as $index => $value)
         if(!empty($value))
         echo "<tr><td><input type='hidden' name='job_time_dependent[$index]' value='$value'></td></tr>\n";
   }
   if (is_array($jobuntilhour)) {
      foreach ($jobuntilhour as $index => $value)
         if(!empty($value))
         echo "<tr><td><input type='hidden' name='jobuntilhour[$index]' value='$value'></td></tr>\n";
   }
   if (is_array($jobuntilminute)) {
      foreach ($jobuntilminute as $index => $value)
         if(!empty($value))
         echo "<tr><td><input type='hidden' name='jobuntilminute[$index]' value='$value'></td></tr>\n";
   }
   if (is_array($jobuntilplusdays)) {
      foreach ($jobuntilplusdays as $index => $value)
         if(!empty($value))
         echo "<tr><td><input type='hidden' name='jobuntilplusdays[$index]' value='$value'></td></tr>\n";
   }
   if (is_array($jobonuntil)) {
      foreach ($jobonuntil as $index => $value)
         if(!empty($value))
         echo "<tr><td><input type='hidden' name='jobonuntil[$index]' value='$value'></td></tr>\n";
   }
   if (is_array($jobdeadlinehour)) {
      foreach ($jobdeadlinehour as $index => $value)
         if(!empty($value))
         echo "<tr><td><input type='hidden' name='jobdeadlinehour[$index]' value='$value'></td></tr>\n";
   }
   if (is_array($jobdeadlineminute)) {
      foreach ($jobdeadlineminute as $index => $value)
         if(!empty($value))
         echo "<tr><td><input type='hidden' name='jobdeadlineminute[$index]' value='$value'></td></tr>\n";
   }
   if (is_array($jobdeadlineplusdays)) {
      foreach ($jobdeadlineplusdays as $index => $value)
         if(!empty($value))
         echo "<tr><td><input type='hidden' name='jobdeadlineplusdays[$index]' value='$value'></td></tr>\n";
   }
   // IWS 9.4
   if (is_array($jobdeadlineaction)) {
      foreach ($jobdeadlineaction as $index => $value)
         if(!empty($value))
         echo "<tr><td><input type='hidden' name='jobdeadlineaction[$index]' value='Y'></td></tr>\n";
   }
   if (is_array($jobeveryhour)) {
      foreach ($jobeveryhour as $index => $value)
         if(!empty($value))
         echo "<tr><td><input type='hidden' name='jobeveryhour[$index]' value='$value'></td></tr>\n";
   }
   if (is_array($jobeveryminute)) {
      foreach ($jobeveryminute as $index => $value)
         if(!empty($value))
         echo "<tr><td><input type='hidden' name='jobeveryminute[$index]' value='$value'></td></tr>\n";
   }
   // TWS 9.X Max/Min Duration
   if (!empty($maxdur_type) && $maxdur_type != '-') {
      foreach ($maxdur_type as $index => $value){
         echo "<tr><td><input type='hidden' name='maxdur_type[$index]' value='$value'></td></tr>\n";
         echo "<tr><td><input type='hidden' name='maxdur_action[$index]' value='$maxdur_action[$index]'></td></tr>\n";
         if(!empty($maxdur_hour[$index]))
            echo "<tr><td><input type='hidden' name='maxdur_hour[$index]' value='$maxdur_hour[$index]'></td></tr>\n";
         if(!empty($maxdur_minute[$index]))
            echo "<tr><td><input type='hidden' name='maxdur_minute[$index]' value='$maxdur_minute[$index]'></td></tr>\n";
         if(!empty($maxdur_percent[$index]))
            echo "<tr><td><input type='hidden' name='maxdur_percent[$index]' value='$maxdur_percent[$index]'></td></tr>\n";
      }
   }
   if (!empty($mindur_type) && $mindur_type != '-') {
      foreach ($mindur_type as $index => $value){
         echo "<tr><td><input type='hidden' name='mindur_type[$index]' value='$value'></td></tr>\n";
         echo "<tr><td><input type='hidden' name='mindur_action[$index]' value='$mindur_action[$index]'></td></tr>\n";
         if(!empty($mindur_hour[$index]))
            echo "<tr><td><input type='hidden' name='mindur_hour[$index]' value='$mindur_hour[$index]'></td></tr>\n";
         if(!empty($mindur_minute[$index]))
            echo "<tr><td><input type='hidden' name='mindur_minute[$index]' value='$mindur_minute[$index]'></td></tr>\n";
         if(!empty($mindur_percent[$index]))
            echo "<tr><td><input type='hidden' name='mindur_percent[$index]' value='$mindur_percent[$index]'></td></tr>\n";
      }
   }


   if (is_array($jobtime_zone)) {
      foreach ($jobtime_zone as $index => $value)
         if(!empty($value))
         echo "<tr><td><input type='hidden' name='jobtime_zone[$index]' value='$value'></td></tr>\n";
   }
   if (is_array($jobpriority)) {
      foreach ($jobpriority as $index => $value)
         echo "<tr><td><input type='hidden' name='jobpriority[$index]' value='$value'></td></tr>\n";
   }
   if (is_array($jobconfirmed)) {
      foreach ($jobconfirmed as $index => $value)
         if(!empty($value))
         echo "<tr><td><input type='hidden' name='jobconfirmed[$index]' value='$value'></td></tr>\n";
   }
   if (is_array($jobkeyjob)) {
      foreach ($jobkeyjob as $index => $value)
         if(!empty($value))
         echo "<tr><td><input type='hidden' name='jobkeyjob[$index]' value='$value'></td></tr>\n";
   }
   if (is_array($jobcritical)) {
      foreach ($jobcritical as $index => $value)
         if(!empty($value))
         echo "<tr><td><input type='hidden' name='jobcritical[$index]' value='$value'></td></tr>\n";
   }
   if (is_array($jobnop)) {
      foreach ($jobnop as $index => $value)
         if(!empty($value))
         echo "<tr><td><input type='hidden' name='jobnop[$index]' value='$value'></td></tr>\n";
   }

   if (is_array($jobfollowsjobstreamcpu)) {
      foreach ($jobfollowsjobstreamcpu as $job => $jobarray) {
         foreach ($jobarray as $index => $value) {
            echo "<tr><td><input type='hidden' name='jobfollowsjobstreamcpu[$job][$index]' value='$value'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobstreamname[$job][$index]'     value='".$jobfollowsjobstreamname[$job][$index]."'></td></tr>\n";
            if(!empty($job_predstream_folder[$job][$index]))
               echo "<tr><td><input type='hidden' name='job_predstream_folder[$job][$index]'     value='".$job_predstream_folder[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobstreammatching[$job][$index]' value='".$jobfollowsjobstreammatching[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobstreammatchingrelativefromdir[$job][$index]'    value='".$jobfollowsjobstreammatchingrelativefromdir[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobstreammatchingrelativefromhour[$job][$index]'   value='".$jobfollowsjobstreammatchingrelativefromhour[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobstreammatchingrelativefromminute[$job][$index]' value='".$jobfollowsjobstreammatchingrelativefromminute[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobstreammatchingrelativetodir[$job][$index]'      value='".$jobfollowsjobstreammatchingrelativetodir[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobstreammatchingrelativetohour[$job][$index]'     value='".$jobfollowsjobstreammatchingrelativetohour[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobstreammatchingrelativetominute[$job][$index]'   value='".$jobfollowsjobstreammatchingrelativetominute[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobstreammatchingabsolutefromdir[$job][$index]'    value='".$jobfollowsjobstreammatchingabsolutefromdir[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobstreammatchingabsolutefromhour[$job][$index]'   value='".$jobfollowsjobstreammatchingabsolutefromhour[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobstreammatchingabsolutefromminute[$job][$index]' value='".$jobfollowsjobstreammatchingabsolutefromminute[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobstreammatchingabsolutefromdays[$job][$index]'   value='".$jobfollowsjobstreammatchingabsolutefromdays[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobstreammatchingabsolutetodir[$job][$index]'      value='".$jobfollowsjobstreammatchingabsolutetodir[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobstreammatchingabsolutetohour[$job][$index]'     value='".$jobfollowsjobstreammatchingabsolutetohour[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobstreammatchingabsolutetominute[$job][$index]'   value='".$jobfollowsjobstreammatchingabsolutetominute[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobstreammatchingabsolutetodays[$job][$index]'     value='".$jobfollowsjobstreammatchingabsolutetodays[$job][$index]."'></td></tr>\n";
            // Conditions
            if($tws_config['cpuinfo']['version']>='9.3'){
               echo "<tr><td><input type='hidden' name='job_js_abend[$job][$index]' value='".$job_js_abend[$job][$index]."'></td></tr>\n";
               echo "<tr><td><input type='hidden' name='job_js_success[$job][$index]' value='".$job_js_success[$job][$index]."'></td></tr>\n";
               echo "<tr><td><input type='hidden' name='job_js_suppress[$job][$index]' value='".$job_js_suppress[$job][$index]."'></td></tr>\n";
            }
            // JOIN
            if($tws_config['cpuinfo']['version']>='9.4'){
               echo "<tr><td><input type='hidden' name='job_js_join_name[$job][$index]' value='".$job_js_join_name[$job][$index]."'></td></tr>\n";
               echo "<tr><td><input type='hidden' name='job_js_join_quantity[$job][$index]' value='".$job_js_join_quantity[$job][$index]."'></td></tr>\n";
               echo "<tr><td><input type='hidden' name='job_js_join_description[$job][$index]' value='".$job_js_join_description[$job][$index]."'></td></tr>\n";
            }
         }
      }
   }
   if (is_array($jobfollowsjobname)) {
      foreach ($jobfollowsjobname as $job => $jobarray) {
         foreach ($jobarray as $index => $value) {
            echo "<tr><td><input type='hidden' name='jobfollowsjobcpu[$job][$index]'       value='".$jobfollowsjobcpu[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobjobstream[$job][$index]' value='".$jobfollowsjobjobstream[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobname[$job][$index]'      value='".$jobfollowsjobname[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobmatching[$job][$index]'  value='".$jobfollowsjobmatching[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobmatchingrelativefromdir[$job][$index]'    value='".$jobfollowsjobmatchingrelativefromdir[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobmatchingrelativefromhour[$job][$index]'   value='".$jobfollowsjobmatchingrelativefromhour[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobmatchingrelativefromminute[$job][$index]' value='".$jobfollowsjobmatchingrelativefromminute[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobmatchingrelativetodir[$job][$index]'      value='".$jobfollowsjobmatchingrelativetodir[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobmatchingrelativetohour[$job][$index]'     value='".$jobfollowsjobmatchingrelativetohour[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobmatchingrelativetominute[$job][$index]'   value='".$jobfollowsjobmatchingrelativetominute[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobmatchingabsolutefromdir[$job][$index]'    value='".$jobfollowsjobmatchingabsolutefromdir[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobmatchingabsolutefromhour[$job][$index]'   value='".$jobfollowsjobmatchingabsolutefromhour[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobmatchingabsolutefromminute[$job][$index]' value='".$jobfollowsjobmatchingabsolutefromminute[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobmatchingabsolutefromdays[$job][$index]'   value='".$jobfollowsjobmatchingabsolutefromdays[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobmatchingabsolutetodir[$job][$index]'      value='".$jobfollowsjobmatchingabsolutetodir[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobmatchingabsolutetohour[$job][$index]'     value='".$jobfollowsjobmatchingabsolutetohour[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobmatchingabsolutetominute[$job][$index]'   value='".$jobfollowsjobmatchingabsolutetominute[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsjobmatchingabsolutetodays[$job][$index]'     value='".$jobfollowsjobmatchingabsolutetodays[$job][$index]."'></td></tr>\n";
            if($tws_config['cpuinfo']['version']>='9.3'){
               echo "<tr><td><input type='hidden' name='job_job_execute[$job][$index]' value='".$job_job_execute[$job][$index]."'></td></tr>\n";
               echo "<tr><td><input type='hidden' name='job_job_abend[$job][$index]' value='".$job_job_abend[$job][$index]."'></td></tr>\n";
               echo "<tr><td><input type='hidden' name='job_job_fail[$job][$index]' value='".$job_job_fail[$job][$index]."'></td></tr>\n";
               echo "<tr><td><input type='hidden' name='job_job_success[$job][$index]' value='".$job_job_success[$job][$index]."'></td></tr>\n";
               echo "<tr><td><input type='hidden' name='job_job_suppress[$job][$index]' value='".$job_job_suppress[$job][$index]."'></td></tr>\n";
               if(!empty($job_job_codemaps[$job][$index])){
                  $dd = 0;
                  foreach($job_job_codemaps[$job][$index] as $codemap){
                        echo "<tr><td><input type='hidden' name='job_job_codemaps[$job][$index][$dd]' value='$codemap'></td></tr>\n";
                        $dd++;
                     // }
                  }
               }
               if(!empty($job_job_condition[$job][$index])){
                  $dd = 0;
                  foreach($job_job_condition[$job][$index] as $dd=>$condition){
                     echo "<tr><td><input type='hidden' name='job_job_condition[$job][$index][$dd]' value='$condition'></td></tr>\n";
                     $dd++;
                  }
               }
            }
            // JOIN
            if($tws_config['cpuinfo']['version']>='9.4'){
               echo "<tr><td><input type='hidden' name='job_job_join_name[$job][$index]' value='".$job_job_join_name[$job][$index]."'></td></tr>\n";
               echo "<tr><td><input type='hidden' name='job_job_join_quantity[$job][$index]' value='".$job_job_join_quantity[$job][$index]."'></td></tr>\n";
               echo "<tr><td><input type='hidden' name='job_job_join_description[$job][$index]' value='".$job_job_join_description[$job][$index]."'></td></tr>\n";
            }
         }
      }
   }
   if (is_array($jobfollowsnetworkagent)) {
      foreach ($jobfollowsnetworkagent as $job => $jobarray) {
         foreach ($jobarray as $index => $value) {
            echo "<tr><td><input type='hidden' name='jobfollowsnetworkagent[$job][$index]' value='$value'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobfollowsnetworkdep[$job][$index]' value='".$jobfollowsnetworkdep[$job][$index]."'></td></tr>\n";
         }
      }
   }
   if (is_array($jobpromptname)) {
      foreach ($jobpromptname as $job => $jobarray) {
         foreach ($jobarray as $index => $value)
            echo "<tr><td><input type='hidden' name='jobpromptname[$job][$index]' value='$value'></td></tr>\n";
      }
   }
   if (is_array($jobprompttext)) {
      foreach ($jobprompttext as $job => $jobarray) {
         foreach ($jobarray as $index => $value)
            echo "<tr><td><input type='hidden' name='jobprompttext[$job][$index]' value='$value'></td></tr>\n";
      }
   }
   if (is_array($jobopenscpu)) {
      foreach ($jobopenscpu as $job => $jobarray) {
         foreach ($jobarray as $index => $value) {
            echo "<tr><td><input type='hidden' name='jobopenscpu[$job][$index]'  value='$value'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobopensfile[$job][$index]' value='".$jobopensfile[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobopensqual[$job][$index]' value='".$jobopensqual[$job][$index]."'></td></tr>\n";
         }
      }
   }
   if (is_array($jobneedscpu)) {
      foreach ($jobneedscpu as $job => $jobarray) {
         foreach ($jobarray as $index => $value) {
            echo "<tr><td><input type='hidden' name='jobneedscpu[$job][$index]' value='$value'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobresource[$job][$index]' value='".$jobresource[$job][$index]."'></td></tr>\n";
            echo "<tr><td><input type='hidden' name='jobunits[$job][$index]'    value='".$jobunits[$job][$index]."'></td></tr>\n";
         }
      }
   }
?>
</table>
</div>
</div>

<script>
   $(function() {

      $('#tabs').tabs();
      $('#tabs').css('background-color','transparent');
      $('#tabs').css('border','none 0px');

      if( $('input[name="freedays_option"][value="default"]').is(':checked') )
         enable_freedays(false);
      else
         enable_freedays(true);

   <? if($display=='yes'){ ?>
         $("input, textarea").attr('readonly', true);
         $('input[type="checkbox"], input[type="radio"]').attr('disabled', true);
         $("select").attr('disabled', true);
         $('select#jobs').attr('disabled', false);
   <? } ?>
   });
   showMatch(document.getElementById('matching').value);
   $( "form" ).submit(function() {
      setjobnames('storage');
   });
</script>

<?
}

/*  tws_show_calendar_form
$values:
calendar_name
calendar_description
dates in format: 'yyyy-mm-dd','yyyy-mm-dd','yyyy-mm-dd'
 */
function tws_show_calendar_form($values, $action){
   global  $tws_config;
   $action = strtolower($action);
if (defined('IWD_PROCMAN')) {
?>
   <script type="text/javascript" src="/jquery/jquery.js"></script>
   <script type="text/javascript" src="/jquery/jquery-ui.js"></script>
   <script type="text/javascript" src="/tws_js_functions.js"></script>

   <link rel="stylesheet" type="text/css" href="/jquery/jquery-ui_default.css"/>
   <link rel="stylesheet" type="text/css" href="/css/wai_default.css"/>
<? }
   tws_specialchars($values);

   if($action=='modify' || $action=='display') $disabled = 'disabled';
   else $disabled = '';

   if ($action=='display') {
      $readonly = 'readonly';
      $display = 'yes';
   } else {
      $readonly  = '';
      $display = '';
      echo '<script type="text/javascript" src="/tws_js_validators.js"></script>'."\n";
   }
   foreach($values as $key=>$value){
      if($key !== 'action')
         $$key = $value;
   }
   $firstdow=tws_profile('firstdow');
   if (empty($firstdow))
      $firstdow="0";
   $curyear = date('Y');
   // all dates were remade into userdate format instead of iso
   if(!empty($calendar_dates)){
      $dates = explode(',', $calendar_dates);
      foreach($dates as $i=>$date){
         $dates[$i]=trim($date,'\'" ');
         if (!preg_match('/\d{4}-\d{2}-\d{2}/', $dates[$i])) {  //in PROCMAN the ISO format is stored during the processing
            $dates[$i] = tws_userdate_to_iso($dates[$i], NULL, TRUE);
         }
      }
      // calendar_dates must have format "'iso','iso','iso'" etc.
      $calendar_dates = '\''.implode("','", $dates).'\'';
   }
?>
<script type="text/javascript" src="jquery/js/jquery-ui-1.9.2.datepicker.min.js"></script>
<script src="CalendarPicker/jquery-ui.multidatespicker.js"></script>
<link rel="stylesheet" type="text/css" href="CalendarPicker/css/mdp.css">

<script type="text/javascript">
$(document).ready(function () {

   $('#full_year').multiDatesPicker({
      numberOfMonths: [3,4],
      dateFormat: "yy-mm-dd",
      firstDay: <?=$firstdow?>,
      <? if(trim($calendar_dates,'\', ')!='') {?>addDates: [<?=$calendar_dates?>],<?}?>
      defaultDate: "<?=$curyear?>-01-01",
      changeYear: true,
      altField: '#altField'
   });
});
</script>

<table border=0 cellspacing=0>
<? if ($tws_config['cpuinfo']['version']>='9.5002'){ ?>
<tr>
   <td><b>Calendar Folder:</b></td>
   <td><input type="text" name="calendar_folder" required="required" size=60 maxlength=200 value="<?=$values['calendar_folder']?>" <?=$disabled?> >
       <? if($action != 'modify' && $action != 'display'){ ?>
       	<input type="button" name="folder_list" onClick="tws_picker_open('folder_picker.php', 'fieldname=calendar_folder&fieldvalue=' + document.contents.calendar_folder.value);" value="List" >
      <? }
      if($action == 'modify'){ ?>
         <input type="hidden" name="calendar_folder" value="<?=$values['calendar_folder']?>" >
      <? } ?>
   </td>
</tr>
<? } ?>

<tr>
<td class=standard width=140><b>Calendar Name:</b>
</td>
<td class=standard>
<input type="text" name="calendar_name" class="tws_name" required="required" size='12' maxlength='8' value="<?=$calendar_name?>" <?=$disabled?> >
<? if($action == 'modify'){ ?>
   <input type="hidden" name="calendar_name" value="<?=$calendar_name?>">
<? } ?>
</td>
</tr>
<tr>
<td class=standard width=140><b>Description:</b></td>
<td class=standard>
<input type="text" name="calendar_description" size='64' maxlength='64' value="<?=$calendar_description?>" >
</td>
</tr>
</table>
<input type="hidden" id="altField" name="calendar_dates">
<br><br>

<!-- div for Calendar -->
<div id="full_year" class="box"></div>


<?
}
/*
Functions
      tws_****_to_arr($id)

    get db_object

*/


function tws_job_to_arr($id){
   global $tws_config;
   global $job_folder, $job_folder_expr; // tws 9.5 folders:

tws_log("-- tws_job_to_arr. Patameter: $id");

   list($ws, $job) = explode('#', $id);

   $arr = tws_get_job_def_data($ws, $job);

tws_log("-- tws_job_to_arr. tws_get_job_def_data: ".var_export($arr, true));

   // if($tws_config['cpuinfo']['version']>='9.5002')
   list($ws_folder, $ws_name) = tws_divide_folder($ws); // $ws_folder is empty if doesn't exist

   list($job_folder, $job_name) = tws_divide_folder($job); // $ws_folder is empty if doesn't exist

   // tws 9.5002 folders:
   if(!empty($ws_folder))
      $arr['workstation_folder'] = $ws_folder;
   // tws 9.5 folders:
   if(!empty($job_folder))
      $arr['job_folder'] = $job_folder;

   if($arr['task_type'] == 'SAP'){
      $jsdl_data = tws_get_job_sap_data($arr['script']);
      $arr['r3_logon'] = $arr['logon'];
   }
   elseif ($arr['task_type']!='WINDOWS' && $arr['task_type']!='UNIX' && $arr['task_type']!='OTHER' )
      $jsdl_data = tws_get_job_jsdl_data($arr['script']);

   if(!empty($jsdl_data))
      foreach ($jsdl_data as $key => $value)
         $arr[$key] = $value;

   if(isset($arr['variables'])) {
      foreach($arr['variables'] as $name=>$val) {
         $arr['var_name'][] = $name;
         $arr['var_val'][] = $val;
      }
   }
   $arr['job'] = $arr['name'];
   return $arr;
}

function tws_parameter_to_arr($id){
   $arr=tws_get_parameters($id);
   foreach($arr as $var=>$val)
      $arr[$var] = $val[0];
   return $arr;
}

function tws_parameter_table_to_arr($id){
   $arr = tws_get_parameter_tables($id);
   foreach($arr as $var=>$val)
      $arr[$var] = $val[0];
   $params = tws_get_parameters("$id.@");
   if(empty($params['parameter_name']))
      return $arr;
   foreach($params['parameter_name'] as $i=>$name){
      $arr['parameter_name'][] = $name;
      $arr['parameter_value'][] = $params['parameter_value'][$i];
   }
   return $arr;
}

function tws_resource_to_arr($id){
   $arr = tws_get_resources($id);
   foreach($arr as $var=>$val)
      $arr[$var] = $val[0];
   return $arr;
}

function tws_prompt_to_arr($id){
   $arr = tws_get_prompts($id);
   foreach($arr as $var=>$val)
      $arr[$var] = $val[0];
   return $arr;
}

// Get $id stream from DB
function tws_jobstream_to_arr($id){
   global $tws_config;

   tws_log('-- tws_jobstream_to_arr (start at '.basename(__FILE__).'['.__LINE__.'])');
   tws_log("-- tws_jobstream_to_arr Parameters: id = $id");

   list($ws_name, $js_name) = explode('#', $id);

   $ws = $ws_name; // $ws with Folder
   $js = $js_name; // $js with Folder

// iws 9.5: STREAM FOLDER
    if($tws_config['cpuinfo']['version'] >= '9.5'){
      list($js_folder, $js_name) = tws_divide_folder($js_name);
       $arr['js_folder'] = $js_folder;
    }
    $arr['js_name'] = $js_name;

// iws 9.5.2: WORKSTATION FOLDER
   if($tws_config['cpuinfo']['version'] >= '9.5002'){
      list($ws_folder, $ws_name) = tws_divide_folder($ws_name);
      $arr['ws_folder'] = $ws_folder;
   }
   $arr['ws_name'] = $ws_name;


   list($js_name, $valid) = explode(':', $js_name);
   if($valid)
      $valid=tws_make_iso_valid_from($valid);

   $arr = tws_get_jobstream_generic_data($ws, $js, $valid);    // Get from appropriate Folder!!

   if(empty($arr))
      tws_err(" can't get jobstream_generic_data for: ws = $ws, js = $js, valid = $valid");

   tws_log("-- tws_jobstream_to_arr, generic_data: ".var_export($arr, true) );

// IWS 9.4 startcond
   if($tws_config['cpuinfo']['version']>'9.4'){
      $tmp = tws_get_stream_startcond ($ws, $js, $valid);
      if(!empty($tmp))
         foreach($tmp as $var=>$val)
            $arr[$var] = $val;
   }

   $run_data = tws_get_jobstream_runcycle_data($ws, $js, $valid);
   if(!empty($run_data))
      foreach($run_data['rc'] as $var=>$val)
         $arr[$var] = $val;

   $tmp = tws_get_jobstream_dep_jobstream($ws, $js, $valid);
   if(!empty($tmp))
      foreach($tmp as $var=>$val)
         $arr[$var] = $val;

   $tmp = tws_get_jobstream_dep_job($ws, $js, $valid);
   if(!empty($tmp))
      foreach($tmp as $var=>$val)
         $arr[$var] = $val;

   $tmp = tws_get_jobstream_dep_net($ws, $js, $valid);
   if(!empty($tmp))
      foreach($tmp as $var=>$val)
         $arr[$var] = $val;

   $tmp = tws_get_jobstream_dep_res($ws, $js, $valid);
   if(!empty($tmp))
      foreach($tmp as $var=>$val)
         $arr[$var] = $val;

// GET JOBSTREAM JOBS
   $tmp = tws_get_jobstream_jobs($ws, $js, $valid);
   if(!empty($tmp))
      foreach($tmp as $var=>$val)
         $arr[$var] = $val;

   if($tws_config['cpuinfo']['version']<'9.5'){      // INTERNETWORK are in tws_get_job_dep_res from IWAD 4.1
      $tmp = tws_get_job_dep_net($ws, $js, $valid, '*');
      if(!empty($tmp))
         foreach($tmp as $var=>$val)
            $arr[$var] = $val;
   }

   $tmp = tws_get_job_dep_jobstream($ws, $js, $valid, '*');
   if(!empty($tmp))
      foreach($tmp as $var=>$val)
         $arr[$var] = $val;

   $tmp = tws_get_job_dep_job($ws, $js, $valid, '*');
   if(!empty($tmp))
      foreach($tmp as $var=>$val)
         $arr[$var] = $val;

   $tmp = tws_get_job_dep_res($ws, $js, $valid, '*');
   if(!empty($tmp))
      foreach($tmp as $var=>$val)
         $arr[$var] = $val;

   return $arr;
}

function tws_calendar_to_arr($id){
   $arr = tws_get_calendars($id);
   if($arr == false || $arr['calendar_num']==0 || $arr['calendar_num']>1){
      tws_error("Unable to list calendars");
      return false;
   }

   foreach($arr as $var=>$val){
      if(is_array($val))
         $arr[$var] = $val[0];
      else $arr[$var] = $val;
   }
   $dates = "";
   $calendar_dates=explode(',',$arr['calendar_dates']);
   foreach ($calendar_dates as $date){
      // all dates are remade into userdate format instead of iso
      //$dates .= "'".substr($date, 0,4)."-".substr($date, 4,2)."-".substr($date, 6,2)."',";
       $date = substr($date, 0,4)."-".substr($date, 4,2)."-".substr($date, 6,2);
       $dates .= "'".tws_iso_to_userdate($date, null, true)."',";
   }
   $dates = substr($dates, 0, -1);
   $arr['calendar_dates'] = $dates;
   return $arr;
}

/*
Functions
            tws_****_to_composer($array)

form appropriate text definition from $array

*/

function tws_resource_to_composer($values, $head){
   $cmd = '';
   if($head) $cmd = "\$resource\n";
   $cmd .= $values['resource_workstation'].'#'.$values['resource_name'].' '.$values['resource_quantity'].' "'.addcslashes($values['resource_description'],'"').'"';
   return $cmd;
}

function tws_prompt_to_composer($values, $head){
   $cmd = '';
   if($head) $cmd = "\$prompt\n";
   if(!empty($values['prompt_folder']))
      $values['prompt_name'] = $values['prompt_folder'].$values['prompt_name'];
   $cmd .= $values['prompt_name'].' "'.addcslashes($values['prompt_text'],'"').'"';
   return $cmd;
}

function tws_parameter_to_composer($values, $head){
   $parm_name = ($values['parameter_table']!='' ? $values['parameter_table'].'.' : '').$values['parameter_name'];
   $cmd = '';
   if($head) $cmd = "\$parm\n";
   $cmd .= $parm_name .' "'.addcslashes($values['parameter_value'],'"').'"';
   return $cmd;
}

function tws_parameter_table_to_composer($values, $head){
   global $tws_config;

	$cmd = "VARTABLE ";
	if(!empty($values['parameter_table_folder'])) {
      $cmd .= $values['parameter_table_folder'];
	}
	$cmd .=$values['parameter_table_name']."\n";

   if ($values['parameter_table_description'] != '') $cmd .= 'DESCRIPTION "'.addcslashes($values['parameter_table_description'],'"')."\"\n";
   if ($values['parameter_table_default']=='yes') $cmd .= "ISDEFAULT\n";
   $cmd .="MEMBERS\n";
   if (is_array($values['parameter_name'])) {
      foreach ($values['parameter_name'] as $j=>$pname) {
         if (trim($pname)=='') continue;
         $cmd .= strtoupper(trim($pname))." \"".addcslashes($values['parameter_value'][$j],'"')."\"\n";
      }
   }
   $cmd .= "END\n";
   return $cmd;
}

function tws_job_to_composer($values, $head){
   global $tws_config;
   global $job_folder;
   foreach($values as $var=>$val)
      $$var = $val;

      if($task_type=='WINDOWS' || $task_type=='UNIX' || $task_type=='OTHER') {
         if ($job_type == "command")
            $job_type_string="DOCOMMAND";
         else $job_type_string="SCRIPTNAME";
         $interactive = tws_yesno($interactive);
         $description=str_replace('\"', '"', $description);
         $script=str_replace('\"', '"', $script);
         $script = addcslashes($script, '"');
      }
      elseif ($task_type=='SAP') {
         $job_type_string="SCRIPTNAME";
         $logon = $r3_logon;
         $script = tws_sap_geather_string($values);
      }
      else {
         $job_type_string="TASK";
         $script = tws_jsdl_geather_string($values);

         if($dshadow_complete == "YES" || $zshadow_complete == "YES")
            $exitcodemap = 'COMPLETE_IF_BIND_FAILS';
      }
      $description = addcslashes($description, '"');
      if(isset($logon)) $logon = addcslashes($logon, '"');
      if(isset($recovery_prompt)) $recovery_prompt = addcslashes($recovery_prompt, '"');
      if(isset($exitcodemap)) $exitcodemap = addcslashes($exitcodemap, '"');

   $cmd = '';
   if($head) $cmd = "\$JOBS\n";
   if(empty($job_folder)) $job_folder = '';
   if(empty($workstation_folder)) $workstation_folder = '';

   $cmd .= "$workstation_folder$workstation#$job_folder$job\n";
   if ($job_type_string == 'TASK')
      $cmd .= "  $job_type_string $script\n";
   else
      $cmd .= "  $job_type_string \"$script\"\n";
   if(isset($logon) && $logon!='')
      $cmd .= "  STREAMLOGON \"$logon\"\n";
   $cmd .= "  DESCRIPTION \"$description\"\n";
   if (isset($task_type) && $job_type_string != 'TASK')
      $cmd .= "  TASKTYPE $task_type\n";
   if (isset($interactive) && strtoupper($interactive) == "YES")
      $cmd .= "  INTERACTIVE\n";
   if($tws_config['cpuinfo']['version']>='9.3'){
      foreach($joc_mapping_expression as $j=>$expression){
         if(empty($expression) || empty($joc_name[$j]))
            continue;
         if($joc_succ_condition[$j] == 'Y')
            $cmd .= 'SUCCOUTPUTCOND '.$joc_name[$j].' "'.$expression.'"'."\n";
         else $cmd .= 'OUTPUTCOND '.$joc_name[$j].' "'.$expression.'"'."\n";
      }
   }
   elseif (isset($exitcodemap) && $exitcodemap != "")
      $cmd .= "  RCCONDSUCC \"$exitcodemap\"\n";

   if (isset($affinity) && $affinity != "" )
      $cmd .= "  TWSAFFINITY \"$affinity\"\n";

   $cmd .= "  RECOVERY $recovery_option ";
   if(isset($recovery_same_workstation) && $recovery_same_workstation == 'Y')
      $cmd .= "SAMEWORKSTATION ";
//   if(empty($recovery_prompt)){
      if(($recovery_repeat_hour != 0 || $recovery_repeat_minute != 0) && $recovery_repeat_occurrences != 0){
         $cmd .= "REPEATEVERY $recovery_repeat_hour$recovery_repeat_minute ";
         $cmd .= "FOR $recovery_repeat_occurrences ATTEMPTS";
      }
//   }
   $cmd .= "\n";
   if ($recovery_workstation != "" && $recovery_job != "" )
      $cmd .= "    AFTER $recovery_workstation#$recovery_job\n";
   if (!empty($recovery_prompt))
      $cmd .= "    ABENDPROMPT \"$recovery_prompt\"\n";

   return $cmd;
}

function tws_jobstream_to_composer($values, $head){
   global $tws_config;
   //ERR18606: IWD_PROCMAN - all TWS dates stored in the YYYY-MM-DD ISO format
   if (defined('IWD_PROCMAN')) {
      empty($values['validfrom']) || $values['validfrom']=tws_iso_to_userdate($values['validfrom'], NULL, TRUE);
      empty($values['validto']) || $values['validto']=tws_iso_to_userdate($values['validto'], NULL, TRUE);
      $i=0;
      while (isset($values['rc_type'][$i])) {
         empty($values['rc_validfrom'][$i]) || $values['rc_validfrom'][$i]=tws_iso_to_userdate($values['rc_validfrom'][$i], NULL, TRUE);
         empty($values['rc_validto'][$i]) || $values['rc_validto'][$i]=tws_iso_to_userdate($values['rc_validto'][$i], NULL, TRUE);
         $s=0;
         while (isset($values['date_day'][$i][$s])) {
            $values['date_day'][$i][$s]=tws_iso_to_userdate($values['date_day'][$i][$s], NULL, TRUE);
            $s++;
         }
         $i++;
      }
   }

   foreach($values as $key=>$val)
      $$key = $val;

   $cmd='';
   if (!empty($comment)) {
      $cmd .= "#\n";
      $comment_line=explode("\n",$comment);
      foreach ($comment_line as $commline) {
         $cmd .= "#".rtrim($commline,"\r")."\n";
      }
      $cmd .= "#\n";
   }

   if($tws_config['cpuinfo']['version']>='9.5'){
      if(empty($jobstream_folder))
         $jobstream_folder = '/';
      elseif(trim($jobstream_folder) != '/'){
         if(preg_match('/^\/.*/', $jobstream_folder) == 0)
            $jobstream_folder = '/'.$jobstream_folder;
         if(preg_match('/.*\/$/', $jobstream_folder) == 0)
            $jobstream_folder = $jobstream_folder.'/';
      }
      /*
         // Check if folder not exist, create it. Bad idea
         $jobstream_folder = strtoupper($jobstream_folder);
         $folders_list = tws_get_folders();
         if(!in_array($jobstream_folder, $folders_list['folder_path'])){
            $res = tws_create_folder($jobstream_folder);
            if($res != true)
               tws_error("Can't create folder '$jobstream_folder'");
         }
      */
   }
   else $jobstream_folder = '';

      $cmd .= "SCHEDULE $workstation#$jobstream_folder$jobstream\n";
      if (!empty($validfrom)) {
        if (($validfrom_iso=tws_userdate_to_iso($validfrom, NULL, TRUE))=='') {
            tws_error($validfrom, 'Unsupported validfrom date format');
            $validfrom_iso=$validfrom; //ERROR!
        }
        $cmd .= " VALIDFROM ".tws_date_from_iso($validfrom_iso)."\n"; //2016-05-12 Added "tws_userdate_to_iso" to fix the problem of lost valid from dates
      }
      if (($time_zone != "") && ($time_zone != "NULL"))
         $cmd .= " TIMEZONE $time_zone\n";

      if ($description != "")
         $cmd .= " DESCRIPTION \"".addcslashes($description,'"')."\"\n";

      if (isset($draft) && ($draft == "YES"))
         $cmd .= " DRAFT \n";

      if ($parameter_table != "" && tws_check_arg($parameter_table, 'tws_name') )
         $cmd .= " VARTABLE $parameter_table \n";

//2016-05-12 Added $values parameter by RS to fix the problem with missing runcycle definitions
      $tmp = tws_get_rc_def_from_form($values);
      foreach($tmp as $line)
         $cmd .= $line;
      if ($request == "YES")
         $cmd .= " ON REQUEST\n";

      // STARTCOND
      if(!empty($startcond_select)){      // Job Condition
         if($startcond_select == 'J'){
            if(!empty($jobcond_cpu) && !empty($jobcond_job) && !empty($jobcond_output)){
               $cmd .= 'STARTCOND JOB '. "$jobcond_cpu#$jobcond_job OUTCOND \"$jobcond_output\" ";
               if(!empty($jobcond_interval))
                  $cmd .= "INTERVAL $jobcond_interval";
               else $cmd .= "INTERVAL 300";
               $cmd .= "\n";
               if(!empty($jobcond_create_job)){
                  $cmd .= "(ALIAS $jobcond_create_job";
                  if(empty($jobcond_once))
                     $cmd .= " RERUN ";
                  $cmd .= ")\n";
               }
            }
         }
         //    File condition
         elseif(!empty($filecond_cpu) && !empty($filecond_file)){
            if($startcond_select == 'C')
               $cmd .= "STARTCOND FILECREATED ";
            else  // file_modified
               $cmd .= "STARTCOND FILEMODIFIED ";

            $cmd .= "$filecond_cpu#\"$filecond_file\" ";
            if(!empty($filecond_login))
               $cmd .= "USER \"$filecond_login\" ";
            if(!empty($filecond_interval))
               $cmd .= "INTERVAL $filecond_interval";
            else $cmd .= "INTERVAL 300";
            $cmd .= "\n";
            if(!empty($filecond_output) || !empty($filecond_add) || !empty($filecond_create_job) ){
               $cmd .= "(";
               if(!empty($filecond_create_job)){
                  $cmd .= "ALIAS $filecond_create_job ";
                  if(empty($filecond_once))
                     $cmd .= "RERUN ";
               }
               if(!empty($filecond_group))
                  $cmd .= "BATCH ";
               if(!empty($filecond_add))
                  $cmd .= "PARAMS \"$filecond_add\" ";
               if(!empty($filecond_output))
                  $cmd .= "OUTFILE \"$filecond_output\" ";
               $cmd .= ")\n";
            }
         }
      }

      if (!empty($running_rule) &&  $running_rule !== 'P' ){
         if($running_rule == 'E')
            $cmd .= " ONOVERLAP ENQUEUE\n";
         else $cmd .= " ONOVERLAP DONOTSTART\n";
      }

      if ($athour != "" && $atminute != "" && tws_check_arg($athour, 'tws_num') && tws_check_arg($atminute, 'tws_num')) {
         if($attimedep=='yes')
            $cmd .= " AT " . $athour . $atminute;
         else $cmd .= " SCHEDTIME " . $athour . $atminute;
         if ($atplusdays != "")
            $cmd .= " +$atplusdays DAYS";
         $cmd .= "\n";
      }
      if (($untilhour != "") && ($untilminute != "") && tws_check_arg($untilhour, 'tws_num') && tws_check_arg($untilminute, 'tws_num')) {
         if($tws_config['cpuinfo']['version']>'9.4' && empty($jsuntil))
            $cmd .=" JSUNTIL " . $untilhour . $untilminute;
         else
            $cmd .=" UNTIL " . $untilhour . $untilminute;
         if ($untilplusdays != "")
            $cmd .= " +$untilplusdays DAYS";
         $cmd .= "\n";
         if ($onuntil == "CONT")
            $cmd .= "  ONUNTIL CONT\n";
         elseif ($onuntil == "CANC")
            $cmd .= "  ONUNTIL CANC\n";
      }
      if ($deadlinehour != "" && $deadlineminute != "" && tws_check_arg($deadlinehour, 'tws_num') && tws_check_arg($deadlineminute, 'tws_num')) {
         $cmd .=" DEADLINE " . $deadlinehour . $deadlineminute;
         if ($deadlineplusdays != "")
            $cmd .= " +$deadlineplusdays DAYS ";
         $cmd .= "\n";
      }
      if ($carryforward == "YES")
         $cmd .= " CARRYFORWARD\n";

      switch ($matching) {
         case "SAMEDAY": //default value - no action needed
               break;
         case "PREVIOUS":
               $cmd .= " MATCHING PREVIOUS\n";
               break;
         case "RELATIVE":
               $cmd .= " MATCHING RELATIVE FROM $matchingrelativefromdir ".$matchingrelativefromhour.$matchingrelativefromminute." TO $matchingrelativetodir ".$matchingrelativetohour.$matchingrelativetominute." \n";
               break;
         case "ABSOLUTE":
               $line = " MATCHING FROM ".$matchingabsolutefromhour.$matchingabsolutefromminute;
               if ($matchingabsolutefromdays > 0) $line .= " $matchingabsolutefromdir $matchingabsolutefromdays days";
               $line .= " TO ".$matchingabsolutetohour.$matchingabsolutetominute;
               if ($matchingabsolutetodays > 0) $line .= " $matchingabsolutetodir $matchingabsolutetodays days";
               $cmd .= $line."\n";
      }

// FOLLOWS
      $js_joins = array();
      if (!empty($followsjobstreamcpu) && count($followsjobstreamcpu) > 0) {
         foreach ($followsjobstreamcpu as $index => $value) {
            if(trim($value)=='' || trim($followsjobstreamname[$index])=='')
               continue;
            $line = " FOLLOWS " . $value . "#" . $followsjobstreamname[$index] . ".@ ";
            // IWS 9.3 : conditional dependencies
            if(!empty($js_js_abend[$index]) || !empty($js_js_success[$index]) || !empty($js_js_suppress[$index])){
               $line .= ' IF ';
               if($js_js_abend[$index] == 'Y') $line .= 'ABEND|';
               if($js_js_success[$index] == 'Y') $line .= 'SUCC|';
               if($js_js_suppress[$index] == 'Y') $line .= 'SUPPR|';
               $line = substr($line, 0, -1);
            }
            switch ($followsjobstreammatching[$index]) {
               case "DEFAULT":  //nothing to do
                  break;
               case "SAMEDAY":
                     $line .= " SAMEDAY";
                     break;
               case "PREVIOUS":
                     $line .= " PREVIOUS";
                     break;
               case "RELATIVE":
                     $line .= " RELATIVE FROM ".$followsjobstreammatchingrelativefromdir[$index]." ";
                     $line .= $followsjobstreammatchingrelativefromhour[$index].$followsjobstreammatchingrelativefromminute[$index];
                     $line .= " TO ".$followsjobstreammatchingrelativetodir[$index]." ";
                     $line .= $followsjobstreammatchingrelativetohour[$index].$followsjobstreammatchingrelativetominute[$index];
                     break;
               case "ABSOLUTE":
                     $line .= " FROM ".$followsjobstreammatchingabsolutefromhour[$index].$followsjobstreammatchingabsolutefromminute[$index]." ";
                     if ($followsjobstreammatchingabsolutefromdays[$index] > 0)
                        $line .= " ".$followsjobstreammatchingabsolutefromdir[$index].$followsjobstreammatchingabsolutefromdays[$index]." days";
                     $line .= " TO ".$followsjobstreammatchingabsolutetohour[$index].$followsjobstreammatchingabsolutetominute[$index]." ";
                     if ($followsjobstreammatchingabsolutetodays[$index] > 0)
                        $line .= " ".$followsjobstreammatchingabsolutetodir[$index]." ".$followsjobstreammatchingabsolutetodays[$index]." days";
                     break;
                  }
            // IWS 9.4 JOINS
            if(!empty($js_js_join_name[$index])){
               $js_joins[$js_js_join_name[$index]]['join_description'] = $js_js_join_description[$index];
               $js_joins[$js_js_join_name[$index]]['join_quantity'] = $js_js_join_quantity[$index];
               $js_joins[$js_js_join_name[$index]]['follows'][] = $line;
               continue;
            }
            $cmd .= $line."\n";
         }
      }
      if (!empty($followsjobcpu) && count($followsjobcpu) > 0) {
         foreach ($followsjobcpu as $index => $value) {
            if(trim($value)=='' || trim($followsjobjobstream[$index])=='' || trim($followsjobname[$index])=='')
               continue;
            $line = " FOLLOWS " . $value . "#" . $followsjobjobstream[$index] . "." . $followsjobname[$index];
            // IWS 9.3 : conditional dependencies
            if(!empty($js_job_abend[$index]) || !empty($js_job_success[$index]) || !empty($js_job_suppress[$index]) || !empty($js_job_fail[$index])){
               $line .= ' IF ';
               if(!empty($js_job_abend[$index]))    $line .= 'ABEND|';
               if(!empty($js_job_success[$index]))  $line .= 'SUCC|';
               if(!empty($js_job_suppress[$index])) $line .= 'SUPPR|';
               if(!empty($js_job_fail[$index]))     $line .= 'FAIL|';
               $line = substr($line, 0, -1);
            }
            elseif(!empty($js_job_execute[$index]) && $js_job_execute[$index] == 'Y')
               $line .= ' IF EXEC';
            elseif(!empty($js_job_condition[$index])){
               $line .= ' IF ';
               foreach($js_job_condition[$index] as $codemap)
                  $line .= "$codemap|";
               $line = substr($line, 0, -1);
            }
            switch ($followsjobmatching[$index]) {
               case "DEFAULT":  //nothing to do
                  break;
               case "SAMEDAY":
                     $line .= " SAMEDAY";
                     break;
               case "PREVIOUS":
                     $line .= " PREVIOUS";
                     break;
               case "RELATIVE":
                     $line .= " RELATIVE FROM ".$followsjobmatchingrelativefromdir[$index]." ";
                     $line .= $followsjobmatchingrelativefromhour[$index].$followsjobmatchingrelativefromminute[$index];
                     $line .= " TO ".$followsjobmatchingrelativetodir[$index]." ";
                     $line .= $followsjobmatchingrelativetohour[$index].$followsjobmatchingrelativetominute[$index];
                     break;
               case "ABSOLUTE":
                     $line .= " FROM ".$followsjobmatchingabsolutefromhour[$index].$followsjobmatchingabsolutefromminute[$index]." ";
                     if ($followsjobmatchingabsolutefromdays[$index] > 0)
                        $line .= " ".$followsjobmatchingabsolutefromdir[$index].$followsjobmatchingabsolutefromdays[$index]." days";
                     $line .= " TO ".$followsjobmatchingabsolutetohour[$index].$followsjobmatchingabsolutetominute[$index]." ";
                     if ($followsjobmatchingabsolutetodays[$index] > 0)
                        $line .= " ".$followsjobmatchingabsolutetodir[$index]." ".$followsjobmatchingabsolutetodays[$index]." days";
                     break;
                  }

            // IWS 9.4 : JOINS
            if(!empty($js_job_join_name[$index])){
               $js_joins[$js_job_join_name[$index]]['join_description'] = $js_job_join_description[$index];
               $js_joins[$js_job_join_name[$index]]['join_quantity'] = $js_job_join_quantity[$index];
               $js_joins[$js_job_join_name[$index]]['follows'][] = $line;
               continue;
            }
            $cmd .= $line."\n";
         }
      }
      if (!empty($followsnetworkagent) && count($followsnetworkagent) > 0) {
         foreach ($followsnetworkagent as $index => $value) {
            if($value=='' && $followsnetworkdep[$index]=='' ) continue;
            $cmd .= " FOLLOWS " . $value . "::\"" . $followsnetworkdep[$index]."\"\n";
         }
      }
      //    FOLLOWS JOIN
      foreach($js_joins as $joinname=>$arr){
         $cmd .= "JOIN $joinname $arr[join_quantity] OF\n";
         if(!empty($arr['join_description']))
            $cmd .= 'DESCRIPTION "'.$arr['join_description'].'"'."\n";
         foreach($arr['follows'] as $str)
            $cmd .= "$str\n";
         $cmd .= "ENDJOIN\n";
      }

      if ($keysched == "YES")
         $cmd .= " KEYSCHED\n";

      if ($limit != "" && tws_check_arg($limit, 'tws_num'))
         $cmd .= " LIMIT " . $limit . "\n";

      if (!empty($needscpu) && count($needscpu) > 0) {
         foreach ($needscpu as $index => $value) {
            if($value=='' && $resource[$index]=='' ) continue;
            $cmd .=" NEEDS " . $units[$index] . " " . $value . "#" . $resource[$index] . "\n";
         }
      }
      if (!empty($openscpu) && count($openscpu) > 0) {
         foreach ($openscpu as $index => $value) {
            if($value=='' && $opensfile[$index]=='' ) continue;
            $cmd .=" OPENS " . $value . "#\"" . addcslashes($opensfile[$index],'"') . "\"";
            if ($opensqual[$index] != "")
               $cmd .= " (" . $opensqual[$index] . ")";
            $cmd .= "\n";
         }
      }
      if ($priority != "" ) {
         if ($priority == 100) $priority="HI";
         if ($priority == 101) $priority="GO";
         $cmd .= " PRIORITY " . $priority . "\n";
      }
      if (!empty($promptname) && count($promptname) > 0) {
         foreach ($promptname as $index => $value) {
            if($value=='') continue;
            tws_check_arg($value, 'tws_name');
            $cmd .= " PROMPT $value\n";
         }
      }
      if (!empty($prompttext) && count($prompttext) > 0) {
         foreach ($prompttext as $index => $value) {
            if($value=='') continue;
            $cmd .= " PROMPT \"".addcslashes($value,'"')."\"\n";
         }
      }
      $cmd .= ": \n";   // JOBS JOBS JOBS JOBS JOBS JOBS JOBS JOBS JOBS

      if(empty($jobname)) $jobname = array();   // avoid warning if no jobs
      foreach ($jobname as $job) {
         $job_joins = array();
         // remade because of problems with text mode in Windows (don't show comments at all)
         if (isset($jobdescription[$job])) {
            $jobdescription[$job]=str_replace("\r", "", $jobdescription[$job]);
            $jobdescription[$job]=str_replace("\\n", "\n", $jobdescription[$job]);
            $description_line=explode("\n", $jobdescription[$job]);
            $cmd .= "#\n";
            foreach ($description_line as $descline) {
               if(!empty($descline))
                  $cmd .= "#$descline\n";
            }
            $cmd .= "#\n";
         }
         // Job Alias
         $job = preg_replace('/ \(.*\)/', '', $job);  // jobname can contain '(TWS0)' - remove it
         if(!preg_match('/ as /i', $job)){
            if (!empty($jobalias[$job]))
               $cmd .= $job." AS $jobalias[$job]\n";
            else $cmd .= $job."\n";
         }
         else { // job had alias
            $tmp = substr($job, 0, strpos($job, ' '));
            if (!empty($jobalias[$job]))
               $cmd .= $tmp." AS $jobalias[$job]\n";
            else
               $cmd .= $tmp."\n";
         }

         if (isset($jobathour[$job]) && isset($jobatminute[$job]) && tws_check_arg($jobathour[$job], 'tws_num') && tws_check_arg($jobatminute[$job], 'tws_num')) {
            if($job_time_dependent[$job]=='Y')
               $cmd .= " AT " . $jobathour[$job] . $jobatminute[$job];
            else $cmd .= " SCHEDTIME " . $jobathour[$job] . $jobatminute[$job];
            if (isset($jobtime_zone[$job])) {
               if (($jobtime_zone[$job] != "") && ($jobtime_zone[$job] != "NULL")) {
                  $cmd .= "   TIMEZONE $jobtime_zone[$job]";
               }
            }
            if ($jobatplusdays[$job] != 0) {
               $cmd .= " +$jobatplusdays[$job] DAYS";
            }
            $cmd .= "\n";
         }
         if (isset($jobuntilhour[$job]) && isset($jobuntilminute[$job]) && tws_check_arg($jobuntilhour[$job], 'tws_num') && tws_check_arg($jobuntilminute[$job], 'tws_num')) {
            $cmd .= " UNTIL " . $jobuntilhour[$job] . $jobuntilminute[$job];
            if (isset($jobtime_zone[$job])) {
               if (($jobtime_zone[$job] != "") && ($jobtime_zone[$job] != "NULL")) {
                  $cmd .= "   TIMEZONE $jobtime_zone[$job]";
               }
            }
            if ($jobuntilplusdays[$job] != 0) {
               $cmd .= " +$jobuntilplusdays[$job] DAYS";
            }
            $cmd .= "\n";
            if (strtoupper($jobonuntil[$job]) == "CONT") {
               $cmd .= "  ONUNTIL CONT\n";
            } elseif (strtoupper($jobonuntil[$job]) == "CANC") {
               $cmd .= "  ONUNTIL CANC\n";
            }
         }
         if (isset($jobdeadlinehour[$job]) && isset($jobdeadlineminute[$job]) && tws_check_arg($jobuntilminute[$job], 'tws_num') && tws_check_arg($jobuntilminute[$job], 'tws_num')) {
            $cmd .= " DEADLINE " . $jobdeadlinehour[$job] . $jobdeadlineminute[$job];
            if (isset($jobtime_zone[$job])) {
               if (($jobtime_zone[$job] != "") && ($jobtime_zone[$job] != "NULL")) {
                  $cmd .= "   TIMEZONE $jobtime_zone[$job]";
               }
            }
            if ($jobdeadlineplusdays[$job] != 0) {
               $cmd .= " +$jobdeadlineplusdays[$job] DAYS";
            }
            if(!empty($jobdeadlineaction[$job]))
               $cmd .= " ONLATE KILL";
            $cmd .= "\n";
         }
         // MAX_DURATION
         $maxstr = '';
         if ((isset($maxdur_hour[$job]) || isset($maxdur_minute[$job])) && $maxdur_type[$job]=='M')
            $maxstr .= " MAXDUR " . str_pad($maxdur_hour[$job], 2, '0', STR_PAD_LEFT) . str_pad($maxdur_minute[$job], 2, '0', STR_PAD_LEFT);
         elseif(isset($maxdur_percent[$job]) && $maxdur_type[$job]=='P')
            $maxstr .= " MAXDUR " . $maxdur_percent[$job]."%";
         if(!empty($maxstr) && $maxdur_action[$job] == 'S')
            $maxstr .= " ONMAXDUR KILL";

         // MIN_DURATION
         $minstr = '';
         if ((isset($mindur_hour[$job]) || isset($mindur_minute[$job])) && $mindur_type[$job]=='M')
            $minstr .= " MINDUR " . str_pad($mindur_hour[$job], 2, '0', STR_PAD_LEFT) . str_pad($mindur_minute[$job], 2, '0', STR_PAD_LEFT);
         elseif(isset($mindur_percent[$job]) && $mindur_type[$job]=='P')
            $minstr .= " MINDUR " . $mindur_percent[$job]."%";
         if(!empty($minstr)){
            if( $mindur_action[$job] == 'F')
               $minstr .= " ONMINDUR CONFIRM";
            elseif($mindur_action[$job] == 'A')
               $minstr .= " ONMINDUR ABEND";
         }
         if(!empty($maxstr) || !empty($minstr))
            $cmd .= $maxstr .' '. $minstr ."\n";

         if (isset($jobeveryhour[$job]) && isset($jobeveryminute[$job]) && tws_check_arg($jobeveryhour[$job], 'tws_num') && tws_check_arg($jobeveryminute[$job], 'tws_num')) {
            $cmd .=" EVERY " . $jobeveryhour[$job] . $jobeveryminute[$job] . "\n";
         }
         if (isset($jobpriority[$job]) && $jobpriority[$job]!=''  && tws_check_arg($jobpriority[$job], 'tws_priority')) {
            $prio=$jobpriority[$job];
            if ($prio == 100) $prio="HI";
            if ($prio == 101) $prio="GO";
            $cmd .= " PRIORITY " . $prio . "\n";
         }
         //    JOB FOLLOWS
         if (!empty($jobfollowsjobstreamcpu) && count($jobfollowsjobstreamcpu) > 0) {
            foreach ($jobfollowsjobstreamcpu as $jb => $jobarray) {
               if ($jb == $job) {
                  foreach ($jobarray as $index => $value) {
                     tws_check_arg($value, 'tws_name') && tws_check_arg($jobfollowsjobstreamname[$jb][$index], 'tws_name');
                     $line = " FOLLOWS " . $value . "#" . $jobfollowsjobstreamname[$jb][$index] . ".@ ";
                     if($tws_config['cpuinfo']['version']>='9.3'){
                        if($job_js_abend[$jb][$index] == 'Y' || $job_js_success[$jb][$index] == 'Y' || $job_js_suppress[$jb][$index] == 'Y'){
                           $line .= ' IF ';
                           if($job_js_abend[$jb][$index] == 'Y')
                              $line .= 'ABEND|';
                           if($job_js_success[$jb][$index] == 'Y')
                              $line .= 'SUCC|';
                           if($job_js_suppress[$jb][$index] == 'Y')
                              $line .= 'SUPPR|';
                           $line = substr($line, 0, -1);
                        }
                     }
                     $line .= "\n";
                     switch ($jobfollowsjobstreammatching[$jb][$index]) {
                        case "DEFAULT":  //nothing to do
                           break;
                        case "SAMEDAY":
                           $line .= "   SAMEDAY";
                           break;
                        case "PREVIOUS":
                           $line .= "   PREVIOUS";
                           break;
                        case "RELATIVE":
                           $line .= "   RELATIVE FROM ".$jobfollowsjobstreammatchingrelativefromdir[$jb][$index]." ";
                           $line .= $jobfollowsjobstreammatchingrelativefromhour[$jb][$index].$jobfollowsjobstreammatchingrelativefromminute[$jb][$index];
                           $line .= " TO ".$jobfollowsjobstreammatchingrelativetodir[$jb][$index]." ";
                           $line .= $jobfollowsjobstreammatchingrelativetohour[$jb][$index].$jobfollowsjobstreammatchingrelativetominute[$jb][$index];
                           break;
                        case "ABSOLUTE":
                           $line .= "   FROM ".$jobfollowsjobstreammatchingabsolutefromhour[$jb][$index].$jobfollowsjobstreammatchingabsolutefromminute[$jb][$index]." ";
                           if ($jobfollowsjobstreammatchingabsolutefromdays[$jb][$index] > 0)
                              $line .= " ".$jobfollowsjobstreammatchingabsolutefromdir[$jb][$index].$jobfollowsjobstreammatchingabsolutefromdays[$jb][$index]." days";
                           $line .= " TO ".$jobfollowsjobstreammatchingabsolutetohour[$jb][$index].$jobfollowsjobstreammatchingabsolutetominute[$jb][$index]." ";
                           if ($jobfollowsjobstreammatchingabsolutetodays[$jb][$index] > 0)
                              $line .= " ".$jobfollowsjobstreammatchingabsolutetodir[$jb][$index]." ".$jobfollowsjobstreammatchingabsolutetodays[$jb][$index]." days";
                           break;
                     }
                     // IWS 9.4 JOINS
                     if(!empty($job_js_join_name[$jb][$index])){
                        $job_joins[$job_js_join_name[$jb][$index]]['join_description'] = $job_js_join_description[$jb][$index];
                        $job_joins[$job_js_join_name[$jb][$index]]['join_quantity'] = $job_js_join_quantity[$jb][$index];
                        $job_joins[$job_js_join_name[$jb][$index]]['follows'][] = $line;
                        continue;
                     }
                     $cmd .=$line."\n";
                  }
               }
            }
         }
         if (is_array($jobfollowsjobname) && count($jobfollowsjobname) > 0) {
            foreach ($jobfollowsjobname as $jb => $jobarray) {
               if ($jb == $job) {
                  foreach ($jobarray as $index => $value) {
                     $_job=$value;
                     if ($jobfollowsjobjobstream[$jb][$index]!='') {
                        $_job=$jobfollowsjobjobstream[$jb][$index].".".$_job;
                        if ($jobfollowsjobcpu[$jb][$index]!='')
                           $_job=$jobfollowsjobcpu[$jb][$index].'#'.$_job;
                     }
                     else{
                        $tmp_arr = tws_divide_folder($_job);   // instead of 'list' f-ce
                        if(!empty($tmp_arr[1])) // folder exist
                           $_job = $tmp_arr[1];
                     }
                     tws_check_arg($_job, 'tws_name');
                     $line = " FOLLOWS ".$_job;
                     //    Conditional
                     if($tws_config['cpuinfo']['version']>='9.3'){
                        if($job_job_abend[$jb][$index] == 'Y' || $job_job_success[$jb][$index] == 'Y' || $job_job_suppress[$jb][$index] == 'Y' || $job_job_fail[$jb][$index] == 'Y' || $job_job_execute[$jb][$index] == 'Y'){
                           $line .= ' IF ';
                           if($job_job_execute[$jb][$index] == 'Y')
                              $line .= 'EXEC';
                           else{
                              if($job_job_abend[$jb][$index] == 'Y')
                                 $line .= 'ABEND|';
                              if($job_job_success[$jb][$index] == 'Y')
                                 $line .= 'SUCC|';
                              if($job_job_suppress[$jb][$index] == 'Y')
                                 $line .= 'SUPPR|';
                              if($job_job_fail[$jb][$index] == 'Y')
                                 $line .= 'FAIL|';
                              $line = substr($line, 0, -1);
                           }
                        }
                        elseif(!empty($job_job_condition[$jb][$index])){
                           $line .= ' IF ';
                           foreach($job_job_condition[$jb][$index] as $codemap)
                              $line .= "$codemap|";
                           $line = substr($line, 0, -1);
                        }
                     }

                     switch ($jobfollowsjobmatching[$jb][$index]) {
                        case "DEFAULT":  //nothing to do
                           break;
                        case "SAMEDAY":
                           $line .= "   SAMEDAY";
                           break;
                        case "PREVIOUS":
                           $line .= "   PREVIOUS";
                           break;
                        case "RELATIVE":
                           $line .= "   RELATIVE FROM ".$jobfollowsjobmatchingrelativefromdir[$jb][$index]." ";
                           $line .= $jobfollowsjobmatchingrelativefromhour[$jb][$index].$jobfollowsjobmatchingrelativefromminute[$jb][$index];
                           $line .= " TO ".$jobfollowsjobmatchingrelativetodir[$jb][$index]." ";
                           $line .= $jobfollowsjobmatchingrelativetohour[$jb][$index].$jobfollowsjobmatchingrelativetominute[$jb][$index];
                           break;
                        case "ABSOLUTE":
                           $line .= "   FROM ".$jobfollowsjobmatchingabsolutefromhour[$jb][$index].$jobfollowsjobmatchingabsolutefromminute[$jb][$index]." ";
                           if ($jobfollowsjobmatchingabsolutefromdays[$jb][$index] > 0)
                              $line .= " ".$jobfollowsjobmatchingabsolutefromdir[$jb][$index].$jobfollowsjobmatchingabsolutefromdays[$jb][$index]." days";
                           $line .= " TO ".$jobfollowsjobmatchingabsolutetohour[$jb][$index].$jobfollowsjobmatchingabsolutetominute[$jb][$index]." ";
                           if ($jobfollowsjobmatchingabsolutetodays[$jb][$index] > 0)
                              $line .= " ".$jobfollowsjobmatchingabsolutetodir[$jb][$index]." ".$jobfollowsjobmatchingabsolutetodays[$jb][$index]." days";
                           break;
                     }
                     // IWS 9.4 JOINS
                     if(!empty($job_job_join_name[$jb][$index])){
                        $job_joins[$job_job_join_name[$jb][$index]]['join_description'] = $job_job_join_description[$jb][$index];
                        $job_joins[$job_job_join_name[$jb][$index]]['join_quantity'] = $job_job_join_quantity[$jb][$index];
                        $job_joins[$job_job_join_name[$jb][$index]]['follows'][] = $line;
                        continue;
                     }
                     $cmd.=$line."\n";
                  }
               }
            }
         }
         if (is_array($jobfollowsnetworkagent) && count($jobfollowsnetworkagent) > 0) {
            foreach ($jobfollowsnetworkagent as $jb => $jobarray) {
               if ($jb == $job) {
                  foreach ($jobarray as $index => $value) {
                     tws_check_arg($value, 'tws_name');
                     $cmd .= " FOLLOWS " . $value . "::\"" . $jobfollowsnetworkdep[$jb][$index]."\"\n";
                  }
               }
            }
         }
         //    FOLLOWS JOIN
         foreach($job_joins as $joinname=>$arr){
            $cmd .= "JOIN $joinname $arr[join_quantity] OF\n";
            if(!empty($arr['join_description']))
               $cmd .= 'DESCRIPTION "'.$arr['join_description'].'"'."\n";
            foreach($arr['follows'] as $str)
               $cmd .= "$str\n";
            $cmd .= "ENDJOIN\n";
         }

         if (is_array($jobpromptname) && count($jobpromptname) > 0) {
            foreach ($jobpromptname as $jb => $promptarray) {
               if ($jb == $job) {
                  foreach ($promptarray as $index => $value) {
                     tws_check_arg($value, 'tws_name');
                     $cmd .= " PROMPT $value\n";
                  }
               }
            }
         }
         if (is_array($jobprompttext) && count($jobprompttext) > 0) {
            foreach ($jobprompttext as $jb => $promptarray) {
               if ($jb == $job) {
                  foreach ($promptarray as $index => $value) {
                     $cmd .= " PROMPT \"".addcslashes($value,'"')."\"\n";
                  }
               }
            }
         }
         if (is_array($jobopenscpu) && count($jobopenscpu) > 0) {
            foreach ($jobopenscpu as $jb => $opensarray) {
               if ($jb == $job) {
                  foreach ($opensarray as $index => $value) {
                     tws_check_arg($value, 'tws_name') && tws_check_arg($jobopensfile[$jb][$index], 'tws_file');
                     $cmd .=" OPENS " . $value . "#\"" . addcslashes($jobopensfile[$jb][$index],'"') . "\"";
                     if ($jobopensqual[$jb][$index] != "") {
                        $cmd .= " (" . $jobopensqual[$jb][$index] . ")";
                     }
                     $cmd .= "\n";
                  }
               }
            }
         }
         if (is_array($jobneedscpu) && count($jobneedscpu) > 0) {
            foreach ($jobneedscpu as $jb => $needsarray) {
               if ($jb == $job) {
                  foreach ($needsarray as $index => $value) {
                     tws_check_arg($value, 'tws_name') && tws_check_arg($jobresource[$jb][$index], 'tws_name') && tws_check_arg($jobunits[$jb][$index], 'tws_num');
                     $cmd .= " NEEDS " . $jobunits[$jb][$index] . " " . $value . "#" . $jobresource[$jb][$index] . "\n";
                  }
               }
            }
         }
         if (isset($jobconfirmed[$job])) {
            if ($jobconfirmed[$job] == "YES") {
               $cmd .= " CONFIRMED\n";
            }
         }
         if ((isset($jobkeyjob[$job]))) {
            if ($jobkeyjob[$job] == "YES") {
               $cmd .= " KEYJOB\n";
            }
         }
         if ((isset($jobcritical[$job]))) {
            if ($jobcritical[$job] == "YES") {
               $cmd .= " CRITICAL\n";
            }
         }
         if ((isset($jobnop[$job]))) {
            if ($jobnop[$job] == "YES") {
               $cmd .= " NOP\n";
            }
         }
      }
      $cmd .= "END\n";

   return $cmd;
}

/**
 * convert calendar data to calendar text definition
 */
function tws_calendar_to_composer($values, $head){
   global $tws_config;
   $datestring = '';
   $values['calendar_dates'] = str_replace(' ', '', $values['calendar_dates']);
   $tmp = explode(',', $values['calendar_dates'] );
   $i=0;
   foreach($tmp as $date) $datestring .= tws_date_from_iso($date).(++$i%5==0 ? "\n" : " "); //ERR17491 - avoid "token too large, exceeds YYLMAX" errors
   $cmd = '';
   if($head) $cmd = "\$CALENDAR\n";
   if ($tws_config['cpuinfo']['version']>='9.5002'){
       $cmd .= $values['calendar_folder'];
   }
   $cmd .= $values['calendar_name'] .' "'.addcslashes($values['calendar_description'], '"').'"'."\n";
   $cmd .= $datestring;
   return $cmd;
}
/////////////////////////////////////

function tws_specialchars(&$var){
   if( is_array($var) ){
      foreach( $var as $key=>$val )
         tws_specialchars($var[$key]);
      return;
   }
   $var=htmlspecialchars($var);
}


/* ---------------------------------------------------------------
               SUBMIT
               Public functions
   --------------------------------------------------------------- */

//    Show submit form

function iwd_show_submit_form($obj_type, $data='', $display=''){
   if (defined('IWD_PROCMAN')) {
      $eold=error_reporting(E_ERROR | E_WARNING);
      $de_old=ini_get('display_errors');
      ini_set('display_errors', 0);
   }
   $arr=array();
   if($obj_type == 'job'){
      if(is_string($data) && !empty($data))
         list($arr['workstation'], $arr['job']) = explode('#', $data);
      else $arr=$data;
      iwd_show_submit_job_form($arr, $display);
   }
   else{
      if(is_string($data) && !empty($data))
         list($arr['workstation'], $arr['jobstream']) = explode('#', $data);
      else $arr=$data;
      iwd_show_submit_stream_form($arr, $display);
   }

   if (defined('IWD_PROCMAN')) {
      error_reporting($eold);
      ini_set('display_errors', $de_old);
   }
}

//    Put data from submit form into array
function iwd_submit_to_arr($obj, $post){
   if (defined('IWD_PROCMAN')) {
      $eold=error_reporting(E_ERROR | E_WARNING);
      $de_old=ini_get('display_errors');
      ini_set('display_errors', 0);
   }

    if($obj == 'job')
      $result=iwd_submit_job_to_arr($post);
   else
      $result=iwd_submit_stream_to_arr($post);

   if (defined('IWD_PROCMAN')) {
      error_reporting($eold);
      ini_set('display_errors', $de_old);
   }
   return $result;
}

//    Return command for submit
function iwd_submit_to_conman($obj, $arr){
   if (defined('IWD_PROCMAN')) {
      $eold=error_reporting(E_ERROR | E_WARNING);
      $de_old=ini_get('display_errors');
      ini_set('display_errors', 0);
   }

    if($obj == 'job')
      $result=iwd_submit_job_to_conman($arr);
   else
      $result=iwd_submit_stream_to_conman($arr);

   if (defined('IWD_PROCMAN')) {
      error_reporting($eold);
      ini_set('display_errors', $de_old);
   }

    return $result;
}

//    Put data from array into submit form
function iwd_arr_to_submit($obj, $arr, $display=''){
   if (defined('IWD_PROCMAN')) {
      $eold=error_reporting(E_ERROR | E_WARNING);
      $de_old=ini_get('display_errors');
      ini_set('display_errors', 0);
   }

   if($obj == 'job')
      iwd_arr_to_job_submit($arr, $display);
   else
      iwd_arr_to_stream_submit($arr, $display);
   if (defined('IWD_PROCMAN')) {
      error_reporting($eold);
      ini_set('display_errors', $de_old);
   }
}


/* ---------------------------------------------------------------
               SUBMIT
               Private functions
   --------------------------------------------------------------- */

function iwd_show_submit_job_form($arr, $display){
   global $tws_config;

if(!empty($display)){ ?>
   <script type="text/javascript" >
   $(document).ready(function () {
      $('input:text' ).prop('readonly', true);
      $('input[value="List"]' ).prop('disabled', true);
      $('input[value="Use MAIN_TABLE"]' ).prop('disabled', true);
      $('input[value=" + "]' ).prop('disabled', true);
      //$('input:checkbox' ).prop('disabled', true);
      //$('select' ).prop('disabled', true);
   });
   </script>
<? } ?>
<script type="text/javascript" src="tws_insert_row.js"></script>

<table class="submit" border="0" cellspacing="0" width="100%">
<colgroup>
   <col span="1" width="1">
</colgroup>
<tr>
   <td class="info"><b>Workstation:</b></td>
   <td class="info">
      <input type="text" name="workstation" class="tws_name" required="required" readonly style="width:15em" maxlength="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" value="<?=$arr['workstation']?>" >
   </td>
</tr>
<tr>
   <td class="info"><b>Job:</b></td>
   <td class="info">
      <input type="text" name="job" class="tws_name" required="required" readonly style="width:15em" maxlength="<?=$tws_config['JOB_MAXLENGTH']?>" value="<?=$arr['job']?>">
   </td>
</tr>
<tr>
   <td colspan="2"></td>
</tr>
<tr>
   <td colspan="2" style="padding-left: 0px"><h2>General</h2></td>
</tr>
<tr>
   <td><b>Into Jobstream:</b></td>
   <td>
      Workstation: <input type="text" name="intocpu" class="tws_name" size="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" maxlength="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" value="<?=$arr['intocpu']?>" >
         <input type="button" name="workstation_list" onClick="tws_picker_open('plan_workstation_picker.php', 'fieldname=intocpu&amp;fieldvalue=' + document.contents.intocpu.value);" value="List">
      Jobstream: <input type="text" name="intojobstream" class="tws_name_inst" size="<?=($tws_config['JOBSTREAM_MAXLENGTH']+$tws_config['SCHEDID_MAXLENGTH']+1)?>" maxlength="<?=($tws_config['JOBSTREAM_MAXLENGTH']+$tws_config['SCHEDID_MAXLENGTH']+1)?>" value="<?=$arr['intojobstream']?>">
         <input type="button" name="jobstream_list" onClick="tws_picker_open('plan_jobstream_picker.php', 'fieldname=intojobstream&amp;fieldvalue=' + document.contents.intojobstream.value + '&amp;wksfieldname=intocpu&amp;cpux=' + document.contents.intocpu.value);" value="List">
   </td>
</tr>
<tr>
   <td><b>Alias:</b></td>
   <td><input type="text" name="aliasname" class="tws_name" size="<?=$tws_config['JOB_MAXLENGTH']?>" maxlength="<?=$tws_config['JOB_MAXLENGTH']?>" value="<?=$arr['aliasname']?>"></td>
</tr>
<tr>
   <td colspan="2">&nbsp;</td>
</tr>
<tr>
   <td colspan="2" style="padding-left: 0px"><h2>Options</h2></td>
</tr>
<tr>
   <td><b>At:</b></td>
   <td><input type="text" name="athour" class="tws_hour" size="2" maxlength="2" value="<?=$arr['athour']?>">:<input type="text" name="atminute" class="tws_minute" size="2" maxlength="2" value="<?=$arr['atminute']?>"> plus <input type="text" name="atplusdays" class="tws_num" size="3" maxlength="3" value="<?=$arr['atplusdays']?>"> days</td>
</tr>
<tr>
   <td><b>Until:</b></td>
   <td><input type="text" name="untilhour" class="tws_hour" size="2" maxlength="2" value="<?=$arr['untilhour']?>">:<input type="text" name="untilminute" class="tws_minute" size="2" maxlength="2" value="<?=$arr['untilminute']?>"> plus <input type="text" name="untilplusdays" class="tws_num" size="3" maxlength="3" value="<?=$arr['untilplusdays']?>"> days</td>
</tr>
<tr>
   <td>&nbsp;&nbsp;<b>Until Action:</b></td>
   <td>
      <select name="onuntil">
         <option value="suppr" <?php if (($arr['onuntil'] == 'suppr') || (!$arr['onuntil'])) echo ' selected'; ?>>Suppress</option>
         <option value="cont" <?php if ($arr['onuntil'] == 'cont') echo ' selected'; ?>>Continue</option>
         <option value="canc" <?php if ($arr['onuntil'] == 'canc') echo ' selected'; ?>>Cancel</option>
      </select>
   </td>
</tr>
<tr>
   <td><b>Deadline:</b></td>
   <td><input type="text" name="deadlinehour" class="tws_hour" size="2" maxlength="2" value="<?=$arr['deadlinehour']?>">:<input type="text" name="deadlineminute" class="tws_minute" size="2" maxlength="2" value="<?=$arr['deadlineminute']?>"> plus <input type="text" name="deadlineplusdays" class="tws_num" size="3" maxlength="3" value="<?=$arr['deadlineplusdays']?>"> days</td>
</tr>
<tr>
   <td><b>Every:</b></td>
   <td><input type="text" name="everyhour" class="tws_hour" size="2" maxlength="2" value="<?=$arr['everyhour']?>">:<input type="text" name="everyminute" class="tws_minute" size="2" maxlength="2" value="<?=$arr['everyminute']?>"></td>
</tr>
<tr>
   <td><b>Priority:</b></td>
   <td><input type="text" name="privalue" class="tws_priority" size="3" maxlength="3" value="<?=$arr['privalue']?>"></td>
</tr>
<?php
   if (tws_yesno(tws_get_tz_status(),TRUE,FALSE)) { ?>
      <tr>
      <td><b>Time Zone:</b></td>
      <td class="standard">
      <select name="time_zone">
      <? tws_print_timezone_options($arr['time_zone']); ?>
      </select>
      </td>
      </tr>
<? } ?>
      <tr>
      <td class="standard"><b>Parameter Table:</b></td>
      <td class="standard"><input type="text" name="parameter_table" class="tws_name" size="20" maxlength="<?=$tws_config['VARTABLE_MAXLENGTH']?>" value="<?=$arr['parameter_table']?>">
      <input type="button" name="parameter_table_list" onClick="tws_picker_open('parameter_table_picker.php', 'fieldname=parameter_table&amp;fieldvalue=' + document.contents.parameter_table.value);" value="List">
      <input type="button" name="default_parameter_table" onClick="document.contents.parameter_table.value='MAIN_TABLE'" value="Use MAIN_TABLE"></td>
      </tr>

<tr><td colspan="2"></td></tr>
<tr>
   <td colspan="2"><b><label><input type="checkbox" name="confirmed" value="yes"<?=($arr['confirmed'] == 'yes' ? ' checked="checked"' : '')?>>Confirmed</label></b></td>
</tr>
      <tr>
      <td colspan="2"><b><label><input type="checkbox" name="critical" value="yes" <?=($arr['critical']=='yes' ? ' checked="checked"' : '')?>>Critical</label></b></td>
      </tr>
<tr><td colspan="2"></td></tr>
</table>
<table>
<tr>
   <td colspan="2" style="padding-left: 0px"><h2>Dependencies</h2></td>
</tr>
<? $i = 1;
do { ?>
<tr class='deps'>
   <td><b>Follows Jobstream:</b></td>
   <td>Workstation:<input type="text" name="followsjobstreamcpu[<?=$i?>]" class="tws_name" style="width:12em" maxlength="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" value="<?=$arr['followsjobstreamcpu'][$i]?>" >
      <input type="button" name="workstation_list" onClick="tws_picker_open('plan_workstation_picker.php', 'fieldname=followsjobstreamcpu[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['followsjobstreamcpu[<?=$i?>]'].value);" value="List">
      Jobstream:<input type="text" name="followsjobstreamname[<?=$i?>]" class="tws_name_inst" size="<?=($tws_config['JOBSTREAM_MAXLENGTH']+$tws_config['SCHEDID_MAXLENGTH']+1)?>" maxlength="<?=($tws_config['JOBSTREAM_MAXLENGTH']+$tws_config['SCHEDID_MAXLENGTH']+1)?>" value="<?=$arr['followsjobstreamname'][$i]?>" >
      <input type="button" name="jobstream_list" onClick="tws_picker_open('plan_jobstream_picker.php', 'fieldname=followsjobstreamname[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['followsjobstreamname[<?=$i?>]'].value + '&amp;wksfieldname=followsjobstreamcpu[<?=$i?>]&amp;cpux=' + document.contents.elements['followsjobstreamcpu[<?=$i?>]'].value);" value="List">
   </td>
</tr>
<? $i++;
} while (isset($arr['followsjobstreamcpu'][$i])) ?>
<tr class='deps'>
   <td></td>
   <td><input type="button" onclick="insertRow(this);" value=" + " title="Add Follows Jobstream"></td>
</tr>
<? $i = 1;
do { ?>
<tr class='deps'>
   <td><b>Follows Job:</b></td>
   <td>
    <table><tr><td>Workstation:</td><td>Jobstream:</td><td>Job:</td></tr>
    <tr><td nowrap><input type="text" name="followsjobcpu[<?=$i?>]" class="tws_name" style="width:12em" maxlength="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" value="<?=$arr['followsjobcpu'][$i]?>" >
    <input type="button" name="workstation_list" onClick="tws_picker_open('plan_workstation_picker.php', 'fieldname=followsjobcpu[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['followsjobcpu[<?=$i?>]'].value);" value="List" ></td>
    <td nowrap><input type="text" name="followsjobjobstream[<?=$i?>]" class="tws_name_inst" size="<?=($tws_config['JOBSTREAM_MAXLENGTH']+$tws_config['SCHEDID_MAXLENGTH']+1)?>" maxlength="<?=($tws_config['JOBSTREAM_MAXLENGTH']+$tws_config['SCHEDID_MAXLENGTH']+1)?>" value="<?=$arr['followsjobjobstream'][$i]?>" >
    <input type="button" name="jobstream_list" onClick="tws_picker_open('plan_jobstream_picker.php', 'fieldname=followsjobjobstream[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['followsjobjobstream[<?=$i?>]'].value + '&amp;wksfieldname=followsjobcpu[<?=$i?>]&amp;cpux=' + document.contents.elements['followsjobcpu[<?=$i?>]'].value);" value="List"></td>
    <td nowrap><input type="text" name="followsjobname[<?=$i?>]" class="tws_name" size="<?=$tws_config['JOB_MAXLENGTH']?>" maxlength="<?=$tws_config['JOB_MAXLENGTH']?>" value="<?=$arr['followsjobname'][$i]?>" >
    <input type="button" name="job_list" onClick="tws_picker_open('plan_job_picker.php', 'fieldname=followsjobname[<?=$i?>]&amp;wksfieldname=followsjobcpu[<?=$i?>]&amp;jsfieldname=followsjobjobstream[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['followsjobname[<?=$i?>]'].value + '&amp;cpux=' + document.contents.elements['followsjobcpu[<?=$i?>]'].value + '&amp;schedulex=' + document.contents.elements['followsjobjobstream[<?=$i?>]'].value);" value="List" ></td>
    </tr></table>
   </td>
</tr>
<? $i++;
} while (isset($arr['followsjobcpu'][$i])) ?>
<tr class='deps'>
   <td></td>
   <td><input type="button" onclick="insertRow(this);" value=" + " title="Add Follows Job"></td>
</tr>
<? $i = 1;
do { ?>
<tr class='deps'>
   <td><b>Global Prompt:</b></td>
   <td><input type="text" name="promptname[<?=$i?>]" class="tws_name" size="<?=2*$tws_config['PROMPT_MAXLENGTH']?>" maxlength="<?=$tws_config['PROMPT_MAXLENGTH']?>" value="<?=$arr['promptname'][$i]?>" >
   <input type="button" name="prompt_list" onClick="tws_picker_open('prompt_picker.php', 'fieldname=promptname[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['promptname[<?=$i?>]'].value);" value="List" >
   </td>
</tr>
<? $i++;
} while (isset($arr['promptname'][$i])) ?>
<tr class='deps'>
   <td></td><td><input type="button" onclick="insertRow(this);" value=" + " title="Add Global Prompt"></td>
</tr>
<? $i = 1;
do { ?>
<tr class='deps'>
   <td><b>Local Prompt:</b></td>
   <td><input type="text" name="prompttext[<?=$i?>]" class="tws_apostrof" size="80" maxlength="200" value="<?=$arr['prompttext'][$i]?>" ></td>
</tr>
<? $i++;
} while (isset($arr['prompttext'][$i])) ?>
<tr class='deps'>
   <td></td><td><input type="button" onclick="insertRow(this);" value=" + " title="Add Local Prompt"></td>
</tr>
<? $i = 1;
do { ?>
<tr class='deps'>
   <td><b>Opens File:</b></td>
   <td>Workstation:<input type="text" name="openscpu[<?=$i?>]" class="tws_name" style="width:12em" maxlength="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" value="<?=$arr['openscpu'][$i]?>" >
   <input type="button" name="workstation_list" onClick="tws_picker_open('plan_workstation_picker.php', 'fieldname=openscpu[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['openscpu[<?=$i?>]'].value);" value="List" >
   Filename:<input type="text" name="opensfile[<?=$i?>]" class="tws_file" size="40" maxlength="<?=$tws_config['FILENAME_MAXLENGTH']?>" value="<?=$arr['opensfile'][$i]?>">
   </td>
</tr>
<? $i++;
} while (isset($arr['openscpu'][$i])) ?>
<tr class='deps'>
   <td></td><td><input type="button" onclick="insertRow(this);" value=" + " title="Add Opens File"></td>
</tr>
<? $i = 1;
do { ?>
<tr class='deps'>
   <td><b>Needs Resource:</b></td>
   <td>Workstation:<input type="text" name="needscpu[<?=$i?>]" class="tws_name" style="width:12em" maxlength="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" value="<?=$arr['needscpu'][$i]?>" >
   <input type="button" name="workstation_list" onClick="tws_picker_open('plan_workstation_picker.php', 'fieldname=needscpu[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['needscpu[<?=$i?>]'].value);" value="List" >
   Resource:<input type="text" name="resource[<?=$i?>]" class="tws_name" size="<?=$tws_config['RESOURCE_MAXLENGTH']?>" maxlength="<?=$tws_config['RESOURCE_MAXLENGTH']?>" value="<?=$arr['resource'][$i]?>" >
   <input type="button" name="resource_list" onClick="tws_picker_open('resource_picker.php', 'fieldname=resource[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['resource[<?=$i?>]'].value + '&amp;cpux=' + document.contents.elements['needscpu[<?=$i?>]'].value);" value="List">
   Units:<input type="text" name="units[<?=$i?>]" class="tws_num" size="4" maxlength="4" value="<?=$arr['units'][$i]?>">
   </td>
</tr>
<? $i++;
} while (isset($_POST['needscpu'][$i])) ?>
<tr class='deps'>
   <td></td>
   <td><input type="button" onclick="insertRow(this);" value=" + " title="Add Needs Resource"></td>
</tr>
</table>
<input type="hidden" name = "object" value = "job">
<?
}

//    function iwd_show_submit_stream_form($arr, $display)

function iwd_show_submit_stream_form($arr, $display){
   global $tws_config;

if(!empty($display)){ ?>
   <script type="text/javascript" >
   $(document).ready(function () {
      $('input:text' ).prop('readonly', true);
      $('input[value="List"]' ).prop('disabled', true);
      $('input[value="Use MAIN_TABLE"]' ).prop('disabled', true);
      $('input[value=" + "]' ).prop('disabled', true);
      //$('input:checkbox' ).prop('disabled', true);
      //$('select' ).prop('disabled', true);
   });
   </script>
<? } ?>
   <script type="text/javascript" src="tws_insert_row.js"></script>

<table class="submit" border="0" cellspacing="0" width="100%">
<colgroup>
   <col span="1" width="1">
</colgroup>
<tr>
   <td class="info"><b>Workstation:</b></td>
   <td class="info">
      <input type="text" name="workstation" class="tws_name" required="required" readonly style="width:15em" maxlength="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" value="<?=$arr['workstation']?>" >
   </td>
</tr>
<tr>
   <td class="info"><b>Jobstream:</b></td>
   <td class="info">
      <input type="text" name="jobstream" class="tws_name" required="required" readonly style="width:15em" maxlength="<?=$tws_config['JOBSTREAM_MAXLENGTH']?>" value="<?=$arr['jobstream']?>" >
   </td>
</tr>
<tr>
   <td colspan="2"></td>
</tr>
<tr>
   <td colspan="2" style="padding-left: 0px"><h2>General</h2></td>
</tr>
<tr>
   <td><b>Alias:</b></td>
   <td><input type="text" name="aliasname" class="tws_name" style="width:15em" maxlength="<?=$tws_config['JOBSTREAM_MAXLENGTH']?>" value="<?=$arr['aliasname']?>" ></td>
</tr>
<tr>
   <td colspan="2">&nbsp;</td>
</tr>
<tr>
   <td colspan="2" style="padding-left: 0px"><h2>Options</h2></td>
</tr>
<tr>
   <td><b>Scheduled Time:</b></td>
   <td><?=tws_datetime_picker('schedtime',$arr['schedtime'],'','',"'dropdown',true,'24',true,false,true,false")?></td>
</tr>
<tr>
   <td><b>At:</b></td>
   <td><input type="text" name="athour" class="tws_hour" size="2" maxlength="2" value="<?=$arr['athour']?>" >:<input type="text" name="atminute" class="tws_minute" size="2" maxlength="2" value="<?=$arr['atminute']?>" >&nbsp;plus&nbsp;<input type="text" name="atplusdays" class="tws_num" size="3" maxlength="3" value="<?=$arr['atplusdays']?>" >&nbsp;days</td>
</tr>
<tr>
   <td><b>Until:</b></td>
   <td><input type="text" name="untilhour" class="tws_hour" size="2" maxlength="2" value="<?=$arr['untilhour']?>" >:<input type="text" name="untilminute" class="tws_minute" size="2" maxlength="2" value="<?=$arr['untilminute']?>" >&nbsp;plus&nbsp;<input type="text" name="untilplusdays" class="tws_num" size="3" maxlength="3" value="<?=$arr['untilplusdays']?>" >&nbsp;days</td>
</tr>
<tr>
   <td>&nbsp;&nbsp;<b>Until Action:</b></td>
   <td>
      <select name="onuntil">
         <option value="suppr" <? if(($arr['onuntil'] == 'suppr') || (!$arr['onuntil'])) echo ' selected';?>>Suppress</option>
         <option value="cont" <? if ($arr['onuntil'] == 'cont') echo ' selected';?>>Continue</option>
         <option value="canc" <? if ($arr['onuntil'] == 'canc') echo ' selected';?>>Cancel</option>
      </select>
   </td>
</tr>
<tr>
   <td><b>Deadline:</b></td>
   <td><input type="text" name="deadlinehour" class="tws_hour" size="2" maxlength="2" value="<?=$arr['deadlinehour']?>" >:<input type="text" name="deadlineminute" class="tws_minute" size="2" maxlength="2" value="<?=$arr['deadlineminute']?>" >&nbsp;plus&nbsp;<input type="text" name="deadlineplusdays" class="tws_num" size="3" maxlength="3" value="<?=$arr['deadlineplusdays']?>" >&nbsp;days</td>
</tr>
<tr>
   <td><b>Priority:</b></td>
   <td><input type="text" name="privalue" class="tws_priority" size="3" maxlength="3" value="<?=$arr['privalue']?>" ></td>
</tr>
<tr>
   <td><b>Limit:</b></td>
   <td><input type="text" name="limitvalue" class="tws_num" size="3" maxlength="3" value="<?=$arr['limitvalue']?>"></td>
</tr>
<? if (tws_yesno(tws_get_tz_status(),TRUE,FALSE)) { ?>
      <tr>
      <td><b>Time Zone:</b></td>
      <td>
      <select name="time_zone">
      <? tws_print_timezone_options($arr['time_zone']);?>
      </select>
      </td>
      </tr>
<? } ?>
      <tr>
         <td class="standard"><b>Parameter Table:</b></td>
         <td class="standard"><input type="text" name="parameter_table" class="tws_name" size="20" maxlength="<?=$tws_config['VARTABLE_MAXLENGTH']?>" value="<?=$arr['parameter_table']?>">
         <input type="button" name="parameter_table_list" onClick="tws_picker_open('parameter_table_picker.php', 'fieldname=parameter_table&amp;fieldvalue=' + document.contents.parameter_table.value);" value="List">
         <input type="button" name="default_parameter_table" onClick="document.contents.parameter_table.value='MAIN_TABLE'" value="Use MAIN_TABLE"></td>
      </tr>
<tr>
   <td colspan="2">&nbsp;</td>
</tr>
<tr>
   <td colspan="2"><b><label><input type="checkbox" name="carryforward" value="yes" <?if($arr['carryforward'] == 'yes') echo 'checked="checked"';?> >Carryforward</label></b></td>
</tr>
<tr>
   <td colspan="2">&nbsp;</td>
</tr>
</table>
<table>
<tr>
   <td colspan="2" style="padding-left: 0px"><h2>Dependencies</h2></td>
</tr>

<? $i = 1;
do { ?>
<tr class='deps'>
   <td><b>Follows Jobstream:</b></td>
   <td>Workstation: <input type="text" name="followsjobstreamcpu[<?=$i?>]" class="tws_name" style="width:12em" maxlength="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" value="<?=$arr['followsjobstreamcpu'][$i]?>" >
      <input type="button" name="workstation_list" onClick="tws_picker_open('plan_workstation_picker.php', 'fieldname=followsjobstreamcpu[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['followsjobstreamcpu[<?=$i?>]'].value);" value="List" >
      Jobstream: <input type="text" name="followsjobstreamname[<?=$i?>]" class="tws_name_inst" size="<?=($tws_config['JOBSTREAM_MAXLENGTH']+$tws_config['SCHEDID_MAXLENGTH']+1)?>" maxlength="<?=($tws_config['JOBSTREAM_MAXLENGTH']+$tws_config['SCHEDID_MAXLENGTH']+1)?>" value="<?=$arr['followsjobstreamname'][$i]?>">
      <input type="button" name="jobstream_list" onClick="tws_picker_open('plan_jobstream_picker.php', 'fieldname=followsjobstreamname[<?=$i?>]&amp;wksfieldname=followsjobstreamcpu[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['followsjobstreamname[<?=$i?>]'].value + '&amp;cpux=' + document.contents.elements['followsjobstreamcpu[<?=$i?>]'].value);" value="List" >
   </td>
</tr>
<? $i++;
} while (isset($arr['followsjobstreamcpu'][$i])) ?>

<tr class='deps'>
   <td></td><td><input type="button" onclick="insertRow(this);" value=" + " title="Add Follows Jobstream" ></td>
</tr>

<? $i = 1;
do { ?>
<tr class='deps'>
   <td><b>Follows Job:</b></td>
   <td><table><tr><td>Workstation:</td><td>Jobstream:</td><td>Job:</td></tr>
       <tr><td nowrap><input type="text" name="followsjobcpu[<?=$i?>]" class="tws_name" style="width:12em" maxlength="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" value="<?=$arr['followsjobcpu'][$i]?>" >
       <input type="button" name="workstation_list" onClick="tws_picker_open('plan_workstation_picker.php', 'fieldname=followsjobcpu[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['followsjobcpu[<?=$i?>]'].value);" value="List"></td>
      <td nowrap><input type="text" name="followsjobjobstream[<?=$i?>]" class="tws_name_inst" size="<?=($tws_config['JOBSTREAM_MAXLENGTH']+$tws_config['SCHEDID_MAXLENGTH']+1)?>" maxlength="<?=($tws_config['JOBSTREAM_MAXLENGTH']+$tws_config['SCHEDID_MAXLENGTH']+1)?>" value="<?=$arr['followsjobjobstream'][$i]?>">
      <input type="button" name="jobstream_list" onClick="tws_picker_open('plan_jobstream_picker.php', 'fieldname=followsjobjobstream[<?=$i?>]&amp;wksfieldname=followsjobcpu[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['followsjobjobstream[<?=$i?>]'].value + '&amp;cpux=' + document.contents.elements['followsjobcpu[<?=$i?>]'].value);" value="List"></td>
      <td nowrap><input type="text" name="followsjobname[<?=$i?>]" class="tws_name" size="<?=$tws_config['JOB_MAXLENGTH']?>" maxlength="<?=$tws_config['JOB_MAXLENGTH']?>" value="<?=$arr['followsjobname'][$i]?>" >
      <input type="button" name="job_list" onClick="tws_picker_open('plan_job_picker.php', 'fieldname=followsjobname[<?=$i?>]&amp;jsfieldname=followsjobjobstream[<?=$i?>]&amp;wksfieldname=followsjobcpu[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['followsjobname[<?=$i?>]'].value + '&amp;cpux=' + document.contents.elements['followsjobcpu[<?=$i?>]'].value + '&amp;schedulex=' + document.contents.elements['followsjobjobstream[<?=$i?>]'].value);" value="List" ></td>
      </tr></table>
   </td>
</tr>
<? $i++;
} while (isset($arr['followsjobcpu'][$i])) ?>

<tr class='deps'>
   <td></td>
   <td><input type="button" onclick="insertRow(this);" value=" + " title="Add Follows Job" ></td>
</tr>
<? $i = 1;
do { ?>
<tr class='deps'>
   <td><b>Global Prompt:</b></td>
   <td><input type="text" name="promptname[<?=$i?>]" class="tws_name" size="<?=$tws_config['PROMPT_MAXLENGTH']?>" maxlength="<?=$tws_config['PROMPT_MAXLENGTH']?>" value="<?=$arr['promptname'][$i]?>">
   <input type="button" name="prompt_list" onClick="tws_picker_open('prompt_picker.php', 'fieldname=promptname[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['promptname[<?=$i?>]'].value);" value="List">
   </td>
</tr>
<? $i++;
} while (isset($arr['promptname'][$i])) ?>
<tr class='deps'>
   <td></td>
   <td><input type="button" onclick="insertRow(this);" value=" + " title="Add Global Prompt" ></td>
</tr>

<? $i = 1;
do { ?>
<tr class='deps'>
   <td><b>Local Prompt:</b></td>
   <td><input type="text" name="prompttext[<?=$i?>]" class="tws_apostrof" size="80" maxlength="200" value="<?=$arr['prompttext'][$i]?>"></td>
</tr>
<? $i++;
} while (isset($arr['prompttext'][$i])) ?>
<tr class='deps'>
   <td></td><td><input type="button" onclick="insertRow(this);" value=" + " title="Add Local Prompt"></td>
</tr>

<? $i = 1;
do { ?>
<tr class='deps'>
   <td><b>Opens File:</b></td>
   <td>Workstation: <input type="text" name="openscpu[<?=$i?>]" class="tws_name" style="width:12em" maxlength="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" value="<?=$arr['openscpu'][$i]?>">
   <input type="button" name="workstation_list" onClick="tws_picker_open('plan_workstation_picker.php', 'fieldname=openscpu[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['openscpu[<?=$i?>]'].value);" value="List">
   Filename:<input type="text" name="opensfile[<?=$i?>]" class="tws_file" size="40" maxlength="<?=$tws_config['FILENAME_MAXLENGTH']?>" value="<?=$arr['opensfile'][$i]?>">
   </td>
</tr>
<? $i++;
} while (isset($arr['openscpu'][$i])) ?>
<tr class='deps'>
   <td></td>
   <td><input type="button" onclick="insertRow(this);" value=" + " title="Add Opens File"></td>
</tr>

<? $i = 1;
do { ?>
<tr class='deps'>
   <td><b>Needs Resource:</b></td>
   <td>Workstation:<input type="text" name="needscpu[<?=$i?>]" class="tws_name" style="width:12em" maxlength="<?=$tws_config['WORKSTATION_MAXLENGTH']?>" value="<?=$arr['needscpu'][$i]?>">
   <input type="button" name="workstation_list" onClick="tws_picker_open('plan_workstation_picker.php', 'fieldname=needscpu[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['needscpu[<?=$i?>]'].value);" value="List">
   Resource:<input type="text" name="resource[<?=$i?>]" class="tws_name" size="<?=$tws_config['RESOURCE_MAXLENGTH']?>" maxlength="<?=$tws_config['RESOURCE_MAXLENGTH']?>" value="<?=$arr['resource'][$i]?>">
   <input type="button" name="resource_list" onClick="tws_picker_open('resource_picker.php', 'fieldname=resource[<?=$i?>]&amp;fieldvalue=' + document.contents.elements['resource[<?=$i?>]'].value + '&amp;cpux=' + document.contents.elements['needscpu[<?=$i?>]'].value);" value="List">
   Units:<input type="text" name="units[<?=$i?>]" class="tws_num" size="4" maxlength="4" value="<?=$arr['units'][$i]?>">
   </td>
</tr>
<? $i++;
} while (isset($_POST['needscpu'][$i])) ?>
<tr class='deps'>
   <td></td>
   <td><input type="button" onclick="insertRow(this);" value=" + " title="Add Needs Resource"></td>
</tr>
</table>
<input type="hidden" name = "object" value = "stream">
<?
}

// ---------------------------------------------------------------  //

function iwd_submit_job_to_arr($post){
   return $post;
}

function iwd_submit_stream_to_arr($post){
   return $post;
}

// ---------------------------------------------------------------  //

function iwd_submit_job_to_conman($arr){
   foreach($arr as $key=>$val)
      $$key = tws_gpc_get($val);
   if(trim($workstation) == '' || trim($job) == ''){
         tws_error('empty workstation or job name');
         return false;
   }
   $deps="";

   if ($intojobstream != "") {
      @list($into_jobstream_name,$into_jobstream_id)=explode(';',$intojobstream);
      if( $into_jobstream_id )
         $intojobstream="$into_jobstream_id;schedid";
      else $intojobstream=$into_jobstream_name;
      if ($intocpu != "")
         $deps .= ";into=$intocpu#$intojobstream";
      else
         $deps .= ";into=$intojobstream";
   }

   if ($aliasname != "")
      $deps .= ";alias=$aliasname";

      if (tws_yesno(tws_get_tz_status(),TRUE,FALSE))
         $time_zone = ($time_zone!='' && $time_zone!='NULL') ? ' timezone '.$time_zone : '';
      else $time_zone = '';

   if (($athour != "") && ($atminute != "")) {
      $deps .= ";at=$athour$atminute$time_zone";
      if ($atplusdays != "")
         $deps .= "+$atplusdays days";
   }
   elseif (($athour != "") || ($atminute != "")) {
      tws_error("AT=$athour:$atminute $time_zone +:$atplusdays days", 'Invalid AT time specification.');
      return FALSE;
   }

   if (($untilhour != "") && ($untilminute != "")) {
      $deps .= ";until=$untilhour$untilminute$time_zone";
      if ($untilplusdays != "")
         $deps .= "+$untilplusdays days";
      $onuntil = ';onuntil '.$onuntil;
      $deps .= $onuntil;
   }
   elseif (($untilhour != "") || ($untilminute != "")) {
      tws_error("UNTIL=$untilhour:$untilminute TZ:$time_zone +:$untilplusdays", 'Invalid UNTIL time specification.');
      return FALSE;
   }

   if (($deadlinehour != "") && ($deadlineminute != "")) {
      $deps .= ";deadline=$deadlinehour$deadlineminute$time_zone";
      if ($deadlineplusdays != "")
         $deps .= "+$deadlineplusdays days";
   }
   elseif (($deadlinehour != "") || ($deadlineminute != "")) {
      tws_error("DEADLINE=$deadlinehour:$deadlineminute TZ:$time_zone +:$deadlineplusdays", 'Invalid DEADLINE time specification.');
      return FALSE;
   }

   if ($everyminute != "")
      $deps .= ";every=$everyhour$everyminute";
   elseif (($everyhour != "") || ($everyminute != "")) {
      tws_error("EVERY=$everyhour:$everyminute", 'Invalid EVERY time format');
      return FALSE;
   }

   if ($privalue != "")
      $deps .= ";pri=$privalue";

   if ($confirmed == "yes")
      $deps .= ";confirmed";

   if ($critical == "yes")
      $deps .= ";critical";

   $first = TRUE;
   if(empty($followsjobstreamname)) $followsjobstreamname = array();
   foreach ($followsjobstreamname as $key => $value) {
      if ($value != "") {
         list($follows_jobstream_name, $follows_jobstream_id) = explode(';', $value);
         if($follows_jobstream_id)
            $follows_jobstream_name = $follows_jobstream_id.";schedid";
         if ($followsjobstreamcpu[$key] != "")
            $deps .= $first ? ";follows=$followsjobstreamcpu[$key]#$follows_jobstream_name" : ",$followsjobstreamcpu[$key]#$follows_jobstream_name";
         else $deps .= $first ? ";follows=$follows_jobstream_name" : ",$follows_jobstream_name";
         $first = FALSE;
      }
   }

   $first = TRUE;
   if(empty($followsjobname)) $followsjobname = array();
   foreach ($followsjobname as $key => $value) {
      if (($value != '') && ($followsjobjobstream[$key] != '')) {
         list($follows_job_jobstream_name,$follows_job_jobstream_id)=explode(';',$followsjobjobstream[$key]);
         if($follows_job_jobstream_id)
            $followsjob = $follows_job_jobstream_id.'.'.$value.";schedid";
         else
            $followsjob = $follows_job_jobstream_name.'.'.$value;
         if ($followsjobcpu[$key] != '')
            $deps .= $first ? ";follows=$followsjobcpu[$key]#$followsjob" : ",$followsjobcpu[$key]#$followsjob";
         else $deps .= $first ? ";follows=$followsjob" : ",$followsjob";
         $first=FALSE;
      }
   }

   $first = TRUE;
   if(empty($promptname)) $promptname = array();
   foreach ($promptname as $value) {
      if ($value != '') {
        $deps .= $first ? ";prompt=$value" : ",$value";
        $first = FALSE;
      }
   }
   if(empty($prompttext)) $prompttext = array();
   foreach ($prompttext as $value) {
      if ($value != '') {
        $value = addcslashes($value,'"');
        if ($host_os=='win32')
           $deps .= $first ? ";prompt='$value'" : ",'$value'";
        else $deps .= $first ? ";prompt=\"$value\"" : ",\"$value\"";
        $first = FALSE;
      }
   }

   $first = TRUE;
   if(empty($opensfile)) $opensfile = array();
   foreach ($opensfile as $key => $value) {
      if ($value != '') {
         $value = addcslashes($value,'"');
         if ($openscpu[$key] != '')
            $deps .= $first ? ";opens=$openscpu[$key]#\"$value\"" : ",$openscpu[$key]#\"$value\"";
         else $deps .= $first ? ";opens=\"$value\"" : ",\"$value\"";
         $first = FALSE;
      }
   }

   $first = TRUE;
   if(empty($resource)) $resource = array();
   foreach ($resource as $key => $value) {
      if ($value != '') {
         if ($needscpu[$key] != '')
            $deps .= $first ? ";needs=$units[$key] $needscpu[$key]#$value" : ",$units[$key] $needscpu[$key]#$value";
         else $deps .= $first ? ";needs=$units[$key] $value" : ",$units[$key] $value";
         $first = FALSE;
      }
   }

   if ($parameter_table != "")
      $deps .= ";vartable=$parameter_table";

 return "$workstation#$job".$deps;

}

function iwd_submit_stream_to_conman($arr){

   foreach($arr as $key=>$val)
      $$key = tws_gpc_get($val);

   if(trim($workstation) == '' || trim($jobstream) == ''){
         tws_error('empty workstation or jobstream name');
         return false;
   }
   $deps="";

   if ($aliasname != "")
      $deps .= ";alias=$aliasname";

   if ($schedtime!='') {
      if (preg_match('!([0-9:/ \-]+)\s*(\+\s*\d+\s*days)?$!i', $schedtime, $r)) {
         $dt=$r[1];
         $pd=$r[2];
         $deps.=trim(';schedtime='.tws_userdate_to_conman($dt).' '.$pd);
      } else {
         tws_error("SCHEDTIME=$schedtime", 'Invalid format of SCHEDTIME parameter');
         return false;
      }
   }
   if (tws_yesno(tws_get_tz_status(),TRUE,FALSE))
      $time_zone = ($time_zone!='' && $time_zone!='NULL') ? ' timezone '.$time_zone : '';
   else $time_zone = '';

   if (($athour != "") && ($atminute != "")) {
      $deps .= ";at=$athour$atminute$time_zone";
      if ($atplusdays != "")
         $deps .= "+$atplusdays days";
   }
   elseif (($athour != "") || ($atminute != "")) {
      tws_error("AT=$athour:$atminute TZ: $time_zone +:$atplusdays days", 'Invalid AT time specification.');
      return false;
   }
   if (($untilhour != "") && ($untilminute != "")) {
      $deps .= ";until=$untilhour$untilminute$time_zone";
      if ($untilplusdays != "")
         $deps .= "+$untilplusdays days";
      $onuntil = ';onuntil '.$onuntil;
      $deps .= $onuntil;
   }
   elseif (($untilhour != "") || ($untilminute != "")) {
      tws_error("UNTIL=$untilhour:$untilminute TZ:$time_zone +:$untilplusdays", 'Invalid UNTIL time specification.');
      return false;
   }

   if (($deadlinehour != "") && ($deadlineminute != "")) {
      $deps .= ";deadline=$deadlinehour$deadlineminute$time_zone";
      if ($deadlineplusdays != "")
         $deps .= "+$deadlineplusdays days";
   }
   elseif (($deadlinehour != "") || ($deadlineminute != "")) {
      tws_error("DEADLINE=$deadlinehour:$deadlineminute TZ:$time_zone +:$deadlineplusdays", 'Invalid DEADLINE time specification.');
      return false;
   }

   if ($privalue != "")
      $deps .= ";pri=$privalue";

   if ($limitvalue != "")
      $deps .= ";limit=$limitvalue";

   if ($carryforward == "yes")
      $deps .= ";carryforward";

   $first = true;
   foreach ($followsjobstreamname as $key => $value) {
      if ($value != "") {
         @list($follows_jobstream_name, $follows_jobstream_id) = explode(';', $value);
         if($follows_jobstream_id)
            $follows_jobstream_name = $follows_jobstream_id.";schedid";
         if ($followsjobstreamcpu[$key] != "")
            $deps .= $first ? ";follows=$followsjobstreamcpu[$key]#$follows_jobstream_name" : ",$followsjobstreamcpu[$key]#$follows_jobstream_name";
         else
            $deps .= $first ? ";follows=$follows_jobstream_name" : ",$follows_jobstream_name";
         $first = false;
      }
   }

   $first = true;
   foreach ($followsjobname as $key => $value) {
      if (($value != '') && ($followsjobjobstream[$key] != '')) {
         @list($follows_job_jobstream_name,$follows_job_jobstream_id)=explode(';',$followsjobjobstream[$key]);
         if($follows_job_jobstream_id)
            $followsjob = $follows_job_jobstream_id.'.'.$value.";schedid";
         else
            $followsjob = $follows_job_jobstream_name.'.'.$value;
         if ($followsjobcpu[$key] != '')
            $deps .= $first ? ";follows=$followsjobcpu[$key]#$followsjob" : ",$followsjobcpu[$key]#$followsjob";
         else
            $deps .= $first ? ";follows=$followsjob" : ",$followsjob";
      }
      $first = false;
   }

   $first = true;
   foreach ($promptname as $value) {
      if ($value != '') {
        $deps .= $first ? ";prompt=$value" : ",$value";
        $first = false;
      }
   }
   foreach ($prompttext as $value) {
      if ($value != '') {
        if ($host_os=='win32') {
           $value = str_replace("'", '"', $value);
           $deps .= $first ? ";prompt='$value'" : ",'$value'";
        }
        else {
           $value = addcslashes($value,'"');
           $deps .= $first ? ";prompt=\"$value\"" : ",\"$value\"";
        }
        $first = false;
      }
   }

   $first = true;
   foreach ($opensfile as $key => $value) {
      if ($value != '') {
         $value = addcslashes($value,'"');
         if ($openscpu[$key] != '')
            $deps .= $first ? ";opens=$openscpu[$key]#\"$value\"" : ",$openscpu[$key]#\"$value\"";
         else
            $deps .= $first ? ";opens=\"$value\"" : ",\"$value\"";
         $first = false;
      }
   }

   $first = true;
   foreach ($resource as $key => $value) {
      if ($value != '') {
         if ($needscpu[$key] != '')
            $deps .= $first ? ";needs=$units[$key] $needscpu[$key]#$value" : ",$units[$key] $needscpu[$key]#$value";
         else
            $deps .= $first ? ";needs=$units[$key] $value" : ",$units[$key] $value";
         $first = false;
      }
   }

   if ($parameter_table != "")
      $deps .= ";vartable=$parameter_table";

 return "$workstation#$jobstream".$deps;
}

// ---------------------------------------------------------------  //

function iwd_arr_to_job_submit($arr, $display){
   iwd_show_submit_job_form($arr, $display);
}

function iwd_arr_to_stream_submit($arr, $display){
   iwd_show_submit_stream_form($arr, $display);
}

?>
