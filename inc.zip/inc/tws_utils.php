<?php
//   HORIZONT Software GmbH, Munich
//

if (!function_exists('INFO')) {
   function INFO($msg) {
      echo date('Y-m-d H:i:s').' INFO  '.rtrim($msg)."\n";
   }
}

if (!function_exists('TRACE')) {
   function TRACE($msg) {
      echo date('Y-m-d H:i:s').' TRACE '.rtrim($msg)."\n";
   }
}

if (!function_exists('ERROR')) {
   function ERROR($msg) {
      echo date('Y-m-d H:i:s').' ERROR '.rtrim($msg)."\n";
   }
}

if (!function_exists('WARNING')) {
   function WARNING($msg) {
      echo date('Y-m-d H:i:s').' WARNING '.rtrim($msg)."\n";
   }
}

// $mode = 'INIT' | 'RUN' | 'CLOSE'
function tws_event_tracker($mode) {
   global $tws_config;
   static $enabled_events, $et_conf, $last_run;
   $version='1.0';

//main
   switch ($mode) {
      case 'INIT' :
/*       INFO("IWS Web Services enabled");
         $tws_config['tws_web_services'] = 'yes';
*/
         $enabled_events = tws_get_enabled_events();

         $et_conf = $tws_config['event_tracker'];
         $last_run=time();
//defaults
         if (!isset($et_conf['run_period'])) $et_conf['run_period'] = 60; //sec
         if (!isset($et_conf['joblong_threshold'])) $et_conf['joblong_threshold'] = 1.5;
         if (!isset($et_conf['joblong_ignore'])) $et_conf['joblong_ignore'] = 60; //sec
         $et_conf_str='';  foreach($et_conf as $key=>$val) $et_conf_str.="$key=$val,";
         INFO('Event Tracker '.$version.' - INIT ('.$et_conf_str.')');
         TRACE('Event Tracker - INIT, ENABLED EVENTS: '.implode(',', $enabled_events));
         break;

      case 'RUN' :
         if ((($t=time()) - $last_run) > $et_conf['run_period']) {
            TRACE('Event Tracker - RUN');
            $new_enabled_events=tws_get_enabled_events();
            $last_run=$t;
            if ($new_enabled_events && in_array('1001',$new_enabled_events)) {   // upd: tws_get_enabled_events can return false, so warning is generated here
               if (!in_array('1001',$enabled_events)) {
                  TRACE('Event Tracker - Enabled Events (BmEvents.conf) modified, reinitialization forced');
                  tws_event_tracker('INIT');
               } else {
                  $new_enabled_events=$enabled_events;
               }
               TRACE('Event Tracker - 1001 Job Long');
               tws_joblong($et_conf['joblong_threshold'],$et_conf['joblong_ignore']);
            }
         } else {
            TRACE('Event Tracker - WAITING');
         }
         break;

      case 'CLOSE' :
         TRACE('Event Tracker - CLOSE');
         break;
   }
}

function tws_joblong($threshold,$ignore) {
   static $finished='';
   global $tws_config;
   global $joblong_threshold, $joblong_ignore, $joblong_pool_in, $joblong_pool_out, $cur_time, $joblong_lowtime;

   $joblong_threshold = $threshold;
   $joblong_ignore = $ignore;
   // covert threshold if set in %
   if (strstr($joblong_threshold,"%")) {
      $joblong_threshold /= 100;
   }

   $joblong_pool_in = array();
   $joblong_pool_out = array();

// pool of all already issued messages
   if (($fd = fopen($tws_config['maestro_dir'].'/webadmin/log/tws_event.log','r')) === FALSE) {
      tws_error('', 'Unable to open '.$tws_config['maestro_dir'].'/webadmin/log/tws_event.log for reading');
      ERROR('JOBLONG: Unable to open '.$tws_config['maestro_dir'].'/webadmin/log/tws_event.log for reading');
      return FALSE;
   } else {
      $schedid_pos = 4 + $tws_config['WORKSTATION_MAXLENGTH'] + 2;
      $jobcpu_pos = $schedid_pos + $tws_config['SCHEDID_MAXLENGTH'] + $tws_config['JOB_MAXLENGTH'] + 2;
      $jobid_pos = $jobcpu_pos + $tws_config['SCHEDID_MAXLENGTH'] + 1;
      $i = 0;
      while (!feof($fd)) {
         $log = fgets($fd);
         if (substr($log,0,4) === "1001") {
            $joblong_pool_in[$i][0] = trim(substr($log,$jobcpu_pos,$tws_config['SCHEDID_MAXLENGTH']));   // jobcpu
            $joblong_pool_in[$i][1] = trim(substr($log,$schedid_pos,$tws_config['SCHEDID_MAXLENGTH']));  // schedid
            $jobid = explode(" ",substr($log,$jobid_pos));                                               // jobid
            $joblong_pool_in[$i][2] = $jobid[0];
            $i++;
         }
      }
      $fd = fclose($fd);
   }

// Get plan jobs
   TRACE('JOBLONG: Calling tws_get_plan_job_list(@#@.@'.$finished.')');
   $t=date('Y-m-d H:i:s',time()-1);
// set up the current time for joblong_callback (minutes - for further comparisons with conman's times)
   $cur_time = (date('H') * 60) + date('i');

   //initialize joblong_lowtime - filterring out jobs that are older than the current plan date (previous plan jobs)
   $sym_date = tws_get_symdate();
   $joblong_lowtime = mktime(0, 0, 0, substr($sym_date,5,2), substr($sym_date,8,2), substr($sym_date,0,4));

   $result=tws_get_plan_job_list('@#@.@'.$finished, 0, 0, 0, 'joblong_callback');
   if ($result===FALSE) {
      ERROR('JOBLONG: Unable to get plan jobstream list, more details in webadmin_error.log');
      $finished='';
      return FALSE;
   }

   //If finished is used alone and it is preceded by ~ then the jobs selected are
   //the jobs that have not finished running.
   //in the next processing we want to process jobs that were STILL RUNNING in time range (-oo; $t)
   $finished='~finished=,'.tws_userdate_to_conman(tws_iso_to_userdate($t));
   if ($result['nrows']==0) {
      TRACE('JOBLONG: No qualified entries');
      return 0;
   }

// update a event log with a new messages
   if (count($joblong_pool_out) > 0) {
      if (($fd = fopen($tws_config["maestro_dir"]."/webadmin/log/tws_event.log","a")) === FALSE) {
         tws_error('', 'Unable to open '.$tws_config['maestro_dir'].'/webadmin/log/tws_event.log for writing');
         ERROR('JOBLONG: Unable to open '.$tws_config['maestro_dir'].'/webadmin/log/tws_event.log for writing');
         return FALSE;
      }
      for ($i = 0; $i < count($joblong_pool_out); $i++) {
         if (fwrite($fd,$joblong_pool_out[$i].($tws_config["host_os"] == "win32" ? "\r\n" : "\n")) === FALSE) {
            $fd = fclose($fd);
            tws_error('', 'Unable to write to file '.$tws_config['maestro_dir'].'/webadmin/log/tws_event.log');
            ERROR('JOBLONG: Unable to write to file  '.$tws_config['maestro_dir'].'/webadmin/log/tws_event.log for writing');
            return FALSE;
         }
      }
      $fd = fclose($fd);
      INFO("JOBLONG: Added $i new 1001 event type messages(s) to tws_event.log");
      return $i;
   } else {
      TRACE('JOBLONG: No new event added to tws_event.log');
      return 0;
   }
}

/// DISPLAY CALLBACK FUNCTIONS
///
function joblong_callback(&$sjs, $ia, $ib) {
   global $tws_config, $tws_status_plan, $joblong_threshold, $joblong_ignore, $joblong_pool_in,  $joblong_pool_out, $cur_time, $joblong_lowtime;
   $cur_time_save = $cur_time;
   $cur_time_offset = (date('H') * 60) + date('i');

   //go through the set of jobs in the plan
   for ($i = $ia; $i <= $ib; $i++) {
      if ((strtoupper($sjs['entry_type'][$i]) === 'JOB') &&
          ((strtoupper($sjs['state'][$i]) === 'EXEC') ||
           (strtoupper($sjs['state'][$i]) === 'SUCC') ||
           (strtoupper($sjs['state'][$i]) === 'ABEND'))) {

         $job_dbid=$sjs['jobcpu'][$i].'#'.$sjs['job'][$i];
         $job_planid=$sjs['cpu'][$sjs['sched_idx'][$i]].'#'.$sjs['schedid'][$sjs['sched_idx'][$i]].'.'.$sjs['job'][$i].';schedid';

         TRACE('JOBLONG: Processing job '.$job_planid.', state='.$sjs['state'][$i].', ST='.$sjs['start_time'][$i].', ELA(ETA)='.$sjs['elapse_time'][$i] );

         $start_time = 0;
         $cur_time = $cur_time_save;
         if (strpos($sjs['start_time'][$i],'/') === FALSE) {
            $start_time = preg_replace('/[^\d\s]/','',$sjs['start_time'][$i]);
            $start_time = (intval(substr($start_time,0,2)) * 60) + intval(substr($start_time,2));
            if ($start_time - $cur_time - $cur_time_offset > ceil($tws_config['event_tracker']['run_period']/60)) {
               TRACE(' - Start time '.$start_time.' bigger than the start of measurement '.$cur_time.' (current time offset='.$cur_time_offset.'). Assuming a job start from previous day');
               // roll to a new day
               // WARNING: sometimes jobs that have starttime>cur_time are being processed
               //          the difference is small (about 1 or 2) but it's not the "midnight problem"
               //          5 is a magic constant just to make the copmparison safer
               $cur_time_save = $cur_time;
               $cur_time += 24 * 60;
            }
         } else {
            // ignore jobs older than current symdate
            $starttime_timestamp = mktime(0, 0, 0, substr($sjs['start_time'][$i],0,2), substr($sjs['start_time'][$i],3,2), date('Y',time()));
            if ($starttime_timestamp < $joblong_lowtime) {
               //skip this job
               continue;
            }
            TRACE(' - Unable to determine the start time of the job '.$job_planid.' ('.$sjs['start_time'][$i].')');
            //as the start time is not known, we set the start_time to the current time to avoid 
            //triggering a false 1001 event
            $start_time=$cur_time;
         }

         // get the average elapse time
         // EST from DB is more accurate as from conman
         if (($jobstats = tws_get_job_stats($sjs['jobcpu'][$i],$sjs['job'][$i]))===FALSE) {
            ERROR("JOBLONG: Unable to get job history run statistics");
            tws_error('', "joblong_callback: (JOBLONG) Unable to get job history run statistics");
         }

         // ignore alias jobs
         if (count($jobstats)===0) {
            WARNING("JOBLONG: Missing runtime statistics of job $job_dbid (alias or rarely running job?) ");
            continue;
         } else {
            if (isset($jobstats['average_elapsed_time']) && intval($jobstats['average_elapsed_time'])>0) {
               $estimate_time = abs($jobstats['average_elapsed_time']) / 60000; //[min]
            } else {
               ERROR("JOBLONG: Missing the average elapsed time of job $job_dbid");
               continue;
            }
         }

         // get the actual elapse time
         if (strtoupper($sjs['state'][$i]) === 'EXEC') {
            $elapse_time = ($cur_time - $start_time);
         } else {
            $elapse_time = preg_replace("/[^0-9\s]/","",$sjs['elapse_time'][$i]);
            $elapse_time = (substr($elapse_time,0,2) * 60) + substr($elapse_time,2);
         }

         // ignore a short jobs
         if ($elapse_time <= ($joblong_ignore/60)) {
            TRACE(' - Ignoring job '.$job_planid.' : (short job) EST='.$estimate_time.', ELA='.$elapse_time);
            continue;
         }

         // count if job running time is exceeded or not
         if (($estimate_time * $joblong_threshold + 1) >= $elapse_time) {
            TRACE(' - Skipping job '.$job_planid.' (in accepted runtime range) EST='.$estimate_time.', ELA='.$elapse_time);
            continue;
         }

         // find if event for overlap job already exists
         //TODO: better structure of the joblong pool : key should be $job_planid
         $jobnum = explode('.',$sjs['jobnum'][$i]);
         $already_logged = FALSE;
         for ($j = 0; $j < count($joblong_pool_in); $j++) {
            if (($joblong_pool_in[$j][0] == $sjs['jobcpu'][$i]) &&                       // jobcpu
                ($joblong_pool_in[$j][1] == $sjs['schedid'][$sjs['sched_idx'][$i]]) &&   // schedid
                ($joblong_pool_in[$j][2] == $jobnum[0])) {                               // jobid
               $already_logged = TRUE;
               TRACE(' - Skipping job '.$job_planid.' (event already logged) EST='.$estimate_time.', ELA='.$elapse_time);
               break;
            }
         }

         // create a event record
         if (!$already_logged) {
            if (($info_list = tws_get_plan_job_info_list($job_planid, 0))===FALSE) {
               ERROR('JOBLONG: Unable to get job INFO data (tws_get_plan_job_info_list('.$job_planid.') failed. See webadmin_error.log for more details.)');
               tws_error('', 'joblong_callback: (JOBLONG) Unable to get job INFO data');
            }
            if (($logon_list = tws_get_plan_job_logon_list($job_planid, 0)) === FALSE) {
               ERROR('JOBLONG: Unable to get job LOGON data (tws_get_plan_job_info_list('.$job_planid.') failed. See webadmin_error.log for more details.)');
               tws_error('', 'joblong_callback: (JOBLONG) Unable to get job LOGON data');
            }

            //the "conman sj xxx;logon" in TWS8.5 has stability issues and often excits with coredump, therefore
            //it's necessary to cartefuly verify the detected data
            $script = isset($info_list['script'][$info_list['nrows']]) && trim($info_list['script'][$info_list['nrows']])!='' ? trim(str_replace(array("\\"," "),array("\\\\",'\040'),$info_list['script'][$info_list['nrows']])) : 'N/A';
            $prompt_text = isset($info_list['recovery_prompt'][$info_list['nrows']]) && trim($info_list['recovery_prompt'][$info_list['nrows']])!='' ? $info_list['recovery_prompt'][$info_list['nrows']] : 'N/A';
            $logon = isset($logon_list['logon'][$logon_list['nrows']]) && trim($logon_list['logon'][$logon_list['nrows']])!='' ? $logon_list['logon'][$logon_list['nrows']] : 'N/A';

            //1001 event message structure         len  description
            //    [1] => 1001                   -- (x)  Event number
            //    [2] => PC13                   -- (16) Schedule workstation name
            //    [3] => 0AAAAAAAAAAACJBR       -- (16) Schedule id
            //    [4] => LS                     -- (40) Job name
            //    [5] => PC13                   -- (16) Workstation name on which the job runs
            //    [6] => 1114                   -- (x)  Job number
            //    [7] => 6                      -- (x)  Job state
            //    [8] => LS                     -- (40) Job's submitted (real) name
            //    [9] => tws83                  -- (x)  Logon
            //    [10] => ls\040-la             -- (x)  Name of the job's script file, or the command it runs
            //    [11] => -32768                -- (x)  The rate at which an "every" job runs
            //    [12] => 1                     -- (x)  Job recovery step
            //    [13] => 2008081912550000      -- (x)  An event timestamp
            //    [14] => 0                     -- (x)  Recovery prompt number
            //    [15] => \t +++ \t             -- (x)  \trecovery prompt text\t
            //    [16] => 0                     -- (x)  Job record number
            //    [17] => 0                     -- (x)  Job keyflag
            //    [18] => 0                     -- (x)  Effective start time of the job
            //    [19] => 0                     -- (x)  Estimated start time of the job
            //    [20] => 0                     -- (x)  Estimated duration of the job
            //    [21] => 0                     -- (x)  Deadline in Epoch
            //    [22] => 0                     -- (x)
            //    [23] => 0AAAAAAAAAAACJBR      -- (16) Schedule id
            //    [24] => 0                     -- (x)
            //    [25] => JOBLONG               -- (x)  Job stream name, left padded
            //    [26] => 0                     -- (x)  Any timestamp
            //    [27] => v.4                   -- (x)  v.4

            $j = 1;
            $newline[$j++] = "1001";
            $newline[$j++] = str_pad($sjs['cpu'][$sjs['sched_idx'][$i]],$tws_config['WORKSTATION_MAXLENGTH']);
            $newline[$j++] = str_pad($sjs['schedid'][$sjs['sched_idx'][$i]],$tws_config['SCHEDID_MAXLENGTH']);
            $newline[$j++] = str_pad($sjs['job'][$i],$tws_config['JOB_MAXLENGTH']);
            $newline[$j++] = str_pad($sjs['jobcpu'][$i],$tws_config['SCHEDID_MAXLENGTH']);
            $newline[$j++] = $jobnum[0];
            $newline[$j++] = array_search($sjs['state'][$i], $tws_status_plan);
            $newline[$j++] = str_pad($sjs['job'][$i],$tws_config['JOB_MAXLENGTH']);
            $newline[$j++] = ($logon === "") ? "N/A" : $logon;
            $newline[$j++] = ($script === "") ? "N/A" : $script;
            $newline[$j++] = "-32768";
            $newline[$j++] = "1";
            $newline[$j++] = date("YmdHis00");
            $newline[$j++] = "0";
            $newline[$j++] = "\t" . $prompt_text . "\t";
            $newline[$j++] = "0";
            $newline[$j++] = "0";
            $newline[$j++] = "0";
            $newline[$j++] = "0";
            $newline[$j++] = "0";
            $newline[$j++] = "0";
            $newline[$j++] = "0";
            $newline[$j++] = str_pad($sjs['schedid'][$sjs['sched_idx'][$i]],$tws_config['SCHEDID_MAXLENGTH']);
            $newline[$j++] = "0";
            $newline[$j++] = str_pad($sjs['schedule'][$sjs['sched_idx'][$i]],$tws_config['JOBSTREAM_MAXLENGTH'], " ", STR_PAD_LEFT);
            $newline[$j++] = "0";
            $newline[$j++] = "v.4";

            $record = "";
            for ($k = 1; $k < $j; $k++) {
               $record .= $newline[$k].' ';
            }

            $joblong_pool_out[] = $record;

            TRACE(" - New event 1001 detected, written to tws_event.log:\n$record");
         }
      }
   }
}
?>
