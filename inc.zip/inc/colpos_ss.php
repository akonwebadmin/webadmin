<?php
//   HORIZONT Software GmbH, Munich
//

   $col[1]=2;     // cpu
   $len[1]=16;
   $col[2]=19;    // schedule
   $len[2]=16;
   $col[3]=36;    // chedtime
   $len[3]=10;
   $col[4]=48;    // state
   $len[4]=5;
   $col[5]=54;    // priority
   $len[5]=2;
   $col[6]=56;    // start time
   $len[6]=7;
   $col[7]=63;    // elapse time
   $len[7]=8;
   $col[8]=71;    // num jobs
   $len[8]=4;
   $col[9]=75;    // OK jobs
   $len[9]=4;
   $col[10]=79;   // limit
   $len[10]=4;
   $col[11]=88;   // deps
   $len[11]=935;
?>